# EcoDAVA 1.0.1

EcoDAVA is distributed as a standard source R package containing the original
Shiny application as installed resources. The launcher keeps installed files
read-only and stores workspaces, external plugins, and mutable settings in the
current user's R data directory.

## Install in RStudio

For a new R installation, use the bundled installer. It supports both the
Windows binary ZIP and the source archive, installs missing dependencies, and
updates outdated EcoDAVA dependencies before installing EcoDAVA:

```r
source("install_dava_local.R")
```

Alternatively, run it explicitly from a terminal:

```sh
Rscript install_dava_local.R EcoDAVA_1.0.1.tar.gz
```

Pass `--no-update` after the archive name to install missing dependencies
without updating already installed ones. Direct installation through
**Tools > Install Packages > Package Archive File** remains supported, but
base R does not fetch dependencies for local archives installed with
`repos = NULL`. If `shinyjqui` alone is missing, `library(EcoDAVA)` now repairs
that dependency automatically. You can also run
`EcoDAVA::dava_install_dependencies(update = TRUE)` at any time.

The package contains no compiled R/C/C++ code, so normal source installation
does not require compilation.

## Run

```r
library(EcoDAVA)
run_dava()
```

By default `run_dava()` opens in RStudio's standalone internal Shiny window,
not in the embedded Viewer pane. If that standalone IDE window is unavailable,
EcoDAVA opens the local URL in the operating system's default browser. Use
`run_dava(launch.browser = FALSE)` to disable automatic browser opening.

To inspect dependency availability:

```r
dava_dependency_status()
```

Individual analytical methods can require additional CRAN, Bioconductor,
GitHub, or archived specialist packages. On the first run of a method, EcoDAVA
checks its method registry, automatically installs missing dependencies from
the declared source, verifies that each namespace is loadable, and then
continues the analysis. Installation errors identify the unresolved packages
and commonly indicate a network, repository, or system compiler prerequisite.

The large Tax4Fun2 reference database is intentionally not embedded in the R
package. Select an external `Tax4Fun2_ReferenceData_v2` directory in the
Tax4Fun2 method settings when that analysis is used.

The package and application use platform-neutral paths and user data
directories on Windows, macOS, and Linux. A platform-neutral build can be
created from the project root with:

```r
Rscript tools/package_dava.R --build --output=dist
```

## Mutable files

By default EcoDAVA writes below `tools::R_user_dir("EcoDAVA", "data")`. Supply a
different writable directory when needed:

```r
run_dava(state_dir = "D:/EcoDAVA-data")
```

## Release metadata

Before public repository or CRAN-style submission, replace the placeholder
maintainer email, add the real project and issue-tracker URLs to `DESCRIPTION`,
and confirm the copyright holder and distribution licence.
