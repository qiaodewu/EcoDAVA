# Scientific plotting module for publication-ready and interactive figures.

plot_demo_data_generate <- function(plot_type = "box", seed = 2026L) {
  set.seed(seed)
  if (plot_type == "box") {
    design <- expand.grid(Treatment = factor(c("Control", "Low", "Medium", "High")),
      Site = factor(c("Meadow", "Steppe")), Replicate = seq_len(18L), KEEP.OUT.ATTRS = FALSE)
    design$Response <- 12 + as.numeric(design$Treatment) * 1.6 +
      ifelse(design$Site == "Meadow", 1.2, -0.4) + stats::rnorm(nrow(design), sd = 1.4)
    return(design[, c("Treatment", "Response", "Site", "Replicate")])
  }
  if (plot_type == "bar") {
    design <- expand.grid(Category = factor(c("Root", "Stem", "Leaf", "Flower")),
      Group = factor(c("Control", "Treatment")), Site = factor(c("North", "South")),
      Replicate = seq_len(12L), KEEP.OUT.ATTRS = FALSE)
    design$Measurement <- 18 + as.numeric(design$Category) * 2.2 +
      ifelse(design$Group == "Treatment", 3.5, 0) + stats::rnorm(nrow(design), sd = 2)
    return(design[, c("Category", "Measurement", "Group", "Site", "Replicate")])
  }
  if (plot_type == "pie") {
    categories <- factor(c("Grasses", "Forbs", "Legumes", "Shrubs", "Bare ground"),
      levels = c("Grasses", "Forbs", "Legumes", "Shrubs", "Bare ground"))
    return(data.frame(Category = rep(categories, times = c(44L, 28L, 18L, 7L, 3L))))
  }
  if (plot_type == "scatter") {
    n <- 120L
    predictor <- stats::runif(n, 2, 18)
    group <- factor(sample(c("Control", "Treatment A", "Treatment B"), n, replace = TRUE))
    site <- factor(sample(c("Site 1", "Site 2"), n, replace = TRUE))
    response <- 4 + 1.15 * predictor + as.numeric(group) * 1.8 + stats::rnorm(n, sd = 2.1)
    return(data.frame(Predictor = predictor, Response = response, Group = group, Site = site,
      SampleID = sprintf("S%03d", seq_len(n))))
  }
  if (plot_type == "line") {
    design <- expand.grid(Time = seq(0, 12, by = 1), Treatment = factor(c("Control", "Low", "High")),
      Site = factor(c("Site 1", "Site 2")), KEEP.OUT.ATTRS = FALSE)
    design$Response <- 8 + 0.65 * design$Time + as.numeric(design$Treatment) * 1.5 +
      sin(design$Time / 2) + stats::rnorm(nrow(design), sd = 0.45)
    return(design[, c("Time", "Response", "Treatment", "Site")])
  }
  if (plot_type %in% c("corr", "tree", "network")) {
    n <- if (plot_type == "tree") 36L else 120L
    climate <- stats::rnorm(n)
    moisture <- -0.72 * climate + stats::rnorm(n, sd = 0.55)
    soil_n <- 0.68 * moisture + stats::rnorm(n, sd = 0.6)
    biomass <- 0.65 * soil_n - 0.35 * climate + stats::rnorm(n, sd = 0.55)
    richness <- 0.62 * biomass + stats::rnorm(n, sd = 0.65)
    return(data.frame(Climate = climate, Moisture = moisture, SoilN = soil_n,
      Biomass = biomass, Richness = richness, SampleID = sprintf("S%03d", seq_len(n))))
  }
  if (plot_type == "upset") {
    n <- 140L
    return(data.frame(Grass = stats::runif(n) < 0.72, Forb = stats::runif(n) < 0.58,
      Legume = stats::runif(n) < 0.42, Shrub = stats::runif(n) < 0.25,
      RareSpecies = stats::runif(n) < 0.18))
  }
  stop("Unsupported plotting demo type: ", plot_type, call. = FALSE)
}

plot_demo_data <- function(plot_type = "box", seed = 2026L) {
  allowed <- c("box", "bar", "pie", "scatter", "line", "corr", "tree", "network", "upset")
  plot_type <- match.arg(plot_type, allowed)
  dava_local_demo_read(file.path("plotting", paste0(plot_type, ".rds")))
}

plot_demo_defaults <- function(plot_type) {
  switch(plot_type,
    box = list(x = "Treatment", y = "Response", group = "Treatment", facet = "Site", label = ""),
    bar = list(x = "Category", y = "Measurement", group = "Group", facet = "Site", label = ""),
    pie = list(x = "Category", y = "", group = "", facet = "", label = ""),
    scatter = list(x = "Predictor", y = "Response", group = "Group", facet = "Site", label = "SampleID"),
    line = list(x = "Time", y = "Response", group = "Treatment", facet = "Site", label = ""),
    corr = list(multi_numeric = c("Climate", "Moisture", "SoilN", "Biomass", "Richness")),
    tree = list(multi_numeric = c("Climate", "Moisture", "SoilN", "Biomass", "Richness")),
    network = list(multi_numeric = c("Climate", "Moisture", "SoilN", "Biomass", "Richness"),
      source = "", target = "", weight = ""),
    upset = list(set_vars = c("Grass", "Forb", "Legume", "Shrub", "RareSpecies")),
    list())
}

plot_title_by_type <- function(plot_type) {
  switch(
    plot_type,
    box = "Boxplot",
    bar = "Bar chart",
    pie = "Pie chart/donut chart",
    scatter = "Scatter plot",
    line = "Line/curve chart",
    corr = "Correlation graph",
    upset = "Collection map",
    tree = "Treemap",
    network = "Network diagram",
    plot_type
  )
}

plot_has_mojibake <- function(value) {
  if (is.null(value) || length(value) == 0) return(FALSE)
  value <- enc2utf8(as.character(value[[1]] %||% ""))
  if (is.na(value) || !nzchar(value)) return(FALSE)
  escaped_unicode_pattern <- paste0("<", "U", "\\+[0-9A-Fa-f]+>")
  mojibake_chars <- vapply(c(
    0x9365, 0x9422, 0x7F02, 0x7487, 0x93CD, 0x6D93, 0x752F,
    0x5BB8, 0x6434, 0x95C8, 0x7EFE, 0x6924, 0x6F70, 0x00C3,
    0x00C2, 0xFFFD
  ), intToUtf8, character(1))
  mojibake_markers <- c(
    mojibake_chars,
    intToUtf8(c(0x7F01, 0x7EBF, 0x56FE)),
    intToUtf8(c(0x7F01, 0x7DDA, 0x5716)),
    intToUtf8(c(0x79BB, 0x7EBF, 0x56FE)),
    intToUtf8(c(0x96E2, 0x7DDA, 0x5716))
  )
  grepl(escaped_unicode_pattern, value, perl = TRUE) ||
    any(vapply(mojibake_markers, function(marker) {
      grepl(marker, value, fixed = TRUE, useBytes = FALSE)
    }, logical(1)))
}

plot_clean_label <- function(value, fallback = "") {
  fallback <- fallback %||% ""
  fallback <- if (length(fallback) > 0) fallback[[1]] else ""
  fallback <- enc2utf8(as.character(fallback %||% ""))
  value <- value %||% fallback
  if (length(value) == 0 || is.null(value)) value <- fallback
  value <- enc2utf8(as.character(value[[1]] %||% fallback))
  escaped_unicode_pattern <- paste0("<", "U", "\\+[0-9A-Fa-f]+>")
  value <- gsub(escaped_unicode_pattern, "", value, perl = TRUE)
  value <- trimws(value)
  if (is.na(value) || !nzchar(value) || plot_has_mojibake(value)) {
    return(fallback)
  }
  value
}

plot_clean_labels <- function(values, fallback = "") {
  vapply(values %||% character(0), plot_clean_label, character(1), fallback = fallback, USE.NAMES = FALSE)
}

plot_numeric_vars <- function(df) dava_plot_numeric_vars(df)
plot_factor_vars <- function(df) dava_plot_factor_vars(df)

plot_palette_values <- function(name, n = 8) {
  dava_plot_palette(name, n)
}

plot_smooth_formula <- function(method = "lm") {
  if (identical(method, "gam")) stats::as.formula("y ~ s(x, bs = 'cs')") else y ~ x
}

plotly_ggplotly_status <- local({
  status <- NULL
  function() {
    if (!is.null(status)) return(status)
    if (!requireNamespace("plotly", quietly = TRUE)) {
      status <<- list(ok = FALSE, message = "The plotly package is not installed and static publication plot preview is currently used.")
      return(status)
    }

    test_plot <- ggplot2::ggplot(data.frame(x = 1:2, y = 1:2), ggplot2::aes(x, y)) +
      ggplot2::geom_point()
    err <- NULL
    ok <- tryCatch({
      plotly::ggplotly(test_plot)
      TRUE
    }, error = function(e) {
      err <<- conditionMessage(e)
      FALSE
    })

    status <<- list(
      ok = ok,
      message = if (ok) {
        "Use plotly interactive preview; PNG/PDF are still exported as static publishing figures."
      } else {
        paste0("Current plotly::ggplotly() andThis unit ggplot2/scales versionIncompatible，AlreadyAutomaticFall back to static publishing image。OriginalError：", err)
      }
    )
    status
  }
})
apply_plot_theme <- function(p, theme_name, base_size, show_legend, rotate_x) {
  dava_plot_theme(p, theme_name, base_size, "right", rotate_x, show_legend)
}

summarise_for_bar <- function(df, x, y, group, summary_fun, facet = "") {
  if ((summary_fun %||% "mean") %in% c("mean", "median")) {
    group_vars <- unique(c(x, group, facet))
    group_vars <- group_vars[nzchar(group_vars) & group_vars %in% names(df)]
    return(
      df |>
        dplyr::group_by(dplyr::across(dplyr::all_of(group_vars))) |>
        dplyr::summarise(
          n = sum(!is.na(.data[[y]])),
          mean = mean(.data[[y]], na.rm = TRUE),
          median = stats::median(.data[[y]], na.rm = TRUE),
          sd = stats::sd(.data[[y]], na.rm = TRUE),
          se = sd / sqrt(n),
          .groups = "drop"
        ) |>
        dplyr::mutate(value = if ((summary_fun %||% "mean") == "median") median else mean) |>
        as.data.frame()
    )
  }
  group_vars <- unique(c(x, group, facet))
  group_vars <- group_vars[group_vars != "" & group_vars %in% names(df)]
  df |>
    dplyr::group_by(dplyr::across(dplyr::all_of(group_vars))) |>
    dplyr::summarise(
      value = if ((summary_fun %||% "mean") == "sum") sum(.data[[y]], na.rm = TRUE) else dplyr::n(),
      se = stats::sd(.data[[y]], na.rm = TRUE) / sqrt(sum(!is.na(.data[[y]]))),
      n = dplyr::n(),
      .groups = "drop"
    ) |>
    as.data.frame()
}

make_corr_df <- function(df, vars, method = "pearson") {
  dava_plot_corr_df(analysis_numeric_df(df, vars), vars, method)
}

make_upset_df <- function(df, vars, min_count = 1) {
  dat <- df[, vars, drop = FALSE]
  dat[] <- lapply(dat, function(x) {
    if (is.logical(x)) return(x)
    if (is.numeric(x)) return(x > 0)
    !is.na(x) & trimws(as.character(x)) != "" & !tolower(as.character(x)) %in% c("0", "false", "no", "none")
  })
  combo <- apply(dat, 1, function(z) paste(vars[which(z)], collapse = " & "))
  combo[combo == ""] <- "None"
  as.data.frame(table(combo), stringsAsFactors = FALSE) |>
    dplyr::rename(set_combination = combo, count = Freq) |>
    dplyr::filter(count >= min_count) |>
    dplyr::arrange(dplyr::desc(count))
}

build_scientific_plot <- function(df, input, plot_type) {
  palette_vars <- input$group_var %||% ""
  if (!nzchar(palette_vars) && plot_type %in% c("box", "bar")) palette_vars <- input$x_var %||% ""
  palette_vars <- palette_vars[palette_vars %in% names(df)]
  required_colors <- if (length(palette_vars)) max(vapply(df[palette_vars], function(value) {
    length(unique(value[!is.na(value)]))
  }, integer(1))) else 1L
  palette <- plot_palette_values(input$palette %||% "Nature", max(10L, required_colors))
  base_size <- input$base_size %||% 14
  alpha <- input$alpha %||% 0.75
  point_size <- input$point_size %||% 2.4
  line_width <- input$line_width %||% 0.9
  x <- input$x_var %||% ""
  y <- input$y_var %||% ""
  group <- input$group_var %||% ""
  facet <- input$facet_var %||% ""
  label <- input$label_var %||% ""
  title <- plot_clean_label(input$plot_title, plot_title_by_type(plot_type))
  x_lab <- plot_clean_label(input$x_label, x)
  y_lab <- plot_clean_label(input$y_label, y)

  add_common <- function(p) {
    if (facet != "" && facet %in% names(df)) p <- p + ggplot2::facet_wrap(stats::as.formula(paste("~", facet)), scales = input$facet_scales %||% "fixed")
    if (isTRUE(input$coord_flip)) p <- p + ggplot2::coord_flip()
    p <- p + ggplot2::scale_fill_manual(values = palette) + ggplot2::scale_color_manual(values = palette)
    apply_plot_theme(p, input$theme_name %||% "publication", base_size, input$show_legend %||% TRUE, input$rotate_x %||% FALSE)
  }

  if (plot_type == "box") {
    validate(need(x %in% names(df) && y %in% names(df), "Please select an X grouping variable and a Y numeric variable."))
    fill_var <- if (group != "" && group %in% names(df)) group else x
    legend_title <- plot_clean_label(fill_var, "")
    p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[[x]], y = .data[[y]], fill = .data[[fill_var]]))
    subtype <- input$box_subtype %||% "box"
    if (subtype %in% c("box", "box_jitter")) p <- p + ggplot2::geom_boxplot(width = 0.62, alpha = alpha, outlier.shape = NA, color = "#3B4A54")
    if (subtype %in% c("violin", "raincloud")) p <- p + ggplot2::geom_violin(width = 0.78, alpha = alpha, trim = FALSE, color = "#3B4A54")
    if (subtype == "raincloud") p <- p + ggplot2::geom_boxplot(width = 0.16, alpha = 0.9, outlier.shape = NA, color = "#3B4A54")
    if (subtype %in% c("box_jitter", "raincloud") || isTRUE(input$show_points)) {
      p <- p + ggplot2::geom_jitter(ggplot2::aes(color = .data[[fill_var]]), width = 0.12, size = point_size, alpha = alpha, show.legend = FALSE)
    }
    return(add_common(p + ggplot2::labs(title = title, x = x_lab, y = y_lab, fill = legend_title, color = legend_title) + ggplot2::guides(color = "none")))
  }

  if (plot_type == "bar") {
    validate(need(x %in% names(df), "Please select an X variable."))
    summary_fun <- input$summary_fun %||% "mean"
    if (summary_fun == "count" || !(y %in% names(df))) {
      dat <- df |>
        dplyr::group_by(dplyr::across(dplyr::all_of(unique(c(x, group[group != ""], facet[facet != ""]))))) |>
        dplyr::summarise(value = dplyr::n(), se = NA_real_, .groups = "drop")
      y_lab <- "Count"
    } else {
      dat <- summarise_for_bar(df, x, y, group, summary_fun, facet)
    }
    fill_var <- if (group != "" && group %in% names(dat)) group else x
    pos <- ggplot2::position_dodge(width = 0.74)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data[[x]], y = value, fill = .data[[fill_var]])) +
      ggplot2::geom_col(width = 0.66, alpha = alpha, position = pos)
    if (isTRUE(input$show_errorbar) && "se" %in% names(dat) && any(!is.na(dat$se))) {
      p <- p + ggplot2::geom_errorbar(ggplot2::aes(ymin = value - se, ymax = value + se), width = 0.18, position = pos)
    }
    return(add_common(p + ggplot2::labs(title = title, x = x_lab, y = y_lab)))
  }

  if (plot_type == "pie") {
    validate(need(x %in% names(df), "Please select a categorical variable."))
    dat <- as.data.frame(table(df[[x]]), stringsAsFactors = FALSE)
    names(dat) <- c("category", "value")
    dat$percent <- dat$value / sum(dat$value)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = ifelse(isTRUE(input$donut), 2, 1), y = value, fill = category)) +
      ggplot2::geom_col(width = 1, color = "white") +
      ggplot2::coord_polar(theta = "y") +
      ggplot2::xlim(if (isTRUE(input$donut)) c(0.5, 2.5) else c(0.5, 1.5)) +
      ggplot2::geom_text(ggplot2::aes(label = scales::percent(percent, accuracy = 0.1)), position = ggplot2::position_stack(vjust = 0.5), size = base_size / 4)
    return(apply_plot_theme(p + ggplot2::labs(title = title, fill = plot_clean_label(x, "")), input$theme_name %||% "publication", base_size, input$show_legend %||% TRUE, FALSE) + ggplot2::theme(axis.title = ggplot2::element_blank(), axis.text = ggplot2::element_blank(), axis.ticks = ggplot2::element_blank(), panel.grid = ggplot2::element_blank()))
  }

  if (plot_type == "scatter") {
    validate(need(x %in% names(df) && y %in% names(df), "Please select X and Y numeric variables."))
    color_var <- if (group != "" && group %in% names(df)) group else NULL
    p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[[x]], y = .data[[y]], color = if (!is.null(color_var)) .data[[color_var]] else NULL)) +
      ggplot2::geom_point(size = point_size, alpha = alpha)
    if (isTRUE(input$show_smooth)) {
      smooth_method <- input$smooth_method %||% "lm"
      p <- p + ggplot2::geom_smooth(method = smooth_method, formula = plot_smooth_formula(smooth_method),
        se = input$show_ci %||% TRUE, linewidth = line_width)
    }
    if (isTRUE(input$show_labels) && label %in% names(df) && requireNamespace("ggrepel", quietly = TRUE)) {
      p <- p + ggrepel::geom_text_repel(ggplot2::aes(label = .data[[label]]), size = base_size / 4, max.overlaps = 30)
    }
    if (isTRUE(input$log_x)) p <- p + ggplot2::scale_x_log10()
    if (isTRUE(input$log_y)) p <- p + ggplot2::scale_y_log10()
    return(add_common(p + ggplot2::labs(title = title, x = x_lab, y = y_lab)))
  }

  if (plot_type == "line") {
    validate(need(x %in% names(df) && y %in% names(df), "Please select X and Y variables."))
    color_var <- if (group != "" && group %in% names(df)) group else NULL
    p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[[x]], y = .data[[y]], group = if (!is.null(color_var)) .data[[color_var]] else 1, color = if (!is.null(color_var)) .data[[color_var]] else NULL)) +
      ggplot2::geom_line(linewidth = line_width, alpha = alpha) +
      ggplot2::geom_point(size = point_size, alpha = alpha)
    if (isTRUE(input$show_smooth)) {
      smooth_method <- input$smooth_method %||% "loess"
      p <- p + ggplot2::geom_smooth(method = smooth_method, formula = plot_smooth_formula(smooth_method),
        se = input$show_ci %||% TRUE, linewidth = line_width)
    }
    return(add_common(p + ggplot2::labs(title = title, x = x_lab, y = y_lab)))
  }

  if (plot_type == "corr") {
    vars <- input$multi_numeric_vars %||% plot_numeric_vars(df)
    validate(need(length(vars) >= 2, "Correlation plots require at least two numeric variables."))
    dat <- make_corr_df(df, vars, input$cor_method %||% "pearson")
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = var1, y = var2, fill = correlation)) +
      ggplot2::geom_tile(color = "white") +
      ggplot2::scale_fill_gradient2(low = "#B2182B", mid = "white", high = "#2166AC", midpoint = 0, limits = c(-1, 1))
    if (isTRUE(input$show_corr_values)) p <- p + ggplot2::geom_text(ggplot2::aes(label = sprintf("%.2f", correlation)), size = base_size / 4)
    return(apply_plot_theme(p + ggplot2::labs(title = title, x = NULL, y = NULL, fill = "r"), input$theme_name %||% "publication", base_size, input$show_legend %||% TRUE, TRUE))
  }

  if (plot_type == "upset") {
    vars <- input$set_vars %||% character(0)
    validate(need(length(vars) >= 2, "Collection plots require at least two variables."))
    dat <- make_upset_df(df, vars, input$min_count %||% 1)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = stats::reorder(set_combination, count), y = count)) +
      ggplot2::geom_col(fill = palette[1], alpha = alpha, width = 0.68) +
      ggplot2::coord_flip()
    return(apply_plot_theme(p + ggplot2::labs(title = title, x = "Set combination", y = "Count"), input$theme_name %||% "publication", base_size, FALSE, FALSE))
  }

  if (plot_type == "network") {
    validate(need(requireNamespace("igraph", quietly = TRUE), "Network graphs require the igraph package."))
    source_var <- input$source_var %||% ""
    target_var <- input$target_var %||% ""
    weight_var <- input$weight_var %||% ""
    if (source_var %in% names(df) && target_var %in% names(df)) {
      edges <- df[, c(source_var, target_var, weight_var[weight_var %in% names(df)]), drop = FALSE]
      names(edges)[1:2] <- c("from", "to")
      if (weight_var %in% names(df)) names(edges)[3] <- "weight" else edges$weight <- 1
      edges <- edges[!is.na(edges$from) & !is.na(edges$to), , drop = FALSE]
    } else {
      vars <- input$multi_numeric_vars %||% plot_numeric_vars(df)
      corr <- make_corr_df(df, vars, input$cor_method %||% "pearson")
      edges <- corr |>
        dplyr::filter(var1 != var2, abs(correlation) >= (input$network_threshold %||% 0.6)) |>
        dplyr::transmute(from = var1, to = var2, weight = abs(correlation), sign = correlation)
    }
    validate(need(nrow(edges) > 0, "There are no drawable network edges under the current settings."))
    g <- igraph::graph_from_data_frame(edges, directed = input$directed_network %||% FALSE)
    layout_name <- input$network_layout %||% "fr"
    coordinates <- switch(layout_name,
      fr = igraph::layout_with_fr(g), kk = igraph::layout_with_kk(g),
      circle = igraph::layout_in_circle(g),
      stress = if (requireNamespace("graphlayouts", quietly = TRUE)) graphlayouts::layout_with_stress(g) else igraph::layout_nicely(g),
      igraph::layout_nicely(g))
    nodes <- data.frame(node_id = seq_len(igraph::vcount(g)), name = igraph::V(g)$name,
      x = coordinates[, 1], y = coordinates[, 2], stringsAsFactors = FALSE)
    edge_ids <- igraph::as_edgelist(g, names = FALSE)
    edge_data <- data.frame(x = nodes$x[edge_ids[, 1]], y = nodes$y[edge_ids[, 1]],
      xend = nodes$x[edge_ids[, 2]], yend = nodes$y[edge_ids[, 2]],
      weight = igraph::E(g)$weight %||% rep(1, igraph::ecount(g)))
    arrow_spec <- if (isTRUE(input$directed_network)) grid::arrow(length = grid::unit(0.16, "cm"), type = "closed") else NULL
    p <- ggplot2::ggplot() +
      ggplot2::geom_segment(data = edge_data,
        ggplot2::aes(x = x, y = y, xend = xend, yend = yend, linewidth = weight),
        alpha = alpha, color = "#5B6770", arrow = arrow_spec, lineend = "round") +
      ggplot2::geom_point(data = nodes, ggplot2::aes(x = x, y = y), size = point_size * 2.2, color = palette[1]) +
      ggplot2::geom_text(data = nodes, ggplot2::aes(x = x, y = y, label = name),
        size = base_size / 4, vjust = -0.8, check_overlap = TRUE) +
      ggplot2::scale_linewidth(range = c(0.3, 2.6), guide = "none") +
      ggplot2::coord_equal() + ggplot2::theme_void(base_size = base_size) +
      ggplot2::labs(title = title)
    return(p)
  }

  validate(need(FALSE, "Unknown graphic type."))
}

draw_tree_plot <- function(df, input, plot_type) {
  vars <- input$multi_numeric_vars %||% plot_numeric_vars(df)
  validate(need(length(vars) >= 2, "A dendrogram requires at least two numeric variables."))
  dat <- stats::na.omit(scale(analysis_numeric_df(df, vars)))
  validate(need(nrow(dat) >= 3, "Too few complete observations to cluster."))
  hc <- stats::hclust(stats::dist(dat, method = input$dist_method %||% "euclidean"), method = input$cluster_method %||% "complete")
  plot(hc, main = plot_clean_label(input$plot_title, "Hierarchical clustering tree"), xlab = "", sub = "", cex = (input$base_size %||% 14) / 18)
  if ((input$tree_k %||% 0) > 1) rect.hclust(hc, k = input$tree_k, border = plot_palette_values(input$palette %||% "Nature", input$tree_k))
}

plotting_code_template <- function(input, plot_type, workspace_data = FALSE) {
  code_title <- plot_clean_label(input$plot_title, plot_title_by_type(plot_type))
  paste0(
    "# DAVA Graphic drawingCode\n",
    "# Graphic type: ", plot_type, "\n",
    "library(ggplot2)\n",
    if (isTRUE(workspace_data)) "df <- analysis_input_data\n" else if (identical(input$dataset_select_input %||% "__demo__", "__demo__")) paste0(
      dava_local_demo_code(file.path("plotting", paste0(plot_type, ".rds")), "df"), "\n"
    ) else paste0("df <- get_dataset('", input$dataset_select_input %||% "", "')\n"),
    "input <- list(\n",
    "  x_var = '", input$x_var %||% "", "',\n",
    "  y_var = '", input$y_var %||% "", "',\n",
    "  group_var = '", input$group_var %||% "", "',\n",
    "  facet_var = '", input$facet_var %||% "", "',\n",
    "  label_var = '", input$label_var %||% "", "',\n",
    "# Graphic type: ", plot_type, "\n",
    "  x_label = '", input$x_label %||% "", "',\n",
    "  y_label = '", input$y_label %||% "", "',\n",
    "  palette = '", input$palette %||% "Nature", "',\n",
    "  theme_name = '", input$theme_name %||% "publication", "',\n",
    "  base_size = ", input$base_size %||% 14, ",\n",
    "  alpha = ", input$alpha %||% 0.78, ",\n",
    "  point_size = ", input$point_size %||% 2.4, ",\n",
    "  line_width = ", input$line_width %||% 0.9, ",\n",
    "  box_subtype = '", input$box_subtype %||% "box_jitter", "',\n",
    "  summary_fun = '", input$summary_fun %||% "mean", "',\n",
    "  donut = ", if (isTRUE(input$donut)) "TRUE" else "FALSE", ",\n",
    "  show_points = ", if (isTRUE(input$show_points)) "TRUE" else "FALSE", ",\n",
    "  show_smooth = ", if (isTRUE(input$show_smooth)) "TRUE" else "FALSE", ",\n",
    "  smooth_method = '", input$smooth_method %||% "lm", "',\n",
    "  show_ci = ", if (isTRUE(input$show_ci)) "TRUE" else "FALSE", ",\n",
    "  show_errorbar = ", if (isTRUE(input$show_errorbar)) "TRUE" else "FALSE", ",\n",
    "  show_labels = ", if (isTRUE(input$show_labels)) "TRUE" else "FALSE", ",\n",
    "  log_x = ", if (isTRUE(input$log_x)) "TRUE" else "FALSE", ",\n",
    "  log_y = ", if (isTRUE(input$log_y)) "TRUE" else "FALSE", ",\n",
    "  facet_scales = '", input$facet_scales %||% "fixed", "',\n",
    "  cor_method = '", input$cor_method %||% "pearson", "',\n",
    "  show_corr_values = ", if (isTRUE(input$show_corr_values)) "TRUE" else "FALSE", ",\n",
    "  min_count = ", input$min_count %||% 1, ",\n",
    "  network_layout = '", input$network_layout %||% "fr", "',\n",
    "  network_threshold = ", input$network_threshold %||% 0.6, ",\n",
    "  directed_network = ", if (isTRUE(input$directed_network)) "TRUE" else "FALSE", ",\n",
    "  show_legend = ", if (isTRUE(input$show_legend)) "TRUE" else "FALSE", ",\n",
    "  rotate_x = ", if (isTRUE(input$rotate_x)) "TRUE" else "FALSE", ",\n",
    "  coord_flip = ", if (isTRUE(input$coord_flip)) "TRUE" else "FALSE", "\n",
    ")\n",
    "p <- build_scientific_plot(df, input, '", plot_type, "')\n",
    "register_plot('code/plotting/", plot_type, "', p, source = 'module code', title = '", code_title, "')\n",
    "p\n"
  )
}

layout_plot_svg_geometry <- function(plot, width = 7, height = 5) {
  if (!inherits(plot, "ggplot")) return(NULL)
  tryCatch({
    gt <- ggplot2::ggplotGrob(plot)
    pan <- gt$layout[grepl("^panel", gt$layout$name), , drop = FALSE]
    if (nrow(pan) == 0) return(NULL)
    resolve_units <- function(units, total_in, dim = c("width", "height")) {
      dim <- match.arg(dim)
      types <- grid::unitType(units)
      out <- rep(NA_real_, length(units))
      null_idx <- types == "null"
      for (i in seq_along(units)) {
        if (isTRUE(null_idx[[i]])) next
        val <- tryCatch({
          if (identical(dim, "width")) grid::convertWidth(units[i], "in", valueOnly = TRUE)
          else grid::convertHeight(units[i], "in", valueOnly = TRUE)
        }, error = function(e) NA_real_)
        out[[i]] <- if (length(val) == 1 && is.finite(val)) val else 0
      }
      fixed_total <- sum(out[!null_idx], na.rm = TRUE)
      remain <- max(0, total_in - fixed_total)
      weights <- suppressWarnings(as.numeric(units[null_idx]))
      if (length(weights) > 0) {
        weights[!is.finite(weights) | weights <= 0] <- 1
        out[null_idx] <- remain * weights / sum(weights)
      }
      out[!is.finite(out)] <- 0
      out
    }
    widths <- resolve_units(gt$widths, width, "width")
    heights <- resolve_units(gt$heights, height, "height")
    unit_w <- function(idx) {
      if (length(idx) == 0) return(0)
      sum(widths[idx], na.rm = TRUE)
    }
    unit_h <- function(idx) {
      if (length(idx) == 0) return(0)
      sum(heights[idx], na.rm = TRUE)
    }
    total_w <- width
    total_h <- height
    scale_x <- width * 72 / total_w
    scale_y <- height * 72 / total_h
    grob_box <- function(rows) {
      if (is.null(rows) || nrow(rows) == 0) return(NULL)
      l <- min(rows$l, na.rm = TRUE)
      r <- max(rows$r, na.rm = TRUE)
      t <- min(rows$t, na.rm = TRUE)
      b <- max(rows$b, na.rm = TRUE)
      x <- unit_w(if (l > 1) seq_len(l - 1) else integer())
      y <- unit_h(if (t > 1) seq_len(t - 1) else integer())
      w <- unit_w(l:r)
      h <- unit_h(t:b)
      vals <- c(total_w, total_h, x, y, w, h)
      if (!all(is.finite(vals)) || total_w <= 0 || total_h <= 0 || w <= 0 || h <= 0) return(NULL)
      list(
        x = x * scale_x,
        y = y * scale_y,
        width = w * scale_x,
        height = h * scale_y,
        x_ratio = (x * scale_x) / (width * 72),
        y_ratio = (y * scale_y) / (height * 72),
        width_ratio = (w * scale_x) / (width * 72),
        height_ratio = (h * scale_y) / (height * 72)
      )
    }
    body <- grob_box(pan)
    if (is.null(body)) return(NULL)
    guide_rows <- gt$layout[grepl("^guide-box", gt$layout$name), , drop = FALSE]
    guide <- grob_box(guide_rows)
    out <- list(
      canvas_x = 0,
      canvas_y = 0,
      canvas_width = width * 72,
      canvas_height = height * 72,
      body_x = body$x,
      body_y = body$y,
      body_width = body$width,
      body_height = body$height,
      body_x_ratio = body$x_ratio,
      body_y_ratio = body$y_ratio,
      body_width_ratio = body$width_ratio,
      body_height_ratio = body$height_ratio
    )
    if (!is.null(guide)) {
      out$legend_x <- guide$x
      out$legend_y <- guide$y
      out$legend_width <- guide$width
      out$legend_height <- guide$height
      out$legend_x_ratio <- guide$x_ratio
      out$legend_y_ratio <- guide$y_ratio
      out$legend_width_ratio <- guide$width_ratio
      out$legend_height_ratio <- guide$height_ratio
    }
    out
  }, error = function(e) NULL)
}

layout_plot_svg_geometry_attrs <- function(geom) {
  if (is.null(geom)) return("")
  attr_num <- function(attr_name, geom_name = attr_name) {
    val <- suppressWarnings(as.numeric(geom[[geom_name]] %||% NA_real_))
    if (length(val) == 1 && is.finite(val)) sprintf(" data-dava-%s=\"%.4f\"", gsub("_", "-", attr_name), val) else ""
  }
  paste0(
    " data-dava-r-device-model=\"1\"",
    " data-dava-r-device-source=\"svglite\"",
    " data-dava-r-device-geometry-source=\"ggplotGrob\"",
    attr_num("plot_canvas_x", "canvas_x"),
    attr_num("plot_canvas_y", "canvas_y"),
    attr_num("plot_canvas_width", "canvas_width"),
    attr_num("plot_canvas_height", "canvas_height"),
    attr_num("plot_body_x", "body_x"),
    attr_num("plot_body_y", "body_y"),
    attr_num("plot_body_width", "body_width"),
    attr_num("plot_body_height", "body_height"),
    attr_num("plot_body_x_ratio", "body_x_ratio"),
    attr_num("plot_body_y_ratio", "body_y_ratio"),
    attr_num("plot_body_width_ratio", "body_width_ratio"),
    attr_num("plot_body_height_ratio", "body_height_ratio"),
    attr_num("plot_legend_x", "legend_x"),
    attr_num("plot_legend_y", "legend_y"),
    attr_num("plot_legend_width", "legend_width"),
    attr_num("plot_legend_height", "legend_height"),
    attr_num("plot_legend_x_ratio", "legend_x_ratio"),
    attr_num("plot_legend_y_ratio", "legend_y_ratio"),
    attr_num("plot_legend_width_ratio", "legend_width_ratio"),
    attr_num("plot_legend_height_ratio", "legend_height_ratio")
  )
}

layout_svg_xpath_literal <- function(x) {
  x <- as.character(x %||% "")
  if (!grepl("'", x, fixed = TRUE)) return(sprintf("'%s'", x))
  if (!grepl('"', x, fixed = TRUE)) return(sprintf('"%s"', x))
  parts <- strsplit(x, "'", fixed = TRUE)[[1]]
  paste0("concat(", paste(sprintf("'%s'", parts), collapse = ", \"'\", "), ")")
}

layout_svg_clone_node <- function(node) {
  tryCatch({
    xml2::xml_root(xml2::read_xml(as.character(node), options = c("RECOVER", "NOERROR", "NOWARNING")))
  }, error = function(e) NULL)
}

layout_svg_simple_hash <- function(x) {
  x <- charToRaw(as.character(x %||% ""))
  if (!length(x)) return("0")
  h <- 0
  for (b in as.integer(x)) h <- (h * 31 + b) %% 2147483647
  sprintf("%.0f", h)
}

layout_svg_attr <- function(node, name, default = "") {
  value <- xml2::xml_attr(node, name)
  if (is.na(value) || !nzchar(value)) default else value
}

layout_svg_node_origin_key <- function(node, index = 0) {
  tag <- tolower(xml2::xml_name(node))
  role <- layout_svg_attr(node, "data-dava-r-semantic-role", layout_svg_attr(node, "data-dava-r-device-role", layout_svg_attr(node, "data-dava-background-region", "element")))
  visual <- paste(
    layout_svg_attr(node, "d"),
    layout_svg_attr(node, "x"),
    layout_svg_attr(node, "y"),
    layout_svg_attr(node, "cx"),
    layout_svg_attr(node, "cy"),
    layout_svg_attr(node, "points"),
    xml2::xml_text(node) %||% "",
    layout_svg_attr(node, "stroke"),
    layout_svg_attr(node, "fill"),
    layout_svg_attr(node, "style"),
    sep = "|"
  )
  paste("rplot", tag, role, index, layout_svg_simple_hash(visual), sep = ":")
}

layout_svg_editor_root_attrs <- function() {
  c(
    "style", "width", "height", "viewBox",
    "data-dava-plot-canvas-x", "data-dava-plot-canvas-y",
    "data-dava-plot-canvas-width", "data-dava-plot-canvas-height",
    "data-dava-plot-body-x", "data-dava-plot-body-y",
    "data-dava-plot-body-width", "data-dava-plot-body-height",
    "data-dava-plot-left", "data-dava-plot-top",
    "data-dava-canvas-fill", "data-dava-view-zoom"
  )
}

layout_svg_editor_element_attrs <- function() {
  c(
    "x", "y", "x1", "y1", "x2", "y2", "cx", "cy", "r", "rx", "ry",
    "width", "height", "points", "d", "transform",
    "fill", "stroke", "stroke-width", "fill-opacity", "stroke-opacity", "opacity",
    "font-size", "font-family", "font-weight", "font-style", "letter-spacing",
    "text-anchor", "dominant-baseline", "stroke-dasharray", "stroke-linecap",
    "marker-start", "marker-end", "style",
    "data-dava-background-region", "data-dava-r-device-role",
    "data-dava-plot-canvas-layer", "data-dava-plot-body-layer",
    "data-dava-source", "data-dava-original-source", "data-dava-derived-from-rplot",
    "data-dava-owned-by-user", "data-dava-persist-overlay", "data-dava-user-element",
    "data-dava-user-group", "data-dava-origin-key", "data-dava-origin-parent-key",
    "data-dava-origin-index", "data-dava-origin-role",
    "data-dava-user-overlay-layer", "data-dava-layer-role", "data-dava-object-type",
    "data-dava-object-root", "data-dava-created-by", "data-dava-insert-type",
    "data-dava-shape-kind", "data-dava-coordinate-space", "data-dava-part",
    "data-dava-operation-profile", "data-dava-operation-capabilities",
    "data-dava-command-surfaces",
    "data-dava-arrow-object", "data-dava-formula", "data-dava-formula-source",
    "data-dava-formula-structure", "data-dava-formula-render-mode"
  )
}

layout_svg_extract_editor_state <- function(svg) {
  if (!is.character(svg) || length(svg) != 1 || !grepl("<svg", svg, fixed = TRUE)) return(NULL)
  if (!requireNamespace("xml2", quietly = TRUE)) return(NULL)
  tryCatch({
    doc <- xml2::read_xml(svg, options = c("RECOVER", "NOERROR", "NOWARNING"))
    root <- xml2::xml_root(doc)
    root_attrs_all <- as.list(xml2::xml_attrs(root))
    root_attrs <- root_attrs_all[intersect(names(root_attrs_all), layout_svg_editor_root_attrs())]

    preserve_attrs <- layout_svg_editor_element_attrs()
    edited_nodes <- xml2::xml_find_all(root, ".//*[@data-dava-node-id]")
    elements <- Filter(Negate(is.null), lapply(edited_nodes, function(node) {
      id <- xml2::xml_attr(node, "data-dava-node-id")
      if (is.na(id) || !nzchar(id)) return(NULL)
      if (identical(xml2::xml_attr(node, "data-dava-user-element"), "1") ||
          identical(xml2::xml_attr(node, "data-dava-user-group"), "1")) return(NULL)
      attrs_all <- as.list(xml2::xml_attrs(node))
      attrs <- attrs_all[intersect(names(attrs_all), preserve_attrs)]
      text_value <- NULL
      if (tolower(xml2::xml_name(node)) %in% c("text", "tspan")) text_value <- xml2::xml_text(node)
      list(id = id, tag = tolower(xml2::xml_name(node)), attrs = attrs, text = text_value)
    }))

    edited_defs <- xml2::xml_find_first(root, ".//*[local-name()='defs']")
    defs <- if (inherits(edited_defs, "xml_missing")) character(0) else as.character(edited_defs)
    user_nodes <- xml2::xml_find_all(root, ".//*[@data-dava-user-element='1' or @data-dava-user-group='1']")
    user_nodes <- Filter(Negate(is.null), lapply(user_nodes, function(node) {
      parent <- xml2::xml_parent(node)
      if (!inherits(parent, "xml_missing") && identical(xml2::xml_attr(parent, "data-dava-user-group"), "1")) return(NULL)
      as.character(node)
    }))

    structure(
      list(
        version = 1,
        svg = svg,
        root_attrs = root_attrs,
        elements = elements,
        defs = defs,
        user_nodes = unlist(user_nodes, use.names = FALSE)
      ),
      class = "dava_svg_editor_state"
    )
  }, error = function(e) NULL)
}

layout_svg_extract_overlay_state <- function(svg) {
  if (!is.character(svg) || length(svg) != 1 || !grepl("<svg", svg, fixed = TRUE)) return(NULL)
  if (!requireNamespace("xml2", quietly = TRUE)) return(NULL)
  tryCatch({
    doc <- xml2::read_xml(svg, options = c("RECOVER", "NOERROR", "NOWARNING"))
    root <- xml2::xml_root(doc)
    root_attrs_all <- as.list(xml2::xml_attrs(root))
    root_attrs <- root_attrs_all[intersect(names(root_attrs_all), layout_svg_editor_root_attrs())]

    edited_defs <- xml2::xml_find_first(root, ".//*[local-name()='defs']")
    defs <- if (inherits(edited_defs, "xml_missing")) character(0) else as.character(edited_defs)
    overlay_nodes <- xml2::xml_find_all(root, paste0(
      ".//*[@data-dava-user-element='1' or @data-dava-user-group='1' or ",
      "@data-dava-owned-by-user='1' or @data-dava-persist-overlay='1' or ",
      "@data-dava-source='user' or @data-dava-derived-from-rplot='1']"
    ))
    overlay_nodes <- Filter(Negate(is.null), lapply(overlay_nodes, function(node) {
      if (identical(xml2::xml_attr(node, "data-dava-user-overlay-layer"), "1")) return(NULL)
      parent <- xml2::xml_parent(node)
      if (!inherits(parent, "xml_missing") && identical(xml2::xml_attr(parent, "data-dava-user-group"), "1")) return(NULL)
      as.character(node)
    }))
    consumed_nodes <- xml2::xml_find_all(root, ".//*[@data-dava-derived-from-rplot='1' or @data-dava-original-source='rplot']")
    consumed <- Filter(Negate(is.null), lapply(consumed_nodes, function(node) {
      origin_key <- xml2::xml_attr(node, "data-dava-origin-key")
      if (is.na(origin_key) || !nzchar(origin_key)) return(NULL)
      list(
        origin_key = origin_key,
        origin_parent_key = layout_svg_attr(node, "data-dava-origin-parent-key"),
        origin_index = layout_svg_attr(node, "data-dava-origin-index"),
        tag = tolower(xml2::xml_name(node)),
        role = layout_svg_attr(node, "data-dava-origin-role", layout_svg_attr(node, "data-dava-r-semantic-role", layout_svg_attr(node, "data-dava-r-device-role"))),
        hash = "",
        owner_group_id = layout_svg_attr(node, "data-dava-node-id"),
        action = "suppress"
      )
    }))

    structure(
      list(
        version = 2,
        strategy = "overlay_only",
        svg = svg,
        root_attrs = root_attrs,
        defs = defs,
        user_nodes = unlist(overlay_nodes, use.names = FALSE),
        consumed_rplot_elements = consumed
      ),
      class = "dava_svg_overlay_state"
    )
  }, error = function(e) NULL)
}

layout_svg_root_meta <- function(svg) {
  if (!is.character(svg) || length(svg) != 1 || !grepl("<svg", svg, fixed = TRUE)) return(list())
  if (!requireNamespace("xml2", quietly = TRUE)) return(list())
  tryCatch({
    doc <- xml2::read_xml(svg, options = c("RECOVER", "NOERROR", "NOWARNING"))
    root <- xml2::xml_root(doc)
    attrs <- as.list(xml2::xml_attrs(root))
    list(
      source_path = attrs[["data-dava-source-path"]] %||% "",
      source_title = attrs[["data-dava-source-title"]] %||% "",
      theme = attrs[["data-dava-theme"]] %||% "",
      palette = attrs[["data-dava-palette"]] %||% "",
      text_color = attrs[["data-dava-text-color"]] %||% "",
      base_size = attrs[["data-dava-base-size"]] %||% "",
      axis_title_size = attrs[["data-dava-axis-title-size"]] %||% "",
      axis_text_size = attrs[["data-dava-axis-text-size"]] %||% "",
      legend_position = attrs[["data-dava-legend-position"]] %||% "",
      legend_title_size = attrs[["data-dava-legend-title-size"]] %||% "",
      legend_text_size = attrs[["data-dava-legend-text-size"]] %||% "",
      show_legend = attrs[["data-dava-show-legend"]] %||% "",
      rotate_x = attrs[["data-dava-rotate-x"]] %||% "",
      editor = attrs[["data-dava-editor"]] %||% ""
    )
  }, error = function(e) list())
}

layout_svg_prepare_editor_ids <- function(svg) {
  if (!is.character(svg) || length(svg) != 1 || !grepl("<svg", svg, fixed = TRUE)) return(svg)
  if (!requireNamespace("xml2", quietly = TRUE)) return(svg)
  tryCatch({
    doc <- xml2::read_xml(svg, options = c("RECOVER", "NOERROR", "NOWARNING"))
    root <- xml2::xml_root(doc)
    containers <- xml2::xml_find_all(root, ".//*[local-name()='g' or local-name()='svg']")
    for (i in seq_along(containers)) {
      node <- containers[[i]]
      parent_names <- tolower(vapply(xml2::xml_parents(node), xml2::xml_name, character(1)))
      if (any(parent_names %in% c("defs", "clippath", "marker", "mask", "pattern"))) next
      if (is.na(xml2::xml_attr(node, "data-dava-origin-index"))) xml2::xml_set_attr(node, "data-dava-origin-index", paste0("container-", i - 1))
      if (is.na(xml2::xml_attr(node, "data-dava-origin-key"))) xml2::xml_set_attr(node, "data-dava-origin-key", layout_svg_node_origin_key(node, paste0("container-", i - 1)))
    }
    nodes <- xml2::xml_find_all(root, ".//*[local-name()='path' or local-name()='circle' or local-name()='rect' or local-name()='line' or local-name()='polyline' or local-name()='polygon' or local-name()='ellipse' or local-name()='text' or local-name()='tspan' or local-name()='use' or local-name()='image']")
    for (i in seq_along(nodes)) {
      node <- nodes[[i]]
      parent_names <- tolower(vapply(xml2::xml_parents(node), xml2::xml_name, character(1)))
      if (any(parent_names %in% c("defs", "clippath", "marker"))) next
      if (is.na(xml2::xml_attr(node, "data-dava-r-device-element"))) xml2::xml_set_attr(node, "data-dava-r-device-element", "1")
      if (is.na(xml2::xml_attr(node, "data-dava-r-device-class"))) xml2::xml_set_attr(node, "data-dava-r-device-class", tolower(xml2::xml_name(node)))
      if (is.na(xml2::xml_attr(node, "data-dava-node-id"))) xml2::xml_set_attr(node, "data-dava-node-id", paste0("r_device_el_", i - 1))
      if (is.na(xml2::xml_attr(node, "data-dava-origin-index"))) xml2::xml_set_attr(node, "data-dava-origin-index", as.character(i - 1))
      if (is.na(xml2::xml_attr(node, "data-dava-origin-role"))) {
        role <- xml2::xml_attr(node, "data-dava-r-device-role")
        if (!is.na(role) && nzchar(role)) xml2::xml_set_attr(node, "data-dava-origin-role", role)
      }
      if (is.na(xml2::xml_attr(node, "data-dava-origin-key"))) xml2::xml_set_attr(node, "data-dava-origin-key", layout_svg_node_origin_key(node, i - 1))
      if (is.na(xml2::xml_attr(node, "data-dava-origin-parent-key"))) {
        parent <- xml2::xml_parent(node)
        if (!inherits(parent, "xml_missing")) {
          parent_key <- xml2::xml_attr(parent, "data-dava-origin-key")
          if (is.na(parent_key) || !nzchar(parent_key)) parent_key <- paste0(tolower(xml2::xml_name(parent)), ":", length(xml2::xml_parents(parent)))
          xml2::xml_set_attr(node, "data-dava-origin-parent-key", parent_key)
        }
      }
    }
    as.character(root, options = "format")
  }, error = function(e) svg)
}

layout_svg_prepare_rplot_document <- function(svg) {
  if (!is.character(svg) || length(svg) != 1 || !grepl("<svg", svg, fixed = TRUE)) return(svg)
  if (!requireNamespace("xml2", quietly = TRUE)) return(svg)
  tryCatch({
    doc <- xml2::read_xml(svg, options = c("RECOVER", "NOERROR", "NOWARNING"))
    root <- xml2::xml_root(doc)
    xml2::xml_set_attr(root, "data-dava-document-model", "rplot-vector-v1")
    xml2::xml_set_attr(root, "overflow", "visible")

    first_regular_child <- function(root_node) {
      children <- xml2::xml_children(root_node)
      for (child in children) {
        name <- tolower(xml2::xml_name(child))
        if (name %in% c("defs", "metadata", "style")) next
        if (identical(xml2::xml_attr(child, "data-dava-r-plot-layer"), "1")) next
      if (identical(xml2::xml_attr(child, "data-dava-user-overlay-layer"), "1")) next
      if (identical(xml2::xml_attr(child, "data-dava-editor-ui-layer"), "1")) next
      return(child)
    }
      NULL
    }

    r_layer <- xml2::xml_find_first(root, ".//*[@data-dava-r-plot-layer='1']")
    if (inherits(r_layer, "xml_missing")) {
      r_layer <- layout_svg_clone_node("<g data-dava-r-plot-layer='1' data-dava-layer-role='r_plot' data-dava-source='internal' data-dava-internal-layer='1' data-dava-container-only='1' data-dava-layer-container='1' data-dava-selectable='0' data-dava-editable='0' pointer-events='none'/>")
      before <- first_regular_child(root)
      if (!is.null(r_layer)) {
        if (!is.null(before) && !inherits(before, "xml_missing")) xml2::xml_add_sibling(before, r_layer, .where = "before") else xml2::xml_add_child(root, r_layer)
      }
      r_layer <- xml2::xml_find_first(root, ".//*[@data-dava-r-plot-layer='1']")
    }
    if (!inherits(r_layer, "xml_missing")) {
      xml2::xml_set_attr(r_layer, "data-dava-layer-role", "r_plot")
      xml2::xml_set_attr(r_layer, "data-dava-source", "internal")
      xml2::xml_set_attr(r_layer, "data-dava-internal-layer", "1")
      xml2::xml_set_attr(r_layer, "data-dava-container-only", "1")
      xml2::xml_set_attr(r_layer, "data-dava-layer-container", "1")
      xml2::xml_set_attr(r_layer, "data-dava-selectable", "0")
      xml2::xml_set_attr(r_layer, "data-dava-editable", "0")
      xml2::xml_set_attr(r_layer, "pointer-events", "none")
      xml2::xml_set_attr(r_layer, "data-dava-object-root", NA)
      xml2::xml_set_attr(r_layer, "data-dava-user-element", NA)
      xml2::xml_set_attr(r_layer, "data-dava-user-group", NA)
    }

    user_layer <- xml2::xml_find_first(root, ".//*[@data-dava-user-overlay-layer='1']")
    if (inherits(user_layer, "xml_missing")) {
      user_layer <- layout_svg_clone_node("<g data-dava-user-overlay-layer='1' data-dava-layer-role='user_overlay' data-dava-source='user' data-dava-owned-by-user='1' data-dava-persist-overlay='1' data-dava-internal-layer='1' data-dava-container-only='1' data-dava-layer-container='1' data-dava-selectable='0' data-dava-editable='0' pointer-events='none'/>")
      if (!is.null(user_layer)) xml2::xml_add_child(root, user_layer)
      user_layer <- xml2::xml_find_first(root, ".//*[@data-dava-user-overlay-layer='1']")
    }
    if (!inherits(user_layer, "xml_missing")) {
      xml2::xml_set_attr(user_layer, "data-dava-layer-role", "user_overlay")
      xml2::xml_set_attr(user_layer, "data-dava-internal-layer", "1")
      xml2::xml_set_attr(user_layer, "data-dava-container-only", "1")
      xml2::xml_set_attr(user_layer, "data-dava-layer-container", "1")
      xml2::xml_set_attr(user_layer, "data-dava-selectable", "0")
      xml2::xml_set_attr(user_layer, "data-dava-editable", "0")
      xml2::xml_set_attr(user_layer, "pointer-events", "none")
      xml2::xml_set_attr(user_layer, "data-dava-object-root", NA)
      xml2::xml_set_attr(user_layer, "data-dava-user-element", NA)
      xml2::xml_set_attr(user_layer, "data-dava-user-group", NA)
    }

    temp_layer <- xml2::xml_find_first(root, ".//*[@data-dava-editor-ui-layer='1']")
    if (inherits(temp_layer, "xml_missing")) {
      temp_layer <- layout_svg_clone_node("<g data-dava-editor-ui-layer='1' data-dava-layer-role='editor_temp' data-dava-source='internal' data-dava-internal-layer='1' data-dava-container-only='1' data-dava-layer-container='1' data-dava-editor-temp='1' data-dava-selectable='0' data-dava-editable='0' pointer-events='none'/>")
      if (!is.null(temp_layer)) xml2::xml_add_child(root, temp_layer)
    }
    temp_layer <- xml2::xml_find_first(root, ".//*[@data-dava-editor-ui-layer='1']")
    if (!inherits(temp_layer, "xml_missing")) {
      xml2::xml_set_attr(temp_layer, "data-dava-layer-role", "editor_temp")
      xml2::xml_set_attr(temp_layer, "data-dava-source", "internal")
      xml2::xml_set_attr(temp_layer, "data-dava-internal-layer", "1")
      xml2::xml_set_attr(temp_layer, "data-dava-container-only", "1")
      xml2::xml_set_attr(temp_layer, "data-dava-layer-container", "1")
      xml2::xml_set_attr(temp_layer, "data-dava-editor-temp", "1")
      xml2::xml_set_attr(temp_layer, "data-dava-selectable", "0")
      xml2::xml_set_attr(temp_layer, "data-dava-editable", "0")
      xml2::xml_set_attr(temp_layer, "pointer-events", "none")
      xml2::xml_set_attr(temp_layer, "data-dava-object-root", NA)
      xml2::xml_set_attr(temp_layer, "data-dava-user-element", NA)
      xml2::xml_set_attr(temp_layer, "data-dava-user-group", NA)
    }

    is_user_owned_node <- function(node) {
      source_value <- xml2::xml_attr(node, "data-dava-source") %||% ""
      identical(xml2::xml_attr(node, "data-dava-owned-by-user"), "1") ||
        identical(xml2::xml_attr(node, "data-dava-persist-overlay"), "1") ||
        identical(xml2::xml_attr(node, "data-dava-user-element"), "1") ||
        identical(xml2::xml_attr(node, "data-dava-user-group"), "1") ||
        grepl("^user", source_value)
    }
    mark_r_structural_groups <- function() {
      r_structural_groups <- xml2::xml_find_all(root, ".//*[@data-dava-r-plot-layer='1']//*[local-name()='g']")
      for (group in r_structural_groups) {
        if (is_user_owned_node(group)) next
        xml2::xml_set_attr(group, "data-dava-source", "internal")
        xml2::xml_set_attr(group, "data-dava-internal-layer", "1")
        xml2::xml_set_attr(group, "data-dava-container-only", "1")
        xml2::xml_set_attr(group, "data-dava-layer-container", "1")
        xml2::xml_set_attr(group, "data-dava-selectable", "0")
        xml2::xml_set_attr(group, "data-dava-editable", "0")
        xml2::xml_set_attr(group, "pointer-events", "none")
        xml2::xml_set_attr(group, "data-dava-object-root", NA)
        xml2::xml_set_attr(group, "data-dava-user-element", NA)
        xml2::xml_set_attr(group, "data-dava-user-group", NA)
      }
    }
    disable_r_editing_clips <- function() {
      r_clipped_nodes <- xml2::xml_find_all(root, ".//*[@data-dava-r-plot-layer='1']//*[@clip-path]")
      for (node in r_clipped_nodes) {
        if (is_user_owned_node(node)) next
        clip_path <- xml2::xml_attr(node, "clip-path")
        if (!is.na(clip_path) && nzchar(clip_path)) {
          if (is.na(xml2::xml_attr(node, "data-dava-original-clip-path"))) {
            xml2::xml_set_attr(node, "data-dava-original-clip-path", clip_path)
          }
          xml2::xml_set_attr(node, "data-dava-clip-disabled-for-editing", "1")
          xml2::xml_set_attr(node, "clip-path", NA)
        }
      }
    }

    children <- xml2::xml_children(root)
    for (child in children) {
      name <- tolower(xml2::xml_name(child))
      if (name %in% c("defs", "metadata", "style")) next
      if (identical(xml2::xml_attr(child, "data-dava-r-plot-layer"), "1")) next
      if (identical(xml2::xml_attr(child, "data-dava-user-overlay-layer"), "1")) next
      if (identical(xml2::xml_attr(child, "data-dava-editor-ui-layer"), "1")) next
      if (identical(xml2::xml_attr(child, "data-dava-owned-by-user"), "1") ||
          identical(xml2::xml_attr(child, "data-dava-persist-overlay"), "1") ||
          identical(xml2::xml_attr(child, "data-dava-user-element"), "1") ||
          identical(xml2::xml_attr(child, "data-dava-user-group"), "1") ||
          grepl("^user", xml2::xml_attr(child, "data-dava-source") %||% "")) {
        if (!inherits(user_layer, "xml_missing")) {
          cloned <- layout_svg_clone_node(as.character(child))
          if (!is.null(cloned)) xml2::xml_add_child(user_layer, cloned)
          xml2::xml_remove(child)
        }
      } else if (!inherits(r_layer, "xml_missing")) {
        cloned <- layout_svg_clone_node(as.character(child))
        if (!is.null(cloned)) xml2::xml_add_child(r_layer, cloned)
        xml2::xml_remove(child)
      }
    }

    mark_r_structural_groups()
    disable_r_editing_clips()

    graphics <- xml2::xml_find_all(root, ".//*[@data-dava-r-plot-layer='1']//*[local-name()='path' or local-name()='circle' or local-name()='rect' or local-name()='line' or local-name()='polyline' or local-name()='polygon' or local-name()='ellipse' or local-name()='text' or local-name()='use' or local-name()='image']")
    for (i in seq_along(graphics)) {
      node <- graphics[[i]]
      if (is.na(xml2::xml_attr(node, "data-dava-source"))) xml2::xml_set_attr(node, "data-dava-source", "rplot")
      if (is.na(xml2::xml_attr(node, "data-dava-selectable"))) xml2::xml_set_attr(node, "data-dava-selectable", "1")
      if (is.na(xml2::xml_attr(node, "data-dava-editable"))) xml2::xml_set_attr(node, "data-dava-editable", "1")
      if (is.na(xml2::xml_attr(node, "data-dava-object-root"))) xml2::xml_set_attr(node, "data-dava-object-root", "1")
      if (is.na(xml2::xml_attr(node, "data-dava-origin-key"))) xml2::xml_set_attr(node, "data-dava-origin-key", layout_svg_node_origin_key(node, i - 1))
      if (is.na(xml2::xml_attr(node, "data-dava-origin-index"))) xml2::xml_set_attr(node, "data-dava-origin-index", as.character(i - 1))
    }

    as.character(root, options = "format")
  }, error = function(e) svg)
}

layout_svg_mark_r_plot_layers <- function(svg, tolerance = 0.08) {
  if (!is.character(svg) || length(svg) != 1 || !grepl("<svg", svg, fixed = TRUE)) return(svg)
  if (!requireNamespace("xml2", quietly = TRUE)) return(svg)
  tryCatch({
    doc <- xml2::read_xml(svg, options = c("RECOVER", "NOERROR", "NOWARNING"))
    root <- xml2::xml_root(doc)
    num_attr <- function(node, name) {
      value <- suppressWarnings(as.numeric(xml2::xml_attr(node, name)))
      if (length(value) == 1 && is.finite(value)) value else NA_real_
    }
    view_box <- suppressWarnings(as.numeric(strsplit(xml2::xml_attr(root, "viewBox") %||% "", "[,[:space:]]+")[[1]]))
    canvas_width <- num_attr(root, "data-dava-plot-canvas-width")
    canvas_height <- num_attr(root, "data-dava-plot-canvas-height")
    if (!is.finite(canvas_width) && length(view_box) == 4) canvas_width <- view_box[[3]]
    if (!is.finite(canvas_height) && length(view_box) == 4) canvas_height <- view_box[[4]]
    if (!is.finite(canvas_width)) canvas_width <- suppressWarnings(as.numeric(gsub("[^0-9.\\-]", "", xml2::xml_attr(root, "width") %||% "")))
    if (!is.finite(canvas_height)) canvas_height <- suppressWarnings(as.numeric(gsub("[^0-9.\\-]", "", xml2::xml_attr(root, "height") %||% "")))
    body <- list(
      x = num_attr(root, "data-dava-plot-body-x"),
      y = num_attr(root, "data-dava-plot-body-y"),
      width = num_attr(root, "data-dava-plot-body-width"),
      height = num_attr(root, "data-dava-plot-body-height")
    )
    rects <- xml2::xml_find_all(root, ".//*[local-name()='rect']")
    rect_rows <- Filter(Negate(is.null), lapply(seq_along(rects), function(i) {
      node <- rects[[i]]
      parent_names <- tolower(vapply(xml2::xml_parents(node), xml2::xml_name, character(1)))
      if (any(parent_names %in% c("defs", "clippath", "marker", "mask", "pattern"))) return(NULL)
      x <- num_attr(node, "x")
      y <- num_attr(node, "y")
      width <- num_attr(node, "width")
      height <- num_attr(node, "height")
      if (!all(is.finite(c(x, y, width, height))) || width <= 0 || height <= 0) return(NULL)
      list(node = node, index = i, x = x, y = y, width = width, height = height, area = width * height)
    }))
    if (!length(rect_rows) || !is.finite(canvas_width) || !is.finite(canvas_height) || canvas_width <= 0 || canvas_height <= 0) {
      return(as.character(root, options = "format"))
    }
    rel_diff <- function(a, b, scale) abs(a - b) / max(scale, 1)
    body_ready <- all(is.finite(unlist(body))) && body$width > 0 && body$height > 0
    body_like <- vapply(rect_rows, function(r) {
      body_ready &&
        rel_diff(r$x, body$x, canvas_width) <= tolerance &&
        rel_diff(r$y, body$y, canvas_height) <= tolerance &&
        rel_diff(r$width, body$width, canvas_width) <= tolerance * 1.8 &&
        rel_diff(r$height, body$height, canvas_height) <= tolerance * 1.8
    }, logical(1))
    canvas_like <- vapply(seq_along(rect_rows), function(i) {
      r <- rect_rows[[i]]
      r$width >= canvas_width * 0.90 &&
        r$height >= canvas_height * 0.90 &&
        abs(r$x) <= canvas_width * 0.10 &&
        abs(r$y) <= canvas_height * 0.10 &&
        !body_like[[i]]
    }, logical(1))
    style_prop <- function(node, name) {
      style <- xml2::xml_attr(node, "style")
      if (is.na(style) || !nzchar(style)) return(NA_character_)
      match <- regexpr(paste0("(^|;)\\s*", name, "\\s*:\\s*([^;]+)"), style, perl = TRUE, ignore.case = TRUE)
      if (match[[1]] < 0) return(NA_character_)
      value <- sub(paste0("^.*(^|;)\\s*", name, "\\s*:\\s*([^;]+).*$"), "\\2", substr(style, match[[1]], match[[1]] + attr(match, "match.length")[[1]] - 1), perl = TRUE, ignore.case = TRUE)
      trimws(value)
    }
    paint_value <- function(node, name) {
      value <- xml2::xml_attr(node, name)
      if (!is.na(value) && nzchar(value)) return(trimws(value))
      style_prop(node, name)
    }
    dark_paint <- function(value) {
      if (is.na(value) || !nzchar(value)) return(FALSE)
      value <- tolower(gsub("\\s+", "", value))
      if (value %in% c("#000", "#000000", "black", "rgb(0,0,0)", "rgba(0,0,0,1)")) return(TRUE)
      m <- regexec("^rgba?\\(([0-9.]+),([0-9.]+),([0-9.]+)(?:,([0-9.]+))?\\)$", value, perl = TRUE)
      parts <- regmatches(value, m)[[1]]
      length(parts) >= 4 &&
        suppressWarnings(as.numeric(parts[2])) <= 8 &&
        suppressWarnings(as.numeric(parts[3])) <= 8 &&
        suppressWarnings(as.numeric(parts[4])) <= 8 &&
        (length(parts) < 5 || is.na(suppressWarnings(as.numeric(parts[5]))) || suppressWarnings(as.numeric(parts[5])) > 0)
    }
    role_for_rect <- function(node) {
      role <- xml2::xml_attr(node, "data-dava-r-device-role")
      if (!is.na(role) && nzchar(role)) return(role)
      region <- xml2::xml_attr(node, "data-dava-background-region")
      if (!is.na(region) && nzchar(region)) return(region)
      ""
    }
    apply_plot_background <- function(node) {
      if (is.null(node) || inherits(node, "xml_missing")) return(invisible(FALSE))
      # R PlotImportLayout beautificationThe library does not carry solid color canvas，Avoid transparency SVG becomes black in the editor。
      xml2::xml_set_attr(node, "fill", "none")
      xml2::xml_set_attr(node, "fill-opacity", "0")
      xml2::xml_set_attr(node, "opacity", "1")
      xml2::xml_set_attr(node, "data-dava-r-device-role", "plot_background")
      xml2::xml_set_attr(node, "data-dava-background-region", "plot_background")
      xml2::xml_set_attr(node, "data-dava-plot-canvas-layer", "1")
      invisible(TRUE)
    }
    apply_coordinate_background <- function(node) {
      if (is.null(node) || inherits(node, "xml_missing")) return(invisible(FALSE))
      if (identical(role_for_rect(node), "plot_background")) return(invisible(FALSE))
      xml2::xml_set_attr(node, "fill-opacity", "0")
      xml2::xml_set_attr(node, "opacity", "1")
      xml2::xml_set_attr(node, "data-dava-r-device-role", "coordinate_background")
      xml2::xml_set_attr(node, "data-dava-background-region", "coordinate_background")
      xml2::xml_set_attr(node, "data-dava-plot-body-layer", "1")
      invisible(TRUE)
    }
    # each ggplot/patchwork sub-panels have corresponding clipPath。Only the geometry rangeand
    # clipPath Completely consistentRectangleis identified as the coordinate background，Avoid pressingColoror area misjudgmentDataRectangle。
    clip_rects <- xml2::xml_find_all(root, ".//*[local-name()='clipPath']/*[local-name()='rect']")
    clip_rows <- Filter(Negate(is.null), lapply(as.list(clip_rects), function(node) {
      values <- c(
        x = num_attr(node, "x"), y = num_attr(node, "y"),
        width = num_attr(node, "width"), height = num_attr(node, "height")
      )
      if (!all(is.finite(values)) || values[["width"]] <= 0 || values[["height"]] <= 0) return(NULL)
      values
    }))
    if (length(clip_rows)) {
      for (rect_row in rect_rows) {
        if (identical(role_for_rect(rect_row$node), "plot_background")) next
        matches_clip <- any(vapply(clip_rows, function(clip) {
          rel_diff(rect_row$x, clip[["x"]], canvas_width) <= 0.002 &&
            rel_diff(rect_row$y, clip[["y"]], canvas_height) <= 0.002 &&
            rel_diff(rect_row$width, clip[["width"]], canvas_width) <= 0.002 &&
            rel_diff(rect_row$height, clip[["height"]], canvas_height) <= 0.002
        }, logical(1)))
        if (matches_clip) apply_coordinate_background(rect_row$node)
      }
    }
    dark_panel_like <- vapply(seq_along(rect_rows), function(i) {
      r <- rect_rows[[i]]
      !canvas_like[[i]] &&
        dark_paint(paint_value(r$node, "fill")) &&
        r$area >= canvas_width * canvas_height * 0.12 &&
        r$width >= canvas_width * 0.42 &&
        r$height >= canvas_height * 0.32
    }, logical(1))
    if (any(canvas_like)) {
      candidates <- rect_rows[canvas_like]
      bg <- candidates[[which.max(vapply(candidates, function(r) r$area, numeric(1)))]]$node
      apply_plot_background(bg)
    }
    panel_node <- NULL
    if (body_ready) {
      if (any(body_like)) {
        candidates <- rect_rows[body_like]
        target_area <- body$width * body$height
        idx <- which.min(abs(vapply(candidates, function(r) r$area, numeric(1)) - target_area))
        panel <- candidates[[idx]]$node
        if (apply_coordinate_background(panel)) {
          panel_node <- panel
        }
      } else if (any(dark_panel_like)) {
        candidates <- rect_rows[dark_panel_like]
        panel <- candidates[[which.max(vapply(candidates, function(r) r$area, numeric(1)))]]$node
        if (apply_coordinate_background(panel)) panel_node <- panel
      }
      if (is.null(panel_node)) {
        panel_parent <- NULL
        groups <- xml2::xml_find_all(root, ".//*[local-name()='g' and @clip-path]")
        for (group in groups) {
          clip_ref <- xml2::xml_attr(group, "clip-path")
          if (is.na(clip_ref) || !grepl("^url\\(#.+\\)$", clip_ref)) next
          clip_id <- sub("^url\\(#(.+)\\)$", "\\1", clip_ref)
          clip_rect <- xml2::xml_find_first(root, sprintf(".//*[local-name()='clipPath' and @id=%s]/*[local-name()='rect']", layout_svg_xpath_literal(clip_id)))
          if (inherits(clip_rect, "xml_missing")) next
          clip_row <- list(
            x = num_attr(clip_rect, "x"),
            y = num_attr(clip_rect, "y"),
            width = num_attr(clip_rect, "width"),
            height = num_attr(clip_rect, "height")
          )
          if (all(is.finite(unlist(clip_row))) &&
              rel_diff(clip_row$x, body$x, canvas_width) <= tolerance &&
              rel_diff(clip_row$y, body$y, canvas_height) <= tolerance &&
              rel_diff(clip_row$width, body$width, canvas_width) <= tolerance * 1.8 &&
              rel_diff(clip_row$height, body$height, canvas_height) <= tolerance * 1.8) {
            panel_parent <- group
            break
          }
        }
        if (is.null(panel_parent)) {
          panel_parent <- xml2::xml_find_first(root, ".//*[local-name()='g' and contains(concat(' ', normalize-space(@class), ' '), ' svglite ')]")
          if (inherits(panel_parent, "xml_missing")) panel_parent <- root
        }
        panel_markup <- sprintf(
          "<rect x='%.4f' y='%.4f' width='%.4f' height='%.4f' fill='#FFFFFF' fill-opacity='0' opacity='1' stroke='none' data-dava-r-device-element='1' data-dava-r-device-class='rect' data-dava-node-id='r_device_panel_background' data-dava-r-device-role='coordinate_background' data-dava-background-region='coordinate_background' data-dava-plot-body-layer='1'/>",
          body$x, body$y, body$width, body$height
        )
        panel_node <- layout_svg_clone_node(panel_markup)
        if (!is.null(panel_node)) xml2::xml_add_child(panel_parent, panel_node, .where = 0)
      }
    }
    as.character(root, options = "format")
  }, error = function(e) svg)
}

layout_svg_merge_editor_state <- function(base_svg, edited_svg = NULL) {
  layout_svg_merge_overlay_state(base_svg, edited_svg)
}

layout_svg_normalize_overlay_state <- function(overlay_state = NULL) {
  if (is.null(overlay_state)) return(NULL)
  if (is.list(overlay_state) && !is.null(overlay_state$overlay_state)) {
    overlay_state <- overlay_state$overlay_state
  }
  if (is.list(overlay_state) && !is.null(overlay_state$state) && is.null(overlay_state$strategy)) {
    overlay_state <- overlay_state$state
  }
  if (inherits(overlay_state, "dava_svg_overlay_state") ||
      (is.list(overlay_state) && identical(overlay_state$strategy %||% NULL, "overlay_only"))) {
    return(overlay_state)
  }
  if (inherits(overlay_state, "dava_svg_editor_state") ||
      (is.list(overlay_state) && identical(overlay_state$version %||% NULL, 1))) {
    return(structure(
      list(
        version = 2,
        strategy = "overlay_only",
        root_attrs = overlay_state$root_attrs %||% list(),
        defs = overlay_state$defs %||% character(0),
        user_nodes = overlay_state$user_nodes %||% character(0),
        consumed_rplot_elements = overlay_state$consumed_rplot_elements %||% list()
      ),
      class = "dava_svg_overlay_state"
    ))
  }
  layout_svg_extract_overlay_state(overlay_state)
}

layout_svg_merge_overlay_state <- function(base_svg, overlay_state = NULL) {
  if (!is.character(base_svg) || length(base_svg) != 1 || !grepl("<svg", base_svg, fixed = TRUE)) return(base_svg)
  state <- layout_svg_normalize_overlay_state(overlay_state)
  if (is.null(state)) return(base_svg)
  if (!requireNamespace("xml2", quietly = TRUE)) return(base_svg)

  tryCatch({
    base <- xml2::read_xml(layout_svg_prepare_editor_ids(base_svg), options = c("RECOVER", "NOERROR", "NOWARNING"))
    base_root <- xml2::xml_root(base)

    for (attr in names(state$root_attrs %||% list())) {
      value <- state$root_attrs[[attr]]
      if (!is.null(value) && nzchar(value)) xml2::xml_set_attr(base_root, attr, value)
    }

    if (length(state$defs %||% character(0))) {
      base_defs <- xml2::xml_find_first(base_root, ".//*[local-name()='defs']")
      if (inherits(base_defs, "xml_missing")) {
        cloned_defs <- layout_svg_clone_node(state$defs[[1]])
        if (!is.null(cloned_defs)) xml2::xml_add_child(base_root, cloned_defs, .where = 0)
      } else {
        edited_defs <- xml2::xml_root(xml2::read_xml(state$defs[[1]], options = c("RECOVER", "NOERROR", "NOWARNING")))
        edited_def_ids <- xml2::xml_find_all(edited_defs, ".//*[@id]")
        for (def_node in edited_def_ids) {
          def_id <- xml2::xml_attr(def_node, "id")
          if (is.na(def_id) || !nzchar(def_id)) next
          exists <- xml2::xml_find_first(base_defs, sprintf(".//*[@id=%s]", layout_svg_xpath_literal(def_id)))
          if (inherits(exists, "xml_missing")) {
            cloned_def <- layout_svg_clone_node(def_node)
            if (!is.null(cloned_def)) xml2::xml_add_child(base_defs, cloned_def)
          }
        }
      }
    }

    consumed <- state$consumed_rplot_elements %||% list()
    if (length(consumed)) {
      for (item in consumed) {
        origin_key <- item$origin_key %||% ""
        if (!nzchar(origin_key)) next
        target <- xml2::xml_find_first(base_root, sprintf(".//*[@data-dava-origin-key=%s]", layout_svg_xpath_literal(origin_key)))
        if (!inherits(target, "xml_missing")) {
          xml2::xml_remove(target)
        }
      }
    }

    overlay_layer <- xml2::xml_find_first(base_root, ".//*[@data-dava-user-overlay-layer='1']")
    if (inherits(overlay_layer, "xml_missing")) {
      overlay_layer <- layout_svg_clone_node("<g data-dava-user-overlay-layer='1' data-dava-layer-role='user_overlay' data-dava-source='user' data-dava-owned-by-user='1' data-dava-persist-overlay='1' data-dava-internal-layer='1' data-dava-container-only='1' data-dava-layer-container='1' data-dava-selectable='0' data-dava-editable='0' pointer-events='none'/>")
      if (!is.null(overlay_layer)) xml2::xml_add_child(base_root, overlay_layer)
      overlay_layer <- xml2::xml_find_first(base_root, ".//*[@data-dava-user-overlay-layer='1']")
      if (inherits(overlay_layer, "xml_missing")) overlay_layer <- base_root
    }

    for (node in state$user_nodes %||% character(0)) {
      cloned_node <- layout_svg_clone_node(node)
      if (is.null(cloned_node)) next
      parent_key <- xml2::xml_attr(cloned_node, "data-dava-origin-parent-key")
      target_parent <- NULL
      if (!is.na(parent_key) && nzchar(parent_key)) {
        found_parent <- xml2::xml_find_first(base_root, sprintf(".//*[@data-dava-origin-key=%s]", layout_svg_xpath_literal(parent_key)))
        if (!inherits(found_parent, "xml_missing")) target_parent <- found_parent
      }
      if (is.null(target_parent)) target_parent <- overlay_layer
      xml2::xml_add_child(target_parent, cloned_node)
    }

    as.character(base_root, options = "format")
  }, error = function(e) base_svg)
}

layout_svg_strip_device_bg <- function(svg) {
  if (!is.character(svg) || length(svg) != 1 || !grepl("<svg", svg, fixed = TRUE)) return(svg)
  if (!requireNamespace("xml2", quietly = TRUE)) {
    svg <- gsub("\\bbackground(?:-color)?\\s*:[^;]*;?", "", svg, perl = TRUE)
    return(gsub(
      "<rect\\b(?=[^>]*\\bwidth\\s*=\\s*['\"]100%['\"])(?=[^>]*\\bheight\\s*=\\s*['\"]100%['\"])(?=[^>]*(?:\\bfill\\s*=\\s*['\"](?:transparent|none)['\"]|\\bfill\\s*:\\s*(?:transparent|none)\\b))[^>]*/>",
      "",
      svg,
      perl = TRUE
    ))
  }

  tryCatch({
    doc <- xml2::read_xml(svg, options = c("RECOVER", "NOERROR", "NOWARNING"))
    root <- xml2::xml_root(doc)
    root_style <- xml2::xml_attr(root, "style")
    if (!is.na(root_style) && nzchar(root_style)) {
      root_style <- trimws(gsub("\\bbackground(?:-color)?\\s*:[^;]*;?", "", root_style, perl = TRUE))
      xml2::xml_set_attr(root, "style", root_style)
    }

    style_prop <- function(node, name) {
      style <- xml2::xml_attr(node, "style")
      if (is.na(style) || !nzchar(style)) return(NA_character_)
      match <- regexpr(paste0("(^|;)\\s*", name, "\\s*:\\s*([^;]+)"), style, perl = TRUE, ignore.case = TRUE)
      if (match[[1]] < 0) return(NA_character_)
      value <- sub(paste0("^.*(^|;)\\s*", name, "\\s*:\\s*([^;]+).*$"), "\\2", substr(style, match[[1]], match[[1]] + attr(match, "match.length")[[1]] - 1), perl = TRUE, ignore.case = TRUE)
      trimws(value)
    }
    paint_value <- function(node, name) {
      value <- xml2::xml_attr(node, name)
      if (!is.na(value) && nzchar(value)) return(trimws(value))
      style_prop(node, name)
    }
    opacity_value <- function(node, name) {
      value <- paint_value(node, name)
      out <- suppressWarnings(as.numeric(value))
      if (length(out) == 1 && is.finite(out)) out else NA_real_
    }
    blank_paint <- function(value) {
      if (is.na(value) || !nzchar(value)) return(FALSE)
      value <- tolower(gsub("\\s+", "", value))
      value %in% c("none", "transparent", "rgba(0,0,0,0)", "rgba(255,255,255,0)")
    }
    percent_100 <- function(value) {
      !is.na(value) && grepl("^\\s*100(?:\\.0+)?%\\s*$", value)
    }
    removable_device_rect <- function(rect) {
      if (!is.na(xml2::xml_attr(rect, "data-dava-r-device-role")) ||
          !is.na(xml2::xml_attr(rect, "data-dava-background-region"))) return(FALSE)
      parent <- xml2::xml_parent(rect)
      parent_name <- tolower(xml2::xml_name(parent))
      parent_class <- tolower(xml2::xml_attr(parent, "class") %||% "")
      near_root <- identical(parent, root) || (identical(parent_name, "g") && grepl("\\bsvglite\\b", parent_class))
      if (!near_root) return(FALSE)
      if (!percent_100(xml2::xml_attr(rect, "width")) || !percent_100(xml2::xml_attr(rect, "height"))) return(FALSE)
      fill_blank <- blank_paint(paint_value(rect, "fill")) || identical(opacity_value(rect, "opacity"), 0) || identical(opacity_value(rect, "fill-opacity"), 0)
      stroke <- paint_value(rect, "stroke")
      stroke_width <- suppressWarnings(as.numeric(paint_value(rect, "stroke-width")))
      stroke_blank <- is.na(stroke) || !nzchar(stroke) || blank_paint(stroke) || (length(stroke_width) == 1 && is.finite(stroke_width) && stroke_width == 0)
      fill_blank && stroke_blank
    }
    rects <- xml2::xml_find_all(root, ".//*[local-name()='rect']")
    for (rect in rects) {
      if (removable_device_rect(rect)) xml2::xml_remove(rect)
    }
    as.character(root, options = "format")
  }, error = function(e) svg)
}

layout_plot_svg_markup <- function(plot, width = 7, height = 5) {
  shiny::validate(shiny::need(requireNamespace("svglite", quietly = TRUE), "SVG element editing requires the svglite package: install.packages('svglite')"))
  f <- tempfile(fileext = ".svg")
  # Use transparent device background so svglite does not inject an unselectable white rect.
  # The ggplot plot.background rect (from the theme) becomes the sole, selectable background layer.
  svglite::svglite(f, width = width, height = height, bg = "transparent", standalone = TRUE)
  closed <- FALSE
  on.exit({
    if (!closed) try(grDevices::dev.off(), silent = TRUE)
    unlink(f)
  }, add = TRUE)
  geom <- if (inherits(plot, "ggplot")) layout_plot_svg_geometry(plot, width, height) else NULL
  print(plot)
  grDevices::dev.off()
  closed <- TRUE
  svg <- paste(readLines(f, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
  svg <- layout_svg_strip_device_bg(svg)
  attrs <- layout_plot_svg_geometry_attrs(geom)
  svg <- sub("<svg ", paste0("<svg class=\"dava-svg-editor-plot\"", attrs, " "), svg, fixed = TRUE)
  svg <- sub("<svg ", "<svg overflow=\"visible\" ", svg, fixed = TRUE)
  layout_svg_prepare_rplot_document(layout_svg_mark_r_plot_layers(layout_svg_prepare_editor_ids(svg)))
}

layout_svg_data_uri <- function(svg) {
  paste0("data:image/svg+xml;charset=utf-8,", utils::URLencode(svg, reserved = TRUE))
}

layout_apply_item_edits <- function(p, item) {
  if (!inherits(p, "ggplot")) return(p)
  nz <- function(x) !is.null(x) && nzchar(x)

  if (nz(item$point_color) || is.finite(item$point_size %||% NA_real_) || !is.null(item$point_shape)) {
    for (i in seq_along(p$layers)) {
      if (inherits(p$layers[[i]]$geom, "GeomPoint")) {
        if (nz(item$point_color)) p$layers[[i]]$aes_params$colour <- item$point_color
        if (is.finite(item$point_size %||% NA_real_)) p$layers[[i]]$aes_params$size <- item$point_size
        if (!is.null(item$point_shape)) p$layers[[i]]$aes_params$shape <- item$point_shape
      }
    }
  }

  if (nz(item$line_color) || is.finite(item$line_width %||% NA_real_)) {
    for (i in seq_along(p$layers)) {
      if (inherits(p$layers[[i]]$geom, "GeomLine") || inherits(p$layers[[i]]$geom, "GeomSmooth") || inherits(p$layers[[i]]$geom, "GeomPath") || inherits(p$layers[[i]]$geom, "GeomSegment")) {
        if (nz(item$line_color)) p$layers[[i]]$aes_params$colour <- item$line_color
        if (is.finite(item$line_width %||% NA_real_)) p$layers[[i]]$aes_params$linewidth <- item$line_width
      }
    }
  }

  if (nz(item$fill_color)) {
    for (i in seq_along(p$layers)) {
      if (inherits(p$layers[[i]]$geom, "GeomCol") || inherits(p$layers[[i]]$geom, "GeomBar") || inherits(p$layers[[i]]$geom, "GeomBoxplot") || inherits(p$layers[[i]]$geom, "GeomViolin") || inherits(p$layers[[i]]$geom, "GeomTile")) {
        p$layers[[i]]$aes_params$fill <- item$fill_color
      }
    }
  }

  font_size <- item$font_size %||% NA_real_
  font_family <- item$font_family %||% ""
  p + ggplot2::theme(
    plot.title = ggplot2::element_text(
      color = if (nz(item$title_color)) item$title_color else NULL,
      size = if (is.finite(font_size)) font_size + 2 else NULL,
      family = if (nz(font_family)) font_family else NULL
    ),
    axis.title = ggplot2::element_text(
      color = if (nz(item$axis_color)) item$axis_color else if (nz(item$text_color)) item$text_color else NULL,
      size = if (is.finite(font_size)) font_size else NULL,
      family = if (nz(font_family)) font_family else NULL
    ),
    axis.text = ggplot2::element_text(
      color = if (nz(item$axis_color)) item$axis_color else if (nz(item$text_color)) item$text_color else NULL,
      size = if (is.finite(font_size)) max(6, font_size - 2) else NULL,
      family = if (nz(font_family)) font_family else NULL
    ),
    legend.text = ggplot2::element_text(
      color = if (nz(item$text_color)) item$text_color else NULL,
      size = if (is.finite(font_size)) max(6, font_size - 2) else NULL,
      family = if (nz(font_family)) font_family else NULL
    ),
    legend.title = ggplot2::element_text(
      color = if (nz(item$text_color)) item$text_color else NULL,
      size = if (is.finite(font_size)) font_size else NULL,
      family = if (nz(font_family)) font_family else NULL
    ),
    panel.background = if (nz(item$panel_color)) ggplot2::element_rect(fill = item$panel_color, color = NA) else NULL
  )
}

mod_plotting_ui <- function(id, title, plot_type) {
  ns <- NS(id)
  plot_appearance_controls <- tagList(
    tags$div(
      class = "stat-box",
      tags$strong("Graphic properties: current", title),
      textInput(ns("plot_title"), "title", value = title),
      textInput(ns("x_label"), "X-axis title", value = ""),
      textInput(ns("y_label"), "Y axis title", value = ""),
      selectInput(ns("palette"), "Colors", choices = dava_plot_palette_choices(), selected = "Nature_NPG"),
      selectInput(ns("theme_name"), "Topic", choices = dava_plot_theme_choices(), selected = "nature"),
      sliderInput(ns("base_size"), "Font size", min = 8, max = 24, value = 14, step = 1),
      sliderInput(ns("alpha"), "Transparency", min = 0.1, max = 1, value = 0.78, step = 0.05),
      sliderInput(ns("point_size"), "Point size", min = 0.5, max = 8, value = 2.4, step = 0.1),
      sliderInput(ns("line_width"), "Line width", min = 0.2, max = 3, value = 0.9, step = 0.1),
      checkboxInput(ns("show_legend"), "Show legend", value = TRUE),
      checkboxInput(ns("rotate_x"), "Rotate X-axis label", value = FALSE),
      checkboxInput(ns("coord_flip"), "Coordinate axis flip", value = FALSE),
      checkboxInput(ns("interactive"), "Interactive graphics", value = plot_type %in% c("scatter", "line", "corr"))
    ),
    tags$div(
      class = "stat-box",
      tags$strong("Exclusive options"),
      checkboxInput(ns("show_points"), "Overlay original points", value = plot_type %in% c("box")),
      checkboxInput(ns("show_smooth"), "Show smoothing/trend lines", value = plot_type %in% c("scatter")),
      selectInput(ns("smooth_method"), "Smoothing method", choices = c("lm", "loess", "gam"), selected = "lm"),
      checkboxInput(ns("show_ci"), "Show confidence interval", value = TRUE),
      checkboxInput(ns("show_errorbar"), "Show error bars", value = TRUE),
      checkboxInput(ns("show_labels"), "Show tags", value = FALSE),
      checkboxInput(ns("log_x"), "X axis log10", value = FALSE),
      checkboxInput(ns("log_y"), "Y axis log10", value = FALSE),
      selectInput(ns("facet_scales"), "Facet coordinates", choices = c("fixed", "free", "free_x", "free_y"), selected = "fixed"),
      if (plot_type == "corr") tagList(selectInput(ns("cor_method"), "Related methods", choices = c("pearson", "spearman", "kendall"), selected = "pearson"), checkboxInput(ns("show_corr_values"), "Show correlation coefficient", value = TRUE)),
      if (plot_type == "upset") numericInput(ns("min_count"), "Minimum combination frequency", value = 1, min = 1, step = 1)
    ),
    tags$div(
      class = "stat-box",
      tags$strong("Graphics operations"),
      numericInput(ns("fig_dpi"), "DPI", value = 300, min = 72, max = 1200, step = 50),
      dava_plot_action_buttons_ui(
        ns, "add_current_plot_to_library", "download_png", "download_pdf", boxed = FALSE
      )
    )
  )
  if (identical(plot_type, "layout")) {
    return(tagList(
      tags$link(rel = "stylesheet", type = "text/css", href = "dava_svgedit_embed.css?v=20260921-export4"),
        tags$script(src = "dava_svgedit_host.js?v=20260922-size7"),
      tags$div(
        class = "dava-svgedit-page",
        `data-dava-svgedit-root` = "1",
        `data-ns-prefix` = ns(""),
        tags$div(
          class = "dava-svgedit-toolbar",
          actionButton(ns("insert_current_r_plot_to_svgedit"), "Insert current R graphic", icon = icon("plus"), class = "btn-outline-primary"),
          tags$div(
            class = "dava-svgedit-import",
            fileInput(
              ns("svgedit_import_file"),
              label = "Import SVG files",
              accept = c(".svg", "image/svg+xml"),
              buttonLabel = "Import SVG files"
            )
          ),
          tags$div(
            class = "dava-svgedit-pdf-import-hidden",
            style = "position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;",
            fileInput(
              ns("svgedit_pdf_import_file"),
              label = "PDF Import",
              accept = c(".pdf", "application/pdf"),
              buttonLabel = "PDF Import"
            )
          ),
          tags$div(
            class = "dava-svgedit-source",
            selectizeInput(
              ns("svgedit_plot_source"),
              label = "Graphics library source",
              choices = c("No graphics available yet" = ""),
              selected = "",
              width = "340px",
              options = list(placeholder = "Select graphics in the analysis gallery")
            )
          ),
          actionButton(ns("save_svgedit_svg"), "Save editing results", icon = icon("save"), class = "btn-success"),
          actionButton(ns("open_svgedit_export"), "Export SVG/PDF/TIFF", icon = icon("file-export"), class = "btn-outline-success"),
          downloadButton(ns("download_edited_svg"), "Download SVG", class = "btn-outline-primary"),
          actionButton(ns("clear_svgedit"), "Clear editor", icon = icon("trash"), class = "btn-outline-danger"),
          tags$button(
            type = "button",
            class = "btn btn-outline-secondary dava-svgedit-exit",
            `data-dava-svgedit-action` = "exit",
            icon("sign-out-alt"),
            "Exit the editor"
          )
        ),
        tags$div(
          class = "dava-svgedit-frame-wrap",
          tags$iframe(
            id = "dava_svg_editor_iframe",
            src = "svgedit/editor/svg-editor.html",
            class = "dava-svgedit-iframe",
            title = "DAVA SVG-Edit",
            `data-dava-svgedit-iframe` = "1",
            `data-dava-ready-input` = ns("svgedit_ready"),
            `data-dava-changed-input` = ns("svgedit_changed"),
            `data-dava-edited-svg-input` = ns("edited_svg"),
            `data-dava-edited-svg-from-svgedit-input` = ns("edited_svg_from_svgedit"),
            `data-dava-save-meta-input` = ns("svgedit_save_meta"),
            `data-dava-import-done-input` = ns("svgedit_import_done"),
            `data-dava-import-error-input` = ns("svgedit_import_error"),
            `data-dava-error-input` = ns("svgedit_error")
          )
        )
      )
    ))
  }
  card(
    card_header(h4(title, style = "margin: 0;")),
    layout_sidebar(
      sidebar = sidebar(
        width = 335,
        tags$div(class = "stat-box", tags$strong("data set"), uiOutput(ns("dataset_select")), tags$div(class = "small-muted", "Please select the loaded data set in file management.")),
        tags$div(
          class = "stat-box",
          tags$strong("Graphic type settings"),
          if (plot_type == "box") selectInput(ns("box_subtype"), "Box plot type", choices = c("Boxplot" = "box", "Boxplot + jitter" = "box_jitter", "Violin" = "violin", "Raincloud style" = "raincloud"), selected = "box_jitter"),
          if (plot_type == "bar") selectInput(ns("summary_fun"), "Summary method", choices = c("Mean" = "mean", "Median" = "median", "Sum" = "sum", "Count" = "count"), selected = "mean"),
          if (plot_type == "pie") checkboxInput(ns("donut"), "Donut chart", value = TRUE),
          if (plot_type == "tree") tagList(selectInput(ns("dist_method"), "distance", choices = c("euclidean", "manhattan", "maximum", "canberra"), selected = "euclidean"), selectInput(ns("cluster_method"), "Clustering method", choices = c("complete", "average", "single", "ward.D2"), selected = "complete"), numericInput(ns("tree_k"), "Number of groups", value = 3, min = 0, max = 20, step = 1)),
          if (plot_type == "network") tagList(selectInput(ns("network_layout"), "Layout", choices = c("fr", "kk", "circle", "stress", "nicely"), selected = "fr"), sliderInput(ns("network_threshold"), "Related Threshold |r|", min = 0, max = 1, value = 0.6, step = 0.05), checkboxInput(ns("directed_network"), "directed network", value = FALSE))
        ),
        tags$div(
          class = "stat-box",
          tags$strong("Variable mapping"),
          uiOutput(ns("variable_controls"))
        )
      ),
      navset_card_tab(
        nav_panel("Plot",
          layout_sidebar(
            sidebar = sidebar(width = 300, position = "right", plot_appearance_controls),
            shiny::tagList(
              dava_plot_size_ui(ns, "static_plot", "plotting_plot_size", width = 900, height = 700)
            )
          )
        ),
        nav_panel("Data preview", DTOutput(ns("raw_data_preview"))),
        nav_panel("Drawing data", DTOutput(ns("plot_data_preview"))),
        nav_panel("R Markdown code document", dava_module_code_panel_ui(ns)),
        nav_panel("Prompt message", DTOutput(ns("message_table")))
      )
    )
  )
}

mod_plotting_server <- function(id, file_data, plot_type) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    if (identical(plot_type, "layout")) {
      edited_svg <- reactiveVal("")
      selected_svg_source_path <- reactiveVal(NULL)

      # SVG-Edit works on serialized SVG. DAVA keeps the source of truth in the
      # existing plot registry so saved edits participate in project state.
      registry_entries <- reactive({
        dava_plot_registry_entries(file_data, reactive = TRUE)
      })

      svg_gallery_entries <- reactive({
        dava_svg_gallery_entries(file_data, reactive = TRUE)
      })

      source_value <- function(kind, key) {
        paste(kind, key, sep = "::")
      }

      source_parts <- function(value) {
        value <- value %||% ""
        if (!nzchar(value)) return(list(kind = "", key = ""))
        parts <- strsplit(value, "::", fixed = TRUE)[[1]]
        if (length(parts) < 2) return(list(kind = "registry", key = value))
        list(kind = parts[[1]], key = paste(parts[-1], collapse = "::"))
      }

      registry_choices <- reactive({
        registry <- registry_entries()
        gallery <- svg_gallery_entries()
        registry_labels <- vapply(names(registry), function(path) {
          entry <- registry[[path]]
          source <- plot_clean_label(entry$source %||% "", "Graphics library")
          title <- plot_clean_label(entry$title %||% path, path)
          type <- entry$type %||% "plot"
          paste0(source, " / ", title, " [", type, "]")
        }, character(1))
        registry_values <- vapply(names(registry), function(path) source_value("registry", path), character(1))
        registry_group <- stats::setNames(registry_values, registry_labels)
        gallery_labels <- vapply(names(gallery), function(name) {
          entry <- gallery[[name]]
          plot_clean_label(entry$title %||% entry$name %||% name, name)
        }, character(1))
        gallery_values <- vapply(names(gallery), function(name) source_value("gallery", name), character(1))
        gallery_group <- stats::setNames(gallery_values, gallery_labels)
        choices <- list()
        if (length(registry_group) > 0) choices[["Graphic layout beautification library"]] <- registry_group
        if (length(gallery_group) > 0) choices[["SVG Gallery"]] <- gallery_group
        if (length(choices) == 0) return(c("No graphics available yet" = ""))
        choices
      })

      choice_values <- function(choices) {
        if (is.list(choices) && !is.null(names(choices))) {
          return(unname(unlist(choices, use.names = FALSE)))
        }
        unname(choices)
      }

      svg_safe_name <- function(x) {
        x <- plot_clean_label(x, "SVG graphics")
        x <- gsub("[\\\\/:*?\"<>|]+", "_", x)
        x <- gsub("\\s+", "_", x)
        if (!nzchar(x)) "SVG graphics" else x
      }

      svg_edit_source_base_name <- function(x) {
        x <- svg_safe_name(x)
        x <- sub("(?:_SVGEdit(?:_[0-9]+)?)+$", "", x, perl = TRUE)
        if (!nzchar(x)) "SVGEdit" else x
      }

      valid_svg_text <- function(svg) {
        is.character(svg) && length(svg) > 0 && grepl("<svg", paste(svg, collapse = "\n"), fixed = TRUE)
      }

      entry_plot_dimensions <- function(entry, default_width = 8.8, default_height = 6.4) {
        params <- entry$params %||% list()
        width_px <- suppressWarnings(as.numeric(params$width_px %||% entry$width_px %||% NA_real_))
        height_px <- suppressWarnings(as.numeric(params$height_px %||% entry$height_px %||% NA_real_))
        list(
          width = if (length(width_px) == 1L && is.finite(width_px) && width_px > 0) width_px / 96 else default_width,
          height = if (length(height_px) == 1L && is.finite(height_px) && height_px > 0) height_px / 96 else default_height
        )
      }

      entry_to_svg <- function(entry) {
        if (is.null(entry)) return("")
        svg_candidates <- list(entry$editor_svg, entry$svg, entry$plot)
        for (candidate in svg_candidates) {
          if (valid_svg_text(candidate)) {
            svg <- paste(candidate, collapse = "\n")
            return(layout_svg_mark_r_plot_layers(svg))
          }
        }
        plot_candidates <- list(entry$r_plot_object, entry$plot_object, entry$plot)
        dimensions <- entry_plot_dimensions(entry)
        for (candidate in plot_candidates) {
          if (inherits(candidate, "ggplot")) {
            svg <- tryCatch(
              layout_plot_svg_markup(candidate, width = dimensions$width, height = dimensions$height),
              error = function(e) ""
            )
            if (valid_svg_text(svg)) return(svg[[1]])
          }
        }
        ""
      }

      entry_to_svgedit_import <- function(entry) {
        if (is.null(entry)) {
          stop("Please create or select an R graph first.", call. = FALSE)
        }

        import_template <- entry$editor_svg_import_template %||% ""
        if (is.character(import_template) && length(import_template) == 1L &&
            nzchar(import_template) &&
            exists("dava_materialize_svg_import_template", mode = "function")) {
          object_id <- dava_make_unique_import_id()
          normalized_svg <- tryCatch(
            dava_materialize_svg_import_template(import_template, object_id),
            error = function(e) ""
          )
          if (valid_svg_text(normalized_svg)) {
            dimensions <- entry_plot_dimensions(entry)
            return(list(
              svg = normalized_svg,
              object_id = object_id,
              width = dimensions$width * 96,
              height = dimensions$height * 96,
              mode = "import"
            ))
          }
        }

        # Generated during registration editor_svg AlreadycontainsUserSettingsThe true whole of width/height/viewBox，
        # must be used first，Avoid from R objectRedraw to default dimensions losing aspect ratio。
        svg_candidates <- list(entry$editor_svg, entry$svg, entry$plot)
        for (candidate_index in seq_along(svg_candidates)) {
          candidate <- svg_candidates[[candidate_index]]
          if (valid_svg_text(candidate)) {
            svg <- paste(candidate, collapse = "\n")
            object_id <- dava_make_unique_import_id()
            # Even ifYesInternal editor_svg，must alsoExecuteOne-time background normalization；The layer tag itself
            # cannot guarantee that allCombination diagramSubpanels all have explicit transparency fill。
            prepared_svg <- dava_clean_svg_for_svgedit(svg)
            if (!grepl("data-dava-r-plot-layer", prepared_svg, fixed = TRUE)) {
              prepared_svg <- layout_svg_mark_r_plot_layers(prepared_svg)
            }
            prefixed_svg <- dava_prefix_svg_ids(prepared_svg, object_id)
            normalized_svg <- dava_wrap_svg_for_svgedit_import(
              prefixed_svg,
              object_id = object_id,
              x_offset = 0,
              y_offset = 0,
              group_first = TRUE,
              already_clean = TRUE,
              validate_output = FALSE
            )
            size <- dava_extract_svg_size(normalized_svg)
            return(list(
              svg = normalized_svg,
              object_id = object_id,
              width = size$width,
              height = size$height,
              mode = "import"
            ))
          }
        }

        dimensions <- entry_plot_dimensions(entry)
        plot_candidates <- list(entry$r_plot_object, entry$plot_object, entry$plot)
        for (candidate in plot_candidates) {
          if (!is.null(candidate) && !is.character(candidate)) {
            return(dava_normalize_r_plot_for_svgedit(
              plot_obj = candidate,
              width = dimensions$width,
              height = dimensions$height,
              bg = "transparent"
            ))
          }
        }

        stop("Please create or select an R graph first.", call. = FALSE)
      }

      current_registry_entry <- reactive({
        registry <- registry_entries()
        gallery <- svg_gallery_entries()
        choices <- registry_choices()
        values <- choice_values(choices)
        if (length(values) == 0 || identical(values, "")) return(NULL)
        selected <- input$svgedit_plot_source %||% selected_svg_source_path() %||% ""
        if (!nzchar(selected) || !selected %in% values) selected <- tail(values, 1)
        selected_svg_source_path(selected)
        parts <- source_parts(selected)
        if (identical(parts$kind, "gallery")) {
          entry <- gallery[[parts$key]]
          if (is.null(entry)) return(NULL)
          entry$path <- entry$path %||% source_value("gallery", parts$key)
          entry$source_kind <- "gallery"
          return(entry)
        }
        entry <- registry[[parts$key]]
        if (is.null(entry)) return(NULL)
        entry$source_kind <- "registry"
        entry
      })

      current_registry_svg <- reactive({
        entry <- current_registry_entry()
        entry_to_svg(entry)
      })

      register_pdf_import_server(input, output, session, file_data)
      register_svg_export_server(input, output, session, file_data)

      gallery_save_default_name <- reactive({
        svg_gallery_entries()
        entry <- current_registry_entry()
        source_title <- if (!is.null(entry)) {
          plot_clean_label(entry$title %||% entry$name %||% entry$source_path %||% entry$path, "SVGEdit")
        } else {
          "SVGEdit"
        }
        dava_svg_gallery_unique_name(file_data, paste0(svg_edit_source_base_name(source_title), "_SVGEdit"))
      })

      observeEvent(gallery_save_default_name(), {
        session$sendCustomMessage("dava-svgedit-gallery-state", list(
          iframeId = "dava_svg_editor_iframe",
          defaultName = gallery_save_default_name()
        ))
      }, ignoreInit = FALSE)

      observeEvent(registry_choices(), {
        choices <- registry_choices()
        selected <- selected_svg_source_path() %||% input$svgedit_plot_source %||% ""
        values <- choice_values(choices)
        if (!selected %in% values) selected <- tail(values, 1)
        updateSelectizeInput(session, "svgedit_plot_source", choices = choices, selected = selected, server = FALSE)
      }, ignoreInit = FALSE)

      observeEvent(input$svgedit_plot_source, {
        selected <- input$svgedit_plot_source %||% ""
        values <- choice_values(registry_choices())
        if (nzchar(selected) && selected %in% values) {
          selected_svg_source_path(selected)
        }
      }, ignoreInit = TRUE)

      send_svg_to_svgedit <- function(svg) {
        session$sendCustomMessage("dava-load-svg-into-svgedit", list(
          svg = svg,
          iframeId = "dava_svg_editor_iframe",
          inputId = session$ns("edited_svg")
        ))
      }

      request_svgedit_export <- function() {
        session$sendCustomMessage("dava-svgedit-command", list(
          command = "DAVA_GET_SVG",
          iframeId = "dava_svg_editor_iframe",
          requestId = paste("svgedit", format(Sys.time(), "%Y%m%d%H%M%OS3"), sep = "-")
        ))
      }

      observeEvent(input$insert_current_r_plot_to_svgedit, {
        entry <- current_registry_entry()
        if (is.null(entry)) {
          showNotification("Please create or select an R graph first.", type = "warning", duration = 4)
          return()
        }

        res <- tryCatch(
          entry_to_svgedit_import(entry),
          error = function(e) {
            showNotification(paste0("R Graphics to SVG conversion failed:", conditionMessage(e)), type = "error", duration = 6)
            NULL
          }
        )
        if (is.null(res) || !valid_svg_text(res$svg)) return()

        dava_send_svg_to_svgedit_import(
          session = session,
          svg_text = res$svg,
          object_id = res$object_id,
          select_after_import = TRUE
        )
        showNotification("The current R graphic has been inserted into the SVG-Edit current layer.", type = "message", duration = 3)
      }, ignoreInit = TRUE)

      observeEvent(input$svgedit_import_file, {
        file <- input$svgedit_import_file
        if (is.null(file) || !nzchar(file$datapath %||% "")) return()
        svg <- tryCatch(
          paste(readLines(file$datapath, warn = FALSE, encoding = "UTF-8"), collapse = "\n"),
          error = function(e) ""
        )
        if (!valid_svg_text(svg)) {
          showNotification("The import file is not a valid SVG and the import has been cancelled.", type = "error", duration = 4)
          return()
        }
        edited_svg(svg)
        send_svg_to_svgedit(svg)
      }, ignoreInit = TRUE)

      observeEvent(input$save_svgedit_svg, {
        session$sendCustomMessage("dava-svgedit-command", list(
          command = "DAVA_OPEN_SAVE_DIALOG",
          iframeId = "dava_svg_editor_iframe",
          source = "toolbar"
        ))
      }, ignoreInit = TRUE)

      observeEvent(input$open_svgedit_export, {
        session$sendCustomMessage("open_svg_export_panel", list(
          iframeId = "dava_svg_editor_iframe"
        ))
      }, ignoreInit = TRUE)

      observeEvent(input$clear_svgedit, {
        edited_svg("")
        session$sendCustomMessage("dava-svgedit-command", list(
          command = "DAVA_CLEAR",
          iframeId = "dava_svg_editor_iframe"
        ))
      }, ignoreInit = TRUE)

      observeEvent(input$edited_svg, {
        svg <- input$edited_svg
        if (!valid_svg_text(svg)) {
          showNotification("SVG-Edit did not return a valid SVG.", type = "error", duration = 4)
          return()
        }
        edited_svg(svg)
        entry <- current_registry_entry()
        source_path <- if (!is.null(entry)) entry$path %||% selected_svg_source_path() %||% "" else selected_svg_source_path() %||% ""
        source_title <- if (!is.null(entry)) plot_clean_label(entry$title %||% entry$name %||% source_path, "SVG graphics") else "SVG graphics"
        save_meta <- input$svgedit_save_meta
        gallery_name <- if (is.list(save_meta)) save_meta$gallery_name %||% "" else ""
        if (!nzchar(gallery_name)) gallery_name <- gallery_save_default_name()
        gallery_name <- svg_safe_name(gallery_name)
        ok <- dava_svg_gallery_register(
          file_data,
          gallery_name,
          svg,
          source = "SVG-Edit",
          source_path = source_path,
          meta = list(
            saved_by = "svgedit",
            source_path = source_path,
            source_title = source_title,
            edited_svg = svg,
            gallery_name = gallery_name,
            saved_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
            svg_element_editable = TRUE
          )
        )
        showNotification(
          if (isTRUE(ok)) paste0("SVG editing results saved to SVG Gallery:", gallery_name) else "SVG editing result failed to save.",
          type = if (isTRUE(ok)) "message" else "error",
          duration = 4
        )
        if (isTRUE(ok)) {
          session$sendCustomMessage("dava-svgedit-save-confirmed", list(
            iframeId = "dava_svg_editor_iframe",
            requestId = if (is.list(save_meta)) save_meta$request_id %||% "" else "",
            galleryName = gallery_name
          ))
        }
      }, ignoreInit = TRUE)

      observeEvent(input$svg_editor_save_document_to_gallery, {
        payload <- input$svg_editor_save_document_to_gallery
        svg <- if (is.list(payload)) payload$svgString %||% "" else ""
        doc_id <- if (is.list(payload)) payload$documentId %||% "" else ""
        doc_name <- if (is.list(payload)) payload$name %||% "" else ""
        if (!valid_svg_text(svg)) {
          showNotification("SVG document save failed: invalid SVG.", type = "error", duration = 4)
          session$sendCustomMessage("svg_document_saved_to_gallery", list(
            iframeId = "dava_svg_editor_iframe",
            documentId = doc_id,
            saved = FALSE
          ))
          return()
        }
        edited_svg(svg)
        entry <- current_registry_entry()
        source_path <- if (!is.null(entry)) entry$path %||% selected_svg_source_path() %||% "" else selected_svg_source_path() %||% ""
        source_title <- if (!is.null(entry)) plot_clean_label(entry$title %||% entry$name %||% source_path, "SVG") else "SVG"
        gallery_name <- svg_safe_name(if (nzchar(doc_name)) doc_name else gallery_save_default_name())
        ok <- dava_svg_gallery_register(
          file_data,
          gallery_name,
          svg,
          source = "SVG-Edit",
          source_path = source_path,
          meta = list(
            saved_by = "svgedit_document_tabs",
            document_id = doc_id,
            source_path = source_path,
            source_title = source_title,
            edited_svg = svg,
            gallery_name = gallery_name,
            saved_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
            svg_element_editable = TRUE
          )
        )
        showNotification(
          if (isTRUE(ok)) paste0("Saved to edited gallery: ", gallery_name) else "Failed to save SVG document to edited gallery.",
          type = if (isTRUE(ok)) "message" else "error",
          duration = 4
        )
        session$sendCustomMessage("svg_document_saved_to_gallery", list(
          iframeId = "dava_svg_editor_iframe",
          documentId = doc_id,
          saved = isTRUE(ok),
          galleryName = gallery_name
        ))
      }, ignoreInit = TRUE)

      observeEvent(input$svgedit_error, {
        msg <- input$svgedit_error %||% "SVG-Edit API not recognized"
        showNotification(msg, type = "error", duration = 5)
      }, ignoreInit = TRUE)

      observeEvent(input$svgedit_import_done, {
        payload <- input$svgedit_import_done
        warning <- if (is.list(payload)) payload$warning %||% "" else ""
        if (nzchar(warning)) {
          showNotification(warning, type = "warning", duration = 5)
        } else {
          showNotification("SVG-Edit has completed the import.", type = "message", duration = 3)
        }
      }, ignoreInit = TRUE)

      observeEvent(input$svgedit_import_error, {
        msg <- input$svgedit_import_error
        if (is.list(msg)) msg <- msg$error %||% msg$message %||% "Unknown error"
        showNotification(paste0("SVG-Edit import failed:", msg), type = "error", duration = 6)
      }, ignoreInit = TRUE)

      current_edited_svg <- reactive({
        svg <- edited_svg()
        if (!valid_svg_text(svg)) svg <- current_registry_svg()
        validate(need(valid_svg_text(svg), "Please create or select a graphic first"))
        svg
      })

      output$download_edited_svg <- downloadHandler(
        filename = function() sprintf("dava_edited_svg_%s.svg", Sys.Date()),
        content = function(file) {
          writeLines(current_edited_svg(), file, useBytes = TRUE)
        }
      )

      return(invisible(NULL))
    }

    output$dataset_select <- renderUI({
      ds_names <- dava_global_dataset_names(file_data)
      demo_label <- paste0(plot_title_by_type(plot_type), "Exclusive simulation data")
      choices <- c(stats::setNames("__demo__", demo_label), ds_names)
      current <- shiny::isolate(input$dataset_select_input %||% "__demo__")
      selected <- if (current %in% unname(choices)) current else "__demo__"
      selectInput(session$ns("dataset_select_input"), "Dataset selection",
        choices = choices, selected = selected)
    })
    raw_df <- reactive({
      selected <- input$dataset_select_input %||% "__demo__"
      if (identical(selected, "__demo__")) return(plot_demo_data(plot_type))
      req(file_data$global_datasets)
      validate(need(selected %in% dava_global_dataset_names(file_data), "The selected data set does not exist."))
      as.data.frame(file_data$global_datasets[[selected]], stringsAsFactors = FALSE, check.names = FALSE)
    })

    dava_module_code_panel_server(
      input, output, session, file_data,
      source_prefix = function() paste("plotting", plot_title_by_type(plot_type), sep = "/"),
      default_code = function() plotting_code_template(input, plot_type, workspace_data = TRUE),
      source = "Graphic drawing",
        title = paste0(plot_title_by_type(plot_type), " Current analysis code"),
      kind = "plot",
      validate_run = function(run) {
        if (is.null(dava_custom_run_plot(run))) {
          stop("The custom drawing code did not produce a displayable graphics object.", call. = FALSE)
        }
        invisible(TRUE)
      },
      plot_params = function() dava_code_plot_params_from_input(input),
      data = function() raw_df(),
      dataset_name = function() input$dataset_select_input %||% "__demo__",
      manifest = list(
        allowed_levels = c("plot", "style", "full"),
        input_schema = "plot_data_and_ui_spec_v1",
        result_schema = "plot_object_v1"),
      standalone_bootstrap = FALSE,
      include_input_snapshot = FALSE,
      preview_plots = function() list("Current figure" = plot_object())
    )

    output$variable_controls <- renderUI({
      req(raw_df())
      df <- raw_df()
      nums <- plot_numeric_vars(df)
      facs <- plot_factor_vars(df)
      all_vars <- names(df)
      defaults <- plot_demo_defaults(plot_type)
      select_default <- function(value, choices, fallback = NULL) {
        if (length(value) && value[[1]] %in% choices) value[[1]] else fallback
      }
      x_default <- select_default(defaults$x, all_vars,
        if (plot_type %in% c("box", "bar", "pie")) facs[1] %||% all_vars[1] else nums[1] %||% all_vars[1])
      y_default <- select_default(defaults$y, nums, nums[2] %||% nums[1] %||% NULL)
      group_default <- select_default(defaults$group, all_vars, facs[1] %||% "")
      facet_default <- select_default(defaults$facet, all_vars, "")
      label_default <- select_default(defaults$label, all_vars, "")
      multi_default <- intersect(defaults$multi_numeric %||% character(), nums)
      if (length(multi_default) < 2L) multi_default <- head(nums, min(6, length(nums)))
      set_default <- intersect(defaults$set_vars %||% character(), all_vars)
      if (length(set_default) < 2L) set_default <- head(all_vars, min(5, length(all_vars)))
      tagList(
        if (plot_type %in% c("box", "bar", "pie", "scatter", "line")) selectInput(session$ns("x_var"), "X / grouping variable", choices = all_vars, selected = x_default),
        if (plot_type %in% c("box", "bar", "scatter", "line")) selectInput(session$ns("y_var"), "Y / Numeric variable", choices = nums, selected = y_default),
        if (plot_type %in% c("box", "bar", "scatter", "line")) selectInput(session$ns("group_var"), "Color/grouping variables", choices = c("None" = "", all_vars), selected = group_default),
        if (plot_type %in% c("box", "bar", "scatter", "line")) selectInput(session$ns("facet_var"), "Faceted variables", choices = c("None" = "", all_vars), selected = facet_default),
        if (plot_type %in% c("scatter")) selectInput(session$ns("label_var"), "tag variable", choices = c("None" = "", all_vars), selected = label_default),
        if (plot_type %in% c("corr", "tree", "network")) pickerInput(session$ns("multi_numeric_vars"), "Numeric variable, multiple selections possible", choices = nums, selected = multi_default, multiple = TRUE, options = list(`live-search` = TRUE, `actions-box` = TRUE)),
        if (plot_type == "upset") pickerInput(session$ns("set_vars"), "Collection variables, multiple selections possible", choices = all_vars, selected = set_default, multiple = TRUE, options = list(`live-search` = TRUE, `actions-box` = TRUE)),
        if (plot_type == "network") tagList(
          selectInput(session$ns("source_var"), "Edge starting point source, can be left blank to use related networks", choices = c("None" = "", all_vars), selected = ""),
          selectInput(session$ns("target_var"), "edge end target", choices = c("None" = "", all_vars), selected = ""),
          selectInput(session$ns("weight_var"), "edge weight weight", choices = c("None" = "", nums), selected = "")
        )
      )
    })
    custom_plot_object <- reactive({
      file_data$method_code_revision %||% 0L
      method_key <- paste("plotting", plot_title_by_type(plot_type), sep = "/")
      dava_method_code_effective(
        original = function() NULL,
        file_data = file_data,
        method_key = method_key,
        adapter = function(run, entry) {
          current_run <- dava_method_code_execute(file_data, method_key,
          data = raw_df(),
          dataset_name = input$dataset_select_input %||% "__demo__",
          spec = dava_code_analysis_spec_from_input(input))
          dava_custom_run_assert(current_run)
          plot <- dava_custom_run_plot(current_run)
          if (is.null(plot)) {
            stop("The custom drawing code did not produce a displayable graphics object.", call. = FALSE)
          }
          plot
        },
        on_error = function(message) {
          warning("User-defined drawing execution failed and the original drawing has been rolled back:", message,
          call. = FALSE)
          NULL
        }
      )
    })

    plot_object <- reactive({
      req(raw_df())
      if (plot_type == "tree") return(NULL)
      custom <- custom_plot_object()
      if (!is.null(custom)) return(custom)
      p <- build_scientific_plot(raw_df(), input, plot_type)
      dava_code_register(
        file_data,
        paste("plotting", plot_title_by_type(plot_type), "current", sep = "/"),
        plotting_code_template(input, plot_type),
        source = "Graphic drawing",
        title = paste0(plot_title_by_type(plot_type), " Current analysis code"),
        kind = "plot",
        editable = TRUE,
        runnable = TRUE,
        params = list(plot_type = plot_type)
      )
      dava_plot_english_labels(p)
    })

    plotting_plot_dimensions <- dava_plot_size_server(
      input, output, session, "static_plot", "plotting_plot_size", width = 900, height = 700,
      content_ui = function() {
        plotly_status <- plotly_ggplotly_status()
        if (isTRUE(input$interactive) && plot_type != "tree" && isTRUE(plotly_status$ok)) {
          plotly::plotlyOutput(session$ns("plotly_plot"), width = "100%", height = "100%")
        } else {
          plotOutput(session$ns("static_plot"), width = "100%", height = "100%")
        }
      }
    )

    output$static_plot <- renderPlot({
      req(raw_df())
      if (plot_type == "tree") {
        custom <- custom_plot_object()
        if (inherits(custom, "recordedplot")) replayPlot(custom)
        else if (dava_code_is_plot_object(custom)) print(custom)
        else draw_tree_plot(raw_df(), input, plot_type)
      } else {
        p <- plot_object()
        print(p)
      }
    })

    observeEvent(input$add_current_plot_to_library, {
      if (plot_type == "tree") {
        showNotification("The tree diagram does not support adding it directly to the layout library. Please export it first and then import it.", type = "warning", duration = 3)
        return()
      }
      p <- plot_object()
      dims <- plotting_plot_dimensions()
      ok <- dava_plot_register(
        file_data,
        paste("plotting", plot_title_by_type(plot_type), "current", sep = "/"),
        p,
        source = "Graphic drawing",
        title = plot_clean_label(input$plot_title, plot_title_by_type(plot_type)),
        meta = list(plot_type = plot_type, added_by = "manual"),
        params = c(
          list(plot_type = plot_type, width_px = dims$width_px, height_px = dims$height_px),
          dava_plot_input_params(input)
        ),
        editor_svg = dava_plot_editor_svg_sized(p, dims)
      )
      showNotification(
        if (isTRUE(ok)) "has been added to the layout beautification library." else "Add failed: The current figure is not a registerable ggplot/SVG object.",
        type = if (isTRUE(ok)) "message" else "error",
        duration = 3
      )
    })
    output$plotly_plot <- plotly::renderPlotly({
      req(plot_object())
      plotly_status <- plotly_ggplotly_status()
      validate(need(isTRUE(plotly_status$ok), plotly_status$message))
      tryCatch(
        plotly::ggplotly(plot_object(), tooltip = c("x", "y", "colour", "fill", "label")),
        error = function(e) {
          validate(need(FALSE, paste0("Interactive conversion failed, it is recommended to temporarily turn off interactive graphics. Original error:", conditionMessage(e))))
        }
      )
    })

    output$raw_data_preview <- renderDT({
      req(raw_df())
      datatable(raw_df(), rownames = TRUE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })

    output$plot_data_preview <- renderDT({
      req(raw_df())
      df <- raw_df()
      dat <- tryCatch({
        if (plot_type == "corr") make_corr_df(df, input$multi_numeric_vars %||% plot_numeric_vars(df), input$cor_method %||% "pearson")
        else if (plot_type == "upset") make_upset_df(df, input$set_vars %||% names(df), input$min_count %||% 1)
        else {
          cols <- unique(c(input$x_var, input$y_var, input$group_var, input$facet_var, input$label_var, input$multi_numeric_vars, input$set_vars))
          cols <- cols[nzchar(cols) & cols %in% names(df)]
          if (length(cols) == 0) head(df, 20) else df[, cols, drop = FALSE]
        }
      }, error = function(e) data.frame(message = conditionMessage(e)))
      datatable(dat, rownames = FALSE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })

    output$message_table <- renderDT({
      plotly_status <- plotly_ggplotly_status()
      datatable(data.frame(
        item = c("interactive", "Export", "Suggestions"),
        message = c(
          if (isTRUE(input$interactive)) plotly_status$message else "Static publication image preview.",
          "PNG/PDF export uses current width, height and DPI settings.",
          "It is recommended to export the paper drawings to PDF for vector typesetting. The final bitmap can be used at 600 DPI."
        )
      ), rownames = FALSE, options = list(dom = "t"))
    })
    save_current_plot <- function(file, device) {
      dims <- plotting_plot_dimensions()
      dpi <- input$fig_dpi %||% 300
      if (plot_type == "tree") {
        if (device == "png") {
          dava_open_png_device(file, width = dims$width_px,
            height = dims$height_px, units = "px", res = dpi)
        } else {
          dava_open_pdf_device(file, width = dims$width_in,
            height = dims$height_in)
        }
        on.exit(grDevices::dev.off(), add = TRUE)
        draw_tree_plot(raw_df(), input, plot_type)
      } else {
        dava_save_sized_plot(file, plot_object(), device, dims, dpi)
      }
    }

    output$download_png <- downloadHandler(
      filename = function() sprintf("%s_%s.png", plot_type, Sys.Date()),
      content = function(file) save_current_plot(file, "png")
    )

    output$download_pdf <- downloadHandler(
      filename = function() sprintf("%s_%s.pdf", plot_type, Sys.Date()),
      content = function(file) save_current_plot(file, "pdf")
    )
  })
}


