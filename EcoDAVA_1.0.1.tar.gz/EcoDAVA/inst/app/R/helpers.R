# helpers.R
# Package loading and shared helper functions.

`%||%` <- function(x, y) if (is.null(x)) y else x

core_pkgs <- c(
  "shiny", "bslib", "shinyjs", "readxl", "writexl", "readr",
  "rhandsontable", "DT", "dplyr", "tibble", "stringr", "purrr",
  "shinyWidgets", "data.table", "tidyr", "rlang", "ggplot2",
  "nortest", "car", "MASS", "shinyjqui", "broom", "broom.mixed",
  "future", "promises", "later", "callr", "processx", "patchwork",
  "afex", "blme", "emmeans", "lme4", "multcomp", "multcompView"
)

# Runtime condition routing -------------------------------------------------
#
# Shiny evaluates analysis code and plot renderers in callbacks.  An ordinary
# warning() or an uncaught plotting error therefore ends up in the R process
# console instead of the currently open DAVA diagnostics panel.  Keep a small
# process-local condition store and provide one capture primitive for all
# analysis modules.  Conditions are muffled after being recorded, so the
# external console remains quiet while the module can present the same text to
# the user.
if (!exists(".dava_runtime_condition_store", envir = .GlobalEnv,
    inherits = FALSE)) {
  assign(".dava_runtime_condition_store", new.env(parent = emptyenv()),
    envir = .GlobalEnv)
}
.dava_runtime_condition_store$records <-
  .dava_runtime_condition_store$records %||% list()

dava_record_runtime_condition <- function(level = c("message", "warning", "error"),
                                           message = "", source = "") {
  level <- match.arg(level)
  message <- trimws(as.character(message %||% ""), which = "right")
  if (!nzchar(trimws(message))) return(invisible(FALSE))
  record <- list(
    time = Sys.time(), level = level, source = as.character(source %||% ""),
    message = message
  )
  store <- get(".dava_runtime_condition_store", envir = .GlobalEnv,
    inherits = FALSE)
  store$records <- c(store$records %||% list(), list(record))
  # Avoid unbounded growth in long-running desktop sessions while preserving
  # enough history for the active module's diagnostics panel.
  if (length(store$records) > 500L) {
    store$records <- tail(store$records, 500L)
  }
  invisible(TRUE)
}

dava_runtime_condition_records <- function(levels = c("message", "warning", "error"),
                                            source = NULL) {
  store <- get(".dava_runtime_condition_store", envir = .GlobalEnv,
    inherits = FALSE)
  records <- store$records %||% list()
  if (!length(records)) {
    return(data.frame(time = as.POSIXct(character()), level = character(),
      source = character(), message = character(), stringsAsFactors = FALSE))
  }
  out <- do.call(rbind, lapply(records, function(record) {
    data.frame(time = as.POSIXct(record$time), level = record$level,
      source = record$source, message = record$message,
      stringsAsFactors = FALSE, check.names = FALSE)
  }))
  out <- out[out$level %in% levels, , drop = FALSE]
  if (!is.null(source)) out <- out[out$source %in% source, , drop = FALSE]
  out
}

dava_capture_conditions <- function(expr, source = "") {
  messages <- warnings <- character()
  error_message <- ""
  value <- tryCatch(
    withCallingHandlers(
      expr,
      message = function(condition) {
        message_text <- conditionMessage(condition)
        messages <<- c(messages, message_text)
        dava_record_runtime_condition("message", message_text, source)
        invokeRestart("muffleMessage")
      },
      warning = function(condition) {
        warning_text <- conditionMessage(condition)
        warnings <<- c(warnings, warning_text)
        dava_record_runtime_condition("warning", warning_text, source)
        invokeRestart("muffleWarning")
      }
    ),
    error = function(condition) {
      # req()/validate() use a silent condition as normal Shiny flow control.
      # Do not turn that state into a visible plot failure.
      if (inherits(condition, "shiny.silent.error")) return(NULL)
      error_message <<- conditionMessage(condition)
      dava_record_runtime_condition("error", error_message, source)
      NULL
    }
  )
  list(value = value, messages = unique(messages), warnings = unique(warnings),
    error = error_message)
}

dava_plot_condition_text <- function(captured, source = "") {
  prefix <- if (nzchar(source %||% "")) paste0("[", source, "] ") else ""
  c(
    if (nzchar(captured$error %||% "")) paste0(prefix, "ERROR: ", captured$error),
    if (length(captured$warnings %||% character())) paste0(prefix,
      "WARNING: ", captured$warnings),
    if (length(captured$messages %||% character())) paste0(prefix,
      "MESSAGE: ", captured$messages)
  )
}

dava_plot_diagnostic_placeholder <- function(message, level = "error") {
  message <- paste(as.character(message %||% "Plot rendering failed."),
    collapse = "\n")
  graphics::plot.new()
  graphics::par(mar = c(0, 0, 0, 0))
  graphics::text(0.5, 0.56, labels = message, col = if (identical(level, "warning"))
    "#9a6700" else "#b42318", cex = 0.95, xpd = NA)
  invisible(NULL)
}

dava_append_diagnostic_rows <- function(table, messages, source = "Plot rendering") {
  messages <- unique(trimws(as.character(messages %||% ""), which = "right"))
  messages <- messages[nzchar(trimws(messages))]
  if (!length(messages)) return(table %||% data.frame())
  table <- if (is.data.frame(table)) table else data.frame()
  if (!ncol(table)) {
    return(data.frame(level = rep("error", length(messages)),
      source = rep(source, length(messages)), message = messages,
      stringsAsFactors = FALSE, check.names = FALSE))
  }
  message_column <- intersect(c("error", "message", "warning", "detail"), names(table))
  message_column <- if (length(message_column)) message_column[[1]] else names(table)[[1]]
  rows <- lapply(messages, function(message) {
    row <- as.list(rep(NA, ncol(table)))
    names(row) <- names(table)
    row[[message_column]] <- message
    as.data.frame(row, stringsAsFactors = FALSE, check.names = FALSE)
  })
  rbind(table, do.call(rbind, rows))
}

dava_load_core_package <- function(package) {
  dava_capture_conditions(
    require(package, character.only = TRUE, quietly = TRUE),
    source = paste0("Package startup: ", package)
  )$value
}

dava_runtime_diagnostic_lines <- function(levels = c("warning", "error"),
                                          exclude_package_startup = TRUE) {
  records <- dava_runtime_condition_records(levels = levels)
  if (isTRUE(exclude_package_startup) && nrow(records)) {
    records <- records[!grepl("^Package startup:", records$source), , drop = FALSE]
  }
  if (!nrow(records)) return(character())
  unique(paste0(toupper(records$level), ": ", records$message))
}

failed_packages <- core_pkgs[!vapply(core_pkgs, function(package) {
  isTRUE(tryCatch(requireNamespace(package, quietly = TRUE),
    error = function(error) FALSE))
}, logical(1))]

if (length(failed_packages) > 0) {
  stop(
    "Please install the necessary startup packages first:\n",
    paste0("install.packages(c(", paste(sprintf('\"%s\"', failed_packages), collapse = ", "), "))"),
    call. = FALSE)
}

invisible(lapply(core_pkgs, dava_load_core_package))

dava_install_cran_packages <- function(pkgs,
    repos = "https://cloud.r-project.org") {
  pkgs <- unique(pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)])
  if (!length(pkgs)) return(invisible(TRUE))
  tryCatch(
    utils::install.packages(pkgs, repos = repos, dependencies = TRUE),
    error = function(error) NULL)
  remaining <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (!length(remaining)) return(invisible(TRUE))

  old <- options(timeout = max(300, getOption("timeout", 60)),
    download.file.method = "libcurl")
  on.exit(options(old), add = TRUE)
  mirrors <- unique(c("https://cran.r-project.org", repos))
  for (pkg in remaining) {
    for (mirror in mirrors) {
      tryCatch(
        utils::install.packages(pkg, repos = mirror, dependencies = TRUE,
          type = getOption("pkgType", "both")),
        error = function(error) NULL)
      if (requireNamespace(pkg, quietly = TRUE)) break
    }
  }
  invisible(TRUE)
}

dava_install_packages <- function(pkgs, purpose = "This analysis",
                                  repos = "https://cloud.r-project.org") {
  pkgs <- unique(as.character(pkgs))
  pkgs <- pkgs[!is.na(pkgs) & nzchar(pkgs)]
  missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (!length(missing)) return(invisible(TRUE))

  bioconductor <- c(
    "ALDEx2", "ANCOMBC", "Biobase", "biomformat", "Biostrings",
    "ComplexHeatmap", "DECIPHER", "DESeq2", "edgeR", "ggtree",
    "ggtreeExtra", "lefser", "Maaslin2", "metagenomeSeq", "mia",
    "microbiome", "mixOmics", "phyloseq", "rhdf5", "SpiecEasi",
    "SummarizedExperiment", "tidytree", "treeio", "zCompositions"
  )
  github <- c(
    LinDA = "zhouhj1994/LinDA", SPRING = "GraceYoon/SPRING",
    NetCoMi = "stefpeschel/NetCoMi", FEAST = "cozygene/FEAST",
    fastshap = "bgreenwell/fastshap", iCAMP = "DaliangNing/iCAMP1",
    ggClusterNet = "taowenmicro/ggClusterNet"
  )
  archives <- c(
    A3 = "https://cran.r-project.org/src/contrib/Archive/A3/A3_1.0.0.tar.gz",
    rbiom = "https://cran.r-project.org/src/contrib/Archive/rbiom/rbiom_2.2.1.tar.gz",
    Tax4Fun2 = paste0(
      "https://zenodo.org/api/records/10035668/files/",
      "Tax4Fun2_1.1.5.tar.gz/content")
  )

  bioc <- intersect(missing, bioconductor)
  github_names <- intersect(missing, names(github))
  archive_names <- intersect(missing, names(archives))
  cran <- setdiff(missing, c(bioc, github_names, archive_names))
  if (length(cran)) dava_install_cran_packages(cran, repos = repos)
  if (length(bioc)) {
    if (!requireNamespace("BiocManager", quietly = TRUE)) {
      utils::install.packages("BiocManager", repos = repos)
    }
    BiocManager::install(bioc, ask = FALSE, update = FALSE)
  }
  if (length(github_names)) {
    if (!requireNamespace("remotes", quietly = TRUE)) {
      utils::install.packages("remotes", repos = repos)
    }
    for (pkg in github_names) {
      remotes::install_github(github[[pkg]], dependencies = TRUE,
        upgrade = "never", force = FALSE)
    }
  }
  for (pkg in archive_names) {
    utils::install.packages(archives[[pkg]], repos = NULL, type = "source")
  }

  unresolved <- missing[!vapply(missing, requireNamespace, logical(1), quietly = TRUE)]
  if (length(unresolved)) {
    stop(purpose, "Automatic installation of required dependencies failed:", paste(unresolved, collapse = ", "),
      ". Please check the network, R package repository and system compilation tools and try again.", call. = FALSE)
  }
  invisible(TRUE)
}

ensure_packages <- function(pkgs, purpose = "This analysis") {
  dava_install_packages(pkgs, purpose = purpose)
}

# Emit a portable import statement for a versioned local simulated-data asset.
dava_local_demo_code <- function(relative_path, object_name = "df") {
  parts <- strsplit(gsub("\\\\", "/", relative_path), "/", fixed = TRUE)[[1]]
  path_code <- paste(sprintf("%s", dQuote(c(".dava_project_root", "data", "simulated_datasets", parts), q = FALSE)),
    collapse = ", ")
  path_code <- sub('".dava_project_root"', ".dava_project_root", path_code, fixed = TRUE)
  paste(
    ".dava_project_root <- c('.', '..', '../..', '../../..')[file.exists(file.path(c('.', '..', '../..', '../../..'), 'data', 'simulated_datasets', 'manifest.csv'))][1]",
    sprintf("%s <- readRDS(file.path(%s))", object_name, path_code),
    sep = "\n"
  )
}

dava_demo_asset_root <- function() {
  configured <- getOption("dava.project_root", Sys.getenv("DAVA_PROJECT_ROOT", unset = ""))
  candidates <- unique(c(configured, ".", "..", file.path("..", ".."), file.path("..", "..", "..")))
  candidates <- candidates[nzchar(candidates) & !is.na(candidates)]
  roots <- candidates[file.exists(file.path(candidates, "data", "simulated_datasets", "manifest.csv"))]
  if (!length(roots)) {
    stop("Cannot locate the local simulated_datasets directory.", call. = FALSE)
  }
  normalizePath(file.path(roots[[1]], "data", "simulated_datasets"),
    winslash = "/", mustWork = TRUE)
}

dava_demo_asset_path <- function(relative_path, must_work = TRUE) {
  relative_path <- gsub("\\\\", "/", as.character(relative_path %||% ""))
  if (!nzchar(relative_path) || grepl("(^|/)\\.\\.(/|$)", relative_path) ||
      grepl("^[A-Za-z]:|^/", relative_path)) {
    stop("Invalid simulated-data asset path.", call. = FALSE)
  }
  parts <- strsplit(relative_path, "/", fixed = TRUE)[[1]]
  path <- do.call(file.path, as.list(c(dava_demo_asset_root(), parts)))
  if (isTRUE(must_work) && !file.exists(path)) {
    stop("The local simulated-data asset is missing: ", relative_path,
      ". Run scripts/build_simulated_datasets.R to rebuild it.", call. = FALSE)
  }
  normalizePath(path, winslash = "/", mustWork = must_work)
}

dava_local_demo_read <- function(relative_path) {
  readRDS(dava_demo_asset_path(relative_path, must_work = TRUE))
}

dava_microbiome_demo_asset <- function(method_id) {
  paste0("microbiome/methods/", gsub("[^A-Za-z0-9_.-]", "_", method_id), ".rds")
}

dava_platform <- function(os_type = .Platform$OS.type,
    sysname = Sys.info()[["sysname"]] %||% "") {
  if (identical(os_type, "windows") || identical(sysname, "Windows")) {
    return("windows")
  }
  if (identical(sysname, "Darwin")) return("macos")
  if (identical(sysname, "Linux")) return("linux")
  tolower(as.character(sysname %||% "unknown"))
}

dava_available_cores <- function(logical = TRUE, reserve = 0L) {
  detected <- suppressWarnings(parallel::detectCores(logical = logical))
  if (!length(detected) || !is.finite(detected[[1]]) || detected[[1]] < 1L) {
    detected <- 1L
  }
  max(1L, as.integer(detected[[1]]) - max(0L, as.integer(reserve %||% 0L)))
}

dava_choose_directory <- function(default = getwd(), caption = "Select directory") {
  default <- normalizePath(default, winslash = "/", mustWork = FALSE)
  if (requireNamespace("rstudioapi", quietly = TRUE) &&
      isTRUE(tryCatch(rstudioapi::isAvailable(), error = function(error) FALSE)) &&
      isTRUE(tryCatch(
        rstudioapi::hasFun("selectDirectory"), error = function(error) FALSE))) {
    selected <- rstudioapi::selectDirectory(
      caption = caption, label = "Select", path = default)
    return(if (is.null(selected)) NA_character_ else
      as.character(selected)[[1]])
  }
  platform <- dava_platform()
  if (identical(platform, "windows") && interactive()) {
    return(utils::choose.dir(default = default, caption = caption))
  }
  if (capabilities("tcltk") && requireNamespace("tcltk", quietly = TRUE)) {
    selected <- tryCatch(
      tcltk::tk_choose.dir(default = default, caption = caption),
      error = function(error) "")
    if (nzchar(selected %||% "")) return(as.character(selected)[[1]])
  }
  if (identical(platform, "macos") && nzchar(Sys.which("osascript"))) {
    escaped_caption <- gsub('"', '\\"', caption, fixed = TRUE)
    script <- paste0(
      'POSIX path of (choose folder with prompt "', escaped_caption, '")')
    selected <- tryCatch(system2(
      "osascript", c("-e", shQuote(script)), stdout = TRUE, stderr = FALSE),
      error = function(error) character())
    if (length(selected) && nzchar(selected[[1]])) return(selected[[1]])
  }
  if (identical(platform, "linux")) {
    zenity <- Sys.which("zenity")
    if (nzchar(zenity)) {
      selected <- tryCatch(system2(
        zenity,
        c("--file-selection", "--directory", paste0("--title=", caption),
          paste0("--filename=", default, "/")),
        stdout = TRUE, stderr = FALSE), error = function(error) character())
      if (length(selected) && nzchar(selected[[1]])) return(selected[[1]])
    }
    kdialog <- Sys.which("kdialog")
    if (nzchar(kdialog)) {
      selected <- tryCatch(system2(
        kdialog, c("--getexistingdirectory", default, "--title", caption),
        stdout = TRUE, stderr = FALSE), error = function(error) character())
      if (length(selected) && nzchar(selected[[1]])) return(selected[[1]])
    }
  }
  NA_character_
}

dava_open_png_device <- function(file, width, height, res = 96,
    units = "px", background = "transparent") {
  if (requireNamespace("ragg", quietly = TRUE)) {
    ragg::agg_png(file, width = width, height = height, units = units,
      res = res, background = background)
  } else {
    arguments <- list(
      filename = file, width = width, height = height, units = units,
      res = res, bg = background)
    if (!identical(dava_platform(), "windows") && capabilities("cairo")) {
      arguments$type <- "cairo"
    }
    do.call(grDevices::png, arguments)
  }
  invisible(grDevices::dev.cur())
}

dava_open_pdf_device <- function(file, width, height, onefile = FALSE,
    background = "transparent") {
  if (capabilities("cairo")) {
    grDevices::cairo_pdf(
      filename = file, width = width, height = height,
      onefile = onefile, bg = background)
  } else {
    grDevices::pdf(
      file = file, width = width, height = height, onefile = onefile,
      bg = background, family = "sans", useDingbats = FALSE)
  }
  invisible(grDevices::dev.cur())
}

dava_open_tiff_device <- function(file, width, height, res = 300,
    units = "px", compression = "lzw", background = "white") {
  if (!capabilities("tiff")) {
    stop(
      "The current R build does not support TIFF graphics devices; please install R that supports TIFF,",
      "Or install rsvg and magick and try again.", call. = FALSE)
  }
  grDevices::tiff(
    filename = file, width = width, height = height, units = units,
    res = res, compression = compression, bg = background)
  invisible(grDevices::dev.cur())
}

dava_platform_status <- function() {
  temp_probe <- tempfile("dava-platform-probe-")
  writable_temp <- tryCatch({
    writeLines("ok", temp_probe, useBytes = TRUE)
    unlink(temp_probe, force = TRUE)
    TRUE
  }, error = function(error) FALSE)
  data.frame(
    item = c(
      "operating_system", "r_version", "utf8_locale", "writable_temp",
      "png", "cairo", "tiff", "libcurl", "available_cores"),
    value = c(
      dava_platform(), as.character(getRversion()),
      isTRUE(l10n_info()[["UTF-8"]]), writable_temp,
      capabilities("png"), capabilities("cairo"), capabilities("tiff"),
      capabilities("libcurl"), dava_available_cores()),
    stringsAsFactors = FALSE)
}

dava_global_datasets <- function(file_data, tabular_only = TRUE) {
  if (is.null(file_data)) return(list())
  datasets <- tryCatch(file_data$global_datasets %||% list(),
    error = function(error) list())
  if (!is.list(datasets)) return(list())
  dataset_names <- names(datasets) %||% character()
  valid_names <- !is.na(dataset_names) & nzchar(trimws(dataset_names))
  datasets <- datasets[valid_names]
  if (isTRUE(tabular_only) && length(datasets)) {
    tabular <- vapply(datasets, function(value) {
      is.data.frame(value) || is.matrix(value) || inherits(value, "data.table")
    }, logical(1))
    datasets <- datasets[tabular]
  }
  datasets[!duplicated(names(datasets))]
}

dava_global_dataset_names <- function(file_data, tabular_only = TRUE) {
  names(dava_global_datasets(file_data, tabular_only = tabular_only)) %||%
    character()
}

safe_file_stem <- function(x) {
  tools::file_path_sans_ext(basename(x))
}

safe_sheet_name <- function(x) {
  x <- gsub("[\\[\\]\\:\\*\\?/\\\\]", "_", x)
  x <- trimws(x)
  x <- substr(x, 1, 31)
  if (nchar(x) == 0) x <- "Sheet1"
  x
}

dava_parse_newick_tree <- function(text) {
  text <- trimws(paste(as.character(text %||% ""), collapse = ""))
  if (!nzchar(text)) {
    stop("The Newick content of the phylogenetic tree is empty.", call. = FALSE)
  }
  if (!grepl(";\\s*$", text, perl = TRUE)) {
    stop("Newick phylogenetic trees must end with a semicolon (;).", call. = FALSE)
  }
  if (!requireNamespace("ape", quietly = TRUE)) {
    stop("Reading the Newick phylogenetic tree requires the ape package.", call. = FALSE)
  }

  parse_warnings <- character()
  tree <- tryCatch(
    withCallingHandlers(
      ape::read.tree(text = text),
      warning = function(warning) {
        parse_warnings <<- c(parse_warnings, conditionMessage(warning))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(error) error
  )
  if (inherits(tree, "error")) {
    stop("Unable to parse phylogenetic tree Newick string:",
      conditionMessage(tree), call. = FALSE)
  }
  if (length(parse_warnings)) {
    stop("Unable to parse phylogenetic tree Newick string:",
      paste(unique(parse_warnings), collapse = "; "), call. = FALSE)
  }
  if (!inherits(tree, "phylo") || !length(tree$tip.label)) {
    stop("Newick content did not generate a valid phylogenetic tree.", call. = FALSE)
  }
  tree
}

make_unique_names <- function(x) {
  make.unique(x, sep = "_")
}

normalize_df <- function(df) {
  df <- as.data.frame(df, stringsAsFactors = FALSE, check.names = FALSE)
  names(df) <- make_unique_names(names(df))
  rownames(df) <- NULL
  df
}

normalize_df_keep_rownames <- function(df) {
  rn <- rownames(df)
  df2 <- normalize_df(df)
  if (!is.null(rn) && length(rn) == nrow(df2)) {
    rownames(df2) <- make_unique_names(as.character(rn))
  }
  df2
}

dava_xlsx_safe_tables <- function(tables, chunk_size = 30000L) {
  if (!is.list(tables)) stop("XLSX export must be a list of worksheets.", call. = FALSE)
  if (!length(tables)) return(list(Sheet1 = data.frame(message = "No data loaded")))
  chunk_size <- as.integer(chunk_size)
  if (is.na(chunk_size) || chunk_size < 1L || chunk_size > 32767L) {
    stop("XLSX long text chunk size must be between 1 and 32767.", call. = FALSE)
  }
  table_names <- names(tables)
  if (is.null(table_names)) table_names <- rep("", length(tables))
  missing_names <- is.na(table_names) | !nzchar(table_names)
  table_names[missing_names] <- paste0("Sheet", which(missing_names))
  names(tables) <- make.unique(table_names, sep = "_")

  long_text <- list()
  record_id <- 0L
  safe_tables <- lapply(seq_along(tables), function(table_index) {
    table <- as.data.frame(tables[[table_index]], stringsAsFactors = FALSE,
      check.names = FALSE)
    if (!nrow(table) || !ncol(table)) return(table)
    for (column_index in seq_along(table)) {
      column <- table[[column_index]]
      if (!(is.character(column) || is.factor(column))) next
      values <- as.character(column)
      lengths <- nchar(values, type = "chars", allowNA = TRUE,
        keepNA = TRUE)
      long_rows <- which(!is.na(lengths) & lengths > 32767L)
      if (!length(long_rows)) next
      for (row_index in long_rows) {
        record_id <<- record_id + 1L
        value <- values[[row_index]]
        starts <- seq.int(1L, nchar(value, type = "chars"), by = chunk_size)
        chunks <- substring(value, starts,
          pmin(starts + chunk_size - 1L, nchar(value, type = "chars")))
        long_text[[length(long_text) + 1L]] <<- data.frame(
          record_id = record_id,
          source_sheet = names(tables)[[table_index]],
          source_row = row_index,
          source_column = names(table)[[column_index]],
          chunk_index = seq_along(chunks),
          original_length = nchar(value, type = "chars"),
          text = chunks,
          stringsAsFactors = FALSE, check.names = FALSE)
        values[[row_index]] <- paste0(
          "[Long text moved to long_text; record_id=", record_id, "]")
      }
      table[[column_index]] <- values
    }
    table
  })
  names(safe_tables) <- names(tables)
  if (length(long_text)) {
    sidecar_name <- "long_text"
    suffix <- 1L
    while (sidecar_name %in% names(safe_tables)) {
      suffix <- suffix + 1L
      sidecar_name <- paste0("long_text_", suffix)
    }
    safe_tables[[sidecar_name]] <- do.call(rbind, long_text)
  }
  safe_tables
}

# ReturnmodelOptional dependencies。Application does not load at startup、Installation without Internet connection，Only inSelectcorresponds to the methodCheck。
DAVA_REGRESSION_CRAN_PACKAGES <- c(
  "MASS", "segmented", "minpack.lm", "robustbase", "sandwich",
  "nnet", "ordinal", "betareg", "pscl", "lme4", "glmmTMB",
  "mgcv", "DHARMa", "performance", "emmeans", "pls", "glmnet",
  "mediation", "interactions", "vegan", "mvabund", "gllvm", "Hmsc",
  "rrpack", "corncob", "ape", "nlme", "phylolm"
)

DAVA_REGRESSION_BIOC_PACKAGES <- c(
  "Maaslin2", "ANCOMBC", "DESeq2", "edgeR", "ALDEx2", "metagenomeSeq"
)

dava_installed_packages <- function(refresh = FALSE) {
  cache_name <- ".dava_installed_packages_cache"
  if (isTRUE(refresh) || !exists(cache_name, envir = .GlobalEnv, inherits = FALSE)) {
    assign(cache_name, rownames(utils::installed.packages()), envir = .GlobalEnv)
  }
  get(cache_name, envir = .GlobalEnv, inherits = FALSE)
}

dava_packages_available <- function(pkgs, refresh = FALSE) {
  pkgs %in% c("stats", "splines") | pkgs %in% dava_installed_packages(refresh)
}

regression_dependency_catalog <- function(refresh = FALSE) {
  packages <- unique(c(DAVA_REGRESSION_CRAN_PACKAGES, DAVA_REGRESSION_BIOC_PACKAGES))
  source <- ifelse(packages %in% DAVA_REGRESSION_BIOC_PACKAGES, "Bioconductor", "CRAN")
  data.frame(
    package = packages,
    source = source,
    installed = dava_packages_available(packages, refresh),
    version = vapply(packages, function(pkg) {
      if (!dava_packages_available(pkg, refresh = FALSE)) return(NA_character_)
      as.character(utils::packageVersion(pkg))
    }, character(1)),
    stringsAsFactors = FALSE
  )
}

regression_install_commands <- function(pkgs) {
  pkgs <- unique(pkgs[nzchar(pkgs)])
  cran <- intersect(pkgs, DAVA_REGRESSION_CRAN_PACKAGES)
  bioc <- intersect(pkgs, DAVA_REGRESSION_BIOC_PACKAGES)
  commands <- character()
  if (length(cran)) commands <- c(commands, paste0(
    "install.packages(c(", paste(encodeString(cran, quote = "\""), collapse = ", "), "))"
  ))
  if (length(bioc)) commands <- c(commands, paste0(
    "BiocManager::install(c(", paste(encodeString(bioc, quote = "\""), collapse = ", "), "), ask = FALSE, update = FALSE)"
  ))
  commands
}

ensure_regression_packages <- function(pkgs, purpose = "The regression method") {
  dava_install_packages(pkgs, purpose = purpose)
  dava_installed_packages(refresh = TRUE)
  invisible(TRUE)
}

guess_and_read_delim <- function(path, ext) {
  if (tolower(ext) == "csv") {
    utils::read.csv(
      path,
      stringsAsFactors = FALSE,
      check.names = FALSE,
      na.strings = c("", "NA", "N/A", "NULL")
    )
  } else {
    utils::read.delim(
      path,
      sep = "\t",
      stringsAsFactors = FALSE,
      check.names = FALSE,
      na.strings = c("", "NA", "N/A", "NULL")
    )
  }
}

coerce_column <- function(x, to) {
  to <- tolower(to)

  if (to == "character") return(as.character(x))
  if (to == "factor") return(factor(as.character(x), exclude = NA))
  if (to == "numeric") return(suppressWarnings(as.numeric(x)))
  if (to == "integer") return(suppressWarnings(as.integer(x)))

  if (to == "logical") {
    out <- as.character(x)
    out <- trimws(tolower(out))
    out[out %in% c("", "na", "n/a", "null")] <- NA_character_
    true_vals <- c("true", "t", "1", "yes", "y")
    false_vals <- c("false", "f", "0", "no", "n")
    res <- ifelse(
      out %in% true_vals,
      TRUE,
      ifelse(out %in% false_vals, FALSE, NA)
    )
    return(as.logical(res))
  }

  if (to == "date") {
    if (inherits(x, "Date")) return(as.Date(x))
    if (inherits(x, "POSIXt")) return(as.Date(x))

    suppressWarnings({
      num_x <- as.numeric(x)
    })

    if (any(!is.na(num_x))) {
      res <- as.Date(num_x, origin = "1899-12-30")
      blank_mask <- is.na(x) | trimws(as.character(x)) == ""
      res[blank_mask] <- as.Date(NA)
      return(res)
    }

    return(suppressWarnings(as.Date(as.character(x))))
  }

  x
}

df_summary <- function(df) {
  tibble::tibble(
    column = names(df),
    class = vapply(df, function(x) paste(class(x), collapse = ", "), character(1)),
    n_missing = vapply(
      df,
      function(x) sum(is.na(x) | (is.character(x) & trimws(x) == "")),
      integer(1)
    ),
    n_unique = vapply(
      df,
      function(x) dplyr::n_distinct(x, na.rm = TRUE),
      integer(1)
    ),
    example = vapply(df, function(x) {
      vals <- unique(x[!is.na(x) & !(is.character(x) & trimws(x) == "")])
      if (length(vals) == 0) "" else substr(as.character(vals[1]), 1, 80)
    }, character(1))
  )
}

empty_like_row <- function(df) {
  if (ncol(df) == 0) return(data.frame())

  vals <- lapply(df, function(col) {
    if (inherits(col, "Date")) as.Date(NA)
    else if (is.numeric(col)) NA_real_
    else if (is.integer(col)) NA_integer_
    else if (is.logical(col)) NA
    else NA_character_
  })

  out <- as.data.frame(vals, stringsAsFactors = FALSE, check.names = FALSE)
  names(out) <- names(df)
  out
}

# Fast paged table helpers for rhandsontable preview.
# Rendering 100k+ rows directly into rhandsontable is slow because the widget is browser-side.
# These helpers render only the current slice/page.

slice_df <- function(df, page = 1, page_size = 200, col_page = 1, col_page_size = 100) {
  page <- suppressWarnings(as.integer(page))
  page_size <- suppressWarnings(as.integer(page_size))
  col_page <- suppressWarnings(as.integer(col_page))
  col_page_size <- suppressWarnings(as.integer(col_page_size))

  if (is.na(page) || page < 1) page <- 1
  if (is.na(page_size) || page_size < 1) page_size <- 200
  if (is.na(col_page) || col_page < 1) col_page <- 1
  if (is.na(col_page_size) || col_page_size < 1) col_page_size <- 100

  n <- nrow(df)
  p <- ncol(df)
  if (n == 0 || p == 0) return(df)

  max_page <- ceiling(n / page_size)
  max_col_page <- ceiling(p / col_page_size)
  page <- min(page, max_page)
  col_page <- min(col_page, max_col_page)

  r_start <- (page - 1) * page_size + 1
  r_end <- min(r_start + page_size - 1, n)
  c_start <- (col_page - 1) * col_page_size + 1
  c_end <- min(c_start + col_page_size - 1, p)

  df[r_start:r_end, c_start:c_end, drop = FALSE]
}

paged_info_text <- function(df, page = 1, page_size = 200, col_page = 1, col_page_size = 100,
                            language = "en") {
  page <- suppressWarnings(as.integer(page))
  page_size <- suppressWarnings(as.integer(page_size))
  col_page <- suppressWarnings(as.integer(col_page))
  col_page_size <- suppressWarnings(as.integer(col_page_size))

  if (is.na(page) || page < 1) page <- 1
  if (is.na(page_size) || page_size < 1) page_size <- 200
  if (is.na(col_page) || col_page < 1) col_page <- 1
  if (is.na(col_page_size) || col_page_size < 1) col_page_size <- 100

  n <- nrow(df)
  p <- ncol(df)
  if (n == 0 || p == 0) {
    return(dava_tr("Current data: %s rows, %s columns", language,
      format(n, big.mark = ","), format(p, big.mark = ",")))
  }

  max_page <- ceiling(n / page_size)
  max_col_page <- ceiling(p / col_page_size)
  page <- min(page, max_page)
  col_page <- min(col_page, max_col_page)
  r_start <- (page - 1) * page_size + 1
  r_end <- min(r_start + page_size - 1, n)
  c_start <- (col_page - 1) * col_page_size + 1
  c_end <- min(c_start + col_page_size - 1, p)

  dava_tr(
    "Showing rows %s-%s; %s rows total; page %s / %s; %s rows per page; showing columns %s-%s; %s columns total; page %s / %s; %s columns per page",
    language,
    format(r_start, big.mark = ","),
    format(r_end, big.mark = ","),
    format(n, big.mark = ","),
    format(page, big.mark = ","),
    format(max_page, big.mark = ","),
    format(page_size, big.mark = ","),
    format(c_start, big.mark = ","),
    format(c_end, big.mark = ","),
    format(p, big.mark = ","),
    format(col_page, big.mark = ","),
    format(max_col_page, big.mark = ","),
    format(col_page_size, big.mark = ",")
  )
}



#--------------------
# Statistical testsrelatedfunction
#--------------------

numeric_vars <- function(df) {
  names(df)[vapply(df, function(x) is.numeric(x) || is.integer(x), logical(1))]
}

#---GetSelect response variable------
coerce_factor_cols <- function(df, cols) {
  cols <- cols[cols %in% names(df)]
  for (nm in cols) df[[nm]] <- as.factor(df[[nm]])
  df
}

#-----modelFixed effectssection-----
fixed_formula_part <- function(fixed_vars, factor_n) {
  fixed_vars <- fixed_vars[fixed_vars != ""]
  factor_n <- as.character(factor_n %||% "")[1]
  n <- length(fixed_vars)
  
  if (n == 0) return("1")
  
  if (factor_n == "Single factor") {
    return(fixed_vars[1])
  }
  
  if (factor_n == "Two factors") {
    if (n < 2) stop("A two-factor model requires the selection of at least 2 fixed effect variables.")
    return(paste(fixed_vars[1:2], collapse = " * "))
  }
  
  if (factor_n == "Three factors") {
    if (n < 3) stop("A three-factor model requires the selection of at least 3 fixed effect variables.")
    return(paste(fixed_vars[1:3], collapse = " * "))
  }
  
  if (factor_n == "Four factors") {
    if (n < 4) stop("A four-factor model requires the selection of at least 4 fixed effect variables.")
    return(paste(fixed_vars[1:4], collapse = " * "))
  }
  
  paste(fixed_vars, collapse = " * ")
}

#---modelRandom effectssection----
random_formula_part <- function(random_type, random_intercept, random_slope, random_nested, random_crossed) {
  random_type <- as.character(random_type %||% "")[1]
  if (random_type == "Random intercept") {
    if (length(random_intercept) < 1) stop("Random intercept models require the selection of at least 1 random effect variable.")
    return(paste0("(1 | ", random_intercept[1], ")"))
  }
  
  if (random_type == "Random slope") {
    if (length(random_intercept) < 1) stop("Random slope models require the selection of random grouping variables.")
    if (length(random_slope) < 1) stop("Random slope models require the selection of random slope variables.")
    return(paste0("(", random_slope[1], " | ", random_intercept[1], ")"))
  }
  
  if (random_type == "Nested random") {
    if (length(random_nested) < 2) stop("Nested random models require at least 2 random variables to be selected, such as block/plot.")
    return(paste0("(1 | ", paste(random_nested, collapse = "/"), ")"))
  }
  
  if (random_type == "Crossover random") {
    if (length(random_crossed) < 2) stop("A crossed random model requires the selection of at least 2 crossed random variables.")
    return(paste0(paste0("(1 | ", random_crossed, ")"), collapse = " + "))
  }
  
  stop("Unidentified random effects structure.")
}

#------modelstructure-------
build_model_formula <- function(response, fixed_vars, model_family, factor_n,
                                subject, within_factors, between_factors, block, covariates,
                                random_type, random_intercept, random_slope, random_nested, random_crossed) {
  model_family <- as.character(model_family %||% "")[1]
  fixed_part <- fixed_formula_part(fixed_vars, factor_n)
  
  if (model_family %in% c("ANOVA","anova_CRD")) {
    return(as.formula(paste(response, "~", fixed_part)))
  } else if(model_family == "anova_block"){
    return(as.formula(paste(response, "~", fixed_part, "+", block)))
  } else if(model_family == "anova_repeated"){
    if (length(subject) < 1) stop("Repeated measures ANOVA requires selection of within/subjects variables.")
    if (length(within_factors) < 1) stop("Repeated measures ANOVA requires selection of at least 1 within factor.")
    
    between_part <- if (length(between_factors) > 0) fixed_formula_part(between_factors, length(between_factors)) else "1"
    within_part <- fixed_formula_part(within_factors, length(within_factors))
    error_part <- paste0("Error(", subject[1], "/", within_part, ")")
    
    return(as.formula(paste(response, "~", between_part, "*", within_part, "+", error_part)))
    
    
    
  } else if(model_family == "ancova"){
    return(as.formula(paste(response, "~", fixed_part, "+", paste(covariates, collapse = " + "))))
  }
  
  rand_part <- random_formula_part(
    random_type = random_type,
    random_intercept = random_intercept,
    random_slope = random_slope,
    random_nested = random_nested,
    random_crossed = random_crossed
  )
  
  as.formula(paste(response, "~", fixed_part, "+", rand_part))
  
}


fit_one_model <- function(df, response, fixed_vars, model_family, factor_n,
                          subject, within_factors, between_factors, block, covariates,
                          random_type, random_intercept, random_slope, random_nested, random_crossed,
                          distribution_family, use_bayes_fallback = FALSE) {
  model_family <- as.character(model_family %||% "")[1]
  response <- as.character(response %||% "")[1]
  distribution_family <- as.character(distribution_family %||% "")[1]
  
  factor_vars <- unique(c(fixed_vars, random_intercept, random_slope, random_nested, random_crossed,
                          subject, within_factors, between_factors, block))
  num_vars <- unique(c(response,covariates))
  
  use_cols <- c(response, factor_vars, covariates)
  dat <- df[, use_cols, drop = FALSE]
  dat <- tidyr::drop_na(dat)
  
  dat <- dat |>
    dplyr::mutate(dplyr::across(dplyr::all_of(factor_vars), as.factor)) |>
    dplyr::mutate(dplyr::across(dplyr::all_of(num_vars), ~ suppressWarnings(as.numeric(.x)))) |>
    droplevels()
  
  if (all(is.na(dat[[response]]))) {
    stop("Response variables are all NA or cannot be converted to numeric values.")
  }
  
  if (length(unique(dat[[response]])) < 2) {
    stop("The response variable does not have enough variation to model.")
  }
  
  group_cols <- setdiff(use_cols, response)
  dat <- coerce_factor_cols(dat, group_cols)
  
  fml <- build_model_formula(
    response = response,
    fixed_vars = fixed_vars,
    model_family = model_family,
    factor_n = factor_n,
    subject = subject, 
    within_factors = within_factors, 
    between_factors = between_factors,
    block = block, 
    covariates = covariates,
    random_type = random_type,
    random_intercept = random_intercept,
    random_slope = random_slope,
    random_nested = random_nested,
    random_crossed = random_crossed
  )
  
  model <- NULL
  anova_table <- data.frame()
  model_table <- data.frame()
  model_status <- data.frame(
    response = response,
    model_family = model_family,
    converged = NA,
    singular = NA,
    bayes_used = FALSE,
    message = NA_character_
  )
  
  if (model_family %in% c("ANOVA","ancova", "anova_block", "anova_CRD")) {
    model <- stats::lm(fml, data = dat)
    anova_table <- extract_anova_table(model, model_family)
    model_table <- extract_model_table(model, model_family)
    
    model_status$converged <- TRUE
    model_status$singular <- FALSE
    model_status$message <- "LM/ANOVA model completed."
  } else if (model_family == "anova_repeated"){
    ensure_packages("afex", "Repeated Measures Analysis of Variance")
    model <- suppressWarnings(suppressMessages(afex::aov_car(fml, data = dat, type = 3)))
    afex_msg <- tryCatch({
      afex::aov_car(fml, data = dat, type = 3)
    }, warning = function(w) {
      return(w$message)
    })
    anova_table <- suppressWarnings(suppressMessages(extract_anova_table(model, model_family)))
    model_table <- suppressWarnings(suppressMessages(extract_model_table(model, model_family)))
    
    model_status$converged <- TRUE
    model_status$singular <- FALSE
    model_status$message <- paste("Repeated measures ANOVA completed.", afex_msg)
  } else if(model_family == "LMM"){
    ensure_packages("lme4", "Linear mixed effects model")
    model <- suppressWarnings(suppressMessages(
      lme4::lmer(
      fml,
      data = dat,
      REML = TRUE,
      control = lme4::lmerControl(
        optimizer = "bobyqa",
        optCtrl = list(maxfun = 2e5)
      ))
      ))
    
    st <- get_mer_status(model)
    model_status$converged <- st$converged
    model_status$singular <- st$singular
    model_status$message <- st$message
    
    if ((!st$converged || st$singular) && isTRUE(use_bayes_fallback)) {
      ensure_packages("blme", "Bayesian Mixture Model fallback")
      model <- blme::blmer(formula = fml, 
                           data = dat, 
                           fixef.prior = blme::normal(sd = 10),
                           cov.prior = blme::wishart(df = 3),
                           resid.prior = blme::gamma(shape = 2, rate = 1),
                           control = lme4::lmerControl(
                             optimizer = "bobyqa",
                             optCtrl = list(maxfun = 2e5)))
      
      st <- get_mer_status(model)
      model_status$converged <- st$converged
      model_status$singular <- st$singular
      model_status$message <- st$message
      model_status$bayes_used <- TRUE
    }
    
    anova_table <- extract_anova_table(model, model_family)
    model_table <- extract_model_table(model, model_family)
    
  } else if (model_family == "GLMM"){
    ensure_packages("lme4", "Generalized Linear Mixed Effects Model")
    fam <- distribution_family %||% "poisson"
    if (fam == "negative binomial") {
      model <- suppressWarnings(suppressMessages(
        lme4::glmer.nb(
        fml,
        data = dat,
        control = lme4::glmerControl(
          optimizer = "bobyqa",
          optCtrl = list(maxfun = 2e5)
        ))
      ))
      
      st <- get_mer_status(model)
      
      model_status$converged <- st$converged
      model_status$singular <- st$singular
      model_status$message <- st$message
      
      if ((!st$converged || st$singular) && isTRUE(use_bayes_fallback)) {
        ensure_packages("blme", "Bayesian generalized mixed model fallback")
        model <- blme::bglmer(fml, data = dat, 
                              family = stats::negbinomial(),
                              fixef.prior = blme::normal(sd = 10),
                              cov.prior = blme::wishart(df = 3),
                              control = lme4::glmerControl(
                                optimizer = "bobyqa",
                                optCtrl = list(maxfun = 2e5))
                              )
        
        st <- get_mer_status(model)
        model_status$converged <- st$converged
        model_status$singular <- st$singular
        model_status$message <- st$message
        model_status$bayes_used <- TRUE
      }
      
    } else {
      family_obj <- switch(
        fam,
        "binomial" = stats::binomial(),
        "poisson" = stats::poisson(),
        "gamma" = stats::Gamma(link = "log"),
        "inverse gaussian" = stats::inverse.gaussian(link = "log"),
        "gaussian" = stats::gaussian(link = "identity"),
        stop("Unsupported GLMM distribution type:", fam)
      )
      
      model <- suppressWarnings(suppressMessages(
        lme4::glmer(
        fml,
        data = dat,
        family = family_obj,
        control = lme4::glmerControl(
          optimizer = "bobyqa",
          optCtrl = list(maxfun = 2e5)
        ))
      ))
      
      st <- get_mer_status(model)
      model_status$converged <- st$converged
      model_status$singular <- st$singular
      model_status$message <- st$message
      
      if ((!st$converged || st$singular) && isTRUE(use_bayes_fallback)) {
        ensure_packages("blme", "Bayesian generalized mixed model fallback")
        model <- blme::bglmer(fml, data = dat, 
                              family = family_obj,
                              fixef.prior = blme::normal(sd = 10),
                              cov.prior = blme::wishart(df = 3),
                              control = lme4::glmerControl(
                                optimizer = "bobyqa",
                                optCtrl = list(maxfun = 2e5))
        )
        
        st <- get_mer_status(model)
        model_status$converged <- st$converged
        model_status$singular <- st$singular
        model_status$message <- st$message
        model_status$bayes_used <- TRUE
      }
      
    }
    
    anova_table <- extract_anova_table(model, model_family)
    model_table <- extract_model_table(model, model_family)
  }
  
  if(model_family == "anova_repeated"){
    terms_to_compare <- make_terms(unique(c(within_factors, between_factors)))
  }else{
    terms_to_compare <- make_terms(fixed_vars)
  }
  
  return(
    list(
    formula = fml,
    model_family = model_family,
    model = model,
    model_table = model_table,
    anova_table = anova_table,
    model_status = model_status,
    terms_to_compare = terms_to_compare,
    data = dat)
    )
}

#modelDiagnosisfunction
get_mer_status <- function(model, tol = 1e-4) {
  
  conv_msg <- model@optinfo$conv$lme4$messages
  singular <- lme4::isSingular(model, tol = tol)
  
  grad <- model@optinfo$derivs$gradient
  max_gradient <- if (!is.null(grad)) max(abs(grad), na.rm = TRUE) else NA_real_
  
  vc <- tryCatch(
    as.data.frame(lme4::VarCorr(model)),
    error = function(e) data.frame()
  )
  
  min_random_variance <- if (nrow(vc) > 0 && "vcov" %in% names(vc)) {
    min(vc$vcov, na.rm = TRUE)
  } else {
    NA_real_
  }
  
  data.frame(
    converged = is.null(conv_msg),
    singular = singular,
    max_gradient = max_gradient,
    min_random_variance = min_random_variance,
    message = if (is.null(conv_msg)) {
      if (singular) {
        "The model has converged, but there is singular fit and the random effects structure may be too complex."
      } else {
        "The model converges normally."
      }
    } else {
      paste(conv_msg, collapse = "; ")
    },
    stringsAsFactors = FALSE
  )
}

# Model resultsExtractfunction
extract_model_table <- function(model, model_family) {
  
  tryCatch({
    
    if (inherits(model, "brmsfit")) {
      
      brms::fixef(model) |>
        as.data.frame() |>
        tibble::rownames_to_column("term")
      
    } else if (inherits(model, "merMod")) {
      
      broom.mixed::tidy(model, effects = "fixed")
      
    } else if (inherits(model, "lm")) {
      
      broom::tidy(model)
      
    } else if (model_family == "anova_repeated") {
      
      broom::tidy(model$anova_table)
      
    } else {
      
      data.frame(message = "The model type is not recognized.")
    }
    
  }, error = function(e) {
    data.frame(error = e$message)
  })
}

extract_anova_table <- function(model, model_family) {
  
  tryCatch({
    
    if (inherits(model, "brmsfit")) {
      
      brms::fixef(model) |>
        as.data.frame() |>
        tibble::rownames_to_column("term")
      
    } else if (model_family %in% c("ANOVA", "ancova", "anova_block", "anova_CRD")) {
      raw <- as.data.frame(stats::anova(model), stringsAsFactors = FALSE,
        check.names = FALSE)
      raw$term <- rownames(raw)
      rownames(raw) <- NULL
      aliases <- c(
        "Df" = "df", "Sum Sq" = "sumsq", "Mean Sq" = "meansq",
        "F value" = "statistic", "Pr(>F)" = "p.value"
      )
      for (source in names(aliases)) {
        if (source %in% names(raw) && !aliases[[source]] %in% names(raw)) {
          names(raw)[names(raw) == source] <- aliases[[source]]
        }
      }
      raw <- raw[c("term", setdiff(names(raw), "term"))]
      raw
      
    } else if (model_family == "anova_repeated") {
      
      broom::tidy(model$anova_table)
      
    } else if (inherits(model, "merMod")) {
      
      broom.mixed::tidy(car::Anova(model), effects = "fixed")
      
    } else {
      
      data.frame(message = "The current model does not support ANOVA table extraction.")
    }
    
  }, error = function(e) {
    data.frame(error = e$message)
  })
}


#-------------Data transformation-------
transform_vector <- function(x, method = "none") {
  x <- suppressWarnings(as.numeric(x))
  method <- tolower(method)
  if(method == "none") {
    return(x)
  }
  
  if (method == "log") {
    min_x <- suppressWarnings(min(x, na.rm = TRUE))
    offset <- ifelse(is.finite(min_x) && min_x <= 0, abs(min_x) + 1, 0)
    return(log(x + offset))
  }
  
  if (method == "square root") {
    min_x <- suppressWarnings(min(x, na.rm = TRUE))
    offset <- ifelse(is.finite(min_x) && min_x < 0, abs(min_x), 0)
    return(sqrt(x + offset))
  }
  
  if (method == "reciprocal") {
    return(ifelse(x == 0, NA_real_, 1 / x))
  }
  
  if (method == "arcsine") {
    # applies to scaleData；If notYes 0-1 range，AutomaticNormalization
    rng <- range(x, na.rm = TRUE)
    if (is.finite(rng[1]) && is.finite(rng[2]) && (rng[1] < 0 || rng[2] > 1)) {
      x <- (x - rng[1]) / (rng[2] - rng[1])
    }
    x[x < 0 | x > 1] <- NA_real_
    return(asin(sqrt(x)))
  }
  
  if (method == "box-cox") {
    
    #MASS::boxcox()
    min_x <- suppressWarnings(min(x, na.rm = TRUE))
    offset <- ifelse(is.finite(min_x) && min_x <= 0, abs(min_x) + 1, 0)
    y <- x + offset

    ok <- is.finite(y) & !is.na(y)
    if (sum(ok) < 3 || length(unique(y[ok])) < 3) return(x)

    bc <- tryCatch(
      MASS::boxcox(lm(y[ok] ~ 1), plotit = FALSE),
      error = function(e) NULL
    )

    if (is.null(bc)) return(x)

    lambda <- bc$x[which.max(bc$y)]

    if (abs(lambda) < 1e-6) {
      out <- log(y)
    } else {
      out <- (y^lambda - 1) / lambda
    }
    
    #car::powerTransform()
    # df<-as.data.frame(x)
    # if(min(x, na.rm = TRUE)>0){
    #   pt <- car::powerTransform(df$x, family = "bcPower")
    #   df$x_transformed <- car::bcPower(df$x, lambda = pt$lambda)
    # }else{
    #   pt <- car::powerTransform(df$x, family = "yjPower")
    #   df$x_transformed <- car::yjPower(df$x, lambda = pt$lambda)
    # }
    # return(df$x_transformed)
    
    return(out)
  }
  
  #x
}

transform_as_df<-function(data, response, response_trans_vars, trans_method){
  
  response_vars <- intersect(response, names(data))
  response_df <- data[response_vars]
  trans_vars <- intersect(response_trans_vars,response)
  trans_df <- data[trans_vars]
  
  transform_df <- dplyr::bind_cols(
    lapply(trans_df, transform_vector, method = trans_method %||% "none")
  )
  names(transform_df) <- trans_vars
  data[trans_vars] <- transform_df
  
  return(data)
}


#------Normality test--------
normality_tests <- function(resid_vec, method = "Shapiro-Wilk") {
  resid_vec <- resid_vec[is.finite(resid_vec)]
  n <- length(resid_vec)
  
  out <- data.frame()
  if(method == "Shapiro-Wilk"){
    if (n >= 3 && n <= 5000) {
      sw <- tryCatch(stats::shapiro.test(resid_vec), error = function(e) NULL)
      if (!is.null(sw)) {
        out <- data.frame(
          test = "Shapiro-Wilk",
          statistic = unname(sw$statistic),
          p_value = sw$p.value
        )
      }
    } else {
      out <- data.frame(
        test = "Shapiro-Wilk",
        statistic = NA_real_,
        p_value = NA_real_
      )
    }
  } else if(method == "Kolmogorov-Smirnov"){
    ks <- tryCatch(stats::ks.test(scale(resid_vec)[, 1], "pnorm"), error = function(e) NULL)
    if (!is.null(ks)) {
      out <- data.frame(
        test = "Kolmogorov-Smirnov",
        statistic = unname(ks$statistic),
        p_value = ks$p.value
      )
    }
  } else if(method == "Anderson-Darling"){
    ad <- tryCatch(nortest::ad.test(resid_vec), error = function(e) NULL)
    if (!is.null(ad)) {
      out <- data.frame(
        test = "Anderson-Darling",
        statistic = unname(ad$statistic),
        p_value = ad$p.value
      )
    }
  }
  
  out
}


#-----Test for homogeneity of variances-----
variance_tests <- function(resid_vec, dat, fixed_vars, method = "Levene") {
  dat$.resid <- resid_vec
  fixed_vars <- fixed_vars[fixed_vars %in% names(dat)]
  
  if (length(fixed_vars) == 0) {
    return(data.frame(
      test = "Variance homogeneity",
      statistic = NA_real_,
      p_value = NA_real_,
      note = "The fixed effect grouping variable is not selected, and the homogeneity of variance test between groups cannot be performed."
    ))
  }
  
  fml <- as.formula(
    paste(".resid ~ interaction(", paste(fixed_vars, collapse = ","), ", drop = TRUE)")
  )
  
  out <- data.frame()
  if (method == "Levene"){
    lev <- tryCatch(car::leveneTest(fml, data = dat), error = function(e) NULL)
    if (!is.null(lev)) {
      out <- data.frame(
        test = "Levene",
        statistic = unname(lev[1, "F value"]),
        p_value = unname(lev[1, "Pr(>F)"])
      )
    }
  } else if (method == "Bartlett"){
    bart <- tryCatch(stats::bartlett.test(fml, data = dat), error = function(e) NULL)
    if (!is.null(bart)) {
      out <- data.frame(
        test = "Bartlett",
        statistic = unname(bart$statistic),
        p_value = bart$p.value
      )
    }
  } else if(method == "Fligner-Killeen"){
    flig <- tryCatch(stats::fligner.test(fml, data = dat), error = function(e) NULL)
    if (!is.null(flig)) {
      out <- data.frame(
        test = "Fligner-Killeen",
        statistic = unname(flig$statistic),
        p_value = flig$p.value
      )
    }
  }
  
  out
}


#--------modelResidualExtract-Shota sexCheck-------
diagnose_one_response <- function(df, response, fixed_vars, model_family, factor_n,
                                  subject, within_factors, between_factors, block, covariates,
                                  random_type, random_intercept, random_slope, random_nested, random_crossed, 
                                  distribution_family, use_bayes_fallback = FALSE,
                                  norm_test, vari_test) {
  fit <- fit_one_model(
    df = df,
    response = response,
    fixed_vars = fixed_vars,
    model_family = model_family,
    factor_n = factor_n,
    random_type = random_type,
    random_intercept = random_intercept,
    random_slope = random_slope,
    random_nested = random_nested,
    random_crossed = random_crossed,
    subject = subject,
    within_factors = within_factors,
    between_factors = between_factors,
    block = block,
    covariates = covariates,
    distribution_family = distribution_family
  )
  
  resid_vec <- residuals(fit$model)
  fitted_vec <- fitted(fit$model)
  
  norm <- normality_tests(resid_vec, method = norm_test) |>
    mutate(response = response, formula = deparse(fit$formula), .before = 1)
  
  vari <- variance_tests(resid_vec, fit$data, fixed_vars, method = vari_test) |>
    mutate(response = response, formula = deparse(fit$formula), .before = 1)
  
  model_summary <- extract_anova_table(fit$model, model_family) |>
    mutate(response = response, formula = deparse(fit$formula), .before = 1)
  
  qq_df <- data.frame(
    response = response,
    residual = resid_vec,
    fitted = fitted_vec
  )
  
  list(
    fit = fit,
    normality = norm,
    variance = vari,
    model_summary = model_summary,
    qq_data = qq_df
  )
}

#--------------------------------------
#------Multiple comparisons----------
dava_cld_from_pairwise <- function(letter_df, pairs_df, term, alpha = 0.05) {
  if (!grepl("|", term, fixed = TRUE) || !requireNamespace("multcompView", quietly = TRUE)) {
    return(letter_df)
  }

  term_parts <- trimws(strsplit(term, "|", fixed = TRUE)[[1]])
  tested_var <- term_parts[1]
  by_vars <- term_parts[-1]
  required_letters <- c(tested_var, by_vars, "letter")
  required_pairs <- c(by_vars, "contrast", "p.value")
  if (!all(required_letters %in% names(letter_df)) || !all(required_pairs %in% names(pairs_df))) {
    return(letter_df)
  }

  strata <- interaction(pairs_df[by_vars], drop = TRUE, lex.order = TRUE)
  pair_groups <- split(seq_len(nrow(pairs_df)), strata)
  for (indices in pair_groups) {
    current_pairs <- pairs_df[indices, , drop = FALSE]
    p_values <- suppressWarnings(as.numeric(current_pairs[["p.value"]]))
    contrasts <- as.character(current_pairs[["contrast"]])
    valid <- is.finite(p_values) & nzchar(contrasts)
    if (!any(valid)) next

    names(p_values) <- gsub(" - ", "-", contrasts, fixed = TRUE)
    cld <- tryCatch(
      multcompView::multcompLetters(p_values[valid], threshold = alpha)$Letters,
      error = function(e) NULL
    )
    if (is.null(cld)) next

    letter_rows <- rep(TRUE, nrow(letter_df))
    for (by_var in by_vars) {
      letter_rows <- letter_rows &
        as.character(letter_df[[by_var]]) == as.character(current_pairs[[by_var]][1])
    }
    levels_in_stratum <- as.character(letter_df[[tested_var]][letter_rows])
    replacement <- unname(cld[levels_in_stratum])
    replaceable <- !is.na(replacement) & nzchar(replacement)
    target_rows <- which(letter_rows)[replaceable]
    letter_df[["letter"]][target_rows] <- replacement[replaceable]
  }
  letter_df
}

multiple_comparison_test <- function(all_models, all_terms, adjust){
  ensure_packages(c("emmeans", "multcomp", "multcompView"), "Multiple comparisons")
  #all_models = all_models; all_terms = all_terms; adjus = "tukey"
  all_posthoc <- list()
  all_letters <- list()
  for (y in names(all_models)) {
    #y = names(all_models)[1]
    model <- all_models[[y]]
    for (term in all_terms[[y]]) {
      #term= all_terms[[y]][1]
      tmp <- tryCatch({
        emm <-suppressWarnings(suppressMessages(emmeans::emmeans(model, specs = as.formula(paste("~", term)))))  #BlockConsoleshowNote and warning
        
        pairs_df <- suppressWarnings(suppressMessages(pairs(emm, adjust = adjust))) |>
          as.data.frame() |>
          mutate(response = y, term = term, p_star = p_to_star(p.value), .before = 1)
        
        letter_df <- suppressWarnings(suppressMessages(multcomp::cld(emm, alpha = 0.05, adjust = adjust, Letters = base::letters))) |>
          as.data.frame() |>
          rename(letter = .group) |>
          mutate(letter = stringr::str_replace_all(letter, " ", ""), response = y, term = term, .before = 1)

        letter_df <- dava_cld_from_pairwise(letter_df, pairs_df, term, alpha = 0.05)
        
        list(pairs = pairs_df, letters = letter_df)
      }, error = function(e) {
        list(
          pairs = tibble(response = y, term = term, error = conditionMessage(e)),
          letters = tibble(response = y, term = term, error = conditionMessage(e))
        )
      })
      
      all_posthoc[[paste(y, term, sep = " ~ ")]] <- tmp$pairs
      all_letters[[paste(y, term, sep = " ~ ")]] <- tmp$letters
    }
  }
  
  
  all_posthoc_df<- dplyr::bind_rows(
    lapply(names(all_posthoc), function(x) {
      all_posthoc[[x]] |>
        dplyr::mutate(expression = x, .before = 1)
    })
  )
  
  all_letters_df<- dplyr::bind_rows(
    lapply(names(all_letters), function(x) {
      all_letters[[x]] |>
        dplyr::mutate(expression = x, .before = 1)
    })
  )
  
  
  posthoc_aov <- format_anova_table(bind_rows(all_posthoc_df))
  letters_aov <- format_anova_table(bind_rows(all_letters_df))
  
  return(list(posthoc_aov = posthoc_aov, letters_aov = letters_aov ))
}




#----------Analysis of Variance+Multiple comparisonssection----------
make_terms <- function(factors) {
  factors <- factors[!is.na(factors) & factors != ""]
  factors <- factors[1:min(4, length(factors))]
  if (length(factors) == 0) return(character(0))
  x1<-unlist(lapply(seq_along(factors), function(k) {
    combn(factors, k, FUN = function(z) paste(z, collapse = ":"))
  }))
  
  com1<-c()
  for(i in seq_along(factors)){
    #i=3
    chars1<-gtools::permutations(n = length(factors), r = i, v = factors)
    for(j in 1:nrow(chars1)){
      #j=1
      com2<-paste(chars1[j,], collapse = "|")
      com1 = c(com1, com2)
    }
  }
  
  return(unique(c(x1,com1)))
}

term_label <- function(response, term) paste(response, term, sep = " ~ ")

split_term_label <- function(x) {
  z <- strsplit(x, " \\~ ")[[1]]
  list(response = z[1], term = z[2])
}


p_to_star <- function(p) {
  if (exists("p_to_significance", mode = "function", inherits = TRUE)) {
    out <- p_to_significance(p)
    out[is.na(out)] <- ""
    return(out)
  }
  dplyr::case_when(
    is.na(p) ~ "",
    p < 0.0001 ~ "****",
    p < 0.001 ~ "***",
    p < 0.01 ~ "**",
    p < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

#-----ANOVA resultsFormat------
format_pvalue <- function(x, digits = 4) {
  x <- suppressWarnings(as.numeric(x))
  ifelse(
    is.na(x),
    NA_character_,
    ifelse(
      x < 10^-digits,
      paste0("<", format(10^-digits, scientific = FALSE)),
      sprintf(paste0("%.", digits, "f"), x)
    )
  )
}

format_anova_table <- function(df, digits = 4) {
  df <- as.data.frame(df, stringsAsFactors = FALSE)
  p_col <- intersect(c("p.value", "p_value", "Pr(>F)", "Pr(>Chisq)", "p", "p.value."), names(df))
  if (length(p_col) > 0) {
    df$significance <- p_to_star(df[[p_col[1]]])
  }
  dbl_cols <- names(df)[vapply(df, is.double, logical(1))]
  dbl_cols <- setdiff(dbl_cols, p_col)
  if (length(dbl_cols) > 0) {
    df[dbl_cols] <- lapply(df[dbl_cols], function(x) round(x, digits))
  }
  if (length(p_col) > 0) {
    df[[p_col[1]]] <- format_pvalue(df[[p_col[1]]], digits = digits)
  }
  df
}



dat_group_summary <- function(df, response, group){
  # df<-data
  # response <- names(data)[8]
  # group <- c("Time","A" )
  
  df |>
    group_by(across(all_of(group))) |>
    summarise(
      min = min(.data[[response]]),
      max = max(.data[[response]]),
      mean = mean(.data[[response]]),
      n = n(),  # Count the number of records in each group
      sd = sd(.data[[response]]),
      se = sd(.data[[response]])/sqrt(n()),
      .groups = "drop_last" 
    ) |>
    as.data.frame()
}



demo_data_set<-function(){
  if (exists("grassland_demo_data", mode = "function")) return(grassland_demo_data())
  set.seed(123)
  expand.grid(
    Block = paste0("B", 1:4),
    Subject = paste0("S", 1:12),
    Time = c("T1", "T2", "T3"),
    A = c("A1", "A2"),
    B = c("B1", "B2"),
    C = c("C1", "C2"),
    KEEP.OUT.ATTRS = FALSE
  ) |>
    as_tibble() |>
    mutate(
      Cov1 = rnorm(n(), 10, 2),
      Height = 20 + if_else(A == "A2", 3, 0) + if_else(B == "B2", 2, 0) + if_else(C == "C2", -1, 0) + as.numeric(factor(Time)) * 1.2 + rnorm(n(), 0, 2),
      Biomass = 5 + if_else(A == "A2", 1.5, 0) - if_else(B == "B2", 0.8, 0) + 0.2 * Cov1 + rnorm(n(), 0, 1),
      Root = 10 + if_else(A == "A2", -1.2, 0) + if_else(B == "B2", 2.1, 0) + if_else(C == "C2", 1.1, 0) + rnorm(n(), 0, 1.5)
    ) |>
    as.data.frame()
}





