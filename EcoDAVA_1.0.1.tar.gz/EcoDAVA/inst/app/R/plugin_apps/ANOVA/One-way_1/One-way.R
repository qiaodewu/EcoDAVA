library(shiny)
library(tidyverse)
library(agricolae)
library(ggpubr)
library(car)

ui <- fluidPage(
  titlePanel("One-Way ANOVA & Multiple Comparisons Batch Tools"),
  sidebarLayout(
    # ============ Fix：widthwritten incolumn() within ============
    sidebarPanel(
      column(width = 12,
             # 1. DataUpload
             fileInput("file", "Upload CSV data file",
                       accept = c(".csv")),
             h5("Data format: The first line is column name, one column is grouping variable, and multiple columns are numerical response variables."),
             hr(),
             # Variable selection
             uiOutput("select_group"),
             uiOutput("select_response"),
             hr(),
             # Multiple comparison methodSelect
             selectInput("mult_method", "Multiple comparison method",
                         choices = c("TukeyHSD" = "tukey",
                                     "LSD method" = "lsd",
                                     "Duncan's method" = "duncan",
                                     "SNK method" = "snk"),
                         selected = "tukey"),
             actionButton("run_analysis", "Perform analysis", class = "btn-primary"),
             hr(),
             downloadButton("download_plot", "Download image")
      )
    ),
    mainPanel(
      column(width = 12,
             tabsetPanel(
               tabPanel("Data preview", tableOutput("data_preview")),
               tabPanel("Analysis formula", verbatimTextOutput("formula_text")),
               tabPanel("ANOVA analysis of variance table", tableOutput("anova_table")),
               tabPanel("Multiple comparison results", tableOutput("multcomp_table")),
               tabPanel("Box plot (including significant letters)", plotOutput("box_plot", height = "700px"))
             )
      )
    )
  )
)

server <- function(input, output, session) {
  
  # ReadData
  df_raw <- reactive({
    req(input$file)
    read.csv(input$file$datapath, header = TRUE, stringsAsFactors = FALSE)
  })
  
  # UIUpdatesSelectControl
  output$select_group <- renderUI({
    req(df_raw())
    vars <- colnames(df_raw())
    selectInput("group_var", "Grouping factor (independent variable)", choices = vars)
  })
  
  output$select_response <- renderUI({
    req(df_raw(), input$group_var)
    all_vars <- colnames(df_raw())
    num_vars <- all_vars[all_vars != input$group_var]
    checkboxGroupInput("resp_vars", "Select response variables (multiple selections for batch analysis are available)",
                       choices = num_vars, selected = num_vars[1])
  })
  
  # StorageResults
  res_list <- reactiveValues()
  
  observeEvent(input$run_analysis, {
    req(df_raw(), input$group_var, input$resp_vars)
    progress <- dava_progress(session, min = 0, max = 1)
    on.exit(progress$close(), add = TRUE)
    progress$set(message = "Run one-way ANOVA", detail = "Prepare data and grouping variables", value = 0.1)
    dat <- df_raw()
    group_col <- input$group_var
    
    # GroupingConvert to factor
    dat[[group_col]] <- as.factor(dat[[group_col]])
    
    all_anova <- list()
    all_multcomp <- list()
    all_plot_data <- list()
    
    for(i in seq_along(input$resp_vars)){
      resp <- input$resp_vars[[i]]
      progress$set(detail = paste("Analyze response variables:", resp),
                   value = 0.15 + 0.7 * (i - 1) / length(input$resp_vars))
      fml <- as.formula(paste0(resp, " ~ ", group_col))
      
      # 1. ANOVA
      fit_aov <- aov(fml, data = dat)
      anova_tab <- as.data.frame(anova(fit_aov))
      anova_tab$Term <- rownames(anova_tab)
      anova_tab <- relocate(anova_tab, Term)
      
      # 2. Multiple comparisons
      method <- input$mult_method
      if(method == "tukey"){
        mult <- TukeyHSD(fit_aov)
        mult_df <- as.data.frame(mult[[1]])
        mult_df$Comparison <- rownames(mult_df)
      }else{
        mult <- LSD.test(fit_aov, group_col, p.adj = method)
        mult_df <- mult$groups
        mult_df$Group <- rownames(mult_df)
      }
      
      all_anova[[resp]] <- list(formula = fml, anova = anova_tab, fit = fit_aov)
      all_multcomp[[resp]] <- mult_df
      
      # SaveDrawingmarked with letters
      if(method != "tukey"){
        all_plot_data[[resp]] <- mult$groups
      }
    }
    
    res_list$anova_result <- all_anova
    res_list$mult_result <- all_multcomp
    res_list$plot_info <- all_plot_data
    res_list$group_name <- group_col
    res_list$data <- dat
    progress$set(detail = "One-way analysis of variance completed", value = 1)
  })
  
  # Data preview
  output$data_preview <- renderTable({
    req(df_raw())
    head(df_raw(), 15)
  })
  
  # Show formula
  output$formula_text <- renderPrint({
    req(res_list$anova_result)
    for(x in names(res_list$anova_result)){
      cat(x, ": ", deparse(res_list$anova_result[[x]]$formula), "\n")
    }
  })
  
  # ANOVAResultsMerge display
  output$anova_table <- renderTable({
    req(res_list$anova_result)
    out_tb <- data.frame()
    for(varname in names(res_list$anova_result)){
      tmp <- res_list$anova_result[[varname]]$anova
      tmp$Response_Variable <- varname
      out_tb <- bind_rows(out_tb, tmp)
    }
    out_tb %>% relocate(Response_Variable)
  }, digits = 4)
  
  # Multiple comparisonsform
  output$multcomp_table <- renderTable({
    req(res_list$mult_result)
    out_tb <- data.frame()
    for(varname in names(res_list$mult_result)){
      tmp <- res_list$mult_result[[varname]]
      tmp$Response_Variable <- varname
      out_tb <- bind_rows(out_tb, tmp)
    }
    out_tb
  }, digits = 4)
  
  # Boxplot
  output$box_plot <- renderPlot({
    req(res_list$anova_result, input$resp_vars)
    dat <- res_list$data
    group_col <- res_list$group_name
    vars <- input$resp_vars
    
    plot_list <- list()
    for(i in seq_along(vars)){
      resp <- vars[i]
      p <- ggboxplot(dat, x = group_col, y = resp, fill = group_col) +
        rotate_x_text(30) +
        labs(y = resp, x = group_col) +
        theme_bw() +
        theme(legend.position = "none")
      
      # AddMultiple comparisonsletter mark（LSD/Duncan/SNKSupport；TukeyNoneAutomaticletters，Show pictures only）
      if(input$mult_method != "tukey"){
        letter_info <- res_list$plot_info[[resp]]
        letter_info[[group_col]] <- rownames(letter_info)
        p <- p + stat_summary(data = letter_info,
                              fun = max, geom = "text",
                              aes(label = groups, y = resp),
                              vjust = -0.3, size = 4)
      }
      plot_list[[i]] <- p
    }
    ggarrange(plotlist = plot_list, ncol = 2, align = "hv")
  })
  
  # Image download
  output$download_plot <- downloadHandler(
    filename = function(){"anova_boxplot.pdf"},
    content = function(file){
      dat <- res_list$data
      group_col <- res_list$group_name
      vars <- input$resp_vars
      
      plot_list <- list()
      for(i in seq_along(vars)){
        resp <- vars[i]
        p <- ggboxplot(dat, x = group_col, y = resp, fill = group_col) +
          rotate_x_text(30) +
          labs(y = resp, x = group_col) +
          theme_bw() +
          theme(legend.position = "none")
        
        if(input$mult_method != "tukey"){
          letter_info <- res_list$plot_info[[resp]]
          letter_info[[group_col]] <- rownames(letter_info)
          p <- p + stat_summary(data = letter_info,
                                fun = max, geom = "text",
                                aes(label = groups),
                                vjust = -0.3, size = 4)
        }
        plot_list[[i]] <- p
      }
      final_plot <- ggarrange(plotlist = plot_list, ncol = 2, align = "hv")
      ggsave(file, plot = final_plot, width = 14, height = 9, device = "pdf")
    }
  )
}

shinyApp(ui, server)
