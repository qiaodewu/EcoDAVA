# DAVA interface internationalisation ---------------------------------------
#
# The translation layer is deliberately kept outside analysis modules. It
# changes rendered interface text only; inputs, values, data, formulas and
# reactive dependencies remain untouched.

dava_i18n_dependency <- function() {
  htmltools::tagList(
    htmltools::tags$script(htmltools::HTML("(function () {
      var supported = ['en', 'zh-CN', 'zh-TW', 'ja', 'es'];
      var stored = null;
      try { stored = window.localStorage.getItem('dava.interface.language'); } catch (error) {}
      var language = supported.indexOf(stored) >= 0 ? stored : 'en';
      document.documentElement.lang = language;
      document.documentElement.setAttribute('data-dava-language', language);
    })();")),
    htmltools::tags$link(
      rel = "stylesheet", type = "text/css", href = "dava_i18n.css?v=20260909-5"
    ),
      htmltools::tags$script(src = "dava_i18n.js?v=20260909-6", defer = NA)
  )
}

.dava_i18n_state <- new.env(parent = emptyenv())

dava_i18n_language <- function(language = NULL) {
  language <- as.character(language %||% "en")[[1L]]
  if (!language %in% c("en", "zh-CN", "zh-TW", "ja", "es")) "en" else language
}

dava_i18n_catalog_path <- function() {
  candidates <- unique(normalizePath(c(
    file.path(getwd(), "www", "dava_i18n_catalog.json"),
    file.path(getwd(), "inst", "app", "www", "dava_i18n_catalog.json"),
    tryCatch(system.file("app", "www", "dava_i18n_catalog.json", package = "DAVA"), error = function(error) "")
  ), winslash = "/", mustWork = FALSE))
  candidates[file.exists(candidates)][1L] %||% ""
}

dava_i18n_catalog <- function() {
  if (!is.null(.dava_i18n_state$catalog)) return(.dava_i18n_state$catalog)
  path <- dava_i18n_catalog_path()
  if (!nzchar(path) || !requireNamespace("jsonlite", quietly = TRUE)) {
    .dava_i18n_state$catalog <- list()
    return(.dava_i18n_state$catalog)
  }
  payload <- tryCatch(jsonlite::fromJSON(path, simplifyVector = FALSE), error = function(error) list())
  .dava_i18n_state$catalog <- payload$messages %||% list()
  .dava_i18n_state$catalog
}

dava_translate_text <- function(text, language = "en", protected = character(), compose = TRUE) {
  if (is.null(text) || !length(text)) return(text)
  language <- dava_i18n_language(language)
  catalog <- dava_i18n_catalog()
  protected <- unique(as.character(protected %||% character()))
  translate_one <- function(value) {
    if (is.na(value) || !nzchar(value) || value %in% protected) return(value)
    if (grepl("^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][+-]?[0-9]+)?%?$", trimws(value))) return(value)
    entry <- catalog[[value]]
    if (!is.null(entry)) {
      translated <- as.character(entry[[language]] %||% entry$en %||% value)[[1L]]
      if (nzchar(translated)) return(translated)
    }
    if (!isTRUE(compose) || !length(catalog)) return(value)
    keys <- names(catalog)
    keys <- keys[nchar(keys) >= 2L & nchar(keys) < nchar(value)]
    keys <- keys[startsWith(value, keys) | endsWith(value, keys)]
    if (!length(keys)) return(value)
    key <- keys[which.max(nchar(keys))]
    translated <- dava_translate_text(key, language, protected, compose = FALSE)
    if (startsWith(value, key)) paste0(translated, substring(value, nchar(key) + 1L))
    else paste0(substr(value, 1L, nchar(value) - nchar(key)), translated)
  }
  translated <- vapply(as.character(text), translate_one, character(1), USE.NAMES = FALSE)
  attributes(translated) <- attributes(text)
  translated
}

dava_tr <- function(key, language = "en", ..., protected = character()) {
  template <- dava_translate_text(
    key, language = language, protected = protected, compose = FALSE
  )
  if (!length(list(...))) return(template)
  sprintf(template, ...)
}

# Mark a select control whose option labels are scientific/package vocabulary
# and must remain stable when the interface language changes.
dava_i18n_preserve_choice_language <- function(control) {
  tagged <- tryCatch(
    htmltools::tagQuery(control)$find("select")$
      addAttrs(`data-dava-i18n-role` = "stable-choice")$allTags(),
    error = function(error) control
  )
  shiny::div(`data-dava-i18n-role` = "stable-choice", tagged)
}

# Translate registered DAVA phrases inside an application-generated sentence.
# Unknown fragments (for example a user data-frame name) are copied verbatim.
dava_translate_composed <- function(text, language = "en", protected = character()) {
  if (is.null(text) || !length(text)) return(text)
  language <- dava_i18n_language(language)
  catalog <- dava_i18n_catalog()
  protected <- unique(as.character(protected %||% character()))
  translate_one <- function(value) {
    if (is.na(value) || !nzchar(value) || value %in% protected) return(value)
    exact <- dava_translate_text(value, language, protected, compose = FALSE)
    if (!identical(exact, value)) return(exact)
    keys <- names(catalog)
    keys <- keys[nzchar(keys) & !keys %in% protected]
    keys <- keys[vapply(keys, function(key) grepl(key, value, fixed = TRUE), logical(1))]
    if (!length(keys)) return(value)
    keys <- keys[order(nchar(keys), decreasing = TRUE)]
    occupied <- rep(FALSE, nchar(value))
    replacements <- list()
    for (key in keys) {
      positions <- gregexpr(key, value, fixed = TRUE)[[1L]]
      if (identical(positions, -1L)) next
      for (position in positions) {
        cells <- position:(position + nchar(key) - 1L)
        if (any(occupied[cells])) next
        occupied[cells] <- TRUE
        replacements[[length(replacements) + 1L]] <- list(
          start = position, end = position + nchar(key) - 1L,
          value = dava_translate_text(key, language, protected, compose = FALSE)
        )
      }
    }
    if (!length(replacements)) return(value)
    replacements <- replacements[order(vapply(replacements, `[[`, numeric(1), "start"))]
    cursor <- 1L
    pieces <- character()
    for (replacement in replacements) {
      if (replacement$start > cursor) {
        pieces <- c(pieces, substr(value, cursor, replacement$start - 1L))
      }
      pieces <- c(pieces, replacement$value)
      cursor <- replacement$end + 1L
    }
    if (cursor <= nchar(value)) pieces <- c(pieces, substr(value, cursor, nchar(value)))
    paste0(pieces, collapse = "")
  }
  translated <- vapply(as.character(text), translate_one, character(1), USE.NAMES = FALSE)
  attributes(translated) <- attributes(text)
  translated
}

dava_user_data_text <- function(data, include_values = TRUE, max_values = 2000L) {
  if (is.null(data)) return(character())
  if (is.matrix(data)) data <- as.data.frame(data, check.names = FALSE)
  if (!is.data.frame(data)) return(character())
  protected <- c(names(data), rownames(data))
  if (isTRUE(include_values)) {
    categorical <- data[vapply(data, function(column) {
      is.character(column) || is.factor(column) || is.ordered(column)
    }, logical(1))]
    values <- unique(as.character(unlist(categorical, use.names = FALSE)))
    values <- values[!is.na(values) & nzchar(values)]
    protected <- c(protected, utils::head(values, max_values))
  }
  unique(protected[!is.na(protected) & nzchar(protected)])
}

dava_localize_model_text <- function(text, language = "en", protected = character()) {
  # Analysis output is scientific evidence, not interface chrome. Preserve the
  # exact text emitted by R and its packages regardless of interface language.
  text
}

dava_localize_message_table <- function(table, language = "en",
    protected = character()) {
  # Keep diagnostic/error/result tables byte-for-byte stable. Column names and
  # values are part of the output and may be referenced in reports or scripts.
  table
}

dava_localize_plot <- function(plot, language = "en", protected = character()) {
  # Plot labels, legends and annotations are analysis output too.
  plot
}

dava_localize_r_comments <- function(code, language = "en") {
  # R/R Markdown source, including comments, must remain reproducible.
  code
}
