# DAVA interface internationalisation ---------------------------------------
#
# The translation layer is deliberately kept outside analysis modules. It
# changes rendered interface text only; inputs, values, data, formulas and
# reactive dependencies remain untouched.

dava_i18n_dependency <- function() {
  htmltools::tagList(
    htmltools::tags$script(htmltools::HTML("(function () {
      var supported = ['en', 'zh-CN', 'zh-TW', 'ja', 'es'];
      var stored = null;
      try { stored = window.localStorage.getItem('dava.interface.language'); } catch (error) {}
      var language = supported.indexOf(stored) >= 0 ? stored : 'en';
      document.documentElement.lang = language;
      document.documentElement.setAttribute('data-dava-language', language);
    })();")),
    htmltools::tags$link(
      rel = "stylesheet", type = "text/css", href = "dava_i18n.css?v=20260909-5"
    ),
      htmltools::tags$script(src = "dava_i18n.js?v=20260921-1", defer = NA)
  )
}

.dava_i18n_state <- new.env(parent = emptyenv())

# Translate progress at the server boundary, including later callbacks outside
# reactive consumers. Scientific values can be explicitly protected.
dava_progress_text <- function(text, session = shiny::getDefaultReactiveDomain(), protected = character()) {
  language <- tryCatch(shiny::isolate(session$rootScope()$input$dava_interface_language),
    error = function(e) "en")
  language <- dava_i18n_language(language)
  # Progress labels are often assembled from a translated action and a
  # method-specific label. Translate complete phases first so they cannot
  # become mixed-language strings after fragment replacement.
  progress_phrases <- list(
    "\u6267\u884c\u7edf\u8ba1\u68c0\u9a8c\u4e0e\u591a\u91cd\u6bd4\u8f83" = c(en = "Run statistical tests and multiple comparisons",
      `zh-CN` = "\u6267\u884c\u7edf\u8ba1\u68c0\u9a8c\u4e0e\u591a\u91cd\u6bd4\u8f83", `zh-TW` = "\u57f7\u884c\u7d71\u8a08\u6aa2\u9a57\u8207\u591a\u91cd\u6bd4\u8f03",
      ja = "\u7d71\u8a08\u691c\u5b9a\u3068\u591a\u91cd\u6bd4\u8f03\u3092\u5b9f\u884c", es = "Ejecutar pruebas estad\u00edsticas y comparaciones m\u00faltiples"),
    "\u6574\u7406\u5206\u6790\u7ed3\u679c" = c(en = "Organize analysis results", `zh-CN` = "\u6574\u7406\u5206\u6790\u7ed3\u679c",
      `zh-TW` = "\u6574\u7406\u5206\u6790\u7d50\u679c", ja = "\u89e3\u6790\u7d50\u679c\u3092\u6574\u7406", es = "Organizar los resultados del an\u00e1lisis"),
    "\u51c6\u5907\u53d8\u91cf\u4e0e\u53d8\u6362\u6570\u636e" = c(en = "Prepare variables and transformed data", `zh-CN` = "\u51c6\u5907\u53d8\u91cf\u4e0e\u53d8\u6362\u6570\u636e",
      `zh-TW` = "\u6e96\u5099\u8b8a\u6578\u8207\u8f49\u63db\u8cc7\u6599", ja = "\u5909\u6570\u3068\u5909\u63db\u30c7\u30fc\u30bf\u3092\u6e96\u5099", es = "Preparar variables y datos transformados"),
    "\u9010\u4e00\u8fd0\u884c\u54cd\u5e94\u53d8\u91cf\u8bca\u65ad" = c(en = "Run diagnostics for each response variable", `zh-CN` = "\u9010\u4e00\u8fd0\u884c\u54cd\u5e94\u53d8\u91cf\u8bca\u65ad",
      `zh-TW` = "\u9010\u4e00\u57f7\u884c\u53cd\u61c9\u8b8a\u6578\u8a3a\u65b7", ja = "\u5fdc\u7b54\u5909\u6570\u3054\u3068\u306e\u8a3a\u65ad\u3092\u5b9f\u884c", es = "Ejecutar diagn\u00f3sticos para cada variable de respuesta"),
    "\u6574\u7406\u68c0\u9a8c\u7ed3\u679c\u4e0e\u8bca\u65ad\u6570\u636e" = c(en = "Organize test results and diagnostic data", `zh-CN` = "\u6574\u7406\u68c0\u9a8c\u7ed3\u679c\u4e0e\u8bca\u65ad\u6570\u636e",
      `zh-TW` = "\u6574\u7406\u6aa2\u9a57\u7d50\u679c\u8207\u8a3a\u65b7\u8cc7\u6599", ja = "\u691c\u5b9a\u7d50\u679c\u3068\u8a3a\u65ad\u30c7\u30fc\u30bf\u3092\u6574\u7406", es = "Organizar resultados de pruebas y datos diagn\u00f3sticos"),
    "\u68c0\u67e5\u6a21\u578b\u3001\u56fa\u5b9a\u6548\u5e94\u4e0e\u968f\u673a\u6548\u5e94" = c(en = "Check the model, fixed effects and random effects", `zh-CN` = "\u68c0\u67e5\u6a21\u578b\u3001\u56fa\u5b9a\u6548\u5e94\u4e0e\u968f\u673a\u6548\u5e94",
      `zh-TW` = "\u6aa2\u67e5\u6a21\u578b\u3001\u56fa\u5b9a\u6548\u61c9\u8207\u96a8\u6a5f\u6548\u61c9", ja = "\u30e2\u30c7\u30eb\u3001\u56fa\u5b9a\u52b9\u679c\u3001\u30e9\u30f3\u30c0\u30e0\u52b9\u679c\u3092\u78ba\u8a8d", es = "Comprobar el modelo, los efectos fijos y aleatorios"),
    "\u9010\u4e00\u62df\u5408\u54cd\u5e94\u53d8\u91cf\u6a21\u578b" = c(en = "Fit a model for each response variable", `zh-CN` = "\u9010\u4e00\u62df\u5408\u54cd\u5e94\u53d8\u91cf\u6a21\u578b",
      `zh-TW` = "\u9010\u4e00\u64ec\u5408\u53cd\u61c9\u8b8a\u6578\u6a21\u578b", ja = "\u5fdc\u7b54\u5909\u6570\u3054\u3068\u306b\u30e2\u30c7\u30eb\u3092\u9069\u5408", es = "Ajustar un modelo para cada variable de respuesta"),
    "\u8ba1\u7b97\u663e\u8457\u6027\u4e0e\u4e8b\u540e\u591a\u91cd\u6bd4\u8f83" = c(en = "Calculate significance and post-hoc multiple comparisons", `zh-CN` = "\u8ba1\u7b97\u663e\u8457\u6027\u4e0e\u4e8b\u540e\u591a\u91cd\u6bd4\u8f83",
      `zh-TW` = "\u8a08\u7b97\u986f\u8457\u6027\u8207\u4e8b\u5f8c\u591a\u91cd\u6bd4\u8f03", ja = "\u6709\u610f\u6027\u3068\u4e8b\u5f8c\u591a\u91cd\u6bd4\u8f03\u3092\u8a08\u7b97", es = "Calcular significancia y comparaciones m\u00faltiples post hoc"),
    "\u6574\u7406\u7ed3\u679c\u8868\u3001\u6ce8\u91ca\u4e0e\u56fe\u5f62\u6570\u636e" = c(en = "Organize result tables, annotations and plot data", `zh-CN` = "\u6574\u7406\u7ed3\u679c\u8868\u3001\u6ce8\u91ca\u4e0e\u56fe\u5f62\u6570\u636e",
      `zh-TW` = "\u6574\u7406\u7d50\u679c\u8868\u3001\u8a3b\u91cb\u8207\u5716\u5f62\u8cc7\u6599", ja = "\u7d50\u679c\u8868\u3001\u6ce8\u91c8\u3001\u4f5c\u56f3\u30c7\u30fc\u30bf\u3092\u6574\u7406", es = "Organizar tablas, anotaciones y datos de gr\u00e1ficos"),
    "\u68c0\u67e5\u53d8\u91cf\u4e0e\u5206\u7ec4\u8bbe\u7f6e" = c(en = "Check variables and grouping settings", `zh-CN` = "\u68c0\u67e5\u53d8\u91cf\u4e0e\u5206\u7ec4\u8bbe\u7f6e",
      `zh-TW` = "\u6aa2\u67e5\u8b8a\u6578\u8207\u5206\u7d44\u8a2d\u5b9a", ja = "\u5909\u6570\u3068\u30b0\u30eb\u30fc\u30d7\u8a2d\u5b9a\u3092\u78ba\u8a8d", es = "Comprobar variables y configuraci\u00f3n de grupos"),
    "\u8fd0\u884c" = c(en = "Run", `zh-CN` = "\u8fd0\u884c", `zh-TW` = "\u57f7\u884c", ja = "\u5b9f\u884c", es = "Ejecutar")
  )
  translate_progress_fragment <- function(value) {
    translated <- dava_translate_text(value, language, protected, compose = FALSE)
    if (!identical(translated, value)) return(translated)
    if (language != "en") return(dava_translate_composed(value, language, protected))
    translated <- value
    replacements <- c(
      "\u7ebf\u6027\u6df7\u5408\u6548\u5e94\u6a21\u578b" = "Linear Mixed Effects Model",
      "\u5e7f\u4e49\u7ebf\u6027\u6df7\u5408\u6548\u5e94\u6a21\u578b" = "Generalized Linear Mixed Effects Model",
      "\u5b8c\u5168\u968f\u673a\u65b9\u5dee\u5206\u6790" = "Completely Randomized ANOVA",
      "\u968f\u673a\u533a\u7ec4\u65b9\u5dee\u5206\u6790" = "Randomized Block ANOVA",
      "\u91cd\u590d\u6d4b\u91cf\u65b9\u5dee\u5206\u6790" = "Repeated Measures ANOVA",
      "\u5355\u6837\u672c" = "one-sample",
      "\u4e24\u72ec\u7acb\u6837\u672c" = "two independent-samples",
      "\u72ec\u7acb\u6837\u672c" = "independent-samples",
      "\u914d\u5bf9\u6837\u672c" = "paired-samples",
      "\u68c0\u9a8c" = "test",
      "\u65b9\u5dee\u5206\u6790" = "ANOVA"
    )
    for (literal in names(replacements)) {
      translated <- gsub(literal, replacements[[literal]], translated, fixed = TRUE)
    }
    gsub("\\s+", " ", trimws(translated))
  }
  values <- as.character(text)
  for (index in seq_along(values)) {
    value <- values[[index]]
    entry <- progress_phrases[[value]]
    if (!is.null(entry)) {
      values[[index]] <- unname(entry[[language]])
    } else if (language == "en" && startsWith(value, "\u8fd0\u884c")) {
      # Test-method labels historically combine Chinese descriptors with
      # Latin method names. Translate the Chinese fragments as one phrase.
      method_label <- sub("^\u8fd0\u884c\\s*", "", value)
      values[[index]] <- paste("Run", translate_progress_fragment(method_label))
    } else if (language == "en" && grepl("^Run\\s+", value)) {
      method_label <- sub("^Run\\s+", "", value)
      values[[index]] <- paste("Run", translate_progress_fragment(method_label))
    }
  }
  dava_translate_composed(values, language, protected)
}

dava_progress <- function(session = shiny::getDefaultReactiveDomain(), min = 0, max = 1, ...) {
  # R6 methods on shiny::Progress are locked bindings. Keep the native
  # instance untouched and expose a small proxy used by DAVA modules.
  native <- shiny::Progress$new(session, min = min, max = max, ...)
  list(
    set = function(value = NULL, message = NULL, detail = NULL) {
      native$set(value = value, message = dava_progress_text(message, session),
        detail = dava_progress_text(detail, session))
    },
    close = function() native$close()
  )
}

dava_with_progress <- function(expr, message = NULL, detail = NULL, ...,
    session = shiny::getDefaultReactiveDomain()) {
  expression <- substitute(expr)
  caller <- parent.frame()
  shiny::withProgress(eval(expression, caller),
    message = dava_progress_text(message, session), detail = dava_progress_text(detail, session),
    ..., session = session)
}

dava_inc_progress <- function(amount = 0.1, message = NULL, detail = NULL,
    session = shiny::getDefaultReactiveDomain()) {
  shiny::incProgress(amount, message = dava_progress_text(message, session),
    detail = dava_progress_text(detail, session), session = session)
}

dava_i18n_language <- function(language = NULL) {
  language <- as.character(language %||% "en")[[1L]]
  if (!language %in% c("en", "zh-CN", "zh-TW", "ja", "es")) "en" else language
}

dava_i18n_catalog_path <- function() {
  candidates <- unique(normalizePath(c(
    file.path(getwd(), "www", "dava_i18n_catalog.json"),
    file.path(getwd(), "inst", "app", "www", "dava_i18n_catalog.json"),
    tryCatch(system.file("app", "www", "dava_i18n_catalog.json", package = "EcoDAVA"), error = function(error) "")
  ), winslash = "/", mustWork = FALSE))
  candidates[file.exists(candidates)][1L] %||% ""
}

dava_i18n_catalog <- function() {
  if (!is.null(.dava_i18n_state$catalog)) return(.dava_i18n_state$catalog)
  path <- dava_i18n_catalog_path()
  if (!nzchar(path) || !requireNamespace("jsonlite", quietly = TRUE)) {
    .dava_i18n_state$catalog <- list()
    return(.dava_i18n_state$catalog)
  }
  payload <- tryCatch(jsonlite::fromJSON(path, simplifyVector = FALSE), error = function(error) list())
  .dava_i18n_state$catalog <- payload$messages %||% list()
  .dava_i18n_state$catalog
}

dava_translate_text <- function(text, language = "en", protected = character(), compose = TRUE) {
  if (is.null(text) || !length(text)) return(text)
  language <- dava_i18n_language(language)
  catalog <- dava_i18n_catalog()
  protected <- unique(as.character(protected %||% character()))
  translate_one <- function(value) {
    if (is.na(value) || !nzchar(value) || value %in% protected) return(value)
    if (grepl("^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][+-]?[0-9]+)?%?$", trimws(value))) return(value)
    entry <- catalog[[value]]
    if (!is.null(entry)) {
      translated <- as.character(entry[[language]] %||% entry$en %||% value)[[1L]]
      if (nzchar(translated)) return(translated)
    }
    if (!isTRUE(compose) || !length(catalog)) return(value)
    keys <- names(catalog)
    keys <- keys[nchar(keys) >= 2L & nchar(keys) < nchar(value)]
    keys <- keys[startsWith(value, keys) | endsWith(value, keys)]
    if (!length(keys)) return(value)
    key <- keys[which.max(nchar(keys))]
    translated <- dava_translate_text(key, language, protected, compose = FALSE)
    if (startsWith(value, key)) paste0(translated, substring(value, nchar(key) + 1L))
    else paste0(substr(value, 1L, nchar(value) - nchar(key)), translated)
  }
  translated <- vapply(as.character(text), translate_one, character(1), USE.NAMES = FALSE)
  attributes(translated) <- attributes(text)
  translated
}

dava_tr <- function(key, language = "en", ..., protected = character()) {
  template <- dava_translate_text(
    key, language = language, protected = protected, compose = FALSE
  )
  if (!length(list(...))) return(template)
  sprintf(template, ...)
}

# Mark a select control whose option labels are scientific/package vocabulary
# and must remain stable when the interface language changes.
dava_i18n_preserve_choice_language <- function(control) {
  tagged <- tryCatch(
    htmltools::tagQuery(control)$find("select")$
      addAttrs(`data-dava-i18n-role` = "stable-choice")$allTags(),
    error = function(error) control
  )
  shiny::div(`data-dava-i18n-role` = "stable-choice", tagged)
}

# Translate registered DAVA phrases inside an application-generated sentence.
# Unknown fragments (for example a user data-frame name) are copied verbatim.
dava_translate_composed <- function(text, language = "en", protected = character()) {
  if (is.null(text) || !length(text)) return(text)
  language <- dava_i18n_language(language)
  catalog <- dava_i18n_catalog()
  protected <- unique(as.character(protected %||% character()))
  translate_one <- function(value) {
    if (is.na(value) || !nzchar(value) || value %in% protected) return(value)
    exact <- dava_translate_text(value, language, protected, compose = FALSE)
    if (!identical(exact, value)) return(exact)
    keys <- names(catalog)
    keys <- keys[nzchar(keys) & !keys %in% protected]
    keys <- keys[vapply(keys, function(key) grepl(key, value, fixed = TRUE), logical(1))]
    if (!length(keys)) return(value)
    keys <- keys[order(nchar(keys), decreasing = TRUE)]
    occupied <- rep(FALSE, nchar(value))
    for (literal in protected[!is.na(protected) & nzchar(protected)]) {
      positions <- gregexpr(literal, value, fixed = TRUE)[[1L]]
      for (position in positions[positions > 0L]) {
        occupied[position:(position + nchar(literal) - 1L)] <- TRUE
      }
    }
    replacements <- list()
    for (key in keys) {
      positions <- gregexpr(key, value, fixed = TRUE)[[1L]]
      if (identical(positions, -1L)) next
      for (position in positions) {
        cells <- position:(position + nchar(key) - 1L)
        if (any(occupied[cells])) next
        occupied[cells] <- TRUE
        replacements[[length(replacements) + 1L]] <- list(
          start = position, end = position + nchar(key) - 1L,
          value = dava_translate_text(key, language, protected, compose = FALSE)
        )
      }
    }
    if (!length(replacements)) return(value)
    replacements <- replacements[order(vapply(replacements, `[[`, numeric(1), "start"))]
    cursor <- 1L
    pieces <- character()
    for (replacement in replacements) {
      if (replacement$start > cursor) {
        pieces <- c(pieces, substr(value, cursor, replacement$start - 1L))
      }
      pieces <- c(pieces, replacement$value)
      cursor <- replacement$end + 1L
    }
    if (cursor <= nchar(value)) pieces <- c(pieces, substr(value, cursor, nchar(value)))
    paste0(pieces, collapse = "")
  }
  translated <- vapply(as.character(text), translate_one, character(1), USE.NAMES = FALSE)
  attributes(translated) <- attributes(text)
  translated
}

dava_user_data_text <- function(data, include_values = TRUE, max_values = 2000L) {
  if (is.null(data)) return(character())
  if (is.matrix(data)) data <- as.data.frame(data, check.names = FALSE)
  if (!is.data.frame(data)) return(character())
  protected <- c(names(data), rownames(data))
  if (isTRUE(include_values)) {
    categorical <- data[vapply(data, function(column) {
      is.character(column) || is.factor(column) || is.ordered(column)
    }, logical(1))]
    values <- unique(as.character(unlist(categorical, use.names = FALSE)))
    values <- values[!is.na(values) & nzchar(values)]
    protected <- c(protected, utils::head(values, max_values))
  }
  unique(protected[!is.na(protected) & nzchar(protected)])
}

dava_localize_model_text <- function(text, language = "en", protected = character()) {
  if (is.null(text)) return(text)
  vapply(text, function(value) {
    lines <- strsplit(value, "\n", fixed = TRUE)[[1L]]
    paste(dava_translate_composed(lines, language, protected), collapse = "\n")
  }, character(1), USE.NAMES = FALSE)
}

dava_localize_message_table <- function(table, language = "en",
    protected = character()) {
  if (!is.data.frame(table)) return(table)
  message_columns <- intersect(names(table), c("message", "Message", "warning", "Warning",
    "error", "Error", "detail", "details", "status", "suggestion", "recommendation"))
  for (column in message_columns) {
    if (is.character(table[[column]])) table[[column]] <-
      dava_translate_composed(table[[column]], language, protected)
  }
  table
}

dava_localize_plot <- function(plot, language = "en", protected = character()) {
  if (inherits(plot, "ggplot")) {
    for (name in c("title", "subtitle", "caption", "x", "y", "colour", "fill")) {
      value <- plot$labels[[name]]
      if (is.character(value)) plot$labels[[name]] <- dava_translate_text(value, language, protected)
    }
  }
  plot
}

dava_localize_r_comments <- function(code, language = "en") {
  # R/R Markdown source, including comments, must remain reproducible.
  code
}
