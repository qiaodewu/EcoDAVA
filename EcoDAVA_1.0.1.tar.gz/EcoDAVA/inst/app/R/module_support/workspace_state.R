# Versioned DAVA workspace snapshots.

DAVA_WORKSPACE_SCHEMA_VERSION <- "2.0"
DAVA_WORKSPACE_COMPATIBLE_MAJORS <- c("1", "2")

dava_workspace_action_input <- function(name, value) {
  inherits(value, "shinyActionButtonValue")
}

dava_workspace_upload_value <- function(name, value) {
  is.data.frame(value) && "datapath" %in% names(value)
}

dava_workspace_can_serialize <- function(value) {
  if (is.environment(value) || is.function(value) ||
      inherits(value, c("externalptr", "connection", "process", "r_process"))) {
    return(FALSE)
  }
  isTRUE(tryCatch({serialize(value, NULL, version = 3); TRUE},
    error = function(error) FALSE))
}

dava_workspace_input_snapshot <- function(input) {
  values <- if (inherits(input, "reactivevalues")) {
    shiny::isolate(shiny::reactiveValuesToList(input, all.names = TRUE))
  } else if (is.list(input)) input else list()
  if (!length(values)) return(list())
  keep <- vapply(names(values), function(name) {
    value <- values[[name]]
    !dava_workspace_action_input(name, value) &&
      !dava_workspace_upload_value(name, value) &&
      dava_workspace_can_serialize(value)
  }, logical(1))
  values[keep]
}

dava_workspace_shared_state <- function(file_data) {
  values <- shiny::isolate(
    shiny::reactiveValuesToList(file_data, all.names = TRUE))
  excluded <- c(
    "workspace_import_request", "workspace_pending_inputs",
    "workspace_last_saved", "workspace_last_loaded",
    "external_plugin_revision", "workspace_restore_in_progress",
    "workspace_restore_generation", "workspace_restore_phase",
    "workspace_restore_error", "workspace_restore_backup",
    "workspace_restore_backup_missing",
    "workspace_restore_target_registry_version",
    "workspace_restore_required_modules", "workspace_restored_modules",
    "workspace_module_states")
  values <- values[setdiff(names(values), excluded)]
  values[vapply(values, dava_workspace_can_serialize, logical(1))]
}

dava_workspace_package_versions <- function() {
  packages <- loadedNamespaces()
  stats::setNames(vapply(packages, function(package) {
    as.character(utils::packageVersion(package))
  }, character(1)), packages)
}

dava_workspace_plugin_files <- function(
    root = dava_external_plugin_root(), max_bytes = 512 * 1024^2) {
  if (!dir.exists(root)) return(list())
  files <- list.files(root, recursive = TRUE, full.names = TRUE,
    all.files = TRUE, no.. = TRUE, include.dirs = FALSE)
  files <- files[basename(files) != ".dava-plugin-settings.json"]
  if (!length(files)) return(list())
  sizes <- file.info(files)$size
  if (any(!is.finite(sizes)) || sum(sizes) > max_bytes) {
    stop("The total size of external plug-in files exceeds the working environment limit (512 MB).", call. = FALSE)
  }
  root_normalized <- normalizePath(root, winslash = "/", mustWork = TRUE)
  relative <- substring(normalizePath(files, winslash = "/", mustWork = TRUE),
    nchar(root_normalized) + 2L)
  stats::setNames(lapply(seq_along(files), function(index) {
    readBin(files[[index]], what = "raw", n = sizes[[index]])
  }), relative)
}

dava_workspace_restore_plugin_files <- function(files) {
  if (!is.list(files) || !length(files)) return(invisible(character()))
  root <- dava_external_plugin_root(create = TRUE)
  restored <- character(length(files))
  for (index in seq_along(files)) {
    relative <- dava_external_plugin_relative_path(names(files)[[index]],
      allow_empty = FALSE)
    parts <- strsplit(relative, "/", fixed = TRUE)[[1L]]
    target <- do.call(file.path, as.list(c(root, parts)))
    dir.create(dirname(target), recursive = TRUE, showWarnings = FALSE)
    bytes <- files[[index]]
    if (!is.raw(bytes)) stop("The plug-in work environment contains invalid file content.", call. = FALSE)
    connection <- file(target, open = "wb")
    tryCatch(writeBin(bytes, connection),
      finally = if (isOpen(connection)) close(connection))
    restored[[index]] <- target
  }
  invisible(restored)
}

dava_workspace_capture <- function(file_data, input = list(),
                                   current_nav = "", project_root = getwd()) {
  shared_state <- dava_workspace_shared_state(file_data)
  ui_inputs <- dava_workspace_input_snapshot(input)
  if (!isTRUE(shared_state$readOnly) && nzchar(shared_state$active_dataset %||% "")) {
    ui_inputs[["file_manager-select_global_dataset"]] <- shared_state$active_dataset
  }
  if (isTRUE(shared_state$readOnly)) {
    ui_inputs[["file_manager-book_select"]] <- shared_state$active_book %||% ""
    ui_inputs[["file_manager-sheet_select"]] <- shared_state$active_sheet %||% ""
  }
  structure(list(
    schema_version = DAVA_WORKSPACE_SCHEMA_VERSION,
    application = list(
      name = "DAVA",
      saved_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"),
      project_root_name = basename(normalizePath(project_root,
        winslash = "/", mustWork = FALSE)),
      r_version = R.version.string,
      platform = R.version$platform,
      package_versions = dava_workspace_package_versions()),
    navigation = list(current = current_nav %||% ""),
    shared_state = shared_state,
    ui_inputs = ui_inputs,
    module_state = shared_state$workspace_module_states %||%
      shiny::isolate(file_data$workspace_module_states %||% list()),
    random_seed = if (exists(".Random.seed", envir = .GlobalEnv,
      inherits = FALSE)) get(".Random.seed", envir = .GlobalEnv) else NULL,
    external_plugins = list(
      settings = dava_external_plugin_settings(),
      registry = dava_external_plugin_scan()[, c(
        "id", "title", "folder", "relative_dir", "description"), drop = FALSE],
      files = dava_workspace_plugin_files())
  ), class = c("dava_workspace", "list"))
}

dava_workspace_validate <- function(workspace) {
  if (!is.list(workspace) ||
      !identical(workspace$application$name %||% "", "DAVA")) {
    stop("The selected file is not a valid DAVA working environment.", call. = FALSE)
  }
  version <- workspace$schema_version %||% ""
  if (!nzchar(version)) stop("The working environment is missing a format version.", call. = FALSE)
  saved_major <- strsplit(version, ".", fixed = TRUE)[[1L]][[1L]]
  if (!saved_major %in% DAVA_WORKSPACE_COMPATIBLE_MAJORS) {
    stop("The working environment format version is incompatible:", version, call. = FALSE)
  }
  if (!is.list(workspace$shared_state) || !is.list(workspace$ui_inputs)) {
    stop("The work environment is missing shared state or interface settings.", call. = FALSE)
  }
  invisible(TRUE)
}

dava_workspace_file_name <- function(name) {
  name <- trimws(as.character(name %||% "")[[1L]])
  name <- sub("\\.davaws$", "", name, ignore.case = TRUE)
  name <- gsub('[<>:"/\\\\|?*[:cntrl:]]+', "_", name, perl = TRUE)
  name <- gsub("[. ]+$", "", name)
  if (!nzchar(name)) name <- paste0("DAVA_workspace_", format(Sys.time(), "%Y%m%d_%H%M%S"))
  paste0(name, ".davaws")
}

dava_workspace_save <- function(workspace, path) {
  dava_workspace_validate(workspace)
  directory <- dirname(path)
  if (!dir.exists(directory) && !dir.create(directory, recursive = TRUE,
      showWarnings = FALSE)) {
    stop("Unable to create working environment save directory.", call. = FALSE)
  }
  temporary <- tempfile(".dava-workspace-", tmpdir = directory)
  on.exit(if (file.exists(temporary)) unlink(temporary, force = TRUE), add = TRUE)
  saveRDS(workspace, temporary, version = 3, compress = "gzip")
  if (file.exists(path) && !file.remove(path)) {
    stop("Unable to overwrite existing work environment files.", call. = FALSE)
  }
  if (!file.rename(temporary, path)) {
    if (!file.copy(temporary, path, overwrite = TRUE)) {
      stop("Unable to complete work environment file write.", call. = FALSE)
    }
    unlink(temporary, force = TRUE)
  }
  normalizePath(path, winslash = "/", mustWork = TRUE)
}

dava_workspace_read <- function(path) {
  workspace <- tryCatch(readRDS(path), error = function(error) {
    stop("Unable to read working environment:", conditionMessage(error), call. = FALSE)
  })
  dava_workspace_validate(workspace)
  workspace
}

dava_workspace_restore_shared <- function(file_data, workspace) {
  dava_workspace_validate(workspace)
  target_state <- workspace$shared_state
  if (!is.list(target_state)) stop("The work environment sharing status is invalid.", call. = FALSE)
  previous_generation <- shiny::isolate(as.integer(
    file_data$workspace_restore_generation %||% 0L))
  backup_names <- unique(c(names(target_state), "file_library",
    "workspace_module_states", "data_registry_version"))
  current_state <- shiny::isolate(shiny::reactiveValuesToList(
    file_data, all.names = TRUE))
  backup_missing <- setdiff(backup_names, names(current_state))
  backup_names <- intersect(backup_names, names(current_state))
  backup <- current_state[backup_names]
  file_data$workspace_restore_in_progress <- TRUE
  file_data$workspace_restore_generation <- previous_generation + 1L
  file_data$workspace_restore_phase <- "prepare"
  file_data$workspace_restore_error <- ""
  file_data$workspace_restore_backup <- backup
  file_data$workspace_restore_backup_missing <- backup_missing
  file_data$workspace_restore_target_registry_version <- as.integer(
    target_state$data_registry_version %||% 0L)
  completed <- FALSE
  on.exit({
    if (!completed) dava_workspace_abort_restore(
      file_data, previous_generation + 1L, rollback = TRUE)
  }, add = TRUE)
  file_data$workspace_restore_phase <- "shared"
  for (name in names(target_state)) {
    if (identical(name, "data_registry_version")) next
    file_data[[name]] <- target_state[[name]]
  }
  file_data$file_library <- list(
    books = target_state$books %||% list(),
    global_datasets = target_state$global_datasets %||% list(),
    book_sources = target_state$book_sources %||% list(),
    dataset_sources = target_state$dataset_sources %||% list(),
    active_book = target_state$active_book %||% NULL,
    active_sheet = target_state$active_sheet %||% NULL,
    active_dataset = target_state$active_dataset %||% NULL,
    readOnly = isTRUE(target_state$readOnly)
  )
  file_data$workspace_pending_inputs <- workspace$ui_inputs
  file_data$workspace_module_states <- workspace$module_state %||%
    target_state$workspace_module_states %||% list()
  file_data$workspace_restore_required_modules <- unique(
    target_state$workspace_loaded_modules %||% character())
  file_data$workspace_restored_modules <- character()
  file_data$workspace_restore_phase <- "modules"
  file_data$workspace_last_loaded <- workspace$application$saved_at %||% ""
  if (!is.null(workspace$external_plugins$settings)) {
    dava_workspace_restore_plugin_files(workspace$external_plugins$files %||% list())
    dava_external_plugin_save_settings(workspace$external_plugins$settings)
    file_data$external_plugin_revision <- shiny::isolate(
      as.integer(file_data$external_plugin_revision %||% 0L) + 1L)
  }
  if (!is.null(workspace$random_seed)) {
    assign(".Random.seed", workspace$random_seed, envir = .GlobalEnv)
  }
  completed <- TRUE
  invisible(workspace)
}

dava_workspace_restore_matches <- function(file_data, generation) {
  identical(
    shiny::isolate(file_data$workspace_restore_generation %||% 0L),
    generation)
}

dava_workspace_finalize_restore <- function(file_data, generation = NULL,
                                              clear_pending = TRUE) {
  if (!is.null(generation) &&
      !dava_workspace_restore_matches(file_data, generation)) {
    return(invisible(FALSE))
  }
  if (!isTRUE(shiny::isolate(
      file_data$workspace_restore_in_progress %||% FALSE))) {
    return(invisible(FALSE))
  }
  file_data$workspace_restore_phase <- "commit"
  saved_version <- shiny::isolate(as.integer(
    file_data$data_registry_version %||% 0L))
  backup_version <- shiny::isolate(as.integer(
    file_data$workspace_restore_backup$data_registry_version %||% 0L))
  target_version <- shiny::isolate(as.integer(
    file_data$workspace_restore_target_registry_version %||% 0L))
  file_data$data_registry_version <- max(
    saved_version, backup_version, target_version) + 1L
  if (isTRUE(clear_pending)) file_data$workspace_pending_inputs <- list()
  file_data$workspace_restore_backup <- NULL
  file_data$workspace_restore_backup_missing <- NULL
  file_data$workspace_restore_target_registry_version <- NULL
  file_data$workspace_restore_in_progress <- FALSE
  file_data$workspace_restore_phase <- "idle"
  invisible(TRUE)
}

dava_workspace_abort_restore <- function(file_data, generation = NULL,
                                           rollback = FALSE, error = "") {
  if (!is.null(generation) &&
      !dava_workspace_restore_matches(file_data, generation)) {
    return(invisible(FALSE))
  }
  if (isTRUE(rollback)) {
    backup <- shiny::isolate(file_data$workspace_restore_backup %||% list())
    missing <- shiny::isolate(
      file_data$workspace_restore_backup_missing %||% character())
    for (name in names(backup)[!is.na(names(backup)) & nzchar(names(backup))]) {
      file_data[[name]] <- backup[[name]]
    }
    for (name in missing[!is.na(missing) & nzchar(missing)]) {
      file_data[[name]] <- NULL
    }
  }
  file_data$workspace_restore_error <- as.character(error %||% "")
  file_data$workspace_restore_backup <- NULL
  file_data$workspace_restore_backup_missing <- NULL
  file_data$workspace_restore_target_registry_version <- NULL
  file_data$workspace_restore_in_progress <- FALSE
  file_data$workspace_restore_phase <- "idle"
  invisible(TRUE)
}

dava_workspace_inputs_for_prefixes <- function(values, prefixes = character(),
                                                 include_top_level = FALSE) {
  if (!is.list(values) || !length(values)) return(list())
  ids <- names(values)
  prefixes <- unique(sub("-+$", "", as.character(prefixes %||% character())))
  selected <- rep(FALSE, length(ids))
  if (length(prefixes)) {
    selected <- vapply(ids, function(id) any(startsWith(
      id, paste0(prefixes, "-"))), logical(1))
  }
  if (isTRUE(include_top_level)) selected <- selected | !grepl("-", ids, fixed = TRUE)
  values[selected]
}

dava_workspace_mark_inputs_restored <- function(file_data, ids, generation) {
  if (!dava_workspace_restore_matches(file_data, generation)) {
    return(invisible(FALSE))
  }
  pending <- shiny::isolate(file_data$workspace_pending_inputs %||% list())
  file_data$workspace_pending_inputs <- pending[setdiff(names(pending), ids)]
  invisible(TRUE)
}

dava_workspace_restore_script <- function() {
  shiny::tags$script(shiny::HTML("\n(function(){
  if (window.davaWorkspaceRestoreReady) return;
  window.davaWorkspaceRestoreReady = true;
  function trigger(el){
    el.dispatchEvent(new Event('input', {bubbles:true}));
    el.dispatchEvent(new Event('change', {bubbles:true}));
  }
  Shiny.addCustomMessageHandler('dava-restore-inputs', function(message){
    var values = (message && message.values) || {};
    var generation = (message && message.generation) || 0;
    window.davaWorkspaceRestoreGeneration = Math.max(
      window.davaWorkspaceRestoreGeneration || 0, generation);
    if (generation < window.davaWorkspaceRestoreGeneration) return;
    window.davaWorkspaceRestoredInputs =
      window.davaWorkspaceRestoredInputs || {};
    if (!window.davaWorkspaceRestoredInputs[generation])
      window.davaWorkspaceRestoredInputs[generation] = {};
    var restored = window.davaWorkspaceRestoredInputs[generation];
    var applied = [];
    Object.keys(values).forEach(function(id){
      if (restored[id]) return;
      var value = values[id];
      var el = document.getElementById(id);
      if (el) {
        if (el.selectize) { el.selectize.setValue(value, false); }
        else if (el.type === 'checkbox') { el.checked = !!value; trigger(el); }
        else if (el.type === 'radio') {
          var radio = document.querySelector('input[name=\"' + CSS.escape(el.name) + '\"][value=\"' + CSS.escape(String(value)) + '\"]');
          if (radio) { radio.checked = true; trigger(radio); }
        } else {
          el.value = Array.isArray(value) ? value.join(',') : value;
          trigger(el);
        }
        restored[id] = true;
        applied.push(id);
      }
    });
    if (applied.length) Shiny.setInputValue('dava_workspace_inputs_applied', {
      generation: generation, ids: applied, nonce: Date.now()
    }, {priority:'event'});
  });
  Shiny.addCustomMessageHandler('dava-close-window', function(message){
    try { window.open('', '_self'); window.close(); } catch (error) {}
    setTimeout(function(){
      document.documentElement.innerHTML = '<head><title>DAVA AlreadyExit</title></head><body style=\"font-family:sans-serif;padding:40px\"><h2>DAVA AlreadyExit</h2><p>The server process has ended，YesClosethis window。</p></body>';
    }, 250);
  });
})();\n"))
}
