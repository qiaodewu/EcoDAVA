# Module-level analysis code support. This does not provide a top-level manager.

dava_code_entries <- function(file_data) {
  shiny::isolate(file_data$code_registry %||% list())
}

dava_code_register <- function(file_data, path, code, source = "", title = "",
                               kind = "analysis", language = "R",
                               editable = TRUE, runnable = TRUE, params = list()) {
  if (is.null(file_data) || !nzchar(path %||% "") || !nzchar(code %||% "")) return(invisible(FALSE))
  registry <- shiny::isolate(file_data$code_registry %||% list())
  registry[[path]] <- list(
    path = path,
    code = code,
    source = source %||% "",
    title = title %||% path,
    kind = kind %||% "analysis",
    language = language %||% "R",
    editable = isTRUE(editable),
    runnable = isTRUE(runnable),
    updated = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
    params = params %||% list()
  )
  file_data$code_registry <- registry
  invisible(TRUE)
}

dava_code_registry_table <- function(file_data) {
  registry <- dava_code_entries(file_data)
  if (length(registry) == 0) {
    return(data.frame(path = character(), source = character(), title = character(), kind = character(), language = character(), updated = character()))
  }
  dplyr::bind_rows(lapply(registry, function(x) {
    data.frame(
      path = x$path %||% "",
      source = x$source %||% "",
      title = x$title %||% "",
      kind = x$kind %||% "",
      language = x$language %||% "R",
      editable = isTRUE(x$editable),
      runnable = isTRUE(x$runnable),
      updated = x$updated %||% "",
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))
}

dava_code_get <- function(file_data, path) {
  registry <- dava_code_entries(file_data)
  registry[[path]] %||% NULL
}

dava_code_result_objects <- function(objects, max_object_bytes = 25 * 1024^2,
                                     max_total_bytes = 75 * 1024^2) {
  if (!is.list(objects) || !length(objects)) return(list())
  excluded <- c(dava_code_infrastructure_names(), "analysis_input_data",
    "analysis_context", "analysis_spec", "bundle", "current_dataset_name",
    ".Random.seed")
  objects <- objects[setdiff(names(objects), excluded)]
  keep <- list()
  total <- 0
  for (name in names(objects)) {
    object <- objects[[name]]
    if (is.function(object) || is.environment(object) || inherits(object, "externalptr")) next
    bytes <- tryCatch(as.numeric(utils::object.size(object)), error = function(error) Inf)
    if (!is.finite(bytes) || bytes > max_object_bytes || total + bytes > max_total_bytes) next
    keep[[name]] <- object
    total <- total + bytes
  }
  keep
}

dava_code_result_value <- function(value, max_total_bytes = 75 * 1024^2) {
  if (is.null(value)) return(NULL)
  if (inherits(value, "microbiome_result")) {
    value$model_objects <- list()
    value$runtime_log <- unique(c(
      value$runtime_log %||% character(),
      "[code-document] Large fitted model objects are not persisted; the active custom method reruns the script with current data."
    ))
  }
  bytes <- tryCatch(
    as.numeric(utils::object.size(value)), error = function(error) Inf)
  if (is.finite(bytes) && bytes <= max_total_bytes) return(value)
  if (is.list(value) && !is.data.frame(value)) {
    compact <- dava_code_result_objects(
      value, max_total_bytes = max_total_bytes)
    class(compact) <- class(value)
    bytes <- tryCatch(
      as.numeric(utils::object.size(compact)), error = function(error) Inf)
    if (is.finite(bytes) && bytes <= max_total_bytes) return(compact)
  }
  NULL
}

dava_custom_run_objects <- function(run) {
  if (!is.list(run)) return(list())
  objects <- run$objects %||% list()
  if (!is.null(run$value)) objects <- c(list(.Last.value = run$value), objects)
  objects
}

dava_custom_run_find <- function(run, candidates = character(), predicate = NULL) {
  objects <- dava_custom_run_objects(run)
  if (!length(objects)) return(NULL)
  candidate_names <- unique(c(candidates, names(objects)))
  for (name in candidate_names) {
    object <- objects[[name]]
    if (is.null(object)) next
    if (is.null(predicate) || isTRUE(predicate(object))) return(object)
  }
  NULL
}

dava_custom_run_table <- function(run, candidates = character()) {
  value <- dava_custom_run_find(run, candidates, function(object) {
    is.data.frame(object) || is.matrix(object)
  })
  if (is.matrix(value)) value <- as.data.frame(value, check.names = FALSE)
  value
}

dava_custom_run_plot <- function(run, candidates = character()) {
  value <- run$value %||% NULL
  if (is.list(value) && dava_code_is_plot_object(value$plot %||% NULL)) {
    return(value$plot)
  }
  dava_custom_run_find(run,
    unique(c(candidates, "plot", "p", "final_plot", "importance_plot",
      "shap_importance_plot", "shap_global_plot", ".Last.plot")),
    dava_code_is_plot_object)
}

dava_custom_run_list <- function(run, required = character()) {
  value <- run$value %||% NULL
  if (is.list(value) && all(required %in% names(value))) return(value)
  candidate <- dava_custom_run_find(run,
    c("result", "results", "analysis_result", "fit_result"),
    function(object) is.list(object) && all(required %in% names(object)))
  candidate
}

dava_custom_run_assert <- function(run) {
  if (!is.list(run)) stop("The custom method did not return run records.", call. = FALSE)
  if (!is.null(run$error)) stop(run$error, call. = FALSE)
  invisible(run)
}

dava_code_return_settings_defaults <- function() {
  list(
    policy = "standard",
    allow_file_io = FALSE,
    allow_network = FALSE,
    allow_external_process = FALSE,
    max_runtime_failures = 3L
  )
}

dava_code_return_settings <- function(file_data = NULL) {
  current <- if (is.null(file_data)) list() else {
    shiny::isolate(file_data$code_return_settings %||% list())
  }
  utils::modifyList(dava_code_return_settings_defaults(), current)
}

dava_method_modification_levels <- function() c(
  "Analysis and replacement" = "analysis",
  "Full method (analysis and plotting)" = "full",
  "Drawing replacement" = "plot",
  "Graphic styles only" = "style"
)

dava_method_manifest <- function(method_key, source = "", title = "",
                                 allowed_levels = c("analysis", "full"),
                                 input_schema = "module_context_v1",
                                 result_schema = "module_adapter_v1",
                                 contract_version = "1.0") {
  known_levels <- unname(dava_method_modification_levels())
  allowed_levels <- intersect(unique(allowed_levels), known_levels)
  if (!length(allowed_levels)) allowed_levels <- "full"
  list(
    contract_version = contract_version,
    method_id = dava_method_code_key(method_key),
    source = source %||% "",
    title = title %||% method_key,
    allowed_levels = allowed_levels,
    input_schema = input_schema,
    result_schema = result_schema
  )
}

dava_method_manifest_normalize <- function(manifest, method_key,
                                           source = "", title = "") {
  defaults <- dava_method_manifest(method_key, source, title)
  if (is.function(manifest)) manifest <- manifest()
  if (!is.list(manifest)) manifest <- list()
  value <- utils::modifyList(defaults, manifest)
  value$method_id <- dava_method_code_key(method_key)
  value$allowed_levels <- intersect(
    unique(value$allowed_levels %||% defaults$allowed_levels),
    unname(dava_method_modification_levels()))
  if (!length(value$allowed_levels)) value$allowed_levels <- "full"
  value
}

dava_code_rule_report <- function(code, settings = dava_code_return_settings_defaults()) {
  code <- paste(as.character(code %||% ""), collapse = "\n")
  parsed <- tryCatch(
    parse(text = code, keep.source = FALSE), error = function(error) error)
  issue <- function(severity, rule, message) data.frame(
    severity = severity, rule = rule, message = message,
    stringsAsFactors = FALSE, check.names = FALSE)
  if (inherits(parsed, "error")) {
    return(list(valid = FALSE, issues = issue(
      "error", "parse", conditionMessage(parsed))))
  }
  symbols <- unique(all.names(parsed, functions = TRUE, unique = TRUE))
  issues <- list()
  add <- function(severity, rule, message) {
    issues[[length(issues) + 1L]] <<- issue(severity, rule, message)
  }
  forbidden_calls <- intersect(symbols, c(
    "runApp", "stopApp", "quit", "q", "assignInNamespace",
    "unlockBinding", "install.packages", "update.packages",
    "install_github", "install_git", "install_url", "globalenv"
  ))
  if (length(forbidden_calls)) add(
    "error", "application_state",
    paste0("Disallow calling in method code:", paste(forbidden_calls, collapse = ", "), "。"))
  state_roots <- character()
  walk_state <- function(value) {
    if (!is.call(value) && !is.expression(value) && !is.pairlist(value)) {
      return(invisible(NULL))
    }
    if (is.call(value)) {
      head <- if (is.symbol(value[[1L]])) as.character(value[[1L]]) else ""
      if (head %in% c("$", "[[") && length(value) >= 2L &&
          is.symbol(value[[2L]])) {
        state_roots <<- c(state_roots, as.character(value[[2L]]))
      }
      if (head == "reactiveValuesToList" && length(value) >= 2L &&
          is.symbol(value[[2L]])) {
        state_roots <<- c(state_roots, as.character(value[[2L]]))
      }
    }
    elements <- as.list(value)
    for (index in seq_along(elements)) {
      if (!identical(elements[[index]], quote(expr = ))) {
        walk_state(elements[[index]])
      }
    }
    invisible(NULL)
  }
  walk_state(parsed)
  forbidden_state <- unique(c(
    intersect(state_roots, c("input", "output", "session", "file_data")),
    intersect(symbols, ".GlobalEnv")))
  if (length(forbidden_state)) add(
    "error", "shiny_state",
    paste0("Method code cannot be accessed or modified directly:",
      paste(forbidden_state, collapse = ", "), ". Please use analysis_context/spec."))
  if (any(c("<<-", "->>") %in% symbols)) add(
    "error", "global_assignment", "Use prohibited <<- or ->> Modify the status outside the sandbox。")

  controlled <- list(
    file_io = c(
      "setwd", "unlink", "file.remove", "file.rename", "file.copy",
      "write.csv", "write.table", "writeLines", "save", "saveRDS",
      "read.csv", "read.table", "readRDS", "file", "gzfile"),
    network = c(
      "download.file", "url", "socketConnection", "curl_fetch_memory",
      "GET", "POST"),
    external_process = c(
      "system", "system2", "shell", "shell.exec", "makeCluster",
      "mcparallel")
  )
  setting_names <- c(
    file_io = "allow_file_io", network = "allow_network",
    external_process = "allow_external_process")
  labels <- c(
    file_io = "File reading and writing", network = "Network access",
    external_process = "External process/cluster")
  for (rule in names(controlled)) {
    hits <- intersect(symbols, controlled[[rule]])
    if (!length(hits) || isTRUE(settings[[setting_names[[rule]]]])) next
    severity <- if (identical(settings$policy %||% "standard", "strict")) {
      "error"
    } else {
      "warning"
    }
    add(severity, rule, paste0(
      labels[[rule]], "Not authorized in global postback rule; detected:",
      paste(hits, collapse = ", "), "。"))
  }
  table <- if (length(issues)) do.call(rbind, issues) else data.frame(
    severity = character(), rule = character(), message = character(),
    stringsAsFactors = FALSE, check.names = FALSE)
  list(valid = !any(table$severity == "error"), issues = table)
}

# Per-method custom implementations are session-local and never replace package
# functions. A tested candidate becomes active only after an explicit apply.
dava_method_code_entries <- function(file_data) {
  shiny::isolate(file_data$method_code_overrides %||% list())
}

dava_method_code_key <- function(method_key) {
  key <- trimws(as.character(method_key %||% "")[[1]])
  if (!nzchar(key)) stop("Analysis method identifier cannot be empty.", call. = FALSE)
  key
}

dava_method_code_get <- function(file_data, method_key) {
  dava_method_code_entries(file_data)[[dava_method_code_key(method_key)]] %||% NULL
}

dava_method_code_write <- function(file_data, method_key, entry) {
  key <- dava_method_code_key(method_key)
  registry <- dava_method_code_entries(file_data)
  registry[[key]] <- entry
  file_data$method_code_overrides <- registry
  file_data$method_code_revision <- shiny::isolate(
    as.integer(file_data$method_code_revision %||% 0L) + 1L
  )
  invisible(entry)
}

dava_method_code_write_runtime <- function(file_data, method_key, entry) {
  key <- dava_method_code_key(method_key)
  registry <- dava_method_code_entries(file_data)
  registry[[key]] <- entry
  file_data$method_code_overrides <- registry
  file_data$method_code_runtime_revision <- shiny::isolate(
    as.integer(file_data$method_code_runtime_revision %||% 0L) + 1L
  )
  invisible(entry)
}

dava_method_code_register_original <- function(file_data, method_key, code,
                                                source = "", title = "",
                                                manifest = NULL) {
  key <- dava_method_code_key(method_key)
  entry <- dava_method_code_get(file_data, key) %||% list(
    key = key, custom_code = "", custom_run = NULL,
    custom_validated = FALSE, enabled = FALSE,
    tested = FALSE, tested_code = "", tested_run = NULL,
    test_error = NULL, tested_at = NULL, applied_at = NULL
  )
  entry$key <- key
  next_source <- source %||% entry$source %||% ""
  next_title <- title %||% entry$title %||% key
  next_code <- code %||% ""
  next_manifest <- dava_method_manifest_normalize(
    manifest, key, next_source, next_title)
  if (identical(entry$source %||% "", next_source) &&
      identical(entry$title %||% key, next_title) &&
      identical(entry$original_code %||% "", next_code) &&
      identical(entry$manifest %||% list(), next_manifest) &&
      !isTRUE(entry$enabled) && !isTRUE(entry$custom_validated)) {
    return(invisible(entry))
  }
  entry$source <- next_source
  entry$title <- next_title
  entry$original_code <- next_code
  entry$enabled <- FALSE
  entry$custom_validated <- FALSE
  entry$custom_run <- NULL
  entry$manifest <- next_manifest
  entry$original_updated <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  dava_method_code_write(file_data, key, entry)
}

dava_method_code_record_test <- function(file_data, method_key, code, run,
                                         modification_level = "full",
                                         static_report = NULL,
                                         contract_report = NULL) {
  key <- dava_method_code_key(method_key)
  entry <- dava_method_code_get(file_data, key) %||% list(
    key = key, original_code = "", custom_code = "", custom_run = NULL,
    custom_validated = FALSE, enabled = FALSE, applied_at = NULL
  )
  static_report <- static_report %||% list(valid = TRUE, issues = data.frame())
  contract_report <- contract_report %||% list(valid = TRUE, message = "")
  success <- is.list(run) && is.null(run$error) &&
    isTRUE(static_report$valid) && isTRUE(contract_report$valid)
  entry$tested <- success
  entry$tested_code <- code %||% ""
  entry$tested_run <- if (success) list(
    value = dava_code_result_value(run$value),
    objects = dava_code_result_objects(run$objects %||% list()),
    output = run$output %||% "",
    executed_code = code %||% ""
  ) else NULL
  entry$tested_level <- modification_level %||% "full"
  entry$tested_contract_version <- entry$manifest$contract_version %||% "1.0"
  entry$static_report <- static_report
  entry$contract_report <- contract_report
  entry$test_error <- if (success) NULL else run$error %||%
    contract_report$message %||% "The code did not pass the postback rule or result contract validation."
  entry$tested_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  dava_method_code_write(file_data, key, entry)
}

dava_method_code_apply <- function(file_data, method_key, code = NULL,
                                   modification_level = NULL) {
  key <- dava_method_code_key(method_key)
  entry <- dava_method_code_get(file_data, key)
  if (is.null(entry) || !isTRUE(entry$tested) || is.null(entry$tested_run)) {
    stop("Please run all code successfully in the code document before applying the custom method.", call. = FALSE)
  }
  if (!is.null(code) && !identical(code %||% "", entry$tested_code %||% "")) {
    stop("The current code is inconsistent with the complete script of the last successful test, please re-run the entire code.", call. = FALSE)
  }
  level <- modification_level %||% entry$tested_level %||% "full"
  allowed <- entry$manifest$allowed_levels %||% c("analysis", "full")
  if (!level %in% allowed) {
    stop("This code modification level is not allowed in the current method manifest:", level, call. = FALSE)
  }
  if (!identical(level, entry$tested_level %||% level)) {
    stop("The code modification level has been changed. Please rerun all codes at the current level.", call. = FALSE)
  }
  current_version <- entry$manifest$contract_version %||% "1.0"
  if (!identical(entry$tested_contract_version %||% current_version,
      current_version)) {
    stop("The method contract version has been updated, please retest the custom code.", call. = FALSE)
  }
  entry$custom_code <- entry$tested_code
  entry$custom_run <- entry$tested_run
  entry$custom_validated <- TRUE
  entry$custom_level <- level
  entry$custom_contract_version <- current_version
  entry$enabled <- TRUE
  entry$runtime_failure_count <- 0L
  entry$last_runtime_error <- NULL
  entry$disabled_reason <- NULL
  entry$applied_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  entry$application_error <- NULL
  dava_method_code_write(file_data, key, entry)
}

dava_method_code_disable <- function(file_data, method_key) {
  key <- dava_method_code_key(method_key)
  entry <- dava_method_code_get(file_data, key)
  if (is.null(entry)) return(invisible(FALSE))
  entry$enabled <- FALSE
  entry$disabled_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  dava_method_code_write(file_data, key, entry)
  invisible(TRUE)
}

dava_method_code_enable <- function(file_data, method_key) {
  key <- dava_method_code_key(method_key)
  entry <- dava_method_code_get(file_data, key)
  if (is.null(entry) || !isTRUE(entry$custom_validated) ||
      is.null(entry$custom_run) || !nzchar(entry$custom_code %||% "")) {
    stop("There is no user-defined implementation of this method that has been tested and applied.", call. = FALSE)
  }
  current_version <- entry$manifest$contract_version %||% "1.0"
  if (!identical(entry$custom_contract_version %||% current_version,
      current_version)) {
    stop("The contract version of the custom implementation has expired, please retest on the method page.", call. = FALSE)
  }
  entry$enabled <- TRUE
  entry$runtime_failure_count <- 0L
  entry$last_runtime_error <- NULL
  entry$disabled_reason <- NULL
  entry$applied_at <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  dava_method_code_write(file_data, key, entry)
}

dava_method_code_execute <- function(file_data, method_key, data = NULL,
                                     dataset_name = "", context = NULL,
                                     spec = NULL) {
  key <- dava_method_code_key(method_key)
  entry <- dava_method_code_get(file_data, key)
  if (is.null(entry) || !isTRUE(entry$enabled) ||
      !isTRUE(entry$custom_validated) || !nzchar(entry$custom_code %||% "")) {
    stop("The selected method does not have a valid user-defined implementation enabled.", call. = FALSE)
  }
  env <- dava_code_context(file_data)
  if (!is.null(data)) {
    env$analysis_input_data <- tryCatch(
      as.data.frame(data, stringsAsFactors = FALSE, check.names = FALSE),
      error = function(error) data
    )
    env$df <- env$analysis_input_data
  }
  base_context <- list(data = data, dataset_name = dataset_name %||% "")
  if (is.list(context)) base_context <- utils::modifyList(base_context, context)
  env$analysis_context <- base_context
  for (name in names(base_context)) {
    if (nzchar(name)) assign(name, base_context[[name]], envir = env)
  }
  base_spec <- list(
    method_id = key,
    modification_level = entry$custom_level %||% "full",
    contract_version = entry$manifest$contract_version %||% "1.0")
  if (is.list(spec)) base_spec <- utils::modifyList(base_spec, spec)
  env$analysis_spec <- base_spec
  env$current_dataset_name <- dataset_name %||% ""
  dava_code_run(entry$custom_code, file_data, env = env)
}

dava_method_code_table <- function(file_data) {
  entries <- dava_method_code_entries(file_data)
  if (!length(entries)) return(data.frame(
    method_key = character(), source = character(), title = character(),
    implementation = character(), tested = logical(), enabled = logical(),
    runtime_failures = integer(),
    contract_version = character(), modification_level = character(),
    rule_status = character(), tested_at = character(),
    applied_at = character(), error = character(),
    stringsAsFactors = FALSE, check.names = FALSE
  ))
  dplyr::bind_rows(lapply(entries, function(entry) data.frame(
    method_key = entry$key %||% "",
    source = entry$source %||% "",
    title = entry$title %||% entry$key %||% "",
    implementation = if (isTRUE(entry$enabled)) "User-defined method" else "Original method",
    tested = isTRUE(entry$tested), enabled = isTRUE(entry$enabled),
    runtime_failures = as.integer(entry$runtime_failure_count %||% 0L),
    contract_version = entry$manifest$contract_version %||% "1.0",
    modification_level = entry$custom_level %||% entry$tested_level %||% "",
    rule_status = if (isTRUE(entry$tested) &&
      isTRUE(entry$static_report$valid %||% TRUE) &&
      isTRUE(entry$contract_report$valid %||% TRUE)) "Passed" else "failed",
    tested_at = entry$tested_at %||% "", applied_at = entry$applied_at %||% "",
    error = entry$last_runtime_error %||% entry$test_error %||%
      entry$application_error %||% entry$disabled_reason %||% "",
    stringsAsFactors = FALSE, check.names = FALSE
  )))
}

dava_method_code_effective <- function(original, file_data, method_key, adapter,
                                       on_error = NULL) {
  if (!is.function(original)) stop("original must be a function.", call. = FALSE)
  # Analysis implementations are no longer replaceable from the documentation
  # panel.  Keeping one execution path guarantees that the displayed R Markdown
  # document and the main analysis always describe the same implementation.
  original()
}


dava_code_analysis_spec_from_input <- function(input) {
  snapshot <- shiny::isolate(
    shiny::reactiveValuesToList(input, all.names = TRUE))
  keep <- !grepl(
    "^(module_code_|manager_|plugin_)|(?:^|_)(?:run|download|install|save|copy|refresh|restore|apply)(?:_|$)",
    names(snapshot), ignore.case = TRUE, perl = TRUE)
  values <- snapshot[keep]
  values[vapply(values, function(value) {
    is.atomic(value) && length(value) <= 100L &&
      !inherits(value, c("shinyActionButtonValue", "shiny.tag"))
  }, logical(1))]
}


# Every analysis exposes one read-only rendered R Markdown preview. It is not
# an editor or execution environment; the main analysis remains the only runtime.
dava_module_code_panel_ui <- function(ns) {
  tags$div(
    id = ns("module_code_workspace"),
    class = "dava-rmarkdown-document-panel",
    `data-dava-i18n-role` = "result",
    shiny::uiOutput(ns("module_code_rmd_document"))
  )
}

dava_code_is_plot_object <- function(object) {
  inherits(object, c("ggplot", "grob", "recordedplot", "trellis"))
}


dava_module_code_data_expression <- function(bootstrap_code = NULL,
                                             data_code = NULL,
                                             snapshot_expression = NULL) {
  paste(
    c(bootstrap_code, data_code %||% snapshot_expression),
    collapse = "\n"
  )
}

dava_module_code_panel_server <- function(input, output, session, file_data,
                                          source_prefix, default_code,
                                          source = "module code", title = "R Markdown code document",
                                          kind = "analysis", on_run = NULL,
                                          validate_run = NULL,
                                          plot_params = NULL, data = NULL,
                                          dataset_name = NULL,
                                          context = NULL,
                                          manifest = NULL,
                                          analysis_spec = NULL,
                                          data_code = NULL,
                                          function_mode = c("direct", "closure", "none"),
                                          standalone_bootstrap = TRUE,
                                          include_input_snapshot = FALSE,
                                          code_document_style = c("ols", "legacy"),
                                          preview_result = NULL,
                                          preview_tables = NULL,
                                          preview_plots = NULL,
                                          preview_text = NULL) {
  function_mode <- match.arg(function_mode)
  code_document_style <- match.arg(code_document_style)
  prefix_value <- function() if (is.function(source_prefix)) source_prefix() else source_prefix
  default_code_value <- function() if (is.function(default_code)) default_code() else default_code
  data_value <- function() if (is.function(data)) data() else data
  dataset_name_value <- function() if (is.function(dataset_name)) dataset_name() else dataset_name
  data_code_value <- function() if (is.function(data_code)) data_code() else data_code
  safe_preview_value <- function(value) tryCatch(
    if (is.function(value)) value() else value,
    error = function(error) NULL
  )
  analysis_spec_value <- function() {
    value <- if (is.function(analysis_spec)) analysis_spec() else analysis_spec
    if (is.list(value)) value else dava_code_analysis_spec_from_input(input)
  }

  document <- shiny::reactive({
    active_data <- data_value()
    active_name <- dataset_name_value()
    code <- default_code_value()
    if (identical(code_document_style, "ols")) code <- dava_code_ols_style(code)
    current_plot_params <- if (is.function(plot_params)) plot_params() else plot_params
    current_data_code <- data_code_value()
    doc <- dava_code_document(
      code,
      file_data = file_data,
      title = title,
      source = source,
      data = active_data,
      dataset_name = active_name,
      plot_params = current_plot_params %||% list(),
      input_params = if (isTRUE(include_input_snapshot)) analysis_spec_value() else list(),
      function_mode = function_mode,
      data_code = current_data_code,
      comments = "The analysis, result objects and plots below use the current method-specific implementation."
    )
    bootstrap <- if (isTRUE(standalone_bootstrap)) c(
      "# Load the EcoDAVA runtime only in a clean R session.",
      "if (!exists('dava_local_demo_code', mode = 'function')) source('app.R', local = FALSE)"
    ) else NULL
    doc$data_expression <- dava_module_code_data_expression(
      bootstrap_code = bootstrap,
      data_code = current_data_code,
      snapshot_expression = dava_code_data_expression(file_data, active_name, active_data)
    )
    doc
  })

  preview_payload <- shiny::reactive({
    doc <- document()
    dava_rmd_preview_payload(
      value = safe_preview_value(preview_result),
      tables = safe_preview_value(preview_tables),
      plots = safe_preview_value(preview_plots),
      text = safe_preview_value(preview_text),
      input_data = doc$data
    )
  })

  output$module_code_rmd_document <- shiny::renderUI({
    dava_code_document_preview_html(
      document(), dava_code_settings(file_data), preview_payload()
    )
  })

  # Keep the central read-only document index synchronized.  No custom
  # implementation is executed or enabled from this panel.
  shiny::observe({
    doc <- document()
    dava_method_code_register_original(
      file_data, prefix_value(), doc$raw_code,
      source = source, title = title, manifest = manifest
    )
  })

  invisible(list(
    document = document,
    rmd = shiny::reactive(
      dava_code_document_rmd(document(), dava_code_settings(file_data))
    ),
    preview = preview_payload
  ))
}
