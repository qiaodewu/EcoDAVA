# Unified reproducible-code extraction and display.

dava_code_settings_defaults <- function() {
  list(
    theme = "textmate", font_size = 14L, tab_size = 2L,
    line_wrap = FALSE, show_packages = TRUE, show_data = TRUE,
    show_functions = TRUE, show_comments = TRUE
  )
}

dava_code_settings <- function(file_data = NULL) {
  current <- if (is.null(file_data)) list() else {
    shiny::isolate(file_data$code_settings %||% list())
  }
  utils::modifyList(dava_code_settings_defaults(), current)
}

dava_code_extract_packages <- function(code) {
  code <- paste(as.character(code %||% ""), collapse = "\n")
  parsed <- tryCatch(
    parse(text = code, keep.source = FALSE), error = function(error) NULL)
  if (is.null(parsed)) return(character())
  packages <- character()
  package_name <- function(value) {
    if (is.symbol(value)) return(as.character(value))
    if (is.character(value) && length(value) == 1L) return(value)
    ""
  }
  walk <- function(value) {
    if (!is.call(value) && !is.expression(value) && !is.pairlist(value)) {
      return(invisible(NULL))
    }
    if (is.call(value)) {
      head <- value[[1L]]
      head_name <- if (is.symbol(head)) as.character(head) else ""
      if (head_name %in% c("::", ":::") && length(value) >= 3L) {
        name <- package_name(value[[2L]])
        if (nzchar(name)) packages <<- c(packages, name)
      } else if (head_name %in% c(
          "library", "require", "requireNamespace") && length(value) >= 2L) {
        name <- package_name(value[[2L]])
        if (nzchar(name)) packages <<- c(packages, name)
      }
    }
    elements <- as.list(value)
    for (index in seq_along(elements)) {
      if (!identical(elements[[index]], quote(expr = ))) {
        walk(elements[[index]])
      }
    }
    invisible(NULL)
  }
  walk(parsed)
  sort(unique(packages[nzchar(packages)]))
}

dava_code_call_names <- function(code) {
  parsed <- tryCatch(parse(text = code, keep.source = FALSE), error = function(error) NULL)
  if (is.null(parsed)) return(character())
  unique(all.names(parsed, functions = TRUE, unique = TRUE))
}

dava_code_global_function <- function(name, inherits = FALSE) {
  if (!nzchar(name %||% "") ||
      !exists(name, envir = .GlobalEnv, mode = "function", inherits = inherits)) {
    return(NULL)
  }
  tryCatch(
    get(name, envir = .GlobalEnv, mode = "function", inherits = inherits),
    error = function(error) NULL)
}

dava_code_function_dependencies <- function(fun) {
  if (!is.function(fun)) return(character())
  globals <- tryCatch(
    suppressWarnings(codetools::findGlobals(fun, merge = FALSE)$functions),
    error = function(error) all.names(body(fun), functions = TRUE, unique = TRUE)
  )
  globals <- unique(as.character(globals %||% character()))
  globals[vapply(globals, function(name) {
    !is.null(dava_code_global_function(name, inherits = FALSE))
  }, logical(1))]
}

dava_code_custom_function_names <- function(code, include_functions = NULL,
                                            max_functions = 500L) {
  roots <- unique(c(
    include_functions %||% character(),
    dava_code_call_names(code)
  ))
  roots <- roots[vapply(roots, function(name) {
    !is.null(dava_code_global_function(name, inherits = FALSE))
  }, logical(1))]
  if (!length(roots)) return(character())

  resolved <- character()
  visiting <- character()
  visit <- function(name) {
    if (name %in% resolved || name %in% visiting ||
        length(resolved) >= max(1L, as.integer(max_functions))) {
      return(invisible(NULL))
    }
    fun <- dava_code_global_function(name, inherits = FALSE)
    if (is.null(fun)) return(invisible(NULL))
    visiting <<- c(visiting, name)
    dependencies <- dava_code_function_dependencies(fun)
    for (dependency in dependencies) visit(dependency)
    visiting <<- setdiff(visiting, name)
    if (!name %in% resolved) resolved <<- c(resolved, name)
    invisible(NULL)
  }
  for (root in roots) visit(root)
  resolved
}

dava_code_function_symbol <- function(name) {
  if (grepl("^[A-Za-z.][A-Za-z0-9._]*$", name) &&
      !grepl("^\\.[0-9]", name)) {
    return(name)
  }
  paste0("`", gsub("`", "\\\\`", name, fixed = TRUE), "`")
}

dava_code_function_sources <- function(code, include_functions = NULL,
                                       mode = c("closure", "direct", "none")) {
  mode <- match.arg(mode)
  if (identical(mode, "none")) return(list())
  names <- if (identical(mode, "closure")) {
    dava_code_custom_function_names(code, include_functions)
  } else {
    roots <- unique(c(include_functions %||% character(), dava_code_call_names(code)))
    roots[vapply(roots, function(name) {
      !is.null(dava_code_global_function(name, inherits = FALSE))
    }, logical(1))]
  }
  sources <- lapply(names, function(name) {
    fun <- dava_code_global_function(name, inherits = FALSE)
    if (is.null(fun)) return(NULL)
    paste0(
      dava_code_function_symbol(name), " <- ",
      paste(deparse(fun, width.cutoff = 100L), collapse = "\n")
    )
  })
  keep <- !vapply(sources, is.null, logical(1))
  stats::setNames(sources[keep], names[keep])
}

dava_code_active_data <- function(file_data = NULL, data = NULL, dataset_name = NULL) {
  if (!is.null(data)) return(data)
  if (is.null(file_data)) return(NULL)
  datasets <- shiny::isolate(file_data$global_datasets %||% list())
  name <- dataset_name %||% shiny::isolate(file_data$active_dataset %||% "")
  datasets[[name]] %||% NULL
}

dava_code_data_expression <- function(file_data = NULL, dataset_name = NULL, data = NULL) {
  name <- dataset_name %||% if (!is.null(file_data)) {
    shiny::isolate(file_data$active_dataset %||% "")
  } else ""
  source_label <- if (!is.null(data) && (!nzchar(name) || identical(name, "__demo__"))) {
    "Simulation data for current analysis method"
  } else if (nzchar(name)) {
    "Global dataset imported by user"
  } else {
    "Module built-in data of the current function"
  }
  display_name <- if (nzchar(name)) name else "Unnamed data set"
  paste0(
    "# Data source：", source_label, "\n",
    "# Data set name：", display_name
  )
}

dava_code_parameter_label <- function(name) {
  tokens <- c(
    dataset = "data set", data = "Data", count = "Abundance table", otu = "OTU/ASV table",
    taxonomy = "Classification annotation table", tax = "Category", sample = "Sample", metadata = "Sample information",
    sequence = "Representative sequence", tree = "Phylogenetic tree", env = "Environment variables",
    method = "Analysis method", mode = "Analysis mode", group = "Grouping", variable = "variable",
    response = "response variable", predictor = "Predictor variables", formula = "Model formula",
    level = "Level", measure = "Metrics", distance = "distance", test = "Check",
    adjust = "Correction", threshold = "Threshold", cutoff = "cutoff value", filter = "Filter",
    normalize = "Standardization", transform = "Convert", zero = "Zero value handling",
    permutation = "Number of replacements", permutations = "Number of replacements",
    seed = "Random seed", worker = "Parallel threads", workers = "Parallel threads",
    plot = "Plot", color = "Color", colour = "Color", palette = "Swatches",
    theme = "Topic", font = "Font", label = "tag", legend = "Legend",
    layout = "Layout", node = "node", edge = "side", axis = "Axis",
    title = "title", size = "Size", alpha = "Transparency", width = "width",
    height = "height", facet = "Faceted", line = "lines", point = "points"
  )
  parts <- strsplit(gsub("[^A-Za-z0-9]+", "_", name), "_", fixed = TRUE)[[1]]
  parts <- parts[nzchar(parts)]
  translated <- vapply(parts, function(part) {
    key <- tolower(part)
    if (key %in% names(tokens)) unname(tokens[[key]]) else part
  }, character(1))
  paste(translated, collapse = " / ")
}

dava_code_parameter_value <- function(value, max_items = 12L,
                                      max_chars = 180L) {
  if (is.null(value) || !length(value)) return("Not selected")
  if (is.factor(value)) value <- as.character(value)
  if (inherits(value, c("Date", "POSIXct", "POSIXlt"))) value <- as.character(value)
  if (!is.atomic(value)) return(paste0("<", paste(class(value), collapse = "/"), ">"))
  original_length <- length(value)
  value <- utils::head(value, max(1L, as.integer(max_items)))
  encoded <- if (is.character(value)) {
    paste0('"', gsub('[\r\n]+', ' ', encodeString(value, quote = "")), '"')
  } else if (is.logical(value)) {
    ifelse(is.na(value), "NA", ifelse(value, "TRUE", "FALSE"))
  } else {
    as.character(value)
  }
  text <- if (original_length == 1L) encoded else
    paste0("c(", paste(encoded, collapse = ", "),
      if (original_length > length(value)) ", ..." else "", ")")
  if (nchar(text, type = "width") > max_chars) {
    paste0(substr(text, 1L, max_chars - 3L), "...")
  } else text
}

dava_code_parameter_range <- function(name, value) {
  if (is.logical(value)) return("TRUE / FALSE")
  if (length(value) > 1L) return("The options provided by the current multi-select control")
  if (is.numeric(value) || is.integer(value)) return("The numerical range and step size allowed by the interface")
  if (grepl("colou?r|palette|background|fill", name, ignore.case = TRUE)) {
    return("Color picker, preset scientific colors or legal color numbers")
  }
  if (grepl("dataset|data|count|otu|tax|sample|metadata|sequence|tree|file",
      name, ignore.case = TRUE)) {
    return("Currently registered data sets, current data corresponding objects or files allowed to be uploaded")
  }
  "The options provided by the current radio/drop-down control"
}

dava_code_parameter_group <- function(name, plot_names = character()) {
  if (name %in% plot_names || grepl(
      "plot|color|colour|palette|theme|font|label|legend|layout|node|edge|axis|title|size|alpha|width|height|facet|line|point|canvas|export|margin",
      name, ignore.case = TRUE)) return("The property bar on the right side of the graphic display")
  if (grepl(
      "dataset|data|count|otu|tax|sample|metadata|sequence|tree|env|missing|na_|filter|normalize|transform|preprocess|zero|raref",
      name, ignore.case = TRUE)) return("Input data and data check processing")
  if (grepl(
      "advanced|adv_|threshold|cutoff|permutation|bootstrap|iteration|nperm|seed|worker|thread|parallel|adjust|p_value|alpha_level|tolerance",
      name, ignore.case = TRUE)) return("Advanced parameters and pop-up panel")
  "Left sidebar analysis settings"
}

dava_code_input_parameter_comments <- function(parameters = list(),
                                               plot_params = list()) {
  parameters <- parameters %||% list()
  if (!is.list(parameters)) parameters <- list()
  # Plot-panel values are emitted as executable R code at the end of the
  # method script.  Do not duplicate them here as a passive comment dump.
  values <- parameters
  values <- values[nzchar(names(values))]
  if (!length(values)) return(character())
  internal <- grepl(
    "^(module_code_|manager_|plugin_)|(?:^|_)(?:run|download|install|save|copy|refresh|restore|apply|status|progress|revision|tab|nav)(?:_|$)",
    names(values), ignore.case = TRUE, perl = TRUE)
  values <- values[!internal & vapply(values, function(value) {
    (is.atomic(value) || is.factor(value)) && length(value) <= 100L &&
      !inherits(value, c("shinyActionButtonValue", "shiny.tag"))
  }, logical(1))]
  if (!length(values)) return(character())

  plot_names <- character()
  groups <- vapply(names(values), dava_code_parameter_group, character(1),
    plot_names = plot_names)
  order <- c("Left sidebar analysis settings", "Input data and data check processing",
    "Advanced parameters and pop-up panel", "The property bar on the right side of the graphic display")
  comments <- c(
    "# Current main method UI Parameter snapshot（onlyComments，will not overwrite the actualRunCode）。",
    "# Modification tips：Modifiable parameter values，but should remainParameter name、DataObject structureandResultsThe contract remains unchanged。",
    "# The range prompt is based on the current interface control；Out-of-range value possibleNoneDharma return masterAnalyzepage。"
  )
  for (group in order[order %in% groups]) {
    comments <- c(comments, paste0("# [", group, "]"))
    selected <- names(values)[groups == group]
    comments <- c(comments, vapply(selected, function(name) {
      paste0("# - ", dava_code_parameter_label(name), " [", name, "] = ",
        dava_code_parameter_value(values[[name]]), " | Modifiable range:",
        dava_code_parameter_range(name, values[[name]]))
    }, character(1)))
  }
  comments
}

dava_code_split_analysis_plot <- function(code) {
  lines <- strsplit(paste(code, collapse = "\n"), "\n", fixed = TRUE)[[1]]
  library_line <- grepl(
    "^\\s*(?:suppressPackageStartupMessages\\s*\\()?\\s*(?:library|require)\\s*\\(",
    lines, perl = TRUE
  )
  lines <- lines[!library_line]
  plot_line <- grepl(
    "(?:^|<-\\s*)(?:graphics::|grDevices::|ggplot2::|[A-Za-z][A-Za-z0-9_.]*::)?(?:plot|ggplot|qplot|autoplot|pairs|hist|boxplot|barplot|heatmap|corrplot|pheatmap|sv_[A-Za-z0-9_.]*|[A-Za-z0-9_.]+_plot)\\s*\\(",
    lines, perl = TRUE
  ) | grepl("register_plot\\s*\\(", lines, perl = TRUE)
  first_plot <- which(plot_line)[1]
  if (is.na(first_plot)) {
    return(list(analysis = paste(lines, collapse = "\n"), plotting = "", plot_lines = integer()))
  }
  list(
    analysis = paste(lines[seq_len(first_plot - 1L)], collapse = "\n"),
    plotting = paste(lines[first_plot:length(lines)], collapse = "\n"),
    plot_lines = which(plot_line[first_plot:length(lines)])
  )
}

dava_code_plot_label <- function(line, index) {
  assigned <- sub("^\\s*([A-Za-z.][A-Za-z0-9._]*)\\s*<-.*$", "\\1", line, perl = TRUE)
  if (!identical(assigned, line)) return(gsub("_", " ", assigned, fixed = TRUE))
  paste("Plot", index)
}

dava_code_annotate_plots <- function(code, plot_lines, plot_params = list()) {
  if (!nzchar(code)) return("")
  lines <- strsplit(code, "\n", fixed = TRUE)[[1]]
  out <- character()
  plot_index <- 0L
  for (index in seq_along(lines)) {
    if (index %in% plot_lines) {
      plot_index <- plot_index + 1L
      out <- c(out, sprintf("# Plot %d: %s", plot_index,
        dava_code_plot_label(lines[[index]], plot_index)))
    }
    out <- c(out, lines[[index]])
  }
  paste(out, collapse = "\n")
}

dava_code_ols_style <- function(code) {
  code <- paste(as.character(code %||% ""), collapse = "\n")
  if (!nzchar(code)) return(code)
  lines <- strsplit(code, "\n", fixed = TRUE)[[1]]
  # Code documents reproduce the method locally; registering a plot is a
  # Shiny-side effect and is not part of the analytical workflow.
  lines <- lines[!grepl("register_plot\\s*\\(", lines, perl = TRUE)]
  candidates <- grepl(
    "^\\s*(?:[A-Za-z.][A-Za-z0-9._]*\\s*<-|[A-Za-z.][A-Za-z0-9._]*\\s*=)\\s*(?:c\\s*\\(|list\\s*\\(|['\"]|[-+]?[0-9.]|TRUE\\b|FALSE\\b|NULL\\b)",
    lines, perl = TRUE
  )
  candidates <- candidates & !grepl(
    "^\\s*(?:result|analysis_result|analysis_output|plot|p|model|fit|res|summary|diagnostics|predictions?|coefficient|table)\\s*(?:<-|=)",
    lines, ignore.case = TRUE, perl = TRUE
  )
  candidates <- candidates & !grepl("<DAVA-UI-PARAM>", lines, fixed = TRUE)
  lines[candidates] <- paste0(lines[candidates], " # <DAVA-UI-PARAM>")
  paste(lines, collapse = "\n")
}

dava_code_executable_plot_parameters <- function(plot_params = list()) {
  plot_params <- plot_params %||% list()
  if (!is.list(plot_params) || !length(plot_params)) return("")
  keep <- nzchar(names(plot_params)) & vapply(plot_params, function(value) {
    (is.atomic(value) || is.factor(value)) && length(value) <= 50L &&
      !(is.character(value) && (!length(value) || all(is.na(value) | !nzchar(value))))
  }, logical(1))
  values <- plot_params[keep]
  if (!length(values)) return("")
  assignments <- vapply(names(values), function(name) {
    safe <- gsub("[^A-Za-z0-9_]+", "_", name)
    paste0("ui_", safe, " <- ", dava_code_parameter_value(values[[name]]),
      " # <DAVA-UI-PARAM>")
  }, character(1))
  variable_for <- function(fields, default) {
    candidates <- names(values)[vapply(names(values), function(name) {
      any(vapply(fields, function(field) endsWith(name, paste0("_", field)) || identical(name, field), logical(1)))
    }, logical(1))]
    if (!length(candidates)) return(default)
    paste0("ui_", gsub("[^A-Za-z0-9_]+", "_", candidates[[1]]))
  }
  theme_var <- variable_for("theme", '"publication"')
  size_var <- variable_for(c("base_size", "font_size"), "14")
  legend_var <- variable_for("legend_position", '"right"')
  show_var <- variable_for(c("show_legend", "legend"), "TRUE")
  title_var <- variable_for("title", '""')
  x_var <- variable_for(c("x_label", "x_title"), '""')
  y_var <- variable_for(c("y_label", "y_title"), '""')
  point_var <- variable_for(c("point_color", "color", "colour"), '"#1F1F1F"')
  point_alpha_var <- variable_for(c("point_alpha", "alpha"), "0.7")
  point_size_var <- variable_for(c("point_size", "size"), "2")
  line_var <- variable_for("line_color", '"#3B7EA1"')
  line_alpha_var <- variable_for("line_alpha", "1")
  line_width_var <- variable_for(c("line_width", "linewidth"), "1")
  confidence_var <- variable_for("confidence_color", '"#B5CEDB"')
  confidence_alpha_var <- variable_for("confidence_alpha", "0.12")
  application <- c(
    ".dava_plot_names <- character()",
    "for (.dava_candidate in ls()) if (inherits(get(.dava_candidate), 'ggplot')) .dava_plot_names <- c(.dava_plot_names, .dava_candidate)",
    "if (exists('result', inherits = FALSE) && is.list(result) && inherits(result$plot, 'ggplot')) { .dava_result_plot <- result$plot; .dava_plot_names <- c(.dava_plot_names, '.dava_result_plot') }",
    "for (.dava_plot_name in unique(.dava_plot_names)) {",
    "  p <- get(.dava_plot_name)",
    sprintf("  theme_name <- %s; base_size <- as.numeric(%s)", theme_var, size_var),
    "  theme_function <- switch(theme_name, minimal = ggplot2::theme_minimal, classic = ggplot2::theme_classic, clean = ggplot2::theme_minimal, nature = ggplot2::theme_classic, cell = ggplot2::theme_classic, lancet = ggplot2::theme_classic, prism = ggplot2::theme_classic, pnas = ggplot2::theme_minimal, ggplot2::theme_bw)",
    sprintf("  p <- p + theme_function(base_size = base_size) + ggplot2::theme(legend.position = if (isTRUE(%s)) %s else 'none')", show_var, legend_var),
    sprintf("  labels <- list(); if (nzchar(%s)) labels$title <- %s; if (nzchar(%s)) labels$x <- %s; if (nzchar(%s)) labels$y <- %s", title_var, title_var, x_var, x_var, y_var, y_var),
    "  if (length(labels)) p <- p + do.call(ggplot2::labs, labels)",
    "  for (i in seq_along(p$layers)) {",
    "    geom <- class(p$layers[[i]]$geom)[1]; mapped <- names(p$layers[[i]]$mapping)",
    sprintf("    if (grepl('Geom(Point|Jitter|Count)', geom)) { if (!any(c('colour','color') %%in%% mapped)) p$layers[[i]]$aes_params$colour <- %s; p$layers[[i]]$aes_params$alpha <- %s; p$layers[[i]]$aes_params$size <- %s }", point_var, point_alpha_var, point_size_var),
    sprintf("    if (grepl('Geom(Line|Path|Smooth)', geom)) { if (!any(c('colour','color') %%in%% mapped)) p$layers[[i]]$aes_params$colour <- %s; p$layers[[i]]$aes_params$alpha <- %s; p$layers[[i]]$aes_params$linewidth <- %s }", line_var, line_alpha_var, line_width_var),
    sprintf("    if (grepl('GeomRibbon', geom)) { if (!'fill' %%in%% mapped) p$layers[[i]]$aes_params$fill <- %s; p$layers[[i]]$aes_params$alpha <- %s; p$layers[[i]]$aes_params$colour <- NA }", confidence_var, confidence_alpha_var),
    "  }",
    "  assign(.dava_plot_name, p, inherits = FALSE)",
    "}",
    "if (exists('.dava_result_plot', inherits = FALSE)) result$plot <- .dava_result_plot",
    ".dava_plot_names <- .dava_plot_names[.dava_plot_names != 'result']",
    "if (exists('result', inherits = FALSE)) result else if (length(.dava_plot_names)) get(tail(.dava_plot_names, 1)) else invisible(NULL)"
  )
  c(
    "# ---- Current plot-panel parameters (executable) ----",
    assignments,
    application
  ) |> paste(collapse = "\n")
}

# Code shown to users must be a standalone, method-specific script.  Internal
# application helpers are intentionally rejected here instead of being hidden
# behind a generated document that cannot run outside EcoDAVA.
dava_code_internal_call_names <- function(code) {
  code <- paste(as.character(code %||% ""), collapse = "\n")
  if (!nzchar(trimws(code))) return(character())
  parsed <- tryCatch(parse(text = code, keep.source = FALSE), error = function(e) NULL)
  if (is.null(parsed)) return(character())
  names_used <- unique(all.names(parsed, functions = TRUE, unique = TRUE))
  # A method may define small local helpers in the document.  Those are part
  # of the standalone source, not unresolved application calls.
  definition_matches <- regmatches(code, gregexpr(
    "(?m)^\\s*(`?[A-Za-z.][A-Za-z0-9._]*`?)\\s*<-\\s*function\\s*\\(",
    code, perl = TRUE
  ))[[1L]]
  locally_defined <- if (length(definition_matches) &&
      !identical(definition_matches, character())) {
    sub("(?m)^\\s*`?([A-Za-z.][A-Za-z0-9._]*)`?\\s*<-.*$", "\\1",
      definition_matches, perl = TRUE)
  } else character()
  names_used <- setdiff(names_used, locally_defined)
  names_used[grepl(
    "^(dava_|microbiome_|advanced_analysis_|fit_(correlation|structural)_method$)",
    names_used
  )]
}

dava_code_assert_standalone <- function(code, method_id = "current method") {
  internal <- dava_code_internal_call_names(code)
  if (length(internal)) {
    stop(
      sprintf(
        "Method-specific code for '%s' still contains internal calls: %s",
        method_id,
        paste(internal, collapse = ", ")
      ),
      call. = FALSE
    )
  }
  invisible(code)
}

dava_code_document <- function(code, file_data = NULL, title = "R analysis",
                               source = "module code", data = NULL,
                               dataset_name = NULL, plot_params = list(),
                               input_params = list(), include_functions = NULL,
                               comments = character(),
                               function_mode = c("closure", "direct", "none"),
                               data_code = NULL) {
  function_mode <- match.arg(function_mode)
  raw_code <- paste(as.character(code %||% ""), collapse = "\n")
  functions <- dava_code_function_sources(raw_code, include_functions, mode = function_mode)
  packages <- dava_code_extract_packages(paste(
    raw_code, paste(unname(functions), collapse = "\n"), sep = "\n"))
  active_data <- dava_code_active_data(file_data, data, dataset_name)
  metadata <- list(
    title = title, source = source, dataset = dataset_name %||%
      if (!is.null(file_data)) shiny::isolate(file_data$active_dataset %||% "") else "",
    generated_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
    plot_params = plot_params %||% list(),
    input_params = input_params %||% list()
  )
  structure(list(
    raw_code = raw_code, packages = packages, data = active_data,
    data_expression = data_code %||% dava_code_data_expression(file_data, dataset_name, data),
    functions = functions, metadata = metadata, comments = comments
  ), class = "dava_code_document")
}

dava_code_plot_params_from_input <- function(input) {
  snapshot <- shiny::isolate(shiny::reactiveValuesToList(input, all.names = TRUE))
  keep <- grepl(
    "plot|color|colour|palette|theme|font|label|legend|layout|node|edge|axis|title|size|alpha|width|height|facet|line|point",
    names(snapshot), ignore.case = TRUE
  )
  keep <- keep & !grepl(
    "^(module_code_|generated_code_|analysis_code_)|(?:^|_)(?:run|download|install|save|copy|tab|nav)(?:_|$)",
    names(snapshot), ignore.case = TRUE, perl = TRUE
  )
  parameter_names <- names(snapshot)[keep]
  values <- stats::setNames(lapply(parameter_names, function(name) input[[name]]), parameter_names)
  values[vapply(values, function(value) {
    is.atomic(value) && length(value) <= 50L &&
      !inherits(value, c("shinyActionButtonValue", "shiny.tag"))
  }, logical(1))]
}

dava_code_document_script <- function(document, settings = dava_code_settings_defaults(), language = "en") {
  stopifnot(inherits(document, "dava_code_document"))
  sections <- character()
  if (isTRUE(settings$show_comments)) {
    sections <- c(sections,
      paste0("# ", document$metadata$title),
      paste0("# Source: ", document$metadata$source),
      if (length(document$comments)) paste0("# ", document$comments) else character())
  }
  if (isTRUE(settings$show_packages) && length(document$packages)) {
    sections <- c(sections, "# ---- Packages ----",
      sprintf("library(%s)", document$packages))
  }
  if (isTRUE(settings$show_data)) {
    sections <- c(sections, "# ---- Input data ----", document$data_expression)
  }
  if (isTRUE(settings$show_functions) && length(document$functions)) {
    sections <- c(sections, "# ---- Current-method local implementations ----",
      unname(document$functions))
  }
  code_parts <- dava_code_split_analysis_plot(document$raw_code)
  sections <- c(sections, "# ---- Analysis ----", code_parts$analysis)
  plot_code <- dava_code_annotate_plots(
    code_parts$plotting, code_parts$plot_lines, document$metadata$plot_params
  )
  if (!nzchar(plot_code)) {
    plot_code <- paste(
      "# Plot 1: display graphical objects created by the analysis",
      ".dava_plot_objects <- list()",
      "for (.dava_object_name in ls()) { .dava_object <- get(.dava_object_name); if (inherits(.dava_object, c('ggplot', 'grob', 'recordedplot'))) .dava_plot_objects[[.dava_object_name]] <- .dava_object }",
      "for (.dava_object in .dava_plot_objects) print(.dava_object)",
      "invisible(.dava_plot_objects)",
      sep = "\n"
    )
  }
  if (nzchar(plot_code)) sections <- c(sections, "# ---- Plotting ----", plot_code)
  if (length(document$metadata$plot_params) &&
      !grepl("apply_current_plot_panel", document$raw_code, fixed = TRUE)) {
    sections <- c(sections,
      dava_code_executable_plot_parameters(document$metadata$plot_params))
  }
  dava_localize_r_comments(
    paste(sections[nzchar(sections)], collapse = "\n\n"), language
  )
}

# Build the R Markdown source behind every rendered analysis document.
# Code and model text are deliberately never passed through the interface
# translator: changing the UI language must not change an executable document.
dava_code_document_rmd <- function(document,
                                   settings = dava_code_settings_defaults()) {
  stopifnot(inherits(document, "dava_code_document"))
  yaml_text <- function(value) {
    value <- gsub("\\\"", "\\\\\\\"", as.character(value %||% ""))
    paste0('"', value, '"')
  }
  chunk <- function(label, code, options = "") {
    code <- paste(as.character(code %||% ""), collapse = "\n")
    if (!nzchar(trimws(code))) return(character())
    header <- paste0("```{r ", label,
      if (nzchar(options)) paste0(", ", options) else "", "}")
    c(header, code, "```")
  }

  # Preserve the generator's statement order verbatim.  Splitting detected
  # plotting calls into another chunk can change execution when later result
  # assembly depends on those plot objects.
  analysis_code <- document$raw_code
  sections <- c(
    "---",
    paste0("title: ", yaml_text(document$metadata$title %||% "R analysis")),
    "output:",
    "  html_document:",
    "    toc: true",
    "    toc_float: true",
    "    df_print: paged",
    "---",
    "",
    paste0("<!-- Source: ", document$metadata$source %||% "module code", " -->"),
    "",
    "# Analysis method",
    "",
    if (length(document$comments)) as.character(document$comments) else
      "This document reproduces the currently selected analysis method and its parameters.",
    "",
    chunk("setup", c(
      "knitr::opts_chunk$set(echo = TRUE, message = FALSE, warning = FALSE)",
      if (isTRUE(settings$show_packages) && length(document$packages))
        sprintf("library(%s)", document$packages) else character()
    ), "include=TRUE"),
    "",
    "# Input data",
    "",
    if (isTRUE(settings$show_data)) chunk("input-data", document$data_expression) else character(),
    "",
    if (isTRUE(settings$show_functions) && length(document$functions)) c(
      "# Method-specific local implementation",
      "",
      chunk("method-implementation", unname(document$functions))
    ) else character(),
    "",
    "# Analysis",
    "",
    chunk("analysis", analysis_code),
    "",
    "# Results",
    "",
    chunk("results", c(
      "if (exists('result_tables', inherits = FALSE)) result_tables",
      "if (exists('tables', inherits = FALSE)) tables",
      "if (exists('result', inherits = FALSE)) result"
    )),
    "",
    "# Plots",
    "",
    chunk("plots", c(
      "if (exists('result_plots', inherits = FALSE) && is.list(result_plots)) invisible(lapply(result_plots, print))",
      "if (exists('plots', inherits = FALSE) && is.list(plots) && !inherits(plots, 'ggplot')) invisible(lapply(plots, print))",
      "if (exists('plot', inherits = FALSE) && inherits(plot, c('ggplot', 'grob', 'recordedplot', 'trellis'))) print(plot)",
      "if (exists('result', inherits = FALSE) && is.list(result) && is.list(result$plots)) invisible(lapply(result$plots, print))"
    ), "fig.width=8, fig.height=6")
  )
  paste(sections, collapse = "\n")
}

dava_rmd_preview_table_list <- function(value, prefix = "Result") {
  if (is.null(value)) return(list())
  if (is.matrix(value)) value <- as.data.frame(value, check.names = FALSE)
  if (is.data.frame(value)) return(stats::setNames(list(value), prefix))
  if (!is.list(value)) return(list())
  output <- list()
  for (index in seq_along(value)) {
    item <- value[[index]]
    if (is.matrix(item)) item <- as.data.frame(item, check.names = FALSE)
    if (!is.data.frame(item)) next
    label <- names(value)[index] %||% ""
    if (!nzchar(label)) label <- paste(prefix, index)
    output[[label]] <- item
  }
  output
}

dava_rmd_preview_plot_list <- function(value, prefix = "Figure") {
  if (is.null(value)) return(list())
  if (is.function(value)) value <- tryCatch(value(), error = function(error) NULL)
  is_plot <- function(object) inherits(object,
    c("ggplot", "grob", "recordedplot", "trellis"))
  if (is_plot(value)) return(stats::setNames(list(value), prefix))
  if (!is.list(value)) return(list())
  output <- list()
  for (index in seq_along(value)) {
    item <- value[[index]]
    if (is.function(item)) item <- tryCatch(item(), error = function(error) NULL)
    if (!is_plot(item)) next
    label <- names(value)[index] %||% ""
    if (!nzchar(label)) label <- paste(prefix, index)
    output[[label]] <- item
  }
  output
}

dava_rmd_preview_payload <- function(value = NULL, tables = NULL, plots = NULL,
                                     text = NULL, input_data = NULL) {
  result_tables <- dava_rmd_preview_table_list(tables, "Result table")
  result_plots <- dava_rmd_preview_plot_list(plots, "Result figure")
  result_text <- as.character(text %||% character())
  if (is.data.frame(value) || is.matrix(value)) {
    result_tables <- c(result_tables, dava_rmd_preview_table_list(value))
  } else if (inherits(value, c("ggplot", "grob", "recordedplot", "trellis"))) {
    result_plots <- c(result_plots, dava_rmd_preview_plot_list(value))
  } else if (is.list(value)) {
    for (field in intersect(c("tables", "result_tables"), names(value))) {
      result_tables <- c(result_tables,
        dava_rmd_preview_table_list(value[[field]], "Result table"))
    }
    for (field in intersect(c("result", "summary", "diagnostics", "errors",
        "model_summary", "posthoc", "letters", "predictions"), names(value))) {
      result_tables <- c(result_tables,
        dava_rmd_preview_table_list(value[[field]], field))
    }
    for (field in intersect(c("plots", "result_plots", "plot_pages", "plot",
        "custom_plot"), names(value))) {
      result_plots <- c(result_plots,
        dava_rmd_preview_plot_list(value[[field]], "Result figure"))
    }
    if (!length(result_text)) {
      for (field in intersect(c("model_text", "text"), names(value))) {
        candidate <- value[[field]]
        if (is.character(candidate) && length(candidate)) {
          result_text <- candidate
          break
        }
      }
    }
  }
  if (length(result_tables)) names(result_tables) <- make.unique(names(result_tables))
  if (length(result_plots)) names(result_plots) <- make.unique(names(result_plots))
  list(
    input = dava_rmd_preview_table_list(input_data, "Input data"),
    tables = result_tables,
    plots = result_plots,
    text = result_text
  )
}

dava_rmd_preview_table_tag <- function(table, caption = "Result table",
                                       max_rows = 12L, max_columns = 14L) {
  table <- as.data.frame(table, stringsAsFactors = FALSE, check.names = FALSE)
  shown <- utils::head(table[, seq_len(min(ncol(table), max_columns)), drop = FALSE], max_rows)
  for (name in names(shown)) if (is.list(shown[[name]])) {
    shown[[name]] <- vapply(shown[[name]], function(item) paste(item, collapse = ", "), character(1))
  }
  header <- htmltools::tags$tr(lapply(names(shown), htmltools::tags$th))
  rows <- lapply(seq_len(nrow(shown)), function(row) {
    htmltools::tags$tr(lapply(shown[row, , drop = TRUE], function(cell) {
      value <- if (!length(cell) || is.na(cell)) "NA" else format(cell, trim = TRUE)
      htmltools::tags$td(value)
    }))
  })
  htmltools::tags$figure(class = "dava-rmd-table-output",
    htmltools::tags$figcaption(caption),
    htmltools::tags$div(class = "dava-rmd-table-scroll",
      htmltools::tags$table(class = "table table-sm table-striped table-hover",
        htmltools::tags$thead(header), htmltools::tags$tbody(rows))),
    if (nrow(table) > nrow(shown) || ncol(table) > ncol(shown))
      htmltools::tags$small(sprintf("Preview: %d of %d rows, %d of %d columns.",
        nrow(shown), nrow(table), ncol(shown), ncol(table)))
  )
}

dava_rmd_preview_plot_uri <- function(plot, width = 960L, height = 640L,
                                      resolution = 120L) {
  if (is.function(plot)) plot <- tryCatch(plot(), error = function(error) NULL)
  if (!inherits(plot, c("ggplot", "grob", "recordedplot", "trellis")) ||
      !requireNamespace("base64enc", quietly = TRUE)) return("")
  file <- tempfile(fileext = ".png")
  on.exit(unlink(file, force = TRUE), add = TRUE)
  device_open <- FALSE
  ok <- tryCatch({
    grDevices::png(file, width = width, height = height, res = resolution)
    device_open <- TRUE
    if (inherits(plot, "recordedplot")) grDevices::replayPlot(plot) else print(plot)
    grDevices::dev.off()
    device_open <- FALSE
    file.exists(file) && file.info(file)$size > 0
  }, error = function(error) FALSE)
  if (device_open) try(grDevices::dev.off(), silent = TRUE)
  if (!isTRUE(ok)) return("")
  base64enc::dataURI(file = file, mime = "image/png")
}

dava_rmd_highlight_r <- function(code) {
  code <- paste(as.character(code %||% ""), collapse = "\n")
  if (requireNamespace("highr", quietly = TRUE)) {
    return(htmltools::HTML(paste(highr::hi_html(code), collapse = "\n")))
  }
  htmltools::HTML(htmltools::htmlEscape(code))
}

dava_code_document_preview_html <- function(document,
                                            settings = dava_code_settings_defaults(),
                                            preview = NULL) {
  stopifnot(inherits(document, "dava_code_document"))
  rmd <- dava_code_document_rmd(document, settings)
  payload <- if (is.list(preview) && all(c("input", "tables", "plots", "text") %in% names(preview))) {
    preview
  } else dava_rmd_preview_payload(preview, input_data = document$data)
  lines <- strsplit(rmd, "\n", fixed = TRUE)[[1L]]
  body <- list()
  headings <- list()
  in_yaml <- FALSE
  index <- 1L
  while (index <= length(lines)) {
    line <- lines[[index]]
    if (index == 1L && identical(line, "---")) { in_yaml <- TRUE; index <- index + 1L; next }
    if (in_yaml) {
      if (identical(line, "---")) in_yaml <- FALSE
      index <- index + 1L
      next
    }
    if (grepl("^```\\{r", line)) {
      label <- sub("^```\\{r[[:space:]]*([^,}]*)[^}]*}.*$", "\\1", line)
      code <- character(); index <- index + 1L
      while (index <= length(lines) && !identical(lines[[index]], "```")) {
        code <- c(code, lines[[index]]); index <- index + 1L
      }
      body[[length(body) + 1L]] <- htmltools::tags$section(
        class = "dava-rmd-chunk", `data-chunk-label` = label,
        htmltools::tags$div(class = "dava-rmd-chunk-head",
          htmltools::tags$span(class = "dava-rmd-chunk-engine", "R"),
          htmltools::tags$span(class = "dava-rmd-chunk-label", label)),
        htmltools::tags$pre(class = "dava-rmd-code",
          htmltools::tags$code(class = "language-r", dava_rmd_highlight_r(code)))
      )
      if (identical(label, "input-data") && length(payload$input)) {
        body <- c(body, lapply(utils::head(seq_along(payload$input), 2L), function(i)
          dava_rmd_preview_table_tag(payload$input[[i]], names(payload$input)[i], 8L, 12L)))
      }
      if (identical(label, "analysis") && length(payload$text)) {
        body[[length(body) + 1L]] <- htmltools::tags$div(class = "dava-rmd-text-output",
          htmltools::tags$div(class = "dava-rmd-output-label", "Model / analysis output"),
          htmltools::tags$pre(paste(payload$text, collapse = "\n")))
      }
      if (identical(label, "results") && length(payload$tables)) {
        body <- c(body, lapply(utils::head(seq_along(payload$tables), 8L), function(i)
          dava_rmd_preview_table_tag(payload$tables[[i]], names(payload$tables)[i])))
      }
      if (identical(label, "plots") && length(payload$plots)) {
        figures <- lapply(utils::head(seq_along(payload$plots), 6L), function(i) {
          uri <- dava_rmd_preview_plot_uri(payload$plots[[i]])
          if (!nzchar(uri)) return(NULL)
          htmltools::tags$figure(class = "dava-rmd-figure-output",
            htmltools::tags$figcaption(names(payload$plots)[i]),
            htmltools::tags$img(src = uri, alt = names(payload$plots)[i]))
        })
        body <- c(body, Filter(Negate(is.null), figures))
      }
      index <- index + 1L
      next
    }
    if (grepl("^# ", line)) {
      title <- sub("^# +", "", line)
      anchor <- paste0("rmd-section-", length(headings) + 1L)
      headings[[length(headings) + 1L]] <- list(anchor = anchor, title = title)
      body[[length(body) + 1L]] <- htmltools::tags$h2(id = anchor, title)
    } else if (nzchar(trimws(line)) && !grepl("^<!--", line)) {
      body[[length(body) + 1L]] <- htmltools::tags$p(class = "dava-rmd-prose", line)
    }
    index <- index + 1L
  }
  toc <- htmltools::tags$nav(class = "dava-rmd-toc",
    htmltools::tags$strong("Contents"),
    lapply(headings, function(item) htmltools::tags$a(href = paste0("#", item$anchor), item$title)))
  htmltools::tagList(
    htmltools::tags$style(htmltools::HTML(paste(
      ".dava-rmarkdown-document-panel{height:100%;min-height:32rem;overflow:auto;background:#edf1f2;padding:0}",
      ".dava-rmd-preview{display:grid;grid-template-columns:175px minmax(0,1fr);max-width:1480px;margin:0 auto;background:#fff;min-height:100%}",
      ".dava-rmd-toc{position:sticky;top:0;align-self:start;max-height:calc(100vh - 10rem);overflow:auto;padding:1.3rem 1rem;border-right:1px solid #d9e1e4;background:#f7f9fa}",
      ".dava-rmd-toc strong{display:block;margin-bottom:.65rem;color:#29434b}.dava-rmd-toc a{display:block;padding:.32rem 0;color:#426873;text-decoration:none;font-size:.82rem}",
      ".dava-rmd-paper{min-width:0;padding:1.5rem 2rem 4rem}.dava-rmd-title{margin:0 0 .2rem;font-size:1.65rem;color:#203b43}.dava-rmd-source{color:#6b7c82;margin-bottom:1.5rem}",
      ".dava-rmd-paper h2{margin:1.8rem 0 .8rem;padding-bottom:.35rem;border-bottom:1px solid #dbe4e6;color:#234e57;font-size:1.3rem}.dava-rmd-prose{color:#465d65}",
      ".dava-rmd-chunk{margin:1rem 0;border:1px solid #d6dee2;border-radius:7px;overflow:hidden;background:#fff}.dava-rmd-chunk-head{display:flex;gap:.55rem;align-items:center;padding:.38rem .65rem;background:#eef2f4;border-bottom:1px solid #d6dee2;font-size:.76rem;color:#60747c}",
      ".dava-rmd-chunk-engine{font-weight:700;color:#28717a}.dava-rmd-code{margin:0;padding:1rem;overflow:auto;background:#f7f8fa;color:#202b30;white-space:pre;font:13px/1.55 Consolas,'Liberation Mono',monospace}",
      ".hl.kwd{color:#0759a5;font-weight:600}.hl.kwb,.hl.opt{color:#7a3e9d}.hl.num{color:#087e8b}.hl.str{color:#b13e3e}.hl.com{color:#4d7b43;font-style:italic}.hl.def{color:#27343a}",
      ".dava-rmd-table-output,.dava-rmd-figure-output,.dava-rmd-text-output{margin:1rem 0 1.5rem;border-left:3px solid #2b8c88;padding:.75rem 1rem;background:#fbfcfc}.dava-rmd-table-output figcaption,.dava-rmd-figure-output figcaption,.dava-rmd-output-label{font-weight:700;color:#34545c;margin-bottom:.55rem}",
      ".dava-rmd-table-scroll{overflow:auto}.dava-rmd-table-output table{font-size:.82rem;margin:0}.dava-rmd-table-output th{white-space:nowrap;background:#eaf2f2}.dava-rmd-text-output pre{max-height:28rem;overflow:auto;margin:0;background:#f4f6f7;padding:.8rem;font-size:.78rem}.dava-rmd-figure-output img{display:block;max-width:100%;height:auto;margin:auto;background:#fff}",
      "@media(max-width:900px){.dava-rmd-preview{grid-template-columns:1fr}.dava-rmd-toc{position:relative;max-height:none;border-right:0;border-bottom:1px solid #d9e1e4}.dava-rmd-paper{padding:1rem}.dava-rmd-code{font-size:12px}}",
      sep = ""))),
    htmltools::tags$article(class = "dava-rmd-preview rmarkdown-body", `data-dava-i18n-role` = "result",
      toc,
      htmltools::tags$main(class = "dava-rmd-paper",
        htmltools::tags$h1(class = "dava-rmd-title", document$metadata$title %||% "R analysis"),
        htmltools::tags$div(class = "dava-rmd-source", paste("Source:", document$metadata$source %||% "module code")),
        body))
  )
}

dava_code_document_panel_ui <- function(ns, prefix = "code_doc", rows = 30L) {
  tags$div(
    id = ns(paste0(prefix, "_document")),
    class = "dava-rmarkdown-source",
    `data-dava-i18n-role` = "result",
    shiny::uiOutput(ns(paste0(prefix, "_text")))
  )
}

dava_bind_code_document <- function(input, output, session, file_data,
                                    prefix, document, active = NULL) {
  document_value <- function() if (is.function(document)) document() else document
  active_value <- function() {
    if (is.null(active)) return(TRUE)
    if (is.function(active)) isTRUE(active()) else isTRUE(active)
  }
  rmd_value <- shiny::reactive({
    dava_code_document_rmd(document_value(), dava_code_settings(file_data))
  })
  output[[paste0(prefix, "_text")]] <- shiny::renderUI({
    shiny::req(active_value())
    dava_code_document_preview_html(document_value(), dava_code_settings(file_data))
  })
  invisible(list(document = shiny::reactive(document_value()), rmd = rmd_value))
}
