# Isolated external Shiny application plugins.

dava_external_plugin_root <- function(create = FALSE) {
  root <- getOption("dava.external_plugin_root",
    file.path(getwd(), "R", "plugin_apps"))
  root <- normalizePath(root, winslash = "/", mustWork = FALSE)
  if (isTRUE(create) && !dir.exists(root)) {
    dir.create(root, recursive = TRUE, showWarnings = FALSE)
  }
  root
}

dava_external_plugin_relative_path <- function(path, allow_empty = TRUE) {
  path <- trimws(gsub("\\\\", "/", as.character(path %||% "")[[1L]]))
  path <- gsub("/+", "/", path)
  path <- sub("^/+|/+$", "", path)
  if (!nzchar(path)) {
    if (isTRUE(allow_empty)) return("")
    stop("Directory name cannot be empty.", call. = FALSE)
  }
  parts <- strsplit(path, "/", fixed = TRUE)[[1L]]
  invalid <- parts %in% c("", ".", "..") |
    grepl('[<>:"|?*[:cntrl:]]', parts, perl = TRUE)
  if (any(invalid) || grepl("^[A-Za-z]:", path)) {
    stop("Directories can only use safe relative paths and cannot contain .., drive letters, or illegal Windows characters.",
      call. = FALSE)
  }
  paste(parts, collapse = "/")
}

dava_external_plugin_id <- function(id) {
  id <- trimws(as.character(id %||% "")[[1L]])
  id <- gsub("[^A-Za-z0-9_.-]+", "_", id)
  id <- gsub("^_+|_+$", "", id)
  if (!nzchar(id)) stop("Plugin ID cannot be empty.", call. = FALSE)
  id
}

dava_external_plugin_settings_file <- function() {
  file.path(dava_external_plugin_root(), ".dava-plugin-settings.json")
}

dava_external_plugin_settings <- function() {
  path <- dava_external_plugin_settings_file()
  value <- if (file.exists(path)) tryCatch(
    jsonlite::read_json(path, simplifyVector = TRUE),
    error = function(error) list()) else list()
  utils::modifyList(list(show_directory = FALSE), value %||% list())
}

dava_external_plugin_save_settings <- function(settings) {
  root <- dava_external_plugin_root(create = TRUE)
  path <- file.path(root, ".dava-plugin-settings.json")
  value <- utils::modifyList(dava_external_plugin_settings(), settings %||% list())
  jsonlite::write_json(value, path, auto_unbox = TRUE, pretty = TRUE)
  invisible(value)
}

dava_external_plugin_is_app <- function(path) {
  file.exists(file.path(path, "app.R")) ||
    all(file.exists(file.path(path, c("ui.R", "server.R"))))
}

dava_external_plugin_is_single_file_app <- function(path) {
  if (!file.exists(path) || tolower(tools::file_ext(path)) != "r") return(FALSE)
  code <- tryCatch(paste(readLines(path, warn = FALSE, encoding = "UTF-8"),
    collapse = "\n"), error = function(error) "")
  if (!nzchar(code)) return(FALSE)
  parsed <- tryCatch(parse(text = code, keep.source = FALSE),
    error = function(error) NULL)
  if (is.null(parsed)) return(FALSE)
  assigned <- character()
  calls <- character()
  walk <- function(value) {
    if (!is.call(value) && !is.expression(value) && !is.pairlist(value)) {
      return(invisible(NULL))
    }
    if (is.call(value)) {
      head <- if (is.symbol(value[[1L]])) as.character(value[[1L]]) else ""
      if (head %in% c("<-", "=") && length(value) >= 3L &&
          is.symbol(value[[2L]])) {
        assigned <<- c(assigned, as.character(value[[2L]]))
      }
      if (nzchar(head)) calls <<- c(calls, head)
    }
    elements <- as.list(value)
    for (index in seq_along(elements)) {
      if (!identical(elements[[index]], quote(expr = ))) {
        walk(elements[[index]])
      }
    }
    invisible(NULL)
  }
  walk(parsed)
  all(c("ui", "server") %in% assigned) && "shinyApp" %in% calls
}

dava_external_plugin_resolve_app <- function(path) {
  path <- normalizePath(path, winslash = "/", mustWork = TRUE)
  if (file.exists(path) && !dir.exists(path)) {
    if (!dava_external_plugin_is_single_file_app(path)) {
      stop("A single R file must define ui, server, and call shinyApp(ui, server).",
        call. = FALSE)
    }
    return(list(app_dir = dirname(path), main_file = path))
  }
  if (dava_external_plugin_is_app(path)) {
    return(list(app_dir = path, main_file = NULL))
  }
  directories <- list.dirs(path, recursive = TRUE, full.names = TRUE)
  standard <- directories[vapply(directories, dava_external_plugin_is_app,
    logical(1))]
  single_files <- list.files(path, pattern = "\\.[Rr]$", recursive = TRUE,
    full.names = TRUE)
  single_files <- single_files[vapply(single_files,
    dava_external_plugin_is_single_file_app, logical(1))]
  candidate_count <- length(standard) + length(single_files)
  if (candidate_count != 1L) {
    stop(paste0(
      "Source must contain a unique app.R, a unique set of ui.R/server.R,",
      "or the only R file that defines ui, server and shinyApp(ui, server)."),
      call. = FALSE)
  }
  if (length(standard)) return(list(app_dir = standard[[1L]], main_file = NULL))
  list(app_dir = dirname(single_files[[1L]]), main_file = single_files[[1L]])
}

dava_external_plugin_nav_value <- function(id, relative_dir) {
  key <- paste(relative_dir %||% "", id %||% "", sep = "/")
  suffix <- if (requireNamespace("digest", quietly = TRUE)) {
    substr(digest::digest(key, algo = "xxhash64"), 1L, 12L)
  } else {
    sprintf("%012d", sum(utf8ToInt(enc2utf8(key)) * seq_along(utf8ToInt(enc2utf8(key)))) %% 1e12)
  }
  paste0("external_plugin_", suffix)
}

dava_external_plugin_scan <- function(root = dava_external_plugin_root()) {
  empty <- data.frame(
    id = character(), title = character(), folder = character(),
    relative_dir = character(), app_dir = character(), nav_value = character(),
    description = character(), stringsAsFactors = FALSE, check.names = FALSE)
  if (!dir.exists(root)) return(empty)
  manifests <- list.files(root, pattern = "^plugin\\.json$", recursive = TRUE,
    full.names = TRUE, all.files = FALSE)
  if (!length(manifests)) return(empty)
  entries <- lapply(manifests, function(manifest_path) {
    app_dir <- dirname(manifest_path)
    if (!dava_external_plugin_is_app(app_dir)) return(NULL)
    manifest <- tryCatch(jsonlite::read_json(manifest_path, simplifyVector = TRUE),
      error = function(error) list())
    relative_dir <- substring(
      normalizePath(app_dir, winslash = "/", mustWork = TRUE),
      nchar(normalizePath(root, winslash = "/", mustWork = TRUE)) + 2L)
    parts <- strsplit(relative_dir, "/", fixed = TRUE)[[1L]]
    id <- dava_external_plugin_id(manifest$id %||% utils::tail(parts, 1L))
    folder <- if (length(parts) > 1L) paste(utils::head(parts, -1L), collapse = "/") else ""
    data.frame(
      id = id,
      title = manifest$title %||% id,
      folder = manifest$folder %||% folder,
      relative_dir = relative_dir,
      app_dir = normalizePath(app_dir, winslash = "/", mustWork = TRUE),
      nav_value = dava_external_plugin_nav_value(id, relative_dir),
      description = manifest$description %||% "",
      stringsAsFactors = FALSE, check.names = FALSE)
  })
  entries <- Filter(Negate(is.null), entries)
  if (!length(entries)) return(empty)
  value <- do.call(rbind, entries)
  value[order(value$folder, value$title), , drop = FALSE]
}

dava_external_plugin_folder_choices <- function(root = dava_external_plugin_root()) {
  folders <- if (dir.exists(root)) list.dirs(root, recursive = TRUE,
    full.names = TRUE) else character()
  root_norm <- normalizePath(root, winslash = "/", mustWork = FALSE)
  relative <- vapply(folders, function(path) {
    normalized <- normalizePath(path, winslash = "/", mustWork = FALSE)
    if (identical(normalized, root_norm)) "" else
      substring(normalized, nchar(root_norm) + 2L)
  }, character(1))
  relative <- relative[!grepl("(^|/)\\.", relative)]
  stats::setNames(relative, ifelse(nzchar(relative), relative, "Plug-in root directory"))
}

dava_external_plugin_create_folder <- function(relative_path) {
  relative_path <- dava_external_plugin_relative_path(relative_path,
    allow_empty = FALSE)
  root <- dava_external_plugin_root(create = TRUE)
  target <- do.call(file.path, as.list(c(root,
    strsplit(relative_path, "/", fixed = TRUE)[[1L]])))
  if (!dir.exists(target) && !dir.create(target, recursive = TRUE,
      showWarnings = FALSE)) {
    stop("Unable to create plugin directory.", call. = FALSE)
  }
  normalizePath(target, winslash = "/", mustWork = TRUE)
}

dava_external_plugin_find_app <- function(path) {
  dava_external_plugin_resolve_app(path)$app_dir
}

dava_external_plugin_rebuild_upload_folder <- function(upload, relative_paths,
                                                       destination) {
  if (is.null(upload) || !nrow(upload)) stop("Please select a local plug-in directory.",
    call. = FALSE)
  dir.create(destination, recursive = TRUE, showWarnings = FALSE)
  relative_paths <- unlist(relative_paths %||% character(), use.names = FALSE)
  if (length(relative_paths) != nrow(upload)) relative_paths <- upload$name
  for (index in seq_len(nrow(upload))) {
    relative <- gsub("\\\\", "/", relative_paths[[index]])
    relative <- sub("^[^/]+/", "", relative)
    parts <- strsplit(relative, "/", fixed = TRUE)[[1L]]
    if (!length(parts) || any(parts %in% c("", ".", "..")) ||
        any(grepl('[<>:"|?*[:cntrl:]]', parts, perl = TRUE))) {
      stop("The selected directory contains an unsafe file path.", call. = FALSE)
    }
    target <- do.call(file.path, as.list(c(destination, parts)))
    dir.create(dirname(target), recursive = TRUE, showWarnings = FALSE)
    if (!file.copy(upload$datapath[[index]], target, overwrite = TRUE)) {
      stop("Unable to rebuild the uploaded plugin directory.", call. = FALSE)
    }
  }
  destination
}

dava_external_plugin_directory_input <- function(ns, id, label) {
  control <- shiny::fileInput(ns(id), label, multiple = TRUE,
    buttonLabel = "Select folder", placeholder = "Please select the unzipped Shiny application folder")
  control <- htmltools::tagQuery(control)$find("input")$
    addAttrs(webkitdirectory = "webkitdirectory", directory = "directory")$
    allTags()
  input_id <- jsonlite::toJSON(ns(id), auto_unbox = TRUE)
  paths_id <- jsonlite::toJSON(ns(paste0(id, "_relative_paths")),
    auto_unbox = TRUE)
  shiny::tagList(control, shiny::tags$script(shiny::HTML(sprintf(
    "(function(){var el=document.getElementById(%s);if(!el||el.dataset.davaDirBound)return;el.dataset.davaDirBound='1';el.addEventListener('change',function(){var paths=Array.from(el.files||[]).map(function(file){return file.webkitRelativePath||file.name;});if(window.Shiny)Shiny.setInputValue(%s,paths,{priority:'event'});});})();",
    input_id, paths_id))))
}

dava_external_plugin_install <- function(source_dir, id, title,
                                         folder = "", description = "") {
  source_dir <- normalizePath(source_dir, winslash = "/", mustWork = TRUE)
  resolved <- dava_external_plugin_resolve_app(source_dir)
  source_dir <- resolved$app_dir
  id <- dava_external_plugin_id(id)
  folder <- dava_external_plugin_relative_path(folder)
  root <- dava_external_plugin_root(create = TRUE)
  parent <- if (nzchar(folder)) do.call(file.path, as.list(c(root,
    strsplit(folder, "/", fixed = TRUE)[[1L]]))) else root
  dir.create(parent, recursive = TRUE, showWarnings = FALSE)
  target <- file.path(parent, id)
  if (dir.exists(target) || file.exists(target)) {
    stop("The target plugin directory already exists; please use a new plugin ID.", call. = FALSE)
  }
  dir.create(target, recursive = FALSE, showWarnings = FALSE)
  source_items <- list.files(source_dir, all.files = TRUE, no.. = TRUE,
    full.names = TRUE)
  copied <- file.copy(source_items, target, recursive = TRUE,
    copy.mode = TRUE, copy.date = TRUE)
  if (length(copied) && !all(copied)) {
    stop("The plugin file failed to copy completely.", call. = FALSE)
  }
  if (!is.null(resolved$main_file)) {
    if (!file.copy(resolved$main_file, file.path(target, "app.R"),
        overwrite = TRUE, copy.mode = TRUE, copy.date = TRUE)) {
      stop("Unable to convert single R app to app.R.", call. = FALSE)
    }
  }
  manifest <- list(
    schema_version = "1.0", id = id, title = title %||% id,
    folder = folder, description = description %||% "",
    installed_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
    data_contract = "DAVA_PLUGIN_DATA_DIR/read-only-rds-v1")
  jsonlite::write_json(manifest, file.path(target, "plugin.json"),
    auto_unbox = TRUE, pretty = TRUE)
  invisible(target)
}

dava_external_plugin_output_id <- function(nav_value) {
  paste0("plugin_host_", sub("^external_plugin_", "", nav_value))
}

dava_external_plugin_nav_items <- function(entries, folder = "") {
  if (!nrow(entries)) return(list())
  direct <- entries[entries$folder == folder, , drop = FALSE]
  prefix <- if (nzchar(folder)) paste0(folder, "/") else ""
  descendants <- entries[startsWith(entries$folder, prefix) &
    entries$folder != folder, , drop = FALSE]
  child_names <- if (nrow(descendants)) {
    unique(vapply(strsplit(substring(descendants$folder,
      nchar(prefix) + 1L), "/", fixed = TRUE), `[[`, character(1), 1L))
  } else character()
  items <- lapply(sort(child_names), function(child) {
    child_path <- paste0(prefix, child)
    children <- dava_external_plugin_nav_items(entries, child_path)
    if (!length(children)) return(NULL)
    do.call(shiny::navbarMenu, c(list(title = child,
      menuName = paste0("plugin_folder_", gsub("[^A-Za-z0-9]+", "_", child_path))),
      children))
  })
  items <- Filter(Negate(is.null), items)
  leaves <- lapply(seq_len(nrow(direct)), function(index) {
    entry <- direct[index, , drop = FALSE]
    bslib::nav_panel(entry$title[[1L]], value = entry$nav_value[[1L]],
      shiny::uiOutput(dava_external_plugin_output_id(entry$nav_value[[1L]])))
  })
  c(items, leaves)
}

dava_external_plugin_nav <- function(entries = dava_external_plugin_scan()) {
  if (!nrow(entries)) return(NULL)
  items <- dava_external_plugin_nav_items(entries)
  if (!length(items)) return(NULL)
  do.call(shiny::navbarMenu, c(list(title = "Plug-in directory",
    menuName = "plugin_directory"), items))
}

dava_external_plugin_safe_name <- function(name, index) {
  value <- gsub("[^A-Za-z0-9_.-]+", "_", name %||% "")
  value <- gsub("^_+|_+$", "", value)
  if (!nzchar(value)) value <- paste0("dataset_", index)
  paste0(sprintf("%03d_", index), value, ".rds")
}

dava_external_plugin_start <- function(entry, datasets = list()) {
  if (!requireNamespace("callr", quietly = TRUE)) {
    stop("Launching external Shiny plugins requires the callr package.", call. = FALSE)
  }
  run_dir <- tempfile(paste0("dava-plugin-", entry$id[[1L]], "-"))
  app_copy <- file.path(run_dir, "app")
  data_copy <- file.path(run_dir, "data")
  dir.create(app_copy, recursive = TRUE, showWarnings = FALSE)
  dir.create(data_copy, recursive = TRUE, showWarnings = FALSE)
  app_items <- list.files(entry$app_dir[[1L]], all.files = TRUE, no.. = TRUE,
    full.names = TRUE)
  copied <- file.copy(app_items, app_copy, recursive = TRUE,
    copy.mode = TRUE, copy.date = TRUE)
  if (length(copied) && !all(copied)) stop("Unable to create a copy of the plug-in application.", call. = FALSE)

  manifest <- data.frame(dataset = character(), file = character(),
    class = character(), stringsAsFactors = FALSE)
  if (length(datasets)) {
    dataset_names <- names(datasets)
    if (is.null(dataset_names)) dataset_names <- rep("", length(datasets))
    for (index in seq_along(datasets)) {
      name <- dataset_names[[index]]
      if (!nzchar(name)) name <- paste0("dataset_", index)
      file_name <- dava_external_plugin_safe_name(name, index)
      path <- file.path(data_copy, file_name)
      saved <- tryCatch({saveRDS(datasets[[index]], path); TRUE},
        error = function(error) FALSE)
      if (saved) manifest <- rbind(manifest, data.frame(
        dataset = name, file = file_name,
        class = paste(class(datasets[[index]]), collapse = "/"),
        stringsAsFactors = FALSE))
    }
  }
  utils::write.csv(manifest, file.path(data_copy, "manifest.csv"),
    row.names = FALSE, fileEncoding = "UTF-8")
  Sys.chmod(list.files(data_copy, full.names = TRUE, recursive = TRUE), "0444")

  port <- httpuv::randomPort()
  stdout <- file.path(run_dir, "plugin.stdout.log")
  stderr <- file.path(run_dir, "plugin.stderr.log")
  process <- callr::r_bg(
    function(app_dir, port) {
      options(shiny.port = port, shiny.host = "127.0.0.1")
      shiny::runApp(app_dir, host = "127.0.0.1", port = port,
        launch.browser = FALSE)
    },
    args = list(app_copy, port), wd = run_dir,
    stdout = stdout, stderr = stderr,
    env = c(
      DAVA_PLUGIN_MODE = "isolated-readonly-copy",
      DAVA_PLUGIN_DATA_DIR = data_copy,
      DAVA_PLUGIN_DATA_MANIFEST = file.path(data_copy, "manifest.csv"),
      DAVA_PLUGIN_ID = entry$id[[1L]]))
  structure(list(
    process = process, port = port, url = paste0("http://127.0.0.1:", port),
    run_dir = run_dir, data_dir = data_copy, stdout = stdout, stderr = stderr,
    entry = entry), class = "dava_external_plugin_process")
}

dava_external_plugin_stop <- function(instance) {
  if (is.null(instance)) return(invisible(FALSE))
  process <- instance$process %||% NULL
  if (!is.null(process) && isTRUE(tryCatch(process$is_alive(),
      error = function(error) FALSE))) {
    try(process$kill(), silent = TRUE)
  }
  run_dir <- instance$run_dir %||% ""
  if (nzchar(run_dir) && dir.exists(run_dir) &&
      startsWith(normalizePath(run_dir, winslash = "/", mustWork = TRUE),
        normalizePath(tempdir(), winslash = "/", mustWork = TRUE))) {
    Sys.chmod(list.files(run_dir, recursive = TRUE, full.names = TRUE,
      include.dirs = TRUE), "0777")
    unlink(run_dir, recursive = TRUE, force = TRUE)
  }
  invisible(TRUE)
}

dava_external_plugin_logs <- function(instance, lines = 200L) {
  if (is.null(instance)) return("")
  paths <- c(instance$stdout, instance$stderr)
  text <- unlist(lapply(paths[file.exists(paths)], function(path) {
    utils::tail(readLines(path, warn = FALSE, encoding = "UTF-8"), lines)
  }), use.names = FALSE)
  paste(text, collapse = "\n")
}
