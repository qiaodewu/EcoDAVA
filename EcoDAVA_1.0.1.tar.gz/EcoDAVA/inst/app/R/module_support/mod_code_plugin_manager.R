# Central code-display settings and isolated external Shiny plugin management.

mod_code_plugin_manager_ui <- function(id, mode = c("code", "plugin")) {
  mode <- match.arg(mode)
  ns <- shiny::NS(id)
  if (identical(mode, "code")) {
    return(bslib::page_sidebar(
      title = "R Markdown code documents",
      sidebar = bslib::sidebar(width = 280,
        shiny::tags$strong("Analysis method"),
        shiny::uiOutput(ns("manager_method_picker")),
        shiny::tags$div(class = "small text-muted mt-2",
          "Documents are read-only and follow the original main-analysis implementation.")
      ),
      dava_code_document_panel_ui(ns, "manager_code", rows = 34)
    ))
  }

  bslib::page_sidebar(
    title = "Plug-in management",
    sidebar = bslib::sidebar(width = 340,
      shiny::tags$strong("External Shiny application"),
      shiny::checkboxInput(ns("external_show_directory"),
        "Display \"Plugin Directory\" in the main navigation", FALSE),
      shiny::textInput(ns("external_new_folder"), "Create new plug-in folder",
        placeholder = "For example File1/F1"),
      shiny::actionButton(ns("external_create_folder"), "Create folder",
        icon = shiny::icon("folder-plus"), class = "btn-outline-primary w-100"),
      shiny::uiOutput(ns("external_folder_picker")),
      shiny::radioButtons(ns("external_source_type"), "Plug-in source",
        choices = c("Unzip the folder" = "folder", "ZIP or single R file" = "archive"),
        selected = "folder", inline = TRUE),
      shiny::conditionalPanel(
        condition = sprintf("input['%s'] === 'folder'", ns("external_source_type")),
        dava_external_plugin_directory_input(ns, "external_source_folder",
          "Local Shiny application directory")),
      shiny::conditionalPanel(
        condition = sprintf("input['%s'] === 'archive'", ns("external_source_type")),
        shiny::fileInput(ns("external_archive"), "Upload application ZIP or single R file",
          accept = c(".zip", ".R", ".r"))),
      shiny::textInput(ns("external_id"), "Plugin ID", "shiny_plugin"),
      shiny::textInput(ns("external_title"), "Plug-in name", "External Shiny application"),
      shiny::textAreaInput(ns("external_description"), "Plug-in description", rows = 2),
      shiny::actionButton(ns("external_install"), "Install to selected folder",
        icon = shiny::icon("box-archive"), class = "btn-primary w-100"),
      shiny::uiOutput(ns("external_plugin_picker")),
      shiny::actionButton(ns("external_launch"), "Isolated startup",
        icon = shiny::icon("play"), class = "btn-success w-100"),
      shiny::actionButton(ns("external_stop"), "Stop application",
        icon = shiny::icon("stop"), class = "btn-outline-danger w-100 mt-2"),
      shiny::actionButton(ns("external_refresh"), "Refresh the plug-in directory",
        icon = shiny::icon("rotate"), class = "btn-outline-secondary w-100 mt-2"),
      shiny::uiOutput(ns("external_status")),
      shiny::tags$div(class = "alert alert-info py-2 px-2 small",
        "The plugin runs in a separate R process. Global data is only provided as a read-only RDS copy in the system temporary directory, and the plug-in does not obtain the main session reactive object.")
    ),
    bslib::navset_card_tab(
      bslib::nav_panel("External application directory", DT::DTOutput(ns("external_tree"))),
      bslib::nav_panel("External application manifest", DT::DTOutput(ns("external_table"))),
      bslib::nav_panel("External application preview", shiny::uiOutput(ns("external_preview"))),
      bslib::nav_panel("External application log", shiny::verbatimTextOutput(ns("external_log")))
    )
  )
}

mod_code_plugin_manager_server <- function(id, file_data, mode = c("code", "plugin")) {
  mode <- match.arg(mode)
  shiny::moduleServer(id, function(input, output, session) {
    root_input <- session$rootScope()$input
    interface_language <- shiny::reactive({
      root_input$dava_interface_language
      dava_i18n_language(root_input$dava_interface_language)
    })
    tr <- function(text) dava_translate_text(text, interface_language())
    tr_generated <- function(text) dava_translate_composed(text, interface_language())
    if (identical(mode, "code")) {
      selected_method_entry <- shiny::reactive({
        file_data$method_code_revision %||% 0L
        file_data$method_code_runtime_revision %||% 0L
        key <- input$manager_method_key %||% ""
        if (!nzchar(key)) return(NULL)
        dava_method_code_get(file_data, key)
      })
      output$manager_method_picker <- shiny::renderUI({
        interface_language()
        file_data$method_code_revision %||% 0L
        methods <- dava_method_code_table(file_data)
        choices <- if (nrow(methods)) stats::setNames(
          methods$method_key,
          paste(tr_generated(methods$source), tr_generated(methods$title), sep = " / ")
        ) else character()
        shiny::selectInput(session$ns("manager_method_key"), tr("Analysis method"),
          choices = choices,
          selected = input$manager_method_key %||% utils::head(choices, 1L))
      })
      selected_entry <- shiny::reactive({
        path <- input$manager_code_path %||% ""
        dava_code_get(file_data, path)
      })
      output$manager_code_picker <- shiny::renderUI({
        interface_language()
        entries <- dava_code_registry_table(file_data)
        choices <- if (nrow(entries)) stats::setNames(entries$path,
          paste(tr_generated(entries$source), tr_generated(entries$title), sep = " / ")) else character()
        shiny::selectInput(session$ns("manager_code_path"), tr("Code record"),
          choices = choices, selected = input$manager_code_path %||% utils::head(choices, 1L))
      })
      manager_document <- shiny::reactive({
        method_entry <- selected_method_entry()
        implementation <- input$manager_implementation %||% "original"
        entry <- selected_entry()
        code <- if (!is.null(method_entry)) {
          if (identical(implementation, "custom")) {
            method_entry$custom_code %||% "# The current method is stillNoneApplied user customizationsCode。"
          } else {
            method_entry$original_code %||% "# The current method has not registered the originalCode。"
          }
        } else {
          entry$code %||% "# Run analysisorDrawingAfter，Code recordwill be displayed here。"
        }
        dava_code_document(code, file_data = file_data,
          title = method_entry$title %||% entry$title %||% "Code record",
          source = method_entry$source %||% entry$source %||% "DAVA")
      })
      dava_bind_code_document(input, output, session, file_data,
        "manager_code", manager_document)
      output$manager_code_table <- DT::renderDT({
        input$manager_refresh
        table <- dava_code_registry_table(file_data)
        interface_columns <- intersect(
          c("source", "title", "kind", "status", "modification_level"), names(table)
        )
        table[interface_columns] <- lapply(
          table[interface_columns], tr_generated
        )
        DT::datatable(table, rownames = FALSE,
          filter = "top", options = list(scrollX = TRUE, pageLength = 25))
      })
      output$manager_method_table <- DT::renderDT({
        file_data$method_code_revision %||% 0L
        file_data$method_code_runtime_revision %||% 0L
        table <- dava_method_code_table(file_data)
        interface_columns <- intersect(
          c("source", "title", "status", "modification_level"), names(table)
        )
        table[interface_columns] <- lapply(
          table[interface_columns], tr_generated
        )
        DT::datatable(table, rownames = FALSE,
          filter = "top", options = list(scrollX = TRUE, pageLength = 25))
      })
      output$manager_method_status <- shiny::renderUI({
        interface_language()
        entry <- selected_method_entry()
        if (is.null(entry)) return(shiny::tags$div(
          class = "small text-muted mt-2", tr("There are no registered analytical methods.")))
        shiny::tags$div(
          class = paste("alert py-2 px-2 small mt-2 mb-0",
            if (isTRUE(entry$enabled)) "alert-success" else "alert-secondary"),
          shiny::tags$strong(if (isTRUE(entry$enabled))
            tr("User-defined methods enabled") else tr("Currently using the original method")),
          shiny::tags$div(if (isTRUE(entry$custom_validated))
            paste0(tr("Custom implementation verified; applied at:"), entry$applied_at %||% "-")
          else tr("There is no verified custom implementation enabled yet.")),
          shiny::tags$div(paste0(
            tr("Contract version:"), entry$manifest$contract_version %||% "1.0",
            tr(";Modification level:"), tr(entry$custom_level %||%
              entry$tested_level %||% "Not tested"))),
          if (nzchar(entry$test_error %||% ""))
            shiny::tags$div(class = "text-danger", entry$test_error),
          if (as.integer(entry$runtime_failure_count %||% 0L) > 0L)
            shiny::tags$div(class = "text-warning", paste0(
              tr("Continuous operation failed:"), entry$runtime_failure_count, tr(" times;"),
              entry$last_runtime_error %||% entry$disabled_reason %||% ""))
        )
      })
      shiny::observe({
        entry <- selected_method_entry()
        if (is.null(entry)) return()
        implementation <- if (isTRUE(entry$enabled)) "custom" else "original"
        shiny::updateRadioButtons(session, "manager_implementation",
          selected = implementation)
        shiny::updateCheckboxInput(session, "manager_method_enabled",
          value = isTRUE(entry$enabled))
      })
      apply_selected_method <- function() {
        key <- input$manager_method_key %||% ""
        if (!nzchar(key)) {
          shiny::showNotification("Please select an analysis method.", type = "warning")
          return(invisible(FALSE))
        }
        tryCatch({
          use_custom <- identical(input$manager_implementation, "custom") &&
            isTRUE(input$manager_method_enabled)
          if (use_custom) dava_method_code_enable(file_data, key)
          else dava_method_code_disable(file_data, key)
          shiny::showNotification(if (use_custom)
            "User-defined implementation has been enabled for the selected method." else
            "The original implementation has been restored for the selected method.", type = "message")
          invisible(TRUE)
        }, error = function(error) {
          shiny::showNotification(conditionMessage(error), type = "error", duration = 6)
          invisible(FALSE)
        })
      }
      shiny::observeEvent(input$manager_apply_method, apply_selected_method())
      shiny::observeEvent(input$manager_method_enabled, {
        entry <- selected_method_entry()
        if (is.null(entry) ||
            identical(isTRUE(input$manager_method_enabled), isTRUE(entry$enabled))) {
          return()
        }
        if (isTRUE(input$manager_method_enabled) &&
            !identical(input$manager_implementation, "custom")) {
          shiny::updateCheckboxInput(session, "manager_method_enabled", value = FALSE)
          shiny::showNotification("Please select \"User-defined method\" first.", type = "warning")
          return()
        }
        apply_selected_method()
      }, ignoreInit = TRUE)
      shiny::observeEvent(input$manager_restore_method, {
        key <- input$manager_method_key %||% ""
        if (nzchar(key)) dava_method_code_disable(file_data, key)
      })
      apply_settings <- function(settings) {
        file_data$code_settings <- settings
        shiny::updateSelectInput(session, "code_theme", selected = settings$theme)
        shiny::updateNumericInput(session, "code_font_size", value = settings$font_size)
        shiny::updateNumericInput(session, "code_tab_size", value = settings$tab_size)
        shiny::updateCheckboxInput(session, "code_line_wrap", value = settings$line_wrap)
        shiny::updateCheckboxInput(session, "code_show_packages", value = settings$show_packages)
        shiny::updateCheckboxInput(session, "code_show_data", value = settings$show_data)
        shiny::updateCheckboxInput(session, "code_show_functions", value = settings$show_functions)
        shiny::updateCheckboxInput(session, "code_show_comments", value = settings$show_comments)
      }
      shiny::observeEvent(TRUE, apply_settings(dava_code_settings(file_data)), once = TRUE)
      shiny::observeEvent(input$apply_code_settings, {
        apply_settings(list(
          theme = input$code_theme, font_size = as.integer(input$code_font_size),
          tab_size = as.integer(input$code_tab_size), line_wrap = isTRUE(input$code_line_wrap),
          show_packages = isTRUE(input$code_show_packages), show_data = isTRUE(input$code_show_data),
          show_functions = isTRUE(input$code_show_functions), show_comments = isTRUE(input$code_show_comments)
        ))
        shiny::showNotification("The code shows that settings have been applied to all modules.", type = "message")
      })
      shiny::observeEvent(input$reset_code_settings, apply_settings(dava_code_settings_defaults()))
      apply_return_settings <- function(settings) {
        settings <- utils::modifyList(
          dava_code_return_settings_defaults(), settings %||% list())
        file_data$code_return_settings <- settings
        shiny::updateSelectInput(session, "code_return_policy",
          selected = settings$policy)
        shiny::updateCheckboxInput(session, "code_allow_file_io",
          value = isTRUE(settings$allow_file_io))
        shiny::updateCheckboxInput(session, "code_allow_network",
          value = isTRUE(settings$allow_network))
        shiny::updateCheckboxInput(session, "code_allow_external_process",
          value = isTRUE(settings$allow_external_process))
        shiny::updateNumericInput(session, "code_max_runtime_failures",
          value = as.integer(settings$max_runtime_failures %||% 3L))
      }
      shiny::observeEvent(TRUE,
        apply_return_settings(dava_code_return_settings(file_data)), once = TRUE)
      shiny::observeEvent(input$apply_code_return_settings, {
        apply_return_settings(list(
          policy = input$code_return_policy %||% "standard",
          allow_file_io = isTRUE(input$code_allow_file_io),
          allow_network = isTRUE(input$code_allow_network),
          allow_external_process = isTRUE(input$code_allow_external_process),
          max_runtime_failures = max(1L,
            as.integer(input$code_max_runtime_failures %||% 3L))
        ))
        shiny::showNotification(
          "Code passback rules have been applied to all modules.", type = "message")
      })
      shiny::observeEvent(input$reset_code_return_settings,
        apply_return_settings(dava_code_return_settings_defaults()))
      return(invisible(NULL))
    }

    plugin_state <- shiny::reactiveValues(
      external_instance = NULL, external_error = "")
    external_revision <- shiny::reactiveVal(0L)
    refresh_external <- function() {
      external_revision(external_revision() + 1L)
      file_data$external_plugin_revision <- shiny::isolate(
        as.integer(file_data$external_plugin_revision %||% 0L) + 1L)
      invisible(TRUE)
    }
    external_entries <- shiny::reactive({
      external_revision()
      dava_external_plugin_scan()
    })
    shiny::observeEvent(TRUE, {
      shiny::updateCheckboxInput(session, "external_show_directory",
        value = isTRUE(dava_external_plugin_settings()$show_directory))
    }, once = TRUE)
    shiny::observeEvent(input$external_show_directory, {
      dava_external_plugin_save_settings(list(
        show_directory = isTRUE(input$external_show_directory)))
      refresh_external()
    }, ignoreInit = TRUE)
    output$external_folder_picker <- shiny::renderUI({
      external_revision()
      shiny::selectInput(session$ns("external_folder"), "Installation target folder",
        choices = dava_external_plugin_folder_choices(), selected = "")
    })
    output$external_plugin_picker <- shiny::renderUI({
      entries <- external_entries()
      choices <- if (nrow(entries)) stats::setNames(entries$nav_value,
        paste(ifelse(nzchar(entries$folder), entries$folder, "Plug-in root directory"),
          entries$title, sep = " / ")) else character()
      shiny::selectInput(session$ns("external_selected"), "External application installed",
        choices = choices)
    })
    shiny::observeEvent(input$external_create_folder, {
      tryCatch({
        dava_external_plugin_create_folder(input$external_new_folder)
        refresh_external()
        shiny::showNotification("Plugin folder created.", type = "message")
      }, error = function(error) shiny::showNotification(
        conditionMessage(error), type = "error", duration = 6))
    })
    shiny::observeEvent(input$external_install, {
      temporary_source <- NULL
      tryCatch({
        source_type <- input$external_source_type %||% "folder"
        temporary_source <- tempfile("dava-plugin-upload-")
        dir.create(temporary_source, recursive = TRUE)
        if (identical(source_type, "folder")) {
          source <- dava_external_plugin_rebuild_upload_folder(
            input$external_source_folder,
            input$external_source_folder_relative_paths,
            temporary_source)
        } else {
          upload <- input$external_archive
          if (is.null(upload) || !nzchar(upload$datapath %||% "")) {
            stop("Please select a ZIP or single R file.", call. = FALSE)
          }
          extension <- tolower(tools::file_ext(upload$name %||% ""))
          if (identical(extension, "zip")) {
            utils::unzip(upload$datapath, exdir = temporary_source)
            source <- temporary_source
          } else if (identical(extension, "r")) {
            source <- file.path(temporary_source, upload$name)
            if (!file.copy(upload$datapath, source, overwrite = TRUE)) {
              stop("Unable to read uploaded R file.", call. = FALSE)
            }
          } else {
            stop("Only supports ZIP or R files.", call. = FALSE)
          }
        }
        dava_external_plugin_install(source, input$external_id,
          input$external_title, input$external_folder %||% "",
          input$external_description)
        refresh_external()
        shiny::showNotification("External Shiny application installed.", type = "message")
      }, error = function(error) {
        plugin_state$external_error <- conditionMessage(error)
        shiny::showNotification(conditionMessage(error), type = "error",
          duration = 8)
      }, finally = {
        if (!is.null(temporary_source) && dir.exists(temporary_source)) {
          unlink(temporary_source, recursive = TRUE, force = TRUE)
        }
      })
    })
    shiny::observeEvent(input$external_refresh, refresh_external())
    selected_external <- shiny::reactive({
      entries <- external_entries()
      entries[entries$nav_value == (input$external_selected %||% ""), ,
        drop = FALSE]
    })
    stop_external_preview <- function(clear_state = TRUE) {
      instance <- shiny::isolate(plugin_state$external_instance)
      dava_external_plugin_stop(instance)
      if (isTRUE(clear_state)) plugin_state$external_instance <- NULL
      invisible(TRUE)
    }
    shiny::observeEvent(input$external_launch, {
      entry <- selected_external()
      if (!nrow(entry)) {
        shiny::showNotification("Please select an installed external application.", type = "warning")
        return()
      }
      stop_external_preview()
      tryCatch({
        datasets <- shiny::isolate(file_data$global_datasets %||% list())
        plugin_state$external_instance <- dava_external_plugin_start(entry, datasets)
        plugin_state$external_error <- ""
        shiny::showNotification("An external application has been started in the quarantine process.", type = "message")
      }, error = function(error) {
        plugin_state$external_error <- conditionMessage(error)
        shiny::showNotification(conditionMessage(error), type = "error",
          duration = 8)
      })
    })
    shiny::observeEvent(input$external_stop, stop_external_preview())
    session$onSessionEnded(function() stop_external_preview(clear_state = FALSE))
    output$external_preview <- shiny::renderUI({
      instance <- plugin_state$external_instance
      if (is.null(instance)) return(shiny::tags$div(
        class = "p-4 text-muted", "Please select the application and click \"Isolate Start\"."))
      shiny::tags$iframe(src = instance$url, title = instance$entry$title[[1L]],
        style = "width:100%;height:760px;border:0;background:white;")
    })
    output$external_log <- shiny::renderText({
      paste(c(plugin_state$external_error,
        dava_external_plugin_logs(plugin_state$external_instance)),
        collapse = "\n")
    })
    output$external_status <- shiny::renderUI({
      instance <- plugin_state$external_instance
      running <- !is.null(instance) && isTRUE(tryCatch(
        instance$process$is_alive(), error = function(error) FALSE))
      shiny::tags$div(class = paste("alert py-2 px-2 small mt-2",
        if (running) "alert-success" else "alert-secondary"),
        if (running) paste0("Running:", instance$entry$title[[1L]],
          "（", instance$url, "）") else "There are currently no external applications running.")
    })
    output$external_table <- DT::renderDT({
      DT::datatable(external_entries()[, setdiff(names(external_entries()),
        "app_dir"), drop = FALSE], rownames = FALSE,
        options = list(scrollX = TRUE, pageLength = 25))
    })
    output$external_tree <- DT::renderDT({
      entries <- external_entries()
      tree <- if (nrow(entries)) data.frame(
        path = file.path(ifelse(nzchar(entries$folder), entries$folder, "."),
          entries$title), type = "Shiny application", id = entries$id,
        stringsAsFactors = FALSE) else data.frame(
          path = character(), type = character(), id = character())
      DT::datatable(tree, rownames = FALSE,
        options = list(scrollX = TRUE, pageLength = 25))
    })
  })
}
