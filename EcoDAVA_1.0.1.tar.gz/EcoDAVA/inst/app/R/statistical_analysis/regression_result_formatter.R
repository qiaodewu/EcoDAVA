# All regression adapters return the same structure；page、Download andDataRegister to consume only theobject。
new_regression_result <- function(...) {
  defaults <- list(
    status = "error", method_id = "", method_name = "", response_structure = "single",
    predictor_structure = "univariate", responses = character(), predictors = character(),
    focus_predictor = "", group_var = "", random_effects = character(), formula = "",
    readable_formula = "", numeric_equation = "", model = NULL, grouped_models = list(),
    model_data = data.frame(), data_summary = data.frame(), coefficients = data.frame(),
    collinearity = data.frame(), variable_selection = data.frame(),
    overall_tests = data.frame(), fit_metrics = data.frame(), group_effects = data.frame(),
    settings = list(), prediction_settings = list(), actual_rows = integer(), effect_sizes = data.frame(),
    fixed_effects = data.frame(), random_effects_table = data.frame(), variance_components = data.frame(),
    smooth_terms = data.frame(), thresholds = data.frame(), nonlinear_parameters = data.frame(),
    conditional_model = data.frame(), zero_inflation_model = data.frame(), dispersion_model = data.frame(),
    mediation_results = data.frame(), moderation_results = data.frame(), multiple_comparisons = data.frame(),
    slope_comparisons = data.frame(), predictions = data.frame(), adjusted_predictions = data.frame(),
    marginal_predictions = data.frame(), conditional_predictions = data.frame(),
    observed_fitted = data.frame(), diagnostics = data.frame(), loadings = data.frame(),
    scores = data.frame(), variable_importance = data.frame(), plots = list(), code = "",
    vip = data.frame(), coefficient_path = data.frame(), community_results = data.frame(),
    feature_results = data.frame(), microbiome_results = data.frame(), filter_records = data.frame(), package_versions = data.frame(),
    model_text = "", warnings = character(), errors = character(), metadata = list()
  )
  supplied <- list(...)
  values <- defaults
  values[names(supplied)] <- supplied
  class(values) <- c("dava_regression_result", "list")
  values
}

regression_legacy_result <- function(result) {
  stopifnot(inherits(result, "dava_regression_result"))
  diagnostic_table <- result$diagnostics
  if (!nrow(diagnostic_table)) diagnostic_table <- result$loadings
  if (!nrow(diagnostic_table)) diagnostic_table <- result$variable_importance
  list(
    summary = result$fit_metrics,
    result = result$coefficients,
    diagnostics = diagnostic_table,
    scores = result$observed_fitted,
    importance = result$variable_importance,
    loadings = result$loadings,
    formula = result$formula,
    model_text = result$model_text,
    model = result$model,
    model_data = result$model_data,
    plot = result$plots$primary %||% NULL,
    regression_result = result,
    errors = data.frame(error = result$errors, stringsAsFactors = FALSE)
  )
}

regression_result_datasets <- function(result) {
  tables <- list(
    data_summary = result$data_summary,
    coefficients = result$coefficients,
    collinearity = result$collinearity,
    variable_selection = result$variable_selection,
    fixed_effects = result$fixed_effects,
    random_effects = result$random_effects_table,
    variance_components = result$variance_components,
    smooth_terms = result$smooth_terms,
    thresholds = result$thresholds,
    nonlinear_parameters = result$nonlinear_parameters,
    conditional_model = result$conditional_model,
    zero_inflation_model = result$zero_inflation_model,
    dispersion_model = result$dispersion_model,
    mediation_results = result$mediation_results,
    moderation_results = result$moderation_results,
    overall_tests = result$overall_tests,
    fit_metrics = result$fit_metrics,
    group_effects = result$group_effects,
    slope_comparisons = result$slope_comparisons,
    predictions = result$predictions,
    adjusted_predictions = result$adjusted_predictions,
    marginal_predictions = result$marginal_predictions,
    conditional_predictions = result$conditional_predictions,
    observed_fitted = result$observed_fitted,
    diagnostics = result$diagnostics,
    loadings = result$loadings,
    scores = result$scores,
    variable_importance = result$variable_importance,
    vip = result$vip,
    coefficient_path = result$coefficient_path,
    community_results = result$community_results,
    feature_results = result$feature_results,
    filter_records = result$filter_records,
    microbiome_results = result$microbiome_results,
    package_versions = result$package_versions,
    errors = data.frame(error = result$errors, stringsAsFactors = FALSE)
  )
  tables[vapply(tables, function(x) is.data.frame(x) && nrow(x) > 0L, logical(1))]
}

regression_available_result_tables <- function(result) {
  if (!inherits(result, "dava_regression_result")) return(list())
  candidates <- list(
    coefficients = result$coefficients,
    collinearity = result$collinearity,
    variable_selection = result$variable_selection,
    overall_tests = result$overall_tests,
    fit_metrics = result$fit_metrics,
    fixed_effects = result$fixed_effects,
    random_effects = result$random_effects_table,
    variance_components = result$variance_components,
    smooth_terms = result$smooth_terms,
    thresholds = result$thresholds,
    nonlinear_parameters = result$nonlinear_parameters,
    conditional_model = result$conditional_model,
    zero_inflation_model = result$zero_inflation_model,
    dispersion_model = result$dispersion_model,
    slope_comparisons = result$slope_comparisons,
    mediation_results = result$mediation_results,
    moderation_results = result$moderation_results,
    community_results = result$community_results,
    feature_results = result$feature_results,
    filter_records = result$filter_records,
    microbiome_results = result$microbiome_results
  )
  candidates[vapply(candidates, function(x) is.data.frame(x) && nrow(x) > 0L, logical(1))]
}

regression_prediction_table <- function(result) {
  tables <- list(
    raw_fitted = result$observed_fitted,
    adjusted = result$adjusted_predictions,
    marginal = result$marginal_predictions,
    conditional = result$conditional_predictions
  )
  tables <- tables[vapply(tables, function(x) is.data.frame(x) && nrow(x) > 0L, logical(1))]
  if (!length(tables)) return(data.frame())
  dplyr::bind_rows(lapply(names(tables), function(type) {
    value <- tables[[type]]
    value$prediction_type <- type
    value
  }))
}

regression_excel_sheet_names <- function(names_in) {
  clean <- gsub("[\\[\\]:*?/\\\\]", "_", names_in)
  clean[!nzchar(clean)] <- "Sheet"
  output <- character(length(clean))
  used <- character()
  for (i in seq_along(clean)) {
    base <- substr(clean[i], 1L, 31L)
    candidate <- base
    suffix <- 1L
    while (candidate %in% used) {
      suffix <- suffix + 1L
      tail <- paste0("_", suffix)
      candidate <- paste0(substr(base, 1L, 31L - nchar(tail)), tail)
    }
    output[i] <- candidate
    used <- c(used, candidate)
  }
  output
}

regression_xlsx_sheets <- function(result) {
  stopifnot(inherits(result, "dava_regression_result"))
  setting_values <- vapply(result$settings, function(value) paste(capture.output(dput(value)), collapse = " "), character(1))
  sheets <- c(list(
    analysis_settings = data.frame(setting = names(setting_values), value = unname(setting_values), stringsAsFactors = FALSE),
    formulas = data.frame(
      type = c("R formula", "readable formula", "numeric equation"),
      value = c(result$formula, result$readable_formula, result$numeric_equation), stringsAsFactors = FALSE
    )
  ), regression_result_datasets(result), list(
    warnings = data.frame(message = result$warnings, stringsAsFactors = FALSE),
    generated_code = data.frame(code = result$code, stringsAsFactors = FALSE)
  ))
  sheets <- sheets[vapply(sheets, function(x) is.data.frame(x) && nrow(x) > 0L, logical(1))]
  names(sheets) <- regression_excel_sheet_names(names(sheets))
  sheets
}

regression_numeric_equation <- function(model, response, group_var = "") {
  if (!inherits(model, c("lm", "glm"))) return("")
  co <- stats::coef(model)
  co <- co[is.finite(co)]
  if (!length(co)) return("")
  terms <- names(co)
  pieces <- sprintf("%+.6g * %s", unname(co), terms)
  pieces[terms == "(Intercept)"] <- sprintf("%.6g", unname(co[terms == "(Intercept)"]))
  link <- if (inherits(model, "glm")) stats::family(model)$link else "identity"
  lhs <- if (identical(link, "identity")) response else sprintf("%s(E[%s])", link, response)
  paste(lhs, "=", paste(pieces, collapse = " "))
}
