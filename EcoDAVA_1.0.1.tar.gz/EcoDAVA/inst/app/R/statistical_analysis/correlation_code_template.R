correlation_code_template <- function(analysis_type, input, workspace_data = FALSE) {
  r_value <- function(value) paste(deparse(value, width.cutoff = 500L), collapse = "")
  variables <- unique(as.character(input$x_vars %||% character()))
  group_variable <- if (isTRUE(input$group_enabled)) as.character(input$group_var %||% "") else ""
  correlation_method <- as.character(input$cor_method %||% "pearson")
  edge_threshold <- suppressWarnings(as.numeric(input$edge_threshold %||% 0.6))[1]
  if (!is.finite(edge_threshold)) edge_threshold <- 0.6
  network <- identical(analysis_type, "network_correlation")
  data_code <- if (isTRUE(workspace_data)) {
    "df <- analysis_input_data\n"
  } else if (identical(input$dataset_select_input %||% "__demo__", "__demo__")) {
    paste0(dava_local_demo_code("statistics/advanced_analysis.rds", "df"), "\n")
  } else {
    paste0("df <- get_dataset(", r_value(input$dataset_select_input %||% ""), ")\n")
  }

  analysis_lines <- c(
    "# ---- Analysis: method-specific correlation workflow ----",
    paste0("variables <- ", r_value(variables), " # <DAVA-UI-PARAM>"),
    paste0("group_variable <- ", r_value(group_variable), " # <DAVA-UI-PARAM>"),
    paste0("correlation_method <- ", r_value(correlation_method), " # <DAVA-UI-PARAM>"),
    if (network) paste0("edge_threshold <- ", r_value(edge_threshold), " # <DAVA-UI-PARAM>") else NULL,
    paste0("edge_limit <- ", if (network) "edge_threshold" else r_value(edge_threshold)),
    "missing_variables <- setdiff(c(variables, if (nzchar(group_variable)) group_variable), names(df))",
    "if (length(missing_variables)) stop(paste('Missing variables:', paste(missing_variables, collapse = ', ')))",
    "if (length(variables) < 2L) stop('Select at least two numeric variables.')",
    "",
    "# This helper is private to correlation analysis and is fully visible here.",
    "fit_one_correlation <- function(source_data) {",
    "  dat <- source_data[, variables, drop = FALSE]",
    "  dat[] <- lapply(dat, function(value) suppressWarnings(as.numeric(value)))",
    "  dat <- stats::na.omit(dat)",
    "  if (ncol(dat) < 2L) stop('Select at least two numeric variables.')",
    "  cor_matrix <- stats::cor(dat, method = correlation_method, use = 'pairwise.complete.obs')",
    "  p_value_matrix <- matrix(NA_real_, nrow = ncol(dat), ncol = ncol(dat), dimnames = list(names(dat), names(dat)))",
    "  diag(p_value_matrix) <- 0",
    "  index_pairs <- utils::combn(seq_along(dat), 2L, simplify = FALSE)",
    "  for (pair in index_pairs) {",
    "    x <- dat[[pair[[1]]]]; y <- dat[[pair[[2]]]]; keep <- stats::complete.cases(x, y)",
    "    p_value <- if (sum(keep) >= 3L) tryCatch(suppressWarnings(stats::cor.test(x[keep], y[keep], method = correlation_method, exact = FALSE)$p.value), error = function(error) NA_real_) else NA_real_",
    "    p_value_matrix[pair[[1]], pair[[2]]] <- p_value; p_value_matrix[pair[[2]], pair[[1]]] <- p_value",
    "  }",
    "  named_pairs <- utils::combn(names(dat), 2L, simplify = FALSE)",
    "  pair_raw <- do.call(rbind, lapply(named_pairs, function(pair) data.frame(var1 = pair[[1]], var2 = pair[[2]], correlation = unname(cor_matrix[pair[[1]], pair[[2]]]), p.value = unname(p_value_matrix[pair[[1]], pair[[2]]]), method = correlation_method, stringsAsFactors = FALSE)))",
    "  pair_raw$p.adjusted <- stats::p.adjust(pair_raw$p.value, method = 'BH')",
    "  significance <- function(p) ifelse(is.na(p), '', ifelse(p < 0.0001, '****', ifelse(p < 0.001, '***', ifelse(p < 0.01, '**', ifelse(p < 0.05, '*', 'ns')))))",
    "  pair_raw$significance <- significance(pair_raw$p.adjusted)",
    "  edges <- pair_raw[abs(pair_raw$correlation) >= edge_limit, , drop = FALSE]",
    "  if (nrow(edges)) edges <- edges[order(abs(edges$correlation), decreasing = TRUE), , drop = FALSE]",
    "  result_table <- pair_raw",
    "  result_table$significance <- significance(result_table$p.value)",
    "  result_table$correlation <- round(result_table$correlation, 4); result_table$p.adjusted <- round(result_table$p.adjusted, 4)",
    "  result_table$p.value <- ifelse(is.na(result_table$p.value), NA_character_, ifelse(result_table$p.value < 0.0001, '<0.0001', sprintf('%.4f', result_table$p.value)))",
    "  summary_text <- data.frame(observations = nrow(dat), variables = ncol(dat), method = correlation_method, p_adjustment = 'Benjamini-Hochberg (BH)', stringsAsFactors = FALSE)",
    "  p_display <- matrix(format.pval(as.vector(p_value_matrix), digits = 4, eps = 0.0001), nrow = nrow(p_value_matrix), ncol = ncol(p_value_matrix), dimnames = dimnames(p_value_matrix))",
    paste0("  model_text <- paste(c('============================================================', 'CORRELATION ANALYSIS SUMMARY', '============================================================', capture.output(print(summary_text, row.names = FALSE)), '', '============================================================', 'CORRELATION COEFFICIENT MATRIX', '============================================================', capture.output(print(round(cor_matrix, 4))), '', '============================================================', 'P-VALUE MATRIX', '============================================================', capture.output(print(p_display, quote = FALSE)), '', '============================================================', 'PAIRWISE CORRELATION TESTS', 'Raw P values, BH-adjusted P values, and significance labels', '============================================================', capture.output(print(result_table, row.names = FALSE))", if (network) ", '', '============================================================', sprintf('NETWORK EDGES (|r| >= %.3f)', edge_threshold), '============================================================', if (nrow(edges)) capture.output(print(edges, row.names = FALSE)) else 'No edges met the threshold.'" else "", "), collapse = '\\n')"),
    "  list(summary = data.frame(n = nrow(dat), variables = ncol(dat), method = correlation_method, threshold = edge_limit), result = result_table, matrix = data.frame(variable = rownames(cor_matrix), cor_matrix, check.names = FALSE, row.names = NULL), cor_matrix = cor_matrix, p_value_matrix = p_value_matrix, group = data.frame(), edges = edges, plot_data = if (network_mode) edges else as.data.frame(as.table(cor_matrix), stringsAsFactors = FALSE), model_text = model_text, formula = paste('cor(', paste(variables, collapse = ', '), ')'))",
    "}",
    paste0("network_mode <- ", r_value(network)),
    "group_values <- if (nzchar(group_variable)) as.character(df[[group_variable]]) else rep('.all', nrow(df))",
    "group_levels <- if (nzchar(group_variable)) unique(group_values[!is.na(group_values) & nzchar(group_values)]) else '.all'",
    "if (!length(group_levels)) stop('The grouping variable has no valid categories.')",
    "grouped_results <- setNames(lapply(group_levels, function(group_name) { rows <- if (nzchar(group_variable)) !is.na(group_values) & group_values == group_name else rep(TRUE, nrow(df)); fit_one_correlation(df[rows, , drop = FALSE]) }), group_levels)",
    "res <- grouped_results[[1]]",
    "if (nzchar(group_variable)) {",
    "  add_group <- function(table, name) data.frame(group = rep(name, nrow(table)), as.data.frame(table), check.names = FALSE, stringsAsFactors = FALSE)",
    "  res$summary <- do.call(rbind, Map(function(item, name) add_group(item$summary, name), grouped_results, names(grouped_results)))",
    "  res$result <- do.call(rbind, Map(function(item, name) add_group(item$result, name), grouped_results, names(grouped_results))); res$group <- res$result",
    "  res$edges <- do.call(rbind, Map(function(item, name) add_group(item$edges, name), grouped_results, names(grouped_results)))",
    "  rownames(res$summary) <- rownames(res$result) <- rownames(res$edges) <- NULL",
    "  res$group_var <- group_variable; res$grouped_results <- grouped_results",
    "  res$model_text <- paste(vapply(names(grouped_results), function(name) paste0('===== ', group_variable, ': ', name, ' =====\\n', grouped_results[[name]]$model_text), character(1)), collapse = '\\n\\n')",
    "  res$formula <- paste0('cor(', paste(variables, collapse = ', '), ') by ', group_variable)",
    "}"
  )

  if (!network) {
    settings <- correlation_corrplot_settings(input)
    plot_lines <- c(
      "# ---- Plotting: current corrplot panel settings ----",
      paste0("corrplot_shape <- ", r_value(settings$method), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_region <- ", r_value(settings$type), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_order <- ", r_value(settings$order), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_show_diagonal <- ", r_value(settings$diag), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_colors <- ", r_value(correlation_corrplot_palette_anchors(settings$palette)), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_legend_ratio <- ", r_value(settings$cl.ratio), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_legend_cex <- ", r_value(settings$cl.cex), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_label_position <- ", r_value(settings$tl.pos), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_label_cex <- ", r_value(settings$tl.cex), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_label_angle <- ", r_value(settings$tl.srt), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_label_color <- ", r_value(settings$tl.col), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_insignificant <- ", r_value(settings$insig), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_significance_levels <- ", r_value(settings$sig.level), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_mark_cex <- ", r_value(settings$pch.cex), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_mark_color <- ", r_value(settings$pch.col), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_show_coefficients <- ", r_value(settings$show_coef), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_number_cex <- ", r_value(settings$number.cex), " # <DAVA-UI-PARAM>"),
      paste0("corrplot_title <- ", r_value(settings$title), " # <DAVA-UI-PARAM>"),
      "if (!requireNamespace('corrplot', quietly = TRUE)) stop('Package corrplot is required.')",
      "corrplot_adaptive_label_cex <- function(matrix, requested) {",
      "  labels <- c(rownames(matrix), colnames(matrix)); labels <- labels[!is.na(labels) & nzchar(labels)]",
      "  longest_label <- if (length(labels)) max(nchar(labels, type = 'width')) else 1L",
      "  device_inches <- tryCatch(grDevices::dev.size('in'), error = function(e) c(7, 7))",
      "  short_side <- if (length(device_inches) >= 2L && all(is.finite(device_inches[1:2]))) max(2, min(device_inches[1:2])) else 7",
      "  max(0.4, min(requested, sqrt(10 / max(10, nrow(matrix), ncol(matrix))), sqrt(12 / max(12, longest_label)), sqrt(min(1, short_side / 7))))",
      "}",
      "plot_results <- if (nzchar(group_variable)) grouped_results else list(all = res)",
      "plots <- setNames(vector('list', length(plot_results)), names(plot_results))",
      "for (group_name in names(plot_results)) {",
      "  panel <- plot_results[[group_name]]; panel_title <- if (nzchar(group_variable)) paste0(corrplot_title, ' - ', group_name) else corrplot_title",
      "  effective_label_cex <- corrplot_adaptive_label_cex(panel$cor_matrix, corrplot_label_cex)",
      "  withCallingHandlers(corrplot::corrplot(panel$cor_matrix, method = corrplot_shape, type = corrplot_region, order = corrplot_order, col = grDevices::colorRampPalette(corrplot_colors)(100), tl.pos = corrplot_label_position, tl.cex = effective_label_cex, tl.col = corrplot_label_color, tl.srt = corrplot_label_angle, p.mat = panel$p_value_matrix, sig.level = corrplot_significance_levels, insig = corrplot_insignificant, diag = corrplot_show_diagonal, pch.cex = corrplot_mark_cex, pch.col = corrplot_mark_color, cl.ratio = corrplot_legend_ratio, cl.cex = corrplot_legend_cex, addCoef.col = if (corrplot_show_coefficients) 'black' else NULL, number.cex = corrplot_number_cex, mar = c(0, 0, if (nzchar(panel_title)) 2.2 else 0, 0), title = panel_title), warning = function(warning) if (grepl('^Not been able to calculate text margin', conditionMessage(warning))) invokeRestart('muffleWarning'))",
      "  plots[[group_name]] <- grDevices::recordPlot()",
      "}",
      "plot <- plots[[1]]; res$plots <- plots; res$plot <- plot",
      "res"
    )
  } else {
    prefix <- advanced_result_plot_settings_prefix(analysis_type)
    setting <- function(field, default = NULL) input[[dava_result_plot_settings_id(prefix, field)]] %||% default
    plot_theme <- as.character(setting("theme", "publication"))
    base_size <- suppressWarnings(as.numeric(setting("base_size", 14)))[1]
    if (!is.finite(base_size)) base_size <- 14
    theme_call <- switch(plot_theme, classic = "theme_classic", minimal = "theme_minimal", clean = "theme_minimal", nature = "theme_classic", science = "theme_bw", cell = "theme_classic", nejm = "theme_bw", lancet = "theme_classic", jama = "theme_bw", pnas = "theme_minimal", prism = "theme_classic", dark = "theme_minimal", "theme_bw")
    plot_lines <- c(
      "# ---- Plotting: current network panel settings ----",
      paste0("plot_theme <- ", r_value(plot_theme), " # <DAVA-UI-PARAM>"),
      paste0("plot_base_size <- ", r_value(base_size), " # <DAVA-UI-PARAM>"),
      paste0("plot_show_legend <- ", r_value(isTRUE(setting("show_legend", TRUE))), " # <DAVA-UI-PARAM>"),
      paste0("plot_legend_position <- ", r_value(setting("legend_position", "right")), " # <DAVA-UI-PARAM>"),
      paste0("plot_x_angle <- ", r_value(suppressWarnings(as.numeric(setting("x_angle", 0)))[1]), " # <DAVA-UI-PARAM>"),
      paste0("plot_flip <- ", r_value(isTRUE(setting("flip", FALSE))), " # <DAVA-UI-PARAM>"),
      paste0("plot_title <- ", r_value(trimws(as.character(setting("title", "")))), " # <DAVA-UI-PARAM>"),
      "plot_results <- if (nzchar(group_variable)) grouped_results else list(all = res)",
      "plots <- setNames(vector('list', length(plot_results)), names(plot_results))",
      "for (group_name in names(plot_results)) {",
      "  edges <- plot_results[[group_name]]$edges; if (!nrow(edges)) next",
      "  nodes <- unique(c(edges$var1, edges$var2)); theta <- seq(0, 2 * pi, length.out = length(nodes) + 1L)[-(length(nodes) + 1L)]",
      "  node_data <- data.frame(node = nodes, x = cos(theta), y = sin(theta), stringsAsFactors = FALSE)",
      "  edge_data <- edges; edge_data$x1 <- node_data$x[match(edge_data$var1, node_data$node)]; edge_data$y1 <- node_data$y[match(edge_data$var1, node_data$node)]; edge_data$x2 <- node_data$x[match(edge_data$var2, node_data$node)]; edge_data$y2 <- node_data$y[match(edge_data$var2, node_data$node)]",
      "  panel_title <- if (nzchar(plot_title)) plot_title else if (nzchar(group_variable)) group_name else 'Correlation network'",
      "  p <- ggplot2::ggplot() + ggplot2::geom_segment(data = edge_data, ggplot2::aes(x = x1, y = y1, xend = x2, yend = y2, linewidth = abs(correlation), color = correlation), alpha = 0.75) + ggplot2::geom_point(data = node_data, ggplot2::aes(x = x, y = y), size = 5, color = '#253494') + ggplot2::geom_text(data = node_data, ggplot2::aes(x = x, y = y, label = node), nudge_y = 0.08, size = 4) + ggplot2::scale_color_gradient2(low = '#d7301f', mid = 'grey85', high = '#2c7fb8', midpoint = 0) + ggplot2::labs(title = panel_title)",
      paste0("  p <- p + ggplot2::", theme_call, "(base_size = plot_base_size) + ggplot2::theme(plot.title = ggplot2::element_text(face = 'bold', hjust = 0, size = plot_base_size + 2), legend.position = if (plot_show_legend) plot_legend_position else 'none', panel.grid.minor = ggplot2::element_blank(), axis.text.x = ggplot2::element_text(angle = plot_x_angle, hjust = if (plot_x_angle == 0) 0.5 else 1))"),
      if (plot_theme %in% c("nature", "cell", "lancet", "prism")) "  p <- p + ggplot2::theme(axis.line = ggplot2::element_line(linewidth = 0.45, color = '#1F2933'), axis.ticks = ggplot2::element_line(linewidth = 0.35, color = '#1F2933'), panel.grid.major = ggplot2::element_blank())" else NULL,
      if (plot_theme %in% c("science", "nejm", "jama")) "  p <- p + ggplot2::theme(panel.border = ggplot2::element_rect(linewidth = 0.55, color = '#1F2933', fill = NA), panel.grid.major = ggplot2::element_line(linewidth = 0.22, color = '#E5E7EB'))" else NULL,
      if (identical(plot_theme, "pnas")) "  p <- p + ggplot2::theme(panel.grid.major = ggplot2::element_line(linewidth = 0.22, color = '#E6E8EB'), axis.line = ggplot2::element_line(linewidth = 0.35, color = '#374151'))" else NULL,
      if (identical(plot_theme, "clean")) "  p <- p + ggplot2::theme(panel.grid.major = ggplot2::element_blank())" else NULL,
      if (identical(plot_theme, "dark")) "  p <- p + ggplot2::theme(plot.background = ggplot2::element_rect(fill = '#111827', color = NA), panel.background = ggplot2::element_rect(fill = '#111827', color = NA), panel.grid.major = ggplot2::element_line(color = '#374151', linewidth = 0.22), text = ggplot2::element_text(color = '#F9FAFB'), plot.title = ggplot2::element_text(color = '#F9FAFB', face = 'bold', size = plot_base_size + 2), axis.title = ggplot2::element_text(color = '#F9FAFB'), axis.text = ggplot2::element_text(color = '#E5E7EB'), legend.background = ggplot2::element_rect(fill = '#111827', color = NA), legend.key = ggplot2::element_rect(fill = '#111827', color = NA), legend.text = ggplot2::element_text(color = '#F9FAFB'), legend.title = ggplot2::element_text(color = '#F9FAFB'))" else NULL,
      "  if (plot_flip) p <- p + ggplot2::coord_flip(); plots[[group_name]] <- p",
      "}",
      "plots <- Filter(Negate(is.null), plots); plot <- if (length(plots)) plots[[1]] else NULL",
      "res$plots <- plots; res$plot <- plot",
      "res"
    )
  }

  paste(c(
    "# EcoDAVA correlation analysis: standalone and reproducible",
    paste0("# Method: ", analysis_title(analysis_type)),
    data_code,
    analysis_lines,
    "",
    plot_lines
  ), collapse = "\n")
}
