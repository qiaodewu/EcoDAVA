# Annotation coordinates are based on each actualCompareRange calculation，Avoid crossingFacetedShare Pinnedheight。

compute_annotation_positions <- function(
    plot_data, annotation_data, y_var, group_vars,
    error_upper = NULL, step_increase = 0.08, expansion = 0.12,
    log_scale = FALSE, panel_vars = character()) {
  data <- as.data.frame(plot_data, stringsAsFactors = FALSE, check.names = FALSE)
  ann <- as.data.frame(annotation_data, stringsAsFactors = FALSE, check.names = FALSE)
  group_vars <- unique(group_vars[nzchar(group_vars)])
  panel_vars <- unique(panel_vars[nzchar(panel_vars)])
  keys <- unique(c(group_vars, panel_vars))
  if (!nrow(data) || !nrow(ann) || !(y_var %in% names(data)) || !all(keys %in% names(data))) return(ann)

  data[[y_var]] <- suppressWarnings(as.numeric(data[[y_var]]))
  data <- data[is.finite(data[[y_var]]), , drop = FALSE]
  if (!nrow(data)) return(ann)
  if (!is.null(error_upper) && error_upper %in% names(data)) {
    data$.dava_ceiling <- pmax(data[[y_var]], suppressWarnings(as.numeric(data[[error_upper]])), na.rm = TRUE)
  } else {
    data$.dava_ceiling <- data[[y_var]]
  }

  maxima <- data |>
    dplyr::group_by(dplyr::across(dplyr::all_of(keys))) |>
    dplyr::summarise(.dava_group_max = max(.data$.dava_ceiling, na.rm = TRUE), .groups = "drop")
  ann <- dplyr::left_join(ann, maxima, by = keys)

  panel_keys <- panel_vars
  ranges <- if (length(panel_keys)) {
    data |>
      dplyr::group_by(dplyr::across(dplyr::all_of(panel_keys))) |>
      dplyr::summarise(
        .dava_min = min(.data$.dava_ceiling, na.rm = TRUE),
        .dava_max = max(.data$.dava_ceiling, na.rm = TRUE),
        .groups = "drop"
      )
  } else {
    data.frame(.dava_min = min(data$.dava_ceiling), .dava_max = max(data$.dava_ceiling))
  }
  ann <- if (length(panel_keys)) dplyr::left_join(ann, ranges, by = panel_keys) else cbind(ann, ranges[rep(1, nrow(ann)), , drop = FALSE])
  span <- ann$.dava_max - ann$.dava_min
  span[!is.finite(span) | span <= 0] <- pmax(abs(ann$.dava_max[!is.finite(span) | span <= 0]), 1)
  base <- ann$.dava_group_max
  level <- if (".dava_level" %in% names(ann)) suppressWarnings(as.numeric(ann$.dava_level)) else rep(0, nrow(ann))
  level[!is.finite(level)] <- 0
  if (isTRUE(log_scale)) {
    positive <- base > 0
    ann$y[positive] <- base[positive] * exp(expansion + step_increase * level[positive])
    ann$y[!positive] <- base[!positive] + expansion * span[!positive]
  } else {
    ann$y <- base + (expansion + step_increase * level) * span
  }
  ann$yend <- ann$y
  ann
}

build_annotation_table <- function(result, plot_data = data.frame(), y_var = result$response,
                                   annotation_type = "cld", group_vars = character(),
                                   panel_vars = character(), show_ns = TRUE, log_scale = FALSE) {
  stopifnot(inherits(result, "dava_analysis_result"))
  strategy <- result$metadata$strategy %||% result$interaction_status
  scope <- strategy$interpretation %||% ""

  if (identical(annotation_type, "cld")) {
    ann <- as.data.frame(result$cld, stringsAsFactors = FALSE, check.names = FALSE)
    if (!nrow(ann) || !"letter" %in% names(ann)) return(dava_empty_annotation_table())
    ann$label <- trimws(as.character(ann$letter))
    ann$annotation_type <- "cld"
    ann$p_value <- NA_real_
    ann$p_adjusted <- NA_real_
    ann$comparison_scope <- scope
    ann$.dava_level <- 0
    ann <- compute_annotation_positions(plot_data, ann, y_var, group_vars,
                                        panel_vars = panel_vars, log_scale = log_scale)
    return(ann)
  }

  pairwise <- as.data.frame(result$pairwise, stringsAsFactors = FALSE, check.names = FALSE)
  if (!nrow(pairwise)) return(dava_empty_annotation_table())
  p <- pairwise$p_adjusted %||% dava_numeric_p(pairwise$p.value)
  label <- switch(annotation_type,
    star = p_to_significance(p, result$metadata$alpha %||% 0.05, show_ns = show_ns),
    p_value = format_p_value(p),
    bracket_star = p_to_significance(p, result$metadata$alpha %||% 0.05, show_ns = show_ns),
    bracket_p = format_p_value(p),
    p_to_significance(p, result$metadata$alpha %||% 0.05, show_ns = show_ns)
  )
  pairwise$label <- label
  pairwise$p_value <- dava_numeric_p(pairwise$p.value)
  pairwise$p_adjusted <- p
  pairwise$annotation_type <- annotation_type
  pairwise$comparison_scope <- scope
  pairwise$.dava_level <- seq_len(nrow(pairwise)) - 1
  if (!all(c("group1", "group2") %in% names(pairwise)) && "contrast" %in% names(pairwise)) {
    pieces <- strsplit(as.character(pairwise$contrast), " - ", fixed = TRUE)
    valid <- lengths(pieces) == 2
    pairwise$group1 <- NA_character_
    pairwise$group2 <- NA_character_
    pairwise$group1[valid] <- vapply(pieces[valid], `[`, character(1), 1)
    pairwise$group2[valid] <- vapply(pieces[valid], `[`, character(1), 2)
  }
  conditioning <- strategy$conditioning_factors %||% character()
  data <- as.data.frame(plot_data, stringsAsFactors = FALSE, check.names = FALSE)
  if (nrow(data) && y_var %in% names(data) && all(conditioning %in% names(data))) {
    data[[y_var]] <- suppressWarnings(as.numeric(data[[y_var]]))
    if (length(conditioning)) {
      ceiling <- data |>
        dplyr::group_by(dplyr::across(dplyr::all_of(conditioning))) |>
        dplyr::summarise(.dava_max = max(.data[[y_var]], na.rm = TRUE), .dava_min = min(.data[[y_var]], na.rm = TRUE), .groups = "drop")
      pairwise <- dplyr::left_join(pairwise, ceiling, by = conditioning)
    } else {
      pairwise$.dava_max <- max(data[[y_var]], na.rm = TRUE)
      pairwise$.dava_min <- min(data[[y_var]], na.rm = TRUE)
    }
    span <- pairwise$.dava_max - pairwise$.dava_min
    span[!is.finite(span) | span <= 0] <- 1
    pairwise$y <- pairwise$.dava_max + (0.12 + 0.08 * pairwise$.dava_level) * span
    pairwise$yend <- pairwise$y
  }
  pairwise
}

validate_annotation_scope <- function(annotation_data, strategy) {
  ann <- as.data.frame(annotation_data, stringsAsFactors = FALSE, check.names = FALSE)
  conditioning <- strategy$conditioning_factors %||% character()
  missing <- setdiff(conditioning, names(ann))
  list(valid = !length(missing), missing_conditioning_factors = missing)
}
