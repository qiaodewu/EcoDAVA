# Unification estimated marginal means、Multiple comparisonsand CLD Security interface。

dava_model_scale <- function(model, requested = c("auto", "response", "link")) {
  requested <- match.arg(requested)
  if (!identical(requested, "auto")) return(requested)
  family <- tryCatch(stats::family(model), error = function(e) NULL)
  if (!is.null(family) && !identical(family$family, "gaussian")) "response" else "link"
}

compute_emmeans_safe <- function(model, specs, scale = "auto", ...) {
  if (is.null(model)) return(list(value = NULL, table = data.frame(), warnings = character(), error = "Model is missing."))
  if (!requireNamespace("emmeans", quietly = TRUE)) {
    return(list(value = NULL, table = data.frame(), warnings = character(), error = "Package 'emmeans' is required."))
  }
  type <- dava_model_scale(model, scale)
  captured <- dava_capture_conditions(emmeans::emmeans(model, specs = specs, type = type, ...))
  table <- if (is.null(captured$value)) data.frame() else as.data.frame(captured$value, check.names = FALSE)
  list(value = captured$value, table = table, warnings = captured$warnings, error = captured$error, scale = type)
}

dava_adjust_method <- function(adjust, contrast_type = "pairwise") {
  adjust <- tolower(trimws(adjust %||% "tukey"))
  aliases <- c("bh/fdr" = "BH", "fdr" = "BH", "none" = "none", "dunnett" = "dunnett")
  if (adjust %in% names(aliases)) return(unname(aliases[adjust]))
  if (identical(adjust, "games-howell")) return("games-howell")
  if (identical(adjust, "scheffe")) return("scheffe")
  adjust
}

compute_pairwise_contrasts <- function(emm, adjust = "tukey", alpha = 0.05) {
  if (is.null(emm)) return(list(table = data.frame(), warnings = character(), error = "Estimated marginal means are unavailable."))
  adjustment <- dava_adjust_method(adjust)
  captured <- dava_capture_conditions(emmeans::contrast(emm, method = "pairwise", adjust = adjustment))
  table <- if (is.null(captured$value)) data.frame() else as.data.frame(captured$value, check.names = FALSE)
  if (nrow(table)) {
    table$p_adjusted <- dava_numeric_p(table$p.value)
    table$significance <- p_to_significance(table$p_adjusted, alpha)
    table$p_label <- format_p_value(table$p_adjusted)
    table$adjust <- adjustment
  }
  list(table = table, warnings = captured$warnings, error = captured$error, adjust = adjustment)
}

dava_oneway_pairwise_fallback <- function(model, response, factor,
                                           adjust = "tukey", alpha = 0.05) {
  dat <- tryCatch(stats::model.frame(model), error = function(e) data.frame())
  if (!nrow(dat) || !all(c(response, factor) %in% names(dat))) {
    return(list(pairwise = data.frame(), cld = data.frame(), error =
      "Model data are unavailable for the one-way ANOVA fallback."))
  }
  dat <- dat[stats::complete.cases(dat[c(response, factor)]), , drop = FALSE]
  dat[[factor]] <- droplevels(base::factor(dat[[factor]]))
  if (nlevels(dat[[factor]]) < 2L) {
    return(list(pairwise = data.frame(), cld = data.frame(), error =
      "At least two factor levels are required for multiple comparisons."))
  }

  adjustment <- dava_adjust_method(adjust)
  pairwise <- data.frame()
  if (tolower(adjustment) == "tukey") {
    fit <- stats::aov(stats::reformulate(factor, response), data = dat)
    table <- tryCatch(stats::TukeyHSD(fit, which = factor)[[factor]],
      error = function(e) NULL)
    if (!is.null(table)) {
      pairwise <- as.data.frame(table, stringsAsFactors = FALSE,
        check.names = FALSE)
      pairwise$contrast <- rownames(pairwise)
      rownames(pairwise) <- NULL
      groups <- strsplit(pairwise$contrast, "-", fixed = TRUE)
      pairwise$group1 <- vapply(groups, `[`, character(1), 1L)
      pairwise$group2 <- vapply(groups, function(x) paste(x[-1L], collapse = "-"),
        character(1))
      names(pairwise)[names(pairwise) == "p adj"] <- "p.value"
    }
  } else {
    method <- if (tolower(adjustment) %in% stats::p.adjust.methods) adjustment else "holm"
    result <- stats::pairwise.t.test(dat[[response]], dat[[factor]],
      p.adjust.method = method, pool.sd = TRUE)
    pairwise <- as.data.frame(as.table(result$p.value), stringsAsFactors = FALSE)
    names(pairwise) <- c("group1", "group2", "p.value")
    pairwise <- pairwise[is.finite(pairwise$p.value), , drop = FALSE]
    pairwise$contrast <- paste(pairwise$group1, pairwise$group2, sep = " - ")
  }
  if (!nrow(pairwise)) {
    return(list(pairwise = data.frame(), cld = data.frame(), error =
      "The one-way ANOVA fallback did not produce pairwise comparisons."))
  }

  pairwise$response <- response
  pairwise$term <- factor
  pairwise$p_adjusted <- dava_numeric_p(pairwise$p.value)
  pairwise$significance <- p_to_significance(pairwise$p_adjusted, alpha)
  pairwise$p_label <- format_p_value(pairwise$p_adjusted)
  pairwise$adjust <- adjustment

  cld <- data.frame()
  if (requireNamespace("multcompView", quietly = TRUE)) {
    values <- pairwise$p_adjusted
    names(values) <- paste(pairwise$group1, pairwise$group2, sep = "-")
    letters <- tryCatch(multcompView::multcompLetters(values)$Letters,
      error = function(e) NULL)
    if (!is.null(letters)) {
      means <- stats::aggregate(dat[[response]], list(level = dat[[factor]]), mean)
      ses <- stats::aggregate(dat[[response]], list(level = dat[[factor]]),
        function(x) stats::sd(x) / sqrt(length(x)))
      cld <- data.frame(response = response, term = factor,
        level = names(letters), letter = unname(letters), stringsAsFactors = FALSE)
      cld[[factor]] <- cld$level
      cld$emmean <- means$x[match(cld$level, as.character(means$level))]
      cld$SE <- ses$x[match(cld$level, as.character(ses$level))]
    }
  }
  list(pairwise = pairwise, cld = cld, error = "")
}

compute_control_contrasts <- function(emm, control_level, adjust = "dunnett", alpha = 0.05) {
  if (is.null(emm)) return(list(table = data.frame(), warnings = character(), error = "Estimated marginal means are unavailable."))
  grid <- tryCatch(as.data.frame(emm), error = function(e) data.frame())
  factor_cols <- setdiff(names(grid), c("emmean", "SE", "df", "lower.CL", "upper.CL", "asymp.LCL", "asymp.UCL", "response", "prob", "rate"))
  tested <- if (length(factor_cols)) factor_cols[[1L]] else ""
  levels <- if (nzchar(tested)) unique(as.character(grid[[tested]])) else character()
  ref <- match(control_level, levels)
  if (!length(ref) || is.na(ref)) return(list(table = data.frame(), warnings = character(), error = "The selected control level is absent."))
  captured <- dava_capture_conditions(emmeans::contrast(emm, method = "trt.vs.ctrl", ref = ref, adjust = dava_adjust_method(adjust)))
  table <- if (is.null(captured$value)) data.frame() else as.data.frame(captured$value, check.names = FALSE)
  if (nrow(table)) {
    table$p_adjusted <- dava_numeric_p(table$p.value)
    table$significance <- p_to_significance(table$p_adjusted, alpha)
    table$p_label <- format_p_value(table$p_adjusted)
  }
  list(table = table, warnings = captured$warnings, error = captured$error)
}

compute_custom_contrasts <- function(emm, custom_contrasts, adjust = "holm", alpha = 0.05) {
  if (is.null(emm)) return(list(table = data.frame(), warnings = character(), error = "Estimated marginal means are unavailable."))
  captured <- dava_capture_conditions(emmeans::contrast(
    emm, method = custom_contrasts, adjust = dava_adjust_method(adjust)
  ))
  table <- if (is.null(captured$value)) data.frame() else as.data.frame(captured$value, check.names = FALSE)
  if (nrow(table)) {
    table$p_adjusted <- dava_numeric_p(table$p.value)
    table$significance <- p_to_significance(table$p_adjusted, alpha)
    table$p_label <- format_p_value(table$p_adjusted)
    table$adjust <- dava_adjust_method(adjust)
  }
  list(table = table, warnings = captured$warnings, error = captured$error)
}

compute_games_howell <- function(data, response, factor, alpha = 0.05) {
  if (!requireNamespace("rstatix", quietly = TRUE)) {
    return(list(table = data.frame(), warnings = character(), error = "Games-Howell requires package 'rstatix'."))
  }
  dat <- as.data.frame(data, stringsAsFactors = FALSE, check.names = FALSE)
  if (!all(c(response, factor) %in% names(dat))) return(list(table = data.frame(), warnings = character(), error = "Response or factor is missing."))
  captured <- dava_capture_conditions(rstatix::games_howell_test(dat, stats::reformulate(factor, response)))
  table <- if (is.null(captured$value)) data.frame() else as.data.frame(captured$value, check.names = FALSE)
  if (nrow(table)) {
    table$p_adjusted <- table$p.adj
    table$significance <- p_to_significance(table$p_adjusted, alpha)
    table$p_label <- format_p_value(table$p_adjusted)
    table$adjust <- "games-howell"
  }
  list(table = table, warnings = captured$warnings, error = captured$error)
}

compute_nonparametric_contrasts <- function(data, response, factor, paired = FALSE,
                                            adjust = "holm", alpha = 0.05) {
  dat <- as.data.frame(data, stringsAsFactors = FALSE, check.names = FALSE)
  if (!all(c(response, factor) %in% names(dat))) return(list(table = data.frame(), warnings = character(), error = "Response or factor is missing."))
  method <- dava_adjust_method(adjust)
  captured <- dava_capture_conditions(stats::pairwise.wilcox.test(
    dat[[response]], dat[[factor]], paired = paired,
    p.adjust.method = if (identical(method, "sidak")) "none" else method,
    exact = FALSE
  ))
  if (is.null(captured$value)) return(list(table = data.frame(), warnings = captured$warnings, error = captured$error))
  table <- as.data.frame(as.table(captured$value$p.value), stringsAsFactors = FALSE)
  names(table) <- c("group1", "group2", "p_adjusted")
  table <- table[is.finite(table$p_adjusted), , drop = FALSE]
  if (identical(method, "sidak") && nrow(table)) {
    table$p_adjusted <- 1 - (1 - table$p_adjusted)^nrow(table)
  }
  table$p_value <- NA_real_
  table$significance <- p_to_significance(table$p_adjusted, alpha)
  table$p_label <- format_p_value(table$p_adjusted)
  table$adjust <- method
  list(table = table, warnings = captured$warnings, error = captured$error)
}

safe_cld <- function(
    emm, adjust = "tukey", alpha = 0.05,
    letters_set = c(base::letters, base::LETTERS, paste0(".", base::letters)),
    sort = TRUE, reversed = FALSE) {
  if (is.null(emm)) return(structure(data.frame(), error_message = "Estimated marginal means are unavailable."))
  if (!requireNamespace("multcomp", quietly = TRUE)) {
    return(structure(data.frame(), error_message = "Package 'multcomp' is required."))
  }
  letters_set <- unique(as.character(letters_set))
  letters_set <- letters_set[!is.na(letters_set) & nzchar(letters_set)]
  if (!length(letters_set)) letters_set <- c(base::letters, base::LETTERS)
  captured <- dava_capture_conditions(multcomp::cld(
    emm,
    alpha = alpha,
    adjust = dava_adjust_method(adjust),
    Letters = letters_set,
    sort = isTRUE(sort),
    reversed = isTRUE(reversed)
  ))
  if (is.null(captured$value)) {
    return(structure(data.frame(), error_message = captured$error, warnings = captured$warnings))
  }
  out <- as.data.frame(captured$value, stringsAsFactors = FALSE, check.names = FALSE)
  if (".group" %in% names(out)) {
    out$.group <- gsub("\\s+", "", trimws(as.character(out$.group)))
  }
  structure(out, error_message = "", warnings = captured$warnings)
}

dava_term_from_strategy <- function(strategy) {
  focus <- strategy$focus_factor %||% ""
  conditioning <- strategy$conditioning_factors %||% character()
  if (length(conditioning)) paste0(focus, "|", paste(conditioning, collapse = ":")) else focus
}

dava_compute_significance <- function(
    model, effect_table, response, factors, focus_factor = NULL,
    adjust = "tukey", alpha = 0.05, scale = "auto", metadata = list(), strategy = NULL) {
  strategy <- strategy %||% determine_comparison_strategy(effect_table, factors, alpha, focus_factor)
  emm_result <- compute_emmeans_safe(model, strategy$comparison_formula, scale = scale)
  pair_result <- compute_pairwise_contrasts(emm_result$value, adjust = adjust, alpha = alpha)
  cld_table <- safe_cld(emm_result$value, adjust = adjust, alpha = alpha, sort = TRUE)
  fallback <- NULL
  if (!nrow(pair_result$table) && inherits(model, "lm") && length(factors) == 1L) {
    fallback <- dava_oneway_pairwise_fallback(
      model, response, factors[[1]], adjust = adjust, alpha = alpha)
    if (nrow(fallback$pairwise)) {
      pair_result$table <- fallback$pairwise
      pair_result$error <- ""
      emm_result$error <- ""
      pair_result$warnings <- c(pair_result$warnings,
        "emmeans contrasts were unavailable; used the base-R one-way ANOVA fallback.")
    }
    if (!nrow(cld_table) && nrow(fallback$cld)) cld_table <- fallback$cld
  }
  cld_error <- attr(cld_table, "error_message") %||% ""
  cld_warnings <- attr(cld_table, "warnings") %||% character()
  term <- dava_term_from_strategy(strategy)

  decorate <- function(table) {
    table <- dava_result_table_contract(table, response, term)
    table$comparison_scope <- rep(strategy$interpretation, nrow(table))
    table
  }
  emm_table <- decorate(emm_result$table)
  pairwise <- decorate(pair_result$table)
  cld_table <- decorate(cld_table)
  if (nrow(cld_table) && ".group" %in% names(cld_table)) names(cld_table)[names(cld_table) == ".group"] <- "letter"

  warnings <- unique(c(emm_result$warnings, pair_result$warnings, cld_warnings))
  errors <- unique(c(emm_result$error, pair_result$error, cld_error))
  errors <- errors[nzchar(errors)]
  family <- tryCatch(stats::family(model)$family, error = function(e) NULL)
  status <- metadata$model_status %||% data.frame()
  validity <- if (length(errors)) "error" else if (length(warnings) || (nrow(status) && any(status$singular %in% TRUE))) "warning" else "valid"
  metadata <- utils::modifyList(metadata, list(
    strategy = strategy,
    adjust_requested = adjust,
    adjust_used = pair_result$adjust %||% adjust,
    alpha = alpha,
    scale = emm_result$scale %||% scale,
    caption = dava_strategy_caption(strategy, pair_result$adjust %||% adjust),
    result_validity = validity
  ))
  dava_new_analysis_result(
    model = model,
    model_class = class(model)[1] %||% "",
    response = response,
    fixed_factors = factors,
    family = family,
    effect_table = dava_normalize_effect_table(effect_table, response),
    interaction_status = strategy,
    emmeans = emm_table,
    pairwise = pairwise,
    cld = cld_table,
    warnings = warnings,
    errors = errors,
    metadata = metadata
  )
}

dava_compute_significance_batch <- function(models, effect_tables, factors, adjust = "tukey",
                                            alpha = 0.05, scale = "auto", model_status = data.frame(),
                                            plot_data = data.frame()) {
  results <- list()
  for (response in names(models)) {
    effect_table <- effect_tables[[response]] %||% data.frame()
    for (focus in factors) {
      strategies <- dava_comparison_strategies(effect_table, factors, alpha, focus)
      for (strategy in strategies) {
        key <- paste(response, dava_term_from_strategy(strategy), sep = "::")
        status <- if (nrow(model_status) && "response" %in% names(model_status)) {
          model_status[model_status$response == response, , drop = FALSE]
        } else data.frame()
        result <- tryCatch(
          dava_compute_significance(
            models[[response]], effect_table, response, factors, focus,
            adjust = adjust, alpha = alpha, scale = scale,
            metadata = list(model_status = status), strategy = strategy
          ),
          error = function(e) {
            dava_new_analysis_result(
              model = models[[response]], response = response,
              fixed_factors = factors,
              interaction_status = strategy,
              errors = conditionMessage(e),
              metadata = list(model_status = status, result_validity = "error")
            )
          }
        )
        result$plot_data <- as.data.frame(plot_data, stringsAsFactors = FALSE, check.names = FALSE)
        if (nrow(result$cld) && nrow(result$plot_data) && exists("build_annotation_table", mode = "function")) {
          result$annotations <- build_annotation_table(
            result, result$plot_data, response, "cld",
            group_vars = unique(c(strategy$focus_factor, strategy$conditioning_factors)),
            panel_vars = strategy$conditioning_factors
          )
        }
        results[[key]] <- result
      }
    }
  }
  list(
    results = results,
    emmeans = dplyr::bind_rows(lapply(results, `[[`, "emmeans")),
    pairwise = dplyr::bind_rows(lapply(results, `[[`, "pairwise")),
    cld = dplyr::bind_rows(lapply(results, `[[`, "cld")),
    annotations = dplyr::bind_rows(lapply(results, `[[`, "annotations")),
    strategies = dplyr::bind_rows(lapply(results, function(x) {
      strategy <- x$interaction_status
      data.frame(
        response = x$response,
        focus_factor = strategy$focus_factor,
        highest_significant_effect = strategy$highest_significant_effect,
        comparison_term = dava_term_from_strategy(strategy),
        interpretation_level = strategy$interpretation_level,
        conditioning_factors = paste(strategy$conditioning_factors, collapse = ":"),
        averaging_factors = paste(strategy$averaging_factors, collapse = ":"),
        interpretation = strategy$interpretation,
        stringsAsFactors = FALSE
      )
    })),
    warnings = unique(unlist(lapply(results, `[[`, "warnings"), use.names = FALSE)),
    errors = unique(unlist(lapply(results, `[[`, "errors"), use.names = FALSE))
  )
}
