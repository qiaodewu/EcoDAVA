# ReturnmodelCapability Registry。UI and server Read only this table，will no longer be maintained separatelymodelAbility judgment。
regression_model_registry <- function() {
  rows <- list(
    c("lm", "Classic linear regression", "Linear regression", "stats", "single", TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, "response"),
    c("polynomial", "Classic linear regression", "Polynomial Regression", "stats", "single", TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, "response"),
    c("logistic", "Generalized linear regression", "Logistic Regression", "stats", "single", TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, "link,response"),
    c("poisson", "Generalized linear regression", "Poisson returns", "stats", "single", TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, "link,response"),
    c("negative_binomial", "Generalized linear regression", "Negative Binomial Regression", "MASS", "single", TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, "link,response"),
    c("gamma", "Generalized linear regression", "Gamma returns", "stats", "single", TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, "link,response"),
    c("quasipoisson", "Generalized linear regression", "Quasi-Poisson returns", "stats", "single", TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, FALSE, "link,response"),
    c("lmm", "Mixed Effects and Hierarchical Regression", "Linear mixed effects model", "lme4", "single", TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, "marginal,conditional"),
    c("glmm", "Mixed Effects and Hierarchical Regression", "Generalized Linear Mixed Effects Model", "lme4", "single", TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, "link,response,marginal,conditional"),
    c("gamm", "Mixed Effects and Hierarchical Regression", "Generalized additive mixed model", "mgcv", "single", TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, "link,response,conditional"),
    c("pls1", "Latent variables and dimensionality reduction regression", "PLS1", "pls", "single", TRUE, TRUE, FALSE, FALSE, FALSE, TRUE, TRUE, FALSE, TRUE, TRUE, "response"),
    c("ridge", "Regularized regression", "Ridge", "glmnet", "single", TRUE, TRUE, TRUE, FALSE, FALSE, TRUE, TRUE, FALSE, TRUE, TRUE, "response"),
    c("lasso", "Regularized regression", "LASSO", "glmnet", "single", TRUE, TRUE, TRUE, FALSE, FALSE, TRUE, TRUE, FALSE, TRUE, TRUE, "response"),
    c("elastic_net", "Regularized regression", "Elastic Net", "glmnet", "single", TRUE, TRUE, TRUE, FALSE, FALSE, TRUE, TRUE, FALSE, TRUE, TRUE, "response"),
    c("gam", "Semi-parametric, non-parametric and robust regression", "GAM", "mgcv", "single", TRUE, TRUE, TRUE, TRUE, FALSE, FALSE, TRUE, TRUE, TRUE, TRUE, "link,response"),
    c("quantile", "Semi-parametric, non-parametric and robust regression", "Quantile Regression", "quantreg", "single", TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, FALSE, "response"),
    c("robust", "Semi-parametric, non-parametric and robust regression", "Robust regression", "MASS", "single", TRUE, TRUE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, FALSE, "response"),
    c("rpart", "Tree model and machine learning regression", "Regression tree", "rpart", "single", TRUE, TRUE, TRUE, FALSE, FALSE, FALSE, TRUE, FALSE, TRUE, TRUE, "response"),
    c("multivariate_tree", "Multiple regression tree", "Multiple regression tree (MRT)", "rpart", "matrix", TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, TRUE, FALSE, "response"),
    c("random_forest", "Tree model and machine learning regression", "Random Forest", "ranger", "single", TRUE, TRUE, TRUE, FALSE, FALSE, FALSE, TRUE, FALSE, TRUE, TRUE, "response"),
    c("xgboost", "Tree model and machine learning regression", "XGBoost", "xgboost", "single", TRUE, TRUE, TRUE, FALSE, FALSE, FALSE, TRUE, FALSE, TRUE, TRUE, "response")
  )
  columns <- c("id", "category", "label", "package", "response_support", "multi_predictor",
               "categorical_predictor", "grouping", "interaction", "random_effects",
               "numeric_equation", "fit_curve", "traditional_p", "diagnostics", "aic_bic",
               "prediction_scales")
  out <- as.data.frame(do.call(rbind, rows), stringsAsFactors = FALSE)
  names(out) <- columns
  logical_columns <- columns[6:15]
  out[logical_columns] <- lapply(out[logical_columns], function(x) x == "TRUE")
  category_by_method <- c(
    lm = "Classic continuous response regression", polynomial = "Classic continuous response regression", robust = "Classic continuous response regression",
    logistic = "Generalized linear regression", poisson = "Generalized linear regression",
    negative_binomial = "Generalized linear regression", gamma = "Generalized linear regression",
    quasipoisson = "Generalized linear regression",
    lmm = "Mixed effects and zero-inflated regression", glmm = "Mixed effects and zero-inflated regression",
    gamm = "Mixed effects and zero-inflated regression",
    gam = "Nonlinear and regularized regression", quantile = "Classic continuous response regression",
    pls1 = "Nonlinear and regularized regression", ridge = "Nonlinear and regularized regression",
    lasso = "Nonlinear and regularized regression", elastic_net = "Nonlinear and regularized regression",
    rpart = "Nonlinear and regularized regression", multivariate_tree = "Community matrix and multiple response regression", random_forest = "Nonlinear and regularized regression",
    xgboost = "Nonlinear and regularized regression"
  )
  out$category <- unname(category_by_method[out$id])
  out$implemented <- TRUE
  out$ui_exposed <- TRUE

  # Methods that have not been connected to the fitting engine only register capabilities and dependencies.，Not exposed in advance UI。
  planned <- data.frame(
    id = c(
      "segmented", "nls", "aggregated_binomial", "weighted_binomial", "multinomial", "ordinal", "quasibinomial", "beta",
      "zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin", "zip_mixed", "zinb_mixed",
      "loess", "pcr", "pls2", "mediation", "moderation",
      "rda", "cca", "dbrda", "manyglm", "gllvm", "jsdm", "rrr",
      "maaslin2", "ancombc2", "deseq2", "edger", "corncob", "aldex2", "metagenomeseq", "multivariable_association", "pgls"
    ),
    category = c(
      rep("Classic continuous response regression", 2), rep("Generalized linear regression", 6),
      rep("Mixed effects and zero-inflated regression", 7), rep("Nonlinear and regularized regression", 3),
      rep("Mediation and Moderated Regression", 2), rep("Community matrix and multiple response regression", 7), rep("Microbiome differences and association models", 9)
    ),
    label = c(
      "Segmentation and threshold regression", "Nonlinear least squares regression", "Aggregated Binomial Regression", "Proportionally weighted binomial regression", "Multiple Logistic", "Orderly Logistic", "Quasi-binomial regression", "Beta Returns",
      "Zero inflation Poisson", "Zero-inflated negative binomial", "Hurdle (compatible entry)", "Hurdle Poisson", "Hurdle negative binomial", "Zero-inflated Poisson Mixture Model", "Zero-inflated negative binomial mixed model",
      "LOESS partial regression", "PCR", "PLS2", "Mediating effect", "Moderating effect",
      "RDA", "CCA (canonical correspondence analysis)", "dbRDA", "Multispecies GLM", "GLLVM", "JSDM", "Reduced rank regression RRR",
      "MaAsLin2", "ANCOM-BC2", "DESeq2", "edgeR", "corncob", "ALDEx2", "metagenomeSeq", "Feature-level multivariate correlations", "PGLS"
    ),
    package = c(
      "segmented", "minpack.lm", "stats", "stats", "nnet", "ordinal", "stats", "betareg",
      "pscl", "pscl", "pscl", "pscl", "pscl", "glmmTMB", "glmmTMB",
      "stats", "pls", "pls", "mediation", "interactions",
      "vegan", "vegan", "vegan", "mvabund", "gllvm", "Hmsc", "rrpack",
      "Maaslin2", "ANCOMBC", "DESeq2", "edgeR", "corncob", "ALDEx2", "metagenomeSeq", "Maaslin2", "phylolm"
    ),
    response_support = c(rep("single", 18), rep("single", 2), rep("matrix", 7), rep("matrix", 8), "single"),
    multi_predictor = TRUE, categorical_predictor = TRUE, grouping = FALSE,
    interaction = TRUE, random_effects = FALSE, numeric_equation = FALSE,
    fit_curve = c(rep(TRUE, 20), rep(FALSE, 16)), traditional_p = TRUE,
    diagnostics = TRUE, aic_bic = c(rep(TRUE, 18), rep(FALSE, 18)),
    prediction_scales = c(rep("link,response", 18), rep("response", 18)),
    implemented = FALSE, ui_exposed = FALSE,
    stringsAsFactors = FALSE
  )
  ready_ids <- c("segmented", "nls", "aggregated_binomial", "weighted_binomial", "multinomial", "ordinal", "quasibinomial", "beta", "zip", "zinb", "hurdle",
                 "hurdle_poisson", "hurdle_negbin", "loess", "pcr", "pls2", "rda", "cca", "dbrda")
  planned$implemented[planned$id %in% ready_ids] <- TRUE
  planned$ui_exposed[planned$id %in% ready_ids] <- TRUE
  planned$grouping[planned$id %in% ready_ids] <- TRUE
  mixed_zero_ids <- c("zip_mixed", "zinb_mixed")
  planned$implemented[planned$id %in% mixed_zero_ids] <- TRUE
  planned$ui_exposed[planned$id %in% mixed_zero_ids] <- TRUE
  planned$grouping[planned$id %in% mixed_zero_ids] <- TRUE
  planned$random_effects[planned$id %in% mixed_zero_ids] <- TRUE
  staged_ready_ids <- c("mediation", "moderation", "manyglm", "gllvm", "jsdm", "rrr", "maaslin2", "ancombc2", "deseq2", "edger", "corncob", "aldex2", "metagenomeseq", "multivariable_association", "pgls")
  planned$implemented[planned$id %in% staged_ready_ids] <- TRUE
  planned$ui_exposed[planned$id %in% staged_ready_ids] <- TRUE
  planned$package[planned$id == "multivariable_association"] <- "stats"
  out <- rbind(out, planned)
  out$package[out$id == "ordinal"] <- "MASS"
  out$response_support[out$id == "pls2"] <- "multiple"
  out$response_support[out$id %in% c("rda", "cca", "dbrda")] <- "matrix"
  # UI name strictly describes the actual statisticsmodel；One dollar、Multivariate sumGroupingYeslineSexmodelThe true whole ofvariable/Fitting scenario，
  # NoCopyinto multiple pseudo method entries using the same engine。
  scientific_labels <- c(
    lm = "Linear regression (univariate/multivariate/grouping and interaction)",
    polynomial = "Polynomial Regression",
    segmented = "Segmentation and threshold regression",
    nls = "Nonlinear least squares regression",
    robust = "Robust regression",
    logistic = "Logistic Regression",
    aggregated_binomial = "Binomial Proportional Regression (Number of Successes/Total Number)",
    weighted_binomial = "Binomial proportional regression (proportion/weight)",
    poisson = "Poisson returns",
    negative_binomial = "Negative Binomial Regression",
    gamma = "Gamma returns",
    beta = "Beta Returns",
    multinomial = "Multinomial Logistic Regression",
    ordinal = "Ordered Logistic Regression",
    quasipoisson = "Quasi-Poisson returns",
    quasibinomial = "Quasi-binomial regression",
    lmm = "Linear mixed effects model",
    glmm = "Generalized Linear Mixed Effects Model",
    gamm = "Generalized additive mixed model",
    zip_mixed = "Zero-inflated Poisson Mixture Model",
    zinb_mixed = "Zero-inflated negative binomial mixed model",
    zip = "Zero-inflation Poisson returns",
    zinb = "Zero-inflated negative binomial regression",
    hurdle_poisson = "Hurdle Poisson returns",
    hurdle_negbin = "Hurdle Negative Binomial Regression",
    gam = "Generalized Additive Model (GAM)",
    loess = "LOESS partial regression",
    pcr = "Principal component regression (PCR)",
    pls1 = "Partial Least Squares Regression (PLS1)",
    pls2 = "Multi-response partial least squares regression (PLS2)",
    ridge = "Ridge returns",
    lasso = "LASSO returns",
    elastic_net = "Elastic Net is back",
    mediation = "Mediating effect",
    moderation = "Moderator effect (interaction regression)",
    rda = "Redundancy Analysis (RDA)",
    cca = "Canonical Correspondence Analysis (CCA)",
    dbrda = "Distance Constrained Redundancy Analysis (dbRDA)",
    manyglm = "Multispecies GLM",
    gllvm = "Generalized linear latent variable model (GLLVM)",
    jsdm = "Joint species distribution model (JSDM)",
    rrr = "Reduced rank regression (RRR)",
    multivariable_association = "Feature-level multivariate correlations",
    pgls = "Phylogenetic generalized least squares (PGLS)"
  )
  relabel <- intersect(names(scientific_labels), out$id)
  out$label[match(relabel, out$id)] <- unname(scientific_labels[relabel])
  legacy_hidden <- c("quantile", "rpart", "random_forest", "xgboost")
  out$ui_exposed[out$id %in% legacy_hidden] <- FALSE

  # Single capability matrix：UI、server and the engine only reads thesefieldDetermines available controlsandoutput。
  out$engine <- out$package
  out$response_mode <- out$response_support
  out$response_types <- "numeric"
  out$response_types[out$id %in% c("logistic", "quasibinomial")] <- "binary,binomial"
  out$response_types[out$id == "aggregated_binomial"] <- "aggregated_binomial"
  out$response_types[out$id == "weighted_binomial"] <- "weighted_proportion"
  out$response_types[out$id %in% c("poisson", "negative_binomial", "quasipoisson", "zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin", "zip_mixed", "zinb_mixed")] <- "count"
  out$response_types[out$id == "beta"] <- "proportion_open_unit"
  out$response_types[out$id == "gamma"] <- "positive_numeric"
  out$response_types[out$id == "multinomial"] <- "nominal_factor"
  out$response_types[out$id == "ordinal"] <- "ordered_factor"
  out$response_types[out$response_support == "matrix"] <- "community_or_feature_matrix"
  out$families <- "gaussian"
  out$families[out$id %in% c("logistic", "aggregated_binomial", "weighted_binomial")] <- "binomial"
  out$families[out$id %in% c("quasibinomial")] <- "quasibinomial"
  out$families[out$id %in% c("poisson", "zip", "hurdle_poisson", "zip_mixed")] <- "poisson"
  out$families[out$id %in% c("negative_binomial", "zinb", "hurdle", "hurdle_negbin", "zinb_mixed")] <- "negative_binomial"
  out$families[out$id == "quasipoisson"] <- "quasipoisson"
  out$families[out$id == "gamma"] <- "Gamma"
  out$families[out$id == "beta"] <- "beta"
  out$families[out$id == "manyglm"] <- "negative.binomial,poisson"
  out$families[out$id == "gllvm"] <- "poisson,negative.binomial"
  out$families[out$id == "jsdm"] <- "normal,poisson,probit"
  out$links <- ifelse(grepl("binomial|beta", out$families), "logit,probit,cloglog", ifelse(grepl("poisson|negative|Gamma", out$families), "log,sqrt,identity", "identity"))
  # These engines currently do notGrouping variablesWrite real design matrix，Therefore must not declareGroupingAbilities。
  out$grouping[out$id %in% c("pcr", "pls1", "pls2", "ridge", "lasso", "elastic_net")] <- FALSE
  out$supports_covariates <- out$multi_predictor
  out$supports_group_main <- out$grouping
  out$supports_group_independent <- out$grouping & !out$random_effects
  out$supports_continuous_moderator <- out$interaction
  out$supports_nested_crossed_random <- out$random_effects
  out$supports_offset <- out$id %in% c("poisson", "negative_binomial", "quasipoisson", "zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin", "glmm", "zip_mixed", "zinb_mixed")
  out$supports_weights <- out$id %in% c("lm", "logistic", "weighted_binomial", "gamma", "glm", "gam")
  out$supports_zero_process <- out$id %in% c("zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin", "zip_mixed", "zinb_mixed")
  out$supports_response_prediction <- grepl("response", out$prediction_scales)
  out$supports_confidence_interval <- out$fit_curve
  out$supports_multiple_testing <- out$response_support == "matrix"
  out$result_tables <- "data_summary,formula,coefficients,overall_tests,fit_metrics,predictions,diagnostics,warnings,errors"
  out$plot_types <- "fit,observed_predicted,residual,coefficients"
  out$variable_controls <- "response,focus,covariates"
  out$variable_controls[out$grouping | out$random_effects] <- paste0(out$variable_controls[out$grouping | out$random_effects], ",group")
  out$variable_controls[out$supports_zero_process] <- paste0(out$variable_controls[out$supports_zero_process], ",zero_predictors")
  out$parameter_controls <- "scenario"
  out$parameter_controls[out$id %in% c("logistic", "poisson", "gamma", "quasipoisson", "quasibinomial")] <- "scenario,link"
  out$parameter_controls[out$id == "aggregated_binomial"] <- "scenario,link"
  out$variable_controls[out$id == "aggregated_binomial"] <- "response,focus,covariates,trials"
  out$parameter_controls[out$id == "weighted_binomial"] <- "scenario,link"
  out$variable_controls[out$id == "weighted_binomial"] <- "response,focus,covariates,trials"
  out$parameter_controls[out$id == "multinomial"] <- "scenario,reference_level"
  out$parameter_controls[out$id == "ordinal"] <- "scenario,link"
  out$parameter_controls[out$id %in% c("polynomial")] <- "scenario,degree"
  out$parameter_controls[out$id == "segmented"] <- "scenario,breakpoint"
  out$parameter_controls[out$id == "nls"] <- "scenario,nls_formula,nls_start"
  out$parameter_controls[out$id == "loess"] <- "scenario,loess_span"
  out$parameter_controls[out$id %in% c("lmm")] <- "scenario,reml,random_slope"
  out$parameter_controls[out$id == "glmm"] <- "scenario,family,random_slope"
  out$parameter_controls[out$id %in% c("zip_mixed", "zinb_mixed")] <- "scenario,random_slope"
  mixed_structure_ids <- c("lmm", "glmm", "gamm", "zip_mixed", "zinb_mixed")
  out$parameter_controls[out$id %in% mixed_structure_ids] <- paste0(
    out$parameter_controls[out$id %in% mixed_structure_ids], ",random_structure"
  )
  out$variable_controls[out$id %in% mixed_structure_ids] <- paste0(
    out$variable_controls[out$id %in% mixed_structure_ids], ",random_intercept,random_slope_variable,nested_group,crossed_groups"
  )
  out$parameter_controls[out$id %in% c("beta", "zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin")] <- "scenario,link"
  out$parameter_controls[out$id %in% c("pcr", "pls1", "pls2")] <- "scenario,n_components,standardize,cv_folds"
  out$parameter_controls[out$id == "multivariate_tree"] <- "scenario,standardize,tree_cp,tree_minsplit,tree_maxdepth,cv_folds"
  out$parameter_controls[out$id %in% c("ridge", "lasso", "elastic_net")] <- "scenario,standardize,cv_folds,lambda_rule"
  out$parameter_controls[out$id == "elastic_net"] <- paste0(out$parameter_controls[out$id == "elastic_net"], ",alpha")
  out$parameter_controls[out$id == "gam"] <- "scenario,smooth_k,smooth_basis"
  out$parameter_controls[out$id == "quantile"] <- "scenario,tau"
  out$parameter_controls[out$id %in% c("rda", "cca", "dbrda")] <- "scenario,permutations"
  out$parameter_controls[out$id == "manyglm"] <- "scenario,family,permutations,fdr_method"
  out$parameter_controls[out$id == "rrr"] <- "scenario,n_components,standardize,cv_folds"
  out$parameter_controls[out$id == "gllvm"] <- "scenario,family,n_components,standardize,seed"
  out$parameter_controls[out$id == "jsdm"] <- "scenario,family,mcmc_samples,mcmc_transient,seed"
  out$parameter_controls[out$id %in% c("ancombc2", "deseq2", "edger")] <- "scenario,minimum_total_abundance,minimum_prevalence,fdr_method"
  out$parameter_controls[out$id == "aldex2"] <- "scenario,minimum_total_abundance,minimum_prevalence,mcmc_samples,fdr_method"
  out$parameter_controls[out$id == "maaslin2"] <- "scenario,minimum_total_abundance,minimum_prevalence,normalization,transformation,standardize,fdr_method"
  out$parameter_controls[out$id == "corncob"] <- "scenario,minimum_total_abundance,minimum_prevalence,fdr_method"
  out$parameter_controls[out$id == "metagenomeseq"] <- "scenario,minimum_total_abundance,minimum_prevalence,fdr_method"
  out$variable_controls[out$id == "corncob"] <- "response,focus,covariates,dispersion_predictors"
  out$variable_controls[out$id == "aldex2"] <- "response,focus"
  out$multi_predictor[out$id == "aldex2"] <- FALSE
  out$supports_covariates[out$id == "aldex2"] <- FALSE
  out$parameter_controls[out$id == "multivariable_association"] <- "scenario,standardize,fdr_method"
  out$variable_controls[out$id == "pgls"] <- "response,focus,covariates,feature_id,phylogeny"
  out$parameter_controls[out$id == "pgls"] <- "scenario,phylogenetic_model"
  out$result_tables[out$id == "pgls"] <- "data_summary,formula,coefficients,fit_metrics,predictions,diagnostics,warnings,errors"
  out$plot_types[out$id == "pgls"] <- "fit,observed_predicted,residual,coefficients,phylogenetic_association"
  out$variable_controls[out$id == "mediation"] <- "response,focus,mediators,covariates"
  out$variable_controls[out$id == "moderation"] <- "response,focus,moderator,covariates"
  out$parameter_controls[out$id == "mediation"] <- "scenario,bootstrap,confidence_level"
  out$parameter_controls[out$id == "moderation"] <- "scenario,center,confidence_level"
  selection_ids <- c("lm", "polynomial", "logistic", "poisson", "negative_binomial", "gamma")
  out$parameter_controls[out$id %in% selection_ids] <- paste0(
    out$parameter_controls[out$id %in% selection_ids], ",collinearity,variable_selection"
  )
  out$result_tables[out$id %in% selection_ids] <- paste0(
    out$result_tables[out$id %in% selection_ids], ",collinearity,variable_selection"
  )
  out$implementation_complete <- out$implemented
  out$available <- if (exists("dava_packages_available", mode = "function")) {
    dava_packages_available(out$package)
  } else {
    installed_packages <- rownames(utils::installed.packages())
    out$package %in% c("stats", "splines") | out$package %in% installed_packages
  }

  # NextcolumnfieldForm the only ability contract。UI、Model settings、ResultspageandDrawingSelectonly reads thesefield，
  # Incompletely implemented method even if dependencies are installed，cannot be marked as available eitherRun。
  out$english_name <- out$id
  out$category_id <- NA_character_
  category_ids <- list(
    classic = c("lm", "polynomial", "segmented", "nls", "robust", "quantile"),
    glm = c("logistic", "aggregated_binomial", "weighted_binomial", "poisson", "negative_binomial", "gamma", "beta", "multinomial", "ordinal", "quasipoisson", "quasibinomial"),
    mixed_zero = c("lmm", "glmm", "gamm", "zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin", "zip_mixed", "zinb_mixed"),
    nonlinear_regularized = c("gam", "loess", "pcr", "pls1", "pls2", "ridge", "lasso", "elastic_net", "rpart", "random_forest", "xgboost"),
    mediation_moderation = c("mediation", "moderation"),
    community_multivariate = c("rda", "cca", "dbrda", "manyglm", "gllvm", "jsdm", "rrr", "multivariate_tree"),
    microbiome = c("maaslin2", "ancombc2", "deseq2", "edger", "corncob", "aldex2", "metagenomeseq", "multivariable_association", "pgls")
  )
  for (category_id in names(category_ids)) out$category_id[out$id %in% category_ids[[category_id]]] <- category_id
  if (anyNA(out$category_id)) stop("There is an unclassified model in the regression registry.", call. = FALSE)
  out$short_label <- out$label
  out$description <- paste0(out$label, ";Execution engine:", out$engine, "。")
  out$method_group <- "general"
  out$data_roles <- ifelse(out$response_support == "matrix", "response_matrix,explanatory_variables", "response,focus,covariates")
  out$needs_metadata <- out$id %in% c("maaslin2", "ancombc2", "deseq2", "edger", "corncob", "aldex2", "metagenomeseq", "multivariable_association")
  out$needs_metadata[out$id == "multivariable_association"] <- FALSE
  out$needs_taxonomy <- out$id %in% c("maaslin2", "ancombc2", "deseq2", "edger", "corncob", "aldex2", "metagenomeseq")
  out$needs_phylogeny <- out$id == "pgls"
  out$requires_raw_counts <- out$id %in% c("deseq2", "edger", "ancombc2", "metagenomeseq")
  out$allows_relative_abundance <- out$id %in% c("maaslin2", "aldex2", "multivariable_association")
  out$supports_continuous_predictor <- TRUE
  out$supports_categorical_predictor <- out$categorical_predictor
  out$supports_multiple_covariates <- out$multi_predictor
  out$supports_interaction <- out$interaction
  out$supports_random_intercept <- out$random_effects
  out$supports_random_slope <- out$random_effects
  out$supports_multiple_random <- out$random_effects
  out$supports_nested_random <- out$random_effects
  out$supports_crossed_random <- out$random_effects
  out$supports_dispersion_formula <- out$id %in% c("beta", "zip_mixed", "zinb_mixed", "corncob")
  out$supports_conditioning <- out$id %in% c("rda", "cca", "dbrda")
  out$supports_latent_variables <- out$id %in% c("gllvm", "jsdm")
  out$supports_phylogenetic_structure <- out$id == "pgls"
  out$analysis_scenarios <- "overall"
  out$analysis_scenarios[out$supports_group_main] <- "overall,group_main,group_interaction,group_independent"
  out$analysis_scenarios[out$random_effects] <- "hierarchical"
  out$analysis_scenarios[out$id == "moderation"] <- "moderation"
  out$analysis_scenarios[out$id == "mediation"] <- "mediation"
  out$analysis_scenarios[out$id %in% c("rda", "cca", "dbrda")] <- "overall,community_condition"
  out$analysis_scenarios[out$needs_metadata] <- "microbiome_contrast,microbiome_interaction"
  out$input_controls <- out$variable_controls
  out$setting_controls <- out$parameter_controls
  out$output_types <- out$result_tables
  out$plot_types <- "fit,observed_predicted,residual,coefficients"
  out$plot_types[out$id %in% c("logistic", "quasibinomial")] <- "fit,observed_predicted,residual,coefficients"
  out$plot_types[out$id %in% c("poisson", "negative_binomial", "gamma", "quasipoisson", "beta")] <- "fit,observed_predicted,residual,coefficients"
  out$plot_types[out$id %in% c("lmm", "glmm", "gamm", "zip_mixed", "zinb_mixed")] <- "fit,observed_predicted,residual,coefficients"
  out$plot_types[out$id %in% c("zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin")] <- "fit,observed_predicted,coefficients"
  out$plot_types[out$id %in% c("pcr", "pls1", "pls2")] <- "fit,observed_predicted,scores,loadings"
  out$plot_types[out$id == "pls2"] <- "observed_predicted,scores,loadings"
  out$plot_types[out$id == "multivariate_tree"] <- "tree,observed_predicted,residual,importance"
  out$plot_types[out$id %in% c("ridge", "lasso", "elastic_net")] <- "fit,observed_predicted,coefficients,cv"
  out$plot_types[out$id %in% c("rda", "cca", "dbrda")] <- "ordination,site_scores,species_scores,explained_variance"
  out$plot_types[out$id == "manyglm"] <- "observed_predicted,coefficients,effect_heatmap"
  out$plot_types[out$id == "gllvm"] <- "observed_predicted,coefficients,scores,loadings"
  out$plot_types[out$id == "rrr"] <- "observed_predicted,coefficients,scores,loadings"
  out$plot_types[out$id == "multivariable_association"] <- "volcano,effect_forest,observed_predicted"
  out$plot_types[out$id == "mediation"] <- "mediation_path,mediation_effects"
  out$plot_types[out$id == "moderation"] <- "simple_slopes,johnson_neyman,observed_predicted,coefficients"
  out$plot_types[out$needs_metadata] <- "volcano,effect_forest,feature_heatmap,abundance,prevalence"
  out$implementation_complete <- out$implemented
  out$runnable <- out$implementation_complete & out$ui_exposed & out$available
  out$unavailable_reason <- ""
  out$unavailable_reason[!out$implementation_complete] <- "The analysis link has not yet been fully implemented"
  out$unavailable_reason[out$implementation_complete & !out$available] <- paste0(
    "Missing dependency packages:", out$package[out$implementation_complete & !out$available]
  )
  out
}

regression_capability_has <- function(capability, field, control) {
  value <- capability[[field]] %||% ""
  control %in% trimws(strsplit(as.character(value[1]), ",", fixed = TRUE)[[1]])
}

# Unified ControlsTable of ContentsOnly describes the input role，Do not save directly Shiny tagobject。
# The model registry declares control IDs; the page builder creates one input per ID.
regression_control_catalog <- function() {
  controls <- list(
    data = c("dataset", "response", "responses", "response_matrix", "environment_data", "metadata", "taxonomy", "phylogeny", "sample_id", "feature_id"),
    variables = c("focus", "covariates", "numeric_covariates", "factor_covariates", "group", "moderator", "mediators", "random_intercept", "random_slope_variable", "nested_group", "crossed_groups", "zero_predictors", "dispersion_predictors", "offset", "exposure", "weights", "successes", "failures", "trials"),
    structure = c("scenario", "interactions", "random_structure", "zero_formula", "dispersion_formula", "condition_variables"),
    estimation = c("family", "link", "reference_level", "event_level", "degree", "polynomial_basis", "breakpoint", "breakpoint_count", "nls_formula", "nls_start", "smooth_basis", "smooth_k", "n_components", "alpha", "lambda_rule", "standardize", "center", "cv_folds", "bootstrap", "permutations", "fdr_method", "abundance_filter", "prevalence_filter", "normalization", "transformation", "seed", "reml", "random_slope", "loess_span", "tau", "num_trees", "nrounds", "tree_cp", "tree_minsplit", "tree_maxdepth", "phylogenetic_model", "mcmc_samples", "mcmc_transient", "minimum_total_abundance", "minimum_prevalence", "collinearity", "variable_selection"),
    prediction = c("prediction_focus", "reference_values", "prediction_points", "prediction_scale", "confidence_level", "prediction_type", "show_group_curves")
  )
  data.frame(
    id = unlist(controls, use.names = FALSE),
    section = rep(names(controls), lengths(controls)),
    stringsAsFactors = FALSE
  )
}

regression_control_ids <- function(capability, field = c("input_controls", "setting_controls")) {
  field <- match.arg(field)
  value <- as.character(capability[[field]][1] %||% "")
  ids <- trimws(strsplit(value, ",", fixed = TRUE)[[1]])
  ids[nzchar(ids)]
}

validate_regression_control_schema <- function(registry = REGRESSION_MODEL_REGISTRY) {
  known <- regression_control_catalog()$id
  declared <- unique(unlist(lapply(seq_len(nrow(registry)), function(i) c(
    regression_control_ids(registry[i, , drop = FALSE], "input_controls"),
    regression_control_ids(registry[i, , drop = FALSE], "setting_controls")
  )), use.names = FALSE))
  unknown <- setdiff(declared, known)
  if (length(unknown)) stop("The regression capability table declares an unregistered control:", paste(unknown, collapse = ", "), call. = FALSE)
  invisible(TRUE)
}

REGRESSION_MODEL_REGISTRY <- regression_model_registry()

refresh_regression_model_registry <- function() {
  REGRESSION_MODEL_REGISTRY <<- regression_model_registry()
  invisible(REGRESSION_MODEL_REGISTRY)
}

new_regression_model_spec <- function(method_id, responses, predictors,
                                      scenario = "overall", focus_predictor = NULL,
                                      group_var = "", random_slope = FALSE,
                                      family = NULL, link = NULL, settings = list()) {
  capability <- regression_model_capability(method_id)
  responses <- unique(as.character(responses))
  predictors <- setdiff(unique(as.character(predictors)), responses)
  if (!length(responses)) stop("Select at least one response variable.", call. = FALSE)
  if (!length(predictors)) stop("Select at least one explanatory variable.", call. = FALSE)
  if (!isTRUE(capability$implemented)) {
    stop(sprintf("%s Dependencies and model capabilities have been registered, but the fitting adapter has not yet been connected.", capability$label), call. = FALSE)
  }
  if (length(responses) > 1L && !capability$response_support %in% c("multiple", "matrix")) {
    stop(sprintf("%s only supports single response variables.", capability$label), call. = FALSE)
  }
  core <- list(
    method_id = method_id, responses = responses, predictors = predictors,
    response_structure = if (length(responses) > 1L) "multiple" else "single",
    predictor_structure = if (length(predictors) > 1L) "multivariate" else "univariate",
    scenario = scenario, focus_predictor = focus_predictor %||% predictors[1],
    group_var = group_var, random_slope = isTRUE(random_slope), family = family,
    link = link
  )
  structure(utils::modifyList(settings, core), class = c("dava_regression_model_spec", "list"))
}

as_regression_model_spec <- function(settings) {
  if (inherits(settings, "dava_regression_model_spec")) return(settings)
  if (!is.list(settings)) stop("Regression model settings must be a list.", call. = FALSE)
  new_regression_model_spec(
    method_id = settings$method_id, responses = settings$responses,
    predictors = settings$predictors, scenario = settings$scenario %||% "overall",
    focus_predictor = settings$focus_predictor %||% NULL,
    group_var = settings$group_var %||% "", random_slope = settings$random_slope %||% FALSE,
    family = settings$family %||% NULL, link = settings$link %||% NULL,
    settings = settings
  )
}

regression_model_capability <- function(method) {
  registry <- REGRESSION_MODEL_REGISTRY
  row <- registry[registry$id == method, , drop = FALSE]
  if (!nrow(row)) stop(sprintf("Unknown regression method: %s", method), call. = FALSE)
  row[1, , drop = FALSE]
}

regression_method_ids_for_entry <- function(analysis_type) {
  ids <- switch(analysis_type,
    reg_classic = c("lm", "polynomial", "segmented", "nls", "robust"),
    reg_glm = c("logistic", "aggregated_binomial", "weighted_binomial", "poisson", "negative_binomial", "gamma", "beta", "multinomial", "ordinal", "quasipoisson", "quasibinomial"),
    reg_mixed_zero = c("lmm", "glmm"),
    reg_nonlinear_regularized = c("pls1", "pls2"),
    reg_mediation = "segmented",
    reg_community = "multivariate_tree",
    rda = "rda",
    cca = "cca",
    dbrda = "dbrda",
    micro_maaslin2 = "maaslin2",
    micro_corncob = "corncob",
    micro_aldex2 = "aldex2",
    micro_multivariable_association = "multivariable_association",
    micro_pgls = "pgls",
    micro_rda = "rda",
    micro_cca = "cca",
    micro_dbrda = "dbrda",
    reg_microbiome = c("maaslin2", "ancombc2", "deseq2", "edger", "corncob", "aldex2", "metagenomeseq", "multivariable_association", "pgls"),
    reg_continuous = c("lm", "polynomial", "segmented"),
    reg_generalized = c("logistic", "poisson", "negative_binomial", "gamma", "quasipoisson", "quasibinomial", "beta"),
    reg_zero_part = c("zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin"),
    reg_mixed = c("lmm", "glmm", "gamm", "zip_mixed", "zinb_mixed"),
    reg_semiparametric = c("gam", "loess", "quantile", "robust"),
    reg_highdim = c("pcr", "pls1", "pls2", "ridge", "lasso", "elastic_net", "rpart", "random_forest", "xgboost"),
    lm = c("lm", "polynomial", "segmented"),
    poly = c("lmm", "glmm", "gamm", "zip_mixed", "zinb_mixed"),
    glm = c("logistic", "poisson", "negative_binomial", "gamma", "quasipoisson", "quasibinomial",
            "beta", "zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin"),
    pls = c("pcr", "pls1", "pls2"),
    regularized = c("ridge", "lasso", "elastic_net"),
    robust = c("gam", "loess", "quantile", "robust"),
    tree_ml = c("rpart", "random_forest", "xgboost"),
    character()
  )
  ids
}

regression_methods_for_entry <- function(analysis_type) {
  ids <- regression_method_ids_for_entry(analysis_type)
  registry <- REGRESSION_MODEL_REGISTRY
  selected <- registry[match(ids, registry$id, nomatch = 0L), , drop = FALSE]
  selected[selected$implemented & selected$ui_exposed & selected$available, , drop = FALSE]
}

regression_unavailable_methods_for_entry <- function(analysis_type) {
  ids <- regression_method_ids_for_entry(analysis_type)
  selected <- REGRESSION_MODEL_REGISTRY[match(ids, REGRESSION_MODEL_REGISTRY$id, nomatch = 0L), , drop = FALSE]
  selected[selected$implemented & selected$ui_exposed & !selected$available, , drop = FALSE]
}

regression_default_method <- function(analysis_type) {
  switch(analysis_type,
         reg_classic = "lm", reg_glm = "logistic", reg_mixed_zero = "lmm",
         reg_nonlinear_regularized = "pls1", reg_mediation = "segmented",
         reg_community = "multivariate_tree", reg_microbiome = "maaslin2",
         rda = "rda", cca = "cca", dbrda = "dbrda",
         micro_maaslin2 = "maaslin2",
         micro_corncob = "corncob", micro_aldex2 = "aldex2",
         micro_multivariable_association = "multivariable_association",
         micro_pgls = "pgls", micro_rda = "rda", micro_cca = "cca", micro_dbrda = "dbrda",
         reg_continuous = "lm", reg_generalized = "logistic", reg_zero_part = "zip",
         reg_mixed = "lmm", reg_semiparametric = "gam", reg_highdim = "pls1",
         lm = "lm", poly = "lmm", glm = "logistic", pls = "pls1",
         regularized = "ridge", robust = "gam", tree_ml = "rpart", "lm")
}

regression_method_help <- function(method) {
  switch(method,
    lm = "Conventional linear relationship for continuous response variables; multiple explanatory variables can be added to control covariates.",
    polynomial = "is used when a single continuous explanatory variable has a tendency to bend and the low-order polynomial has a clear interpretation.",
    segmented = "Ecological threshold used to identify changes in the slope of the relationship between a continuous explanatory variable and the response.",
    logistic = "is used for binary response variables such as presence/absence and positive/negative.",
    poisson = "is used for non-negative counts, suitable for situations where the mean and variance are close.",
    negative_binomial = "Used for overdispersion ecological counting, generally more robust than Poisson.",
    gamma = "For continuous response variables that are strictly greater than zero and right-skewed.",
    quasipoisson = "is used for overdispersed counts, focusing on effects testing without comparing AICs.",
    beta = "For continuous proportional responses strictly between 0 and 1.",
    zip = "Count response for approximating Poisson's count response with a significant bias towards zero values ​​and a non-zero component.",
    zinb = "Used for count responses with both excessive zero values ​​and excessive dispersion.",
    hurdle = "Model zero occurrence processes separately from positive count abundance processes.",
    lmm = "is used for block, repeated measurement, or plot-level data, and the response variable is continuous.",
    glmm = "For binary or count data with random effects.",
    gamm = "For data with both nonlinear trends and random effects.",
    pls1 = "is used to explain single response predictions with many variables and obvious collinearity.",
    pls2 = "For joint forecasting of multiple correlated response variables with a set of collinear explanatory variables.",
    ridge = "Keep all variables and reduce coefficients, suitable for strong collinearity.",
    lasso = "Filter variables and reduce coefficients, which is suitable when there are many explanatory variables.",
    elastic_net = "Combining Ridge with LASSO, fits group-correlated explanatory variables.",
    gam = "Nonlinear ecological response curves for unknown forms.",
    quantile = "is used to compare different quantiles of the response distribution instead of just analyzing the mean.",
    robust = "is used when a small number of outliers may significantly affect ordinary linear regression.",
    rpart = "Generate easily interpretable regression trees for exploring thresholds and variable interactions.",
    multivariate_tree = "Using a tree to simultaneously explain multiple ecological responses is suitable for exploring the environmental thresholds and interactions of the entire community.",
    random_forest = "is used for nonlinear prediction and variable importance, focusing on predictions rather than traditional P values.",
    xgboost = "is used for more complex nonlinear predictions and is recommended to be combined with cross-validation evaluation.",
    ""
  )
}
