regression_response_candidates <- function(df, method, family = "binomial") {
  numeric_names <- names(df)[vapply(df, is.numeric, logical(1))]
  binary_names <- names(df)[vapply(df, function(x) length(unique(stats::na.omit(x))) == 2L, logical(1))]
  positive_names <- numeric_names[vapply(df[numeric_names], function(x) all(stats::na.omit(x) > 0), logical(1))]
  proportion_names <- numeric_names[vapply(df[numeric_names], function(x) {
    values <- stats::na.omit(x); length(values) && all(values > 0 & values < 1)
  }, logical(1))]
  closed_proportion_names <- numeric_names[vapply(df[numeric_names], function(x) {
    values <- stats::na.omit(x); length(values) && all(values >= 0 & values <= 1)
  }, logical(1))]
  count_names <- numeric_names[vapply(df[numeric_names], function(x) {
    values <- stats::na.omit(x); length(values) && all(values >= 0 & values == floor(values))
  }, logical(1))]
  nominal_names <- names(df)[vapply(df, function(x) is.factor(x) && !is.ordered(x) && nlevels(droplevels(x)) >= 3L, logical(1))]
  ordinal_names <- names(df)[vapply(df, function(x) is.ordered(x) && nlevels(droplevels(x)) >= 3L, logical(1))]
  if (method %in% c("logistic", "quasibinomial") || (method == "glmm" && family == "binomial")) return(binary_names)
  if (method == "aggregated_binomial") return(count_names)
  if (method == "weighted_binomial") return(closed_proportion_names)
  if (method == "multinomial") return(nominal_names)
  if (method == "ordinal") return(ordinal_names)
  if (method %in% c("poisson", "negative_binomial", "quasipoisson", "zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin", "zip_mixed", "zinb_mixed") ||
      (method == "glmm" && family == "poisson")) return(count_names)
  if (method == "beta") return(proportion_names)
  if (method == "gamma") return(positive_names)
  numeric_names
}

validate_regression_data_for_capability <- function(data, settings, capability) {
  response <- settings$responses[1]
  values <- data[[response]]
  response_type <- capability$response_types[1] %||% "numeric"
  finite_values <- values[!is.na(values)]

  if (identical(settings$method_id %||% "", "pgls")) {
    feature_id <- settings$feature_id %||% ""
    tree <- settings$phylogeny
    if (!nzchar(feature_id) || !feature_id %in% names(data)) {
      stop("PGLS The species or trait name field must be selected.", call. = FALSE)
    }
    if (!inherits(tree, "phylo")) {
      stop("PGLS must provide a valid phylogenetic tree (phylo object).", call. = FALSE)
    }
    ids <- trimws(as.character(data[[feature_id]]))
    if (anyNA(ids) || any(!nzchar(ids)) || anyDuplicated(ids)) {
      stop("Species or trait names for PGLS must be non-empty and unique.", call. = FALSE)
    }
    missing_tips <- setdiff(ids, tree$tip.label)
    extra_tips <- setdiff(tree$tip.label, ids)
    if (length(missing_tips) || length(extra_tips)) {
      stop(sprintf(
        "PGLS tree and data names do not match exactly; missing from tree: %s; missing from data: %s.",
        paste(missing_tips, collapse = ", "), paste(extra_tips, collapse = ", ")
      ), call. = FALSE)
    }
  }

  if (response_type %in% c("binary", "binomial", "binary,binomial") && length(unique(finite_values)) != 2L) {
    stop("The current model requires that the response variable contain exactly two valid levels and that the event level be specified.", call. = FALSE)
  }
  if (identical(response_type, "count")) {
    numeric_values <- suppressWarnings(as.numeric(finite_values))
    if (any(!is.finite(numeric_values) | numeric_values < 0 | numeric_values != floor(numeric_values))) {
      stop("Count regression requires the response variable to be a non-negative integer and is not silently converted or truncated.", call. = FALSE)
    }
  }
  if (identical(response_type, "aggregated_binomial")) {
    trial_var <- settings$trials_var %||% ""
    if (!nzchar(trial_var) || !trial_var %in% names(data)) stop("Aggregate binomial regression must select the total number of trials variable.", call. = FALSE)
    successes <- suppressWarnings(as.numeric(values))
    trials <- suppressWarnings(as.numeric(data[[trial_var]]))
    invalid <- !is.finite(successes) | !is.finite(trials) | successes < 0 | trials <= 0 |
      successes != floor(successes) | trials != floor(trials) | successes > trials
    if (any(invalid)) stop("The number of successes and the total number of trials must be non-negative integers, the total number must be greater than zero, and the number of successes must not exceed the total number.", call. = FALSE)
  }
  if (identical(response_type, "weighted_proportion")) {
    trial_var <- settings$trials_var %||% ""
    if (!nzchar(trial_var) || !trial_var %in% names(data)) stop("Proportionally weighted binomial regression must select the total number of trials variable.", call. = FALSE)
    proportions <- suppressWarnings(as.numeric(values))
    trials <- suppressWarnings(as.numeric(data[[trial_var]]))
    successes <- proportions * trials
    invalid <- !is.finite(proportions) | !is.finite(trials) | proportions < 0 | proportions > 1 |
      trials <= 0 | trials != floor(trials) | abs(successes - round(successes)) > sqrt(.Machine$double.eps)
    if (any(invalid)) stop("The scale must be between 0 and 1, the number of trials must be a positive integer, and the number of implied successes must be an integer.", call. = FALSE)
  }
  if (identical(response_type, "nominal_factor")) {
    if (!is.factor(values) || is.ordered(values) || nlevels(droplevels(values)) < 3L) stop("Multinomial logistic requires at least three levels of unordered factor responses.", call. = FALSE)
    reference <- settings$reference_level %||% ""
    if (!nzchar(reference) || !reference %in% levels(values)) stop("Multiple logistic must explicitly select a valid reference category.", call. = FALSE)
  }
  if (identical(response_type, "ordered_factor")) {
    if (!is.ordered(values) || nlevels(droplevels(values)) < 3L) stop("Ordinal Logistic requires at least three levels of ordered factor responses in a clear order.", call. = FALSE)
  }
  if (identical(response_type, "positive_numeric") && any(!is.finite(finite_values) | finite_values <= 0)) {
    stop("Gamma regression requires that all response variables be strictly greater than 0.", call. = FALSE)
  }
  if (identical(response_type, "proportion_open_unit") && any(!is.finite(finite_values) | finite_values <= 0 | finite_values >= 1)) {
    stop("Beta regression requires that the response variable lies strictly between 0 and 1; boundary values are not silently truncated.", call. = FALSE)
  }

  scenario <- settings$scenario %||% "overall"
  supported <- trimws(strsplit(capability$analysis_scenarios[1] %||% "overall", ",", fixed = TRUE)[[1]])
  if (!scenario %in% supported) stop(sprintf("%s The current analysis scenario: %s is not supported.", capability$label, scenario), call. = FALSE)

  group_var <- settings$group_var %||% ""
  if (!scenario %in% c("overall", "mediation", "moderation", "microbiome_contrast", "microbiome_interaction")) {
    if (!nzchar(group_var) || !group_var %in% names(data)) stop("A valid grouping variable must be selected for the current analysis scenario.", call. = FALSE)
    group_counts <- table(data[[group_var]])
    if (length(group_counts) < 2L) stop("Group or random effects variables require at least two valid levels.", call. = FALSE)
    if (isTRUE(capability$random_effects) && any(group_counts < 2L)) {
      stop("At least two replicate observations are required for each level of the random effects variable.", call. = FALSE)
    }
    if (isTRUE(settings$random_slope)) {
      focus <- settings$focus_predictor
      within_group_levels <- tapply(data[[focus]], data[[group_var]], function(x) length(unique(x[!is.na(x)])))
      if (any(within_group_levels < 2L)) stop("The random slope variable must vary within each random effect level.", call. = FALSE)
    }
  }
  invisible(TRUE)
}

prepare_regression_data <- function(df, responses, predictors, group_var = "", weight_var = "", extra_vars = character()) {
  responses <- intersect(unique(responses), names(df))
  predictors <- setdiff(intersect(unique(predictors), names(df)), responses)
  extra <- c(group_var, weight_var, extra_vars)
  extra <- intersect(extra[nzchar(extra)], names(df))
  vars <- unique(c(responses, predictors, extra))
  if (!length(responses)) stop("Please select a valid response variable.", call. = FALSE)
  if (!length(predictors)) stop("Please select at least one explanatory variable, and the response variable cannot be used as an explanatory variable at the same time.", call. = FALSE)
  dat <- as.data.frame(df[, vars, drop = FALSE], stringsAsFactors = FALSE, check.names = FALSE)
  for (response in responses) {
    if (!is.numeric(dat[[response]]) && !is.factor(dat[[response]])) dat[[response]] <- type.convert(dat[[response]], as.is = TRUE)
  }
  if (nzchar(group_var) && group_var %in% names(dat)) dat[[group_var]] <- droplevels(factor(dat[[group_var]]))
  dat$.dava_row_id <- seq_len(nrow(dat))
  complete <- stats::complete.cases(dat[, setdiff(names(dat), ".dava_row_id"), drop = FALSE])
  model_data <- dat[complete, , drop = FALSE]
  if (nrow(model_data) < 5L) stop("Unable to fit regression model with fewer than 5 complete observations.", call. = FALSE)
  one_level <- predictors[vapply(model_data[predictors], function(x) length(unique(x)) < 2L, logical(1))]
  if (length(one_level)) stop(sprintf("The explanatory variable has only one valid level: %s", paste(one_level, collapse = ", ")), call. = FALSE)
  list(
    data = model_data,
    responses = responses,
    predictors = predictors,
    removed_rows = sum(!complete),
    summary = data.frame(
      observations_total = nrow(dat), observations_used = nrow(model_data),
      observations_removed = sum(!complete), responses = paste(responses, collapse = ", "),
      predictors = paste(predictors, collapse = ", "), stringsAsFactors = FALSE
    )
  )
}

align_regression_datasets <- function(datasets, id_columns) {
  if (!is.list(datasets) || length(datasets) < 2L || is.null(names(datasets)) || any(!nzchar(names(datasets)))) {
    stop("Multi-dataset mode requires at least two named datasets.", call. = FALSE)
  }
  if (is.null(names(id_columns))) id_columns <- stats::setNames(rep(as.character(id_columns)[1], length(datasets)), names(datasets))
  missing_specs <- setdiff(names(datasets), names(id_columns))
  if (length(missing_specs)) stop("The following dataset is missing the sample ID field configuration:", paste(missing_specs, collapse = ", "), call. = FALSE)

  normalized <- lapply(names(datasets), function(name) {
    data <- as.data.frame(datasets[[name]], stringsAsFactors = FALSE, check.names = FALSE)
    id_column <- as.character(id_columns[[name]])[1]
    if (!nzchar(id_column) || !id_column %in% names(data)) stop(sprintf("Data set %s does not contain sample ID field %s.", name, id_column), call. = FALSE)
    ids <- trimws(as.character(data[[id_column]]))
    if (anyNA(ids) || any(!nzchar(ids))) stop(sprintf("Sample ID for dataset %s contains missing or null values.", name), call. = FALSE)
    duplicates <- unique(ids[duplicated(ids)])
    if (length(duplicates)) stop(sprintf("Data set %s has duplicate sample ID: %s", name, paste(head(duplicates, 10L), collapse = ", ")), call. = FALSE)
    data$.dava_sample_id <- ids
    data
  })
  names(normalized) <- names(datasets)

  id_sets <- lapply(normalized, `[[`, ".dava_sample_id")
  common_ids <- Reduce(intersect, id_sets)
  if (!length(common_ids)) stop("There is no common sample ID between multiple datasets.", call. = FALSE)
  reference_ids <- id_sets[[1]]
  common_ids <- reference_ids[reference_ids %in% common_ids]
  aligned <- lapply(normalized, function(data) data[match(common_ids, data$.dava_sample_id), , drop = FALSE])
  missing <- lapply(id_sets, function(ids) setdiff(Reduce(union, id_sets), ids))
  report <- data.frame(
    dataset = names(datasets), input_samples = lengths(id_sets), aligned_samples = length(common_ids),
    excluded_samples = lengths(id_sets) - length(common_ids), missing_from_dataset = vapply(missing, function(x) paste(x, collapse = ", "), character(1)),
    stringsAsFactors = FALSE
  )
  list(data = aligned, sample_ids = common_ids, report = report)
}

prepare_regression_microbiome_counts <- function(data, settings) {
  features <- intersect(unique(settings$responses %||% character()), names(data))
  predictors <- intersect(unique(settings$predictors %||% character()), names(data))
  metadata_variables <- intersect(unique(c(predictors, settings$dispersion_predictors %||% character())), names(data))
  if (length(features) < 2L) stop("Microbiome models require at least two feature count columns.", call. = FALSE)
  counts <- as.matrix(data[, features, drop = FALSE])
  storage.mode(counts) <- "double"
  if (any(!is.finite(counts) | counts < 0 | counts != floor(counts))) {
    stop("The current microbial count model must use non-negative integer raw counts; it must not use relative abundance or silent rounding.", call. = FALSE)
  }
  focus <- settings$focus_predictor %||% ""
  if (!nzchar(focus) || !focus %in% predictors) stop("Microbiome models must select valid variables of interest.", call. = FALSE)
  design_data <- as.data.frame(data[, metadata_variables, drop = FALSE], check.names = FALSE)
  if (is.character(design_data[[focus]])) design_data[[focus]] <- factor(design_data[[focus]])
  if (is.factor(design_data[[focus]]) && nlevels(droplevels(design_data[[focus]])) < 2L) {
    stop("The microbiome grouping variable requires at least two valid levels.", call. = FALSE)
  }
  min_total <- max(0, as.numeric(settings$minimum_total_abundance %||% 10))
  min_prevalence <- min(1, max(0, as.numeric(settings$minimum_prevalence %||% 0.1)))
  totals <- colSums(counts)
  prevalence <- colMeans(counts > 0)
  keep <- totals >= min_total & prevalence >= min_prevalence
  filter_record <- data.frame(
    feature = features, total_abundance = totals, prevalence = prevalence, retained = keep,
    reason = ifelse(keep, "retained", ifelse(totals < min_total, "low_total_abundance", "low_prevalence")),
    stringsAsFactors = FALSE
  )
  if (sum(keep) < 2L) stop("There are less than two features after microbial feature filtering and the model cannot be run.", call. = FALSE)
  list(
    counts = round(t(counts[, keep, drop = FALSE])), metadata = design_data,
    features = features[keep], filter_record = filter_record,
    design = stats::reformulate(predictors)
  )
}
