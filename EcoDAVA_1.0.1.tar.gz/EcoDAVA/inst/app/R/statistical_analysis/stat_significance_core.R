# UnificationSignificanceResultsContractandFormat Tool。

dava_significance_thresholds <- function(alpha = 0.05, thresholds = NULL) {
  defaults <- c("****" = 0.0001, "***" = 0.001, "**" = 0.01, "*" = alpha)
  if (is.null(thresholds)) return(defaults)
  values <- suppressWarnings(as.numeric(thresholds))
  names(values) <- names(thresholds)
  values[is.finite(values) & values > 0]
}

p_to_significance <- function(p, alpha = 0.05, thresholds = NULL, show_ns = TRUE) {
  p <- suppressWarnings(as.numeric(p))
  cuts <- dava_significance_thresholds(alpha, thresholds)
  vapply(p, function(value) {
    if (!is.finite(value)) return(NA_character_)
    hit <- names(cuts)[value < cuts]
    if (length(hit)) hit[1] else if (isTRUE(show_ns)) "ns" else ""
  }, character(1))
}

format_p_value <- function(p, digits = 3, prefix = "P") {
  p <- suppressWarnings(as.numeric(p))
  vapply(p, function(value) {
    if (!is.finite(value)) return(NA_character_)
    cutoff <- 10^(-digits)
    if (value < cutoff) return(sprintf("%s < %.*f", prefix, digits, cutoff))
    sprintf("%s = %.*f", prefix, digits, value)
  }, character(1))
}

dava_empty_annotation_table <- function() {
  data.frame(
    response = character(), label = character(), p_value = numeric(),
    p_adjusted = numeric(), annotation_type = character(), x = numeric(),
    xend = numeric(), y = numeric(), yend = numeric(), panel_id = character(),
    comparison_scope = character(), stringsAsFactors = FALSE
  )
}

dava_result_table_contract <- function(table, response = "", term = "") {
  out <- as.data.frame(table, stringsAsFactors = FALSE, check.names = FALSE)
  if (!"response" %in% names(out)) out[["response"]] <- rep(response, nrow(out))
  if (!"term" %in% names(out)) out[["term"]] <- rep(term, nrow(out))
  out
}

dava_new_analysis_result <- function(
    model = NULL, model_class = "", response = "", fixed_factors = character(),
    random_effects = character(), family = NULL, effect_table = data.frame(),
    interaction_status = list(), emmeans = data.frame(), pairwise = data.frame(),
    cld = data.frame(), annotations = dava_empty_annotation_table(),
    plot_data = data.frame(), warnings = character(), errors = character(),
    metadata = list()) {
  structure(list(
    model = model,
    model_class = model_class %||% class(model)[1] %||% "",
    response = response,
    fixed_factors = unique(fixed_factors[nzchar(fixed_factors)]),
    random_effects = unique(random_effects[nzchar(random_effects)]),
    family = family,
    effect_table = dava_normalize_effect_table(effect_table, response),
    interaction_status = interaction_status,
    emmeans = dava_result_table_contract(emmeans, response),
    pairwise = dava_result_table_contract(pairwise, response),
    cld = dava_result_table_contract(cld, response),
    annotations = as.data.frame(annotations, check.names = FALSE),
    plot_data = as.data.frame(plot_data, check.names = FALSE),
    warnings = unique(warnings[nzchar(warnings)]),
    errors = unique(errors[nzchar(errors)]),
    metadata = metadata
  ), class = c("dava_analysis_result", "list"))
}

dava_capture_conditions <- function(expr, source = "") {
  warnings <- character()
  messages <- character()
  value <- tryCatch(
    withCallingHandlers(
      expr,
      warning = function(w) {
        text <- conditionMessage(w)
        warnings <<- c(warnings, text)
        if (exists("dava_record_runtime_condition", mode = "function")) {
          dava_record_runtime_condition("warning", text, source)
        }
        invokeRestart("muffleWarning")
      },
      message = function(m) {
        text <- conditionMessage(m)
        messages <<- c(messages, text)
        if (exists("dava_record_runtime_condition", mode = "function")) {
          dava_record_runtime_condition("message", text, source)
        }
        invokeRestart("muffleMessage")
      }
    ),
    error = function(e) {
      if (!inherits(e, "shiny.silent.error") &&
          exists("dava_record_runtime_condition", mode = "function")) {
        dava_record_runtime_condition("error", conditionMessage(e), source)
      }
      e
    }
  )
  list(
    value = if (inherits(value, "error")) NULL else value,
    warnings = unique(warnings),
    messages = unique(messages),
    error = if (inherits(value, "error") &&
                !inherits(value, "shiny.silent.error")) conditionMessage(value) else ""
  )
}

dava_numeric_p <- function(x) {
  x <- trimws(as.character(x))
  x <- sub("^[<=>]+\\s*", "", x)
  suppressWarnings(as.numeric(x))
}

dava_effect_p_column <- function(effect_table) {
  candidates <- intersect(
    c("p.value", "p_value", "p-value", "Pr(>F)", "Pr(>Chisq)", "p", "p.value."),
    names(effect_table)
  )
  if (length(candidates)) candidates[[1L]] else ""
}

dava_normalize_effect_table <- function(effect_table, response = "") {
  out <- as.data.frame(effect_table, stringsAsFactors = FALSE, check.names = FALSE)
  if (!"term" %in% names(out)) {
    candidates <- intersect(c("effect", "Effect", "term.label", "rowname"), names(out))
    candidate <- if (length(candidates)) candidates[[1L]] else ""
    if (nzchar(candidate)) names(out)[names(out) == candidate] <- "term"
  }
  if (!"term" %in% names(out)) out[["term"]] <- rep("", nrow(out))
  if (!"response" %in% names(out)) out[["response"]] <- rep(response, nrow(out))
  if (!nrow(out)) {
    out$p_numeric <- numeric()
    out$significance <- character()
    return(out)
  }
  p_col <- dava_effect_p_column(out)
  p_numeric <- if (nzchar(p_col)) dava_numeric_p(out[[p_col]]) else rep(NA_real_, nrow(out))
  if (!length(p_numeric)) p_numeric <- rep(NA_real_, nrow(out))
  if (length(p_numeric) != nrow(out)) p_numeric <- rep_len(p_numeric, nrow(out))
  out$p_numeric <- p_numeric
  out$significance <- p_to_significance(out$p_numeric)
  out
}

dava_validate_analysis_result <- function(result) {
  required <- c("model", "model_class", "response", "fixed_factors", "effect_table",
                "interaction_status", "emmeans", "pairwise", "cld", "annotations",
                "warnings", "errors", "metadata")
  missing <- setdiff(required, names(result))
  list(valid = !length(missing), missing = missing)
}
