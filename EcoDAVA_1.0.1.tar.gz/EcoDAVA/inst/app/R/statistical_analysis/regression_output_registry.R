# Register fitted regression outputs without changing the active dataset.
register_regression_outputs <- function(file_data, result, prefix) {
  if (is.null(file_data) || !inherits(result, "dava_regression_result")) return(character())
  tables <- regression_result_datasets(result)
  if (!length(tables)) return(character())
  datasets <- shiny::isolate(file_data$global_datasets %||% list())
  sources <- shiny::isolate(file_data$dataset_sources %||% list())
  clean_prefix <- gsub("[^[:alnum:]_]+", "_", prefix)
  registered <- character()
  for (table_name in names(tables)) {
    base_name <- paste(clean_prefix, table_name, sep = "_")
    name <- base_name
    suffix <- 1L
    while (name %in% names(datasets)) {
      suffix <- suffix + 1L
      name <- paste0(base_name, "_", suffix)
    }
    datasets[[name]] <- as.data.frame(tables[[table_name]], stringsAsFactors = FALSE, check.names = FALSE)
    sources[[name]] <- paste("Regression model analysis", result$method_name, sep = " / ")
    registered <- c(registered, name)
  }
  file_data$global_datasets <- datasets
  file_data$dataset_sources <- sources
  registered
}

regression_code_family_call <- function(settings, default = "binomial") {
  family <- settings$family %||% default
  switch(family,
    gaussian = "stats::gaussian()",
    poisson = "stats::poisson()",
    quasipoisson = "stats::quasipoisson()",
    quasibinomial = "stats::quasibinomial()",
    Gamma =, gamma = "stats::Gamma(link = 'log')",
    binomial = "stats::binomial()",
    "stats::binomial()"
  )
}

regression_code_formula <- function(settings) {
  tryCatch(build_regression_formula(
    settings$responses, settings$predictors, settings$focus_predictor,
    settings$scenario %||% "overall", settings$group_var %||% "",
    isTRUE(settings$random_slope), settings$degree %||% 2L, settings$method_id %||% "lm",
    random_structure = settings$random_structure %||% "intercept",
    nested_group = settings$nested_group %||% "",
    crossed_groups = settings$crossed_groups %||% character(),
    random_slope_correlated = isTRUE(settings$random_slope_correlated %||% TRUE),
    random_slope_predictor = settings$random_slope_variable %||% settings$focus_predictor
  ), error = function(error) NULL)
}

regression_code_direct_call <- function(method, settings) {
  family_call <- regression_code_family_call(settings,
    if (method %in% c("poisson", "quasipoisson")) "poisson" else "binomial")
  zero_terms <- settings$zero_predictors %||% character()
  zero_formula <- if (length(zero_terms)) {
    paste("~", paste(sprintf("`%s`", zero_terms), collapse = " + "))
  } else "~ 1"
  switch(method,
    lm =, polynomial = "stats::lm(model_formula, data = df)",
    robust = "MASS::rlm(model_formula, data = df, psi = MASS::psi.huber)",
    segmented = sprintf("segmented::segmented(stats::lm(model_formula, data = df), seg.Z = ~ `%s`, psi = %.8g)",
      settings$focus_predictor %||% settings$predictors[[1]], as.numeric(settings$breakpoint %||% 0)),
    nls = "minpack.lm::nlsLM(model_formula, data = df)",
    logistic = "stats::glm(model_formula, data = df, family = stats::binomial())",
    poisson = "stats::glm(model_formula, data = df, family = stats::poisson())",
    negative_binomial = "MASS::glm.nb(model_formula, data = df)",
    gamma = "stats::glm(model_formula, data = df, family = stats::Gamma(link = 'log'))",
    quasipoisson = "stats::glm(model_formula, data = df, family = stats::quasipoisson())",
    quasibinomial = "stats::glm(model_formula, data = df, family = stats::quasibinomial())",
    aggregated_binomial = "stats::glm(model_formula, data = df, family = stats::binomial())",
    weighted_binomial = "stats::glm(model_formula, data = df, family = stats::binomial(), weights = analysis_weights)",
    multinomial = "nnet::multinom(model_formula, data = df, trace = FALSE)",
    ordinal = "MASS::polr(model_formula, data = df, Hess = TRUE)",
    beta = "betareg::betareg(model_formula, data = df)",
    lmm = sprintf("lme4::lmer(model_formula, data = df, REML = %s)", if (isTRUE(settings$reml)) "TRUE" else "FALSE"),
    glmm = paste0("lme4::glmer(model_formula, data = df, family = ", family_call, ")"),
    gamm = paste0("mgcv::gamm(model_formula, data = df, family = ", family_call, ")"),
    zip = paste0("pscl::zeroinfl(model_formula, data = df, dist = 'poisson', link = '", settings$link %||% "logit", "')"),
    zinb = paste0("pscl::zeroinfl(model_formula, data = df, dist = 'negbin', link = '", settings$link %||% "logit", "')"),
    hurdle =, hurdle_negbin = "pscl::hurdle(model_formula, data = df, dist = 'negbin')",
    hurdle_poisson = "pscl::hurdle(model_formula, data = df, dist = 'poisson')",
    zip_mixed = paste0("glmmTMB::glmmTMB(model_formula, ziformula = ", zero_formula, ", data = df, family = stats::poisson())"),
    zinb_mixed = paste0("glmmTMB::glmmTMB(model_formula, ziformula = ", zero_formula, ", data = df, family = glmmTMB::nbinom2())"),
    pls1 =, pls2 = sprintf("pls::plsr(model_formula, data = df, ncomp = %d, validation = 'CV')", as.integer(settings$n_components %||% 2L)),
    pcr = sprintf("pls::pcr(model_formula, data = df, ncomp = %d, validation = 'CV')", as.integer(settings$n_components %||% 2L)),
    ridge = "glmnet::cv.glmnet(x_matrix, y_vector, alpha = 0)",
    lasso = "glmnet::cv.glmnet(x_matrix, y_vector, alpha = 1)",
    elastic_net = sprintf("glmnet::cv.glmnet(x_matrix, y_vector, alpha = %.4g)", as.numeric(settings$elastic_alpha %||% 0.5)),
    gam = paste0("mgcv::gam(model_formula, data = df, family = ", family_call, ", method = 'REML')"),
    loess = sprintf("stats::loess(`%s` ~ `%s`, data = df, span = %.4g)",
      settings$responses[[1]], settings$focus_predictor %||% settings$predictors[[1]], as.numeric(settings$smooth_span %||% 0.75)),
    mediation = sprintf("mediation::mediate(mediator_model, outcome_model, treat = '%s', mediator = mediator_name, boot = TRUE, sims = %d)",
      settings$focus_predictor %||% settings$predictors[[1]], as.integer(settings$bootstrap %||% 1000L)),
    moderation = "stats::lm(moderation_formula, data = df)",
    multivariate_tree = sprintf("mvpart::mvpart(model_formula, data = df, xv = '1se', xval = 10, cp = %.4g, minsplit = %d)",
      as.numeric(settings$tree_cp %||% 0.01), as.integer(settings$tree_minsplit %||% 10L)),
    rda = "vegan::rda(model_formula, data = df)",
    cca = "vegan::cca(model_formula, data = df)",
    dbrda = "vegan::capscale(model_formula, data = df, distance = 'bray')",
    manyglm = "mvabund::manyglm(model_formula, data = df, family = 'negative.binomial')",
    gllvm = "gllvm::gllvm(y = response_matrix, X = predictor_frame, family = 'negative.binomial')",
    jsdm = "Hmsc::Hmsc(Y = response_matrix, XData = predictor_frame, XFormula = ~ .)",
    rrr = "rrpack::rrr(response_matrix, predictor_matrix)",
    maaslin2 = "Maaslin2::Maaslin2(input_data = t(response_matrix), input_metadata = predictor_frame, output = maaslin_output_dir)",
    ancombc2 = "ANCOMBC::ancombc2(data = count_matrix, fix_formula = group_variable, group = group_variable)",
    deseq2 = "DESeq2::DESeq(DESeq2::DESeqDataSetFromMatrix(countData = count_matrix, colData = predictor_frame, design = model_formula))",
    edger = "edgeR::glmQLFit(edgeR::estimateDisp(edgeR::calcNormFactors(edgeR::DGEList(counts = count_matrix)), design_matrix), design_matrix)",
    corncob = "corncob::differentialTest(formula = model_formula, phi.formula = ~ 1, formula_null = ~ 1, phi.formula_null = ~ 1, data = count_matrix)",
    aldex2 = "ALDEx2::aldex(count_matrix, predictor_frame[[group_variable]], test = 't', effect = TRUE)",
    metagenomeseq = "metagenomeSeq::fitZig(metagenomeSeq::cumNorm(metagenomeSeq::newMRexperiment(count_matrix)), design_matrix)",
    multivariable_association = "stats::lm(model_formula, data = df)",
    pgls = "phylolm::phylolm(model_formula, data = df, phy = phylogeny)",
    "stats::lm(model_formula, data = df)"
  )
}

regression_code_plot_value <- function(plot_params, plot_name, field, default = NULL) {
  plot_params <- plot_params %||% list()
  prefix <- paste0("regression_result_plot_", plot_name, "_")
  exact <- paste0(prefix, field)
  if (!is.null(plot_params[[exact]])) return(plot_params[[exact]])
  default
}

regression_code_plot_replay_lines <- function(plot_params = list(), plot_name = "fit",
                                               layout_rows = 1L, layout_cols = 1L) {
  q <- function(x) encodeString(as.character(x %||% ""), quote = "\"")
  val <- function(field, default) regression_code_plot_value(plot_params, plot_name, field, default)
  theme <- val("theme", "publication")
  palette <- val("palette", "Nature")
  palette_colors <- tryCatch(
    dava_plot_palette(palette, 16L),
    error = function(error) grDevices::hcl.colors(16L, "Dark 3")
  )
  base_size <- as.numeric(val("base_size", 14))
  legend <- val("legend_position", "right")
  show_legend <- isTRUE(val("show_legend", TRUE))
  x_angle <- as.numeric(val("x_angle", 0))
  flip <- isTRUE(val("flip", FALSE))
  point_color <- val("point_color", "#1F1F1F")
  point_alpha <- as.numeric(val("point_alpha", 0.65))
  point_size <- as.numeric(val("point_size", 2))
  line_color <- val("line_color", "#3B7EA1")
  line_alpha <- as.numeric(val("line_alpha", 1))
  line_width <- as.numeric(val("line_width", 1))
  confidence_color <- val("confidence_color", "#B5CEDB")
  confidence_alpha <- as.numeric(val("confidence_alpha", 0.12))
  width <- as.integer(plot_params$advanced_plot_size_width %||% val("size_width", val("width", 900)))
  height <- as.integer(plot_params$advanced_plot_size_height %||% val("size_height", val("height", 700)))
  title <- val("title", "")
  x_label <- val("x_label", "")
  y_label <- val("y_label", "")
  y_min <- val("y_min", "")
  y_max <- val("y_max", "")
  c(
    "# ---- Apply the current plot-panel values (executable code) ----",
    sprintf("plot_theme <- %s # <DAVA-UI-PARAM>", q(theme)),
    sprintf("plot_palette <- %s # <DAVA-UI-PARAM>", q(palette)),
    sprintf("plot_colors <- c(%s) # <DAVA-UI-PARAM>", paste(q(palette_colors), collapse = ", ")),
    sprintf("plot_base_size <- %.8g # <DAVA-UI-PARAM>", base_size),
    sprintf("plot_title <- %s # <DAVA-UI-PARAM>", q(title)),
    sprintf("plot_x_label <- %s # <DAVA-UI-PARAM>", q(x_label)),
    sprintf("plot_y_label <- %s # <DAVA-UI-PARAM>", q(y_label)),
    sprintf("plot_x_angle <- %.8g # <DAVA-UI-PARAM>", x_angle),
    sprintf("plot_show_legend <- %s # <DAVA-UI-PARAM>", if (show_legend) "TRUE" else "FALSE"),
    sprintf("plot_legend_position <- %s # <DAVA-UI-PARAM>", q(legend)),
    sprintf("point_color <- %s; point_alpha <- %.8g # <DAVA-UI-PARAM>", q(point_color), point_alpha),
    sprintf("point_size <- %.8g # <DAVA-UI-PARAM>", point_size),
    sprintf("line_color <- %s; line_alpha <- %.8g # <DAVA-UI-PARAM>", q(line_color), line_alpha),
    sprintf("line_width <- %.8g # <DAVA-UI-PARAM>", line_width),
    sprintf("confidence_color <- %s; confidence_alpha <- %.8g # <DAVA-UI-PARAM>", q(confidence_color), confidence_alpha),
    sprintf("plot_flip <- %s # <DAVA-UI-PARAM>", if (flip) "TRUE" else "FALSE"),
    sprintf("plot_y_limits <- c(%s, %s) # <DAVA-UI-PARAM>",
      if (nzchar(as.character(y_min))) as.character(as.numeric(y_min)) else "NA_real_",
      if (nzchar(as.character(y_max))) as.character(as.numeric(y_max)) else "NA_real_"),
    sprintf("plot_width_px <- %d; plot_height_px <- %d # <DAVA-UI-PARAM>", width, height),
    sprintf("layout_rows <- %d; layout_cols <- %d # <DAVA-UI-PARAM>", as.integer(layout_rows), as.integer(layout_cols)),
    "plot_panels <- if (inherits(plot, 'patchwork')) as.list(plot) else list(plot)",
    "for (plot_index in seq_along(plot_panels)) {",
    "  p <- plot_panels[[plot_index]]",
    "  if (!inherits(p, 'ggplot')) next",
    "  for (layer_index in seq_along(p$layers)) {",
    "    geom <- class(p$layers[[layer_index]]$geom)[1]",
    "    mapped <- unique(c(names(p$mapping), names(p$layers[[layer_index]]$mapping)))",
    "    if (grepl('Geom(Point|Jitter|Count)', geom)) {",
      "      if (!any(c('colour', 'color') %in% mapped)) p$layers[[layer_index]]$aes_params$colour <- point_color",
      "      p$layers[[layer_index]]$aes_params$alpha <- point_alpha",
      "      p$layers[[layer_index]]$aes_params$size <- point_size",
    "    } else if (grepl('Geom(Line|Path|Smooth)', geom)) {",
      "      if (!any(c('colour', 'color') %in% mapped)) p$layers[[layer_index]]$aes_params$colour <- line_color",
      "      p$layers[[layer_index]]$aes_params$alpha <- line_alpha",
      "      p$layers[[layer_index]]$aes_params$linewidth <- line_width",
    "    } else if (grepl('GeomRibbon', geom)) {",
      "      if (!'fill' %in% mapped) p$layers[[layer_index]]$aes_params$fill <- confidence_color",
      "      p$layers[[layer_index]]$aes_params$alpha <- confidence_alpha; p$layers[[layer_index]]$aes_params$colour <- NA",
    "    }",
    "  }",
    "  chosen_theme <- switch(plot_theme, minimal = ggplot2::theme_minimal, clean = ggplot2::theme_minimal, pnas = ggplot2::theme_minimal, classic = ggplot2::theme_classic, nature = ggplot2::theme_classic, cell = ggplot2::theme_classic, lancet = ggplot2::theme_classic, prism = ggplot2::theme_classic, light = ggplot2::theme_light, dark = ggplot2::theme_dark, ggplot2::theme_bw)",
    "  p <- p + chosen_theme(base_size = plot_base_size) + ggplot2::theme(axis.text.x = ggplot2::element_text(angle = plot_x_angle, hjust = if (plot_x_angle == 0) 0.5 else 1), legend.position = if (plot_show_legend) plot_legend_position else 'none')",
    "  labels <- list(); if (nzchar(plot_title)) labels$title <- plot_title; if (nzchar(plot_x_label)) labels$x <- plot_x_label; if (nzchar(plot_y_label)) labels$y <- plot_y_label",
    "  if (length(labels)) p <- p + do.call(ggplot2::labs, labels)",
    "  mapped <- names(p$mapping)",
    "  for (layer_index in seq_along(p$layers)) mapped <- unique(c(mapped, names(p$layers[[layer_index]]$mapping)))",
    "  if ('colour' %in% mapped || 'color' %in% mapped) p <- p + ggplot2::scale_colour_manual(values = plot_colors)",
    "  if ('fill' %in% mapped) p <- p + ggplot2::scale_fill_manual(values = plot_colors, guide = 'none')",
    "  if (plot_flip) p <- p + ggplot2::coord_flip() else if (any(is.finite(plot_y_limits))) p <- p + ggplot2::coord_cartesian(ylim = plot_y_limits)",
    "  plot_panels[[plot_index]] <- p",
    "}",
    "plot <- if (length(plot_panels) == 1L) plot_panels[[1L]] else patchwork::wrap_plots(plot_panels, nrow = layout_rows, ncol = layout_cols, guides = 'collect')",
    "result$plot <- plot",
    "save_current_plot <- function(output_path, dpi = 300) ggplot2::ggsave(output_path, plot = plot, width = plot_width_px / 96, height = plot_height_px / 96, units = 'in', dpi = dpi)",
    "print(plot)",
    "result"
  )
}

regression_code_grouped_lm_lines <- function(settings, plot_name = "fit") {
  q <- function(x) encodeString(as.character(x), quote = "\"")
  response <- settings$responses[[1]]
  focus <- settings$focus_predictor
  group <- settings$group_var
  c(
    sprintf("group_name <- %s # <DAVA-UI-PARAM>", q(group)),
    "group_data <- split(df, df[[group_name]], drop = TRUE)",
    "model <- lapply(group_data, function(dat) stats::lm(model_formula, data = dat))",
    "model_summary <- lapply(model, summary)",
    "coefficient_table <- dplyr::bind_rows(Map(function(fit, level) transform(broom::tidy(fit, conf.int = TRUE), group = level), model, names(model)))",
    "fit_metrics <- dplyr::bind_rows(Map(function(fit, level) transform(broom::glance(fit), group = level, n = stats::nobs(fit)), model, names(model)))",
    "diagnostics <- dplyr::bind_rows(Map(function(fit, level) transform(broom::augment(fit), group = level), model, names(model)))",
    "prediction_table <- dplyr::bind_rows(Map(function(fit, dat, level) {",
    sprintf("  grid <- dat[order(dat[[%s]]), , drop = FALSE]", q(focus)),
    "  interval <- as.data.frame(stats::predict(fit, newdata = grid, interval = 'confidence'))",
    sprintf("  data.frame(row_id = as.integer(rownames(grid)), observed = grid[[%s]], predicted = interval$fit, conf.low = interval$lwr, conf.high = interval$upr, group = level, focus_value = grid[[%s]])", q(response), q(focus)),
    "}, model, group_data, names(model)))",
    "overall_tests <- dplyr::bind_rows(Map(function(fit, level) transform(as.data.frame(stats::anova(fit)), term = rownames(stats::anova(fit)), group = level, row.names = NULL), model, names(model)))",
    sprintf("plot <- ggplot2::ggplot(df, ggplot2::aes(x = .data[[%s]], y = .data[[%s]], colour = .data[[group_name]], fill = .data[[group_name]])) +", q(focus), q(response)),
    "  ggplot2::geom_point(alpha = 0.65, size = 2) +",
    "  ggplot2::geom_ribbon(data = prediction_table, ggplot2::aes(x = focus_value, ymin = conf.low, ymax = conf.high, fill = group, group = group), inherit.aes = FALSE, alpha = 0.12, colour = NA, show.legend = FALSE) +",
    "  ggplot2::geom_line(data = prediction_table, ggplot2::aes(x = focus_value, y = predicted, colour = group, group = group), inherit.aes = FALSE, linewidth = 1) +",
    sprintf("  ggplot2::labs(x = %s, y = %s, colour = group_name, fill = group_name)", q(focus), q(response))
  )
}

regression_standalone_method_code <- function(settings, plot_name = "fit") {
  method <- settings$method_id %||% "lm"
  formula <- regression_code_formula(settings)
  if (is.null(formula)) return("stop('Select valid response and predictor variables before generating code.')")
  formula_text <- paste(deparse(formula), collapse = " ")
  responses <- settings$responses %||% "response"
  predictors <- settings$predictors %||% character()
  response <- responses[[1]]
  primary_predictor <- if (length(predictors)) predictors[[1]] else "group"
  q <- function(x) encodeString(x, quote = "\"")
  q_responses <- paste(q(responses), collapse = ", ")
  q_predictors <- paste(q(predictors), collapse = ", ")
  setup <- character()
  if (method == "weighted_binomial") {
    weight_name <- settings$weight_var %||% "weights"
    setup <- sprintf("analysis_weights <- df[[%s]]", q(weight_name))
  }
  if (method %in% c("ridge", "lasso", "elastic_net")) setup <- c(
    sprintf("x_matrix <- stats::model.matrix(~ %s, data = df)[, -1, drop = FALSE]", paste(sprintf("`%s`", predictors), collapse = " + ")),
    sprintf("y_vector <- df[[%s]]", q(response))
  )
  if (method == "mediation") {
    mediator_names <- settings$mediators %||% character()
    mediator <- if (length(mediator_names)) mediator_names[[1]] else primary_predictor
    exposure <- settings$focus_predictor %||% primary_predictor
    covariates <- setdiff(predictors, c(exposure, mediator))
    setup <- c(
      sprintf("mediator_name <- %s", q(mediator)),
      sprintf("mediator_formula <- stats::reformulate(c(%s), response = mediator_name)", paste(q(c(exposure, covariates)), collapse = ", ")),
      sprintf("outcome_formula <- stats::reformulate(c(%s), response = response_name)", paste(q(c(exposure, mediator, covariates)), collapse = ", ")),
      "mediator_model <- stats::lm(mediator_formula, data = df)",
      "outcome_model <- stats::lm(outcome_formula, data = df)"
    )
  }
  if (method == "moderation") {
    moderator <- settings$moderator %||% primary_predictor
    exposure <- settings$focus_predictor %||% primary_predictor
    covariates <- setdiff(predictors, c(exposure, moderator))
    interaction_term <- paste0("`", exposure, "` * `", moderator, "`")
    rhs <- c(interaction_term, sprintf("`%s`", covariates))
    setup <- sprintf("moderation_formula <- stats::as.formula(%s)", q(paste(sprintf("`%s`", response), "~", paste(rhs, collapse = " + "))))
  }
  community_methods <- c("gllvm", "jsdm", "rrr", "maaslin2", "ancombc2", "deseq2", "edger", "corncob", "aldex2", "metagenomeseq")
  if (method %in% community_methods) setup <- c(
    sprintf("response_columns <- c(%s)", q_responses),
    sprintf("predictor_columns <- c(%s)", q_predictors),
    "response_matrix <- as.matrix(df[, response_columns, drop = FALSE])",
    "predictor_frame <- df[, predictor_columns, drop = FALSE]",
    "predictor_matrix <- stats::model.matrix(~ ., predictor_frame)[, -1, drop = FALSE]",
    "count_matrix <- t(round(pmax(response_matrix, 0)))",
    "design_matrix <- stats::model.matrix(model_formula, data = df)",
    sprintf("group_variable <- %s", q(settings$group_var %||% primary_predictor)),
    "maaslin_output_dir <- tempfile('maaslin2_')"
  )
  zero_terms <- settings$zero_predictors %||% character()
  grouped_lm <- method %in% c("lm", "polynomial") &&
    identical(settings$scenario %||% "overall", "group_independent") &&
    nzchar(settings$group_var %||% "")
  result_code <- if (grouped_lm) {
    regression_code_grouped_lm_lines(settings, plot_name)
  } else if (method == "mediation") c(
    "model_summary <- summary(model)",
    "coefficient_table <- data.frame(effect = c('indirect', 'direct', 'total'), estimate = c(model$d0, model$z0, model$tau.coef), conf.low = c(model$d0.ci[1], model$z0.ci[1], model$tau.ci[1]), conf.high = c(model$d0.ci[2], model$z0.ci[2], model$tau.ci[2]), p.value = c(model$d0.p, model$z0.p, model$tau.p))",
    "prediction_table <- data.frame(row_id = seq_len(nrow(df)), observed = df[[response_name]], predicted = as.numeric(stats::fitted(outcome_model)))",
    "plot <- ggplot2::ggplot(coefficient_table, ggplot2::aes(estimate, effect)) + ggplot2::geom_point(size = 3, colour = '#3B7EA1') + ggplot2::geom_errorbarh(ggplot2::aes(xmin = conf.low, xmax = conf.high), height = 0.15) + ggplot2::geom_vline(xintercept = 0, linetype = 2) + ggplot2::theme_bw()"
  ) else if (method %in% c("ridge", "lasso", "elastic_net")) c(
    "model_summary <- model",
    "selected_coefficients <- as.matrix(stats::coef(model, s = 'lambda.min'))",
    "coefficient_table <- data.frame(term = rownames(selected_coefficients), estimate = as.numeric(selected_coefficients[, 1]), row.names = NULL)",
    "prediction_table <- data.frame(row_id = seq_len(nrow(df)), observed = y_vector, predicted = as.numeric(stats::predict(model, newx = x_matrix, s = 'lambda.min')))",
    "plot <- ggplot2::ggplot(prediction_table, ggplot2::aes(observed, predicted)) + ggplot2::geom_point(alpha = 0.7) + ggplot2::geom_abline(slope = 1, intercept = 0, colour = '#3B7EA1') + ggplot2::theme_bw()"
  ) else if (method %in% c("pls1", "pls2", "pcr")) c(
    "model_summary <- summary(model)",
    "coefficient_table <- data.frame(term = rownames(model$loadings), loading = as.numeric(model$loadings[, 1]), row.names = NULL)",
    sprintf("prediction_table <- data.frame(row_id = seq_len(nrow(df)), observed = df[[%s]], predicted = as.numeric(stats::predict(model, newdata = df, ncomp = model$ncomp)))", q(response)),
    "plot <- ggplot2::ggplot(prediction_table, ggplot2::aes(observed, predicted)) + ggplot2::geom_point(alpha = 0.7) + ggplot2::geom_abline(slope = 1, intercept = 0, colour = '#3B7EA1') + ggplot2::theme_bw()"
  ) else if (method == "multivariate_tree") c(
    "model_summary <- summary(model)",
    "coefficient_table <- if (is.null(model$variable.importance)) data.frame() else data.frame(term = names(model$variable.importance), importance = as.numeric(model$variable.importance), row.names = NULL)",
    "prediction_table <- data.frame(row_id = seq_len(nrow(df)), as.data.frame(stats::predict(model, newdata = df)))",
    "plot <- ggplot2::ggplot(data.frame(cp = model$cptable[, 'CP'], error = model$cptable[, 'xerror']), ggplot2::aes(cp, error)) + ggplot2::geom_line(colour = '#3B7EA1') + ggplot2::geom_point() + ggplot2::scale_x_log10() + ggplot2::theme_bw()"
  ) else if (method %in% c("rda", "cca", "dbrda")) c(
    "model_summary <- summary(model)",
    "site_scores <- as.data.frame(vegan::scores(model, display = 'sites', choices = 1:2))",
    "coefficient_table <- as.data.frame(vegan::scores(model, display = 'bp', choices = 1:2))",
    "prediction_table <- site_scores",
    "plot <- ggplot2::ggplot(site_scores, ggplot2::aes(site_scores[[1]], site_scores[[2]])) + ggplot2::geom_point(size = 2.5, alpha = 0.75, colour = '#3B7EA1') + ggplot2::theme_bw() + ggplot2::labs(x = 'Axis 1', y = 'Axis 2')"
  ) else if (method %in% c("manyglm", community_methods)) c(
    "model_summary <- tryCatch(summary(model), error = function(e) model)",
    "coefficient_table <- tryCatch(broom::tidy(model), error = function(e) data.frame())",
    "prediction_table <- data.frame()",
    "plot <- if (nrow(coefficient_table) && all(c('term', 'estimate') %in% names(coefficient_table))) ggplot2::ggplot(coefficient_table, ggplot2::aes(estimate, stats::reorder(term, estimate))) + ggplot2::geom_col(fill = '#3B7EA1') + ggplot2::theme_bw() + ggplot2::labs(y = NULL) else NULL"
  ) else c(
    "model_summary <- summary(model)",
    "coefficient_table <- tryCatch(broom::tidy(model, conf.int = TRUE), error = function(e) data.frame())",
    sprintf("prediction_table <- data.frame(row_id = seq_len(nrow(df)), observed = df[[%s]], predicted = as.numeric(stats::predict(model, newdata = df, type = 'response')))", q(response)),
    "plot <- ggplot2::ggplot(prediction_table, ggplot2::aes(observed, predicted)) +",
    "  ggplot2::geom_point(alpha = 0.70, colour = '#1F1F1F') +",
    "  ggplot2::geom_abline(slope = 1, intercept = 0, colour = '#3B7EA1') +",
    "  ggplot2::theme_bw() + ggplot2::labs(title = 'Observed and fitted values')"
  )
  supplementary_code <- if (grouped_lm) character() else c(
    "fit_metrics <- tryCatch(broom::glance(model), error = function(e) data.frame())",
    "overall_tests <- tryCatch(transform(as.data.frame(stats::anova(model)), term = rownames(stats::anova(model)), row.names = NULL), error = function(e) data.frame())",
    "diagnostics <- tryCatch(broom::augment(model), error = function(e) data.frame())"
  )
  selected_plot_code <- if (grouped_lm) character() else switch(plot_name,
    fit = c(
      sprintf("plot <- ggplot2::ggplot(df, ggplot2::aes(x = .data[[%s]], y = .data[[%s]])) +", q(settings$focus_predictor), q(response)),
      "  ggplot2::geom_point(alpha = 0.65, size = 2) +",
      "  ggplot2::geom_smooth(method = 'lm', formula = y ~ x, se = TRUE, linewidth = 1, alpha = 0.12)"
    ),
    residual = c(
      "plot <- ggplot2::ggplot(diagnostics, ggplot2::aes(.fitted, .resid)) +",
      "  ggplot2::geom_point(alpha = 0.7) + ggplot2::geom_hline(yintercept = 0, linetype = 2) + ggplot2::labs(x = 'Fitted', y = 'Residual')"
    ),
    coefficients = c(
      "coefficient_plot_data <- subset(coefficient_table, term != '(Intercept)')",
      "plot <- ggplot2::ggplot(coefficient_plot_data, ggplot2::aes(estimate, stats::reorder(term, estimate))) + ggplot2::geom_vline(xintercept = 0, linetype = 2) + ggplot2::geom_point(size = 2.8) + ggplot2::geom_errorbar(ggplot2::aes(xmin = conf.low, xmax = conf.high), orientation = 'y', width = 0.15) + ggplot2::labs(y = NULL)"
    ),
    character()
  )
  c(
    sprintf("# ---- %s: explicit method-specific analysis ----", method),
    sprintf("method_id <- %s # <DAVA-UI-PARAM>", q(method)),
    sprintf("response_name <- %s # <DAVA-UI-PARAM>", q(response)),
    sprintf("predictor_names <- c(%s) # <DAVA-UI-PARAM>", q_predictors),
    sprintf("focus_predictor <- %s # <DAVA-UI-PARAM>", q(settings$focus_predictor %||% primary_predictor)),
    sprintf("analysis_scenario <- %s # <DAVA-UI-PARAM>", q(settings$scenario %||% "overall")),
    sprintf("formula_text <- %s # <DAVA-UI-PARAM>", q(formula_text)),
    "model_formula <- stats::as.formula(formula_text)",
    if (length(zero_terms)) sprintf("zero_predictors <- c(%s) # <DAVA-UI-PARAM>", paste(q(zero_terms), collapse = ", ")) else character(),
    setup,
    if (!grouped_lm) paste0("model <- ", regression_code_direct_call(method, settings)) else character(),
    result_code,
    supplementary_code,
    selected_plot_code,
    "analysis_output <- list(",
    "  method_id = method_id, formula = formula_text, response = response_name,",
    "  predictors = predictor_names, model = model, summary = model_summary,",
    "  coefficients = coefficient_table, predictions = prediction_table,",
    "  observed_fitted = prediction_table, fit_metrics = fit_metrics,",
    "  overall_tests = overall_tests, diagnostics = diagnostics, plot = plot",
    ")",
    "result <- analysis_output",
    "result"
  )
}

regression_code_template <- function(dataset_name, settings, plot_params = list(),
                                     plot_name = "fit", layout_rows = 1L,
                                     layout_cols = 1L, apply_plot_settings = TRUE,
                                     include_data = TRUE) {
  dataset_text <- encodeString(dataset_name, quote = "\"")
  paste0(
    "# EcoDAVA - current regression method (standalone and reproducible)\n",
    if (!isTRUE(include_data)) "df <- analysis_input_data\n" else if (identical(dataset_name, "__demo__")) paste0(
      dava_local_demo_code("statistics/advanced_analysis.rds", "df"), "\n"
    ) else paste0("df <- get_dataset(", dataset_text, ")\n"),
    if (nzchar(settings$phylogeny_dataset %||% "")) paste0(
      "phylogeny <- get_dataset(", encodeString(settings$phylogeny_dataset, quote = "\""), ")\n"
    ) else "",
    paste(regression_standalone_method_code(settings, plot_name), collapse = "\n"), "\n",
    if (isTRUE(apply_plot_settings)) paste(
      regression_code_plot_replay_lines(plot_params, plot_name, layout_rows, layout_cols),
      collapse = "\n"
    ) else "",
    "\n"
  )
}

regression_multi_response_code_template <- function(dataset_name, settings,
                                                    responses, plot_params = list(),
                                                    plot_name = "fit",
                                                    layout_rows = 1L,
                                                    layout_cols = 2L,
                                                    include_data = TRUE) {
  responses <- unique(responses[nzchar(responses)])
  layout_cols <- max(1L, suppressWarnings(as.integer(layout_cols %||% 2L)))
  layout_rows <- max(
    1L,
    suppressWarnings(as.integer(layout_rows %||% 1L)),
    ceiling(length(responses) / layout_cols)
  )
  if (length(responses) <= 1L) {
    settings$responses <- responses %||% settings$responses
    return(regression_code_template(dataset_name, settings, plot_params,
      plot_name, layout_rows, layout_cols, include_data = include_data))
  }
  dataset_text <- encodeString(dataset_name, quote = "\"")
  q <- function(x) encodeString(as.character(x), quote = "\"")
  data_code <- if (!isTRUE(include_data)) "df <- analysis_input_data" else if (identical(dataset_name, "__demo__")) {
    dava_local_demo_code("statistics/advanced_analysis.rds", "df")
  } else paste0("df <- get_dataset(", dataset_text, ")")
  blocks <- vapply(responses, function(response) {
    response_settings <- settings
    response_settings$responses <- response
    paste0(
      "analysis_results[[", q(response), "]] <- local({\n",
      paste0("  ", regression_standalone_method_code(response_settings, plot_name), collapse = "\n"),
      "\n})"
    )
  }, character(1))
  combine <- c(
    "bind_result_table <- function(field) dplyr::bind_rows(lapply(names(analysis_results), function(response) {",
    "  table <- analysis_results[[response]][[field]]",
    "  if (!is.data.frame(table) || !nrow(table)) return(NULL)",
    "  if (!'response' %in% names(table)) table$response <- response",
    "  table",
    "}))",
    "plot_list <- lapply(analysis_results, `[[`, 'plot')",
    sprintf("plot <- patchwork::wrap_plots(plot_list, nrow = %d, ncol = %d, guides = 'collect')", as.integer(layout_rows), as.integer(layout_cols)),
    "result <- list(",
    sprintf("  method_id = %s, responses = names(analysis_results),", q(settings$method_id %||% "lm")),
    "  response = names(analysis_results), predictors = analysis_results[[1]]$predictors,",
    "  formula = vapply(analysis_results, `[[`, character(1), 'formula'),",
    "  model = lapply(analysis_results, `[[`, 'model'), summary = lapply(analysis_results, `[[`, 'summary'),",
    "  coefficients = bind_result_table('coefficients'), predictions = bind_result_table('predictions'),",
    "  observed_fitted = bind_result_table('observed_fitted'), fit_metrics = bind_result_table('fit_metrics'),",
    "  overall_tests = bind_result_table('overall_tests'), diagnostics = bind_result_table('diagnostics'),",
    "  analysis_results = analysis_results, plot = plot",
    ")"
  )
  paste(c(
    "# EcoDAVA - complete multi-response regression page reproduction",
    data_code,
    sprintf("selected_responses <- c(%s) # <DAVA-UI-PARAM>", paste(q(responses), collapse = ", ")),
    "analysis_results <- list()",
    blocks,
    combine,
    regression_code_plot_replay_lines(plot_params, plot_name, layout_rows, layout_cols)
  ), collapse = "\n")
}
