ttest_demo_data_generate <- function() {
  set.seed(2026)
  n <- 72
  data.frame(
    Subject = rep(paste0("S", sprintf("%02d", 1:24)), each = 3),
    Block = rep(paste0("B", 1:12), each = 6, length.out = n),
    Group = rep(c("CK", "Biochar", "Manure"), each = 24),
    Time = rep(c("T1", "T2", "T3"), times = 24),
    Stress = rep(c("Moderate", "Severe"), length.out = n),
    Height = rnorm(n, rep(c(20, 23, 25), each = 24), 3),
    Biomass = rnorm(n, rep(c(4.8, 5.6, 6.2), each = 24), 0.8),
    Root = rnorm(n, rep(c(10, 12, 13), each = 24), 1.6),
    check.names = FALSE
  )
}

ttest_code_template <- function(model_type, input, workspace_data = FALSE) {
  r_value <- function(value) paste(deparse(value, width.cutoff = 500L), collapse = "")
  responses <- as.character(input$response %||% character())
  groups <- switch(model_type,
    t_OneSample = input$group %||% "", Wilcoxon_OneSample = input$group %||% "",
    t_TwoSample = input$group %||% "", WMW_TwoSample = input$group %||% "",
    t_TwoSamplePaired = input$group %||% "", Wilcoxon_TwoSamplePaired = input$group %||% "",
    KW_OneWay = input$group %||% "", Friedman_OneWay = c(input$group %||% "", input$block %||% ""),
    SRH_TwoWay = c(input$group1 %||% "", input$group2 %||% ""),
    ART_ANOVA = c(input$fixed_effect %||% character(), input$block_subject %||% ""), character())
  groups <- groups[nzchar(groups)]
  method_parameters <- switch(model_type,
    t_OneSample = paste0("group <- ", r_value(input$group %||% ""), " # <DAVA-UI-PARAM>\nmu <- ", r_value(input$num %||% 0), " # <DAVA-UI-PARAM>\n"),
    Wilcoxon_OneSample = paste0("group <- ", r_value(input$group %||% ""), " # <DAVA-UI-PARAM>\nmu <- ", r_value(input$num %||% 0), " # <DAVA-UI-PARAM>\n"),
    t_TwoSample = paste0("group <- ", r_value(input$group %||% ""), " # <DAVA-UI-PARAM>\nadjust_method <- ", r_value(input$adjust_method %||% "holm"), " # <DAVA-UI-PARAM>\n"),
    WMW_TwoSample = paste0("group <- ", r_value(input$group %||% ""), " # <DAVA-UI-PARAM>\nadjust_method <- ", r_value(input$adjust_method %||% "holm"), " # <DAVA-UI-PARAM>\n"),
    t_TwoSamplePaired = paste0("group <- ", r_value(input$group %||% ""), " # <DAVA-UI-PARAM>\nadjust_method <- ", r_value(input$adjust_method %||% "holm"), " # <DAVA-UI-PARAM>\n"),
    Wilcoxon_TwoSamplePaired = paste0("group <- ", r_value(input$group %||% ""), " # <DAVA-UI-PARAM>\nadjust_method <- ", r_value(input$adjust_method %||% "holm"), " # <DAVA-UI-PARAM>\n"),
    KW_OneWay = paste0("group <- ", r_value(input$group %||% ""), " # <DAVA-UI-PARAM>\nadjust_method <- ", r_value(input$adjust_method %||% "holm"), " # <DAVA-UI-PARAM>\n"),
    Friedman_OneWay = paste0("group <- ", r_value(input$group %||% ""), " # <DAVA-UI-PARAM>\nblock <- ", r_value(input$block %||% ""), " # <DAVA-UI-PARAM>\nadjust_method <- ", r_value(input$adjust_method %||% "holm"), " # <DAVA-UI-PARAM>\n"),
    SRH_TwoWay = paste0("group1 <- ", r_value(input$group1 %||% ""), " # <DAVA-UI-PARAM>\ngroup2 <- ", r_value(input$group2 %||% ""), " # <DAVA-UI-PARAM>\n"),
    ART_ANOVA = paste0("fixed_effect <- ", r_value(input$fixed_effect %||% character()), " # <DAVA-UI-PARAM>\nblock_subject <- ", r_value(input$block_subject %||% ""), " # <DAVA-UI-PARAM>\n"), "")
  one_sample <- model_type %in% c("t_OneSample", "Wilcoxon_OneSample")
  two_sample <- model_type %in% c("t_TwoSample", "WMW_TwoSample", "t_TwoSamplePaired", "Wilcoxon_TwoSamplePaired")
  method_code <- if (one_sample) paste0(
    "  dat <- stats::na.omit(df[, unique(c(response, group[nzchar(group)])), drop = FALSE])\n",
    "  split_data <- if (nzchar(group)) split(dat, dat[[group]], drop = TRUE) else list(All = dat)\n",
    "  response_rows <- list()\n",
    "  for (level_name in names(split_data)) {\n",
    "    x <- as.numeric(split_data[[level_name]][[response]])\n",
    if (identical(model_type, "t_OneSample")) "    test <- stats::t.test(x, mu = mu)\n" else "    test <- stats::wilcox.test(x, mu = mu, exact = FALSE)\n",
    "    response_rows[[level_name]] <- data.frame(response = response, group = level_name, method = test$method, statistic = unname(test$statistic), parameter = paste(test$parameter, collapse = ', '), estimate = paste(round(unname(test$estimate), 6), collapse = ', '), p.value = test$p.value, stringsAsFactors = FALSE)\n",
    "  }\n  response_result <- dplyr::bind_rows(response_rows)\n")
  else if (two_sample) paste0(
    "  dat <- stats::na.omit(df[, c(response, group), drop = FALSE]); dat[[group]] <- factor(dat[[group]])\n",
    "  level_pairs <- utils::combn(levels(dat[[group]]), 2, simplify = FALSE); response_rows <- list()\n",
    "  for (pair_index in seq_along(level_pairs)) { pair <- level_pairs[[pair_index]]; x <- dat[dat[[group]] == pair[1], response]; y <- dat[dat[[group]] == pair[2], response]\n",
    if (model_type %in% c("t_TwoSamplePaired", "Wilcoxon_TwoSamplePaired")) "    n_pair <- min(length(x), length(y)); x <- x[seq_len(n_pair)]; y <- y[seq_len(n_pair)]; paired <- TRUE\n" else "    paired <- FALSE\n",
    if (model_type %in% c("t_TwoSample", "t_TwoSamplePaired")) "    test <- stats::t.test(x, y, paired = paired)\n" else "    test <- stats::wilcox.test(x, y, paired = paired, exact = FALSE)\n",
    "    response_rows[[pair_index]] <- data.frame(response=response, group=paste(pair, collapse=' vs '), group1=pair[1], group2=pair[2], n1=length(x), n2=length(y), method=test$method, statistic=unname(test$statistic), parameter=paste(test$parameter, collapse=', '), estimate=paste(round(unname(test$estimate),6), collapse=', '), p.value=test$p.value, stringsAsFactors=FALSE)\n  }\n",
    "  response_result <- dplyr::bind_rows(response_rows); response_result$p.adjusted <- if (adjust_method == 'sidak') 1-(1-response_result$p.value)^sum(!is.na(response_result$p.value)) else stats::p.adjust(response_result$p.value, method=adjust_method)\n")
  else if (identical(model_type, "KW_OneWay")) paste0(
    "  dat <- stats::na.omit(df[, c(response, group), drop=FALSE]); dat[[group]] <- factor(dat[[group]]); test <- stats::kruskal.test(stats::reformulate(group, response=response), data=dat)\n",
    "  response_result <- data.frame(response=response, group=group, method=test$method, statistic=unname(test$statistic), parameter=unname(test$parameter), p.value=test$p.value)\n",
    "  pairwise <- stats::pairwise.wilcox.test(dat[[response]], dat[[group]], p.adjust.method=if (adjust_method=='sidak') 'none' else adjust_method, exact=FALSE); pairwise_rows <- as.data.frame(as.table(pairwise$p.value)); names(pairwise_rows) <- c('group1','group2','p.value'); pairwise_rows <- pairwise_rows[!is.na(pairwise_rows$p.value),]; pairwise_rows$response <- response; pairwise_rows$method <- 'Pairwise Wilcoxon test'; response_result <- dplyr::bind_rows(response_result, pairwise_rows)\n")
  else if (identical(model_type, "Friedman_OneWay")) paste0(
    "  dat <- stats::na.omit(df[, c(response, group, block), drop=FALSE]); dat[[group]] <- factor(dat[[group]]); dat[[block]] <- factor(dat[[block]]); test <- stats::friedman.test(stats::as.formula(paste(response,'~',group,'|',block)), data=dat)\n",
    "  response_result <- data.frame(response=response, group=paste(group,'|',block), method=test$method, statistic=unname(test$statistic), parameter=unname(test$parameter), p.value=test$p.value)\n")
  else if (identical(model_type, "SRH_TwoWay")) paste0(
    "  dat <- stats::na.omit(df[, c(response, group1, group2), drop=FALSE]); dat[[group1]] <- factor(dat[[group1]]); dat[[group2]] <- factor(dat[[group2]]); dat$.rank_y <- rank(dat[[response]], ties.method='average'); fit <- stats::lm(stats::as.formula(paste('.rank_y ~',group1,'*',group2)), data=dat); response_result <- as.data.frame(stats::anova(fit)); response_result$term <- rownames(response_result); response_result$response <- response; response_result$method <- 'Scheirer-Ray-Hare rank ANOVA approximation'; rownames(response_result) <- NULL\n")
  else paste0(
    "  selected_factors <- fixed_effect[nzchar(fixed_effect)]; selected_columns <- unique(c(response, selected_factors, block_subject[nzchar(block_subject)])); dat <- stats::na.omit(df[, selected_columns, drop=FALSE]); dat[selected_factors] <- lapply(dat[selected_factors], factor); dat$.rank_y <- rank(dat[[response]], ties.method='average'); rhs <- paste(selected_factors, collapse=' * '); if (nzchar(block_subject)) rhs <- paste(rhs,'+',block_subject); fit <- stats::lm(stats::as.formula(paste('.rank_y ~',rhs)), data=dat); response_result <- as.data.frame(stats::anova(fit)); response_result$term <- rownames(response_result); response_result$response <- response; response_result$method <- 'Aligned-rank style ANOVA approximation'; rownames(response_result) <- NULL\n")
  code <- paste0(
    "# DAVA Statistical testsComplete process WhenCode\n",
    "# Model: ", model_type, "\n",
    if (isTRUE(workspace_data)) "df <- analysis_input_data\n" else if (identical(input$dataset_select_input %||% "__demo__", "__demo__")) paste0(
      dava_local_demo_code("statistics/t_test.rds", "df"), "\n"
    ) else paste0("df <- get_dataset('", input$dataset_select_input %||% "", "')\n"),
    "responses <- ", r_value(responses), " # <DAVA-UI-PARAM>\n", method_parameters,
    "result_rows <- list(); summary_rows <- list(); errors <- list()\n",
    "for (response in responses) {\n", method_code,
    "  response_result$significance <- cut(response_result$p.value, breaks=c(-Inf,.001,.01,.05,Inf), labels=c('***','**','*','ns'))\n",
    "  result_rows[[response]] <- response_result\n",
    "  summary_groups <- ", r_value(groups), "; if (length(summary_groups)) summary_rows[[response]] <- dplyr::summarise(dplyr::group_by(dat, dplyr::across(dplyr::all_of(summary_groups))), n=sum(!is.na(.data[[response]])), mean=mean(.data[[response]],na.rm=TRUE), sd=stats::sd(.data[[response]],na.rm=TRUE), se=sd/sqrt(n), .groups='drop') else summary_rows[[response]] <- data.frame(n=sum(!is.na(dat[[response]])), mean=mean(dat[[response]],na.rm=TRUE), sd=stats::sd(dat[[response]],na.rm=TRUE)); summary_rows[[response]]$response <- response\n",
    "}\nresult_table <- dplyr::bind_rows(result_rows); summary_table <- dplyr::bind_rows(summary_rows)\n",
    "plot_response <- responses[1]; plot_group <- ", r_value(if (length(groups)) groups[1] else ""), "\n",
    "if (nzchar(plot_group)) p <- ggplot2::ggplot(df, ggplot2::aes(x=.data[[plot_group]], y=.data[[plot_response]], fill=.data[[plot_group]])) + ggplot2::geom_boxplot(alpha=.72, outlier.shape=NA) + ggplot2::geom_jitter(width=.12, alpha=.5) else p <- ggplot2::ggplot(df, ggplot2::aes(x='', y=.data[[plot_response]])) + ggplot2::geom_boxplot(fill='#6BAED6', alpha=.65, width=.35, outlier.shape=NA) + ggplot2::geom_jitter(width=.08, alpha=.5)\n",
    "p <- p + ggplot2::theme_bw(base_size=14) + ggplot2::labs(x=if(nzchar(plot_group)) plot_group else NULL, y=plot_response)\n",
    "if (!is.null(p)) print(p)\n",
    "analysis_output <- list(summary=summary_table, result=result_table, errors=dplyr::bind_rows(errors), responses=responses, groups=", r_value(groups), ", plot=p)\nresult <- analysis_output\nresult\n"
  )
  dava_code_assert_standalone(code, model_type)
  code
}

dava_ttest_plot <- function(df, y, groups = character(0)) {
  if (!nzchar(y %||% "") || !(y %in% names(df))) return(NULL)
  if (length(groups) == 0 || !(groups[1] %in% names(df))) {
    return(
      ggplot2::ggplot(df, ggplot2::aes(y = .data[[y]], x = "")) +
        ggplot2::geom_boxplot(fill = "#6baed6", alpha = 0.65, width = 0.35, outlier.shape = NA) +
        ggplot2::geom_jitter(width = 0.08, alpha = 0.5) +
        ggplot2::theme_bw(base_size = 14) +
        ggplot2::labs(x = NULL, y = y)
    )
  }
  x <- groups[1]
  fill_var <- if (length(groups) >= 2 && groups[2] %in% names(df)) groups[2] else x
  p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[[x]], y = .data[[y]], fill = .data[[fill_var]])) +
    ggplot2::geom_boxplot(width = 0.65, alpha = 0.72, outlier.shape = NA) +
    ggplot2::geom_jitter(width = 0.12, alpha = 0.5) +
    ggplot2::theme_bw(base_size = 14) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 35, hjust = 1)) +
    ggplot2::labs(x = x, y = y)
  if (!identical(fill_var, x)) p <- p + ggplot2::facet_wrap(stats::as.formula(paste("~", fill_var)))
  p
}

ttest_demo_data <- function() {
  dava_local_demo_read("statistics/t_test.rds")
}

dava_ttest_custom_result <- function(run, responses, groups) {
  dava_custom_run_assert(run)
  value <- dava_custom_run_list(run, required = "result")
  if (is.null(value)) stop("Custom statistical tests must return a list containing result.", call. = FALSE)
  result <- value$result
  if (is.matrix(result)) result <- as.data.frame(result, check.names = FALSE)
  if (!is.data.frame(result)) stop("The result of a custom statistical test must be a data frame.", call. = FALSE)
  summary <- value$summary %||% data.frame()
  if (is.matrix(summary)) summary <- as.data.frame(summary, check.names = FALSE)
  if (!is.data.frame(summary)) summary <- data.frame()
  errors <- value$errors %||% data.frame()
  if (is.matrix(errors)) errors <- as.data.frame(errors, check.names = FALSE)
  if (!is.data.frame(errors)) errors <- data.frame(message = as.character(errors))
  list(
    result = result, summary = summary, errors = errors,
    responses = as.character(value$responses %||% responses),
    groups = as.character(value$groups %||% groups),
    custom_plot = dava_custom_run_plot(run)
  )
}

mod_ttest_ui <- function(id, title, model_type) {
  ns <- NS(id)

  card(
    card_header(h4(title, style = "margin: 0;")),
    layout_sidebar(
      sidebar = sidebar(
        width = 330,
        tags$div(
          class = "stat-box",
          tags$strong("Data"),
          uiOutput(ns("dataset_select")),
          tags$div(class = "small-muted", "Choose a data set")
        ),
        tags$div(
          class = "stat-box",
          tags$strong("Analysis"),
          pickerInput(
            ns("response"),
            "Response variable(s)",
            choices = NULL,
            selected = NULL,
            multiple = TRUE,
            options = list(`live-search` = TRUE, `actions-box` = TRUE)
          ),

          if (model_type %in% c("t_OneSample", "Wilcoxon_OneSample")) {
            tagList(
              selectInput(ns("group"), "Optional grouping variable", choices = NULL, selected = "", multiple = FALSE),
              numericInput(ns("num"), "Reference value", value = 0, step = 1)
            )
          },

          if (model_type %in% c("t_TwoSample", "WMW_TwoSample", "t_TwoSamplePaired", "Wilcoxon_TwoSamplePaired")) {
            tagList(
              selectInput(ns("group"), "Grouping variable", choices = NULL, selected = NULL, multiple = FALSE),
              selectInput(
                ns("adjust_method"),
                "Pairwise p adjustment",
                choices = c("None" = "none", "Bonferroni" = "bonferroni", "Holm" = "holm", "BH/FDR" = "BH", "Sidak" = "sidak"),
                selected = "holm",
                multiple = FALSE
              )
            )
          },

          if (model_type == "KW_OneWay") {
            tagList(
              selectInput(ns("group"), "Grouping variable", choices = NULL, selected = NULL, multiple = FALSE),
              selectInput(
                ns("adjust_method"),
                "Post-hoc p adjustment",
                choices = c("None" = "none", "Bonferroni" = "bonferroni", "Holm" = "holm", "BH/FDR" = "BH", "Sidak" = "sidak"),
                selected = "holm",
                multiple = FALSE
              )
            )
          },

          if (model_type == "Friedman_OneWay") {
            tagList(
              selectInput(ns("group"), "Treatment/group variable", choices = NULL, selected = NULL, multiple = FALSE),
              selectInput(ns("block"), "Block/subject variable", choices = NULL, selected = NULL, multiple = FALSE),
              selectInput(
                ns("adjust_method"),
                "Post-hoc p adjustment",
                choices = c("None" = "none", "Bonferroni" = "bonferroni", "Holm" = "holm", "BH/FDR" = "BH", "Sidak" = "sidak"),
                selected = "holm",
                multiple = FALSE
              )
            )
          },

          if (model_type == "SRH_TwoWay") {
            tagList(
              selectInput(ns("group1"), "Factor 1", choices = NULL, selected = NULL, multiple = FALSE),
              selectInput(ns("group2"), "Factor 2", choices = NULL, selected = NULL, multiple = FALSE),
              selectInput(
                ns("adjust_method"),
                "Post-hoc p adjustment",
                choices = c("None" = "none", "Bonferroni" = "bonferroni", "Holm" = "holm", "BH/FDR" = "BH", "Sidak" = "sidak"),
                selected = "holm",
                multiple = FALSE
              )
            )
          },

          if (model_type == "ART_ANOVA") {
            tagList(
              selectInput(ns("factor_n"), "Number of fixed factors", choices = c("One factor" = 1, "Two factors" = 2), selected = 1),
              pickerInput(
                ns("fixed_effect"),
                "Fixed factor(s)",
                choices = NULL,
                selected = NULL,
                multiple = TRUE,
                options = list(`live-search` = TRUE, `actions-box` = TRUE, `max-options` = 2)
              ),
              selectInput(ns("block_subject"), "Optional block/subject", choices = NULL, selected = "", multiple = FALSE),
              selectInput(
                ns("adjust_method"),
                "Post-hoc p adjustment",
                choices = c("None" = "none", "Bonferroni" = "bonferroni", "Holm" = "holm", "BH/FDR" = "BH", "Sidak" = "sidak"),
                selected = "holm",
                multiple = FALSE
              )
            )
          },

          hr(),
          dava_dependency_button_ui(ns),
          actionButton(ns("run_test"), tags$strong("Run analysis"), class = "btn-primary w-100"),
          actionButton(ns("register_results"), "Add to data table repository", icon = icon("plus"),
            title = "Add to data table repository", class = "btn-success w-100 mt-2"),
          downloadButton(ns("download_results"), "Download analysis results table", icon = icon("download"), class = "btn-success w-100 mt-2")
        )
      ),

      navset_card_tab(
        nav_panel("Raw data", DTOutput(ns("raw_data_preview"))),
        nav_panel("Summary", DTOutput(ns("summary_df"))),
        nav_panel("Results", DTOutput(ns("anova_table"))),
        nav_panel(
          "Plot",
          layout_sidebar(
            sidebar = sidebar(
              width = 300,
              position = "right",
              tags$div(class = "stat-box", tags$strong("Graphics settings")),
              dava_plot_action_buttons_ui(ns),
              dava_factor_plot_controls_ui(
                ns,
                ids = c(
                  response = "plot_reponse", mode = "test_plot_mode",
                  x = "test_plot_x", group = "test_plot_group",
                  facet = "test_plot_facet", panel = "test_plot_panel",
                  plot_type = "test_plot_type", significance = "test_sig_method",
                  effect = "test_sig_term",
                  combo_enabled = "test_enable_response_combo",
                  combo_responses = "test_plot_combo_responses",
                  combo_rows = "test_plot_combo_rows", combo_cols = "test_plot_combo_cols"
                ),
                max_factors = 2L,
                include_response_combo = TRUE,
                default_mode = "multi"
              ),
              selectInput(ns("test_plot_theme"), "Topic", choices = dava_plot_theme_choices(), selected = "publication"),
              selectInput(ns("test_plot_palette"), "Colors", choices = dava_plot_palette_choices(), selected = "Nature"),
              textInput(ns("test_plot_title"), "Figure title", value = ""),
              sliderInput(ns("test_plot_base_size"), "Basic font size", min = 8, max = 24, value = 14, step = 1),
              sliderInput(ns("test_plot_x_angle"), "X-axis label angle", min = 0, max = 90, value = 35, step = 5),
              checkboxInput(ns("test_show_legend"), "Show legend", value = TRUE),
              selectInput(ns("test_legend_position"), "Legend location", choices = c("Right" = "right", "Bottom" = "bottom", "Top" = "top", "Left" = "left"), selected = "right"),
              uiOutput(ns("test_component_settings"))
            ),
            dava_plot_size_ui(
              ns, "plot", "test_plot_size", width = 900, height = 700,
              extra_controls = conditionalPanel(
                ns = ns, condition = "input.test_enable_response_combo === true",
                dava_plot_pagination_ui(ns, "test_combo")
              )
            )
          )
        ),
        nav_panel("Model text", verbatimTextOutput(ns("model_text"))),
        nav_panel("Errors and warnings", DTOutput(ns("error_table"))),
        nav_panel("R Markdown code document", dava_module_code_panel_ui(ns))
      )
    )
  )
}

mod_ttest_server <- function(id, file_data, model_type) {
  moduleServer(id, function(input, output, session) {
    root_input <- session$rootScope()$input
    interface_language <- reactive({
      root_input$dava_interface_language
      dava_i18n_language(root_input$dava_interface_language)
    })
    dava_bind_dependency_checker(
      input, session,
      packages = unique(c("stats", "ggplot2", "dplyr", "broom", "patchwork", "writexl")),
      method_label = model_type)
    plot_runtime_diagnostics <- reactiveVal(character())
    record_plot_runtime_diagnostics <- function(captured, source = "Statistical plot") {
      entries <- dava_plot_condition_text(captured, source)
      if (!length(entries)) return(invisible(NULL))
      plot_runtime_diagnostics(unique(c(shiny::isolate(plot_runtime_diagnostics()), entries)))
      invisible(entries)
    }
    make_demo_data <- function() {
      ttest_demo_data()
    }

    selected_group_vars <- reactive({
      opts <- list(
        group = input$group %||% "",
        group1 = input$group1 %||% "",
        group2 = input$group2 %||% "",
        block = input$block %||% "",
        block_subject = input$block_subject %||% "",
        fixed_effect = input$fixed_effect %||% character(0)
      )
      dava_stat_selected_group_vars(model_type, opts)
    })

    output$dataset_select <- renderUI({
      ds_names <- dava_global_dataset_names(file_data)
      choices <- c("Demo data" = "__demo__", ds_names)
      current <- shiny::isolate(input$dataset_select_input %||% "__demo__")
      selected <- if (current %in% unname(choices)) current else "__demo__"
      selectInput(session$ns("dataset_select_input"), "Data set", choices = choices,
        selected = selected, multiple = FALSE)
    })

    raw_df <- reactive({
      selected <- input$dataset_select_input %||% "__demo__"
      if (identical(selected, "__demo__")) {
        return(make_demo_data())
      }
      req(file_data$global_datasets)
      validate(need(selected %in% dava_global_dataset_names(file_data), "Selected data set is not available."))
      as.data.frame(file_data$global_datasets[[selected]], stringsAsFactors = FALSE, check.names = FALSE)
    })

    dava_module_code_panel_server(
      input, output, session, file_data,
      source_prefix = function() paste("statistics", model_type, sep = "/"),
      default_code = function() ttest_code_template(model_type, input, workspace_data = TRUE),
      source = "Statistical analysis",
      title = paste0(model_type, "Complete analysis code"),
      kind = "analysis",
      validate_run = function(run) dava_ttest_custom_result(
        run, input$response %||% character(),
        selected_group_vars()[selected_group_vars() != ""]),
      plot_params = function() {
        params <- list(
          plot_response = input$plot_reponse %||% (input$response %||% character())[1],
          plot_x = input$test_plot_x %||% input$group %||% "",
          plot_group = input$test_plot_group %||% "",
          plot_type = input$test_plot_type %||% "boxplot",
          plot_theme = input$test_plot_theme %||% "publication",
          plot_palette = input$test_plot_palette %||% "Nature",
          plot_base_size = input$test_plot_base_size %||% 14,
          plot_x_angle = input$test_plot_x_angle %||% 35,
          show_legend = isTRUE(input$test_show_legend),
          legend_position = input$test_legend_position %||% "right",
          plot_title = input$test_plot_title %||% ""
        )
        if (isTRUE(input$test_enable_response_combo)) {
          params$combo_responses <- input$test_plot_combo_responses %||% character()
          params$combo_rows <- input$test_plot_combo_rows %||% 1L
          params$combo_cols <- input$test_plot_combo_cols %||% 2L
        }
        params
      },
      data = function() raw_df(),
      dataset_name = function() input$dataset_select_input %||% "__demo__",
      function_mode = "none",
      standalone_bootstrap = FALSE,
      include_input_snapshot = FALSE,
      preview_result = function() analysis_results(),
      preview_plots = function() list("Current result figure" = current_ttest_plot())
    )

    observeEvent(raw_df(), {
      df <- raw_df()
      num_vars <- numeric_vars(df)
      factor_vars <- setdiff(names(df), num_vars)
      all_predictors <- setdiff(names(df), num_vars[1] %||% character(0))

      updatePickerInput(session, "response", choices = num_vars, selected = num_vars[1] %||% NULL)
      updateSelectInput(session, "group", choices = c("None" = "", names(df)), selected = factor_vars[1] %||% "")
      updateSelectInput(session, "block", choices = names(df), selected = factor_vars[2] %||% factor_vars[1] %||% NULL)
      updateSelectInput(session, "group1", choices = names(df), selected = factor_vars[1] %||% NULL)
      updateSelectInput(session, "group2", choices = names(df), selected = factor_vars[2] %||% factor_vars[1] %||% NULL)
      updatePickerInput(session, "fixed_effect", choices = all_predictors, selected = head(factor_vars, as.integer(input$factor_n %||% 1)))
      updateSelectInput(session, "block_subject", choices = c("None" = "", names(df)), selected = "")
      updateSelectInput(session, "plot_reponse", choices = num_vars, selected = num_vars[1] %||% NULL)
    }, ignoreInit = FALSE)

    observeEvent(input$factor_n, {
      req(raw_df())
      selected <- head(input$fixed_effect %||% setdiff(names(raw_df()), input$response %||% character(0)), as.integer(input$factor_n))
      updatePickerInput(session, "fixed_effect", selected = selected)
    })

    output$raw_data_preview <- renderDT({
      req(raw_df())
      datatable(raw_df(), rownames = TRUE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })

    original_analysis_results <- eventReactive(input$run_test, {
      req(raw_df(), input$response)
      test_label <- switch(model_type,
        t_OneSample = "\u5355\u6837\u672c t \u68c0\u9a8c",
        Wilcoxon_OneSample = "\u5355\u6837\u672c Wilcoxon \u68c0\u9a8c",
        t_TwoSample = "\u72ec\u7acb\u6837\u672c t \u68c0\u9a8c",
        WMW_TwoSample = "\u4e24\u72ec\u7acb\u6837\u672c Wilcoxon \u68c0\u9a8c",
        t_TwoSamplePaired = "\u914d\u5bf9\u6837\u672c t \u68c0\u9a8c",
        Wilcoxon_TwoSamplePaired = "\u914d\u5bf9\u6837\u672c Wilcoxon \u68c0\u9a8c",
        KW_OneWay = "Kruskal-Wallis \u68c0\u9a8c",
        Friedman_OneWay = "Friedman \u68c0\u9a8c",
        SRH_TwoWay = "Scheirer-Ray-Hare \u68c0\u9a8c",
        ART_ANOVA = "ART \u65b9\u5dee\u5206\u6790",
        model_type
      )
      progress <- dava_progress(session, min = 0, max = 1)
      on.exit(progress$close(), add = TRUE)
      progress$set(
        message = paste("\u8fd0\u884c", test_label),
        detail = "\u68c0\u67e5\u53d8\u91cf\u4e0e\u5206\u7ec4\u8bbe\u7f6e",
        value = 0.1
      )
      opts <- list(
        group = input$group %||% "",
        group1 = input$group1 %||% "",
        group2 = input$group2 %||% "",
        block = input$block %||% "",
        block_subject = input$block_subject %||% "",
        fixed_effect = input$fixed_effect %||% character(0),
        factor_n = input$factor_n %||% 1,
        adjust_method = input$adjust_method %||% "holm",
        num = input$num %||% 0
      )
      progress$set(detail = "\u6267\u884c\u7edf\u8ba1\u68c0\u9a8c\u4e0e\u591a\u91cd\u6bd4\u8f83", value = 0.35)
      value <- dava_stat_run_tests(raw_df(), input$response, model_type, opts)
      progress$set(detail = "\u6574\u7406\u5206\u6790\u7ed3\u679c", value = 0.9)
      return(value)

      df <- raw_df()
      responses <- input$response
      results <- list()
      summaries <- list()
      errors <- list()

      for (resp in responses) {
        try_result <- tryCatch({
          if (model_type %in% c("t_OneSample", "Wilcoxon_OneSample")) {
            grp <- input$group %||% ""
            dat <- prepare_df(df, resp, grp)
            if (grp == "") {
              split_dat <- list(All = dat)
            } else {
              split_dat <- split(dat, dat[[grp]], drop = TRUE)
            }

            tests <- lapply(names(split_dat), function(level_name) {
              x <- split_dat[[level_name]][[resp]]
              validate(need(length(x) >= 2, "At least two observations are required."))
              if (model_type == "t_OneSample") {
                tidy_htest(stats::t.test(x, mu = input$num %||% 0), resp, level_name)
              } else {
                tidy_htest(stats::wilcox.test(x, mu = input$num %||% 0, exact = FALSE), resp, level_name)
              }
            })
            list(result = dplyr::bind_rows(tests), data = dat, groups = if (grp == "") character(0) else grp)

          } else if (model_type %in% c("t_TwoSample", "WMW_TwoSample", "t_TwoSamplePaired", "Wilcoxon_TwoSamplePaired")) {
            grp <- input$group %||% ""
            validate(need(grp %in% names(df), "Please choose a grouping variable."))
            dat <- prepare_df(df, resp, grp)
            dat[[grp]] <- as.factor(dat[[grp]])
            lv <- levels(dat[[grp]])
            validate(need(length(lv) >= 2, "The grouping variable must have at least two levels."))

            paired <- model_type %in% c("t_TwoSamplePaired", "Wilcoxon_TwoSamplePaired")
            pairs <- utils::combn(lv, 2, simplify = FALSE)
            pair_results <- lapply(pairs, function(pair_lv) {
              x <- dat[dat[[grp]] == pair_lv[1], resp]
              y <- dat[dat[[grp]] == pair_lv[2], resp]
              if (paired) {
                n_pair <- min(length(x), length(y))
                validate(need(n_pair >= 2, "At least two complete pairs are required for each comparison."))
                x <- x[seq_len(n_pair)]
                y <- y[seq_len(n_pair)]
              } else {
                validate(need(length(x) >= 2 && length(y) >= 2, "Each compared group must have at least two observations."))
              }
              
              test <- if (model_type %in% c("t_TwoSample", "t_TwoSamplePaired")) {
                stats::t.test(x, y, paired = paired)
              } else {
                stats::wilcox.test(x, y, paired = paired, exact = FALSE)
              }

              tidy_htest(test, resp, paste(pair_lv, collapse = " vs ")) |>
                dplyr::mutate(
                  group1 = pair_lv[1],
                  group2 = pair_lv[2],
                  n1 = length(x),
                  n2 = length(y),
                  .after = group
                )
            })

            result_df <- dplyr::bind_rows(pair_results)
            adjust <- input$adjust_method %||% "holm"
            result_df$p.adjusted <- p_adjust_vec(result_df$p.value, adjust)
            result_df$p.adjust.method <- adjust
            result_df$significance <- p_to_star(result_df$p.adjusted)

            list(result = result_df, data = dat, groups = grp)

          } else if (model_type == "KW_OneWay") {
            grp <- input$group %||% ""
            validate(need(grp %in% names(df), "Please choose a grouping variable."))
            dat <- prepare_df(df, resp, grp)
            dat[[grp]] <- as.factor(dat[[grp]])
            kt <- stats::kruskal.test(stats::as.formula(paste(resp, "~", grp)), data = dat)
            res <- tidy_htest(kt, resp, grp)
            pw <- stats::pairwise.wilcox.test(dat[[resp]], dat[[grp]], p.adjust.method = ifelse((input$adjust_method %||% "holm") == "sidak", "none", input$adjust_method %||% "holm"), exact = FALSE)
            post <- pairwise_to_df(pw, resp, grp, input$adjust_method %||% "holm")
            if ((input$adjust_method %||% "") == "sidak" && nrow(post) > 0) {
              post$p.value <- p_adjust_vec(post$p.value, "sidak")
              post$significance <- p_to_star(post$p.value)
            }
            list(result = dplyr::bind_rows(res, post), data = dat, groups = grp)

          } else if (model_type == "Friedman_OneWay") {
            grp <- input$group %||% ""
            block <- input$block %||% ""
            validate(need(grp %in% names(df) && block %in% names(df), "Please choose treatment and block variables."))
            dat <- prepare_df(df, resp, c(grp, block))
            dat[[grp]] <- as.factor(dat[[grp]])
            dat[[block]] <- as.factor(dat[[block]])
            ft <- stats::friedman.test(stats::as.formula(paste(resp, "~", grp, "|", block)), data = dat)
            res <- tidy_htest(ft, resp, paste(grp, "|", block))
            pw <- stats::pairwise.wilcox.test(dat[[resp]], dat[[grp]], paired = TRUE, p.adjust.method = ifelse((input$adjust_method %||% "holm") == "sidak", "none", input$adjust_method %||% "holm"), exact = FALSE)
            post <- pairwise_to_df(pw, resp, grp, input$adjust_method %||% "holm")
            if ((input$adjust_method %||% "") == "sidak" && nrow(post) > 0) {
              post$p.value <- p_adjust_vec(post$p.value, "sidak")
              post$significance <- p_to_star(post$p.value)
            }
            list(result = dplyr::bind_rows(res, post), data = dat, groups = c(grp, block))

          } else if (model_type == "SRH_TwoWay") {
            g1 <- input$group1 %||% ""
            g2 <- input$group2 %||% ""
            validate(need(g1 %in% names(df) && g2 %in% names(df), "Please choose two factors."))
            dat <- prepare_df(df, resp, c(g1, g2))
            dat[[g1]] <- as.factor(dat[[g1]])
            dat[[g2]] <- as.factor(dat[[g2]])
            dat$.rank_y <- rank(dat[[resp]], ties.method = "average")
            fit <- stats::lm(stats::as.formula(paste(".rank_y ~", g1, "*", g2)), data = dat)
            res <- broom::tidy(stats::anova(fit)) |>
              dplyr::mutate(response = resp, method = "Scheirer-Ray-Hare rank ANOVA approximation", .before = 1)
            names(res)[names(res) == "p.value"] <- "p.value"
            res$significance <- p_to_star(res$p.value)
            list(result = res, data = dat, groups = c(g1, g2))

          } else if (model_type == "ART_ANOVA") {
            factors <- head(input$fixed_effect %||% character(0), as.integer(input$factor_n %||% 1))
            block <- input$block_subject %||% ""
            validate(need(length(factors) > 0, "Please choose fixed factor(s)."))
            dat <- prepare_df(df, resp, c(factors, block))
            for (nm in factors) dat[[nm]] <- as.factor(dat[[nm]])
            if (block != "" && block %in% names(dat)) dat[[block]] <- as.factor(dat[[block]])
            dat$.rank_y <- rank(dat[[resp]], ties.method = "average")
            rhs <- paste(factors, collapse = " * ")
            if (block != "" && block %in% names(dat)) rhs <- paste(rhs, "+", block)
            fit <- stats::lm(stats::as.formula(paste(".rank_y ~", rhs)), data = dat)
            res <- broom::tidy(stats::anova(fit)) |>
              dplyr::mutate(response = resp, method = "Aligned-rank style ANOVA approximation", .before = 1)
            res$significance <- p_to_star(res$p.value)
            list(result = res, data = dat, groups = factors)
          } else {
            stop("Unsupported analysis type: ", model_type)
          }
        }, error = function(e) e)

        if (inherits(try_result, "error")) {
          errors[[resp]] <- data.frame(response = resp, error = conditionMessage(try_result), stringsAsFactors = FALSE)
        } else {
          results[[resp]] <- try_result$result
          group_vars <- try_result$groups
          if (length(group_vars) == 0) {
            summaries[[resp]] <- data.frame(
              response = resp,
              n = sum(!is.na(try_result$data[[resp]])),
              mean = mean(try_result$data[[resp]], na.rm = TRUE),
              sd = stats::sd(try_result$data[[resp]], na.rm = TRUE),
              se = stats::sd(try_result$data[[resp]], na.rm = TRUE) / sqrt(sum(!is.na(try_result$data[[resp]]))),
              stringsAsFactors = FALSE
            )
          } else {
            summaries[[resp]] <- try_result$data |>
              dplyr::group_by(dplyr::across(dplyr::all_of(group_vars))) |>
              dplyr::summarise(
                n = sum(!is.na(.data[[resp]])),
                mean = mean(.data[[resp]], na.rm = TRUE),
                sd = stats::sd(.data[[resp]], na.rm = TRUE),
                se = sd / sqrt(n),
                .groups = "drop"
              ) |>
              dplyr::mutate(response = resp, .before = 1) |>
              as.data.frame()
          }
        }
      }

      res_df <- dplyr::bind_rows(results)
      err_df <- dplyr::bind_rows(errors)
      if (nrow(err_df) > 0) {
        res_df <- dplyr::bind_rows(res_df, err_df)
      }

      list(
        result = format_anova_table(res_df),
        summary = dplyr::bind_rows(summaries),
        responses = responses,
        groups = selected_group_vars()[selected_group_vars() != ""]
      )
    })

    custom_analysis_run <- eventReactive(list(
      input$run_test, file_data$method_code_revision
    ), {
      method_key <- paste("statistics", model_type, sep = "/")
      entry <- dava_method_code_get(file_data, method_key)
      if (is.null(entry) || !isTRUE(entry$enabled)) return(NULL)
      dava_method_code_execute(file_data, method_key,
        data = raw_df(),
        dataset_name = input$dataset_select_input %||% "__demo__",
        spec = dava_code_analysis_spec_from_input(input))
    }, ignoreInit = TRUE)

    analysis_results <- reactive({
      method_key <- paste("statistics", model_type, sep = "/")
      dava_method_code_effective(
        original = function() original_analysis_results(),
        file_data = file_data, method_key = method_key,
        adapter = function(run, entry) dava_ttest_custom_result(
          custom_analysis_run(),
          responses = input$response %||% character(),
          groups = selected_group_vars()[selected_group_vars() != ""]
        ),
        on_error = function(message) {
          warning_text <- paste0(
            "The user-defined statistical test failed and the original method has been rolled back: ",
            message)
          dava_record_runtime_condition("warning", warning_text,
            paste0("Statistical method: ", model_type))
          plot_runtime_diagnostics(unique(c(
            shiny::isolate(plot_runtime_diagnostics()),
            paste0("[Statistical method: ", model_type, "] WARNING: ", warning_text))))
          original_analysis_results()
        }
      )
    })

    output$summary_df <- renderDT({
      req(analysis_results())
      datatable(analysis_results()$summary, rownames = FALSE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })

    output$anova_table <- renderDT({
      req(analysis_results())
      datatable(analysis_results()$result, rownames = FALSE, filter = "top", options = list(scrollX = TRUE, pageLength = 25))
    })
    output$error_table <- renderDT({
      messages <- c(plot_runtime_diagnostics(), dava_runtime_diagnostic_lines())
      value <- tryCatch(analysis_results(), error = function(error) NULL)
      base_errors <- if (is.list(value) && is.data.frame(value$errors)) value$errors else data.frame()
      datatable(
        dava_localize_message_table(
          dava_append_diagnostic_rows(base_errors, messages,
            source = "Statistical method / plot rendering"),
          interface_language(), dava_user_data_text(raw_df())),
        rownames = FALSE, options = list(scrollX = TRUE, pageLength = 25))
    })
    observeEvent(input$register_results, {
      selected_dataset <- isolate(input$dataset_select_input %||% "__demo__")
      value <- analysis_results()
      req(value)
      registered <- dava_register_global_datasets(
        file_data,
        list(summary = value$summary, result = value$result),
        source = "Statistical analysis / t-test", prefix = "t_test")
      updateSelectInput(session, "dataset_select_input", selected = selected_dataset)
      showNotification(paste0("has been added to the data table warehouse:", paste(unname(registered), collapse = "、")), type = "message", duration = 3)
    })

    output$model_text <- renderText({
      value <- analysis_results()
      req(value)
      responses <- value$responses %||% input$response %||% character(0)
      groups <- value$groups %||% selected_group_vars()
      text <- paste(
        paste0("Analysis method: ", analysis_title(model_type)),
        paste0("Response variables: ", paste(responses, collapse = ", ")),
        paste0("Grouping/Design Variables: ", paste(groups[nzchar(groups)], collapse = ", ")),
        "",
        paste(capture.output(print(value$result)), collapse = "\n"),
        sep = "\n"
      )
      dava_localize_model_text(
        text, interface_language(), dava_user_data_text(raw_df())
      )
    })
    
    
    observeEvent(analysis_results(),{
      req(analysis_results(), raw_df())
      responses <- analysis_results()$responses %||% character(0)
      groups <- analysis_results()$groups %||% character(0)
      groups <- groups[nzchar(groups)]
      selected_response <- if (length(input$plot_reponse) && input$plot_reponse %in% responses) input$plot_reponse else responses[1] %||% NULL
      selected_x <- if (length(input$test_plot_x) && input$test_plot_x %in% groups) input$test_plot_x else groups[1] %||% NULL
      default_group <- if (model_type %in% c("SRH_TwoWay", "ART_ANOVA")) groups[2] %||% "" else ""
      updateSelectInput(session, "plot_reponse", choices = responses, selected = selected_response)
      updateSelectInput(session, "test_plot_x", choices = groups, selected = selected_x)
      updateSelectInput(
        session, "test_plot_group",
        choices = c("None" = "", setdiff(groups, selected_x)),
        selected = if (length(input$test_plot_group) && input$test_plot_group %in% setdiff(groups, selected_x)) input$test_plot_group else default_group
      )
    })

    observeEvent(input$test_plot_x, {
      groups <- analysis_results()$groups %||% character(0)
      choices <- setdiff(groups[nzchar(groups)], input$test_plot_x %||% "")
      selected <- input$test_plot_group %||% ""
      if (nzchar(selected) && !(selected %in% choices)) selected <- ""
      updateSelectInput(session, "test_plot_group", choices = c("None" = "", choices), selected = selected)
    }, ignoreInit = TRUE)

    observeEvent(list(analysis_results(), input$plot_reponse), {
      responses <- setdiff(analysis_results()$responses %||% character(0), input$plot_reponse %||% "")
      selected <- intersect(input$test_plot_combo_responses %||% character(0), responses)
      shinyWidgets::updatePickerInput(
        session, "test_plot_combo_responses", choices = responses, selected = selected
      )
    }, ignoreInit = FALSE)

    test_plot_mapping <- reactive({
      groups <- analysis_results()$groups %||% character(0)
      groups <- as.character(groups)
      groups <- groups[!is.na(groups) & nzchar(groups)]
      x <- input$test_plot_x %||% if (length(groups)) groups[[1L]] else ""
      color_group <- input$test_plot_group %||% ""
      if (!identical(input$test_plot_mode %||% "multi", "multi")) color_group <- ""
      if (is.na(x) || !(x %in% groups)) x <- if (length(groups)) groups[[1L]] else ""
      if (!(color_group %in% setdiff(groups, x))) color_group <- ""
      list(x = x, group = color_group, groups = unique(c(x, color_group))[nzchar(unique(c(x, color_group)))])
    })

    test_annotation_contract_for <- function(response) {
      mapping <- test_plot_mapping()
      result <- as.data.frame(analysis_results()$result, stringsAsFactors = FALSE, check.names = FALSE)
      summary <- as.data.frame(analysis_results()$summary, stringsAsFactors = FALSE, check.names = FALSE)
      if ("response" %in% names(result)) {
        result <- result[
          !is.na(result$response) & as.character(result$response) == as.character(response),
          , drop = FALSE
        ]
      }
      if ("response" %in% names(summary)) {
        summary <- summary[
          !is.na(summary$response) & as.character(summary$response) == as.character(response),
          , drop = FALSE
        ]
      }
      dava_test_result_contract(
        result,
        summary,
        response,
        mapping$groups
      )
    }

    test_annotation_contract <- reactive({
      req(analysis_results(), input$plot_reponse)
      test_annotation_contract_for(input$plot_reponse)
    })

    observeEvent(list(test_annotation_contract(), input$plot_reponse), {
      mapping <- test_plot_mapping()
      contract <- test_annotation_contract()
      if (!nzchar(mapping$x)) {
        updateSelectInput(session, "test_sig_term", choices = character(0), selected = NULL)
        return()
      }
      choices <- dava_significance_term_choices(
        contract$terms, mapping$x, mapping$group, "",
        language = interface_language()
      )
      preferred <- if (nzchar(mapping$group)) paste(mapping$x, mapping$group, sep = ":") else mapping$x
      selected <- if (preferred %in% unname(choices)) preferred else unname(choices)[1] %||% NULL
      updateSelectInput(session, "test_sig_term", choices = choices, selected = selected)
    }, ignoreInit = TRUE)
    
    build_ttest_plot <- function(y) {
      req(analysis_results(), raw_df(), y)
      df <- raw_df()
      mapping <- test_plot_mapping()
      groups <- mapping$groups
      validate(need(y %in% names(df), "No response selected."))
      if (!nzchar(mapping$x) || !(mapping$x %in% names(df))) {
        p <- dava_ttest_plot(df, y, groups)
        validate(need(!is.null(p), "No plot is available."))
        return(dava_plot_theme(
          p,
          input$test_plot_theme %||% "publication",
          input$test_plot_base_size %||% 14,
          input$test_legend_position %||% "right",
          TRUE,
          isTRUE(input$test_show_legend)
        ))
      }

      plot_vars <- unique(c(y, mapping$x, mapping$group))
      plot_vars <- plot_vars[nzchar(plot_vars) & plot_vars %in% names(df)]
      keep <- stats::complete.cases(df[, plot_vars, drop = FALSE]) & is.finite(suppressWarnings(as.numeric(df[[y]])))
      df <- droplevels(df[keep, , drop = FALSE])
      validate(need(nrow(df) > 0, "No complete observations are available for plotting."))
      df[[y]] <- suppressWarnings(as.numeric(df[[y]]))

      summary_groups <- unique(c(mapping$x, mapping$group))
      summary_groups <- summary_groups[nzchar(summary_groups)]
      plot_summary <- df |>
        dplyr::group_by(dplyr::across(dplyr::all_of(summary_groups))) |>
        dplyr::summarise(
          mean = mean(.data[[y]], na.rm = TRUE),
          se = stats::sd(.data[[y]], na.rm = TRUE) / sqrt(sum(!is.na(.data[[y]]))),
          n = sum(!is.na(.data[[y]])),
          .groups = "drop"
        )

      p <- dava_anova_effect_plot(
        df, plot_summary, y, mapping$x, mapping$group, "",
        input$test_plot_type %||% "boxplot",
        input$test_sig_method %||% "none",
        add_defaults = FALSE
      )
      validate(need(!is.null(p), "No plot is available."))
      palette_vars <- unique(c(mapping$x, mapping$group))
      palette_vars <- palette_vars[nzchar(palette_vars) & palette_vars %in% names(df)]
      palette_n <- max(
        16L,
        vapply(palette_vars, function(var) length(unique(stats::na.omit(df[[var]]))), integer(1)),
        na.rm = TRUE
      )
      p <- suppressMessages(dava_plot_add_palette(p, input$test_plot_palette %||% "Nature", palette_n))
      p <- dava_plot_theme(
        p,
        input$test_plot_theme %||% "publication",
        input$test_plot_base_size %||% 14,
        input$test_legend_position %||% "right",
        FALSE,
        isTRUE(input$test_show_legend)
      ) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = input$test_plot_x_angle %||% 35, hjust = 1)) +
        ggplot2::labs(
          title = if (nzchar(trimws(input$test_plot_title %||% ""))) input$test_plot_title else paste(model_type, y),
          x = mapping$x,
          y = y
        )

      y_range <- range(df[[y]], na.rm = TRUE)
      y_span <- diff(y_range)
      if (!is.finite(y_span) || y_span == 0) y_span <- abs(y_range[1]) + 1
      lower <- y_range[1] - 0.08 * y_span
      upper <- y_range[2] + 0.35 * y_span
      if (identical(input$test_plot_type %||% "boxplot", "bar")) lower <- min(0, lower)
      p <- p + ggplot2::coord_cartesian(ylim = c(lower, upper), clip = "on")

      contract <- test_annotation_contract_for(y)
      sig_method <- input$test_sig_method %||% "auto"
      if (sig_method %in% c("auto", "cld_lower", "cld_upper") && nrow(contract$standard_result$cld)) {
        annotation <- build_annotation_table(
          contract$standard_result, df, y, "cld",
          group_vars = unique(c(mapping$x, mapping$group))
        )
        if (identical(sig_method, "cld_upper")) annotation$label <- toupper(annotation$label)
        p <- add_cld_annotations(p, annotation, mapping$x, mapping$group, size = 5)
      } else {
        p <- dava_add_model_significance(
          p,
          response = y,
          x = mapping$x,
          group = mapping$group,
          term = input$test_sig_term %||% mapping$x,
          method = sig_method,
          anova_table = contract$anova_table,
          posthoc = contract$posthoc,
          letters = contract$letters,
          data = df,
          y_span = y_span,
          y_top = y_range[2],
          allow_pairwise = !nzchar(mapping$group)
        )
      }
      p
    }

    test_plot_responses <- reactive({
      req(input$plot_reponse)
      responses <- input$plot_reponse
      if (isTRUE(input$test_enable_response_combo)) {
        responses <- unique(c(responses, input$test_plot_combo_responses %||% character(0)))
      }
      responses
    })
    cached_test_plot_pages <- reactive({
      rows <- max(1L, suppressWarnings(as.integer(input$test_plot_combo_rows %||% 1L)))
      cols <- max(1L, suppressWarnings(as.integer(input$test_plot_combo_cols %||% 2L)))
      chunks <- dava_plot_page_chunks(test_plot_responses(), rows, cols)
      lapply(chunks, function(responses) {
        plots <- lapply(responses, build_ttest_plot)
        if ((length(plots) == 1L && !isTRUE(input$test_enable_response_combo)) || !requireNamespace("patchwork", quietly = TRUE)) return(plots[[1]])
        patchwork::wrap_plots(plots, nrow = rows, ncol = cols)
      })
    })
    test_plot_total_pages <- reactive(max(1L, length(cached_test_plot_pages())))
    test_plot_page <- dava_plot_pagination_server(input, session, "test_combo", test_plot_total_pages)

    current_ttest_plot <- reactive({
      custom <- analysis_results()$custom_plot %||% NULL
      if (!is.null(custom)) return(custom)
      pages <- cached_test_plot_pages()
      pages[[min(test_plot_page(), length(pages))]]
    })

    output$test_component_settings <- renderUI({
      plot <- current_ttest_plot()
      if (!dava_is_composite_plot(plot)) return(NULL)
      dava_composite_plot_settings_ui(session$ns, plot, "ttest_components")
    })

    configured_ttest_plot <- reactive({
      dava_apply_composite_plot_settings(current_ttest_plot(), input, "ttest_components")
    })

    test_plot_dimensions <- dava_plot_size_server(
      input, output, session, "plot", "test_plot_size", width = 900, height = 700
    )

    output$plot <- renderPlot({
      captured <- dava_capture_conditions({
        p <- configured_ttest_plot()
        print(p)
      }, source = paste0("Statistical plot: ", model_type))
      record_plot_runtime_diagnostics(captured,
        paste0("Statistical plot: ", model_type))
      if (nzchar(captured$error %||% "")) dava_plot_diagnostic_placeholder(captured$error)
      invisible(captured$value)
    })

    observeEvent(input$add_plot_to_library, {
      p <- configured_ttest_plot()
      dims <- test_plot_dimensions()
      ok <- dava_plot_register(
        file_data,
        paste("statistics", model_type, input$plot_reponse %||% "plot", sep = "/"),
        p,
        source = "Statistical analysis",
        title = paste(model_type, input$plot_reponse %||% "plot"),
        meta = list(module = "t_test_mode", model_type = model_type, response = input$plot_reponse %||% "", added_by = "manual"),
        params = c(list(module = "t_test_mode", model_type = model_type, width_px = dims$width_px, height_px = dims$height_px), dava_plot_input_params(input)),
        editor_svg = dava_plot_editor_svg_sized(p, dims)
      )
      showNotification(if (isTRUE(ok)) "has been added to the Analysis Gallery." else "Add failed: The current drawing is not a registrable object.", type = if (isTRUE(ok)) "message" else "error", duration = 3)
    })

    output$download_plot_png <- downloadHandler(
      filename = function() sprintf("%s_%s_%s.png", model_type, input$plot_reponse %||% "plot", Sys.Date()),
      content = function(file) dava_save_sized_plot(file, configured_ttest_plot(), "png", test_plot_dimensions(), 300)
    )
    output$download_plot_pdf <- downloadHandler(
      filename = function() sprintf("%s_%s_%s.pdf", model_type, input$plot_reponse %||% "plot", Sys.Date()),
      content = function(file) dava_save_sized_plot(file, configured_ttest_plot(), "pdf", test_plot_dimensions(), 300)
    )
    output$download_results <- downloadHandler(
      filename = function() sprintf("t_test_results_%s.xlsx", Sys.Date()),
      content = function(file) {
        value <- analysis_results(); req(value)
        tables <- Filter(function(x) is.data.frame(x) || is.matrix(x), list(
          summary = value$summary, result = value$result, errors = value$errors
        ))
        if (!length(tables)) tables <- list(Sheet1 = data.frame(message = "No results"))
        dava_write_xlsx(tables, path = file)
      }
    )
  })
}
