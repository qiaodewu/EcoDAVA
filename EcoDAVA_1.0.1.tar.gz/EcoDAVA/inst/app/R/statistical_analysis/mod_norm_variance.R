# mod_norm_variance.R

dava_norm_qq_plot <- function(qq_data, response) {
  response_value <- response
  dd <- qq_data |>
    dplyr::filter(.data[["response"]] == response_value)
  if (nrow(dd) == 0) return(NULL)
  ggplot2::ggplot(dd, ggplot2::aes(sample = residual)) +
    ggplot2::stat_qq(size = 2, alpha = 0.75) +
    ggplot2::stat_qq_line(linewidth = 1) +
    ggplot2::labs(
      title = paste0("QQ plot of residuals: ", response),
      x = "Theoretical quantiles",
      y = "Sample quantiles"
    ) +
    ggplot2::theme_bw(base_size = 14)
}

dava_norm_resid_plot <- function(qq_data, response) {
  response_value <- response
  dd <- qq_data |>
    dplyr::filter(.data[["response"]] == response_value)
  if (nrow(dd) == 0) return(NULL)
  ggplot2::ggplot(dd, ggplot2::aes(x = fitted, y = residual)) +
    ggplot2::geom_point(size = 2, alpha = 0.75) +
    ggplot2::geom_hline(yintercept = 0, linetype = 2) +
    ggplot2::geom_smooth(method = "loess", se = FALSE) +
    ggplot2::labs(
      title = paste0("Residuals vs fitted: ", response),
      x = "Fitted values",
      y = "Residuals"
    ) +
    ggplot2::theme_bw(base_size = 14)
}

dava_norm_plot_settings_prefix <- function(kind) paste0("norm_plot_", kind)

dava_norm_plot_object <- function(qq_data, response, kind, input = NULL) {
  plot <- if (identical(kind, "qq")) dava_norm_qq_plot(qq_data, response) else dava_norm_resid_plot(qq_data, response)
  if (!is.null(input)) plot <- dava_apply_result_plot_settings(plot,
    dava_result_plot_settings(input, dava_norm_plot_settings_prefix(kind)))
  dava_plot_english_labels(plot)
}

dava_anova_effect_plot <- function(df, summary_df, y, x, group = "", facet = "", plot_type = "boxplot", sig_type = "none", posthoc_letters = NULL, add_defaults = TRUE) {
  if (!y %in% names(df) || !x %in% names(df)) return(NULL)
  dodge <- ggplot2::position_dodge(width = 0.78)
  p <- switch(
    plot_type,
    "boxplot" = {
      if (nzchar(group) && group %in% names(df)) {
        ggplot2::ggplot(df, ggplot2::aes(x = .data[[x]], y = .data[[y]], fill = .data[[group]])) +
          ggplot2::geom_boxplot(width = 0.65, alpha = 0.75, position = dodge, outlier.shape = NA) +
          ggplot2::geom_point(position = ggplot2::position_jitterdodge(jitter.width = 0.08, dodge.width = 0.78), alpha = 0.45)
      } else {
        ggplot2::ggplot(df, ggplot2::aes(x = .data[[x]], y = .data[[y]], fill = .data[[x]])) +
          ggplot2::geom_boxplot(width = 0.65, alpha = 0.75, outlier.shape = NA) +
          ggplot2::geom_jitter(width = 0.12, alpha = 0.45)
      }
    },
    "bar" = {
      if (nzchar(group) && group %in% names(summary_df)) {
        ggplot2::ggplot(summary_df, ggplot2::aes(x = .data[[x]], y = mean, fill = .data[[group]])) +
          ggplot2::geom_col(width = 0.65, alpha = 0.85, position = dodge) +
          ggplot2::geom_errorbar(ggplot2::aes(ymin = mean - se, ymax = mean + se), width = 0.18, position = dodge)
      } else {
        ggplot2::ggplot(summary_df, ggplot2::aes(x = .data[[x]], y = mean, fill = .data[[x]])) +
          ggplot2::geom_col(width = 0.65, alpha = 0.85) +
          ggplot2::geom_errorbar(ggplot2::aes(ymin = mean - se, ymax = mean + se), width = 0.18)
      }
    },
    "line" = {
      if (nzchar(group) && group %in% names(summary_df)) {
        ggplot2::ggplot(summary_df, ggplot2::aes(x = .data[[x]], y = mean, group = .data[[group]], color = .data[[group]])) +
          ggplot2::geom_point(size = 3, position = dodge) +
          ggplot2::geom_line(linewidth = 1, position = dodge) +
          ggplot2::geom_errorbar(ggplot2::aes(ymin = mean - se, ymax = mean + se), width = 0.15, position = dodge)
      } else {
        ggplot2::ggplot(summary_df, ggplot2::aes(x = .data[[x]], y = mean, group = 1)) +
          ggplot2::geom_point(size = 4) +
          ggplot2::geom_line(linewidth = 1) +
          ggplot2::geom_errorbar(ggplot2::aes(ymin = mean - se, ymax = mean + se), width = 0.15)
      }
    },
    "violin" = {
      if (nzchar(group) && group %in% names(df)) {
        ggplot2::ggplot(df, ggplot2::aes(x = .data[[x]], y = .data[[y]], fill = .data[[group]])) +
          ggplot2::geom_violin(alpha = 0.65, trim = FALSE, position = dodge) +
          ggplot2::geom_boxplot(width = 0.15, alpha = 0.85, position = dodge, outlier.shape = NA)
      } else {
        ggplot2::ggplot(df, ggplot2::aes(x = .data[[x]], y = .data[[y]], fill = .data[[x]])) +
          ggplot2::geom_violin(alpha = 0.65, trim = FALSE) +
          ggplot2::geom_boxplot(width = 0.18, alpha = 0.85, outlier.shape = NA) +
          ggplot2::geom_jitter(width = 0.1, alpha = 0.45)
      }
    }
  )
  if (is.null(p)) return(NULL)
  if (nzchar(facet) && facet %in% names(df)) p <- p + ggplot2::facet_wrap(stats::as.formula(paste("~", facet)))
  if (!isTRUE(add_defaults)) return(p)
  y_range <- range(df[[y]], na.rm = TRUE)
  y_span <- diff(y_range)
  if (!is.finite(y_span) || y_span == 0) y_span <- abs(y_range[1]) + 1
  p +
    ggplot2::coord_cartesian(ylim = c(y_range[1] - 0.08 * y_span, y_range[2] + 0.28 * y_span), clip = "off") +
    ggplot2::theme_bw(base_size = 14) +
    ggplot2::theme(
      plot.margin = ggplot2::margin(20, 25, 35, 15),
      axis.text.x = ggplot2::element_text(angle = 35, hjust = 1),
      legend.position = ifelse(nzchar(group), "right", "none")
    ) +
    ggplot2::labs(x = x, y = y, title = paste("Effect plot for", y))
}

anova_plot_settings_ui <- function(ns) {
  tagList(
    tags$div(class = "stat-box", tags$strong("Graphics settings")),
    dava_plot_action_buttons_ui(
      ns, "add_anova_plot_to_library", "download_anova_plot_png", "download_anova_plot_pdf"
    ),
    selectInput(ns("plot_layout_aov"), "Multi-factor layout", choices = c("Standard grouping/faceting" = "standard", "Symmetrical left and right split" = "symmetric", "Dual response variable dual Y-axis" = "dual_axis"), selected = "standard"),
    conditionalPanel(
      ns = ns,
      "input.plot_layout_aov == 'dual_axis'",
      selectInput(ns("plot_secondary_response_aov"), "Secondary coordinate response variable", choices = NULL)
    ),
    selectInput(ns("plot_theme_aov"), "Topic", choices = dava_plot_theme_choices(), selected = "publication"),
    selectInput(ns("plot_palette_aov"), "Colors", choices = dava_plot_palette_choices(), selected = "Nature"),
    textInput(ns("plot_title_aov"), "Figure title", value = ""),
    textInput(ns("plot_x_label_aov"), "X-axis title", value = ""),
    textInput(ns("plot_y_label_aov"), "Y-axis title", value = ""),
    sliderInput(ns("plot_base_size_aov"), "Basic font size", min = 8, max = 24, value = 14, step = 1),
    sliderInput(ns("plot_x_angle_aov"), "X-axis label angle", min = 0, max = 90, value = 35, step = 5),
    checkboxInput(ns("plot_show_legend_aov"), "Show legend", value = TRUE),
    selectInput(
      ns("plot_legend_position_aov"),
      "Legend location",
      choices = c("Right" = "right", "Bottom" = "bottom", "Top" = "top", "Left" = "left"),
      selected = "right"
    ),
    textInput(ns("plot_y_min_aov"), "Y-axis lower limit (leave blank to automatically)", value = ""),
    textInput(ns("plot_y_max_aov"), "Y-axis upper limit (leave blank to automatically)", value = ""),
    checkboxInput(ns("plot_flip_coord_aov"), "Flip axis", value = FALSE)
  )
}

anova_apply_shared_composite_settings <- function(plot, input) {
  if (!dava_is_composite_plot(plot)) return(plot)
  settings <- list(
    title = "",
    theme = input$plot_theme_aov %||% "publication",
    palette = input$plot_palette_aov %||% "Nature",
    base_size = input$plot_base_size_aov %||% 14,
    x_angle = input$plot_x_angle_aov %||% 35,
    show_legend = isTRUE(input$plot_show_legend_aov),
    legend_position = input$plot_legend_position_aov %||% "right",
    flip = FALSE
  )
  for (index in seq_len(length(plot))) {
    plot[[index]] <- dava_apply_result_plot_settings(plot[[index]], settings)
  }
  plot
}

norm_variance_code_template <- function(input, workspace_data = FALSE) {
  responses <- paste(sprintf("'%s'", input$response_var_input %||% character(0)), collapse = ", ")
  fixed <- paste(sprintf("'%s'", input$fixed_var_input %||% character(0)), collapse = ", ")
  paste0(
    "# DAVA Normality-Homogeneity of Variances TestComplete process WhenCode\n",
    if (isTRUE(workspace_data)) "df <- analysis_input_data\n" else if (identical(input$dataset_select_input %||% "__demo__", "__demo__")) paste0(
      dava_local_demo_code("statistics/ecology_demo.rds", "df"), "\n"
    ) else paste0("df <- get_dataset('", input$dataset_select_input %||% "", "')\n"),
    "responses <- c(", responses, ")\n",
    "fixed_vars <- c(", fixed, ")\n",
    "result <- lapply(responses, function(y) {\n",
    "  dat <- df[, unique(c(y, fixed_vars)), drop = FALSE]\n",
    "  dat <- stats::na.omit(dat)\n",
    "  model <- stats::lm(stats::reformulate(fixed_vars, response = y), data = dat)\n",
    "  residual <- stats::residuals(model)\n",
    "  data.frame(\n",
    "    response = y,\n",
    "    normality_method = '", input$norm_method %||% "Shapiro-Wilk", "',\n",
    "    shapiro_p = if (length(residual) >= 3 && length(residual) <= 5000) stats::shapiro.test(residual)$p.value else NA_real_,\n",
    "    model = paste(deparse(stats::formula(model)), collapse = ''),\n",
    "    stringsAsFactors = FALSE\n",
    "  )\n",
    "})\n",
    "result <- dplyr::bind_rows(result)\n",
    "p <- NULL\n",
    "if (length(responses) > 0 && length(fixed_vars) > 0) {\n",
    "  y <- responses[1]\n",
    "  dat <- stats::na.omit(df[, unique(c(y, fixed_vars)), drop = FALSE])\n",
    "  model <- stats::lm(stats::reformulate(fixed_vars, response = y), data = dat)\n",
    "  qq_data <- data.frame(response = y, residual = stats::residuals(model), fitted = stats::fitted(model))\n",
    "  qq_reference <- stats::qqnorm(qq_data$residual, plot.it = FALSE)\n",
    "  qq_plot_data <- data.frame(theoretical = qq_reference$x, sample = qq_reference$y)\n",
    "  p <- ggplot2::ggplot(qq_plot_data, ggplot2::aes(x = theoretical, y = sample)) + ggplot2::geom_point(colour = '#2C7FB8', alpha = 0.75) + ggplot2::geom_qq_line(ggplot2::aes(sample = sample), colour = '#D7301F', linewidth = 0.8) + ggplot2::theme_bw(base_size = 14) + ggplot2::labs(title = paste('Normal Q-Q:', y), x = 'Theoretical quantiles', y = 'Residual quantiles')\n",
    "  register_plot('code/statistics/norm_variance', p, source = 'Module Code', title = 'Normality-Homogeneity of Variance Test')\n",
    "}\n",
    "list(result = result, summary = result, plot = p)\n"
  )
}

anova_code_template <- function(model_type, input, workspace_data = FALSE) {
  r_literal <- function(value) paste(deparse(value, width.cutoff = 500L), collapse = "")
  response_values <- input$response_var_aov %||% character(0)
  fixed_values <- input$fixed_var_aov %||% character(0)
  random_type <- input$random_type %||% "Random intercept"
  random_intercept <- if (identical(random_type, "Random slope")) {
    input$random_intercept_slope_group %||% input$random_vars %||% character(0)
  } else input$random_intercept %||% input$random_vars %||% character(0)
  random_slope <- input$random_slope %||% fixed_values[1] %||% character(0)
  random_nested <- input$random_nested %||% input$random_vars %||% character(0)
  random_crossed <- input$random_crossed %||% input$random_vars %||% character(0)
  formula_values <- vapply(response_values, function(response) {
    tryCatch(
      paste(deparse(build_model_formula(
        response, fixed_values, model_type, input$factor_n_aov,
        input$subject %||% character(0), input$within_factors %||% character(0),
        input$between_factors %||% character(0), input$block %||% character(0),
        input$covariates %||% character(0), random_type, random_intercept,
        random_slope, random_nested, random_crossed
      )), collapse = ""),
      error = function(e) paste(response, "~", paste(fixed_values, collapse = " + "))
    )
  }, character(1))
  names(formula_values) <- response_values
  fit_lines <- if (model_type %in% c("ANOVA", "anova_CRD", "anova_block", "ancova")) {
    "  fit <- stats::lm(form, data = dat)\n"
  } else if (identical(model_type, "anova_repeated")) {
    paste0(
      "  if (!requireNamespace('afex', quietly = TRUE)) stop('Repeated measures ANOVA requires the afex package.')\n",
      "  fit <- afex::aov_car(form, data = dat, type = 3)\n")
  } else if (identical(model_type, "LMM")) {
    paste0(
      "  if (!requireNamespace('lme4', quietly = TRUE)) stop('LMM requires the lme4 package.')\n",
      "  fit <- lme4::lmer(form, data = dat, REML = TRUE, control = lme4::lmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 2e5)))\n",
      "  bad_fit <- !is.null(fit@optinfo$conv$lme4$messages) || lme4::isSingular(fit)\n",
      "  if (bad_fit && use_bayes_fallback) {\n",
      "    if (!requireNamespace('blme', quietly = TRUE)) stop('Bayesian fallback requires the blme package.')\n",
      "    fit <- blme::blmer(form, data = dat, fixef.prior = blme::normal(sd = 10), cov.prior = blme::wishart(df = 3), resid.prior = blme::gamma(shape = 2, rate = 1), control = lme4::lmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 2e5)))\n",
      "  }\n")
  } else if (identical(model_type, "GLMM")) {
    paste0(
      "  if (!requireNamespace('lme4', quietly = TRUE)) stop('GLMM requires the lme4 package.')\n",
      "  family_object <- switch(distribution_family, binomial = stats::binomial(), poisson = stats::poisson(), gamma = stats::Gamma(link = 'log'), `inverse gaussian` = stats::inverse.gaussian(link = 'log'), gaussian = stats::gaussian(), NULL)\n",
      "  fit <- if (identical(distribution_family, 'negative binomial')) lme4::glmer.nb(form, data = dat, control = lme4::glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 2e5))) else lme4::glmer(form, data = dat, family = family_object, control = lme4::glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 2e5)))\n",
      "  bad_fit <- !is.null(fit@optinfo$conv$lme4$messages) || lme4::isSingular(fit)\n",
      "  if (bad_fit && use_bayes_fallback) {\n",
      "    if (!requireNamespace('blme', quietly = TRUE)) stop('Bayesian fallback requires the blme package.')\n",
      "    fallback_family <- if (identical(distribution_family, 'negative binomial')) stats::negbinomial() else family_object\n",
      "    fit <- blme::bglmer(form, data = dat, family = fallback_family, fixef.prior = blme::normal(sd = 10), cov.prior = blme::wishart(df = 3), control = lme4::glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 2e5)))\n",
      "  }\n")
  } else paste0("  stop('Unsupported model type: ", model_type, "')\n")
  paste0(
    "# DAVA Analysis of Variance/MixmodelComplete process WhenCode\n",
    "# Model: ", model_type, "\n",
    if (isTRUE(workspace_data)) "df <- analysis_input_data\n" else if (identical(input$dataset_select_aov_input %||% "__demo__", "__demo__")) paste0(
      dava_local_demo_code("statistics/ecology_demo.rds", "df"), "\n"
    ) else paste0("df <- get_dataset('", input$dataset_select_aov_input %||% "", "')\n"),
    "model_family <- ", r_literal(model_type), " # <DAVA-UI-PARAM>\n",
    "responses <- ", r_literal(response_values), " # <DAVA-UI-PARAM>\n",
    "fixed_vars <- ", r_literal(fixed_values), " # <DAVA-UI-PARAM>\n",
    "formula_text <- ", r_literal(formula_values), " # <DAVA-UI-PARAM>\n",
    "distribution_family <- ", r_literal(input$distribution_family %||% "poisson"), " # <DAVA-UI-PARAM>\n",
    "use_bayes_fallback <- ", r_literal(isTRUE(input$use_bayes_fallback)), " # <DAVA-UI-PARAM>\n",
    "fits <- list()\n",
    "for (y in responses) {\n",
    "  form <- stats::as.formula(formula_text[[y]])\n",
    "  dat <- stats::na.omit(df[, unique(all.vars(form)), drop = FALSE])\n",
    "  factor_vars <- intersect(unique(c(fixed_vars, ", r_literal(unique(c(input$subject, input$within_factors, input$between_factors, input$block, random_intercept, random_nested, random_crossed))), ")), names(dat))\n",
    "  dat[factor_vars] <- lapply(dat[factor_vars], as.factor)\n",
    fit_lines,
    "  anova_part <- if (inherits(fit, 'afex_aov')) as.data.frame(fit$anova_table) else as.data.frame(stats::anova(fit))\n",
    "  anova_part$term <- rownames(anova_part); anova_part$response <- y; rownames(anova_part) <- NULL\n",
    "  coefficient_part <- tryCatch({ z <- as.data.frame(summary(fit)$coefficients); z$term <- rownames(z); z$response <- y; rownames(z) <- NULL; z }, error = function(e) data.frame())\n",
    "  fits[[y]] <- list(model = fit, formula = form, anova = anova_part, coefficients = coefficient_part, model_text = paste(capture.output(summary(fit)), collapse = '\\n'))\n",
    "}\n",
    "result <- dplyr::bind_rows(lapply(fits, `[[`, 'anova'))\n",
    "model_table <- dplyr::bind_rows(lapply(fits, `[[`, 'coefficients'))\n",
    "models <- lapply(fits, `[[`, 'model')\n",
    "model_text <- stats::setNames(lapply(fits, `[[`, 'model_text'), responses)\n",
    "p <- NULL\n",
    "if (length(responses) > 0 && length(fixed_vars) > 0) {\n",
    "  y <- '", input$plot_response_aov %||% input$response_var_aov[1] %||% "", "'; x <- '", input$plot_x_aov %||% input$fixed_var_aov[1] %||% "", "'\n",
    "  group <- '", if (identical(input$plot_mode_aov %||% "single", "multi")) input$plot_group_aov %||% "" else "", "'; facet <- '", if (identical(input$plot_mode_aov %||% "single", "multi")) input$plot_facet_aov %||% "" else "", "'\n",
    "  group_vars <- unique(c(x, group)); group_vars <- group_vars[nzchar(group_vars) & group_vars %in% names(df)]\n",
    "  summary_df <- dplyr::summarise(dplyr::group_by(df, dplyr::across(dplyr::all_of(group_vars))), mean = mean(.data[[y]], na.rm = TRUE), se = stats::sd(.data[[y]], na.rm = TRUE) / sqrt(sum(!is.na(.data[[y]]))), .groups = 'drop')\n",
    "  plot_data <- df[is.finite(df[[y]]) & !is.na(df[[x]]), , drop = FALSE]\n",
    "  if (nzchar(group) && group %in% names(plot_data)) {\n",
    "    p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data[[x]], y = .data[[y]], colour = .data[[group]], fill = .data[[group]]))\n",
    "  } else {\n",
    "    p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data[[x]], y = .data[[y]]))\n",
    "  }\n",
    "  plot_type <- '", input$plot_type_aov %||% "boxplot", "' # <DAVA-UI-PARAM>\n",
    "  if (plot_type %in% c('boxplot', 'box')) p <- p + ggplot2::geom_boxplot(alpha = 0.65, outlier.shape = NA) + ggplot2::geom_jitter(width = 0.12, alpha = 0.65)\n",
    "  if (plot_type %in% c('violin', 'violinplot')) p <- p + ggplot2::geom_violin(alpha = 0.55, trim = FALSE) + ggplot2::geom_boxplot(width = 0.15, alpha = 0.7, outlier.shape = NA)\n",
    "  if (plot_type %in% c('bar', 'barplot')) p <- ggplot2::ggplot(summary_df, ggplot2::aes(x = .data[[x]], y = .data[['mean']])) + ggplot2::geom_col(fill = '#3B7EA1', alpha = 0.8) + ggplot2::geom_errorbar(ggplot2::aes(ymin = .data[['mean']] - .data[['se']], ymax = .data[['mean']] + .data[['se']]), width = 0.15)\n",
    "  if (plot_type %in% c('line', 'lineplot')) p <- p + ggplot2::stat_summary(fun = mean, geom = 'line', ggplot2::aes(group = if (nzchar(group)) .data[[group]] else 1), linewidth = 0.9) + ggplot2::stat_summary(fun = mean, geom = 'point', size = 2.4)\n",
    "  p <- p + ggplot2::theme_bw(base_size = 14) + ggplot2::labs(x = x, y = y)\n",
    "  if (nzchar(group)) p <- p + ggplot2::labs(colour = group, fill = group)\n",
    "  if (!is.null(p)) register_plot('code/statistics/", model_type, "', p, source = 'module code', title = '", model_type, "')\n",
    "}\n",
    "analysis_output <- list(result = result, summary = model_table, models = models, formulas = formula_text, model_text = model_text, plot = p)\n",
    "result <- analysis_output\n",
    "result\n"
  )
}

# Keep the fitted-model section above as the single method-specific source, but
# replace its former one-response preview with the same multi-response plotting
# contract used by the analysis page.  The emitted script remains standalone:
# it contains no calls to private EcoDAVA helpers.
anova_code_template_model_only <- anova_code_template
anova_code_template <- function(model_type, input, workspace_data = FALSE) {
  r_literal <- function(value) paste(deparse(value, width.cutoff = 500L), collapse = "")
  canonical_model_type <- if (tolower(as.character(model_type %||% "")[1]) == "anova") "ANOVA" else model_type
  code <- anova_code_template_model_only(canonical_model_type, input, workspace_data)
  marker <- "p <- NULL\n"
  marker_at <- regexpr(marker, code, fixed = TRUE)[1]
  if (marker_at < 1L) return(code)
  model_code <- substr(code, 1L, marker_at - 1L)

  responses <- input$response_var_aov %||% character(0)
  primary <- input$plot_response_aov %||% responses[1] %||% ""
  plot_responses <- primary
  if (isTRUE(input$enable_response_combo_aov)) {
    plot_responses <- unique(c(primary, setdiff(input$plot_combo_responses_aov %||% character(0), primary)))
  }
  plot_responses <- plot_responses[nzchar(plot_responses) & plot_responses %in% responses]
  if (!length(plot_responses)) plot_responses <- responses[1] %||% character(0)
  palette <- input$plot_palette_aov %||% "Nature"
  palette_base <- switch(
    palette,
    Nature = c("#3B7EA1", "#D95F02", "#1B9E77", "#7570B3", "#E7298A", "#66A61E", "#E6AB02", "#A6761D"),
    Cell = c("#3C5488", "#00A087", "#E64B35", "#4DBBD5", "#F39B7F", "#8491B4", "#91D1C2", "#7E6148"),
    JAMA = c("#374E55", "#DF8F44", "#00A1D5", "#B24745", "#79AF97", "#6A6599", "#80796B", "#F39B7F"),
    Ecology = c("#2A9D8F", "#E9C46A", "#F4A261", "#E76F51", "#264653", "#8AB17D", "#577590", "#BC4749"),
    Colorblind_OkabeIto = c("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7", "#000000"),
    c("#3B7EA1", "#D95F02", "#1B9E77", "#7570B3", "#E7298A", "#66A61E", "#E6AB02", "#A6761D")
  )
  colors <- if (exists("dava_plot_palette", mode = "function")) {
    dava_plot_palette(palette, 16L)
  } else {
    rep(palette_base, length.out = 16L)
  }
  numeric_limit <- function(value) {
    out <- suppressWarnings(as.numeric(trimws(value %||% "")))
    if (length(out) != 1L || !is.finite(out)) NA_real_ else out
  }
  rows <- max(1L, suppressWarnings(as.integer(input$plot_combo_rows_aov %||% 1L)))
  cols <- max(1L, suppressWarnings(as.integer(input$plot_combo_cols_aov %||% 2L)))

  plot_parameters <- paste0(
    "plot_responses <- ", r_literal(plot_responses), " # <DAVA-UI-PARAM>\n",
    "plot_x <- ", r_literal(input$plot_x_aov %||% input$fixed_var_aov[1] %||% ""), " # <DAVA-UI-PARAM>\n",
    "plot_group <- ", r_literal(if (identical(input$plot_mode_aov %||% "single", "multi")) input$plot_group_aov %||% "" else ""), " # <DAVA-UI-PARAM>\n",
    "plot_facet <- ", r_literal(if (identical(input$plot_mode_aov %||% "single", "multi")) input$plot_facet_aov %||% "" else ""), " # <DAVA-UI-PARAM>\n",
    "plot_type <- ", r_literal(input$plot_type_aov %||% "boxplot"), " # <DAVA-UI-PARAM>\n",
    "significance_display <- ", r_literal(input$sig_type_aov %||% "none"), " # <DAVA-UI-PARAM>\n",
    "multiplicity_adjustment <- ", r_literal(input$adjust_method_aov %||% "none"), " # <DAVA-UI-PARAM>\n",
    "significance_alpha <- ", r_literal(suppressWarnings(as.numeric(input$significance_alpha_aov %||% 0.05))), " # <DAVA-UI-PARAM>\n",
    "plot_theme <- ", r_literal(input$plot_theme_aov %||% "publication"), " # <DAVA-UI-PARAM>\n",
    "plot_palette <- ", r_literal(palette), " # <DAVA-UI-PARAM>\n",
    "plot_colors <- ", r_literal(colors), " # <DAVA-UI-PARAM>\n",
    "plot_base_size <- ", r_literal(input$plot_base_size_aov %||% 14), " # <DAVA-UI-PARAM>\n",
    "plot_x_angle <- ", r_literal(input$plot_x_angle_aov %||% 35), " # <DAVA-UI-PARAM>\n",
    "plot_show_legend <- ", r_literal(isTRUE(input$plot_show_legend_aov)), " # <DAVA-UI-PARAM>\n",
    "plot_legend_position <- ", r_literal(input$plot_legend_position_aov %||% "right"), " # <DAVA-UI-PARAM>\n",
    "plot_title <- ", r_literal(trimws(input$plot_title_aov %||% "")), " # <DAVA-UI-PARAM>\n",
    "plot_x_label <- ", r_literal(trimws(input$plot_x_label_aov %||% "")), " # <DAVA-UI-PARAM>\n",
    "plot_y_label <- ", r_literal(trimws(input$plot_y_label_aov %||% "")), " # <DAVA-UI-PARAM>\n",
    "plot_y_limits <- ", r_literal(c(numeric_limit(input$plot_y_min_aov), numeric_limit(input$plot_y_max_aov))), " # <DAVA-UI-PARAM>\n",
    "plot_flip <- ", r_literal(isTRUE(input$plot_flip_coord_aov)), " # <DAVA-UI-PARAM>\n",
    "layout_rows <- ", rows, "L; layout_cols <- ", cols, "L # <DAVA-UI-PARAM>\n"
  )

  plot_code <- paste0(
    "posthoc <- data.frame(); letters <- data.frame()\n",
    "if (nzchar(plot_x) && plot_x %in% names(df) && requireNamespace('emmeans', quietly = TRUE)) {\n",
    "  for (y in intersect(plot_responses, names(models))) {\n",
    "    comparison <- tryCatch({\n",
    "      emm <- emmeans::emmeans(models[[y]], specs = plot_x)\n",
    "      pair <- as.data.frame(emmeans::contrast(emm, method = 'pairwise', adjust = multiplicity_adjustment)); pair$response <- y; pair$term <- plot_x\n",
    "      cld <- if (requireNamespace('multcomp', quietly = TRUE)) as.data.frame(multcomp::cld(emm, alpha = significance_alpha, adjust = multiplicity_adjustment, Letters = base::letters)) else data.frame()\n",
    "      if (nrow(cld)) { names(cld)[names(cld) == '.group'] <- 'letter'; cld$response <- y; cld$term <- plot_x; cld$letter <- trimws(cld$letter) }\n",
    "      list(pair = pair, cld = cld)\n",
    "    }, error = function(e) list(pair = data.frame(), cld = data.frame()))\n",
    "    posthoc <- dplyr::bind_rows(posthoc, comparison$pair); letters <- dplyr::bind_rows(letters, comparison$cld)\n",
    "  }\n",
    "}\n",
    "plots <- list()\n",
    "for (y in plot_responses) {\n",
    "  if (!y %in% names(df) || !plot_x %in% names(df)) next\n",
    "  required <- unique(c(y, plot_x, plot_group, plot_facet)); required <- required[nzchar(required) & required %in% names(df)]\n",
    "  plot_data <- droplevels(df[stats::complete.cases(df[, required, drop = FALSE]) & is.finite(df[[y]]), , drop = FALSE])\n",
    "  grouping <- unique(c(plot_x, plot_group, plot_facet)); grouping <- grouping[nzchar(grouping) & grouping %in% names(plot_data)]\n",
    "  summary_df <- dplyr::summarise(dplyr::group_by(plot_data, dplyr::across(dplyr::all_of(grouping))), mean = mean(.data[[y]], na.rm = TRUE), se = stats::sd(.data[[y]], na.rm = TRUE) / sqrt(sum(!is.na(.data[[y]]))), .groups = 'drop')\n",
    "  has_group <- nzchar(plot_group) && plot_group %in% names(plot_data); dodge <- ggplot2::position_dodge(width = 0.78)\n",
    "  if (plot_type %in% c('boxplot', 'box')) {\n",
    "    if (has_group) p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data[[plot_x]], y = .data[[y]], fill = .data[[plot_group]])) + ggplot2::geom_boxplot(width = 0.65, alpha = 0.75, position = dodge, outlier.shape = NA) + ggplot2::geom_point(position = ggplot2::position_jitterdodge(jitter.width = 0.08, dodge.width = 0.78), alpha = 0.45)\n",
    "    else p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data[[plot_x]], y = .data[[y]], fill = .data[[plot_x]])) + ggplot2::geom_boxplot(width = 0.65, alpha = 0.75, outlier.shape = NA) + ggplot2::geom_jitter(width = 0.12, alpha = 0.45)\n",
    "  } else if (plot_type %in% c('violin', 'violinplot')) {\n",
    "    if (has_group) p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data[[plot_x]], y = .data[[y]], fill = .data[[plot_group]])) + ggplot2::geom_violin(alpha = 0.65, trim = FALSE, position = dodge) + ggplot2::geom_boxplot(width = 0.15, alpha = 0.85, position = dodge, outlier.shape = NA)\n",
    "    else p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data[[plot_x]], y = .data[[y]], fill = .data[[plot_x]])) + ggplot2::geom_violin(alpha = 0.65, trim = FALSE) + ggplot2::geom_boxplot(width = 0.18, alpha = 0.85, outlier.shape = NA) + ggplot2::geom_jitter(width = 0.1, alpha = 0.45)\n",
    "  } else if (plot_type %in% c('bar', 'barplot')) {\n",
    "    if (has_group) p <- ggplot2::ggplot(summary_df, ggplot2::aes(x = .data[[plot_x]], y = .data[['mean']], fill = .data[[plot_group]])) + ggplot2::geom_col(width = 0.65, alpha = 0.85, position = dodge) + ggplot2::geom_errorbar(ggplot2::aes(ymin = .data[['mean']] - .data[['se']], ymax = .data[['mean']] + .data[['se']]), width = 0.18, position = dodge)\n",
    "    else p <- ggplot2::ggplot(summary_df, ggplot2::aes(x = .data[[plot_x]], y = .data[['mean']], fill = .data[[plot_x]])) + ggplot2::geom_col(width = 0.65, alpha = 0.85) + ggplot2::geom_errorbar(ggplot2::aes(ymin = .data[['mean']] - .data[['se']], ymax = .data[['mean']] + .data[['se']]), width = 0.18)\n",
    "  } else {\n",
    "    if (has_group) p <- ggplot2::ggplot(summary_df, ggplot2::aes(x = .data[[plot_x]], y = .data[['mean']], group = .data[[plot_group]], colour = .data[[plot_group]])) + ggplot2::geom_point(size = 3, position = dodge) + ggplot2::geom_line(linewidth = 1, position = dodge) + ggplot2::geom_errorbar(ggplot2::aes(ymin = .data[['mean']] - .data[['se']], ymax = .data[['mean']] + .data[['se']]), width = 0.15, position = dodge)\n",
    "    else p <- ggplot2::ggplot(summary_df, ggplot2::aes(x = .data[[plot_x]], y = .data[['mean']], group = 1)) + ggplot2::geom_point(size = 4) + ggplot2::geom_line(linewidth = 1) + ggplot2::geom_errorbar(ggplot2::aes(ymin = .data[['mean']] - .data[['se']], ymax = .data[['mean']] + .data[['se']]), width = 0.15)\n",
    "  }\n",
    "  if (nzchar(plot_facet) && plot_facet %in% names(plot_data)) p <- p + ggplot2::facet_wrap(stats::as.formula(paste('~', plot_facet)))\n",
    "  mapped_legend <- if (has_group) plot_group else plot_x\n",
    "  if (!plot_type %in% c('line', 'lineplot')) p <- p + ggplot2::scale_fill_manual(values = plot_colors, name = mapped_legend)\n",
    "  if (plot_type %in% c('line', 'lineplot') && has_group) p <- p + ggplot2::scale_colour_manual(values = plot_colors, name = mapped_legend)\n",
    "  theme_base <- switch(plot_theme, classic = ggplot2::theme_classic(base_size = plot_base_size), minimal = ggplot2::theme_minimal(base_size = plot_base_size), clean = ggplot2::theme_minimal(base_size = plot_base_size), nature = ggplot2::theme_classic(base_size = plot_base_size), cell = ggplot2::theme_classic(base_size = plot_base_size), lancet = ggplot2::theme_classic(base_size = plot_base_size), prism = ggplot2::theme_classic(base_size = plot_base_size), pnas = ggplot2::theme_minimal(base_size = plot_base_size), dark = ggplot2::theme_minimal(base_size = plot_base_size), ggplot2::theme_bw(base_size = plot_base_size))\n",
    "  p <- p + theme_base + ggplot2::theme(plot.title = ggplot2::element_text(face = 'bold', hjust = 0, size = plot_base_size + 2), panel.grid.minor = ggplot2::element_blank(), legend.position = if (plot_show_legend) plot_legend_position else 'none', plot.margin = ggplot2::margin(20, 25, 35, 15), axis.text.x = ggplot2::element_text(angle = plot_x_angle, hjust = if (plot_x_angle == 0) 0.5 else 1)) + ggplot2::labs(x = if (nzchar(plot_x_label)) plot_x_label else plot_x, y = if (nzchar(plot_y_label)) plot_y_label else y, title = if (nzchar(plot_title)) plot_title else paste('Effect plot for', y))\n",
    "  y_range <- range(plot_data[[y]], na.rm = TRUE); y_span <- diff(y_range); if (!is.finite(y_span) || y_span == 0) y_span <- abs(y_range[1]) + 1\n",
    "  lower <- if (is.finite(plot_y_limits[1])) plot_y_limits[1] else y_range[1] - 0.08 * y_span; upper <- if (is.finite(plot_y_limits[2])) plot_y_limits[2] else y_range[2] + 0.28 * y_span\n",
    "  letter_data <- letters[letters$response == y & letters$term == plot_x, , drop = FALSE]\n",
    "  if (significance_display %in% c('auto', 'cld_lower', 'cld_upper', 'omnibus_cld', 'summary_cld') && nrow(letter_data) && plot_x %in% names(letter_data)) { letter_data$label <- if (identical(significance_display, 'cld_upper')) toupper(letter_data$letter) else letter_data$letter; letter_data$label_y <- upper - 0.04 * y_span; p <- p + ggplot2::geom_text(data = letter_data, ggplot2::aes(x = .data[[plot_x]], y = .data[['label_y']], label = .data[['label']]), inherit.aes = FALSE, size = 5) }\n",
    "  p <- if (plot_flip) p + ggplot2::coord_flip(ylim = c(lower, upper), clip = 'on') else p + ggplot2::coord_cartesian(ylim = c(lower, upper), clip = 'on')\n",
    "  plots[[y]] <- p\n",
    "}\n",
    "plot_capacity <- max(1L, layout_rows * layout_cols); plot_chunks <- if (length(plots)) split(plots, ceiling(seq_along(plots) / plot_capacity)) else list()\n",
    "plot_pages <- lapply(plot_chunks, function(chunk) { if (length(chunk) == 1L) chunk[[1]] else { if (!requireNamespace('patchwork', quietly = TRUE)) stop('Multiple-response plotting requires the patchwork package.'); patchwork::wrap_plots(chunk, nrow = layout_rows, ncol = layout_cols, guides = 'collect') & ggplot2::theme(legend.position = if (plot_show_legend) plot_legend_position else 'none') } })\n",
    "p <- if (length(plot_pages)) plot_pages[[1]] else NULL\n",
    "analysis_output <- list(result = result, summary = model_table, models = models, formulas = formula_text, model_text = model_text, posthoc = posthoc, letters = letters, plots = plots, plot_pages = plot_pages, plot = p)\n",
    "result <- analysis_output\nresult\n"
  )
  paste0(model_code, plot_parameters, plot_code)
}

dava_norm_variance_custom_result <- function(run) {
  dava_custom_run_assert(run)
  value <- dava_custom_run_list(run, required = "result")
  if (is.null(value) || !is.data.frame(value$result %||% NULL)) {
    stop("Custom normality tests must return the data frame result.", call. = FALSE)
  }
  result <- value$result
  qq_data <- dava_custom_run_table(run, "qq_data") %||% data.frame()
  formulas <- if (all(c("response", "model") %in% names(result))) {
    unique(result[c("response", "model")]) |>
      stats::setNames(c("response", "formula"))
  } else data.frame(response = character(), formula = character())
  list(
    normality = result,
    variance = value$variance %||% data.frame(),
    model_summary = value$summary %||% result,
    qq_data = qq_data,
    errors = value$errors %||% data.frame(),
    formulas = value$formulas %||% formulas,
    custom_plot = dava_custom_run_plot(run)
  )
}

dava_anova_custom_result <- function(run, data) {
  dava_custom_run_assert(run)
  value <- dava_custom_run_list(run, required = "result")
  if (is.null(value) || !is.data.frame(value$result %||% NULL)) {
    stop("Custom ANOVA must return the data frame result.", call. = FALSE)
  }
  summary <- value$summary %||% data.frame()
  if (!is.data.frame(summary)) summary <- data.frame()
  list(
    transform_df = data, formulas = value$formulas %||% data.frame(),
    data_summary = summary, models = list(), model_status = data.frame(),
    anova_table = value$result, model_table = data.frame(),
    significance_results = list(), comparison_strategy = data.frame(),
    emmeans = data.frame(), annotations = data.frame(),
    posthoc = value$posthoc %||% data.frame(),
    letters = value$letters %||% data.frame(), terms = list(),
    errors = value$errors %||% data.frame(),
    custom_plot = dava_custom_run_plot(run)
  )
}

#----------------------------------------------------------------------------------------
# Normality-Homogeneity of Variances Test-UI
#----------------------------------------------------------------------------------------
mod_norm_variance_ui <- function(id) {
  ns <- NS(id)
  card(
    card_header(h4("Normality-Homogeneity of Variances Test", style = "margin: 0;")),
    
    layout_sidebar(
      sidebar = sidebar(
        width = 285,
        tagList(
          tags$div(
            class = "stat-box",
            tags$strong("Dataset selection"),
            uiOutput(ns("dataset_select")),
            tags$hr(),
            tags$strong("Variable selection"),
            uiOutput(ns("response_var")),
            uiOutput(ns("fixed_var")),
            tags$div(class = "small-muted", "The response variable must be numeric; fixed factors are used for group homogeneity of variance testing.")
          ),
          
          tags$div(
            class = "stat-box",
            tags$strong("Analysis model"),
            selectInput(
              ns("model_family"),
              "Analysis model type",
              choices = c("Analysis of Variance ANOVA" = "ANOVA", "Linear Mixed Effects Model LMM" = "LMM"),
              selected = "ANOVA"
            ),
            
            selectInput(
              ns("factor_n"),
              "Fixed effects model",
              choices = c("Single factor", "Two factors", "Three factors", "Four factors"),
              selected = "Single factor"
            ),
            
            conditionalPanel(
              condition = "input.model_family == 'LMM'",    
              ns = ns,           #Shiny in module conditionalPanel() Cannot find namespace by default input ID。
              uiOutput(ns("random_candidate_var")),
              selectInput(
                ns("random_type"),
                "Random effects structure",
                choices = c("Random intercept", "Random slope", "Nested random", "Crossover random"),
                selected = "Random intercept"
              ),
              uiOutput(ns("random_structure_ui"))
            )
          ),
          
          tags$div(
            class = "stat-box",
            tags$strong("Normality-homogeneity of variance test method"),
            selectInput(
              ns("norm_method"),
              "Normality test method",
              c("Shapiro-Wilk", "Kolmogorov-Smirnov", "Anderson-Darling"),
              selected = "Shapiro-Wilk",
              multiple = FALSE
            ),
            selectInput(
              ns("vari_method"),
              "Homogeneity of variance test method",
              c("Bartlett", "Levene", "Fligner-Killeen"),
              selected = "Levene",
              multiple = FALSE
            )
          ),
          
          tags$div(
            class = "stat-box",
            tags$strong("Data transformation"),
            selectInput(
              ns("data_transform"),
              "Data transformation method",
              choices = c("none", "log", "square root", "reciprocal", "arcsine","box-cox"),
              selected = "none",
              multiple = FALSE
            )
          ),
          
          tags$div(
            class = "stat-box",
            actionButton(ns("norm_vari_run"), "Run batch inspection", class = "btn-primary w-100")
          ),
          
          br(), br(),
          actionButton(ns("register_norm_results"), "Add to data table repository", icon = icon("plus"),
            title = "Add to data table repository", class = "btn-success w-100 mb-2"),
          downloadButton(ns("download_norm_vari_results"), "Download analysis results table", icon = icon("download"), class = "btn-success w-100")
        )
      ),
      
      navset_card_tab(
        nav_panel("Data preview", DTOutput(ns("raw_data_preview"))),
        nav_panel("Transform data preview", DTOutput(ns("trans_data_preview"))),
        nav_panel("Model formula", DTOutput(ns("formula_table"))),
        nav_panel("Normality test", DTOutput(ns("normality_table"))),
        nav_panel("Test for homogeneity of variances", DTOutput(ns("variance_table"))),
        nav_panel("Model results", DTOutput(ns("model_table"))),
        nav_panel("QQ plot/residual-fitted value plot", uiOutput(ns("norm_plot_panel"))),
        nav_panel("Errors", DTOutput(ns("error_table"))),
        nav_panel("Model text", verbatimTextOutput(ns("model_text"))),
        nav_panel("R Markdown code document", dava_module_code_panel_ui(ns))
      )
    )


  )
}

#----------------------------------------------------------------------------------------
# Normality-Homogeneity of Variances Test-server
#----------------------------------------------------------------------------------------
mod_norm_variance_server <-function(id, file_data, active_nav = reactive(NULL)) {
  moduleServer(id, function(input, output, session) {
    root_input <- session$rootScope()$input
    interface_language <- reactive({
      root_input$dava_interface_language
      dava_i18n_language(root_input$dava_interface_language)
    })
    plot_runtime_diagnostics <- reactiveVal(character())
    record_plot_runtime_diagnostics <- function(captured, source = "Normality plot") {
      entries <- dava_plot_condition_text(captured, source)
      if (!length(entries)) return(invisible(NULL))
      plot_runtime_diagnostics(unique(c(shiny::isolate(plot_runtime_diagnostics()), entries)))
      invisible(entries)
    }
    
    rv<-reactiveValues(
      result_datasets=list(),
      raw_df = NULL
    )
    
    #--SimulationData----
    demo_data <- reactive({
      demo_data_set()
    })
    
    ##----------------- NormalityandTest for homogeneity of variancesPanel---------
    
    output$dataset_select <- renderUI({
      
      ds_names <- dava_global_dataset_names(file_data)
      if (is.null(ds_names) || length(ds_names) == 0) {
        selectInput(
          session$ns("dataset_select_input"),
          "Dataset selection",
          choices = c("Simulation data demo_data" = "__demo__"),
          selected = "__demo__",
          multiple = FALSE
        )
      } else {
        selectInput(
          session$ns("dataset_select_input"),
          "Dataset selection",
          choices = c("Simulation data demo_data" = "__demo__", ds_names),
          selected = "__demo__",
          multiple = FALSE
        )
      }
      
    })
    
    raw_df_stat1 <- reactive({
      selected <- input$dataset_select_input %||% "__demo__"
      if (identical(selected, "__demo__")) {
        return(demo_data())
      }
      
      req(file_data$global_datasets)
      validate(
        need(selected %in% dava_global_dataset_names(file_data), "The selected data set does not exist.")
      )
      
      file_data$global_datasets[[selected]]
    })

    dava_module_code_panel_server(
      input, output, session, file_data,
      source_prefix = function() "statistics/normality-homogeneity of variance test",
      default_code = function() norm_variance_code_template(input, workspace_data = TRUE),
      source = "Statistical analysis",
      title = "Complete code for normality-homogeneity of variance test",
      kind = "analysis",
      validate_run = dava_norm_variance_custom_result,
      plot_params = function() dava_code_plot_params_from_input(input),
      data = function() raw_df_stat1(),
      dataset_name = function() input$dataset_select_input %||% "__demo__",
      function_mode = "none",
      standalone_bootstrap = FALSE,
      include_input_snapshot = FALSE,
      preview_result = function() analysis_results(),
      preview_plots = function() {
        value <- analysis_results()
        response <- input$qq_response %||% unique(value$qq_data$response)[1]
        kind <- input$norm_plot_name %||% "qq"
        stats::setNames(list(dava_norm_plot_object(value$qq_data, response, kind, input)),
          if (identical(kind, "qq")) "Q-Q diagnostic plot" else "Residuals versus fitted plot")
      }
    )


    output$response_var <- renderUI({
      req(raw_df_stat1())
      nums <- numeric_vars(raw_df_stat1())
      pickerInput(
        session$ns("response_var_input"),
        "Response variable, multiple selections possible",
        choices = nums,
        selected = nums[1],
        multiple = TRUE,
        options = list(`actions-box` = TRUE,`live-search` = TRUE)
      )
    })
    
    output$fixed_var <- renderUI({
      req(raw_df_stat1(), input$response_var_input)
      vars <- setdiff(names(raw_df_stat1()), input$response_var_input %||% character(0))
      pickerInput(
        session$ns("fixed_var_input"),
        "Fixed effects/grouping variables, multiple selections possible",             #use “/”will not be escaped by default，instead of using“\”will be escaped by default，causes an error
        choices = vars,
        selected = vars[1] %||% NULL,
        multiple = TRUE,
        options = list(`live-search` = TRUE, `actions-box` = TRUE)
      )
    })
    
    output$random_candidate_var <- renderUI({
      req(raw_df_stat1())
      vars <- setdiff(names(raw_df_stat1()), input$response_var_input %||% character(0))
      pickerInput(
        session$ns("random_vars_all"),
        "Random effects candidate variables",
        choices = vars,
        selected = vars[1],
        multiple = TRUE,
        options = list(`actions-box` = TRUE, `live-search` = TRUE)
      )
    })
    
    output$random_structure_ui <- renderUI({
      req(raw_df_stat1(),input$response_var_input)
      vars <- input$random_vars_all %||% setdiff(names(raw_df_stat1()), input$response_var_input %||% character(0))
      if (length(vars) == 0) vars <- setdiff(names(raw_df_stat1()), input$response_var_input %||% character(0))
      
      tagList(
        conditionalPanel(
          condition = "input.random_type == 'Random intercept'",
          ns = session$ns,                    #Shiny in module conditionalPanel() Cannot find namespace by default input ID。
          selectInput(session$ns("random_intercept"), "Random intercept grouping variable", choices = vars)
        ),
        conditionalPanel(
          condition = "input.random_type == 'Random slope'",
          ns = session$ns,
          selectInput(session$ns("random_intercept_slope_group"), "Random slope grouping variable", choices = vars),
          selectInput(session$ns("random_slope"), "Random slope variable", choices = input$fixed_var_input %||% vars)
        ),
        conditionalPanel(
          condition = "input.random_type == 'Nested random'",
          ns = session$ns,
          shinyWidgets::pickerInput(
            session$ns("random_nested"),
            "Nested random variables, the order is upper level / lower level",
            choices = vars,
            multiple = TRUE,
            options = list(`actions-box` = TRUE, `live-search` = TRUE)
          )
        ),
        conditionalPanel(
          condition = "input.random_type == 'Cross random'",
          ns = session$ns,
          shinyWidgets::pickerInput(
            session$ns("random_crossed"),
            "Crossed random variables",
            choices = vars,
            multiple = TRUE,
            options = list(`actions-box` = TRUE, `live-search` = TRUE)
          )
        )
      )
    })
    
    
    transform_df <- reactive({
      req(raw_df_stat1(), input$response_var_input, input$data_transform)
      transform_as_df(data = raw_df_stat1(), response = input$response_var_input, 
                      response_trans_vars = input$response_var_input, trans_method = input$data_transform)
    })
    
    
    original_analysis_results <- eventReactive(input$norm_vari_run, {
      req(transform_df(), input$response_var_input, input$fixed_var_input, input$norm_method, input$vari_method, input$data_transform)
      progress <- shiny::Progress$new(session, min = 0, max = 1)
      on.exit(progress$close(), add = TRUE)
      progress$set(
        message = paste("Run", input$norm_method, "and", input$vari_method),
        detail = "\u51c6\u5907\u53d8\u91cf\u4e0e\u53d8\u6362\u6570\u636e",
        value = 0.1
      )
      
      norm_test <- input$norm_method  %||% "Shapiro-Wilk"
      vari_test <- input$vari_method  %||% "Levene"
      
      df <- transform_df()
      
      random_intercept <- character(0)
      random_slope <- character(0)
      random_nested <- character(0)
      random_crossed <- character(0)
      
      if (input$model_family == "LMM") {
        if (input$random_type == "Random intercept") {
          random_intercept <- input$random_intercept %||% character(0)
        } else if (input$random_type == "Random slope") {
          random_intercept <- input$random_intercept_slope_group %||% character(0)
          random_slope <- input$random_slope %||% character(0)
        } else if (input$random_type == "Nested random") {
          random_nested <- input$random_nested %||% character(0)
        } else if (input$random_type == "Crossover random") {
          random_crossed <- input$random_crossed %||% character(0)
        }
      }
      
      results <- list()
      errors <- list()
      progress$set(detail = "\u9010\u4e00\u8fd0\u884c\u54cd\u5e94\u53d8\u91cf\u8bca\u65ad", value = 0.3)
      
      for (resp in input$response_var_input) {
        one <- tryCatch({
          diagnose_one_response(
            df = df,
            response = resp,
            fixed_vars = input$fixed_var_input,
            model_family = input$model_family,
            factor_n = input$factor_n,
            random_type = input$random_type %||% "Random intercept",
            random_intercept = random_intercept,
            random_slope = random_slope,
            random_nested = random_nested,
            random_crossed = random_crossed,
            subject = character(0),
            within_factors = character(0),
            between_factors = NULL,
            block = character(0),
            covariates = character(0),
            norm_test = norm_test,
            vari_test = vari_test,
            distribution_family = NULL
          )
        }, error = function(e) e)
        
        if (inherits(one, "error")) {
          errors[[resp]] <- data.frame(response = resp, error = one$message)
        } else {
          results[[resp]] <- one
        }
      }
      
      # Extract and combine the normality result from every response model.
      normality <- dplyr::bind_rows(lapply(results, `[[`, "normality"))
      variance <- dplyr::bind_rows(lapply(results, `[[`, "variance"))
      model_summary <- dplyr::bind_rows(lapply(results, `[[`, "model_summary"))
      qq_data <- dplyr::bind_rows(lapply(results, `[[`, "qq_data"))
      errors_df <- dplyr::bind_rows(errors)
      
      formulas <- if (length(results) > 0) {
        data.frame(
          response = names(results),
          formula = vapply(results, function(x) deparse(x$fit$formula), character(1))
        )
      } else {
        data.frame(response = character(), formula = character())
      }
      progress$set(detail = "\u6574\u7406\u68c0\u9a8c\u7ed3\u679c\u4e0e\u8bca\u65ad\u6570\u636e", value = 0.85)
      
      rv$result_datasets<-list(
        raw_df = raw_df_stat1(),
        transform_df = transform_df(),
        normality = normality,
        variance = variance,
        model_summary = model_summary,
        qq_data = qq_data,
        errors = errors_df,
        formulas = formulas
      )
      
      list(
        normality = normality,
        variance = variance,
        model_summary = model_summary,
        qq_data = qq_data,
        errors = errors_df,
        formulas = formulas
      )
    })
    
    custom_analysis_run <- eventReactive(list(
      input$norm_vari_run, file_data$method_code_revision
    ), {
      method_key <- "statistics/normality-homogeneity of variance test"
      entry <- dava_method_code_get(file_data, method_key)
      if (is.null(entry) || !isTRUE(entry$enabled)) return(NULL)
      dava_method_code_execute(file_data, method_key,
        data = raw_df_stat1(),
        dataset_name = input$dataset_select_input %||% "__demo__",
        spec = dava_code_analysis_spec_from_input(input))
    }, ignoreInit = TRUE)

    analysis_results <- reactive({
      method_key <- "statistics/normality-homogeneity of variance test"
      dava_method_code_effective(
        original = function() original_analysis_results(),
        file_data = file_data, method_key = method_key,
        adapter = function(run, entry) dava_norm_variance_custom_result(
          custom_analysis_run()),
        on_error = function(message) {
          dava_record_runtime_condition("warning", paste0(
            "The user-defined normality test failed and the original method has been rolled back: ",
            message), "Statistical method: normality-homogeneity")
          original_analysis_results()
        }
      )
    })
    observeEvent(input$register_norm_results, {
      value <- analysis_results(); req(value)
      tables <- Filter(function(x) is.data.frame(x) || is.matrix(x), list(
        formulas = value$formulas, normality = value$normality,
        variance = value$variance, model_summary = value$model_summary,
        errors = value$errors
      ))
      registered <- dava_register_global_datasets(file_data, tables,
        source = "Statistical Analysis / Normality-Homogeneity of Variances Test", prefix = "norm_variance")
      showNotification(paste0("has been added to the data table warehouse:", paste(unname(registered), collapse = "、")), type = "message", duration = 3)
    }, ignoreInit = TRUE)

    #------------Resultsoutput-------------  
    output$raw_data_preview <- renderDT({
      req(raw_df_stat1())
      datatable(
        raw_df_stat1(),
        rownames = TRUE,
        filter = "top",
        options = list(scrollX = TRUE, pageLength = 20)
      )
    })
    
    output$trans_data_preview <- renderDT({
      req(transform_df())
      datatable(
        transform_df(),
        rownames = TRUE,
        filter = "top",
        options = list(scrollX = TRUE, pageLength = 20)
      )
    })
    
    output$formula_table <- renderDT({
      req(analysis_results())
      datatable(analysis_results()$formulas, rownames = FALSE, options = list(scrollX = TRUE))
    })
    
    output$normality_table <- renderDT({
      req(analysis_results())
      dat <- analysis_results()$normality
      if (is.null(dat) || nrow(dat) == 0 || !"statistic" %in% names(dat)) {
        return(datatable(
          data.frame(message = "Normality test has no valid results, please see the Error Messages table."),
          rownames = FALSE
        ))
      }
      dt <- datatable(
        dat,
        rownames = FALSE,
        filter = "top",
        options = list(scrollX = TRUE, pageLength = 25)
      )
      round_cols <- intersect(c("statistic", "p_value"), names(dat))
      if (length(round_cols) > 0) {
        dt <- formatRound(dt, columns = round_cols, digits = 4)
      }
      dt
    })
    
    output$variance_table <- renderDT({
      req(analysis_results())
      dat <- analysis_results()$variance
      if (is.null(dat) || nrow(dat) == 0 || !"statistic" %in% names(dat)) {
        return(datatable(
          data.frame(message = "Test for homogeneity of variances has no valid results, please see the Error Message table."),
          rownames = FALSE
        ))
      }
      dt <- datatable(
        dat,
        rownames = FALSE,
        filter = "top",
        options = list(scrollX = TRUE, pageLength = 25)
      )
      round_cols <- intersect(c("statistic", "p_value"), names(dat))
      if (length(round_cols) > 0) {
        dt <- formatRound(dt, columns = round_cols, digits = 4)
      }
      dt
    })
    
    output$model_table <- renderDT({
      req(analysis_results())
      datatable(
        analysis_results()$model_summary,
        rownames = FALSE,
        filter = "top",
        options = list(scrollX = TRUE, pageLength = 25)
      )
    })

    output$model_text <- renderText({
      value <- analysis_results()
      req(value)
      formulas <- value$formulas %||% data.frame()
      formula_text <- if (is.data.frame(formulas) && nrow(formulas)) {
        paste(paste0(formulas$response, ": ", formulas$formula), collapse = "\n")
      } else "Model formula not generated."
      text <- paste(
        "Model used for normality and homogeneity of variance tests",
        formula_text,
        "",
        paste(capture.output(print(value$model_summary)), collapse = "\n"),
        sep = "\n"
      )
      dava_localize_model_text(
        text, interface_language(), dava_user_data_text(raw_df_stat1())
      )
    })
    
    output$error_table <- renderDT({
      req(analysis_results())
      errors <- dava_append_diagnostic_rows(
        analysis_results()$errors,
        c(plot_runtime_diagnostics(), dava_runtime_diagnostic_lines()),
        source = "Plot rendering")
      datatable(
        dava_localize_message_table(
          errors, interface_language(),
          dava_user_data_text(raw_df_stat1())
        ),
        rownames = FALSE,
        options = list(scrollX = TRUE, pageLength = 25)
      )
    })
    
    output$qq_resid_response <- renderUI({
      req(analysis_results())
      resps <- unique(analysis_results()$qq_data$response)
      selectInput(session$ns("qq_response"), "Select response variable", choices = resps, selected = resps[1])
    })
    output$norm_plot_panel <- renderUI({
      bslib::layout_sidebar(
        sidebar = bslib::sidebar(width = 300, position = "right",
          shiny::conditionalPanel(
            condition = sprintf("input['%s'] === 'qq'", session$ns("norm_plot_name")),
            shiny::tagList(
              dava_plot_action_buttons_ui(
                session$ns, "add_qq_plot_to_library", "download_qq_plot_png", "download_qq_plot_pdf"
              ),
              dava_result_plot_settings_ui(session$ns, dava_norm_plot_settings_prefix("qq"),
                dava_translate_composed("Graphic properties: QQ graph", interface_language()))
            )
          ),
          shiny::conditionalPanel(
            condition = sprintf("input['%s'] === 'resid'", session$ns("norm_plot_name")),
            shiny::tagList(
              dava_plot_action_buttons_ui(
                session$ns, "add_resid_plot_to_library", "download_resid_plot_png", "download_resid_plot_pdf"
              ),
              dava_result_plot_settings_ui(session$ns, dava_norm_plot_settings_prefix("resid"),
                dava_translate_composed("Graph Properties: Residuals-Fitted Values Plot", interface_language()))
            )
          )),
        shiny::tagList(
          shiny::uiOutput(session$ns("qq_resid_response")),
          shiny::selectInput(session$ns("norm_plot_name"), "Result graph",
            c("QQ picture" = "qq", "Residuals-fitted value plot" = "resid"), selected = "qq"),
          shiny::plotOutput(session$ns("norm_plot_selected"), height = 620)
        )
      )
    })
    
    qq_plot_dimensions <- dava_plot_size_server(input, output, session, "qq_plot", "qq_plot_size", 720, 624)
    resid_plot_dimensions <- dava_plot_size_server(input, output, session, "resid_plot", "resid_plot_size", 720, 624)

    output$qq_plot <- renderPlot({
      captured <- dava_capture_conditions({
        req(analysis_results(), input$qq_response)
        p <- analysis_results()$custom_plot %||%
          dava_norm_qq_plot(analysis_results()$qq_data, input$qq_response)
        validate(need(!is.null(p), "There is currently no QQ map to draw."))
        print(p)
      }, source = "Normality QQ plot")
      record_plot_runtime_diagnostics(captured, "Normality QQ plot")
      if (nzchar(captured$error %||% "")) dava_plot_diagnostic_placeholder(captured$error)
      invisible(captured$value)
    })
    
    output$resid_plot <- renderPlot({
      captured <- dava_capture_conditions({
        req(analysis_results(), input$qq_response)
        p <- analysis_results()$custom_plot %||%
          dava_norm_resid_plot(analysis_results()$qq_data, input$qq_response)
        validate(need(!is.null(p), "There is currently no residual plot to draw."))
        print(p)
      }, source = "Normality residual plot")
      record_plot_runtime_diagnostics(captured, "Normality residual plot")
      if (nzchar(captured$error %||% "")) dava_plot_diagnostic_placeholder(captured$error)
      invisible(captured$value)
    })
    output$norm_plot_selected <- renderPlot({
      captured <- dava_capture_conditions({
        req(analysis_results(), input$qq_response)
        kind <- input$norm_plot_name %||% "qq"
        p <- analysis_results()$custom_plot %||%
          dava_norm_plot_object(analysis_results()$qq_data, input$qq_response, kind, input)
        validate(need(!is.null(p), "There is no result graph available yet."))
        print(p)
      }, source = "Normality selected plot")
      record_plot_runtime_diagnostics(captured, "Normality selected plot")
      if (nzchar(captured$error %||% "")) dava_plot_diagnostic_placeholder(captured$error)
      invisible(captured$value)
    })

    add_norm_plot_to_library <- function(kind = c("qq", "resid")) {
      kind <- match.arg(kind)
      req(analysis_results(), input$qq_response)
      p <- analysis_results()$custom_plot %||%
        dava_norm_plot_object(analysis_results()$qq_data, input$qq_response, kind, input)
      label <- if (identical(kind, "qq")) "QQ picture" else "Residuals-fitted value plot"
      validate(need(!is.null(p), paste0("Nothing to add yet", label, "。")))
      dims <- if (identical(kind, "qq")) qq_plot_dimensions() else resid_plot_dimensions()
      ok <- dava_plot_register(
        file_data,
        paste("norm_variance", kind, input$qq_response %||% "plot", sep = "/"),
        p,
        source = "Normality and Homogeneity of Variances Test",
        title = paste(label, input$qq_response %||% "plot"),
        meta = list(module = "norm_variance", plot_kind = kind, response = input$qq_response %||% "", added_by = "manual"),
        params = c(list(module = "norm_variance", plot_kind = kind, width_px = dims$width_px, height_px = dims$height_px), dava_plot_input_params(input)),
        editor_svg = dava_plot_editor_svg_sized(p, dims)
      )
      showNotification(if (isTRUE(ok)) paste0(label, "has been added to the layout beautification library.") else "Add failed: The current drawing is not a registrable object.", type = if (isTRUE(ok)) "message" else "error", duration = 3)
    }

    observeEvent(input$add_qq_plot_to_library, {
      add_norm_plot_to_library("qq")
    })

    observeEvent(input$add_resid_plot_to_library, {
      add_norm_plot_to_library("resid")
    })

    norm_plot_for_download <- function(kind = c("qq", "resid")) {
      kind <- match.arg(kind)
      req(analysis_results(), input$qq_response)
      analysis_results()$custom_plot %||%
        dava_norm_plot_object(analysis_results()$qq_data, input$qq_response, kind, input)
    }
    output$download_qq_plot_png <- downloadHandler(
      filename = function() sprintf("qq_%s_%s.png", input$qq_response %||% "plot", Sys.Date()),
      content = function(file) dava_save_sized_plot(file, norm_plot_for_download("qq"), "png", qq_plot_dimensions(), 300)
    )
    output$download_qq_plot_pdf <- downloadHandler(
      filename = function() sprintf("qq_%s_%s.pdf", input$qq_response %||% "plot", Sys.Date()),
      content = function(file) dava_save_sized_plot(file, norm_plot_for_download("qq"), "pdf", qq_plot_dimensions(), 300)
    )
    output$download_resid_plot_png <- downloadHandler(
      filename = function() sprintf("residual_%s_%s.png", input$qq_response %||% "plot", Sys.Date()),
      content = function(file) dava_save_sized_plot(file, norm_plot_for_download("resid"), "png", resid_plot_dimensions(), 300)
    )
    output$download_resid_plot_pdf <- downloadHandler(
      filename = function() sprintf("residual_%s_%s.pdf", input$qq_response %||% "plot", Sys.Date()),
      content = function(file) dava_save_sized_plot(file, norm_plot_for_download("resid"), "pdf", resid_plot_dimensions(), 300)
    )
    
    
    output$download_norm_vari_results <- downloadHandler(
      filename = function() {
        sprintf("norm_vari_results_%s.xlsx", Sys.Date())
      },
      content = function(file) {
        if (length(rv$result_datasets) == 0) {
          sheet_list[["Sheet1"]] <- data.frame(message = "No data loaded")
        }
        writexl::write_xlsx(rv$result_datasets, path = file)
      }
    )
    
    
  })
}


#----------------------------------------------------------------------------------------
# Analysis of Variance-UI
#----------------------------------------------------------------------------------------
mod_anova_ui <-function(id, title, model_type){
  ns <- NS(id)
  card(
    card_header(h4(title, style = "margin: 0;")),
    
    layout_sidebar(
      sidebar = sidebar(
        width = 285,
        tagList(
          tags$div(
            class = "stat-box",
            tags$strong("Data Management"),
            uiOutput(ns("dataset_select_aov")),
            tags$hr(),
            pickerInput(ns("response_var_aov"),"Response variable, multiple selections possible", choices = NULL, multiple = TRUE,options = list(`actions-box` = TRUE,`live-search` = TRUE)),
            pickerInput(ns("response_trans_aov"),"Data transformation variable, multiple selections possible", choices = NULL, multiple = TRUE,options = list(`actions-box` = TRUE,`live-search` = TRUE)),
            selectInput(ns("trans_method_aov"),"Data transformation method",choices = c("none", "log", "square root", "reciprocal", "arcsine","box-cox"),selected = "none"),
            tags$div(class = "small-muted", "Response variable - the response variable for data transformation, must be numeric")
          ),
          
          tags$div(class = "stat-box",tags$strong("Analysis model"),
                   selectInput(ns("factor_n_aov"),"Number of factors",choices = c("Single factor", "Two factors", "Three factors", "Four factors"),selected = "Single factor"),
                   pickerInput( ns("fixed_var_aov"), "Fixed effects/grouping variables, multiple selections possible",             #use “/”will not be escaped by default，instead of using“\”will be escaped by default，causes an error
                                choices = NULL,selected = NULL, multiple = TRUE,options = list(`live-search` = TRUE, `actions-box` = TRUE)),
                   
                   if (model_type == "anova_repeated") {
                     tagList(
                       selectInput(ns("subject"), "Repeated Measurement Subject/Subject Subject ID", choices = NULL),
                       selectizeInput(ns("within_factors"), "Within factors/repeated conditions Within factors", choices = NULL, multiple = TRUE),
                       selectizeInput(ns("between_factors"), "Between factors/Group processing", choices = NULL, multiple = TRUE)
                     )
                   },
                   
                   if (model_type == "anova_block") {
                     selectInput(ns("block"), "Block variable Block", choices = NULL)
                   },
                   
                   if (model_type == "ancova") {
                     selectizeInput(ns("covariates"), "Covariates", choices = NULL, multiple = TRUE)
                   },
                   
                   if (model_type == "GLMM") {
                     selectizeInput(
                       ns("distribution_family"),
                       "Distribution family",
                       choices = c(
                         "Gaussian Normal" = "gaussian",
                         "Binomial" = "binomial",
                         "Poisson count" = "poisson",
                         "Negative binomial" = "negative binomial",
                         "Gamma positive bias continuous" = "gamma",
                         "Inverse Gaussian" = "inverse gaussian"
                       ),
                       selected = "gaussian",
                       multiple = FALSE
                     )
                   },
                   
                   if (model_type %in% c("LMM", "GLMM")) {
                     tagList(
                       selectizeInput(ns("random_vars"), "Random variable", choices = NULL, multiple = TRUE),
                       selectInput(
                         ns("random_type"),
                         "Random effects structure",
                         choices = c("Random intercept", "Random slope", "Nested random", "Crossover random"),
                         selected = "Random intercept"
                       ),
                       uiOutput(ns("random_structure_ui")),
                       hr(),
                       checkboxInput(
                         ns("use_bayes_fallback"),
                         "Automatically try Bayesian model brms when LMM or GLMM does not converge or singular fit",
                         value = FALSE
                       )
                     )
                   },
                   hr(),
                   selectInput(ns("adjust_method_aov"),tags$strong("Multiple comparison method"),
                               choices = c("None" = "none", "Tukey" = "tukey","Bonferroni" = "bonferroni","Holm" = "holm",
                                           "BH/FDR" = "BH", "Sidak" = "sidak", "Scheffe" = "scheffe"), selected = "tukey",multiple = FALSE),
                   numericInput(ns("significance_alpha_aov"), "Significance level alpha", value = 0.05, min = 0.0001, max = 0.2, step = 0.005),
                   hr(),
                   actionButton(ns("run_anova"), tags$strong("Run batch inspection"), class = "btn-primary w-100")
          ),
          
          
          tags$div(class = "stat-box", tags$strong("Drawing"),
                   dava_factor_plot_controls_ui(
                     ns,
                     ids = c(
                       response = "plot_response_aov", mode = "plot_mode_aov",
                       x = "plot_x_aov", group = "plot_group_aov",
                       facet = "plot_facet_aov", panel = "plot_panel_aov",
                       plot_type = "plot_type_aov", significance = "sig_type_aov",
                       effect = "plot_sig_term_aov",
                       combo_enabled = "enable_response_combo_aov",
                       combo_responses = "plot_combo_responses_aov",
                       combo_rows = "plot_combo_rows_aov", combo_cols = "plot_combo_cols_aov"
                     ),
                     max_factors = 4L,
                     include_response_combo = TRUE
                   )
          ),
          
          br(), br(),
          actionButton(ns("register_aov_results"), "Add to data table repository", icon = icon("plus"),
            title = "Add to data table repository", class = "btn-success w-100 mb-2"),
          downloadButton(ns("download_anova_results"), "Download analysis results table", icon = icon("download"), class = "btn-success w-100")
          
        )
      ),
      
      navset_card_tab(
        nav_panel("Data preview", DTOutput(ns("raw_data_preview_aov"))),
        nav_panel("Conversion data preview", DTOutput(ns("trans_vars_aov"))),
        nav_panel("Summary data", DTOutput(ns("summary_table_aov"))),
        nav_panel("Model formula", DTOutput(ns("formula_table_aov"))),
        nav_panel("ANOVA results", DTOutput(ns("anova_table"))),
        nav_panel(
          "Multiple comparison results",
          selectInput(
            ns("posthoc_aov_selcet"),
            "Multiple comparison results preview", 
            choices = c(
              "All multiple comparison results" = "all_posthoc_aov",
              "Multiple comparison results preview" = "part_posthoc_aov"
            ),
            selected = "part_posthoc_aov"
          ),
          conditionalPanel(
            "input.posthoc_aov_selcet == 'all_posthoc_aov'",
            ns = ns,
            DTOutput(ns("all_posthoc_aov"))
          ),
          
          conditionalPanel(
            "input.posthoc_aov_selcet == 'part_posthoc_aov'",
            ns = ns,
            selectInput(ns("posthoc_preview_aov"), "Preview multiple comparison results", choices = NULL),
            helpText("The format is: response variable | main effect or interaction effect. For example Height | A:B."),
            DTOutput(ns("part_posthoc_aov")),
            DTOutput(ns("letter_posthoc_aov"))
          )
        ),
        nav_panel(
          "Plots",
          layout_sidebar(
            sidebar = sidebar(width = 300, position = "right", anova_plot_settings_ui(ns)),
            tagList(
              dava_plot_size_ui(
                ns, "plot_aov", "anova_plot_size", width = 900, height = 700,
                extra_controls = conditionalPanel(
                  ns = ns, condition = "input.enable_response_combo_aov === true",
                  dava_plot_pagination_ui(ns, "anova_combo")
                )
              )
            )
          )
        ),
        nav_panel("Model table", DTOutput(ns("model_table"))),
        nav_panel("Model text", verbatimTextOutput(ns("model_text"))),
        nav_panel("Model diagnostic table", DTOutput(ns("model_status"))),
        nav_panel("Errors", DTOutput(ns("error_table_anova"))),
        nav_panel("R Markdown code document", dava_module_code_panel_ui(ns))
      )
      
    )
    
  )
}


#----------------------------------------------------------------------------------------
# Analysis of Variance-server
#----------------------------------------------------------------------------------------

mod_anova_server <- function(id, file_data, model_type) {
  moduleServer(id, function(input, output, session) {
    root_input <- session$rootScope()$input
    interface_language <- reactive({
      root_input$dava_interface_language
      dava_i18n_language(root_input$dava_interface_language)
    })
    plot_runtime_diagnostics <- reactiveVal(character())
    record_plot_runtime_diagnostics <- function(captured, source = "ANOVA plot") {
      entries <- dava_plot_condition_text(captured, source)
      if (!length(entries)) return(invisible(NULL))
      plot_runtime_diagnostics(unique(c(shiny::isolate(plot_runtime_diagnostics()), entries)))
      invisible(entries)
    }
    
    rv<-reactiveValues(
      result_datasets=list(),
      raw_df = NULL
    )
    fixed_var_selection_order <- reactiveVal(character(0))
    fixed_var_available_choices <- reactiveVal(character(0))
    
    #--SimulationData----
    demo_data <- reactive({
      demo_data_set()
    })
  
#----------------- Analysis of VariancePanel-----
    output$dataset_select_aov <- renderUI({
      ds_names <- dava_global_dataset_names(file_data)
      if (is.null(ds_names) || length(ds_names) == 0) {
        selectInput(
          session$ns("dataset_select_aov_input"),
          "Dataset selection",
          choices = c("Simulation data demo_data" = "__demo__"),
          selected = "__demo__",
          multiple = FALSE
        )
      } else {
        selectInput(
          session$ns("dataset_select_aov_input"),
          "Dataset selection",
          choices = c("Simulation data demo_data" = "__demo__", ds_names),
          selected = "__demo__",
          multiple = FALSE
        )
      }
    })
    
    raw_df <- reactive({
      selected <- input$dataset_select_aov_input %||% "__demo__"
      if (identical(selected, "__demo__")) {
        return(demo_data())
      }
      
      req(file_data$global_datasets)
      validate(
        need(selected %in% dava_global_dataset_names(file_data), "The selected data set does not exist.")
      )
      
      file_data$global_datasets[[selected]]
    })

    dava_module_code_panel_server(
      input, output, session, file_data,
      source_prefix = function() paste("statistics", model_type, sep = "/"),
      default_code = function() anova_code_template(model_type, input, workspace_data = TRUE),
      source = "Statistical analysis",
      title = paste0(model_type, "Complete analysis code"),
      kind = "analysis",
      validate_run = function(run) dava_anova_custom_result(run, raw_df()),
      plot_params = function() dava_code_plot_params_from_input(input),
      data = function() raw_df(),
      dataset_name = function() input$dataset_select_aov_input %||% "__demo__",
      function_mode = "none",
      standalone_bootstrap = FALSE,
      include_input_snapshot = FALSE,
      preview_result = function() aov_analysis_results(),
      preview_plots = function() list("Current result figure" = current_anova_plot())
    )


    observeEvent(raw_df(), {
      req(raw_df())
      num_vars <- numeric_vars(raw_df())
      updatePickerInput(session, "response_var_aov", choices = num_vars, selected = num_vars[1]%||% NULL)
    }, ignoreInit = FALSE)
    
    observeEvent(input$response_var_aov,{
      req(raw_df(),input$response_var_aov)
      fixed_vars <- setdiff(names(raw_df()), input$response_var_aov %||% character(0))
      num_vars <- numeric_vars(raw_df())
      cov_candidates <- setdiff(num_vars, input$response_var_aov %||% character(0))
      initial_fixed <- fixed_vars[1] %||% character(0)
      fixed_var_available_choices(fixed_vars)
      fixed_var_selection_order(initial_fixed)

      updatePickerInput(session, "fixed_var_aov", choices = fixed_vars, selected = initial_fixed)
      updatePickerInput(session, "response_trans_aov", choices = input$response_var_aov, selected = NULL)
      updateSelectInput(session, "subject", choices = fixed_vars, selected = fixed_vars[1] %||% NULL)
      updateSelectizeInput(session, "within_factors", choices = fixed_vars, selected = fixed_vars[1] %||% NULL)
      updateSelectizeInput(session, "between_factors", choices = fixed_vars, selected = fixed_vars[1] %||% NULL, server = TRUE)
      updateSelectInput(session, "block", choices = fixed_vars, selected = fixed_vars[1] %||% NULL)
      updateSelectizeInput(session, "covariates", choices = cov_candidates, selected = cov_candidates[1] %||% NULL, server = TRUE)
    })
    
    observeEvent(input$fixed_var_aov,{
      req(input$fixed_var_aov, input$response_var_aov)
      current <- as.character(input$fixed_var_aov %||% character(0))
      previous <- fixed_var_selection_order()
      ordered <- unique(c(previous[previous %in% current], current[!current %in% previous]))
      available <- fixed_var_available_choices()
      fixed_var_selection_order(ordered)
      if (!identical(current, ordered)) {
        updatePickerInput(
          session,
          "fixed_var_aov",
          choices = c(ordered, setdiff(available, ordered)),
          selected = ordered
        )
      }
      vars <- setdiff(names(raw_df()), c(input$response_var_aov, ordered) %||% character(0))
      vars <- vars[vars != ""]
      updateSelectizeInput(session, "random_vars", choices = vars, selected = vars[1] %||% NULL)
    })
    
    transformed_df <- reactive({
      req(raw_df(), input$response_var_aov, input$trans_method_aov)
      transform_as_df(
        data = raw_df(),
        response = input$response_var_aov,
        response_trans_vars = input$response_trans_aov %||% character(0),
        trans_method = input$trans_method_aov %||% "none"
      )
    })
    
    output$random_structure_ui <- renderUI({
      req(raw_df())
      vars <- input$random_vars %||% setdiff(names(raw_df()), input$response_var_aov %||% character(0))
      if (length(vars) == 0) vars <- setdiff(names(raw_df()), input$response_var_aov %||% character(0))
      
      tagList(
        conditionalPanel(
          condition = "input.random_type == 'Random intercept'",
          ns = session$ns,                    
          selectInput(session$ns("random_intercept"), "Random intercept grouping variable", choices = vars, selected = vars[1] %||% NULL)
        ),
        conditionalPanel(
          condition = "input.random_type == 'Random slope'",
          ns = session$ns,
          selectInput(session$ns("random_intercept_slope_group"), "Random slope grouping variable", choices = vars, selected = vars[1] %||% NULL),
          selectInput(session$ns("random_slope"), "Random slope variable", choices = input$fixed_var_aov %||% vars)
        ),
        conditionalPanel(
          condition = "input.random_type == 'Nested random'",
          ns = session$ns,
          shinyWidgets::pickerInput(
            session$ns("random_nested"),
            "Nested random variables, the order is upper level / lower level",
            choices = vars, selected = head(vars, 2),
            multiple = TRUE,
            options = list(`actions-box` = TRUE, `live-search` = TRUE)
          )
        ),
        conditionalPanel(
          condition = "input.random_type == 'Cross random'",
          ns = session$ns,
          shinyWidgets::pickerInput(
            session$ns("random_crossed"),
            "Cross random variables/select two variables",
            choices = vars, selected = head(vars, 2),
            multiple = TRUE,
            options = list(`actions-box` = TRUE, `live-search` = TRUE)
          )
        )
      )
    })
    
#------------- ANOVA results----------
    get_model_family <- reactive(model_type)
    
    original_aov_analysis_results <- eventReactive(input$run_anova, {
      req(raw_df(), input$response_var_aov, input$fixed_var_aov)
      progress <- shiny::Progress$new(session, min = 0, max = 1)
      on.exit(progress$close(), add = TRUE)
      progress$set(
        message = paste("Run", analysis_title(model_type)),
        detail = "\u68c0\u67e5\u6a21\u578b\u3001\u56fa\u5b9a\u6548\u5e94\u4e0e\u968f\u673a\u6548\u5e94",
        value = 0.08
      )
      
      df <- transformed_df()
      model_family = get_model_family()
      
      selected_fixed <- input$fixed_var_aov %||% character(0)
      fixed_vars <- unique(c(
        fixed_var_selection_order()[fixed_var_selection_order() %in% selected_fixed],
        selected_fixed[!selected_fixed %in% fixed_var_selection_order()]
      ))
      if (model_family %in% c("anova_repeated")) {
        fixed_vars <- unique(c(input$within_factors %||% character(0), input$between_factors %||% character(0)))
      }
      
      req(length(fixed_vars) > 0 || model_family %in% c("LMM", "GLMM"))
      factor_n = input$factor_n_aov
      
      subject = character(0)
      within_factors = character(0)
      between_factors = NULL
      block = character(0)
      covariates = character(0)
      
      random_intercept <- character(0)
      random_slope <- character(0)
      random_nested <- character(0)
      random_crossed <- character(0)
      
      distribution_family = input$distribution_family %||% NULL
      use_bayes_fallback = input$use_bayes_fallback %||% FALSE
      
      
      if (model_family %in% c("LMM","GLMM")) {
        random_type <- input$random_type %||% "Random intercept"
        
        if (random_type == "Random intercept") {
          random_intercept <- input$random_intercept%||% input$random_vars %||% character(0)
        } else if (random_type == "Random slope") {
          random_intercept <- input$random_intercept_slope_group %||% input$random_vars %||% character(0)
          random_slope <- input$random_slope %||% fixed_vars[1] %||% character(0)
        } else if (random_type == "Nested random") {
          random_nested <- input$random_nested %||% input$random_vars %||% character(0)
        } else if (random_type == "Crossover random") {
          random_crossed <- input$random_crossed %||% input$random_vars %||% character(0)
        }
        
        validate(
          need(length(random_intercept) > 0 ||
                 length(random_slope) > 0 ||
                 length(random_nested) > 0 ||
                 length(random_crossed) > 0,
               "LMM/GLMM requires the selection of at least one random effects variable.")
        )
        
      } else if(model_family == "anova_block"){
        block <- input$block %||% character(0)
      } else if(model_family == "anova_repeated"){
        subject <- input$subject %||% character(0)
        within_factors <- input$within_factors %||% character(0)
        between_factors <- input$between_factors %||% NULL
      } else if(model_family == "ancova"){
        covariates <- input$covariates %||% NULL
      }
    
      results <- list()
      errors <- list()
      all_terms <- list()
      all_models <- list()
      dat_summary<-list()
      progress$set(detail = "\u9010\u4e00\u62df\u5408\u54cd\u5e94\u53d8\u91cf\u6a21\u578b", value = 0.28)
      
      for (resp in input$response_var_aov) {
        fit <- tryCatch({
           fit_one_model(
            df = df,
            response = resp,
            fixed_vars = fixed_vars,
            model_family = model_family,
            factor_n = factor_n,
            subject = subject,
            within_factors = within_factors,
            between_factors = between_factors,
            block = block,
            covariates = covariates,
            random_type = random_type,
            random_intercept = random_intercept,
            random_slope = random_slope,
            random_nested = random_nested,
            random_crossed = random_crossed,
            distribution_family = distribution_family,
            use_bayes_fallback = use_bayes_fallback
          )
        }, error = function(e) e)
        
        if (inherits(fit, "error")) {
          errors[[resp]] <- data.frame(response = resp, error = fit$message)
        } else {
          results[[resp]] <- fit
          all_models[[resp]] <- fit$model
          all_terms[[resp]] <- fit$terms_to_compare
          dat_summary[[resp]] = dat_group_summary(df = raw_df(), response = resp, group = fixed_vars)
        }
      }
      
      data_summary <- dplyr::bind_rows(
        lapply(names(dat_summary), function(resp) {
          dat_summary[[resp]] |>
            dplyr::mutate(response = resp, .before = 1)
        })
      )
      
      anova_table <- dplyr::bind_rows(
        lapply(names(results), function(resp) {
          results[[resp]]$anova_table |>
            format_anova_table() |>
            dplyr::mutate(response = resp, .before = 1)
        })
      )
      anova_table <- dava_result_table_contract(anova_table)
      
      model_table <- dplyr::bind_rows(
        lapply(names(results), function(resp) {
          results[[resp]]$model_table |>
            dplyr::mutate(response = resp, .before = 1)
        })
      )
      
      model_status <- dplyr::bind_rows(
        lapply(results, `[[`, "model_status")
      )
        
      errors_df <- dplyr::bind_rows(errors)
      
      formulas <- if (length(results) > 0) {
        data.frame(
          response = names(results),
          formula = vapply(results, function(x) {
            deparse(x$formula)
          }, character(1))
        )
      } else {
        data.frame(response = character(), formula = character())
      }
      
      
     #-----------Multiple comparisons-----------
      progress$set(detail = "\u8ba1\u7b97\u663e\u8457\u6027\u4e0e\u4e8b\u540e\u591a\u91cd\u6bd4\u8f83", value = 0.68)
      adjust <- input$adjust_method_aov %||% "none"
      alpha <- suppressWarnings(as.numeric(input$significance_alpha_aov %||% 0.05))
      if (!is.finite(alpha) || alpha <= 0 || alpha >= 1) alpha <- 0.05
      significance_batch <- dava_compute_significance_batch(
        models = all_models,
        effect_tables = lapply(results, `[[`, "anova_table"),
        factors = fixed_vars,
        adjust = adjust,
        alpha = alpha,
        scale = if (identical(model_family, "GLMM")) "response" else "auto",
        model_status = model_status,
        plot_data = df
      )
      comparison_errors <- unique(significance_batch$errors %||% character())
      comparison_errors <- comparison_errors[
        !is.na(comparison_errors) & nzchar(comparison_errors)]
      if (length(comparison_errors)) {
        errors_df <- dplyr::bind_rows(
          errors_df,
          data.frame(
            response = NA_character_,
            error = paste0("Multiple-comparison engine: ", comparison_errors),
            stringsAsFactors = FALSE
          )
        )
      }
      mct_results <- list(
        posthoc_aov = dava_result_table_contract(format_anova_table(significance_batch$pairwise)),
        letters_aov = dava_result_table_contract(format_anova_table(significance_batch$cld))
      )
      all_terms <- lapply(names(all_models), function(response) {
        unique(c(
          significance_batch$pairwise$term[significance_batch$pairwise$response == response],
          significance_batch$cld$term[significance_batch$cld$response == response]
        ))
      }) |>
        stats::setNames(names(all_models))

      preview_choices <- unlist(lapply(names(all_terms), function(y) term_label(y, all_terms[[y]])))
      updateSelectInput(session, "posthoc_preview_aov", choices = preview_choices, selected = preview_choices[1] %||% NULL)
      updateSelectInput(session, "plot_response_aov", choices = input$response_var_aov, selected = input$response_var_aov[1] %||% NULL)
      updateSelectInput(
        session,
        "plot_secondary_response_aov",
        choices = setdiff(input$response_var_aov, input$response_var_aov[1] %||% ""),
        selected = setdiff(input$response_var_aov, input$response_var_aov[1] %||% "")[1] %||% NULL
      )
      updateSelectInput(session, "plot_x_aov", choices = input$fixed_var_aov, selected = input$fixed_var_aov[1] %||%  NULL)
      updateSelectInput(session, "plot_group_aov", choices = c("None" = "", input$fixed_var_aov),selected =  "")
      updateSelectInput(session, "plot_facet_aov", choices = c("None" = "", input$fixed_var_aov),selected =  "")
      updateSelectInput(session, "plot_panel_aov", choices = c("None" = "", input$fixed_var_aov), selected = "")
      
      
      
      rv$result_datasets <-list(
        data_summary = data_summary,
        anova_table = anova_table,
        model_status = model_status,
        comparison_strategy = significance_batch$strategies,
        emmeans = significance_batch$emmeans,
        annotations = significance_batch$annotations,
        posthoc = mct_results$posthoc_aov,
        letters = mct_results$letters_aov,
        comparison_warnings = data.frame(message = significance_batch$warnings),
        errors = errors_df
      )
      progress$set(detail = "\u6574\u7406\u7ed3\u679c\u8868\u3001\u6ce8\u91ca\u4e0e\u56fe\u5f62\u6570\u636e", value = 0.92)
      

      list(
        transform_df = df,
        formulas = formulas,
        data_summary = data_summary,
        models = all_models,
        model_status = model_status,
        anova_table = anova_table,
        model_table = model_table,
        significance_results = significance_batch$results,
        comparison_strategy = significance_batch$strategies,
        emmeans = significance_batch$emmeans,
        annotations = significance_batch$annotations,
        posthoc = mct_results$posthoc_aov,
        letters = mct_results$letters_aov,
        terms = all_terms,
        errors = errors_df
      )
      
  })


  custom_aov_run <- eventReactive(list(
    input$run_anova, file_data$method_code_revision
  ), {
    method_key <- paste("statistics", model_type, sep = "/")
    entry <- dava_method_code_get(file_data, method_key)
    if (is.null(entry) || !isTRUE(entry$enabled)) return(NULL)
    dava_method_code_execute(file_data, method_key,
      data = raw_df(),
      dataset_name = input$dataset_select_aov_input %||% "__demo__",
      spec = dava_code_analysis_spec_from_input(input))
  }, ignoreInit = TRUE)

  aov_analysis_results <- reactive({
    method_key <- paste("statistics", model_type, sep = "/")
    dava_method_code_effective(
      original = function() original_aov_analysis_results(),
      file_data = file_data, method_key = method_key,
      adapter = function(run, entry) dava_anova_custom_result(
        custom_aov_run(), raw_df()),
      on_error = function(message) {
        dava_record_runtime_condition("warning", paste0(
          "User-defined variance analysis failed and the original method has been rolled back: ",
          message), paste0("Statistical method: ", model_type))
        original_aov_analysis_results()
      }
    )
  })

  output$model_text <- renderText({
    value <- aov_analysis_results()
    req(value)
    formulas <- value$formulas %||% data.frame()
    models <- value$models %||% list()
    blocks <- lapply(names(models), function(response) {
      model <- models[[response]]
      formula_line <- if (is.data.frame(formulas) && response %in% formulas$response) {
        formulas$formula[match(response, formulas$response)]
      } else tryCatch(paste(deparse(stats::formula(model)), collapse = ""), error = function(e) "")
      paste0(
        "===== ", response, " =====\n",
        "Formula: ", formula_line, "\n",
        paste(capture.output(summary(model)), collapse = "\n")
      )
    })
    text <- if (!length(blocks)) "The model text has not been generated; please run the analysis first." else
      paste(unlist(blocks), collapse = "\n\n")
    dava_localize_model_text(
      text, interface_language(), dava_user_data_text(raw_df())
    )
  })

  selected_posthoc_aov <- reactive({
    req(aov_analysis_results(), input$posthoc_preview_aov)
    s <- split_term_label(input$posthoc_preview_aov)
    aov_analysis_results()$posthoc |>
      filter(response == s$response, term == s$term)
  })
  
  selected_letters_aov <- reactive({
    req(aov_analysis_results(), input$posthoc_preview_aov)
    s <- split_term_label(input$posthoc_preview_aov)
    aov_analysis_results()$letters |>
      filter(response == s$response, term == s$term)
  })

  observeEvent(list(input$plot_response_aov, input$response_var_aov), {
    responses <- input$response_var_aov %||% character(0)
    choices <- setdiff(responses, input$plot_response_aov %||% "")
    current <- isolate(input$plot_secondary_response_aov %||% "")
    selected <- if (current %in% choices) current else choices[1] %||% NULL
    updateSelectInput(session, "plot_secondary_response_aov", choices = choices, selected = selected)

    current_combo <- isolate(input$plot_combo_responses_aov %||% character(0))
    updatePickerInput(
      session,
      "plot_combo_responses_aov",
      choices = choices,
      selected = intersect(current_combo, choices)
    )
  }, ignoreInit = TRUE)

  observeEvent(
    list(
      aov_analysis_results(), input$plot_response_aov, input$plot_x_aov,
      input$plot_group_aov, input$plot_facet_aov, input$plot_panel_aov, input$plot_mode_aov
    ),
    {
      result <- aov_analysis_results()
      response <- input$plot_response_aov %||% ""
      x <- input$plot_x_aov %||% ""
      group <- if (identical(input$plot_mode_aov %||% "single", "multi")) input$plot_group_aov %||% "" else ""
      facet <- if (identical(input$plot_mode_aov %||% "single", "multi")) input$plot_facet_aov %||% "" else ""
      panel <- if (identical(input$plot_mode_aov %||% "single", "multi")) input$plot_panel_aov %||% "" else ""
      terms <- unique(c(
        result$terms[[response]] %||% character(0),
        result$anova_table$term[result$anova_table$response == response] %||% character(0),
        result$letters$term[result$letters$response == response] %||% character(0),
        result$posthoc$term[result$posthoc$response == response] %||% character(0)
      ))
      choices <- dava_significance_term_choices(
        terms, x, group, facet, panel,
        language = interface_language()
      )
      current <- isolate(input$plot_sig_term_aov %||% "")
      displayed <- c(x, group, facet, panel)
      displayed <- displayed[nzchar(displayed)]
      preferred <- paste(displayed, collapse = ":")
      selected <- if (current %in% unname(choices)) {
        current
      } else if (preferred %in% unname(choices)) {
        preferred
      } else if (x %in% unname(choices)) {
        x
      } else {
        unname(choices)[1] %||% NULL
      }
      updateSelectInput(session, "plot_sig_term_aov", choices = choices, selected = selected)
    },
    ignoreInit = TRUE
  )

  current_fixed_vars_aov <- reactive({
    if (identical(model_type, "anova_repeated")) {
      return(unique(c(input$within_factors %||% character(0), input$between_factors %||% character(0))))
    }
    selected <- input$fixed_var_aov %||% character(0)
    unique(c(
      fixed_var_selection_order()[fixed_var_selection_order() %in% selected],
      selected[!selected %in% fixed_var_selection_order()]
    ))
  })

  summary_preview_aov <- reactive({
    df <- transformed_df()
    responses <- input$response_var_aov %||% character(0)
    groups <- current_fixed_vars_aov()
    groups <- groups[nzchar(groups) & groups %in% names(df)]
    validate(need(length(responses) > 0, "Please select at least one response variable."))

    dplyr::bind_rows(lapply(responses, function(resp) {
      tryCatch(
        dat_group_summary(df = df, response = resp, group = groups) |>
          dplyr::mutate(response = resp, .before = 1),
        error = function(e) data.frame(response = resp, error = conditionMessage(e), check.names = FALSE)
      )
    }))
  })

  formula_preview_aov <- reactive({
    responses <- input$response_var_aov %||% character(0)
    fixed_vars <- current_fixed_vars_aov()
    validate(need(length(responses) > 0, "Please select at least one response variable."))

    data.frame(
      response = responses,
      formula = vapply(responses, function(resp) {
        tryCatch(
          paste(deparse(build_model_formula(
            response = resp,
            fixed_vars = fixed_vars,
            model_family = model_type,
            factor_n = input$factor_n_aov %||% "Single factor",
            subject = input$subject %||% character(0),
            within_factors = input$within_factors %||% character(0),
            between_factors = input$between_factors %||% character(0),
            block = input$block %||% character(0),
            covariates = input$covariates %||% character(0),
            random_type = input$random_type %||% "Random intercept",
            random_intercept = input$random_intercept %||% input$random_vars %||% character(0),
            random_slope = input$random_slope %||% character(0),
            random_nested = input$random_nested %||% character(0),
            random_crossed = input$random_crossed %||% character(0)
          )), collapse = ""),
          error = function(e) paste0("Configuration error:", conditionMessage(e))
        )
      }, character(1)),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  })
  
  
  
#--------
    output$raw_data_preview_aov <- renderDT({
      req(raw_df())
      datatable(raw_df(), rownames = TRUE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })
    
    output$model_status <- renderDT({
      req(aov_analysis_results())
      datatable(aov_analysis_results()$model_status, rownames = TRUE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })
  
    output$model_table <- renderDT({
      req(aov_analysis_results())
      datatable(aov_analysis_results()$model_table, rownames = TRUE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })
    
    output$trans_vars_aov <- renderDT({
      req(aov_analysis_results())
      datatable(aov_analysis_results()$transform_df, rownames = TRUE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })
    
    output$formula_table_aov <- renderDT({
      datatable(formula_preview_aov(), rownames = FALSE, options = list(scrollX = TRUE))
    })
    
    output$anova_table <- renderDT({
      req(aov_analysis_results())
      datatable(aov_analysis_results()$anova_table, rownames = FALSE, options = list(scrollX = TRUE))
    })
    
    output$error_table_anova <- renderDT({
      req(aov_analysis_results())
      errors <- dava_append_diagnostic_rows(
        aov_analysis_results()$errors,
        c(plot_runtime_diagnostics(), dava_runtime_diagnostic_lines()),
        source = "Plot rendering")
      datatable(dava_localize_message_table(
        errors, interface_language(),
        dava_user_data_text(raw_df())
      ), rownames = FALSE, options = list(scrollX = TRUE, pageLength = 25))
    })
    
    output$summary_table_aov <- renderDT({
      datatable(summary_preview_aov(), rownames = FALSE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })
    
    output$all_posthoc_aov <- renderDT({
      req(aov_analysis_results())
      validate(need(nrow(aov_analysis_results()$posthoc) > 0, "There are no multiple comparison results yet."))
      datatable(aov_analysis_results()$posthoc, rownames = TRUE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })
    
    output$part_posthoc_aov <- renderDT({
      req(selected_posthoc_aov())
      validate(need(nrow(selected_posthoc_aov()) > 0, "There are no multiple comparison results for the current object."))
      datatable(selected_posthoc_aov(), rownames = TRUE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })
    
    output$letter_posthoc_aov <- renderDT({
      req(selected_letters_aov())
      validate(need(nrow(selected_letters_aov()) > 0, "There are no significant letter results for the current object."))
      datatable(selected_letters_aov(), rownames = TRUE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })
    
    
    # plot_data_summary <- reactive({
    #   req(aov_analysis_results(), aov_analysis_results(), input$plot_response_aov, input$plot_x_aov)
    #   df <- raw_df()
    #   y <- input$plot_response_aov
    #   x <- input$plot_x_aov
    #   group <- input$plot_group_aov %||% ""
    #   facet <- input$plot_facet_aov %||% ""
    #   
    #   group_vars <- c(x, group, facet)
    #   group_vars <- unique(group_vars[group_vars != ""])
    #   
    #   df |>
    #     group_by(across(all_of(group_vars))) |>
    #     summarise(
    #       mean = mean(.data[[y]], na.rm = TRUE),
    #       se = sd(.data[[y]], na.rm = TRUE) / sqrt(sum(!is.na(.data[[y]]))),
    #       n = sum(!is.na(.data[[y]])),
    #       .groups = "drop"
    #     )
    # })
    plot_data_summary<- reactive({
      req(aov_analysis_results())
      aov_analysis_results()$data_summary
    })
    
    
    build_anova_plot <- function(y) {
      req(aov_analysis_results(), y, input$plot_x_aov)
      
      analysis_result <- aov_analysis_results()
      response_result_rows <- function(table) {
        table <- as.data.frame(table, stringsAsFactors = FALSE, check.names = FALSE)
        if (!nrow(table) || !"response" %in% names(table)) return(table[0, , drop = FALSE])
        table[!is.na(table$response) & as.character(table$response) == as.character(y), , drop = FALSE]
      }
      response_anova <- response_result_rows(analysis_result$anova_table)
      response_posthoc <- response_result_rows(analysis_result$posthoc)
      response_letters <- response_result_rows(analysis_result$letters)

      df <- raw_df()
      x <- input$plot_x_aov
      group <- if (input$plot_mode_aov == "multi") input$plot_group_aov %||% "" else ""
      facet <- if (input$plot_mode_aov == "multi") input$plot_facet_aov %||% "" else ""
      panel <- if (input$plot_mode_aov == "multi") input$plot_panel_aov %||% "" else ""
      symmetric_layout <- identical(input$plot_layout_aov %||% "standard", "symmetric")
      dual_axis_layout <- identical(input$plot_layout_aov %||% "standard", "dual_axis")
      secondary_response <- if (dual_axis_layout) input$plot_secondary_response_aov %||% "" else ""
      
      validate(
        need(y %in% names(df), "Please select a valid response variable."),
        need(x %in% names(df), "Please select a valid X-axis factor.")
      )
      plot_vars <- unique(c(y, secondary_response, x, group, facet, panel))
      plot_vars <- plot_vars[nzchar(plot_vars) & plot_vars %in% names(df)]
      keep_rows <- stats::complete.cases(df[, plot_vars, drop = FALSE]) & is.finite(df[[y]])
      df <- droplevels(df[keep_rows, , drop = FALSE])
      validate(need(nrow(df) > 0, "There are no complete valid observations for the current plot variable."))
      
      summary_df <- plot_data_summary()
      if ("response" %in% names(summary_df)) {
        summary_df <- dplyr::filter(summary_df, .data[["response"]] == y)
      }
      if (nrow(summary_df) == 0) {
        group_vars <- unique(c(x, group, facet, panel))
        group_vars <- group_vars[nzchar(group_vars) & group_vars %in% names(df)]
        summary_df <- dplyr::summarise(
          dplyr::group_by(df, dplyr::across(dplyr::all_of(group_vars))),
          mean = mean(.data[[y]], na.rm = TRUE),
          se = stats::sd(.data[[y]], na.rm = TRUE) / sqrt(sum(!is.na(.data[[y]]))),
          n = sum(!is.na(.data[[y]])),
          .groups = "drop"
        )
      }
      dodge <- position_dodge(width = 0.78)
      
      if (dual_axis_layout) {
        validate(
          need(nzchar(secondary_response) && secondary_response %in% names(df), "Dual Y-axis layout requires selecting a second numeric response variable."),
          need(secondary_response != y, "The primary response variable and the secondary response variable cannot be the same.")
        )
        p <- dava_dual_axis_effect_plot(df, y, secondary_response, x, group, facet)
      } else if (symmetric_layout) {
        validate(
          need(nzchar(group) && group %in% names(summary_df), "Symmetrical layout requires selection of grouping/color factors."),
          need(nzchar(facet) && facet %in% names(summary_df), "A symmetrical layout requires the option of having two levels of left and right split factors."),
          need(length(unique(stats::na.omit(summary_df[[facet]]))) == 2, "The left and right split factors must contain exactly two levels.")
        )
        p <- dava_symmetric_effect_plot(summary_df, x, group, facet, panel)
      } else {
        p <- dava_anova_effect_plot(
          df, summary_df, y, x, group, facet,
          input$plot_type_aov,
          input$sig_type_aov,
          add_defaults = FALSE
        )
      }
      validate(need(!is.null(p), "There is currently no effect diagram to draw."))
      
      y_values <- df[[y]][is.finite(df[[y]])]
      validate(need(length(y_values) > 0, "The response variable has no finite values ​​to plot."))
      y_range <- range(y_values)
      y_span <- diff(y_range)
      if (!is.finite(y_span) || y_span == 0) y_span <- abs(y_range[1]) + 1
      auto_upper <- y_range[2] + 0.28 * y_span
      auto_lower <- y_range[1] - 0.08 * y_span
      if (identical(input$plot_type_aov %||% "boxplot", "bar")) {
        auto_upper <- max(0, auto_upper)
        auto_lower <- min(0, auto_lower)
      }
      mark_term <- input$plot_sig_term_aov %||% if (nzchar(group)) paste(x, group, sep = ":") else x
      if (input$sig_type_aov %in% c("star", "pvalue", "star_pvalue") &&
          identical(input$plot_mode_aov %||% "single", "single") && identical(mark_term, x)) {
        pair_count <- response_posthoc |>
          dplyr::filter(.data[["term"]] == mark_term) |>
          nrow()
        if (pair_count > 0 && pair_count <= 6) {
          auto_upper <- max(auto_upper, y_range[2] + (pair_count + 1) * 0.075 * y_span)
        }
      }
      parse_limit <- function(value, fallback) {
        parsed <- suppressWarnings(as.numeric(trimws(value %||% "")))
        if (length(parsed) != 1 || !is.finite(parsed)) fallback else parsed
      }
      upper_space <- parse_limit(input$plot_y_max_aov, auto_upper)
      lower_space <- parse_limit(input$plot_y_min_aov, auto_lower)
      validate(need(lower_space < upper_space, "Y-axis lower limit must be smaller than the upper limit."))

      plot_title <- trimws(input$plot_title_aov %||% "")
      x_label <- trimws(input$plot_x_label_aov %||% "")
      y_label <- trimws(input$plot_y_label_aov %||% "")
      if (!nzchar(plot_title)) plot_title <- paste("Effect plot for", y)
      if (!nzchar(x_label)) x_label <- x
      if (!nzchar(y_label)) y_label <- y

      palette_vars <- unique(c(x, group))
      palette_vars <- palette_vars[nzchar(palette_vars) & palette_vars %in% names(df)]
      palette_n <- max(
        16L,
        vapply(palette_vars, function(var) length(unique(stats::na.omit(df[[var]]))), integer(1)),
        na.rm = TRUE
      )
      p <- suppressMessages(dava_plot_add_palette(p, input$plot_palette_aov %||% "Nature", palette_n))
      p <- dava_plot_theme(
        p,
        theme_name = input$plot_theme_aov %||% "publication",
        base_size = input$plot_base_size_aov %||% 14,
        legend_position = input$plot_legend_position_aov %||% "right",
        rotate_x = FALSE,
        show_legend = isTRUE(input$plot_show_legend_aov)
      ) +
        ggplot2::theme(
          plot.margin = ggplot2::margin(20, 25, 35, 15),
          axis.text.x = ggplot2::element_text(
            angle = input$plot_x_angle_aov %||% 35,
            hjust = if ((input$plot_x_angle_aov %||% 35) == 0) 0.5 else 1
          )
        ) +
        ggplot2::labs(
          x = if (symmetric_layout) y_label else x_label,
          y = if (symmetric_layout) x_label else y_label,
          title = plot_title
        )

      if (!symmetric_layout && !dual_axis_layout) {
        p <- if (isTRUE(input$plot_flip_coord_aov)) {
          p + ggplot2::coord_flip(ylim = c(lower_space, upper_space), clip = "on")
        } else {
          p + ggplot2::coord_cartesian(ylim = c(lower_space, upper_space), clip = "on")
        }
      }

      sig_method <- input$sig_type_aov %||% "none"
      if (symmetric_layout && !identical(sig_method, "none")) {
        if (sig_method %in% c("auto", "cld_lower", "cld_dual", "omnibus_cld", "summary_cld")) {
          p <- dava_add_symmetric_cld(
            p, response_letters, y, mark_term, x, group, facet, df,
            y_span = y_span, letter_case = "lower"
          )
        }
        if (identical(sig_method, "cld_upper")) {
          p <- dava_add_symmetric_cld(
            p, response_letters, y, mark_term, x, group, facet, df,
            y_span = y_span, letter_case = "upper"
          )
        }
        summary_method <- if (sig_method %in% c("auto", "model_summary", "summary_cld")) "model_summary" else if (sig_method %in% c("omnibus_star", "omnibus_pvalue", "omnibus_both", "omnibus_cld")) sig_method else "none"
        p <- dava_add_model_significance(
          p, y, x, group, facet, mark_term, summary_method,
          response_anova,
          response_posthoc,
          response_letters,
          df, y_span, y_range[2], 0.78,
          allow_pairwise = FALSE
        )
      } else {
        standard_result <- NULL
        for (candidate in analysis_result$significance_results %||% list()) {
          if (identical(candidate$response, y) &&
              identical(dava_term_from_strategy(candidate$interaction_status), mark_term)) {
            standard_result <- candidate
            break
          }
        }
        if (!is.null(standard_result) && sig_method %in% c("auto", "cld_lower", "cld_upper")) {
          annotation <- standard_result$annotations
          if (!nrow(annotation)) {
            annotation <- build_annotation_table(
              standard_result, df, y, "cld",
              group_vars = unique(c(x, group)),
              panel_vars = unique(c(facet, panel))
            )
          }
          if (identical(sig_method, "cld_upper") && "label" %in% names(annotation)) {
            annotation$label <- toupper(annotation$label)
          }
          if (nrow(annotation)) {
            p <- add_cld_annotations(p, annotation, x, group, size = 5, dodge_width = 0.78)
          } else if (identical(sig_method, "auto")) {
            # CLD unavailable (for example, only one estimable level): retain the
            # selected effect annotation, including a non-significant "ns" result.
            p <- dava_add_model_significance(
              p = p,
              response = y,
              x = x,
              group = group,
              facet = facet,
              term = mark_term,
              method = "omnibus_both",
              anova_table = response_anova,
              posthoc = response_posthoc,
              letters = response_letters,
              data = df,
              y_span = y_span,
              y_top = y_range[2],
              dodge_width = 0.78,
              allow_pairwise = FALSE
            )
          }
        } else if (!is.null(standard_result) &&
                   sig_method %in% c("pairwise_star", "pairwise_pvalue", "pairwise_both") &&
                   identical(standard_result$interaction_status$focus_factor, x)) {
          annotation_type <- if (identical(sig_method, "pairwise_pvalue")) "bracket_p" else "bracket_star"
          annotation <- build_annotation_table(
            standard_result, df, y, annotation_type,
            group_vars = x, panel_vars = unique(c(facet, panel)), show_ns = TRUE
          )
          if (identical(sig_method, "pairwise_both") && nrow(annotation)) {
            annotation$label <- paste(annotation$label, format_p_value(annotation$p_adjusted))
          }
          p <- add_bracket_annotations(p, annotation)
        } else {
          p <- dava_add_model_significance(
            p = p,
            response = y,
            x = x,
            group = group,
            facet = facet,
            term = mark_term,
            method = sig_method,
            anova_table = response_anova,
            posthoc = response_posthoc,
            letters = response_letters,
            data = df,
            y_span = y_span,
            y_top = y_range[2],
            dodge_width = 0.78,
            allow_pairwise = identical(input$plot_mode_aov %||% "single", "single")
          )
        }
      }
      
      p
    }

    active_plot_responses <- reactive({
      primary <- input$plot_response_aov %||% ""
      req(nzchar(primary))
      responses <- primary
      if (isTRUE(input$enable_response_combo_aov)) {
        extras <- input$plot_combo_responses_aov %||% character(0)
        responses <- unique(c(primary, setdiff(extras, primary)))
      }
      responses
    })

    cached_anova_plot_pages <- reactive({
      rows <- max(1L, suppressWarnings(as.integer(input$plot_combo_rows_aov %||% 1L)))
      cols <- max(1L, suppressWarnings(as.integer(input$plot_combo_cols_aov %||% 2L)))
      chunks <- dava_plot_page_chunks(active_plot_responses(), rows, cols)
      lapply(chunks, function(responses) {
        plots <- lapply(responses, build_anova_plot)
        if (length(plots) == 1L) return(plots[[1]])
        if (!requireNamespace("patchwork", quietly = TRUE)) {
          warning(
            "Multiple-response plot composition requires the 'patchwork' package; showing the first plot.",
            call. = FALSE
          )
          return(plots[[1]])
        }
        patchwork::wrap_plots(plots, nrow = rows, ncol = cols, guides = "collect") &
          ggplot2::theme(legend.position = input$plot_legend_position_aov %||% "right")
      })
    })
    anova_plot_total_pages <- reactive(max(1L, length(cached_anova_plot_pages())))
    anova_plot_page <- dava_plot_pagination_server(input, session, "anova_combo", anova_plot_total_pages)

    current_anova_plot <- reactive({
      custom <- aov_analysis_results()$custom_plot %||% NULL
      if (!is.null(custom)) return(custom)
      pages <- cached_anova_plot_pages()
      pages[[min(anova_plot_page(), length(pages))]]
    })

    configured_anova_plot <- reactive({
      plot <- current_anova_plot()
      anova_apply_shared_composite_settings(plot, input)
    })
    observeEvent(input$register_aov_results, {
      value <- aov_analysis_results(); req(value)
      tables <- Filter(function(x) is.data.frame(x) || is.matrix(x), list(
        transformed_data = value$transform_df, summary = summary_preview_aov(),
        formula = formula_preview_aov(), anova = value$anova_table,
        posthoc = value$posthoc, letters = value$letters,
        model = value$model_table, diagnostics = value$model_status, errors = value$errors
      ))
      registered <- dava_register_global_datasets(file_data, tables,
        source = "Statistical Analysis / Analysis of Variance", prefix = "anova")
      showNotification(paste0("has been added to the data table warehouse:", paste(unname(registered), collapse = "、")), type = "message", duration = 3)
    }, ignoreInit = TRUE)

    anova_plot_dimensions <- dava_plot_size_server(
      input, output, session, "plot_aov", "anova_plot_size", width = 900, height = 700
    )

    output$plot_aov <- renderPlot({
      captured <- dava_capture_conditions(print(configured_anova_plot()),
        source = "ANOVA plot")
      record_plot_runtime_diagnostics(captured, "ANOVA plot")
      if (nzchar(captured$error %||% "")) dava_plot_diagnostic_placeholder(captured$error)
      invisible(captured$value)
    })

    observeEvent(input$add_anova_plot_to_library, {
      p <- configured_anova_plot()
      response <- paste(active_plot_responses(), collapse = "_")
      dims <- anova_plot_dimensions()
      ok <- dava_plot_register(
        file_data,
        paste("statistics", model_type, response, sep = "/"),
        p,
        source = "Statistical analysis",
        title = paste0(model_type, " - ", response),
        meta = list(module = "anova", model_type = model_type, response = response, added_by = "manual"),
        params = c(list(module = "anova", model_type = model_type, width_px = dims$width_px, height_px = dims$height_px), dava_plot_input_params(input)),
        editor_svg = dava_plot_editor_svg_sized(p, dims)
      )
      showNotification(
        if (isTRUE(ok)) "has been added to the layout beautification library." else "Add failed: The current drawing is not a registrable object.",
        type = if (isTRUE(ok)) "message" else "error",
        duration = 3
      )
    })

    output$download_anova_plot_png <- downloadHandler(
      filename = function() sprintf("%s_%s_%s.png", model_type, paste(active_plot_responses(), collapse = "_"), Sys.Date()),
      content = function(file) dava_save_sized_plot(file, configured_anova_plot(), "png", anova_plot_dimensions(), 300)
    )
    output$download_anova_plot_pdf <- downloadHandler(
      filename = function() sprintf("%s_%s_%s.pdf", model_type, paste(active_plot_responses(), collapse = "_"), Sys.Date()),
      content = function(file) dava_save_sized_plot(file, configured_anova_plot(), "pdf", anova_plot_dimensions(), 300)
    )
    
    output$download_anova_results <- downloadHandler(
      filename = function() sprintf("anova_results_%s.xlsx", Sys.Date()),
      content = function(file) {
        out <- rv$result_datasets
        if (length(out) == 0) out <- list(Sheet1 = data.frame(message = "No results"))
        writexl::write_xlsx(out, path = file)
      }
    )
    
  })
}










