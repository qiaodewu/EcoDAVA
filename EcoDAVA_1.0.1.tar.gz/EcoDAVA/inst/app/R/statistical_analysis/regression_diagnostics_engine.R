regression_metrics <- function(observed, predicted, predictor_count = NA_integer_) {
  ok <- is.finite(observed) & is.finite(predicted)
  observed <- observed[ok]
  predicted <- predicted[ok]
  n <- length(observed)
  if (!n) return(data.frame())
  residual <- observed - predicted
  tss <- sum((observed - mean(observed))^2)
  r2 <- if (tss > 0) 1 - sum(residual^2) / tss else NA_real_
  data.frame(
    n = n, r.squared = r2,
    adj.r.squared = if (is.finite(predictor_count) && n > predictor_count + 1L) 1 - (1 - r2) * (n - 1) / (n - predictor_count - 1) else NA_real_,
    rmse = sqrt(mean(residual^2)), mae = mean(abs(residual)), stringsAsFactors = FALSE
  )
}

regression_linear_diagnostics <- function(model, data, response) {
  if (!inherits(model, c("lm", "glm"))) return(data.frame())
  fitted <- stats::fitted(model)
  residual <- if (inherits(model, "glm")) stats::residuals(model, type = "deviance") else stats::residuals(model)
  leverage <- tryCatch(stats::hatvalues(model), error = function(e) rep(NA_real_, length(fitted)))
  cooks <- tryCatch(stats::cooks.distance(model), error = function(e) rep(NA_real_, length(fitted)))
  data.frame(.row = data$.dava_row_id, response = response, observed = data[[response]], fitted = fitted,
             residual = residual, standardized_residual = as.numeric(scale(residual)), leverage = leverage,
             cooks_distance = cooks, stringsAsFactors = FALSE)
}

regression_vif <- function(model) {
  if (!inherits(model, "lm") || !requireNamespace("car", quietly = TRUE)) return(data.frame())
  value <- tryCatch(car::vif(model), error = function(e) NULL)
  if (is.null(value)) return(data.frame())
  if (is.matrix(value)) return(data.frame(term = rownames(value), value, row.names = NULL, check.names = FALSE))
  data.frame(term = names(value), vif = as.numeric(value), row.names = NULL)
}
