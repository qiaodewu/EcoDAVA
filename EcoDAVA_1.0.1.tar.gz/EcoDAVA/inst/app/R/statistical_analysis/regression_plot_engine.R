regression_plot_types <- function(result) {
  choices <- c("Regression fitting graph" = "fit", "Observed value-predicted value plot" = "observed_predicted",
               "Residual diagnostic plot" = "residual", "Coefficient forest graph" = "coefficients")
  if (nrow(result$scores) >= 2L) choices <- c(choices, "Component Score Chart" = "scores")
  if (nrow(result$loadings) >= 2L) choices <- c(choices, "Load diagram" = "loadings")
  if (nrow(result$variable_importance)) choices <- c(choices, "Variable Importance Plot" = "importance")
  if (identical(result$method_id, "multivariate_tree") && inherits(result$model, "rpart")) {
    choices <- c("Multiple regression tree structure diagram" = "tree", choices)
  }
  if (inherits(result$model, "cv.glmnet")) choices <- c(choices, "Cross-validation error plot" = "cv")
  if ((inherits(result$model, "cca") || result$method_id %in% c("rda", "cca", "dbrda")) && nrow(result$scores)) {
    choices <- c("Community ranking biplot" = "ordination", choices)
  }
  if (nrow(result$mediation_results)) choices <- c("Mediation effect diagram" = "mediation_effects", choices)
  if (nrow(result$moderation_results)) choices <- c("Simple slope plot" = "simple_slopes", choices)
  if (nrow(result$feature_results)) choices <- c("Feature correlation volcano plot" = "volcano", "Feature effect forest plot" = "effect_forest", choices)
  if (nrow(result$feature_results)) choices <- c(choices, "Feature effect heat map" = "feature_heatmap", "Multi-species effect heat map" = "effect_heatmap")
  if (nrow(result$filter_records)) choices <- c(choices, "Feature abundance" = "abundance", "Feature prevalence" = "prevalence")
  if (nrow(result$scores) >= 2L) choices <- c(choices, "Sample score" = "site_scores")
  if (nrow(result$loadings) >= 2L) choices <- c(choices, "Species Score" = "species_scores")
  if (nrow(result$community_results)) choices <- c(choices, "Interpretation rate" = "explained_variance")
  if (identical(result$method_id, "pgls") && nrow(result$coefficients)) choices <- c(choices, "Phylogenetic associations" = "phylogenetic_association")
  if (nrow(result$metadata$johnson_neyman %||% data.frame())) choices <- c("Johnson-Neyman diagram" = "johnson_neyman", choices)
  capability <- tryCatch(regression_model_capability(result$method_id), error = function(e) NULL)
  if (is.null(capability)) return(choices)
  allowed <- trimws(strsplit(capability$plot_types[1] %||% "", ",", fixed = TRUE)[[1]])
  choices <- choices[!duplicated(unname(choices))]
  choices[unname(choices) %in% allowed]
}

regression_confidence_colors <- function(colors, white_mix = 0.62) {
  colors <- as.character(colors)
  white_mix <- max(0, min(1, as.numeric(white_mix %||% 0.62)))
  vapply(colors, function(color) {
    rgb <- grDevices::col2rgb(color) / 255
    mixed <- rgb * (1 - white_mix) + white_mix
    grDevices::rgb(mixed[1], mixed[2], mixed[3])
  }, character(1), USE.NAMES = FALSE)
}

regression_plot_engine <- function(result, type = "fit", palette = "Scientific", base_size = 14) {
  if (!inherits(result, "dava_regression_result") || result$status == "error") return(NULL)
  colors <- dava_plot_palette(palette, 12)
  if (type == "tree" && inherits(result$model, "rpart")) {
    model <- result$model
    coordinates <- tryCatch(getFromNamespace("rpartco", "rpart")(model, list()), error = function(e) NULL)
    if (is.null(coordinates)) return(NULL)
    nodes <- as.integer(row.names(model$frame))
    node_data <- data.frame(
      node = nodes, x = coordinates$x, y = coordinates$y,
      label = ifelse(model$frame$var == "<leaf>",
        paste0("Yenode\nn = ", model$frame$n),
        paste0(model$frame$var, "\nn = ", model$frame$n)),
      leaf = model$frame$var == "<leaf>", stringsAsFactors = FALSE
    )
    edge_rows <- lapply(nodes[nodes != 1L], function(node) {
      child <- node_data[node_data$node == node, , drop = FALSE]
      parent <- node_data[node_data$node == node %/% 2L, , drop = FALSE]
      if (!nrow(child) || !nrow(parent)) return(NULL)
      data.frame(x = parent$x, y = parent$y, xend = child$x, yend = child$y)
    })
    edge_data <- dplyr::bind_rows(edge_rows)
    p <- ggplot2::ggplot() +
      ggplot2::geom_segment(data = edge_data, ggplot2::aes(x = .data$x, y = .data$y, xend = .data$xend, yend = .data$yend), color = "grey55", linewidth = 0.55) +
      ggplot2::geom_point(data = node_data, ggplot2::aes(x = .data$x, y = .data$y, fill = .data$leaf), shape = 21, size = 5, color = colors[1]) +
      ggplot2::geom_label(data = node_data, ggplot2::aes(x = .data$x, y = .data$y, label = .data$label), size = 3.2, linewidth = 0.2, vjust = -0.75) +
      ggplot2::scale_fill_manual(values = c(`TRUE` = colors[2], `FALSE` = "white"), guide = "none") +
      ggplot2::labs(title = "Multiple regression tree", subtitle = "Node partitioning simultaneously minimizes within-group sums of squares for multiple response variables") +
      ggplot2::theme_void(base_size = base_size) +
      ggplot2::theme(plot.title = ggplot2::element_text(face = "bold"))
    return(p)
  }
  if (type %in% c("site_scores", "species_scores")) {
    type <- if (identical(type, "site_scores")) "scores" else "loadings"
  }
  if (type == "explained_variance") {
    dat <- result$community_results
    axis_column <- intersect(c("axis", "component", "term"), names(dat))[1] %||% ""
    value_column <- intersect(c("explained_variance", "proportion", "variance", "estimate"), names(dat))[1] %||% ""
    if (!nzchar(axis_column) || !nzchar(value_column) || !nrow(dat)) return(NULL)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = factor(.data[[axis_column]], levels = unique(.data[[axis_column]])), y = .data[[value_column]])) +
      ggplot2::geom_col(fill = colors[1], alpha = 0.85) +
      ggplot2::labs(x = "Axis", y = "Explained variance", title = "Explained variance by constrained axis")
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, FALSE))
  }
  if (type %in% c("effect_heatmap", "feature_heatmap") && nrow(result$feature_results)) {
    dat <- result$feature_results
    feature_column <- intersect(c("feature", "taxon", "response"), names(dat))[1] %||% ""
    effect_column <- intersect(c("effect", "term", "contrast"), names(dat))[1] %||% ""
    value_column <- intersect(c("estimate", "effect_size", "coefficient"), names(dat))[1] %||% ""
    if (!nzchar(feature_column) || !nzchar(value_column)) return(NULL)
    if (!nzchar(effect_column)) {
      dat$.effect <- "Effect"
      effect_column <- ".effect"
    }
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data[[effect_column]], y = .data[[feature_column]], fill = .data[[value_column]])) +
      ggplot2::geom_tile(color = "white", linewidth = 0.25) +
      ggplot2::scale_fill_gradient2(low = colors[2], mid = "white", high = colors[1], midpoint = 0) +
      ggplot2::labs(x = NULL, y = "Feature", fill = "Effect", title = "Feature effect heatmap")
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, TRUE))
  }
  if (type %in% c("abundance", "prevalence") && nrow(result$filter_records)) {
    dat <- result$filter_records
    feature_column <- intersect(c("feature", "taxon"), names(dat))[1] %||% ""
    value_column <- if (type == "abundance") {
      intersect(c("total_abundance", "mean_abundance", "abundance"), names(dat))[1] %||% ""
    } else {
      intersect(c("prevalence", "prevalence_fraction", "sample_prevalence"), names(dat))[1] %||% ""
    }
    if (!nzchar(feature_column) || !nzchar(value_column)) return(NULL)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data[[value_column]], y = stats::reorder(.data[[feature_column]], .data[[value_column]]))) +
      ggplot2::geom_col(fill = colors[1], alpha = 0.85) +
      ggplot2::labs(x = if (type == "abundance") "Abundance" else "Prevalence", y = "Feature",
                    title = if (type == "abundance") "Feature abundance" else "Feature prevalence")
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, FALSE))
  }
  if (type == "phylogenetic_association") {
    dat <- result$coefficients
    if (!nrow(dat) || !all(c("term", "estimate") %in% names(dat))) return(NULL)
    dat <- dat[dat$term != "(Intercept)", , drop = FALSE]
    if (!nrow(dat)) return(NULL)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data$estimate, y = stats::reorder(.data$term, .data$estimate))) +
      ggplot2::geom_vline(xintercept = 0, linetype = 2) +
      ggplot2::geom_point(color = colors[1], size = 2.8) +
      ggplot2::labs(x = "Phylogenetic effect estimate", y = NULL, title = "Phylogenetic association")
    if (all(c("conf.low", "conf.high") %in% names(dat))) {
      p <- p + ggplot2::geom_errorbar(ggplot2::aes(xmin = .data$conf.low, xmax = .data$conf.high), orientation = "y", width = 0.15)
    }
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, FALSE))
  }
  if (type == "volcano" && nrow(result$feature_results)) {
    dat <- result$feature_results
    if (!all(c("estimate", "p.adjust", "feature") %in% names(dat))) return(NULL)
    dat$significant <- is.finite(dat$p.adjust) & dat$p.adjust < 0.05
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data$estimate, y = -log10(pmax(.data$p.adjust, .Machine$double.xmin)), color = .data$significant)) +
      ggplot2::geom_point(size = 2.4, alpha = 0.8) +
      ggplot2::scale_color_manual(values = c(`TRUE` = colors[2], `FALSE` = "grey65")) +
      ggplot2::labs(x = "Effect estimate", y = "-log10(FDR)", color = "FDR < 0.05", title = "Feature-level multivariate correlations")
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, TRUE))
  }
  if (type == "effect_forest" && nrow(result$feature_results)) {
    dat <- result$feature_results
    if (!all(c("estimate", "feature") %in% names(dat))) return(NULL)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data$estimate, y = stats::reorder(.data$feature, .data$estimate))) +
      ggplot2::geom_vline(xintercept = 0, linetype = 2) + ggplot2::geom_point(color = colors[1], size = 2.5)
    if (all(c("conf.low", "conf.high") %in% names(dat))) p <- p + ggplot2::geom_errorbar(
      ggplot2::aes(xmin = .data$conf.low, xmax = .data$conf.high), orientation = "y", width = 0.15
    )
    return(dava_plot_theme(p + ggplot2::labs(x = "Effect estimate", y = "Features", title = "Feature effect forest plot"), "publication", base_size, "right", FALSE, FALSE))
  }
  if (type %in% c("mediation_path", "mediation_effects") && nrow(result$mediation_results)) {
    dat <- result$mediation_results
    plot_data <- dplyr::bind_rows(
      data.frame(mediator = dat$mediator, effect = "Indirect effects", estimate = dat$indirect_effect,
                 conf.low = dat$conf.low, conf.high = dat$conf.high),
      data.frame(mediator = dat$mediator, effect = "Direct effect", estimate = dat$direct_effect,
                 conf.low = NA_real_, conf.high = NA_real_)
    )
    p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data$estimate, y = .data$mediator, color = .data$effect)) +
      ggplot2::geom_vline(xintercept = 0, linetype = 2) + ggplot2::geom_point(size = 3) +
      ggplot2::geom_errorbar(ggplot2::aes(xmin = .data$conf.low, xmax = .data$conf.high), orientation = "y", width = 0.15, na.rm = TRUE) +
      ggplot2::scale_color_manual(values = colors[1:2]) + ggplot2::labs(x = "Effect estimate", y = "Mediating variable", title = "Mediation Effect and Bootstrap Confidence Interval")
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, TRUE))
  }
  if (type == "simple_slopes" && nrow(result$adjusted_predictions)) {
    dat <- result$adjusted_predictions
    focus <- result$focus_predictor
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data[[focus]], y = .data$predicted,
                                           color = factor(.data$moderator_value), group = factor(.data$moderator_value))) +
      ggplot2::geom_ribbon(ggplot2::aes(ymin = .data$conf.low, ymax = .data$conf.high, fill = factor(.data$moderator_value)), alpha = 0.13, color = NA) +
      ggplot2::geom_line(linewidth = 1) + ggplot2::scale_color_manual(values = colors) + ggplot2::scale_fill_manual(values = colors) +
      ggplot2::labs(x = focus, y = result$responses[1], color = "Adjustment variable", fill = "Adjustment variable", title = "Adjustment effect simple slope")
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, TRUE))
  }
  if (type == "johnson_neyman") {
    dat <- result$metadata$johnson_neyman %||% data.frame()
    if (!nrow(dat)) return(NULL)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data$moderator_value, y = .data$slope)) +
      ggplot2::geom_ribbon(ggplot2::aes(ymin = .data$conf.low, ymax = .data$conf.high, fill = .data$significant), alpha = 0.22) +
      ggplot2::geom_line(color = colors[1], linewidth = 1) + ggplot2::geom_hline(yintercept = 0, linetype = 2) +
      ggplot2::scale_fill_manual(values = c(`TRUE` = colors[2], `FALSE` = "grey75")) +
      ggplot2::labs(x = "Modulated variable W", y = "Conditional slope of X", fill = "Significantly", title = "Johnson-Neyman significant interval")
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, TRUE))
  }
  if (type == "fit" && nrow(result$adjusted_predictions) && nzchar(result$focus_predictor)) {
    focus <- result$focus_predictor
    response <- result$responses[1]
    data <- result$model_data
    pred <- result$adjusted_predictions
    group <- result$group_var
    grouped <- nzchar(group) && group %in% names(pred)
    if (grouped) {
      group_count <- length(unique(as.character(pred[[group]])))
      colors <- dava_plot_palette(palette, max(12L, group_count))
    }
    mapping <- if (grouped) ggplot2::aes(x = .data[[focus]], y = .data[[response]], color = .data[[group]]) else ggplot2::aes(x = .data[[focus]], y = .data[[response]])
    point_layer <- if (grouped) ggplot2::geom_point(alpha = 0.65, size = 2) else
      ggplot2::geom_point(color = "#1F1F1F", alpha = 0.65, size = 2)
    p <- ggplot2::ggplot(data, mapping) + point_layer
    if (grouped) {
      confidence_colors <- regression_confidence_colors(colors)
      p <- p + ggplot2::geom_ribbon(data = pred, ggplot2::aes(x = .data[[focus]], ymin = .data$conf.low, ymax = .data$conf.high, fill = .data[[group]], group = .data[[group]]), inherit.aes = FALSE, alpha = 0.12, color = NA, na.rm = TRUE) +
        ggplot2::geom_line(data = pred, ggplot2::aes(x = .data[[focus]], y = .data$predicted, color = .data[[group]], group = .data[[group]]), inherit.aes = FALSE, linewidth = 1) +
        ggplot2::scale_color_manual(values = colors) + ggplot2::scale_fill_manual(values = confidence_colors)

      metrics <- result$fit_metrics
      metric_group <- intersect(c(group, "group"), names(metrics))[1] %||% ""
      if (nrow(metrics) && nzchar(metric_group)) {
        annotation <- dplyr::bind_rows(lapply(seq_len(nrow(metrics)), function(i) {
          group_value <- as.character(metrics[[metric_group]][i])
          group_data <- data[as.character(data[[group]]) == group_value, , drop = FALSE]
          if (!nrow(group_data)) return(data.frame())
          r2 <- if ("r.squared" %in% names(metrics)) suppressWarnings(as.numeric(metrics$r.squared[i])) else NA_real_
          p_value <- if ("p.value" %in% names(metrics)) suppressWarnings(as.numeric(metrics$p.value[i])) else NA_real_
          n_value <- if ("n" %in% names(metrics)) suppressWarnings(as.integer(metrics$n[i])) else nrow(group_data)
          label <- c(
            if (is.finite(r2)) sprintf("R2 = %.3f", r2) else "",
            if (is.finite(p_value)) {
              if (p_value < 0.001) "P < 0.001" else sprintf("P = %.3f", p_value)
            } else "",
            sprintf("n = %d", n_value)
          )
          label <- paste(label[nzchar(label)], collapse = "   ")
          x_values <- group_data[[focus]]
          y_values <- group_data[[response]]
          data.frame(
            x = min(x_values, na.rm = TRUE) + 0.03 * diff(range(x_values, na.rm = TRUE)),
            y = max(y_values, na.rm = TRUE), label = label,
            group_value = group_value, stringsAsFactors = FALSE
          )
        }))
        if (nrow(annotation)) {
          annotation[[group]] <- annotation$group_value
          if (is.factor(data[[group]])) annotation[[group]] <- factor(annotation[[group]], levels = levels(data[[group]]))
          p <- p + ggplot2::geom_text(
            data = annotation,
            ggplot2::aes(x = .data$x, y = .data$y, label = .data$label, color = .data[[group]]),
            inherit.aes = FALSE, hjust = 0, vjust = -0.35, size = 3.5, show.legend = FALSE
          )
        }
      }
    } else {
      p <- p + ggplot2::geom_ribbon(data = pred, ggplot2::aes(x = .data[[focus]], ymin = .data$conf.low, ymax = .data$conf.high), inherit.aes = FALSE, fill = regression_confidence_colors(colors[1]), alpha = 0.12, color = NA, na.rm = TRUE) +
        ggplot2::geom_line(data = pred, ggplot2::aes(x = .data[[focus]], y = .data$predicted), inherit.aes = FALSE, color = colors[1], linewidth = 1.05)
    }
    metric <- if (grouped) data.frame() else result$fit_metrics[1, , drop = FALSE]
    p_label <- if ("p.value" %in% names(metric) && is.finite(suppressWarnings(as.numeric(metric$p.value[1])))) {
      p_value <- as.numeric(metric$p.value[1])
      if (p_value < 0.001) "P < 0.001" else sprintf("P = %.3f", p_value)
    } else ""
    statistic_items <- c(
      if ("r.squared" %in% names(metric) && is.finite(metric$r.squared[1])) sprintf("R2 = %.3f", metric$r.squared[1]) else "",
      p_label,
      sprintf("n = %d", nrow(data))
    )
    statistic_label <- paste(statistic_items[nzchar(statistic_items)], collapse = "   ")
    if (!grouped && nzchar(statistic_label)) {
      p <- p + ggplot2::annotate(
        "text", x = -Inf, y = Inf, label = statistic_label,
        hjust = -0.05, vjust = 1.35, size = 3.5, color = colors[1]
      )
    }
    p <- p + ggplot2::labs(title = result$method_name, subtitle = result$numeric_equation, x = focus, y = response)
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, grouped))
  }
  if (type %in% c("fit", "observed_predicted")) {
    dat <- result$observed_fitted
    if (!nrow(dat)) return(NULL)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data$predicted, y = .data$observed)) +
      ggplot2::geom_point(color = colors[1], alpha = 0.7, size = 2.3) +
      ggplot2::geom_abline(slope = 1, intercept = 0, linetype = 2, color = colors[2]) +
      ggplot2::labs(x = "Predicted value", y = "Observations", title = paste(result$method_name, "observed value - predicted value"))
    if (length(unique(dat$response)) > 1L) {
      p <- p + ggplot2::facet_wrap(~response, scales = "free")
    } else {
      p <- p + ggplot2::coord_equal()
    }
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, FALSE))
  }
  if (type == "residual") {
    dat <- result$diagnostics
    if (!nrow(dat) || !all(c("fitted", "residual") %in% names(dat))) return(NULL)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data$fitted, y = .data$residual)) +
      ggplot2::geom_point(color = colors[1], alpha = 0.7) + ggplot2::geom_hline(yintercept = 0, linetype = 2) +
      ggplot2::labs(x = "Fitted value", y = "Residual", title = "Residual-fitted value diagnostics")
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, FALSE))
  }
  if (type == "coefficients") {
    dat <- result$coefficients
    if (!nrow(dat) || !all(c("term", "estimate") %in% names(dat))) return(NULL)
    dat <- dat[dat$term != "(Intercept)", , drop = FALSE]
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data$estimate, y = stats::reorder(.data$term, .data$estimate))) +
      ggplot2::geom_vline(xintercept = 0, linetype = 2) + ggplot2::geom_point(color = colors[1], size = 2.8)
    if (all(c("conf.low", "conf.high") %in% names(dat))) p <- p + ggplot2::geom_errorbar(
      ggplot2::aes(xmin = .data$conf.low, xmax = .data$conf.high), orientation = "y", width = 0.15
    )
    if ("response" %in% names(dat) && length(unique(dat$response)) > 1L) p <- p + ggplot2::facet_wrap(~response, scales = "free_y")
    return(dava_plot_theme(p + ggplot2::labs(x = "Estimate", y = NULL, title = "Regression coefficient"), "publication", base_size, "right", FALSE, FALSE))
  }
  if (type %in% c("scores", "loadings")) {
    dat <- if (type == "scores") result$scores else result$loadings
    numeric_columns <- names(dat)[vapply(dat, is.numeric, logical(1))]
    numeric_columns <- setdiff(numeric_columns, ".row")
    if (length(numeric_columns) < 2L) return(NULL)
    label <- if (type == "loadings" && "variable" %in% names(dat)) "variable" else ""
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data[[numeric_columns[1]]], y = .data[[numeric_columns[2]]])) +
      ggplot2::geom_point(color = colors[1], size = 2.6, alpha = 0.75)
    if (nzchar(label)) p <- p + ggplot2::geom_text(ggplot2::aes(label = .data[[label]]), nudge_y = 0.02, size = 3.5)
    return(dava_plot_theme(p + ggplot2::labs(title = if (type == "scores") "Ingredients Score" else "payload"), "publication", base_size, "right", FALSE, FALSE))
  }
  if (type == "ordination") {
    sites <- result$scores
    species <- result$loadings
    site_axes <- setdiff(names(sites)[vapply(sites, is.numeric, logical(1))], ".row")
    species_axes <- names(species)[vapply(species, is.numeric, logical(1))]
    if (length(site_axes) < 2L) return(NULL)
    p <- ggplot2::ggplot(sites, ggplot2::aes(x = .data[[site_axes[1]]], y = .data[[site_axes[2]]])) +
      ggplot2::geom_hline(yintercept = 0, linewidth = 0.3, color = "grey75") +
      ggplot2::geom_vline(xintercept = 0, linewidth = 0.3, color = "grey75") +
      ggplot2::geom_point(color = colors[1], alpha = 0.72, size = 2.2)
    if (nrow(species) && length(species_axes) >= 2L) {
      p <- p + ggplot2::geom_segment(
        data = species, ggplot2::aes(x = 0, y = 0, xend = .data[[species_axes[1]]], yend = .data[[species_axes[2]]]),
        inherit.aes = FALSE, arrow = grid::arrow(length = grid::unit(0.12, "cm")), color = colors[2], linewidth = 0.55
      ) + ggplot2::geom_text(
        data = species, ggplot2::aes(x = .data[[species_axes[1]]], y = .data[[species_axes[2]]], label = .data$variable),
        inherit.aes = FALSE, color = colors[2], size = 3, vjust = -0.35
      )
    }
    return(dava_plot_theme(
      p + ggplot2::labs(x = site_axes[1], y = site_axes[2], title = result$method_name),
      "publication", base_size, "right", FALSE, FALSE
    ))
  }
  if (type == "importance") {
    dat <- result$variable_importance
    term <- intersect(c("term", "Feature", "variable"), names(dat))[1] %||% ""
    value <- intersect(c("importance", "Gain", "estimate"), names(dat))[1] %||% ""
    if (!nzchar(term) || !nzchar(value)) return(NULL)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data[[value]], y = stats::reorder(.data[[term]], .data[[value]]))) +
      ggplot2::geom_col(fill = colors[1], alpha = 0.85) + ggplot2::labs(x = "Importance", y = NULL, title = "Variable importance")
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, FALSE))
  }
  if (type == "cv" && inherits(result$model, "cv.glmnet")) {
    dat <- data.frame(lambda = result$model$lambda, cvm = result$model$cvm, cvsd = result$model$cvsd)
    p <- ggplot2::ggplot(dat, ggplot2::aes(x = log(.data$lambda), y = .data$cvm)) +
      ggplot2::geom_ribbon(ggplot2::aes(ymin = .data$cvm - .data$cvsd, ymax = .data$cvm + .data$cvsd), fill = colors[1], alpha = 0.18) +
      ggplot2::geom_line(color = colors[1]) + ggplot2::geom_vline(xintercept = log(result$model$lambda.min), linetype = 2) +
      ggplot2::labs(x = "log(lambda)", y = "Cross-validation error", title = "Regularized cross validation")
    return(dava_plot_theme(p, "publication", base_size, "right", FALSE, FALSE))
  }
  NULL
}
