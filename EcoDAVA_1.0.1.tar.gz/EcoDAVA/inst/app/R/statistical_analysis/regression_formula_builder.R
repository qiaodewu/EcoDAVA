# Clearly distinguish the whole、GroupingMasterEffect、GroupingInteraction、GroupingIndependent andLevelmodel。
build_regression_formula <- function(responses, predictors, focus_predictor = NULL,
                                     scenario = "overall", group_var = "",
                                     random_slope = FALSE, degree = 2L,
                                     method = "lm", random_structure = "intercept",
                                     nested_group = "", crossed_groups = character(),
                                     random_slope_correlated = TRUE,
                                     random_slope_predictor = focus_predictor) {
  responses <- unique(responses[nzchar(responses)])
  predictors <- unique(predictors[nzchar(predictors)])
  focus_predictor <- focus_predictor %||% predictors[1] %||% ""
  lhs <- if (length(responses) > 1L) paste0("cbind(", paste(responses, collapse = ", "), ")") else responses[1]
  rhs <- predictors
  if (identical(method, "polynomial") && nzchar(focus_predictor)) {
    rhs[rhs == focus_predictor] <- sprintf("stats::poly(%s, %d, raw = TRUE)", focus_predictor, as.integer(degree))
  }
  if (identical(method, "spline") && nzchar(focus_predictor)) {
    rhs[rhs == focus_predictor] <- sprintf("splines::ns(%s, df = %d)", focus_predictor, max(3L, as.integer(degree)))
  }
  if (scenario == "group_main" && nzchar(group_var)) rhs <- c(rhs, group_var)
  if (scenario == "group_interaction" && nzchar(group_var) && nzchar(focus_predictor)) {
    rhs <- c(setdiff(rhs, focus_predictor), sprintf("%s * %s", focus_predictor, group_var))
  }
  if (scenario == "hierarchical" && nzchar(group_var)) {
    random_terms <- build_regression_random_terms(
      group_var = group_var, focus_predictor = random_slope_predictor,
      random_slope = random_slope, random_structure = random_structure,
      nested_group = nested_group, crossed_groups = crossed_groups,
      random_slope_correlated = random_slope_correlated
    )
    rhs <- c(rhs, random_terms)
  }
  stats::as.formula(sprintf("%s ~ %s", lhs, paste(unique(rhs), collapse = " + ")))
}

build_regression_random_terms <- function(group_var, focus_predictor = "", random_slope = FALSE,
                                          random_structure = "intercept", nested_group = "",
                                          crossed_groups = character(), random_slope_correlated = TRUE) {
  variables <- unique(c(group_var, nested_group, crossed_groups))
  variables <- variables[nzchar(variables)]
  if (!length(variables)) stop("A random effects structure requires at least one valid grouping variable.", call. = FALSE)
  if (identical(random_structure, "nested")) {
    if (!nzchar(group_var) || !nzchar(nested_group)) stop("Nested random effects require upper and lower grouping variables.", call. = FALSE)
    return(sprintf("(1 | %s/%s)", group_var, nested_group))
  }
  if (identical(random_structure, "crossed") || identical(random_structure, "multiple")) {
    groups <- unique(c(group_var, crossed_groups))
    groups <- groups[nzchar(groups)]
    if (length(groups) < 2L) stop("Crossed or multiple random factor structures require at least two grouping variables.", call. = FALSE)
    return(sprintf("(1 | %s)", groups))
  }
  if (isTRUE(random_slope) || identical(random_structure, "slope")) {
    if (!nzchar(focus_predictor)) stop("A random slope structure requires a continuous slope variable.", call. = FALSE)
    operator <- if (isTRUE(random_slope_correlated)) "|" else "||"
    return(sprintf("(%s %s %s)", focus_predictor, operator, group_var))
  }
  sprintf("(1 | %s)", group_var)
}

build_regression_component_formulas <- function(response, predictors, zero_predictors = character(),
                                                dispersion_predictors = character(), intercept_only_zero = FALSE) {
  conditional <- build_regression_formula(response, predictors)
  zero_rhs <- if (isTRUE(intercept_only_zero) || !length(zero_predictors)) "1" else paste(unique(zero_predictors[nzchar(zero_predictors)]), collapse = " + ")
  dispersion_rhs <- if (!length(dispersion_predictors)) "1" else paste(unique(dispersion_predictors[nzchar(dispersion_predictors)]), collapse = " + ")
  list(
    conditional = conditional,
    zero = stats::as.formula(paste("~", zero_rhs)),
    dispersion = stats::as.formula(paste("~", dispersion_rhs))
  )
}

parse_regression_nls_starts <- function(value) {
  if (is.list(value) && length(value) && !is.null(names(value))) {
    starts <- vapply(value, as.numeric, numeric(1))
  } else {
    text <- trimws(as.character(value %||% ""))[1]
    parts <- trimws(strsplit(text, ",", fixed = TRUE)[[1]])
    parts <- parts[nzchar(parts)]
    pairs <- strsplit(parts, "=", fixed = TRUE)
    if (!length(pairs) || any(lengths(pairs) != 2L)) stop("The initial value of the nonlinear parameter must use the name=value format.", call. = FALSE)
    names_value <- trimws(vapply(pairs, `[[`, character(1), 1L))
    starts <- suppressWarnings(as.numeric(trimws(vapply(pairs, `[[`, character(1), 2L))))
    names(starts) <- names_value
  }
  if (!length(starts) || any(!is.finite(starts)) || any(!grepl("^[A-Za-z][A-Za-z0-9_.]*$", names(starts))) || anyDuplicated(names(starts))) {
    stop("The nonlinear parameter initial value name or value is invalid.", call. = FALSE)
  }
  as.list(starts)
}

build_regression_nls_formula <- function(value, response, predictors, parameter_names) {
  formula <- tryCatch(stats::as.formula(as.character(value)[1]), error = function(e) NULL)
  if (is.null(formula) || length(formula) != 3L) stop("Invalid nonlinear formula.", call. = FALSE)
  lhs <- all.vars(formula[[2]])
  if (!identical(lhs, response)) stop("The left side of the nonlinear formula must be the current response variable.", call. = FALSE)
  symbols <- all.names(formula[[3]], functions = TRUE, unique = TRUE)
  allowed_functions <- c("+", "-", "*", "/", "^", "(", "exp", "log", "log1p", "sqrt", "plogis")
  allowed <- unique(c(predictors, parameter_names, allowed_functions))
  forbidden <- setdiff(symbols, allowed)
  if (length(forbidden)) stop("Non-linear formula contains unauthorized name:", paste(forbidden, collapse = ", "), call. = FALSE)
  formula
}

regression_readable_formula <- function(responses, predictors, scenario = "overall", group_var = "") {
  response_text <- paste(responses, collapse = ", ")
  predictor_text <- paste(predictors, collapse = " + ")
  switch(scenario,
    group_main = sprintf("%s is explained by the main effect of %s and group %s (same slope for each group)", response_text, predictor_text, group_var),
    group_interaction = sprintf("%s is explained by %s, group %s, and their interaction (allowing different slopes between groups)", response_text, predictor_text, group_var),
    group_independent = sprintf("Fit %s ~ %s separately within each level of %s", group_var, response_text, predictor_text),
    hierarchical = sprintf("%s ~ %s, and use %s as a level random effect", response_text, predictor_text, group_var),
    sprintf("The overall model of %s ~ %s", response_text, predictor_text)
  )
}
