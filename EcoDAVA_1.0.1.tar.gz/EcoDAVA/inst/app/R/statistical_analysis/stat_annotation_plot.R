# ggplot Mark the adapter as consuming onlyStandardAnnotation table，Do not restartFit a model or perform a statistical test。

add_cld_annotations <- function(p, annotation_data, x, group = "", size = 5, dodge_width = 0.78) {
  ann <- as.data.frame(annotation_data, stringsAsFactors = FALSE, check.names = FALSE)
  if (!inherits(p, "ggplot") || !nrow(ann) || !all(c(x, "y", "label") %in% names(ann))) return(p)
  mapping <- if (nzchar(group) && group %in% names(ann)) {
    ggplot2::aes(x = .data[[x]], y = .data$y, label = .data$label, group = .data[[group]])
  } else {
    ggplot2::aes(x = .data[[x]], y = .data$y, label = .data$label)
  }
  position <- if (nzchar(group) && group %in% names(ann)) ggplot2::position_dodge(width = dodge_width) else "identity"
  p + ggplot2::geom_text(data = ann, mapping = mapping, inherit.aes = FALSE, position = position, size = size, na.rm = TRUE)
}

add_bracket_annotations <- function(p, annotation_data, hide_ns = FALSE, tip_length = 0.01) {
  ann <- as.data.frame(annotation_data, stringsAsFactors = FALSE, check.names = FALSE)
  if (!inherits(p, "ggplot") || !nrow(ann)) return(p)
  required <- c("group1", "group2", "y", "label")
  if (!all(required %in% names(ann)) || !requireNamespace("ggpubr", quietly = TRUE)) return(p)
  ggpubr::stat_pvalue_manual(
    p, ann, label = "label", xmin = "group1", xmax = "group2", y.position = "y",
    hide.ns = isTRUE(hide_ns), tip.length = tip_length, inherit.aes = FALSE
  )
}

add_model_test_annotation <- function(p, effect_table, terms = character(), x = Inf, y = Inf, size = 4) {
  effects <- dava_normalize_effect_table(effect_table)
  if (!inherits(p, "ggplot") || !nrow(effects) || !"term" %in% names(effects)) return(p)
  if (length(terms)) effects <- effects[effects$term %in% terms, , drop = FALSE]
  if (!nrow(effects)) return(p)
  statistic_candidates <- intersect(
    c("statistic", "F", "Chisq", "F.value", "F-value", "t.value", "t-value", "z.value", "z-value"),
    names(effects)
  )
  statistic_col <- if (length(statistic_candidates)) statistic_candidates[[1L]] else ""
  statistic_name <- if (nzchar(statistic_col)) {
    if (grepl("chisq", statistic_col, ignore.case = TRUE)) "chi-square" else sub("\\.value$", "", statistic_col)
  } else "test"
  labels <- vapply(seq_len(nrow(effects)), function(i) {
    statistic <- if (nzchar(statistic_col)) sprintf("%s = %.3f, ", statistic_name, as.numeric(effects[[statistic_col]][i])) else ""
    paste0(gsub(":", " x ", effects$term[i]), ": ", statistic, format_p_value(effects$p_numeric[i]))
  }, character(1))
  p + ggplot2::annotate("text", x = x, y = y, label = paste(labels, collapse = "\n"),
                        hjust = 1.05, vjust = 1.15, size = size)
}

dava_add_result_annotations <- function(p, result, plot_data, x, group = "", panel_vars = character(),
                                        annotation_type = "cld", y_var = result$response,
                                        show_ns = TRUE, log_scale = FALSE, text_size = 5) {
  ann <- build_annotation_table(result, plot_data, y_var, annotation_type,
                                group_vars = unique(c(x, group)), panel_vars = panel_vars,
                                show_ns = show_ns, log_scale = log_scale)
  if (identical(annotation_type, "cld")) {
    return(add_cld_annotations(p, ann, x, group, text_size))
  }
  if (annotation_type %in% c("bracket_star", "bracket_p")) {
    return(add_bracket_annotations(p, ann, hide_ns = !show_ns))
  }
  p
}
