regression_reference_value <- function(x, mode = "mean") {
  if (is.numeric(x)) {
    if (identical(mode, "median")) stats::median(x, na.rm = TRUE) else mean(x, na.rm = TRUE)
  } else {
    values <- stats::na.omit(x)
    if (is.factor(x)) factor(levels(x)[1], levels = levels(x)) else as.character(values[1])
  }
}

build_adjusted_prediction_grid <- function(data, predictors, focus_predictor,
                                           group_var = "", scenario = "overall",
                                           reference_mode = "mean", points = 100L) {
  if (!nzchar(focus_predictor) || !focus_predictor %in% names(data)) return(data.frame())
  focus <- data[[focus_predictor]]
  focus_values <- if (is.numeric(focus)) {
    seq(min(focus, na.rm = TRUE), max(focus, na.rm = TRUE), length.out = max(20L, as.integer(points)))
  } else {
    if (is.factor(focus)) factor(levels(focus), levels = levels(focus)) else unique(as.character(focus))
  }
  grid <- data.frame(.focus = focus_values, check.names = FALSE)
  names(grid) <- focus_predictor
  for (variable in setdiff(predictors, focus_predictor)) {
    value <- regression_reference_value(data[[variable]], reference_mode)
    grid[[variable]] <- rep(value, nrow(grid))
  }
  if (nzchar(group_var) && group_var %in% names(data) && scenario %in% c("group_main", "group_interaction", "hierarchical")) {
    groups <- if (is.factor(data[[group_var]])) levels(data[[group_var]]) else unique(as.character(data[[group_var]]))
    grid <- merge(grid, stats::setNames(data.frame(groups, stringsAsFactors = FALSE), group_var), all = TRUE)
    if (is.factor(data[[group_var]])) grid[[group_var]] <- factor(grid[[group_var]], levels = levels(data[[group_var]]))
  }
  grid
}

predict_regression_safe <- function(model, newdata, method_id, level = 0.95, conditional = FALSE,
                                    ncomp = NULL, lambda = NULL, model_matrix_terms = NULL) {
  if (!nrow(newdata)) return(data.frame())
  alpha <- 1 - level
  result <- tryCatch({
    if (inherits(model, c("multinom", "polr"))) {
      probabilities <- as.matrix(stats::predict(model, newdata = newdata, type = "probs"))
      predicted <- max.col(probabilities, ties.method = "first")
      data.frame(predicted = predicted, conf.low = NA_real_, conf.high = NA_real_)
    } else if (inherits(model, c("betareg", "zeroinfl", "hurdle"))) {
      pred <- stats::predict(model, newdata = newdata, type = "response")
      data.frame(predicted = as.numeric(pred), conf.low = NA_real_, conf.high = NA_real_)
    } else if (inherits(model, "glm")) {
      pp <- stats::predict(model, newdata, type = "link", se.fit = TRUE)
      crit <- stats::qnorm(1 - alpha / 2)
      fam <- stats::family(model)
      data.frame(predicted = fam$linkinv(pp$fit), conf.low = fam$linkinv(pp$fit - crit * pp$se.fit),
                 conf.high = fam$linkinv(pp$fit + crit * pp$se.fit))
    } else if (inherits(model, "lm")) {
      pp <- stats::predict(model, newdata, interval = "confidence", level = level)
      data.frame(predicted = pp[, "fit"], conf.low = pp[, "lwr"], conf.high = pp[, "upr"])
    } else if (inherits(model, "glmmTMB")) {
      pred <- stats::predict(model, newdata = newdata, type = "response",
                             re.form = if (isTRUE(conditional)) NULL else NA, allow.new.levels = TRUE)
      data.frame(predicted = as.numeric(pred), conf.low = NA_real_, conf.high = NA_real_)
    } else if (inherits(model, "merMod")) {
      pred <- stats::predict(model, newdata, re.form = if (isTRUE(conditional)) NULL else NA, allow.new.levels = TRUE,
                             type = if (inherits(model, "glmerMod")) "response" else "link")
      data.frame(predicted = as.numeric(pred), conf.low = NA_real_, conf.high = NA_real_)
    } else if (inherits(model, c("mvr"))) {
      pred <- stats::predict(model, newdata = newdata, ncomp = ncomp)
      data.frame(predicted = as.numeric(pred), conf.low = NA_real_, conf.high = NA_real_)
    } else if (inherits(model, "cv.glmnet")) {
      mm <- stats::model.matrix(model_matrix_terms, newdata)[, -1, drop = FALSE]
      pred <- stats::predict(model, newx = mm, s = lambda %||% "lambda.min")
      data.frame(predicted = as.numeric(pred), conf.low = NA_real_, conf.high = NA_real_)
    } else if (inherits(model, "ranger")) {
      data.frame(predicted = as.numeric(stats::predict(model, data = newdata)$predictions), conf.low = NA_real_, conf.high = NA_real_)
    } else if (inherits(model, "xgb.Booster")) {
      mm <- stats::model.matrix(model_matrix_terms, newdata)[, -1, drop = FALSE]
      data.frame(predicted = as.numeric(stats::predict(model, mm)), conf.low = NA_real_, conf.high = NA_real_)
    } else {
      pred <- stats::predict(model, newdata = newdata)
      if (is.matrix(pred) && ncol(pred) > 1L) pred <- pred[, 1]
      data.frame(predicted = as.numeric(pred), conf.low = NA_real_, conf.high = NA_real_)
    }
  }, error = function(e) structure(data.frame(), error = conditionMessage(e)))
  if (nrow(result) != nrow(newdata)) return(structure(data.frame(), error = attr(result, "error") %||% "The number of rows in the prediction results is inconsistent"))
  cbind(newdata, result)
}
