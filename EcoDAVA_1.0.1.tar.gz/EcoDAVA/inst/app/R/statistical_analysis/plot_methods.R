# Lightweight reusable plotting helpers shared across analysis modules.

dava_plot_numeric_vars <- function(df) {
  names(df)[vapply(df, function(x) is.numeric(x) || is.integer(x), logical(1))]
}

dava_plot_factor_vars <- function(df) {
  setdiff(names(df), dava_plot_numeric_vars(df))
}

dava_plot_palette <- function(name = "Nature", n = 8) {
  name <- name %||% "Nature"
  n <- max(1, as.integer(n %||% 8))
  base <- switch(
    name,
    Nature = c("#3B7EA1", "#D95F02", "#1B9E77", "#7570B3", "#E7298A", "#66A61E", "#E6AB02", "#A6761D"),
    Nature_NPG = c("#E64B35", "#4DBBD5", "#00A087", "#3C5488", "#F39B7F", "#8491B4", "#91D1C2", "#DC0000", "#7E6148", "#B09C85"),
    Nature_Reviews = c("#0073C2", "#EFC000", "#868686", "#CD534C", "#7AA6DC", "#003C67", "#8F7700", "#3B3B3B"),
    Science_AAAS = c("#3B4992", "#EE0000", "#008B45", "#631879", "#008280", "#BB0021", "#5F559B", "#A20056"),
    Cell = c("#3C5488", "#00A087", "#E64B35", "#4DBBD5", "#F39B7F", "#8491B4", "#91D1C2", "#7E6148"),
    NEJM = c("#BC3C29", "#0072B5", "#E18727", "#20854E", "#7876B1", "#6F99AD", "#FFDC91", "#EE4C97"),
    Lancet = c("#00468B", "#ED0000", "#42B540", "#0099B4", "#925E9F", "#FDAF91", "#AD002A", "#ADB6B6"),
    JAMA = c("#374E55", "#DF8F44", "#00A1D5", "#B24745", "#79AF97", "#6A6599", "#80796B", "#F39B7F"),
    BMJ = c("#0066A4", "#E31B23", "#7F7F7F", "#00AEEF", "#F7941D", "#00A651", "#92278F", "#2E3192"),
    PNAS = c("#2E5C8A", "#E07A5F", "#3D405B", "#81B29A", "#F2CC8F", "#8D99AE", "#D62828", "#457B9D"),
    Microbiome = c("#1B9E77", "#D95F02", "#7570B3", "#E7298A", "#66A61E", "#E6AB02", "#A6761D", "#1F78B4", "#B2DF8A", "#FB9A99"),
    Ecology = c("#2A9D8F", "#E9C46A", "#F4A261", "#E76F51", "#264653", "#8AB17D", "#577590", "#BC4749"),
    Clinical = c("#1F77B4", "#D62728", "#2CA02C", "#9467BD", "#FF7F0E", "#17BECF", "#8C564B", "#7F7F7F"),
    Colorblind_OkabeIto = c("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7", "#000000"),
    Tol_Bright = c("#4477AA", "#EE6677", "#228833", "#CCBB44", "#66CCEE", "#AA3377", "#BBBBBB"),
    Tol_Muted = c("#332288", "#88CCEE", "#44AA99", "#117733", "#999933", "#DDCC77", "#CC6677", "#882255", "#AA4499", "#DDDDDD"),
    Viridis = if (requireNamespace("viridisLite", quietly = TRUE)) viridisLite::viridis(n) else grDevices::hcl.colors(n, "viridis"),
    Plasma = if (requireNamespace("viridisLite", quietly = TRUE)) viridisLite::plasma(n) else grDevices::hcl.colors(n, "plasma"),
    Inferno = if (requireNamespace("viridisLite", quietly = TRUE)) viridisLite::inferno(n) else grDevices::hcl.colors(n, "inferno"),
    Magma = if (requireNamespace("viridisLite", quietly = TRUE)) viridisLite::magma(n) else grDevices::hcl.colors(n, "magma"),
    Cividis = if (requireNamespace("viridisLite", quietly = TRUE)) viridisLite::cividis(n) else grDevices::hcl.colors(n, "cividis"),
    Set2 = if (requireNamespace("RColorBrewer", quietly = TRUE)) RColorBrewer::brewer.pal(min(max(n, 3), 8), "Set2") else grDevices::hcl.colors(n, "Set 2"),
    Dark2 = if (requireNamespace("RColorBrewer", quietly = TRUE)) RColorBrewer::brewer.pal(min(max(n, 3), 8), "Dark2") else grDevices::hcl.colors(n, "Dark 2"),
    Paired = if (requireNamespace("RColorBrewer", quietly = TRUE)) RColorBrewer::brewer.pal(min(max(n, 3), 12), "Paired") else grDevices::hcl.colors(n, "Pastel 1"),
    Spectral = if (requireNamespace("RColorBrewer", quietly = TRUE)) RColorBrewer::brewer.pal(min(max(n, 3), 11), "Spectral") else grDevices::hcl.colors(n, "Spectral"),
    RdBu = if (requireNamespace("RColorBrewer", quietly = TRUE)) RColorBrewer::brewer.pal(min(max(n, 3), 11), "RdBu") else grDevices::hcl.colors(n, "RdBu"),
    Scientific = c("#2C7FB8", "#D95F0E", "#31A354", "#756BB1", "#E6550D", "#636363", "#6BAED6", "#9ECAE1"),
    c("#3B7EA1", "#D95F02", "#1B9E77", "#7570B3", "#E7298A", "#66A61E", "#E6AB02", "#A6761D")
  )
  rep(base, length.out = n)
}

dava_plot_palette_choices <- function() {
  c(
    "Nature original color" = "Nature",
    "Nature Publishing Group" = "Nature_NPG",
    "Nature Reviews" = "Nature_Reviews",
    "Science / AAAS" = "Science_AAAS",
    "Cell Press" = "Cell",
    "NEJM" = "NEJM",
    "Lancet" = "Lancet",
    "JAMA" = "JAMA",
    "BMJ" = "BMJ",
    "PNAS" = "PNAS",
    "Microbiome / ecological microorganisms" = "Microbiome",
    "Ecology / Environmental Ecology" = "Ecology",
    "Clinical / Clinical Medicine" = "Clinical",
    "Okabe-Ito color blind friendly" = "Colorblind_OkabeIto",
    "Tol Bright color blind friendly" = "Tol_Bright",
    "Tol Muted color blind friendly" = "Tol_Muted",
    "Viridis" = "Viridis",
    "Plasma" = "Plasma",
    "Inferno" = "Inferno",
    "Magma" = "Magma",
    "Cividis" = "Cividis",
    "Set2" = "Set2",
    "Dark2" = "Dark2",
    "Paired" = "Paired",
    "Spectral" = "Spectral",
    "RdBu" = "RdBu",
    "Scientific" = "Scientific"
  )
}

dava_plot_theme_choices <- function() {
  c(
    "Publication Basics" = "publication",
    "Nature paper style" = "nature",
    "Science paper style" = "science",
    "Cell Press style" = "cell",
    "NEJM clinical style" = "nejm",
    "Lancet clinical style" = "lancet",
    "JAMA Clinical Style" = "jama",
    "PNAS simple style" = "pnas",
    "Minimal minimalist" = "minimal",
    "Classic" = "classic",
    "Clean Borderless" = "clean",
    "Prism chart style" = "prism",
    "Dark Presentation" = "dark"
  )
}

dava_significance_term_vars <- function(term) {
  term <- trimws(term %||% "")
  if (!nzchar(term)) return(character(0))
  unique(trimws(unlist(strsplit(term, "[:|]"))))
}

dava_significance_term_label <- function(term, language = "zh-CN") {
  if (grepl("|", term, fixed = TRUE)) {
    parts <- strsplit(term, "|", fixed = TRUE)[[1]]
    return(paste0(
      dava_translate_text("Simple effect:", language),
      " ", parts[1], " | ", paste(parts[-1], collapse = " x ")
    ))
  }
  vars <- dava_significance_term_vars(term)
  prefix <- if (length(vars) > 1) "Interaction effect:" else "Main effect:"
  paste0(dava_translate_text(prefix, language), " ", paste(vars, collapse = " x "))
}

dava_significance_term_choices <- function(terms, x, group = "", facet = "", extra = character(0),
                                           language = "en") {
  terms <- unique(as.character(terms %||% character(0)))
  displayed <- unique(c(x, group, facet, extra))
  displayed <- displayed[nzchar(displayed)]
  keep <- vapply(terms, function(term) {
    vars <- dava_significance_term_vars(term)
    length(vars) > 0 && x %in% vars && all(vars %in% displayed)
  }, logical(1))
  terms <- terms[keep]
  labels <- vapply(
    terms,
    function(term) dava_significance_term_label(term, language = language),
    character(1)
  )
  stats::setNames(terms, labels)
}

dava_significance_method_choices <- function() {
  c(
    "Automatic recommendation" = "auto",
    "Not marked" = "none",
    "CLD lowercase letters" = "cld_lower",
    "CLD uppercase letters" = "cld_upper",
    "CLD uppercase and lowercase double-layer simple effect" = "cld_dual",
    "Paired brackets + asterisk (single factor)" = "pairwise_star",
    "Paired brackets + corrected P value (single factor)" = "pairwise_pvalue",
    "Paired brackets + asterisks and P-value (single factor)" = "pairwise_both",
    "Selected overall effect + asterisk" = "omnibus_star",
    "Selected overall effect + P value" = "omnibus_pvalue",
    "Selected overall effect + asterisk and P value" = "omnibus_both",
    "Selected overall effect + CLD" = "omnibus_cld",
    "Summary of current model effects" = "model_summary",
    "Summary of current model effects + CLD" = "summary_cld"
  )
}

dava_test_result_contract <- function(result, summary, response, groups = character(0)) {
  result <- as.data.frame(result, stringsAsFactors = FALSE, check.names = FALSE)
  summary <- as.data.frame(summary, stringsAsFactors = FALSE, check.names = FALSE)
  groups <- as.character(groups)
  groups <- groups[!is.na(groups) & nzchar(groups)]
  x <- if (length(groups)) groups[[1L]] else ""
  if ("response" %in% names(result)) result <- result[result[["response"]] == response, , drop = FALSE]
  if ("response" %in% names(summary)) summary <- summary[summary[["response"]] == response, , drop = FALSE]

  pair_mask <- rep(FALSE, nrow(result))
  if (all(c("group1", "group2") %in% names(result))) {
    pair_mask <- !is.na(result[["group1"]]) & nzchar(as.character(result[["group1"]])) &
      !is.na(result[["group2"]]) & nzchar(as.character(result[["group2"]]))
  }
  posthoc <- result[pair_mask, , drop = FALSE]
  if (nrow(posthoc) > 0) {
    posthoc[["response"]] <- response
    if (!("term" %in% names(posthoc))) posthoc[["term"]] <- x
    posthoc[["term"]][is.na(posthoc[["term"]]) | !nzchar(as.character(posthoc[["term"]]))] <- x
    posthoc[["contrast"]] <- paste(posthoc[["group1"]], posthoc[["group2"]], sep = " - ")
    preferred_p <- if ("p.adjusted" %in% names(posthoc)) posthoc[["p.adjusted"]] else posthoc[["p.value"]]
    if ("p.value" %in% names(posthoc)) {
      use_adjusted <- is.finite(dava_pvalue_numeric(preferred_p))
      posthoc[["p.value"]][use_adjusted] <- preferred_p[use_adjusted]
    } else {
      posthoc[["p.value"]] <- preferred_p
    }
  }

  overall <- result[!pair_mask, , drop = FALSE]
  if (nrow(overall) == 0 && nrow(posthoc) > 0 && nzchar(x)) {
    overall <- posthoc[1, , drop = FALSE]
  }
  if (nrow(overall) > 0) {
    overall[["response"]] <- response
    if (!("term" %in% names(overall))) overall[["term"]] <- x
    overall[["term"]][is.na(overall[["term"]]) | !nzchar(as.character(overall[["term"]]))] <- x
    if (!("df" %in% names(overall)) && "parameter" %in% names(overall)) overall[["df"]] <- overall[["parameter"]]
    if (nrow(posthoc) > 0 && all(pair_mask) && "p.adjusted" %in% names(overall)) {
      overall[["p.value"]] <- overall[["p.adjusted"]]
    }
  }

  letters <- data.frame()
  if (nrow(posthoc) > 0 && nzchar(x) && x %in% names(summary) && requireNamespace("multcompView", quietly = TRUE)) {
    p_values <- dava_pvalue_numeric(posthoc[["p.value"]])
    names(p_values) <- paste(posthoc[["group1"]], posthoc[["group2"]], sep = "-")
    p_values <- p_values[is.finite(p_values)]
    if (length(p_values) > 0) {
      cld <- tryCatch(multcompView::multcompLetters(p_values)$Letters, error = function(e) NULL)
      if (!is.null(cld)) {
        letters <- summary[match(names(cld), as.character(summary[[x]])), , drop = FALSE]
        letters <- letters[!is.na(letters[[x]]), , drop = FALSE]
        letters[["response"]] <- response
        letters[["term"]] <- x
        letters[["letter"]] <- unname(cld[as.character(letters[[x]])])
        letters[["emmean"]] <- letters[["mean"]] %||% NA_real_
        letters[["SE"]] <- letters[["se"]] %||% 0
      }
    }
  }

  list(
    anova_table = overall,
    posthoc = posthoc,
    letters = letters,
    terms = unique(c(as.character(overall[["term"]] %||% character(0)), as.character(posthoc[["term"]] %||% character(0)))),
    standard_result = dava_new_analysis_result(
      response = response,
      fixed_factors = groups,
      effect_table = dava_normalize_effect_table(overall, response),
      interaction_status = list(
        focus_factor = x,
        conditioning_factors = setdiff(groups, x),
        averaging_factors = character(),
        interpretation = if (length(groups) > 1) {
          paste0("Compare ", x, " within ", paste(setdiff(groups, x), collapse = " x "))
        } else {
          paste0("Compare levels of ", x)
        },
        alpha = 0.05
      ),
      pairwise = posthoc,
      cld = letters,
      metadata = list(
        alpha = 0.05,
        adjust_used = {
          values <- unique(as.character(posthoc[["p.adjust.method"]] %||% ""))
          if (length(values) && !is.na(values[[1L]])) values[[1L]] else ""
        },
        result_validity = "valid"
      )
    )
  )
}

dava_symmetric_effect_plot <- function(summary_df, x, group, split, panel = "") {
  summary_df <- as.data.frame(summary_df, stringsAsFactors = FALSE, check.names = FALSE)
  required <- c(x, group, split, "mean", "se")
  if (!all(required %in% names(summary_df))) return(NULL)
  summary_df <- summary_df[stats::complete.cases(summary_df[, required, drop = FALSE]), , drop = FALSE]
  if (!nrow(summary_df)) return(NULL)
  split_levels <- unique(as.character(summary_df[[split]]))
  split_levels <- split_levels[!is.na(split_levels) & nzchar(split_levels)]
  if (length(split_levels) != 2) return(NULL)
  if (any(summary_df[["mean"]] < 0, na.rm = TRUE)) return(NULL)

  summary_df[[".dava_side"]] <- ifelse(as.character(summary_df[[split]]) == split_levels[1], -1, 1)
  summary_df[[".dava_value"]] <- summary_df[["mean"]] * summary_df[[".dava_side"]]
  low <- (summary_df[["mean"]] - summary_df[["se"]]) * summary_df[[".dava_side"]]
  high <- (summary_df[["mean"]] + summary_df[["se"]]) * summary_df[[".dava_side"]]
  summary_df[[".dava_low"]] <- pmin(low, high)
  summary_df[[".dava_high"]] <- pmax(low, high)
  dodge <- ggplot2::position_dodge(width = 0.78)

  p <- ggplot2::ggplot(
    summary_df,
    ggplot2::aes(y = .data[[x]], x = .data[[".dava_value"]], fill = .data[[group]])
  ) +
    ggplot2::geom_col(width = 0.68, position = dodge, alpha = 0.88) +
    ggplot2::geom_errorbar(
      ggplot2::aes(xmin = .data[[".dava_low"]], xmax = .data[[".dava_high"]]),
      width = 0.18,
      position = dodge,
      orientation = "y"
    ) +
    ggplot2::geom_vline(xintercept = 0, linewidth = 0.45) +
    ggplot2::scale_x_continuous(labels = function(value) abs(value)) +
    ggplot2::labs(
      x = NULL,
      y = x,
      subtitle = paste0(split_levels[1], "  <-   |   ->  ", split_levels[2])
    )
  if (nzchar(panel) && panel %in% names(summary_df)) {
    p <- p + ggplot2::facet_wrap(stats::as.formula(paste("~", panel)))
  }
  p
}

dava_add_symmetric_cld <- function(
    p, letters, response, term, x, group, split, data, y_span = 1,
    letter_case = c("lower", "upper"), dodge_width = 0.78) {
  letter_case <- match.arg(letter_case)
  if (!inherits(p, "ggplot") || !is.data.frame(data)) return(p)
  letters <- as.data.frame(letters, stringsAsFactors = FALSE, check.names = FALSE)
  required <- c("response", "term", "letter", "emmean", x, group, split)
  if (!all(required %in% names(letters))) return(p)
  dd <- dplyr::filter(letters, .data[["response"]] == response, .data[["term"]] == term)
  if (!nrow(dd)) return(p)
  split_levels <- unique(as.character(data[[split]]))
  split_levels <- split_levels[!is.na(split_levels) & nzchar(split_levels)]
  if (length(split_levels) != 2) return(p)
  dd[["emmean"]] <- suppressWarnings(as.numeric(dd[["emmean"]]))
  se_value <- if ("SE" %in% names(dd)) suppressWarnings(as.numeric(dd[["SE"]])) else 0
  se_value[!is.finite(se_value)] <- 0
  side <- ifelse(as.character(dd[[split]]) == split_levels[1], -1, 1)
  dd[[".dava_label_x"]] <- (dd[["emmean"]] + se_value + 0.05 * y_span) * side
  dd[[".dava_label"]] <- if (identical(letter_case, "upper")) toupper(dd[["letter"]]) else tolower(dd[["letter"]])
  dd <- dd[is.finite(dd[[".dava_label_x"]]), , drop = FALSE]
  if (!nrow(dd)) return(p)
  p + ggplot2::geom_text(
    data = dd,
    ggplot2::aes(y = .data[[x]], x = .data[[".dava_label_x"]], label = .data[[".dava_label"]], group = .data[[group]]),
    inherit.aes = FALSE,
    position = ggplot2::position_dodge(width = dodge_width),
    size = 4.6
  )
}

dava_dual_axis_effect_plot <- function(data, primary, secondary, x, group = "", panel = "") {
  data <- as.data.frame(data, stringsAsFactors = FALSE, check.names = FALSE)
  required <- unique(c(primary, secondary, x, group, panel))
  required <- required[nzchar(required)]
  if (!all(required %in% names(data))) return(NULL)
  data <- data[stats::complete.cases(data[, required, drop = FALSE]), , drop = FALSE]
  if (!nrow(data)) return(NULL)
  data[[primary]] <- suppressWarnings(as.numeric(data[[primary]]))
  data[[secondary]] <- suppressWarnings(as.numeric(data[[secondary]]))
  data <- data[is.finite(data[[primary]]) & is.finite(data[[secondary]]), , drop = FALSE]
  if (!nrow(data)) return(NULL)

  group_vars <- unique(c(x, group, panel))
  group_vars <- group_vars[nzchar(group_vars)]
  summary_df <- data |>
    dplyr::group_by(dplyr::across(dplyr::all_of(group_vars))) |>
    dplyr::summarise(
      primary_mean = mean(.data[[primary]], na.rm = TRUE),
      primary_se = stats::sd(.data[[primary]], na.rm = TRUE) / sqrt(sum(!is.na(.data[[primary]]))),
      secondary_mean = mean(.data[[secondary]], na.rm = TRUE),
      secondary_se = stats::sd(.data[[secondary]], na.rm = TRUE) / sqrt(sum(!is.na(.data[[secondary]]))),
      .groups = "drop"
    )
  primary_range <- range(c(summary_df[["primary_mean"]] - summary_df[["primary_se"]], summary_df[["primary_mean"]] + summary_df[["primary_se"]]), na.rm = TRUE)
  secondary_range <- range(c(summary_df[["secondary_mean"]] - summary_df[["secondary_se"]], summary_df[["secondary_mean"]] + summary_df[["secondary_se"]]), na.rm = TRUE)
  primary_span <- diff(primary_range)
  secondary_span <- diff(secondary_range)
  if (!is.finite(primary_span) || primary_span == 0) primary_span <- max(abs(primary_range), 1)
  if (!is.finite(secondary_span) || secondary_span == 0) secondary_span <- max(abs(secondary_range), 1)
  scale_ratio <- primary_span / secondary_span
  transform_secondary <- function(value) (value - secondary_range[1]) * scale_ratio + primary_range[1]
  summary_df[["secondary_plot"]] <- transform_secondary(summary_df[["secondary_mean"]])
  summary_df[["secondary_low"]] <- transform_secondary(summary_df[["secondary_mean"]] - summary_df[["secondary_se"]])
  summary_df[["secondary_high"]] <- transform_secondary(summary_df[["secondary_mean"]] + summary_df[["secondary_se"]])
  dodge <- ggplot2::position_dodge(width = 0.72)

  if (nzchar(group)) {
    p <- ggplot2::ggplot(summary_df, ggplot2::aes(x = .data[[x]])) +
      ggplot2::geom_col(ggplot2::aes(y = .data[["primary_mean"]], fill = .data[[group]]), width = 0.62, position = dodge, alpha = 0.82) +
      ggplot2::geom_errorbar(ggplot2::aes(ymin = .data[["primary_mean"]] - .data[["primary_se"]], ymax = .data[["primary_mean"]] + .data[["primary_se"]], group = .data[[group]]), width = 0.16, position = dodge) +
      ggplot2::geom_line(ggplot2::aes(y = .data[["secondary_plot"]], color = .data[[group]], group = .data[[group]]), linewidth = 0.95, position = dodge) +
      ggplot2::geom_point(ggplot2::aes(y = .data[["secondary_plot"]], color = .data[[group]], group = .data[[group]]), size = 2.8, position = dodge) +
      ggplot2::geom_errorbar(ggplot2::aes(ymin = .data[["secondary_low"]], ymax = .data[["secondary_high"]], color = .data[[group]], group = .data[[group]]), width = 0.12, position = dodge)
  } else {
    p <- ggplot2::ggplot(summary_df, ggplot2::aes(x = .data[[x]])) +
      ggplot2::geom_col(ggplot2::aes(y = .data[["primary_mean"]], fill = .data[[x]]), width = 0.62, alpha = 0.82) +
      ggplot2::geom_errorbar(ggplot2::aes(ymin = .data[["primary_mean"]] - .data[["primary_se"]], ymax = .data[["primary_mean"]] + .data[["primary_se"]]), width = 0.16) +
      ggplot2::geom_line(ggplot2::aes(y = .data[["secondary_plot"]], group = 1), linewidth = 0.95) +
      ggplot2::geom_point(ggplot2::aes(y = .data[["secondary_plot"]]), size = 2.8) +
      ggplot2::geom_errorbar(ggplot2::aes(ymin = .data[["secondary_low"]], ymax = .data[["secondary_high"]]), width = 0.12)
  }
  p <- p + ggplot2::scale_y_continuous(
    name = primary,
    sec.axis = ggplot2::sec_axis(
      ~ (. - primary_range[1]) / scale_ratio + secondary_range[1],
      name = secondary
    )
  )
  if (nzchar(panel) && panel %in% names(summary_df)) {
    p <- p + ggplot2::facet_wrap(stats::as.formula(paste("~", panel)))
  }
  p
}

dava_pvalue_numeric <- function(x) {
  x <- trimws(as.character(x))
  suppressWarnings(as.numeric(sub("^[<=>~ ]+", "", x)))
}

dava_pvalue_text <- function(x, digits = 3) {
  raw <- trimws(as.character(x %||% ""))[1]
  if (is.na(raw) || !nzchar(raw)) return("P = NA")
  value <- dava_pvalue_numeric(raw)
  if (!is.finite(value)) return("P = NA")
  if (exists("format_p_value", mode = "function", inherits = TRUE)) return(format_p_value(value, digits))
  if (value < 10^(-digits)) return(paste0("P < ", format(10^(-digits), nsmall = digits)))
  paste0("P = ", formatC(value, digits = digits, format = "f"))
}

dava_pvalue_star <- function(x) {
  value <- dava_pvalue_numeric(x)[1]
  if (!is.finite(value)) return("")
  if (exists("p_to_significance", mode = "function", inherits = TRUE)) return(p_to_significance(value))
  if (value < 0.0001) return("****")
  if (value < 0.001) return("***")
  if (value < 0.01) return("**")
  if (value < 0.05) return("*")
  "ns"
}

dava_significance_label <- function(term, p_value, method) {
  effect <- sub("^[^:]+:", "", dava_significance_term_label(term))
  star <- dava_pvalue_star(p_value)
  p_text <- dava_pvalue_text(p_value)
  detail <- switch(
    method,
    star = star,
    pvalue = p_text,
    star_pvalue = paste(star, p_text),
    ""
  )
  paste0(effect, ": ", detail)
}

dava_prepare_cld_annotation <- function(
    letters, response, term, data = NULL, y_span = 1,
    letter_case = c("lower", "upper"), label_offset = 0.08) {
  letter_case <- match.arg(letter_case)
  dd <- as.data.frame(letters, stringsAsFactors = FALSE, check.names = FALSE)
  term_vars <- dava_significance_term_vars(term)
  required <- c("response", "term", "letter", "emmean", term_vars)
  if (!nrow(dd) || !length(term_vars) || !all(required %in% names(dd))) return(data.frame())
  dd <- dplyr::filter(dd, .data[["response"]] == response, .data[["term"]] == term)
  if ("error" %in% names(dd)) {
    error_value <- as.character(dd[["error"]])
    dd <- dd[is.na(error_value) | !nzchar(trimws(error_value)), , drop = FALSE]
  }
  for (variable in term_vars) dd[[variable]] <- trimws(as.character(dd[[variable]]))
  complete_key <- stats::complete.cases(dd[, term_vars, drop = FALSE]) &
    apply(dd[, term_vars, drop = FALSE], 1, function(value) all(nzchar(value)))
  dd <- dd[complete_key, , drop = FALSE]
  if (!nrow(dd)) return(data.frame())

  dd[["emmean"]] <- suppressWarnings(as.numeric(dd[["emmean"]]))
  se_value <- if ("SE" %in% names(dd)) suppressWarnings(as.numeric(dd[["SE"]])) else rep(0, nrow(dd))
  se_value[!is.finite(se_value)] <- 0
  dd[[".dava_label"]] <- if (identical(letter_case, "upper")) toupper(dd[["letter"]]) else tolower(dd[["letter"]])
  dd[[".dava_y"]] <- dd[["emmean"]] + se_value + label_offset * y_span

  if (is.data.frame(data) && response %in% names(data) && all(term_vars %in% names(data))) {
    plot_data <- data
    for (variable in term_vars) plot_data[[variable]] <- trimws(as.character(plot_data[[variable]]))
    valid_data <- stats::complete.cases(plot_data[, c(response, term_vars), drop = FALSE]) &
      apply(plot_data[, term_vars, drop = FALSE], 1, function(value) all(nzchar(value)))
    plot_data <- plot_data[valid_data, , drop = FALSE]
    valid_keys <- unique(plot_data[, term_vars, drop = FALSE])
    dd <- dplyr::semi_join(dd, valid_keys, by = term_vars)
    position_df <- plot_data |>
      dplyr::group_by(dplyr::across(dplyr::all_of(term_vars))) |>
      dplyr::summarise(
        .dava_group_max = {
          values <- suppressWarnings(as.numeric(.data[[response]]))
          values <- values[is.finite(values)]
          if (length(values)) max(values) else NA_real_
        },
        .groups = "drop"
      )
    dd <- dplyr::left_join(dd, position_df, by = term_vars)
    use_max <- is.finite(dd[[".dava_group_max"]])
    dd[[".dava_y"]][use_max] <- dd[[".dava_group_max"]][use_max] + label_offset * y_span
  }
  dd <- dd[is.finite(dd[[".dava_y"]]) & nzchar(trimws(dd[[".dava_label"]])), , drop = FALSE]
  dd[!duplicated(dd[, term_vars, drop = FALSE]), , drop = FALSE]
}

dava_add_cld_geom <- function(p, annotation, x, group = "", dodge_width = 0.78, size = 5) {
  if (!inherits(p, "ggplot") || !nrow(annotation) || !(x %in% names(annotation))) return(p)
  if (nzchar(group) && group %in% names(annotation)) {
    return(p + ggplot2::geom_text(
      data = annotation,
      ggplot2::aes(x = .data[[x]], y = .data[[".dava_y"]], label = .data[[".dava_label"]], group = .data[[group]]),
      inherit.aes = FALSE,
      position = ggplot2::position_dodge(width = dodge_width),
      size = size
    ))
  }
  p + ggplot2::geom_text(
    data = annotation,
    ggplot2::aes(x = .data[[x]], y = .data[[".dava_y"]], label = .data[[".dava_label"]]),
    inherit.aes = FALSE,
    size = size
  )
}

dava_add_model_significance <- function(
    p, response, x, group = "", facet = "", term = "", method = "none",
    anova_table = data.frame(), posthoc = data.frame(), letters = data.frame(),
    data = NULL, y_span = 1, y_top = 1, dodge_width = 0.78, allow_pairwise = TRUE,
    label_offset = 0.08) {
  if (!inherits(p, "ggplot") || identical(method, "none") || !nzchar(term)) return(p)

  term_vars <- dava_significance_term_vars(term)
  if (!length(term_vars) || !x %in% term_vars) return(p)
  y_span <- if (is.finite(y_span) && y_span > 0) y_span else 1

  method <- switch(
    method,
    letter = "cld_lower",
    star = if (isTRUE(allow_pairwise)) "pairwise_star" else "omnibus_star",
    pvalue = if (isTRUE(allow_pairwise)) "pairwise_pvalue" else "omnibus_pvalue",
    star_pvalue = if (isTRUE(allow_pairwise)) "pairwise_both" else "omnibus_both",
    method
  )
  if (identical(method, "auto")) {
    method <- if (grepl("|", term, fixed = TRUE)) {
      "cld_lower"
    } else if (length(term_vars) == 1 && isTRUE(allow_pairwise)) {
      "pairwise_star"
    } else {
      "omnibus_cld"
    }
  }
  if (identical(method, "omnibus_cld")) {
    p <- dava_add_model_significance(
      p, response, x, group, facet, term, "cld_lower",
      anova_table, posthoc, letters, data, y_span, y_top, dodge_width,
      allow_pairwise = FALSE, label_offset = 0.08
    )
    return(dava_add_model_significance(
      p, response, x, group, facet, term, "omnibus_both",
      anova_table, posthoc, letters, data, y_span, y_top, dodge_width,
      allow_pairwise = FALSE, label_offset = 0.08
    ))
  }
  if (identical(method, "summary_cld")) {
    p <- dava_add_model_significance(
      p, response, x, group, facet, term, "cld_lower",
      anova_table, posthoc, letters, data, y_span, y_top, dodge_width,
      allow_pairwise = FALSE, label_offset = 0.08
    )
    method <- "model_summary"
  }
  if (identical(method, "cld_dual")) {
    if (grepl("|", term, fixed = TRUE)) {
      parts <- strsplit(term, "|", fixed = TRUE)[[1]]
      secondary_term <- paste(c(parts[-1], parts[1]), collapse = "|")
    } else if (length(term_vars) == 2) {
      term <- paste(term_vars[1], term_vars[2], sep = "|")
      secondary_term <- paste(term_vars[2], term_vars[1], sep = "|")
    } else {
      secondary_term <- ""
    }
    lower_data <- dava_prepare_cld_annotation(
      letters, response, term, data, y_span,
      letter_case = "lower", label_offset = 0.1
    )
    if (!nzchar(secondary_term)) return(dava_add_cld_geom(p, lower_data, x, group, dodge_width))
    upper_data <- dava_prepare_cld_annotation(
      letters, response, secondary_term, data, y_span,
      letter_case = "upper", label_offset = 0.1
    )
    key_vars <- union(dava_significance_term_vars(term), dava_significance_term_vars(secondary_term))
    if (nrow(lower_data) && nrow(upper_data) && all(key_vars %in% names(lower_data)) && all(key_vars %in% names(upper_data))) {
      lower_join <- lower_data[, c(key_vars, ".dava_label", ".dava_y"), drop = FALSE]
      upper_join <- upper_data[, c(key_vars, ".dava_label", ".dava_y"), drop = FALSE]
      names(lower_join)[names(lower_join) == ".dava_label"] <- ".dava_lower"
      names(lower_join)[names(lower_join) == ".dava_y"] <- ".dava_y_lower"
      names(upper_join)[names(upper_join) == ".dava_label"] <- ".dava_upper"
      names(upper_join)[names(upper_join) == ".dava_y"] <- ".dava_y_upper"
      combined <- dplyr::full_join(
        lower_join,
        upper_join,
        by = key_vars
      )
      combined[[".dava_upper"]][is.na(combined[[".dava_upper"]])] <- ""
      combined[[".dava_lower"]][is.na(combined[[".dava_lower"]])] <- ""
      combined[[".dava_label"]] <- paste0(combined[[".dava_upper"]], combined[[".dava_lower"]])
      combined[[".dava_y"]] <- pmax(combined[[".dava_y_lower"]], combined[[".dava_y_upper"]], na.rm = TRUE)
      combined <- combined[is.finite(combined[[".dava_y"]]) & nzchar(combined[[".dava_label"]]), , drop = FALSE]
      return(dava_add_cld_geom(p, combined, x, group, dodge_width))
    }
    fallback <- if (nrow(lower_data)) lower_data else upper_data
    return(dava_add_cld_geom(p, fallback, x, group, dodge_width))
  }

  anova_df <- as.data.frame(anova_table, stringsAsFactors = FALSE, check.names = FALSE)
  if (identical(method, "model_summary") && nrow(anova_df) > 0 &&
      all(c("response", "term") %in% names(anova_df))) {
    displayed <- unique(c(x, group, facet))
    displayed <- displayed[nzchar(displayed)]
    effect_df <- dplyr::filter(anova_df, .data[["response"]] == response)
    keep <- vapply(effect_df[["term"]], function(effect_term) {
      vars <- dava_significance_term_vars(effect_term)
      length(vars) > 0 && all(vars %in% displayed)
    }, logical(1))
    effect_df <- effect_df[keep, , drop = FALSE]
    p_candidates <- intersect(c("p.value", "p_value", "Pr(>F)", "Pr(>Chisq)", "p"), names(effect_df))
    p_col <- if (length(p_candidates)) p_candidates[[1L]] else ""
    if (nrow(effect_df) > 0 && nzchar(p_col)) {
      labels <- vapply(seq_len(nrow(effect_df)), function(i) {
        effect <- paste(dava_significance_term_vars(effect_df[["term"]][i]), collapse = "x")
        paste0(effect, ": ", dava_pvalue_star(effect_df[[p_col]][i]))
      }, character(1))
      return(p + ggplot2::annotate(
        "text", x = Inf, y = Inf, label = paste(labels, collapse = "\n"),
        hjust = 1.08, vjust = 1.25, size = 4.4, fontface = "bold"
      ))
    }
    return(p)
  }

  letters_df <- as.data.frame(letters, stringsAsFactors = FALSE, check.names = FALSE)
  if (method %in% c("cld_lower", "cld_upper") && nrow(letters_df) > 0 &&
      all(c("response", "term", "letter", "emmean") %in% names(letters_df))) {
    annotation <- dava_prepare_cld_annotation(
      letters, response, term, data, y_span,
      letter_case = if (identical(method, "cld_upper")) "upper" else "lower",
      label_offset = label_offset
    )
    return(dava_add_cld_geom(p, annotation, x, group, dodge_width))
  }

  posthoc_df <- as.data.frame(posthoc, stringsAsFactors = FALSE, check.names = FALSE)
  pairwise_method <- switch(
    method,
    pairwise_star = "star",
    pairwise_pvalue = "pvalue",
    pairwise_both = "star_pvalue",
    ""
  )
  if (nzchar(pairwise_method) && isTRUE(allow_pairwise) && identical(term, x) && nrow(posthoc_df) > 0 &&
      all(c("response", "term", "contrast", "p.value") %in% names(posthoc_df))) {
    pair_df <- dplyr::filter(posthoc_df, .data[["response"]] == response, .data[["term"]] == term)
    pair_df <- pair_df[!is.na(pair_df[["p.value"]]) & !grepl("|", pair_df[["term"]], fixed = TRUE), , drop = FALSE]
    if (nrow(pair_df) > 0 && nrow(pair_df) <= 6) {
      contrast_parts <- strsplit(as.character(pair_df[["contrast"]]), " - ", fixed = TRUE)
      valid <- lengths(contrast_parts) == 2
      pair_df <- pair_df[valid, , drop = FALSE]
      contrast_parts <- contrast_parts[valid]
      if (nrow(pair_df) > 0) {
        pair_df[["group1"]] <- vapply(contrast_parts, `[[`, character(1), 1)
        pair_df[["group2"]] <- vapply(contrast_parts, `[[`, character(1), 2)
        pair_df[["y.position"]] <- y_top + seq_len(nrow(pair_df)) * 0.075 * y_span
        pair_df[["label"]] <- vapply(pair_df[["p.value"]], function(value) {
          dava_significance_label(term, value, pairwise_method)
        }, character(1))
        pair_df[["label"]] <- sub(paste0("^", x, ": "), "", pair_df[["label"]])
        return(p + ggpubr::stat_pvalue_manual(
          pair_df,
          label = "label",
          xmin = "group1",
          xmax = "group2",
          y.position = "y.position",
          tip.length = 0.01,
          size = 4,
          inherit.aes = FALSE
        ))
      }
    }
  }

  omnibus_method <- switch(
    method,
    omnibus_star = "star",
    omnibus_pvalue = "pvalue",
    omnibus_both = "star_pvalue",
    ""
  )
  if (nzchar(omnibus_method) && nrow(anova_df) > 0 && all(c("response", "term") %in% names(anova_df))) {
    effect_row <- dplyr::filter(anova_df, .data[["response"]] == response, .data[["term"]] == term)
    p_candidates <- intersect(c("p.value", "p_value", "Pr(>F)", "Pr(>Chisq)", "p"), names(effect_row))
    p_col <- if (length(p_candidates)) p_candidates[[1L]] else ""
    if (nrow(effect_row) > 0 && nzchar(p_col)) {
      label <- dava_significance_label(term, effect_row[[p_col]][1], omnibus_method)
      statistic_candidates <- intersect(c("statistic", "F value", "Chisq"), names(effect_row))
      statistic_col <- if (length(statistic_candidates)) statistic_candidates[[1L]] else ""
      df_candidates <- intersect(c("df", "Df", "num.df"), names(effect_row))
      df_col <- if (length(df_candidates)) df_candidates[[1L]] else ""
      statistic <- if (nzchar(statistic_col)) suppressWarnings(as.numeric(effect_row[[statistic_col]][1])) else NA_real_
      df1 <- if (nzchar(df_col)) suppressWarnings(as.numeric(effect_row[[df_col]][1])) else NA_real_
      response_rows <- dplyr::filter(anova_df, .data[["response"]] == response)
      residual_row <- response_rows[grepl("residual", response_rows[["term"]], ignore.case = TRUE), , drop = FALSE]
      df2 <- if (nrow(residual_row) && nzchar(df_col) && df_col %in% names(residual_row)) {
        suppressWarnings(as.numeric(residual_row[[df_col]][1]))
      } else {
        NA_real_
      }
      if (is.finite(statistic)) {
        effect <- sub("^[^:]+:", "", dava_significance_term_label(term))
        method_text <- if ("method" %in% names(effect_row)) tolower(as.character(effect_row[["method"]][1])) else ""
        statistic_name <- if (grepl("wilcox|mann.whitney|signed.rank", method_text)) {
          "W"
        } else if (grepl("kruskal|friedman", method_text)) {
          "Chi-square"
        } else if (grepl("t.test|t test|welch", method_text)) {
          "t"
        } else {
          "F"
        }
        test_text <- if (is.finite(df1) && is.finite(df2) && identical(statistic_name, "F")) {
          sprintf("%s(%s, %s)=%.3g", statistic_name, format(df1, trim = TRUE), format(df2, trim = TRUE), statistic)
        } else if (is.finite(df1)) {
          sprintf("%s(%s)=%.3g", statistic_name, format(df1, trim = TRUE), statistic)
        } else {
          sprintf("%s=%.3g", statistic_name, statistic)
        }
        detail <- switch(
          omnibus_method,
          star = dava_pvalue_star(effect_row[[p_col]][1]),
          pvalue = dava_pvalue_text(effect_row[[p_col]][1]),
          star_pvalue = paste(dava_pvalue_star(effect_row[[p_col]][1]), dava_pvalue_text(effect_row[[p_col]][1])),
          ""
        )
        label <- paste0(effect, ": ", test_text, ", ", detail)
      }
      return(p + ggplot2::annotate(
        "text", x = Inf, y = Inf, label = label,
        hjust = 1.05, vjust = 1.4, size = 4.5, fontface = "bold"
      ))
    }
  }

  if (nzchar(omnibus_method) && grepl("|", term, fixed = TRUE) && nrow(posthoc_df) > 0 &&
      all(c("response", "term", "p.value") %in% names(posthoc_df))) {
    simple_df <- dplyr::filter(posthoc_df, .data[["response"]] == response, .data[["term"]] == term)
    condition_vars <- setdiff(term_vars, x)
    if (nrow(simple_df) > 0) {
      labels <- vapply(seq_len(nrow(simple_df)), function(i) {
        condition <- if (length(condition_vars) && all(condition_vars %in% names(simple_df))) {
          paste(vapply(condition_vars, function(v) as.character(simple_df[[v]][i]), character(1)), collapse = " x ")
        } else {
          paste0("Compare", i)
        }
        paste0(condition, ": ", sub("^.*: ", "", dava_significance_label(term, simple_df[["p.value"]][i], omnibus_method)))
      }, character(1))
      return(p + ggplot2::annotate(
        "text", x = Inf, y = Inf, label = paste(labels, collapse = "\n"),
        hjust = 1.05, vjust = 1.2, size = 4.2
      ))
    }
  }

  p
}

dava_plot_add_palette <- function(p, palette_name = "Nature", n = 12) {
  if (!inherits(p, "ggplot")) return(p)
  n <- max(1L, suppressWarnings(as.integer(n %||% 12)))
  mapped_variable <- function(mapping) {
    expression <- tryCatch(
      rlang::get_expr(mapping),
      error = function(error) NULL)
    if (is.null(expression)) return("")
    if (rlang::is_symbol(expression)) {
      return(rlang::as_string(expression))
    }
    if (rlang::is_call(expression, "$", n = 3L) &&
        rlang::is_symbol(expression[[2]], ".data")) {
      return(rlang::as_string(expression[[3]]))
    }
    if (rlang::is_call(expression, "[[", n = 3L) &&
        rlang::is_symbol(expression[[2]], ".data")) {
      field <- tryCatch(eval(expression[[3]]), error = function(error) "")
      if (is.character(field) && length(field) == 1L) return(field)
    }
    variables <- setdiff(all.vars(expression), ".data")
    if (length(variables) == 1L) variables[[1]] else ""
  }
  existing_scale_status <- function(aes_names) {
    scales <- p$scales$scales %||% list()
    matching <- Filter(function(scale) any(scale$aesthetics %in% aes_names), scales)
    if (!length(matching)) return("none")
    if (any(vapply(matching, function(scale) inherits(scale, "ScaleContinuous"), logical(1)))) {
      return("continuous")
    }
    "discrete"
  }
  mapped_levels <- function(aes_names) {
    mappings <- list(p$mapping)
    if (length(p$layers)) mappings <- c(mappings, lapply(p$layers, function(layer) layer$mapping))
    data_list <- list(p$data)
    if (length(p$layers)) data_list <- c(data_list, lapply(p$layers, function(layer) layer$data))
    levels <- character()
    for (mapping in mappings) {
      if (is.null(mapping)) next
      matched_aes <- aes_names[aes_names %in% names(mapping)]
      if (!length(matched_aes)) next
      aes_name <- matched_aes[[1]]
      var <- mapped_variable(mapping[[aes_name]])
      if (!nzchar(var)) next
      for (dat in data_list) {
        if (is.data.frame(dat) && var %in% names(dat) && !is.numeric(dat[[var]]) && !is.integer(dat[[var]])) {
          levels <- c(levels, as.character(dat[[var]]))
        }
      }
    }
    length(unique(levels[!is.na(levels) & nzchar(levels)]))
  }
  discrete_data_levels <- function() {
    data_list <- list(p$data)
    if (length(p$layers)) {
      data_list <- c(data_list, lapply(p$layers, function(layer) layer$data))
    }
    counts <- unlist(lapply(data_list, function(dat) {
      if (!is.data.frame(dat) || !ncol(dat)) return(integer())
      vapply(dat, function(value) {
        if (is.factor(value)) {
          value <- as.character(value)
        } else if (!is.character(value) && !is.logical(value)) {
          return(0L)
        }
        length(unique(value[!is.na(value) & nzchar(as.character(value))]))
      }, integer(1))
    }), use.names = FALSE)
    if (length(counts)) max(counts) else 0L
  }
  required_n <- max(
    n,
    mapped_levels(c("colour", "color")),
    mapped_levels(c("fill")),
    discrete_data_levels())
  pal <- dava_plot_palette(palette_name, required_n)
  mapped_status <- function(aes_names) {
    mappings <- list(p$mapping)
    if (length(p$layers)) mappings <- c(mappings, lapply(p$layers, function(layer) layer$mapping))
    data_list <- list(p$data)
    if (length(p$layers)) data_list <- c(data_list, lapply(p$layers, function(layer) layer$data))
    for (mapping in mappings) {
      if (is.null(mapping)) next
      matched_aes <- aes_names[aes_names %in% names(mapping)]
      if (!length(matched_aes)) next
      aes_name <- matched_aes[[1]]
      var <- mapped_variable(mapping[[aes_name]])
      if (!nzchar(var)) return("discrete")
      for (dat in data_list) {
        if (is.data.frame(dat) && var %in% names(dat)) {
          return(if (!is.numeric(dat[[var]]) && !is.integer(dat[[var]])) "discrete" else "continuous")
        }
      }
      return("discrete")
    }
    "none"
  }
  color_status <- existing_scale_status(c("colour", "color"))
  if (identical(color_status, "none")) color_status <- mapped_status(c("colour", "color"))
  fill_status <- existing_scale_status(c("fill"))
  if (identical(fill_status, "none")) fill_status <- mapped_status(c("fill"))
  if (identical(color_status, "discrete")) {
    p <- p + ggplot2::scale_color_manual(values = pal)
  }
  if (identical(fill_status, "discrete")) {
    p <- p + ggplot2::scale_fill_manual(values = pal)
  }
  p
}

dava_save_plot <- function(file, plot, device = c("png", "pdf"),
                           width = 8.8, height = 6.4, dpi = 300,
                           background = "transparent") {
  device <- match.arg(device)
  if (is.null(plot)) stop("There are currently no graphics available for download.", call. = FALSE)
  if (identical(device, "png")) {
    dava_open_png_device(
      file, width = width, height = height, units = "in", res = dpi,
      background = background)
  } else {
    dava_open_pdf_device(
      file, width = width, height = height, background = background)
  }
  on.exit(grDevices::dev.off(), add = TRUE)
  if (inherits(plot, "grob")) grid::grid.draw(plot) else print(plot)
  invisible(file)
}

dava_plot_pagination_ui <- function(ns, id) {
  tags$div(
    class = "d-flex align-items-center gap-1 flex-nowrap",
    actionButton(ns(paste0(id, "_prev")), "Previous page", class = "btn-outline-secondary btn-sm"),
    selectInput(ns(paste0(id, "_page")), NULL, choices = c("Page 1" = 1L), selected = 1L, width = "92px"),
    actionButton(ns(paste0(id, "_next")), "Next page", class = "btn-outline-secondary btn-sm")
  )
}

dava_plot_pagination_server <- function(input, session, id, total_pages) {
  page <- reactiveVal(1L)
  page_input <- paste0(id, "_page")
  observeEvent(total_pages(), {
    total <- max(1L, as.integer(total_pages()))
    current <- min(page(), total)
    page(current)
    updateSelectInput(session, page_input, choices = stats::setNames(seq_len(total), paste("No.", seq_len(total), "page")), selected = current)
  }, ignoreInit = FALSE)
  observeEvent(input[[paste0(id, "_prev")]], page(max(1L, page() - 1L)), ignoreInit = TRUE)
  observeEvent(input[[paste0(id, "_next")]], page(min(max(1L, as.integer(total_pages())), page() + 1L)), ignoreInit = TRUE)
  observeEvent(input[[page_input]], {
    requested <- suppressWarnings(as.integer(input[[page_input]]))
    if (is.finite(requested)) page(max(1L, min(requested, max(1L, as.integer(total_pages())))))
  }, ignoreInit = TRUE)
  observeEvent(page(), {
    updateSelectInput(session, page_input, selected = page())
  }, ignoreInit = TRUE)
  page
}

dava_paginate_plots <- function(items, page, rows, cols) {
  rows <- suppressWarnings(as.integer(rows)); cols <- suppressWarnings(as.integer(cols))
  if (!is.finite(rows) || rows < 1L) rows <- 1L
  if (!is.finite(cols) || cols < 1L) cols <- 2L
  capacity <- rows * cols
  total <- max(1L, ceiling(length(items) / capacity))
  page <- max(1L, min(suppressWarnings(as.integer(page)), total))
  page_items <- items
  if (length(items)) {
    index <- seq.int((page - 1L) * capacity + 1L, min(page * capacity, length(items)))
    page_items <- items[index]
  }
  list(items = page_items, page = page, total = total, rows = rows, cols = cols)
}

dava_plot_page_chunks <- function(items, rows, cols) {
  layout <- dava_paginate_plots(items, 1L, rows, cols)
  if (!length(items)) return(list())
  page_id <- ceiling(seq_along(items) / (layout$rows * layout$cols))
  unname(split(items, page_id))
}

dava_plot_size_ui <- function(ns, plot_id, size_id, width = 900, height = 700, extra_controls = NULL) {
  tagList(
    uiOutput(ns(paste0(size_id, "_frame_ui"))),
    tags$div(
      class = "dava-plot-size-controls",
      style = "display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:8px 4px 2px;border-top:1px solid #d7dde5;",
      tags$div(
        style = "display:flex;align-items:center;gap:8px;",
        tags$label(
          "Graphic width (px)",
          `for` = ns(paste0(size_id, "_width")),
          style = "margin:0;white-space:nowrap;"
        ),
        numericInput(
          ns(paste0(size_id, "_width")), NULL,
          value = width, min = 320, max = 5000, step = 10, width = "130px"
        )
      ),
      tags$div(
        style = "display:flex;align-items:center;gap:8px;",
        tags$label(
          "Graphic height (px)",
          `for` = ns(paste0(size_id, "_height")),
          style = "margin:0;white-space:nowrap;"
        ),
        numericInput(
          ns(paste0(size_id, "_height")), NULL,
          value = height, min = 240, max = 5000, step = 10, width = "130px"
        )
      ),
      checkboxInput(ns(paste0(size_id, "_lock")), "Lock aspect ratio", value = FALSE),
      extra_controls
    )
  )
}

# Factor-comparison analyses share the same grouped-plot mapping controls.
# Each module passes only existing input IDs; statistics are unchanged.
dava_factor_plot_controls_ui <- function(
    ns, ids, max_factors = 4L, include_response_combo = TRUE,
    default_mode = "single") {
  ids <- as.list(ids)
  required_ids <- c("response", "mode", "x", "group", "facet", "panel",
                    "plot_type", "significance", "effect")
  stopifnot(all(required_ids %in% names(ids)))

  multi_condition <- sprintf("input.%s == 'multi'", ids$mode)
  controls <- list(
    selectInput(ns(ids$response), "Plot response variables", choices = NULL),
    radioButtons(
      ns(ids$mode), "Drawing mode",
      choices = c("Single factor plot" = "single", "Multi-factor plot" = "multi"),
      selected = default_mode, inline = TRUE
    ),
    selectInput(ns(ids$x), "X-axis factors", choices = NULL)
  )

  multi_controls <- list()
  if (max_factors >= 2L) {
    multi_controls <- c(multi_controls, list(
      selectInput(ns(ids$group), "Grouping/Color Factors", choices = c("None" = ""))
    ))
  }
  if (max_factors >= 3L) {
    multi_controls <- c(multi_controls, list(
      selectInput(ns(ids$facet), "Left and right segmentation factors", choices = c("None" = ""))
    ))
  }
  if (max_factors >= 4L) {
    multi_controls <- c(multi_controls, list(
      selectInput(ns(ids$panel), "The fourth factor facet", choices = c("None" = ""))
    ))
  }
  if (length(multi_controls)) {
    controls <- c(controls, list(
      conditionalPanel(ns = ns, condition = multi_condition, do.call(tagList, multi_controls))
    ))
  }

  controls <- c(controls, list(
    selectInput(
      ns(ids$plot_type), "Graphic type",
      choices = c("Boxplot" = "boxplot", "Bar chart + SE" = "bar",
                  "Mean point and line chart" = "line", "Violin diagram" = "violin"),
      selected = "boxplot"
    ),
    selectInput(
      ns(ids$significance), "Salience annotation method",
      choices = dava_significance_method_choices(), selected = "auto"
    ),
    selectInput(ns(ids$effect), "Annotation Effect", choices = NULL)
  ))

  if (isTRUE(include_response_combo) &&
      all(c("combo_enabled", "combo_responses", "combo_rows", "combo_cols") %in% names(ids))) {
    controls <- c(controls, list(
      checkboxInput(ns(ids$combo_enabled), "Enable multi-response variable combination chart", value = FALSE),
      conditionalPanel(
        ns = ns,
        condition = sprintf("input.%s === true", ids$combo_enabled),
        shinyWidgets::pickerInput(
          ns(ids$combo_responses), "Combination Plot Response Variables", choices = NULL,
          selected = NULL, multiple = TRUE,
          options = list(`live-search` = TRUE, `actions-box` = TRUE)
        ),
        layout_columns(
          numericInput(ns(ids$combo_rows), "Number of layout rows", value = 1, min = 1, max = 8, step = 1),
          numericInput(ns(ids$combo_cols), "Number of layout columns", value = 2, min = 1, max = 8, step = 1),
          col_widths = c(6, 6)
        )
      )
    ))
  }

  do.call(tagList, controls)
}

dava_plot_size_server <- function(input, output, session, plot_id, size_id, width = 900, height = 700,
                                  content_ui = NULL) {
  dimensions <- reactive({
    width_px <- suppressWarnings(as.integer(input[[paste0(size_id, "_width")]] %||% width))
    height_px <- suppressWarnings(as.integer(input[[paste0(size_id, "_height")]] %||% height))
    if (!is.finite(width_px) || width_px < 320) width_px <- width
    if (!is.finite(height_px) || height_px < 240) height_px <- height
    list(
      width_px = width_px,
      height_px = height_px,
      width_in = width_px / 96,
      height_in = height_px / 96,
      lock_ratio = isTRUE(input[[paste0(size_id, "_lock")]])
    )
  })

  output[[paste0(size_id, "_frame_ui")]] <- renderUI({
    dims <- dimensions()
    frame_id <- session$ns(paste0(size_id, "_frame"))
    width_id <- session$ns(paste0(size_id, "_width"))
    height_id <- session$ns(paste0(size_id, "_height"))
    lock_id <- session$ns(paste0(size_id, "_lock"))
    frame_content <- if (is.function(content_ui)) {
      content_ui()
    } else {
      plotOutput(session$ns(plot_id), width = "100%", height = "100%")
    }
    frame <- tags$div(
      id = frame_id,
      class = "dava-resizable-plot-frame",
      style = sprintf(
        "width:%spx;max-width:100%%;height:auto;aspect-ratio:%s;min-width:0;min-height:0;overflow:hidden;border:1px solid #d7dde5;position:relative;",
        dims$width_px, dims$width_px / dims$height_px
      ),
      frame_content
    )
    shinyjqui::jqui_resizable(
      frame,
      options = list(
        minWidth = 320,
        minHeight = 240,
        handles = "se",
        aspectRatio = if (isTRUE(dims$lock_ratio)) dims$width_px / dims$height_px else FALSE,
        start = JS(sprintf(
          "function(event,ui){var lock=$('#%s').is(':checked');$(this).resizable('option','aspectRatio',lock ? ui.originalSize.width/ui.originalSize.height : false);}",
          lock_id
        )),
        resize = JS(sprintf(
          "function(event,ui){$('#%s').val(Math.round(ui.size.width));$('#%s').val(Math.round(ui.size.height));}",
          width_id, height_id
        )),
        stop = JS(sprintf(
          "function(event,ui){Shiny.setInputValue('%s',Math.round(ui.size.width),{priority:'event'});Shiny.setInputValue('%s',Math.round(ui.size.height),{priority:'event'});}",
          width_id, height_id
        ))
      )
    )
  })

  dimensions
}

dava_save_sized_plot <- function(file, plot, device = c("png", "pdf"), dimensions, dpi = 300) {
  device <- match.arg(device)
  if (identical(device, "png")) {
    dava_open_png_device(
      file, width = dimensions$width_px, height = dimensions$height_px,
      units = "px", res = dpi, background = "transparent")
    on.exit(grDevices::dev.off(), add = TRUE)
    if (inherits(plot, "grob")) grid::grid.draw(plot) else print(plot)
  } else {
    dava_save_plot(file, plot, "pdf", dimensions$width_in, dimensions$height_in, dpi)
  }
  invisible(file)
}

dava_plot_editor_svg_sized <- function(plot, dimensions) {
  if (!exists("layout_plot_svg_markup", mode = "function")) return(NULL)
  tryCatch(
    layout_plot_svg_markup(plot, width = dimensions$width_in, height = dimensions$height_in),
    error = function(e) NULL
  )
}

dava_plot_theme <- function(p, theme_name = "publication", base_size = 14, legend_position = "right", rotate_x = FALSE, show_legend = TRUE) {
  theme_name <- theme_name %||% "publication"
  base_size <- base_size %||% 14
  legend_position <- legend_position %||% "right"
  base <- switch(
    theme_name,
    classic = ggplot2::theme_classic(base_size = base_size),
    minimal = ggplot2::theme_minimal(base_size = base_size),
    clean = ggplot2::theme_minimal(base_size = base_size),
    nature = ggplot2::theme_classic(base_size = base_size),
    science = ggplot2::theme_bw(base_size = base_size),
    cell = ggplot2::theme_classic(base_size = base_size),
    nejm = ggplot2::theme_bw(base_size = base_size),
    lancet = ggplot2::theme_classic(base_size = base_size),
    jama = ggplot2::theme_bw(base_size = base_size),
    pnas = ggplot2::theme_minimal(base_size = base_size),
    prism = ggplot2::theme_classic(base_size = base_size),
    dark = ggplot2::theme_minimal(base_size = base_size),
    publication = ggplot2::theme_bw(base_size = base_size),
    ggplot2::theme_bw(base_size = base_size)
  )
  p <- p + base + ggplot2::theme(
    plot.title = ggplot2::element_text(face = "bold", hjust = 0, size = base_size + 2),
    legend.position = if (isTRUE(show_legend)) legend_position else "none",
    panel.grid.minor = ggplot2::element_blank()
  )
  if (theme_name %in% c("nature", "cell", "lancet", "prism")) {
    p <- p + ggplot2::theme(
      axis.line = ggplot2::element_line(linewidth = 0.45, color = "#1F2933"),
      axis.ticks = ggplot2::element_line(linewidth = 0.35, color = "#1F2933"),
      panel.grid.major = ggplot2::element_blank()
    )
  }
  if (theme_name %in% c("science", "nejm", "jama")) {
    p <- p + ggplot2::theme(
      panel.border = ggplot2::element_rect(linewidth = 0.55, color = "#1F2933", fill = NA),
      panel.grid.major = ggplot2::element_line(linewidth = 0.22, color = "#E5E7EB")
    )
  }
  if (identical(theme_name, "pnas")) {
    p <- p + ggplot2::theme(
      panel.grid.major = ggplot2::element_line(linewidth = 0.22, color = "#E6E8EB"),
      axis.line = ggplot2::element_line(linewidth = 0.35, color = "#374151")
    )
  }
  if (identical(theme_name, "clean")) {
    p <- p + ggplot2::theme(panel.grid.major = ggplot2::element_blank())
  }
  if (identical(theme_name, "dark")) {
    p <- p + ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = "#111827", color = NA),
      panel.background = ggplot2::element_rect(fill = "#111827", color = NA),
      panel.grid.major = ggplot2::element_line(color = "#374151", linewidth = 0.22),
      text = ggplot2::element_text(color = "#F9FAFB"),
      plot.title = ggplot2::element_text(color = "#F9FAFB", face = "bold", size = base_size + 2),
      axis.title = ggplot2::element_text(color = "#F9FAFB"),
      axis.text = ggplot2::element_text(color = "#E5E7EB"),
      legend.background = ggplot2::element_rect(fill = "#111827", color = NA),
      legend.key = ggplot2::element_rect(fill = "#111827", color = NA),
      legend.text = ggplot2::element_text(color = "#F9FAFB"),
      legend.title = ggplot2::element_text(color = "#F9FAFB")
    )
  }
  if (isTRUE(rotate_x)) {
    p <- p + ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 35, hjust = 1))
  }
  p
}

dava_plot_registry_entries <- function(file_data, reactive = FALSE) {
  if (isTRUE(reactive)) {
    file_data$plot_registry %||% list()
  } else {
    shiny::isolate(file_data$plot_registry %||% list())
  }
}

dava_svg_gallery_entries <- function(file_data, reactive = FALSE) {
  if (isTRUE(reactive)) {
    file_data$svg_gallery %||% list()
  } else {
    shiny::isolate(file_data$svg_gallery %||% list())
  }
}

dava_plot_registry_label <- function(value, fallback = "") {
  if (exists("plot_clean_label", mode = "function")) {
    return(plot_clean_label(value, fallback))
  }
  fallback <- fallback %||% ""
  fallback <- if (length(fallback) > 0) fallback[[1]] else ""
  value <- value %||% fallback
  if (length(value) == 0 || is.null(value)) value <- fallback
  value <- trimws(enc2utf8(as.character(value[[1]] %||% fallback)))
  escaped_unicode_pattern <- paste0("<", "U", "\\+[0-9A-Fa-f]+>")
  value <- gsub(escaped_unicode_pattern, "", value, perl = TRUE)
  if (!nzchar(value)) enc2utf8(as.character(fallback %||% "")) else value
}

dava_svg_gallery_safe_name <- function(name, fallback = "SVGEdit") {
  name <- dava_plot_registry_label(name, fallback)
  name <- gsub("[\\\\/:*?\"<>|]+", "_", name)
  name <- gsub("\\s+", "_", name)
  name <- trimws(name)
  if (!nzchar(name)) fallback else name
}

dava_svg_gallery_unique_name <- function(file_data, base_name) {
  gallery <- dava_svg_gallery_entries(file_data)
  base_name <- dava_svg_gallery_safe_name(base_name, "SVGEdit")
  existing <- names(gallery)
  if (!base_name %in% existing) return(base_name)
  i <- 1L
  repeat {
    candidate <- paste0(base_name, "_", i)
    if (!candidate %in% existing) return(candidate)
    i <- i + 1L
  }
}

dava_svg_gallery_register <- function(file_data, name, svg, source = "", source_path = "", meta = list()) {
  if (is.null(file_data) || !is.character(svg) || length(svg) == 0 || !grepl("<svg", svg[[1]], fixed = TRUE)) {
    return(invisible(FALSE))
  }
  name <- dava_svg_gallery_safe_name(name, "SVGEdit")
  gallery <- shiny::isolate(file_data$svg_gallery %||% list())
  gallery[[name]] <- list(
    name = name,
    title = name,
    path = paste("svg_gallery", name, sep = "/"),
    source = dava_plot_registry_label(source, "SVG Gallery"),
    source_path = source_path %||% "",
    type = "svg",
    svg = svg[[1]],
    editor_svg = svg[[1]],
    updated = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
    meta = meta %||% list()
  )
  file_data$svg_gallery <- gallery
  invisible(TRUE)
}

dava_plot_input_params <- function(input, include = NULL, exclude = character()) {
  vals <- tryCatch(shiny::isolate(shiny::reactiveValuesToList(input)), error = function(e) list())
  if (!is.null(include)) vals <- vals[intersect(include, names(vals))]
  drop_names <- unique(c(
    exclude,
    grep("(_click|_geometry|_markup|_state|^add_|^download_|^run_|^confirm_|^undo_|^redo_|^save_)", names(vals), value = TRUE)
  ))
  vals <- vals[setdiff(names(vals), drop_names)]
  Filter(function(x) {
    is.null(x) ||
      is.atomic(x) ||
      (is.list(x) && length(x) <= 20 && all(vapply(x, function(y) is.null(y) || is.atomic(y), logical(1))))
  }, vals)
}

dava_plot_build_editor_svg <- function(plot, type = NULL) {
  inferred_type <- type %||% if (inherits(plot, "ggplot")) "ggplot" else if (is.character(plot) && length(plot) == 1 && grepl("<svg", plot, fixed = TRUE)) "svg" else "object"
  if (identical(inferred_type, "svg")) return(plot)
  if (!identical(inferred_type, "ggplot")) return(NULL)
  if (!exists("layout_plot_svg_markup", mode = "function")) return(NULL)
  tryCatch(layout_plot_svg_markup(plot, width = 8.8, height = 6.4), error = function(e) NULL)
}

dava_plot_register <- function(file_data, path, plot, source = "", title = "", type = NULL, meta = list(), params = list(), code = NULL, editor_svg = NULL) {
  if (is.null(file_data)) return(invisible(FALSE))
  inferred_type <- type %||% if (inherits(plot, "ggplot")) "ggplot" else if (is.character(plot) && length(plot) == 1 && grepl("<svg", plot, fixed = TRUE)) "svg" else "object"
  if (!inferred_type %in% c("ggplot", "svg")) return(invisible(FALSE))
  if (is.null(editor_svg) || !is.character(editor_svg) || !length(editor_svg) || !grepl("<svg", editor_svg[[1]], fixed = TRUE)) {
    editor_svg <- dava_plot_build_editor_svg(plot, inferred_type)
  }
  editor_svg_import_template <- NULL
  if (is.character(editor_svg) && length(editor_svg) == 1L &&
      grepl("<svg", editor_svg, fixed = TRUE) &&
      exists("dava_prepare_svg_import_template", mode = "function")) {
    editor_svg_import_template <- tryCatch(
      dava_prepare_svg_import_template(editor_svg),
      error = function(e) NULL
    )
  }
  meta <- meta %||% list()
  params <- params %||% meta$params %||% meta$plot_params %||% list()
  registry <- shiny::isolate(file_data$plot_registry %||% list())
  registry[[path]] <- list(
    path = path,
    plot = plot,
    plot_object = plot,
    r_plot_object = if (inherits(plot, "ggplot")) plot else NULL,
    source = dava_plot_registry_label(source, ""),
    title = dava_plot_registry_label(title, path),
    type = inferred_type,
    updated = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
    meta = meta,
    params = params,
    plot_params = params,
    code = code,
    editor_svg = editor_svg,
    editor_svg_import_template = editor_svg_import_template,
    svg = editor_svg,
    svg_element_editable = is.character(editor_svg) && length(editor_svg) == 1 && grepl("<svg", editor_svg, fixed = TRUE)
  )
  file_data$plot_registry <- registry
  invisible(TRUE)
}

dava_plot_registry_table <- function(file_data) {
  registry <- dava_plot_registry_entries(file_data)
  if (length(registry) == 0) {
    return(data.frame(path = character(), source = character(), title = character(), type = character(), editable_svg = character(), updated = character()))
  }
  dplyr::bind_rows(lapply(registry, function(x) {
    data.frame(
      path = x$path %||% "",
      source = dava_plot_registry_label(x$source, ""),
      title = dava_plot_registry_label(x$title, x$path %||% ""),
      type = x$type %||% "",
      editable_svg = if (isTRUE(x$svg_element_editable %||% FALSE)) "Yes" else "No",
      updated = x$updated %||% "",
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }))
}

dava_plot_retheme <- function(p, input, title = NULL) {
  if (!inherits(p, "ggplot")) return(p)
  if (!is.null(title) && nzchar(title)) p <- p + ggplot2::labs(title = title)
  p <- suppressMessages(dava_plot_add_palette(p, input$layout_palette %||% input$palette %||% input$plot_palette %||% "Nature", 16))
  p <- dava_plot_theme(
    p,
    input$layout_theme %||% input$theme_name %||% "publication",
    input$layout_base_size %||% input$base_size %||% 14,
    input$layout_legend_position %||% input$legend_position %||% "right",
    input$layout_rotate_x %||% input$rotate_x %||% FALSE,
    input$layout_show_legend %||% input$show_legend %||% TRUE
  )
  p <- p + ggplot2::theme(
    plot.title = ggplot2::element_text(
      face = if (isTRUE(input$title_bold %||% TRUE)) "bold" else "plain",
      hjust = input$title_hjust %||% 0,
      size = (input$layout_base_size %||% input$base_size %||% 14) + 2,
      color = input$layout_text_color %||% "#1D3440"
    ),
    axis.title = ggplot2::element_text(size = input$axis_title_size %||% input$layout_base_size %||% 14, color = input$layout_text_color %||% "#1D3440"),
    axis.text = ggplot2::element_text(size = input$axis_text_size %||% max(8, (input$layout_base_size %||% 14) - 2), color = input$layout_text_color %||% "#1D3440"),
    legend.title = ggplot2::element_text(size = input$legend_title_size %||% input$layout_base_size %||% 14, color = input$layout_text_color %||% "#1D3440"),
    legend.text = ggplot2::element_text(size = input$legend_text_size %||% max(8, (input$layout_base_size %||% 14) - 2), color = input$layout_text_color %||% "#1D3440"),
    axis.line = ggplot2::element_line(color = input$layout_text_color %||% "#1D3440", linewidth = 0.35),
    axis.ticks = ggplot2::element_line(color = input$layout_text_color %||% "#1D3440", linewidth = 0.3),
    panel.border = ggplot2::element_rect(fill = NA, color = input$layout_text_color %||% "#1D3440", linewidth = 0.35),
    panel.grid.minor = ggplot2::element_blank()
  )
  if (isTRUE(input$layout_log_x)) p <- p + ggplot2::scale_x_log10()
  if (isTRUE(input$layout_log_y)) p <- p + ggplot2::scale_y_log10()
  if (isTRUE(input$layout_coord_flip)) p <- p + ggplot2::coord_flip()
  p
}

# Reusable result-plot controls. Modules keep their own plotting code and only
# opt into this presentation layer when a plot can safely be re-themed.
dava_result_plot_settings_id <- function(prefix, field) paste(prefix, field, sep = "_")

dava_plot_action_buttons_ui <- function(ns, add_id = "add_plot_to_library",
                                        png_id = "download_plot_png",
                                        pdf_id = "download_plot_pdf",
                                        boxed = TRUE) {
  buttons <- shiny::tags$div(
    class = "dava-plot-action-buttons d-flex gap-1 flex-nowrap",
    shiny::actionButton(
      ns(add_id), "Analysis plot library", icon = shiny::icon("plus"),
      title = "Add to Analysis Gallery",
      class = "btn-primary flex-fill"
    ),
    shiny::downloadButton(
      ns(png_id), "PNG", title = "Download PNG",
      class = "btn-success flex-fill"
    ),
    shiny::downloadButton(
      ns(pdf_id), "PDF", title = "Download PDF",
      class = "btn-outline-success flex-fill"
    )
  )
  content <- shiny::tagList(
    shiny::tags$style(shiny::HTML(
      ".dava-plot-action-buttons>.btn{min-width:0;padding:6px 7px;font-size:12px;white-space:nowrap;}"
    )),
    buttons
  )
  if (!isTRUE(boxed)) return(content)
  shiny::tags$div(
    class = "stat-box dava-plot-actions",
    shiny::tags$strong("Graphics operations"),
    content
  )
}

dava_result_plot_settings_ui <- function(ns, prefix, plot_label = "Current result graph",
                                         include_palette = TRUE, include_title = TRUE) {
  theme_choices <- dava_plot_theme_choices()
  palette_choices <- dava_plot_palette_choices()
  shiny::tagList(
    shiny::tags$div(class = "stat-box", shiny::tags$strong(plot_label)),
    if (include_title) shiny::textInput(ns(dava_result_plot_settings_id(prefix, "title")), "Graphic title", value = ""),
    shiny::selectInput(ns(dava_result_plot_settings_id(prefix, "theme")), "Topic", theme_choices, selected = "publication"),
    if (include_palette) shiny::selectInput(ns(dava_result_plot_settings_id(prefix, "palette")), "Colors", palette_choices, selected = "Nature"),
    shiny::sliderInput(ns(dava_result_plot_settings_id(prefix, "base_size")), "Basic font size", min = 8, max = 24, value = 14, step = 1),
    shiny::sliderInput(ns(dava_result_plot_settings_id(prefix, "x_angle")), "X-axis label angle", min = 0, max = 90, value = 0, step = 5),
    shiny::checkboxInput(ns(dava_result_plot_settings_id(prefix, "show_legend")), "Show legend", TRUE),
    shiny::selectInput(ns(dava_result_plot_settings_id(prefix, "legend_position")), "Legend location",
      c("Right" = "right", "Bottom" = "bottom", "Top" = "top", "Left" = "left"), selected = "right"),
    shiny::checkboxInput(ns(dava_result_plot_settings_id(prefix, "flip")), "Flip axis", FALSE)
  )
}

dava_result_plot_settings <- function(input, prefix) {
  value <- function(field, default = NULL) input[[dava_result_plot_settings_id(prefix, field)]] %||% default
  list(
    title = value("title", ""), theme = value("theme", "publication"), palette = value("palette", "Nature"),
    base_size = value("base_size", 14), x_angle = value("x_angle", 0),
    show_legend = isTRUE(value("show_legend", TRUE)), legend_position = value("legend_position", "right"),
    flip = isTRUE(value("flip", FALSE))
  )
}

dava_apply_result_plot_settings <- function(plot, settings) {
  if (is.null(plot) || !inherits(plot, "ggplot")) return(plot)
  plot <- suppressMessages(dava_plot_add_palette(plot, settings$palette %||% "Nature", 16))
  plot <- dava_plot_theme(plot, settings$theme %||% "publication", settings$base_size %||% 14,
    settings$legend_position %||% "right", FALSE, isTRUE(settings$show_legend)) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(
      angle = settings$x_angle %||% 0, hjust = if ((settings$x_angle %||% 0) == 0) 0.5 else 1
    ))
  if (nzchar(trimws(settings$title %||% ""))) plot <- plot + ggplot2::labs(title = trimws(settings$title))
  if (isTRUE(settings$flip)) plot <- plot + ggplot2::coord_flip()
  plot
}

dava_plot_english_text <- function(value) {
  if (!is.character(value)) return(value)
  exact <- c(
    "Variable importance" = "Variable importance",
    "Model average effect" = "Model-averaged effects",
    "Model weight sum" = "Sum of model weights",
    "Candidate model weights" = "Candidate-model weights",
    "Relative contribution (%)" = "Relative contribution (%)",
    "Relative contribution rate (%)" = "Relative contribution (%)",
    "Variable grouping" = "Variable group",
    "Regression coefficient estimates (95% CI)" = "Coefficient estimate (95% CI)",
    "Effect estimate" = "Effect estimate",
    "Features" = "Feature",
    "Mediating variable" = "Mediator",
    "Adjustment variable" = "Moderator",
    "Modulated variable W" = "Moderator W",
    "Conditional slope of X" = "Conditional slope of X",
    "Observations" = "Observed values",
    "Estimate" = "Estimate",
    "Importance" = "Importance",
    "Cross-validation error" = "Cross-validation error",
    "Standardized direct effects" = "Standardized direct effects",
    "Standardized indirect effects" = "Standardized indirect effects",
    "Normalized total effect" = "Standardized total effects",
    "Residual" = "Residuals", "Fitted value" = "Fitted values", "Predicted value" = "Predicted values",
    "variable" = "Variable", "Grouping" = "Group", "response variable" = "Response",
    "Frequency" = "Frequency", "Density" = "Density", "Correlation coefficient" = "Correlation coefficient",
    "Sample" = "Sample", "time" = "Time", "mean" = "Mean", "Standard deviation" = "Standard deviation",
    "Top 20 models sorted by information criteria" = "Top 20 models ranked by information criterion",
    "SHAP global feature contribution map" = "Global SHAP feature contribution",
    "SHAP average absolute contribution ranking" = "Mean absolute SHAP contribution",
    "SHAP interaction heat map" = "SHAP interaction heatmap",
    "SHAP feature importance" = "SHAP feature importance",
    "SHAP interaction strength network diagram" = "SHAP interaction-strength network",
    "SHAP dependency graph (all features)" = "SHAP dependence plots (all features)",
    "Feature-level multivariate correlations" = "Feature-level multivariable associations",
    "Feature effect forest plot" = "Feature-effect forest plot",
    "Mediation Effect and Bootstrap Confidence Interval" = "Mediation effects with bootstrap confidence intervals",
    "Adjustment effect simple slope" = "Simple slopes for moderation",
    "Johnson-Neyman significant interval" = "Johnson-Neyman significance region",
    "Residual-fitted value diagnostics" = "Residuals versus fitted values",
    "Regression coefficient" = "Regression coefficients",
    "Ingredients Score" = "Component scores", "payload" = "Loadings",
    "Regularized cross validation" = "Regularization cross-validation"
  )
  translate_one <- function(text) {
    if (is.na(text) || !nzchar(text)) return(text)
    if (text %in% names(exact)) return(unname(exact[[text]]))
    replacements <- c(
      "Importance" = "importance", "Interpretation rate" = "explained variation", "Effect" = "effect",
      "Estimate" = "estimate", "Confidence interval" = "confidence interval", "Significance" = "significance",
      "Relevance" = "correlation", "Heat map" = "heatmap", "Network diagram" = "network",
      "Scatter plot" = "scatter plot", "Boxplot" = "boxplot", "Bar chart" = "bar plot",
      "Observations" = "observed values", "Features" = "feature", "payload" = "loading",
      "Cross validation" = "cross-validation", "Standardization" = "standardized", "Contribution rate" = "contribution",
      "model" = "model", "variable" = "variable", "Grouping" = "group", "Sample" = "sample",
      "Residual" = "residual", "Fitted value" = "fitted value", "Predicted value" = "predicted value",
      "mean" = "mean", "Frequency" = "frequency", "Density" = "density"
    )
    for (pattern in names(replacements)) text <- gsub(pattern, replacements[[pattern]], text, fixed = TRUE)
    text
  }
  vapply(value, translate_one, character(1), USE.NAMES = FALSE)
}

dava_plot_english_labels <- function(plot) {
  # Scientific figures are result output. Interface-language changes must not
  # rewrite titles, axes, legends, annotations, or composite-plot captions.
  plot
}

dava_is_composite_plot <- function(plot) inherits(plot, "patchwork") && length(plot) > 1L

dava_plot_object_prefix <- function(prefix, index) paste0(prefix, "_object_", as.integer(index))

dava_plot_object_label <- function(plot, index) {
  title <- plot$labels$title %||% ""
  if (is.expression(title) || is.language(title)) title <- paste(deparse(title), collapse = " ")
  title <- as.character(title %||% "")[1]
  if (!nzchar(title) || is.na(title)) title <- paste("Plot object", index)
  sprintf("%d. %s", index, title)
}

dava_plot_object_capabilities <- function(plot) {
  geom_classes <- if (inherits(plot, "ggplot")) vapply(plot$layers,
    function(layer) class(layer$geom)[1], character(1)) else character()
  colour_scales <- if (inherits(plot, "ggplot")) Filter(function(scale) {
    any(scale$aesthetics %in% c("colour", "color", "fill"))
  }, plot$scales$scales) else list()
  continuous_colour <- any(vapply(colour_scales,
    function(scale) inherits(scale, "ScaleContinuous"), logical(1)))
  list(
    palette = !continuous_colour,
    point = any(grepl("Geom(Point|Jitter|Count)", geom_classes)),
    line = any(grepl("Geom(Line|Path|Segment|Errorbar|Smooth|Hline|Vline)", geom_classes)),
    alpha = length(geom_classes) > 0L
  )
}

dava_plot_object_settings_ui <- function(ns, prefix, plot, label = "Plot object", include_alpha = TRUE) {
  capability <- dava_plot_object_capabilities(plot)
  shiny::tagList(
    dava_result_plot_settings_ui(ns, prefix, paste0("Graphic object:", label),
      include_palette = capability$palette),
    shiny::textInput(ns(dava_result_plot_settings_id(prefix, "x_label")), "X-axis label", value = ""),
    shiny::textInput(ns(dava_result_plot_settings_id(prefix, "y_label")), "Y-axis label", value = ""),
    if (capability$point) shiny::sliderInput(
      ns(dava_result_plot_settings_id(prefix, "point_size")), "Point size",
      min = 0.5, max = 10, value = 3, step = 0.25),
    if (capability$line) shiny::sliderInput(
      ns(dava_result_plot_settings_id(prefix, "line_width")), "Line width",
      min = 0.2, max = 4, value = 0.8, step = 0.1),
    if (capability$alpha && isTRUE(include_alpha)) shiny::sliderInput(
      ns(dava_result_plot_settings_id(prefix, "alpha")), "Opacity",
      min = 0.1, max = 1, value = 1, step = 0.05)
  )
}

dava_composite_plot_settings_ui <- function(ns, plot, prefix, label = "graphics object") {
  if (!dava_is_composite_plot(plot)) return(NULL)
  indices <- seq_len(length(plot))
  labels <- vapply(indices, function(index) dava_plot_object_label(plot[[index]], index), character(1))
  selector_id <- dava_result_plot_settings_id(prefix, "selected_object")
  shiny::tagList(
    shiny::selectInput(ns(selector_id), "Graphical property object",
      choices = stats::setNames(as.list(as.character(indices)), labels), selected = "1"),
    lapply(indices, function(index) shiny::conditionalPanel(
      condition = sprintf("input['%s'] === '%s'", ns(selector_id), index),
      dava_plot_object_settings_ui(ns, dava_plot_object_prefix(prefix, index), plot[[index]], labels[index])
    ))
  )
}

dava_plot_object_settings <- function(input, prefix) {
  settings <- dava_result_plot_settings(input, prefix)
  value <- function(field, default = NULL) input[[dava_result_plot_settings_id(prefix, field)]] %||% default
  settings$x_label <- value("x_label", "")
  settings$y_label <- value("y_label", "")
  settings$point_size <- value("point_size", NULL)
  settings$line_width <- value("line_width", NULL)
  settings$alpha <- value("alpha", NULL)
  settings
}

dava_apply_plot_object_settings <- function(plot, settings) {
  if (is.null(plot) || !inherits(plot, "ggplot")) return(plot)
  plot <- dava_apply_result_plot_settings(plot, settings)
  if (nzchar(trimws(settings$x_label %||% ""))) plot <- plot + ggplot2::labs(x = trimws(settings$x_label))
  if (nzchar(trimws(settings$y_label %||% ""))) plot <- plot + ggplot2::labs(y = trimws(settings$y_label))
  if (length(plot$layers)) {
    for (index in seq_along(plot$layers)) {
      geom_class <- class(plot$layers[[index]]$geom)[1]
      if (!is.null(settings$point_size) && grepl("Geom(Point|Jitter|Count)", geom_class)) {
        plot$layers[[index]]$aes_params$size <- as.numeric(settings$point_size)
      }
      if (!is.null(settings$line_width) &&
          grepl("Geom(Line|Path|Segment|Errorbar|Smooth|Hline|Vline)", geom_class)) {
        plot$layers[[index]]$aes_params$linewidth <- as.numeric(settings$line_width)
      }
      if (!is.null(settings$alpha)) plot$layers[[index]]$aes_params$alpha <- as.numeric(settings$alpha)
    }
  }
  dava_plot_english_labels(plot)
}

dava_apply_composite_plot_settings <- function(plot, input, prefix, apply_single = FALSE) {
  if (dava_is_composite_plot(plot)) {
    for (index in seq_len(length(plot))) {
      child_prefix <- dava_plot_object_prefix(prefix, index)
      plot[[index]] <- dava_apply_plot_object_settings(plot[[index]],
        dava_plot_object_settings(input, child_prefix))
    }
    return(dava_plot_english_labels(plot))
  }
  if (isTRUE(apply_single) && inherits(plot, "ggplot")) {
    return(dava_apply_plot_object_settings(plot, dava_plot_object_settings(input, prefix)))
  }
  dava_plot_english_labels(plot)
}

dava_plot_summarise_group <- function(df, x, y, group = "", summary_fun = "mean") {
  group_vars <- c(x, group)
  group_vars <- group_vars[nzchar(group_vars) & group_vars %in% names(df)]
  df |>
    dplyr::group_by(dplyr::across(dplyr::all_of(group_vars))) |>
    dplyr::summarise(
      n = sum(!is.na(.data[[y]])),
      mean = mean(.data[[y]], na.rm = TRUE),
      median = stats::median(.data[[y]], na.rm = TRUE),
      sd = stats::sd(.data[[y]], na.rm = TRUE),
      se = sd / sqrt(n),
      .groups = "drop"
    ) |>
    dplyr::mutate(value = if ((summary_fun %||% "mean") == "median") median else mean) |>
    as.data.frame()
}

dava_plot_corr_df <- function(df, vars, method = "pearson") {
  vars <- vars[vars %in% names(df)]
  mat <- stats::cor(df[, vars, drop = FALSE], use = "pairwise.complete.obs", method = method %||% "pearson")
  as.data.frame(as.table(mat), stringsAsFactors = FALSE) |>
    stats::setNames(c("var1", "var2", "correlation"))
}

dava_plot_box <- function(df, x, y, fill = "", input = list(), title = NULL) {
  fill_var <- if (nzchar(fill %||% "") && fill %in% names(df)) fill else x
  pal <- dava_plot_palette(input$plot_palette %||% input$palette_name %||% "Nature", length(unique(df[[fill_var]])))
  p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[[x]], y = .data[[y]], fill = .data[[fill_var]])) +
    ggplot2::geom_boxplot(width = 0.65, alpha = input$plot_alpha %||% input$alpha %||% 0.75, outlier.shape = NA) +
    ggplot2::geom_jitter(width = 0.12, size = input$point_size %||% 2.2, alpha = 0.55) +
    ggplot2::scale_fill_manual(values = pal) +
    ggplot2::labs(title = title %||% input$plot_title %||% y, x = x, y = y, fill = fill_var)
  dava_plot_theme(p, input$plot_theme %||% input$theme_name %||% "publication", input$plot_base_size %||% input$base_size %||% 14, input$legend_position %||% "right", input$rotate_x %||% FALSE, input$show_legend %||% TRUE)
}

dava_plot_bar_summary <- function(df, x, y, fill = "", input = list(), title = NULL) {
  fill_var <- if (nzchar(fill %||% "") && fill %in% names(df)) fill else x
  dat <- dava_plot_summarise_group(df, x, y, if (identical(fill_var, x)) "" else fill_var, input$summary_fun %||% "mean")
  pos <- if (!identical(fill_var, x)) ggplot2::position_dodge(width = 0.78) else "stack"
  pal <- dava_plot_palette(input$plot_palette %||% input$palette_name %||% "Nature", length(unique(dat[[fill_var]])))
  p <- ggplot2::ggplot(dat, ggplot2::aes(x = .data[[x]], y = value, fill = .data[[fill_var]])) +
    ggplot2::geom_col(width = 0.66, alpha = input$plot_alpha %||% input$alpha %||% 0.85, position = pos) +
    ggplot2::geom_errorbar(ggplot2::aes(ymin = value - se, ymax = value + se), width = 0.18, position = pos) +
    ggplot2::scale_fill_manual(values = pal) +
    ggplot2::labs(title = title %||% input$plot_title %||% y, x = x, y = input$summary_fun %||% "mean", fill = fill_var)
  dava_plot_theme(p, input$plot_theme %||% input$theme_name %||% "publication", input$plot_base_size %||% input$base_size %||% 14, input$legend_position %||% "right", input$rotate_x %||% FALSE, input$show_legend %||% TRUE)
}

dava_plot_scatter <- function(df, x, y, color = "", label = "", input = list(), title = NULL) {
  color_var <- if (nzchar(color %||% "") && color %in% names(df)) color else NULL
  p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[[x]], y = .data[[y]], color = if (!is.null(color_var)) .data[[color_var]] else NULL)) +
    ggplot2::geom_point(size = input$point_size %||% 2.4, alpha = input$plot_alpha %||% input$alpha %||% 0.8)
  if (isTRUE(input$show_smooth)) p <- p + ggplot2::geom_smooth(method = input$smooth_method %||% "lm", se = input$show_ci %||% TRUE)
  if (nzchar(label %||% "") && label %in% names(df) && requireNamespace("ggrepel", quietly = TRUE)) {
    p <- p + ggrepel::geom_text_repel(ggplot2::aes(label = .data[[label]]), max.overlaps = 30)
  }
  p <- p + ggplot2::labs(title = title %||% input$plot_title %||% paste(y, "vs", x), x = x, y = y, color = color_var)
  dava_plot_theme(p, input$plot_theme %||% input$theme_name %||% "publication", input$plot_base_size %||% input$base_size %||% 14, input$legend_position %||% "right", input$rotate_x %||% FALSE, input$show_legend %||% TRUE)
}

dava_plot_corr_heatmap <- function(df, vars, input = list(), method = "pearson", title = NULL) {
  dat <- dava_plot_corr_df(df, vars, method)
  p <- ggplot2::ggplot(dat, ggplot2::aes(x = var1, y = var2, fill = correlation)) +
    ggplot2::geom_tile(color = "white") +
    ggplot2::scale_fill_gradient2(low = "#B2182B", mid = "white", high = "#2166AC", midpoint = 0, limits = c(-1, 1)) +
    ggplot2::labs(title = title %||% input$plot_title %||% "Correlation heatmap", x = NULL, y = NULL, fill = "r")
  if (isTRUE(input$show_corr_values)) {
    p <- p + ggplot2::geom_text(ggplot2::aes(label = sprintf("%.2f", correlation)), size = (input$plot_base_size %||% input$base_size %||% 14) / 4)
  }
  dava_plot_theme(p, input$plot_theme %||% input$theme_name %||% "publication", input$plot_base_size %||% input$base_size %||% 14, input$legend_position %||% "right", TRUE, input$show_legend %||% TRUE)
}
