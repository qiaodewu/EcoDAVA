# Multiple factorsEffectLevelDecision。SignificantlyWhen higher-order interactions exist，MasterEffectCan't leaveConditionsExplanation。

dava_effect_vars <- function(term) {
  term <- trimws(as.character(term %||% ""))
  if (!nzchar(term)) return(character())
  unique(trimws(strsplit(term, "[:*|]", perl = TRUE)[[1]]))
}

dava_canonical_effect <- function(term) {
  paste(sort(dava_effect_vars(term)), collapse = ":")
}

detect_significant_interactions <- function(effect_table, factors, alpha = 0.05) {
  effects <- dava_normalize_effect_table(effect_table)
  if (!nrow(effects) || !"term" %in% names(effects)) return(effects[0, , drop = FALSE])
  factors <- as.character(factors)
  factors <- unique(factors[!is.na(factors) & nzchar(factors)])
  order <- vapply(effects$term, function(x) length(dava_effect_vars(x)), integer(1))
  within_model <- vapply(effects$term, function(x) all(dava_effect_vars(x) %in% factors), logical(1))
  effects$effect_order <- order
  effects[within_model & order > 1 & is.finite(effects$p_numeric) & effects$p_numeric < alpha, , drop = FALSE]
}

build_emmeans_formula <- function(focus_factor, conditioning_factors = character()) {
  focus_factor <- trimws(focus_factor %||% "")
  conditioning_factors <- as.character(conditioning_factors)
  conditioning_factors <- unique(conditioning_factors[!is.na(conditioning_factors) & nzchar(conditioning_factors)])
  if (!nzchar(focus_factor)) return(NULL)
  rhs <- if (length(conditioning_factors)) {
    paste0(focus_factor, " | ", paste(conditioning_factors, collapse = " * "))
  } else {
    focus_factor
  }
  stats::as.formula(paste("~", rhs))
}

determine_comparison_strategy <- function(effect_table, factors, alpha = 0.05, focus_factor = NULL) {
  factors <- unique(as.character(factors))
  factors <- factors[!is.na(factors) & nzchar(factors)]
  factors <- factors[seq_len(min(4, length(factors)))]
  focus_factor <- focus_factor %||% if (length(factors)) factors[[1L]] else ""
  if (is.na(focus_factor) || !(focus_factor %in% factors)) {
    focus_factor <- if (length(factors)) factors[[1L]] else ""
  }
  effects <- dava_normalize_effect_table(effect_table)
  significant <- detect_significant_interactions(effects, factors, alpha)

  selected <- data.frame()
  if (nrow(significant)) {
    includes_focus <- vapply(significant$term, function(x) focus_factor %in% dava_effect_vars(x), logical(1))
    candidates <- significant[includes_focus, , drop = FALSE]
    if (nrow(candidates)) {
      max_order <- max(candidates$effect_order)
      selected <- candidates[candidates$effect_order == max_order, , drop = FALSE][1, , drop = FALSE]
    }
  }

  if (nrow(selected)) {
    selected_vars <- dava_effect_vars(selected$term[1])
    conditioning <- setdiff(selected_vars, focus_factor)
    averaging <- setdiff(factors, selected_vars)
    scope <- paste0("Compare ", focus_factor, " within every ", paste(conditioning, collapse = " x "), " combination")
    level <- "simple_effect"
    allow_main <- FALSE
    highest <- as.character(selected$term[1])
    highest_p <- selected$p_numeric[1]
  } else {
    conditioning <- character()
    averaging <- setdiff(factors, focus_factor)
    scope <- if (length(averaging)) {
      paste0("Compare marginal means of ", focus_factor, " averaged over ", paste(averaging, collapse = ", "))
    } else {
      paste0("Compare levels of ", focus_factor)
    }
    level <- "main_effect"
    allow_main <- TRUE
    highest <- focus_factor
    row <- effects[vapply(effects$term %||% character(), function(x) identical(dava_canonical_effect(x), dava_canonical_effect(focus_factor)), logical(1)), , drop = FALSE]
    highest_p <- if (nrow(row)) row$p_numeric[1] else NA_real_
  }

  factor_count <- length(factors)
  layout <- switch(as.character(factor_count),
    "1" = "x",
    "2" = "x_group",
    "3" = "x_group_facet",
    "4" = "x_group_facet_grid",
    "x"
  )
  list(
    factor_count = factor_count,
    highest_significant_effect = highest,
    highest_order_interaction = if (nrow(selected)) highest else "",
    highest_order_p = highest_p,
    significant = nrow(selected) > 0,
    interpretation_level = level,
    comparison_formula = build_emmeans_formula(focus_factor, conditioning),
    focus_factor = focus_factor,
    conditioning_factors = conditioning,
    averaging_factors = averaging,
    annotation_type = if (length(conditioning)) "cld_within_panel" else "cld",
    recommended_layout = layout,
    interpretation = scope,
    allow_main_effect_interpretation = allow_main,
    alpha = alpha
  )
}

dava_comparison_strategies <- function(effect_table, factors, alpha = 0.05, focus_factor = NULL) {
  base <- determine_comparison_strategy(effect_table, factors, alpha, focus_factor)
  significant <- detect_significant_interactions(effect_table, factors, alpha)
  if (!nrow(significant)) return(list(base))
  includes_focus <- vapply(significant$term, function(x) base$focus_factor %in% dava_effect_vars(x), logical(1))
  candidates <- significant[includes_focus, , drop = FALSE]
  if (!nrow(candidates)) return(list(base))
  candidates <- candidates[candidates$effect_order == max(candidates$effect_order), , drop = FALSE]
  lapply(seq_len(nrow(candidates)), function(i) {
    strategy <- base
    effect <- as.character(candidates$term[i])
    effect_vars <- dava_effect_vars(effect)
    strategy$highest_significant_effect <- effect
    strategy$highest_order_interaction <- effect
    strategy$highest_order_p <- candidates$p_numeric[i]
    strategy$conditioning_factors <- setdiff(effect_vars, strategy$focus_factor)
    strategy$averaging_factors <- setdiff(factors, effect_vars)
    strategy$comparison_formula <- build_emmeans_formula(strategy$focus_factor, strategy$conditioning_factors)
    strategy$interpretation <- paste0(
      "Compare ", strategy$focus_factor, " within every ",
      paste(strategy$conditioning_factors, collapse = " x "), " combination"
    )
    strategy
  })
}

dava_strategy_caption <- function(strategy, adjust = "tukey") {
  if (is.null(strategy) || !length(strategy)) return("")
  conditioning <- strategy$conditioning_factors %||% character()
  if (length(conditioning)) {
    paste0(
      "Because the ", strategy$highest_significant_effect,
      " interaction is significant, ", strategy$focus_factor,
      " is compared separately within each ", paste(conditioning, collapse = " x "),
      " condition. Letters are independent between conditions and use ", adjust, "-adjusted comparisons."
    )
  } else {
    averaged <- strategy$averaging_factors %||% character()
    suffix <- if (length(averaged)) paste0(" averaged over ", paste(averaged, collapse = ", ")) else ""
    paste0("Letters compare estimated marginal means of ", strategy$focus_factor, suffix,
           " using ", adjust, "-adjusted comparisons.")
  }
}
