# Lightweight reusable statistical methods shared by statistical and microbiome modules.

dava_stat_p_adjust <- function(p, method = "none") {
  method <- method %||% "none"
  if (method == "sidak") return(1 - (1 - p)^sum(!is.na(p)))
  if (method %in% stats::p.adjust.methods) return(stats::p.adjust(p, method = method))
  p
}

dava_stat_require <- function(ok, message) {
  if (!isTRUE(ok)) stop(message, call. = FALSE)
}

dava_stat_prepare_df <- function(df, response, vars = character(0)) {
  vars <- unique(c(response, vars))
  vars <- vars[vars %in% names(df) & nzchar(vars)]
  dat <- df[, vars, drop = FALSE]
  dat[[response]] <- suppressWarnings(as.numeric(dat[[response]]))
  stats::na.omit(dat)
}

dava_stat_tidy_htest <- function(test, response, group = NA_character_, method_label = NA_character_) {
  method_text <- if (length(method_label) == 0 || is.na(method_label)) test$method else method_label
  data.frame(
    response = response,
    group = group,
    method = method_text,
    statistic = unname(test$statistic %||% NA_real_),
    parameter = paste(test$parameter %||% NA_character_, collapse = ", "),
    estimate = paste(round(unname(test$estimate %||% NA_real_), 6), collapse = ", "),
    p.value = unname(test$p.value),
    significance = p_to_star(unname(test$p.value)),
    stringsAsFactors = FALSE
  )
}

dava_stat_pairwise_to_df <- function(pw, response, term, adjust = "none", method = "Pairwise comparison", response_col = "response") {
  mat <- pw$p.value
  if (is.null(mat) || length(mat) == 0) return(data.frame())
  out <- as.data.frame(as.table(mat), stringsAsFactors = FALSE)
  names(out) <- c("group1", "group2", "p.value")
  out <- out[!is.na(out$p.value), , drop = FALSE]
  if (nrow(out) == 0) return(out)
  out[[response_col]] <- response
  out$term <- term
  out$method <- method
  out$p.adjust.method <- adjust
  out$significance <- p_to_star(out$p.value)
  front <- c(response_col, "term", "method", "group1", "group2", "p.value", "p.adjust.method", "significance")
  out[, front, drop = FALSE]
}

dava_stat_summary <- function(dat, response, group_vars = character(0)) {
  group_vars <- group_vars[group_vars %in% names(dat) & nzchar(group_vars)]
  if (length(group_vars) == 0) {
    return(data.frame(
      response = response,
      n = sum(!is.na(dat[[response]])),
      mean = mean(dat[[response]], na.rm = TRUE),
      sd = stats::sd(dat[[response]], na.rm = TRUE),
      se = stats::sd(dat[[response]], na.rm = TRUE) / sqrt(sum(!is.na(dat[[response]]))),
      stringsAsFactors = FALSE
    ))
  }
  dat |>
    dplyr::group_by(dplyr::across(dplyr::all_of(group_vars))) |>
    dplyr::summarise(
      n = sum(!is.na(.data[[response]])),
      mean = mean(.data[[response]], na.rm = TRUE),
      sd = stats::sd(.data[[response]], na.rm = TRUE),
      se = sd / sqrt(n),
      .groups = "drop"
    ) |>
    dplyr::mutate(response = response, .before = 1) |>
    as.data.frame()
}

dava_stat_selected_group_vars <- function(model_type, opts = list()) {
  switch(
    model_type,
    t_OneSample = opts$group %||% "",
    Wilcoxon_OneSample = opts$group %||% "",
    t_TwoSample = opts$group %||% "",
    WMW_TwoSample = opts$group %||% "",
    t_TwoSamplePaired = opts$group %||% "",
    Wilcoxon_TwoSamplePaired = opts$group %||% "",
    KW_OneWay = opts$group %||% "",
    Friedman_OneWay = c(opts$group %||% "", opts$block %||% ""),
    SRH_TwoWay = c(opts$group1 %||% "", opts$group2 %||% ""),
    ART_ANOVA = c(opts$fixed_effect %||% character(0), opts$block_subject %||% ""),
    character(0)
  )
}

dava_stat_run_one_response <- function(df, response, model_type, opts = list()) {
  if (model_type %in% c("t_OneSample", "Wilcoxon_OneSample")) {
    grp <- opts$group %||% ""
    dat <- dava_stat_prepare_df(df, response, grp)
    split_dat <- if (grp == "") list(All = dat) else split(dat, dat[[grp]], drop = TRUE)
    tests <- lapply(names(split_dat), function(level_name) {
      x <- split_dat[[level_name]][[response]]
      dava_stat_require(length(x) >= 2, "At least two observations are required.")
      if (model_type == "t_OneSample") {
        dava_stat_tidy_htest(stats::t.test(x, mu = opts$num %||% 0), response, level_name)
      } else {
        dava_stat_tidy_htest(stats::wilcox.test(x, mu = opts$num %||% 0, exact = FALSE), response, level_name)
      }
    })
    return(list(result = dplyr::bind_rows(tests), data = dat, groups = if (grp == "") character(0) else grp))
  }

  if (model_type %in% c("t_TwoSample", "WMW_TwoSample", "t_TwoSamplePaired", "Wilcoxon_TwoSamplePaired")) {
    grp <- opts$group %||% ""
    dava_stat_require(grp %in% names(df), "Please choose a grouping variable.")
    dat <- dava_stat_prepare_df(df, response, grp)
    dat[[grp]] <- as.factor(dat[[grp]])
    lv <- levels(dat[[grp]])
    dava_stat_require(length(lv) >= 2, "The grouping variable must have at least two levels.")
    paired <- model_type %in% c("t_TwoSamplePaired", "Wilcoxon_TwoSamplePaired")
    pairs <- utils::combn(lv, 2, simplify = FALSE)
    pair_results <- lapply(pairs, function(pair_lv) {
      x <- dat[dat[[grp]] == pair_lv[1], response]
      y <- dat[dat[[grp]] == pair_lv[2], response]
      if (paired) {
        n_pair <- min(length(x), length(y))
        dava_stat_require(n_pair >= 2, "At least two complete pairs are required for each comparison.")
        x <- x[seq_len(n_pair)]
        y <- y[seq_len(n_pair)]
      } else {
        dava_stat_require(length(x) >= 2 && length(y) >= 2, "Each compared group must have at least two observations.")
      }
      test <- if (model_type %in% c("t_TwoSample", "t_TwoSamplePaired")) {
        stats::t.test(x, y, paired = paired)
      } else {
        stats::wilcox.test(x, y, paired = paired, exact = FALSE)
      }
      dava_stat_tidy_htest(test, response, paste(pair_lv, collapse = " vs ")) |>
        dplyr::mutate(group1 = pair_lv[1], group2 = pair_lv[2], n1 = length(x), n2 = length(y), .after = group)
    })
    result_df <- dplyr::bind_rows(pair_results)
    adjust <- opts$adjust_method %||% "holm"
    result_df$p.adjusted <- dava_stat_p_adjust(result_df$p.value, adjust)
    result_df$p.adjust.method <- adjust
    result_df$significance <- p_to_star(result_df$p.adjusted)
    return(list(result = result_df, data = dat, groups = grp))
  }

  if (model_type == "KW_OneWay") {
    grp <- opts$group %||% ""
    dava_stat_require(grp %in% names(df), "Please choose a grouping variable.")
    dat <- dava_stat_prepare_df(df, response, grp)
    dat[[grp]] <- as.factor(dat[[grp]])
    kt <- stats::kruskal.test(stats::reformulate(grp, response = response), data = dat)
    res <- dava_stat_tidy_htest(kt, response, grp)
    adjust <- opts$adjust_method %||% "holm"
    pw <- stats::pairwise.wilcox.test(dat[[response]], dat[[grp]], p.adjust.method = ifelse(adjust == "sidak", "none", adjust), exact = FALSE)
    post <- dava_stat_pairwise_to_df(pw, response, grp, adjust, "Pairwise Wilcoxon test")
    if (adjust == "sidak" && nrow(post) > 0) {
      post$p.value <- dava_stat_p_adjust(post$p.value, "sidak")
      post$significance <- p_to_star(post$p.value)
    }
    return(list(result = dplyr::bind_rows(res, post), data = dat, groups = grp))
  }

  if (model_type == "Friedman_OneWay") {
    grp <- opts$group %||% ""
    block <- opts$block %||% ""
    dava_stat_require(grp %in% names(df) && block %in% names(df), "Please choose treatment and block variables.")
    dat <- dava_stat_prepare_df(df, response, c(grp, block))
    dat[[grp]] <- as.factor(dat[[grp]])
    dat[[block]] <- as.factor(dat[[block]])
    ft <- stats::friedman.test(stats::as.formula(paste(response, "~", grp, "|", block)), data = dat)
    res <- dava_stat_tidy_htest(ft, response, paste(grp, "|", block))
    adjust <- opts$adjust_method %||% "holm"
    pw <- stats::pairwise.wilcox.test(dat[[response]], dat[[grp]], paired = TRUE, p.adjust.method = ifelse(adjust == "sidak", "none", adjust), exact = FALSE)
    post <- dava_stat_pairwise_to_df(pw, response, grp, adjust, "Pairwise paired Wilcoxon test")
    if (adjust == "sidak" && nrow(post) > 0) {
      post$p.value <- dava_stat_p_adjust(post$p.value, "sidak")
      post$significance <- p_to_star(post$p.value)
    }
    return(list(result = dplyr::bind_rows(res, post), data = dat, groups = c(grp, block)))
  }

  if (model_type == "SRH_TwoWay") {
    g1 <- opts$group1 %||% ""
    g2 <- opts$group2 %||% ""
    dava_stat_require(g1 %in% names(df) && g2 %in% names(df), "Please choose two factors.")
    dat <- dava_stat_prepare_df(df, response, c(g1, g2))
    dat[[g1]] <- as.factor(dat[[g1]])
    dat[[g2]] <- as.factor(dat[[g2]])
    dat$.rank_y <- rank(dat[[response]], ties.method = "average")
    fit <- stats::lm(stats::as.formula(paste(".rank_y ~", g1, "*", g2)), data = dat)
    res <- broom::tidy(stats::anova(fit)) |>
      dplyr::mutate(response = response, method = "Scheirer-Ray-Hare rank ANOVA approximation", .before = 1)
    res$significance <- p_to_star(res$p.value)
    return(list(result = res, data = dat, groups = c(g1, g2)))
  }

  if (model_type == "ART_ANOVA") {
    factors <- head(opts$fixed_effect %||% character(0), as.integer(opts$factor_n %||% 1))
    block <- opts$block_subject %||% ""
    dava_stat_require(length(factors) > 0, "Please choose fixed factor(s).")
    dat <- dava_stat_prepare_df(df, response, c(factors, block))
    for (nm in factors) dat[[nm]] <- as.factor(dat[[nm]])
    if (block != "" && block %in% names(dat)) dat[[block]] <- as.factor(dat[[block]])
    dat$.rank_y <- rank(dat[[response]], ties.method = "average")
    rhs <- paste(factors, collapse = " * ")
    if (block != "" && block %in% names(dat)) rhs <- paste(rhs, "+", block)
    fit <- stats::lm(stats::as.formula(paste(".rank_y ~", rhs)), data = dat)
    res <- broom::tidy(stats::anova(fit)) |>
      dplyr::mutate(response = response, method = "Aligned-rank style ANOVA approximation", .before = 1)
    res$significance <- p_to_star(res$p.value)
    return(list(result = res, data = dat, groups = factors))
  }

  stop("Unsupported analysis type: ", model_type)
}

dava_stat_run_tests <- function(df, responses, model_type, opts = list()) {
  results <- list()
  summaries <- list()
  errors <- list()

  for (resp in responses) {
    try_result <- tryCatch(dava_stat_run_one_response(df, resp, model_type, opts), error = function(e) e)
    if (inherits(try_result, "error")) {
      errors[[resp]] <- data.frame(response = resp, error = conditionMessage(try_result), stringsAsFactors = FALSE)
    } else {
      results[[resp]] <- try_result$result
      summaries[[resp]] <- dava_stat_summary(try_result$data, resp, try_result$groups)
    }
  }

  res_df <- dplyr::bind_rows(results)
  err_df <- dplyr::bind_rows(errors)
  if (nrow(err_df) > 0) res_df <- dplyr::bind_rows(res_df, err_df)

  list(
    result = format_anova_table(res_df),
    summary = dplyr::bind_rows(summaries),
    responses = responses,
    groups = dava_stat_selected_group_vars(model_type, opts)[dava_stat_selected_group_vars(model_type, opts) != ""]
  )
}

dava_stat_compare_one_metric <- function(data, response, group, overall_method = "kruskal", posthoc_method = "pairwise_wilcox", adjust = "BH", response_col = "metric") {
  dava_stat_require(response %in% names(data) && group %in% names(data), "Response and group variables are required.")
  dat <- dava_stat_prepare_df(data, response, group)
  dat[[group]] <- as.factor(dat[[group]])
  lv <- levels(dat[[group]])
  dava_stat_require(length(lv) >= 2, "The grouping variable must have at least two levels.")
  overall_method <- overall_method %||% "kruskal"
  if (overall_method == "auto") overall_method <- if (length(lv) == 2) "wilcox" else "kruskal"
  fml <- stats::reformulate(group, response = response)

  overall <- switch(
    overall_method,
    t_test = {
      dava_stat_require(length(lv) == 2, "Welch t-test requires exactly two groups.")
      tt <- stats::t.test(fml, data = dat)
      data.frame(method = "Welch t-test", statistic = unname(tt$statistic), parameter = unname(tt$parameter), p.value = tt$p.value)
    },
    wilcox = {
      dava_stat_require(length(lv) == 2, "Wilcoxon rank-sum test requires exactly two groups.")
      wt <- suppressWarnings(stats::wilcox.test(fml, data = dat, exact = FALSE))
      data.frame(method = "Wilcoxon rank-sum test", statistic = unname(wt$statistic), parameter = NA_real_, p.value = wt$p.value)
    },
    anova = {
      fit <- stats::aov(fml, data = dat)
      av <- as.data.frame(stats::anova(fit))
      data.frame(method = "One-way ANOVA", statistic = av[1, "F value"], parameter = av[1, "Df"], p.value = av[1, "Pr(>F)"])
    },
    welch_anova = {
      ow <- stats::oneway.test(fml, data = dat, var.equal = FALSE)
      data.frame(method = "Welch one-way ANOVA", statistic = unname(ow$statistic), parameter = unname(ow$parameter[1]), p.value = ow$p.value)
    },
    lm = {
      fit <- stats::lm(fml, data = dat)
      av <- as.data.frame(stats::anova(fit))
      data.frame(method = "Linear model ANOVA", statistic = av[1, "F value"], parameter = av[1, "Df"], p.value = av[1, "Pr(>F)"])
    },
    {
      kt <- stats::kruskal.test(fml, data = dat)
      data.frame(method = "Kruskal-Wallis test", statistic = unname(kt$statistic), parameter = unname(kt$parameter), p.value = kt$p.value)
    }
  )
  overall[[response_col]] <- response
  overall$term <- group
  overall$significance <- p_to_star(overall$p.value)
  overall <- overall[, c(response_col, "term", "method", setdiff(names(overall), c(response_col, "term", "method"))), drop = FALSE]

  posthoc <- data.frame()
  posthoc_method <- posthoc_method %||% "pairwise_wilcox"
  if (posthoc_method != "none" && length(lv) >= 2) {
    posthoc <- tryCatch({
      if (posthoc_method == "tukey_hsd") {
        fit <- stats::aov(fml, data = dat)
        tk <- stats::TukeyHSD(fit, which = group)[[group]]
        out <- as.data.frame(tk, stringsAsFactors = FALSE)
        out$contrast <- rownames(out)
        rownames(out) <- NULL
        names(out)[names(out) == "p adj"] <- "p.value"
        parts <- strsplit(out$contrast, "-")
        out$group1 <- vapply(parts, `[`, character(1), 1)
        out$group2 <- vapply(parts, `[`, character(1), 2)
        out[[response_col]] <- response
        out$term <- group
        out$method <- "Tukey HSD"
        out$p.adjust.method <- "tukey"
        out$significance <- p_to_star(out$p.value)
        out[, c(response_col, "term", "method", "group1", "group2", "diff", "lwr", "upr", "p.value", "p.adjust.method", "significance"), drop = FALSE]
      } else if (posthoc_method == "emmeans_tukey" && requireNamespace("emmeans", quietly = TRUE)) {
        fit <- stats::lm(fml, data = dat)
        emm <- emmeans::emmeans(fit, specs = stats::as.formula(paste("~", group)))
        out <- as.data.frame(pairs(emm, adjust = ifelse(adjust == "none", "none", "tukey")))
        parts <- strsplit(as.character(out$contrast), " - ")
        out$group1 <- vapply(parts, `[`, character(1), 1)
        out$group2 <- vapply(parts, `[`, character(1), 2)
        out[[response_col]] <- response
        out$term <- group
        out$method <- "emmeans pairwise"
        out$p.adjust.method <- ifelse(adjust == "none", "none", "tukey")
        out$significance <- p_to_star(out$p.value)
        out[, intersect(c(response_col, "term", "method", "group1", "group2", "estimate", "SE", "df", "t.ratio", "p.value", "p.adjust.method", "significance"), names(out)), drop = FALSE]
      } else if (posthoc_method == "pairwise_t") {
        pw <- stats::pairwise.t.test(dat[[response]], dat[[group]], p.adjust.method = ifelse(adjust == "sidak", "none", adjust), pool.sd = FALSE)
        out <- dava_stat_pairwise_to_df(pw, response, group, adjust, "Pairwise Welch t-test", response_col)
        if (adjust == "sidak" && nrow(out) > 0) {
          out$p.value <- dava_stat_p_adjust(out$p.value, "sidak")
          out$significance <- p_to_star(out$p.value)
        }
        out
      } else {
        pw <- stats::pairwise.wilcox.test(dat[[response]], dat[[group]], p.adjust.method = ifelse(adjust == "sidak", "none", adjust), exact = FALSE)
        out <- dava_stat_pairwise_to_df(pw, response, group, adjust, "Pairwise Wilcoxon test", response_col)
        if (adjust == "sidak" && nrow(out) > 0) {
          out$p.value <- dava_stat_p_adjust(out$p.value, "sidak")
          out$significance <- p_to_star(out$p.value)
        }
        out
      }
    }, error = function(e) {
      data.frame(error = conditionMessage(e), stringsAsFactors = FALSE)
    })
  }

  list(overall = overall, posthoc = posthoc)
}

dava_stat_compare_group_metrics <- function(data, metrics, group, overall_method = "kruskal", posthoc_method = "pairwise_wilcox", adjust = "BH", response_col = "metric") {
  metrics <- metrics[metrics %in% names(data)]
  if (!(group %in% names(data)) || length(metrics) == 0) {
    return(list(overall = data.frame(), posthoc = data.frame()))
  }
  ans <- lapply(metrics, function(metric) {
    dava_stat_compare_one_metric(data, metric, group, overall_method, posthoc_method, adjust, response_col)
  })
  list(
    overall = format_anova_table(dplyr::bind_rows(lapply(ans, `[[`, "overall"))),
    posthoc = format_anova_table(dplyr::bind_rows(lapply(ans, `[[`, "posthoc")))
  )
}
