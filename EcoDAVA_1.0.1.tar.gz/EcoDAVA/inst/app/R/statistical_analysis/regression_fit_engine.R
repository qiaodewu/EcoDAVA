regression_capture <- function(expr) {
  warnings <- character()
  value <- tryCatch(withCallingHandlers(expr, warning = function(w) {
    warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning")
  }), error = function(e) e)
  list(value = if (inherits(value, "error")) NULL else value,
       warnings = unique(warnings), error = if (inherits(value, "error")) conditionMessage(value) else "")
}

regression_tidy_model <- function(model, conf.int = TRUE) {
  tryCatch({
    if (inherits(model, c("merMod", "glmmTMB"))) broom.mixed::tidy(model, effects = "fixed", conf.int = conf.int)
    else if (inherits(model, "segmented")) {
      # broom delegates segmented objects to its lm tidier and emits a
      # maintenance warning. Build the standard tidy coefficient table from
      # summary.segmented() directly; model$model is the model frame, not an
      # lm object, and must never be passed to broom::tidy().
      coefficient_matrix <- as.matrix(summary(model)$coefficients)
      tidy <- data.frame(
        term = rownames(coefficient_matrix),
        estimate = coefficient_matrix[, 1L],
        std.error = coefficient_matrix[, 2L],
        statistic = coefficient_matrix[, 3L],
        p.value = coefficient_matrix[, 4L],
        row.names = NULL, check.names = FALSE
      )
      if (isTRUE(conf.int)) {
        degrees <- suppressWarnings(as.numeric(model$df.residual %||% Inf))
        critical <- if (is.finite(degrees) && degrees > 0) {
          stats::qt(0.975, degrees)
        } else stats::qnorm(0.975)
        tidy$conf.low <- tidy$estimate - critical * tidy$std.error
        tidy$conf.high <- tidy$estimate + critical * tidy$std.error
      }
      tidy
    }
    else broom::tidy(model, conf.int = conf.int)
  }, error = function(e) data.frame(error = conditionMessage(e), stringsAsFactors = FALSE))
}

regression_glance_model <- function(model) {
  tryCatch({
    if (inherits(model, c("merMod", "glmmTMB"))) broom.mixed::glance(model) else broom::glance(model)
  }, error = function(e) data.frame(error = conditionMessage(e), stringsAsFactors = FALSE))
}

# Return the model-level significance P value, preferring the fitted model's overall test.
# Only if themodelNoneOverall inspectiontime，only read the followingExplanatory variablescorresponding coefficientCheck。
regression_model_p_value <- function(model, focus_predictor = "") {
  glance <- regression_glance_model(model)
  if (nrow(glance) && "p.value" %in% names(glance)) {
    value <- suppressWarnings(as.numeric(glance$p.value[1]))
    if (length(value) && is.finite(value)) return(value)
  }
  tidy <- regression_tidy_model(model, conf.int = FALSE)
  if (!nrow(tidy) || !all(c("term", "p.value") %in% names(tidy))) return(NA_real_)
  rows <- tidy$term == focus_predictor
  value <- suppressWarnings(as.numeric(tidy$p.value[rows][1]))
  if (length(value) && is.finite(value)) value else NA_real_
}

regression_numeric_response <- function(x) {
  if (is.factor(x) && nlevels(x) == 2L) return(as.numeric(x == levels(x)[2]))
  if (is.logical(x)) return(as.numeric(x))
  suppressWarnings(as.numeric(x))
}

# Return a valid starting breakpoint for segmented regression.  segmented::segmented
# requires psi to lie strictly inside the observed predictor range; persisted UI
# values such as 0 can otherwise make a valid analysis fail before fitting starts.
regression_segmented_start_psi <- function(x, requested = NA_real_) {
  values <- suppressWarnings(as.numeric(x))
  values <- values[is.finite(values)]
  if (length(unique(values)) < 3L) {
    stop("Piecewise threshold regression requires that the primary explanatory variable contains at least three different significant values.", call. = FALSE)
  }
  bounds <- stats::quantile(values, probs = c(0.05, 0.95), na.rm = TRUE,
    names = FALSE, type = 7)
  if (!all(is.finite(bounds)) || bounds[1] >= bounds[2]) {
    bounds <- range(values, na.rm = TRUE)
  }
  candidate <- suppressWarnings(as.numeric(requested)[1])
  if (!is.finite(candidate) || candidate <= bounds[1] || candidate >= bounds[2]) {
    candidate <- stats::median(values, na.rm = TRUE)
  }
  # A tied median can coincide with an edge; fall back to the interior midpoint.
  if (!is.finite(candidate) || candidate <= bounds[1] || candidate >= bounds[2]) {
    candidate <- mean(bounds)
  }
  candidate
}

regression_category_probability_table <- function(model, newdata, response_name) {
  probabilities <- as.matrix(stats::predict(model, newdata = newdata, type = "probs"))
  if (is.null(colnames(probabilities))) colnames(probabilities) <- levels(model$model[[1]])
  dplyr::bind_rows(lapply(seq_len(ncol(probabilities)), function(index) {
    cbind(newdata, response = response_name, category = colnames(probabilities)[index],
          predicted = probabilities[, index], conf.low = NA_real_, conf.high = NA_real_, stringsAsFactors = FALSE)
  }))
}

regression_package_versions <- function(packages) {
  packages <- unique(packages[nzchar(packages)])
  data.frame(
    package = packages,
    version = vapply(packages, function(pkg) {
      if (!requireNamespace(pkg, quietly = TRUE)) return(NA_character_)
      as.character(utils::packageVersion(pkg))
    }, character(1)),
    stringsAsFactors = FALSE
  )
}

fit_regression_linear_adapter <- function(data, formula, method_id, settings) {
  if (method_id %in% c("lm", "polynomial", "spline", "multivariate_lm")) return(stats::lm(formula, data = data))
  if (method_id == "segmented") {
    base <- stats::lm(formula, data = data)
    psi <- regression_segmented_start_psi(
      data[[settings$focus_predictor]], settings$breakpoint %||% NA_real_
    )
    return(segmented::segmented(base, seg.Z = stats::as.formula(paste("~", settings$focus_predictor)), psi = psi))
  }
  if (method_id == "nls") {
    starts <- parse_regression_nls_starts(settings$nls_start)
    nls_formula <- build_regression_nls_formula(settings$nls_formula, settings$responses[1], settings$predictors, names(starts))
    return(minpack.lm::nlsLM(
      nls_formula, data = data, start = starts,
      control = minpack.lm::nls.lm.control(maxiter = as.integer(settings$nls_max_iterations %||% 200L), ftol = as.numeric(settings$nls_tolerance %||% 1e-8))
    ))
  }
  stop(sprintf("Classic linear adapter not yet supported: %s", method_id), call. = FALSE)
}

fit_regression_glm_adapter <- function(data, formula, method_id, settings) {
  if (method_id == "multinomial") {
    response <- settings$responses[1]
    reference <- settings$reference_level %||% ""
    data[[response]] <- stats::relevel(droplevels(factor(data[[response]])), ref = reference)
    model <- nnet::multinom(formula, data = data, trace = FALSE, model = TRUE)
    model$call$formula <- formula
    return(model)
  }
  if (method_id == "ordinal") {
    response <- settings$responses[1]
    if (!is.ordered(data[[response]])) stop("An ordered logistic response must be an ordered factor.", call. = FALSE)
    model <- MASS::polr(formula, data = data, Hess = TRUE, model = TRUE, method = settings$link %||% "logistic")
    model$call$formula <- formula
    return(model)
  }
  if (method_id == "negative_binomial") return(MASS::glm.nb(formula, data = data))
  response <- data[[settings$responses[1]]]
  if (method_id == "beta") {
    if (any(!is.finite(response) | response <= 0 | response >= 1)) {
      stop("Beta regression requires that the response variables all lie strictly between 0 and 1.", call. = FALSE)
    }
    return(betareg::betareg(formula, data = data, link = settings$link %||% "logit"))
  }
  if (method_id %in% c("zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin")) {
    if (any(!is.finite(response) | response < 0 | response != floor(response))) {
      stop(sprintf("%s requires the response variable to be a non-negative integer count.", toupper(method_id)), call. = FALSE)
    }
    zero_predictors <- intersect(settings$zero_predictors %||% character(), names(data))
    model_formula <- if (length(zero_predictors)) stats::as.formula(sprintf(
      "%s | %s", paste(deparse(formula), collapse = " "), paste(zero_predictors, collapse = " + ")
    )) else formula
    if (method_id %in% c("hurdle", "hurdle_poisson", "hurdle_negbin")) {
      hurdle_dist <- if (method_id == "hurdle_poisson") "poisson" else "negbin"
      return(pscl::hurdle(model_formula, data = data, dist = hurdle_dist, zero.dist = "binomial", link = settings$link %||% "logit"))
    }
    return(pscl::zeroinfl(model_formula, data = data, dist = if (method_id == "zinb") "negbin" else "poisson", link = settings$link %||% "logit"))
  }
  family <- switch(method_id,
    logistic = stats::binomial(link = settings$link %||% "logit"),
    aggregated_binomial = stats::binomial(link = settings$link %||% "logit"),
    weighted_binomial = stats::binomial(link = settings$link %||% "logit"),
    poisson = stats::poisson(link = settings$link %||% "log"),
    gamma = stats::Gamma(link = settings$link %||% "log"),
    quasipoisson = stats::quasipoisson(link = settings$link %||% "log"),
    quasibinomial = stats::quasibinomial(link = settings$link %||% "logit"),
    stats::gaussian()
  )
  if (method_id == "weighted_binomial") {
    data$.dava_binomial_weights <- data[[settings$trials_var]]
    return(stats::glm(formula, data = data, family = family, weights = .dava_binomial_weights))
  }
  stats::glm(formula, data = data, family = family)
}

fit_regression_mixed_adapter <- function(data, formula, method_id, settings) {
  if (method_id == "lmm") return(lme4::lmer(formula, data = data, REML = isTRUE(settings$reml)))
  if (method_id == "glmm") {
    family <- switch(settings$family %||% "binomial", poisson = stats::poisson(), stats::binomial())
    return(lme4::glmer(formula, data = data, family = family))
  }
  if (method_id == "gamm") {
    rhs <- c(settings$predictors, sprintf("s(%s, bs = 're')", settings$group_var))
    if (isTRUE(settings$random_slope)) rhs <- c(rhs, sprintf("s(%s, %s, bs = 're')", settings$focus_predictor, settings$group_var))
    gamm_formula <- stats::as.formula(paste(settings$responses[1], "~", paste(rhs, collapse = " + ")))
    return(mgcv::gam(gamm_formula, data = data, method = "REML"))
  }
  if (method_id %in% c("zip_mixed", "zinb_mixed")) {
    zero_predictors <- intersect(settings$zero_predictors %||% character(), names(data))
    zi_formula <- if (length(zero_predictors)) stats::reformulate(zero_predictors) else ~1
    family <- if (method_id == "zinb_mixed") glmmTMB::nbinom2(link = "log") else stats::poisson(link = "log")
    return(glmmTMB::glmmTMB(formula, ziformula = zi_formula, data = data, family = family))
  }
  stop(sprintf("Mixed model adapter not yet supported: %s", method_id), call. = FALSE)
}

fit_regression_pls_adapter <- function(data, responses, predictors, method_id, settings) {
  formula <- build_regression_formula(responses, predictors)
  ncomp <- min(as.integer(settings$n_components %||% 2L), length(predictors), nrow(data) - 2L)
  segments <- min(max(3L, as.integer(settings$cv_folds %||% 10L)), nrow(data))
  model <- if (method_id == "pcr") pls::pcr(formula, data = data, ncomp = ncomp, scale = isTRUE(settings$standardize), validation = "CV", segments = segments) else
    pls::plsr(formula, data = data, ncomp = ncomp, scale = isTRUE(settings$standardize), validation = "CV", segments = segments)
  list(model = model, ncomp = ncomp)
}

fit_regression_regularized_adapter <- function(data, response, predictors, method_id, settings) {
  terms <- stats::terms(stats::reformulate(predictors, response = response), data = data)
  x <- stats::model.matrix(terms, data)[, -1, drop = FALSE]
  y <- data[[response]]
  alpha <- switch(method_id, ridge = 0, lasso = 1, adaptive_lasso = 1,
                  elastic_net = as.numeric(settings$elastic_alpha %||% 0.5), 0)
  penalty_factor <- NULL
  if (method_id == "adaptive_lasso") {
    initial <- glmnet::glmnet(x, y, alpha = 0)
    initial_coef <- as.numeric(stats::coef(initial, s = tail(initial$lambda, 1))[-1, 1])
    penalty_factor <- 1 / pmax(abs(initial_coef), sqrt(.Machine$double.eps))
  }
  model <- glmnet::cv.glmnet(
    x, y, alpha = alpha, penalty.factor = penalty_factor,
    nfolds = min(as.integer(settings$cv_folds %||% 10L), nrow(data))
  )
  list(model = model, terms = stats::delete.response(terms), x = x, alpha = alpha)
}

fit_regression_semiparametric_adapter <- function(data, formula, method_id, settings) {
  focus <- settings$focus_predictor
  if (method_id == "gam") {
    basis <- settings$smooth_basis %||% "tp"
    rhs <- c(sprintf("s(%s, k = %d, bs = '%s')", focus, max(4L, as.integer(settings$smooth_k %||% 6L)), basis), setdiff(settings$predictors, focus))
    return(mgcv::gam(stats::as.formula(paste(settings$responses[1], "~", paste(rhs, collapse = " + "))), data = data, method = "REML"))
  }
  if (method_id == "loess") return(stats::loess(formula, data = data, span = as.numeric(settings$loess_span %||% 0.75)))
  if (method_id == "quantile") return(quantreg::rq(formula, data = data, tau = as.numeric(settings$tau %||% 0.5)))
  if (method_id == "robust") return(MASS::rlm(formula, data = data))
  stop(sprintf("Semi-parametric/robust adapter not yet supported: %s", method_id), call. = FALSE)
}

regression_multivariate_tree_method <- function() {
  node_eval <- function(y, wt, parms) {
    y <- as.matrix(y)
    center <- colSums(y * wt) / sum(wt)
    deviance <- sum(rowSums(sweep(y, 2L, center, "-")^2) * wt)
    list(label = center, deviance = deviance)
  }
  node_split <- function(y, wt, x, parms, continuous) {
    y <- as.matrix(y)
    center <- colSums(y * wt) / sum(wt)
    centered <- sweep(y, 2L, center, "-")
    total <- sum(rowSums(centered^2) * wt)
    if (!is.finite(total) || total <= 0) total <- 1
    if (continuous) {
      n <- nrow(centered)
      cumulative <- apply(centered * wt, 2L, cumsum)
      if (is.null(dim(cumulative))) cumulative <- matrix(cumulative, ncol = 1L)
      cumulative <- cumulative[-n, , drop = FALSE]
      left_weight <- cumsum(wt)[-n]
      right_weight <- sum(wt) - left_weight
      left_mean <- cumulative / left_weight
      right_mean <- -cumulative / right_weight
      direction <- sign(left_mean[, 1L])
      direction[direction == 0] <- 1
      return(list(
        goodness = (left_weight * rowSums(left_mean^2) + right_weight * rowSums(right_mean^2)) / total,
        direction = direction
      ))
    }
    levels <- sort(unique(x))
    weight_by_level <- tapply(wt, x, sum)
    mean_by_level <- vapply(levels, function(level) {
      rows <- x == level
      colSums(y[rows, , drop = FALSE] * wt[rows]) / sum(wt[rows])
    }, numeric(ncol(y)))
    if (is.null(dim(mean_by_level))) mean_by_level <- matrix(mean_by_level, nrow = 1L)
    order_index <- order(mean_by_level[1L, ])
    sum_by_level <- vapply(levels, function(level) {
      rows <- x == level
      colSums(y[rows, , drop = FALSE] * wt[rows])
    }, numeric(ncol(y)))
    if (is.null(dim(sum_by_level))) sum_by_level <- matrix(sum_by_level, nrow = 1L)
    sum_by_level <- t(sum_by_level)[order_index, , drop = FALSE]
    n_levels <- length(order_index)
    cumulative <- apply(sum_by_level, 2L, cumsum)
    if (is.null(dim(cumulative))) cumulative <- matrix(cumulative, ncol = 1L)
    cumulative <- cumulative[-n_levels, , drop = FALSE]
    left_weight <- cumsum(weight_by_level[order_index])[-n_levels]
    right_weight <- sum(wt) - left_weight
    left_mean <- cumulative / left_weight
    total_sum <- matrix(center * sum(wt), n_levels - 1L, ncol(y), byrow = TRUE)
    right_mean <- (total_sum - cumulative) / right_weight
    center_matrix <- matrix(center, n_levels - 1L, ncol(y), byrow = TRUE)
    between <- left_weight * rowSums((left_mean - center_matrix)^2) +
      right_weight * rowSums((right_mean - center_matrix)^2)
    list(goodness = between / total, direction = levels[order_index])
  }
  node_init <- function(y, offset, parms, wt) {
    y <- as.matrix(y)
    if (!is.null(offset)) y <- y - offset
    response_count <- ncol(y)
    list(
      y = y, parms = list(), numresp = response_count, numy = response_count,
      summary = function(yval, dev, wt, ylevel, digits) paste0(
        "  means=", paste(format(signif(yval, digits)), collapse = ", "),
        ", SSE=", format(signif(dev, digits))
      )
    )
  }
  list(eval = node_eval, split = node_split, init = node_init)
}

fit_regression_multivariate_tree_adapter <- function(data, responses, predictors, settings) {
  model_data <- data
  response_matrix <- as.matrix(model_data[, responses, drop = FALSE])
  response_center <- rep(0, length(responses))
  response_scale <- rep(1, length(responses))
  if (isTRUE(settings$standardize)) {
    response_center <- colMeans(response_matrix)
    response_scale <- apply(response_matrix, 2L, stats::sd)
    response_scale[!is.finite(response_scale) | response_scale == 0] <- 1
    response_matrix <- sweep(sweep(response_matrix, 2L, response_center, "-"), 2L, response_scale, "/")
    model_data[, responses] <- response_matrix
  }
  formula <- build_regression_formula(responses, predictors)
  control <- rpart::rpart.control(
    cp = max(0, as.numeric(settings$tree_cp %||% 0.01)),
    minsplit = max(2L, as.integer(settings$tree_minsplit %||% 10L)),
    maxdepth = max(1L, min(30L, as.integer(settings$tree_maxdepth %||% 6L))),
    xval = max(0L, as.integer(settings$cv_folds %||% 10L))
  )
  model <- rpart::rpart(
    formula, data = model_data, method = regression_multivariate_tree_method(),
    control = control, model = TRUE, x = TRUE, y = TRUE
  )
  attr(model, "dava_response_names") <- responses
  list(model = model, response_center = response_center, response_scale = response_scale)
}

fit_regression_ml_adapter <- function(data, formula, response, predictors, method_id, settings) {
  if (method_id == "rpart") return(list(model = rpart::rpart(formula, data = data, method = "anova")))
  if (method_id == "random_forest") return(list(model = ranger::ranger(formula, data = data, importance = "permutation", num.trees = as.integer(settings$num_trees %||% 500L))))
  terms <- stats::terms(formula, data = data)
  x <- stats::model.matrix(terms, data)[, -1, drop = FALSE]
  y <- data[[response]]
  if (method_id %in% c("xgboost", "gradient_boost")) {
    model <- xgboost::xgboost(data = x, label = y, objective = "reg:squarederror", nrounds = as.integer(settings$nrounds %||% 100L), verbose = 0)
    return(list(model = model, terms = stats::delete.response(terms), x = x))
  }
  if (method_id == "svr") return(list(model = e1071::svm(formula, data = data, type = "eps-regression")))
  if (method_id == "neural_network") return(list(model = nnet::nnet(formula, data = data, size = as.integer(settings$hidden_units %||% 5L), linout = TRUE, trace = FALSE, maxit = 500)))
  stop(sprintf("Machine learning adapter not yet supported: %s", method_id), call. = FALSE)
}

fit_regression_community_adapter <- function(data, formula, method_id, settings) {
  response_matrix <- as.matrix(data[, settings$responses, drop = FALSE])
  explanatory_matrix <- stats::model.matrix(
    stats::reformulate(settings$predictors), data = data
  )[, -1, drop = FALSE]
  if (method_id == "rda") return(vegan::rda(response_matrix, explanatory_matrix, scale = isTRUE(settings$standardize)))
  if (method_id == "cca") return(vegan::cca(response_matrix, explanatory_matrix))
  if (method_id == "dbrda") return(vegan::capscale(response_matrix ~ ., data = as.data.frame(explanatory_matrix), distance = settings$distance %||% "bray"))
  if (method_id == "manyglm") {
    if (any(response_matrix < 0 | response_matrix != floor(response_matrix))) {
      stop("Multispecies GLM requires that the community response matrix be a non-negative integer count.", call. = FALSE)
    }
    x_data <- as.data.frame(data[, settings$predictors, drop = FALSE], check.names = FALSE)
    y_mv <- mvabund::mvabund(response_matrix)
    family <- settings$family %||% "negative.binomial"
    if (!family %in% c("negative.binomial", "poisson")) family <- "negative.binomial"
    return(mvabund::manyglm(y_mv ~ ., data = x_data, family = family))
  }
  if (method_id == "gllvm") {
    if (any(response_matrix < 0 | response_matrix != floor(response_matrix))) {
      stop("GLLVM's currently open count distribution requires that the community response matrix be a non-negative integer.", call. = FALSE)
    }
    x_data <- as.data.frame(data[, settings$predictors, drop = FALSE], check.names = FALSE)
    family <- settings$family %||% "poisson"
    if (!family %in% c("poisson", "negative.binomial")) family <- "poisson"
    num_lv <- max(1L, min(as.integer(settings$n_components %||% 2L), ncol(response_matrix) - 1L))
    fit <- gllvm::gllvm(
      y = response_matrix, X = x_data, family = family, num.lv = num_lv,
      seed = as.integer(settings$seed %||% 123L), scale.X = isTRUE(settings$standardize),
      control = list(max.iter = 1000L, maxit = 1000L, trace = FALSE)
    )
    attr(fit, "dava_x") <- x_data
    return(fit)
  }
  if (method_id == "jsdm") {
    family <- settings$family %||% "normal"
    if (!family %in% c("normal", "poisson", "probit")) stop("Invalid JSDM response distribution.", call. = FALSE)
    if (family == "poisson" && any(response_matrix < 0 | response_matrix != floor(response_matrix))) {
      stop("Poisson JSDM requires the community response matrix to be non-negative integer counts.", call. = FALSE)
    }
    if (family == "probit" && any(!response_matrix %in% c(0, 1))) {
      stop("Probit JSDM requires that the community response matrix contain only 0s and 1s.", call. = FALSE)
    }
    x_data <- as.data.frame(data[, settings$predictors, drop = FALSE], check.names = FALSE)
    set.seed(as.integer(settings$seed %||% 123L))
    fit <- Hmsc::Hmsc(Y = response_matrix, XData = x_data,
                      XFormula = stats::reformulate(settings$predictors), distr = family)
    return(Hmsc::sampleMcmc(
      fit, samples = max(5L, as.integer(settings$mcmc_samples %||% 250L)),
      transient = max(2L, as.integer(settings$mcmc_transient %||% 250L)), thin = 1L,
      nChains = 1L, nParallel = 1L, verbose = 0L
    ))
  }
  if (method_id == "rrr") {
    x <- stats::model.matrix(stats::reformulate(settings$predictors), data = data)[, -1, drop = FALSE]
    if (isTRUE(settings$standardize)) x <- scale(x)
    rank_max <- max(1L, min(as.integer(settings$n_components %||% 2L), ncol(x), ncol(response_matrix)))
    fit <- rrpack::rrr(response_matrix, x, maxrank = rank_max)
    attr(fit, "dava_x") <- x
    return(fit)
  }
  stop(sprintf("Community Matrix Adapter not yet supported: %s", method_id), call. = FALSE)
}

fit_regression_feature_association_adapter <- function(data, settings) {
  responses <- settings$responses
  predictors <- settings$predictors
  focus <- settings$focus_predictor
  if (length(responses) < 2L) stop("Feature-level multivariate correlations require at least two response features.", call. = FALSE)
  models <- stats::setNames(lapply(responses, function(response) {
    stats::lm(stats::reformulate(predictors, response = response), data = data)
  }), responses)
  feature_results <- dplyr::bind_rows(lapply(responses, function(response) {
    tidy <- regression_tidy_model(models[[response]])
    tidy <- tidy[tidy$term == focus, , drop = FALSE]
    if (!nrow(tidy)) return(data.frame(feature = response, term = focus, error = "The coefficient of the variable of interest is not estimable"))
    transform(tidy, feature = response)
  }))
  if ("p.value" %in% names(feature_results)) {
    feature_results$p.adjust <- stats::p.adjust(feature_results$p.value, method = settings$fdr_method %||% "BH")
  }
  list(model = models, feature_results = feature_results)
}

fit_regression_microbiome_count_adapter <- function(data, method_id, settings) {
  spec <- prepare_regression_microbiome_counts(data, settings)
  focus <- settings$focus_predictor
  if (method_id == "deseq2") {
    dds <- DESeq2::DESeqDataSetFromMatrix(
      countData = spec$counts, colData = spec$metadata, design = spec$design
    )
    dds <- DESeq2::DESeq(dds, quiet = TRUE)
    result_names <- DESeq2::resultsNames(dds)
    coefficient_name <- grep(focus, result_names, value = TRUE)[1] %||% ""
    if (!nzchar(coefficient_name)) stop("DESeq2 cannot construct testable coefficients for the variable of interest.", call. = FALSE)
    table <- as.data.frame(DESeq2::results(dds, name = coefficient_name, independentFiltering = FALSE))
    table$feature <- rownames(table)
    rownames(table) <- NULL
    names(table)[names(table) == "log2FoldChange"] <- "estimate"
    names(table)[names(table) == "lfcSE"] <- "std.error"
    names(table)[names(table) == "stat"] <- "statistic"
    names(table)[names(table) == "pvalue"] <- "p.value"
    names(table)[names(table) == "padj"] <- "p.adjust"
    fitted <- t(SummarizedExperiment::assays(dds)[["mu"]])
    return(list(model = dds, feature_results = table, fitted = fitted,
                filter_records = spec$filter_record, coefficient_name = coefficient_name))
  }
  if (method_id == "ancombc2") {
    metadata <- spec$metadata
    rownames(metadata) <- paste0("sample_", seq_len(nrow(metadata)))
    colnames(spec$counts) <- rownames(metadata)
    fit <- ANCOMBC::ancombc2(
      data = spec$counts, taxa_are_rows = TRUE, meta_data = metadata,
      fix_formula = paste(settings$predictors, collapse = " + "),
      p_adj_method = settings$fdr_method %||% "BH", pseudo_sens = FALSE,
      prv_cut = 0, lib_cut = 0, group = focus, struc_zero = FALSE,
      neg_lb = FALSE, n_cl = 1, verbose = FALSE, global = FALSE,
      pairwise = FALSE, dunnet = FALSE, trend = FALSE
    )
    result <- fit$res
    lfc_column <- grep(paste0("^lfc_", focus), names(result), value = TRUE)[1] %||% ""
    if (!nzchar(lfc_column)) stop("ANCOM-BC2 Unable to extract effect coefficient for variable of interest.", call. = FALSE)
    suffix <- sub("^lfc_", "", lfc_column)
    table <- data.frame(
      feature = result$taxon, term = suffix, estimate = result[[lfc_column]],
      std.error = result[[paste0("se_", suffix)]], statistic = result[[paste0("W_", suffix)]],
      p.value = result[[paste0("p_", suffix)]], p.adjust = result[[paste0("q_", suffix)]],
      differentially_abundant = result[[paste0("diff_", suffix)]], stringsAsFactors = FALSE
    )
    fitted <- t(as.matrix(fit$bias_correct_log_table))
    return(list(model = fit, feature_results = table, fitted = fitted,
                filter_records = spec$filter_record, coefficient_name = suffix))
  }
  if (method_id == "maaslin2") {
    metadata <- spec$metadata
    rownames(metadata) <- paste0("sample_", seq_len(nrow(metadata)))
    abundance <- as.data.frame(t(spec$counts), check.names = FALSE)
    rownames(abundance) <- rownames(metadata)
    output_dir <- file.path(tempdir(), paste0("dava_maaslin2_", Sys.getpid(), "_", as.integer(stats::runif(1, 1, 1e9))))
    fit <- Maaslin2::Maaslin2(
      input_data = abundance, input_metadata = metadata, output = output_dir,
      min_abundance = 0, min_prevalence = 0,
      normalization = settings$normalization %||% "TSS",
      transform = settings$transformation %||% "LOG", analysis_method = "LM",
      fixed_effects = settings$predictors, correction = settings$fdr_method %||% "BH",
      standardize = isTRUE(settings$standardize), cores = 1,
      plot_heatmap = FALSE, plot_scatter = FALSE, save_models = TRUE
    )
    table <- fit$results[fit$results$metadata == focus, , drop = FALSE]
    if (!nrow(table)) stop("MaAsLin2 was unable to extract feature-level results for the variable of interest.", call. = FALSE)
    names(table)[names(table) == "coef"] <- "estimate"
    names(table)[names(table) == "stderr"] <- "std.error"
    names(table)[names(table) == "pval"] <- "p.value"
    names(table)[names(table) == "qval"] <- "p.adjust"
    return(list(model = fit, feature_results = table, fitted = t(fit$fitted),
                filter_records = spec$filter_record, coefficient_name = focus,
                workspace = output_dir))
  }
  if (method_id == "corncob") {
    total <- colSums(spec$counts)
    if (any(total <= 0)) stop("corncob requires that the total count for each sample be greater than zero.", call. = FALSE)
    dispersion_predictors <- intersect(settings$dispersion_predictors %||% character(), names(spec$metadata))
    phi_formula <- stats::reformulate(dispersion_predictors)
    models <- vector("list", length(spec$features))
    names(models) <- spec$features
    fitted <- matrix(NA_real_, nrow = nrow(spec$metadata), ncol = length(spec$features), dimnames = list(NULL, spec$features))
    rows <- lapply(seq_along(spec$features), function(index) {
      feature <- spec$features[index]
      model_data <- spec$metadata
      model_data$.dava_feature_count <- as.numeric(spec$counts[index, ])
      model_data$.dava_total_count <- total
      formula <- stats::as.formula(paste(
        "cbind(.dava_feature_count, .dava_total_count - .dava_feature_count) ~",
        paste(settings$predictors, collapse = " + ")
      ))
      model <- corncob::bbdml(formula, phi.formula = phi_formula, data = model_data)
      models[[index]] <<- model
      fitted[, index] <<- as.numeric(model$mu.resp) * total
      coefficient_table <- summary(model)$coefficients
      term <- grep(paste0("^mu\\.", focus), rownames(coefficient_table), value = TRUE)[1] %||% ""
      if (!nzchar(term)) return(data.frame(feature = feature, error = "The coefficient of the variable of interest is not estimable"))
      data.frame(
        feature = feature, term = sub("^mu\\.", "", term), estimate = coefficient_table[term, 1],
        std.error = coefficient_table[term, 2], statistic = coefficient_table[term, 3],
        p.value = coefficient_table[term, 4], stringsAsFactors = FALSE
      )
    })
    table <- dplyr::bind_rows(rows)
    table$p.adjust <- if ("p.value" %in% names(table)) stats::p.adjust(table$p.value, method = settings$fdr_method %||% "BH") else NA_real_
    return(list(model = models, feature_results = table, fitted = fitted,
                filter_records = spec$filter_record, coefficient_name = focus))
  }
  if (method_id == "metagenomeseq") {
    metadata <- spec$metadata
    rownames(metadata) <- paste0("sample_", seq_len(nrow(metadata)))
    colnames(spec$counts) <- rownames(metadata)
    object <- metagenomeSeq::newMRexperiment(
      spec$counts, phenoData = Biobase::AnnotatedDataFrame(metadata)
    )
    object <- metagenomeSeq::cumNorm(object)
    design <- stats::model.matrix(spec$design, data = metadata)
    coefficient <- grep(focus, colnames(design))[1] %||% NA_integer_
    if (!is.finite(coefficient)) stop("metagenomeSeq cannot construct design matrix coefficients for the variable of interest.", call. = FALSE)
    fit <- metagenomeSeq::fitZig(object, design)
    fit_lm <- methods::slot(fit, "fit")
    estimates <- fit_lm$coefficients[, coefficient]
    standard_errors <- fit_lm$stdev.unscaled[, coefficient] * fit_lm$sigma
    statistics <- estimates / standard_errors
    p_values <- 2 * stats::pt(abs(statistics), df = fit_lm$df.residual, lower.tail = FALSE)
    table <- data.frame(
      feature = rownames(fit_lm$coefficients), term = colnames(design)[coefficient],
      estimate = estimates, std.error = standard_errors, statistic = statistics,
      p.value = p_values, p.adjust = stats::p.adjust(p_values, method = settings$fdr_method %||% "BH"),
      stringsAsFactors = FALSE
    )
    fitted <- fit_lm$design %*% t(fit_lm$coefficients)
    return(list(model = fit, feature_results = table, fitted = fitted,
                filter_records = spec$filter_record, coefficient_name = colnames(design)[coefficient]))
  }
  if (method_id == "edger") {
    dge <- edgeR::DGEList(counts = spec$counts)
    dge <- edgeR::calcNormFactors(dge)
    design <- stats::model.matrix(spec$design, data = spec$metadata)
    coefficient <- grep(focus, colnames(design))[1] %||% NA_integer_
    if (!is.finite(coefficient)) stop("edgeR cannot construct the design matrix coefficients for the variable of interest.", call. = FALSE)
    dge <- edgeR::estimateDisp(dge, design)
    fit <- edgeR::glmQLFit(dge, design, robust = TRUE)
    test <- edgeR::glmQLFTest(fit, coef = coefficient)
    table <- edgeR::topTags(test, n = Inf, sort.by = "none")$table
    table$feature <- rownames(table)
    rownames(table) <- NULL
    names(table)[names(table) == "logFC"] <- "estimate"
    names(table)[names(table) == "PValue"] <- "p.value"
    names(table)[names(table) == "FDR"] <- "p.adjust"
    return(list(model = fit, feature_results = table, fitted = t(fit$fitted.values),
                filter_records = spec$filter_record, coefficient_name = colnames(design)[coefficient]))
  }
  if (method_id == "aldex2") {
    conditions <- spec$metadata[[focus]]
    if (length(unique(stats::na.omit(conditions))) != 2L) {
      stop("ALDEx2 The current adapter requires that the variable of interest contain exactly two levels.", call. = FALSE)
    }
    clr <- ALDEx2::aldex.clr(
      spec$counts, as.character(conditions),
      mc.samples = max(16L, as.integer(settings$mcmc_samples %||% 128L)), verbose = FALSE
    )
    tests <- ALDEx2::aldex.ttest(clr, verbose = FALSE)
    effects <- ALDEx2::aldex.effect(clr, verbose = FALSE)
    table <- cbind(tests, effects)
    table$feature <- rownames(table)
    rownames(table) <- NULL
    table$estimate <- table$effect
    table$p.value <- table$we.ep
    table$p.adjust <- table$we.eBH
    instances <- ALDEx2::getMonteCarloInstances(clr)
    fitted <- t(vapply(instances, rowMeans, numeric(length(spec$features))))
    colnames(fitted) <- spec$features
    return(list(model = clr, feature_results = table, fitted = fitted,
                filter_records = spec$filter_record, coefficient_name = focus))
  }
  stop(sprintf("Microbial counting adapter not yet supported: %s", method_id), call. = FALSE)
}

fit_regression_pgls_adapter <- function(data, formula, settings) {
  feature_id <- settings$feature_id
  tree <- settings$phylogeny
  model_name <- settings$phylogenetic_model %||% "lambda"
  allowed <- c("lambda", "BM", "OUrandomRoot")
  if (!model_name %in% allowed) stop("PGLS phylogeny related structure is invalid.", call. = FALSE)
  model_data <- data
  rownames(model_data) <- as.character(model_data[[feature_id]])
  phylolm::phylolm(formula, data = model_data, phy = tree, model = model_name)
}

# Mediation and RegulationSharedlineSexmodelBasics，But return to their respective scientific researchResults，Cannot return to normal regression display。
fit_regression_mediation_adapter <- function(data, settings) {
  y <- settings$responses[1]
  x <- settings$focus_predictor
  mediators <- unique(settings$mediators %||% character())
  covariates <- setdiff(settings$predictors, c(x, mediators))
  if (!length(mediators)) stop("Mediation analysis requires the selection of at least one mediating variable M.", call. = FALSE)
  if (any(!vapply(data[c(y, x, mediators)], is.numeric, logical(1)))) {
    stop("The current mediation adapter requires that X, M, and Y are all numeric variables.", call. = FALSE)
  }
  mediator_models <- stats::setNames(lapply(mediators, function(m) {
    stats::lm(stats::reformulate(c(x, covariates), response = m), data = data)
  }), mediators)
  outcome_model <- stats::lm(stats::reformulate(c(x, mediators, covariates), response = y), data = data)
  total_model <- stats::lm(stats::reformulate(c(x, covariates), response = y), data = data)
  a <- vapply(mediators, function(m) stats::coef(mediator_models[[m]])[[x]], numeric(1))
  b <- stats::coef(outcome_model)[mediators]
  indirect <- a * b
  direct <- unname(stats::coef(outcome_model)[x])
  total <- unname(stats::coef(total_model)[x])

  bootstrap_n <- max(200L, as.integer(settings$bootstrap %||% 1000L))
  confidence <- settings$confidence_level %||% 0.95
  seed <- as.integer(settings$seed %||% 123L)
  set.seed(seed)
  boot_indirect <- replicate(bootstrap_n, {
    idx <- sample.int(nrow(data), replace = TRUE)
    dd <- data[idx, , drop = FALSE]
    om <- tryCatch(stats::lm(stats::reformulate(c(x, mediators, covariates), response = y), data = dd), error = function(e) NULL)
    if (is.null(om)) return(rep(NA_real_, length(mediators)))
    vapply(mediators, function(m) {
      mm <- tryCatch(stats::lm(stats::reformulate(c(x, covariates), response = m), data = dd), error = function(e) NULL)
      if (is.null(mm)) return(NA_real_)
      unname(stats::coef(mm)[x] * stats::coef(om)[m])
    }, numeric(1))
  })
  if (is.null(dim(boot_indirect))) boot_indirect <- matrix(boot_indirect, nrow = length(mediators))
  alpha <- (1 - confidence) / 2
  ci <- t(apply(boot_indirect, 1, stats::quantile, probs = c(alpha, 1 - alpha), na.rm = TRUE, names = FALSE))
  p_boot <- apply(boot_indirect, 1, function(z) {
    z <- z[is.finite(z)]
    if (!length(z)) return(NA_real_)
    min(1, 2 * min(mean(z <= 0), mean(z >= 0)))
  })
  results <- data.frame(
    mediator = mediators, path_a = unname(a), path_b = unname(b),
    indirect_effect = unname(indirect), conf.low = ci[, 1], conf.high = ci[, 2],
    p.value = p_boot, direct_effect = direct, total_effect = total,
    proportion_mediated = if (is.finite(total) && total != 0) indirect / total else NA_real_,
    bootstrap = bootstrap_n, stringsAsFactors = FALSE
  )
  list(model = outcome_model, mediator_models = mediator_models, total_model = total_model,
       mediation_results = results)
}

fit_regression_moderation_adapter <- function(data, settings) {
  y <- settings$responses[1]
  x <- settings$focus_predictor
  w <- settings$moderator %||% ""
  if (!nzchar(w) || !w %in% names(data)) stop("Moderator analysis must select a valid moderator variable W.", call. = FALSE)
  centers <- numeric()
  if (isTRUE(settings$center)) {
    center_variables <- c(x, w)[vapply(data[c(x, w)], is.numeric, logical(1))]
    centers <- vapply(data[center_variables], mean, numeric(1), na.rm = TRUE)
    for (variable in center_variables) data[[variable]] <- data[[variable]] - centers[[variable]]
  }
  covariates <- setdiff(settings$predictors, c(x, w))
  model <- stats::lm(stats::reformulate(c(sprintf("%s * %s", x, w), covariates), response = y), data = data)
  confidence <- settings$confidence_level %||% 0.95
  critical <- stats::qt(1 - (1 - confidence) / 2, stats::df.residual(model))
  co <- stats::coef(model)
  vc <- stats::vcov(model)
  interaction_names <- c(paste0(x, ":", w), paste0(w, ":", x))
  interaction <- interaction_names[interaction_names %in% names(co)][1] %||% ""
  if (!nzchar(interaction)) stop("Unable to identify interaction coefficients from the moderation model.", call. = FALSE)

  if (is.numeric(data[[w]])) {
    representative <- unique(c(mean(data[[w]]), mean(data[[w]]) - stats::sd(data[[w]]), mean(data[[w]]) + stats::sd(data[[w]])))
    slope_table <- dplyr::bind_rows(lapply(representative, function(value) {
      slope <- unname(co[x] + value * co[interaction])
      variance <- vc[x, x] + value^2 * vc[interaction, interaction] + 2 * value * vc[x, interaction]
      se <- sqrt(max(variance, 0))
      data.frame(moderator_value = value, slope = slope, std.error = se,
                 conf.low = slope - critical * se, conf.high = slope + critical * se,
                 p.value = 2 * stats::pt(-abs(slope / se), stats::df.residual(model)))
    }))
    w_grid <- seq(min(data[[w]]), max(data[[w]]), length.out = 400L)
    jn <- dplyr::bind_rows(lapply(w_grid, function(value) {
      slope <- unname(co[x] + value * co[interaction])
      se <- sqrt(max(vc[x, x] + value^2 * vc[interaction, interaction] + 2 * value * vc[x, interaction], 0))
      data.frame(moderator_value = value, slope = slope, conf.low = slope - critical * se,
                 conf.high = slope + critical * se, significant = (slope - critical * se) * (slope + critical * se) > 0)
    }))
    grid <- dplyr::bind_rows(lapply(representative, function(value) {
      dd <- build_adjusted_prediction_grid(data, settings$predictors, x, reference_mode = "mean")
      dd[[w]] <- value
      cbind(dd, moderator_value = value, predict_regression_safe(model, dd, "lm"))
    }))
  } else {
    data[[w]] <- droplevels(factor(data[[w]]))
    trend <- emmeans::emtrends(model, specs = w, var = x)
    slope_table <- as.data.frame(trend)
    names(slope_table)[names(slope_table) == paste0(x, ".trend")] <- "slope"
    jn <- data.frame()
    grid <- dplyr::bind_rows(lapply(levels(data[[w]]), function(value) {
      dd <- build_adjusted_prediction_grid(data, settings$predictors, x, reference_mode = "mean")
      dd[[w]] <- factor(value, levels = levels(data[[w]]))
      cbind(dd, moderator_value = value, predict_regression_safe(model, dd, "lm"))
    }))
  }
  list(model = model, model_data = data, moderation_results = slope_table, johnson_neyman = jn,
       moderation_predictions = grid, interaction_term = interaction, centers = centers)
}

regression_variable_selection <- function(model, settings, focus_predictor = "") {
  method <- settings$selection_method %||% "none"
  if (identical(method, "none")) return(list(model = model, path = data.frame()))
  if (!inherits(model, c("lm", "glm"))) stop("The current model does not support AIC/BIC-based stepwise variable selection.", call. = FALSE)
  family_name <- if (inherits(model, "glm")) stats::family(model)$family else "gaussian"
  if (grepl("quasi", family_name, ignore.case = TRUE)) stop("The quasi-likelihood model has no comparable AIC/BIC and cannot perform stepwise variable selection.", call. = FALSE)
  upper <- stats::formula(model)
  selection_data <- stats::model.frame(model)
  environment(upper) <- environment()
  model <- if (inherits(model, "glm")) {
    stats::glm(upper, data = selection_data, family = stats::family(model))
  } else {
    stats::lm(upper, data = selection_data)
  }
  labels <- attr(stats::terms(model), "term.labels")
  focus_pattern <- paste0("(^|[^[:alnum:]_.])`?", gsub("([][{}()+*^$|\\?.])", "\\\\\\1", focus_predictor), "`?([^[:alnum:]_.]|$)")
  required <- if (isTRUE(settings$selection_keep_focus) && nzchar(focus_predictor)) labels[grepl(focus_pattern, labels)] else character()
  lower <- stats::reformulate(required, response = all.vars(upper)[1])
  environment(lower) <- environment()
  start <- if (identical(method, "forward")) stats::update(model, lower) else model
  criterion <- toupper(settings$selection_criterion %||% "AIC")
  k <- if (identical(criterion, "BIC")) log(stats::nobs(model)) else 2
  selected <- stats::step(start, scope = list(lower = lower, upper = upper), direction = method, k = k, trace = 0)
  path <- as.data.frame(selected$anova %||% data.frame())
  if (nrow(path)) {
    path$step_number <- seq_len(nrow(path)) - 1L
    path$criterion <- criterion
  }
  list(model = selected, path = path)
}

regression_collinearity_table <- function(model, threshold = 5) {
  if (!inherits(model, c("lm", "glm"))) return(data.frame())
  matrix <- stats::model.matrix(model)
  assign <- attr(matrix, "assign")
  keep <- colnames(matrix) != "(Intercept)"
  matrix <- matrix[, keep, drop = FALSE]
  assign <- assign[keep]
  if (!ncol(matrix)) return(data.frame())
  term_labels <- attr(stats::terms(model), "term.labels")
  values <- vapply(seq_len(ncol(matrix)), function(index) {
    target <- matrix[, index]
    others <- matrix[, -index, drop = FALSE]
    if (!stats::sd(target)) return(Inf)
    if (!ncol(others)) return(1)
    fit <- stats::lm.fit(cbind(`(Intercept)` = 1, others), target)
    rss <- sum(fit$residuals^2)
    tss <- sum((target - mean(target))^2)
    r_squared <- if (tss > 0) 1 - rss / tss else 1
    if (!is.finite(r_squared) || r_squared >= 1 - sqrt(.Machine$double.eps)) Inf else 1 / (1 - max(0, r_squared))
  }, numeric(1))
  threshold <- if (is.finite(threshold) && threshold > 0) threshold else 5
  data.frame(
    term = ifelse(assign > 0, term_labels[assign], colnames(matrix)),
    design_column = colnames(matrix), vif = values,
    tolerance = ifelse(is.finite(values) & values > 0, 1 / values, 0),
    threshold = threshold,
    assessment = ifelse(!is.finite(values), "Completely collinear", ifelse(values >= threshold, "requires attention", "Acceptable")),
    stringsAsFactors = FALSE, check.names = FALSE
  )
}

fit_regression_engine <- function(df, settings) {
  settings <- as_regression_model_spec(settings)
  method_id <- settings$method_id
  capability <- regression_model_capability(method_id)
  if (!isTRUE(capability$available)) {
    if (exists("ensure_regression_packages", mode = "function")) {
      ensure_regression_packages(capability$package, paste0("model ", capability$label))
    }
    stop(sprintf("Model %s requires R package %s to be installed.", capability$label, capability$package), call. = FALSE)
  }
  if (length(settings$responses %||% character()) != 1L && !method_id %in% c("pls2", "multivariate_tree", "rda", "cca", "dbrda", "manyglm", "gllvm", "jsdm", "rrr", "maaslin2", "ancombc2", "deseq2", "edger", "corncob", "aldex2", "metagenomeseq", "multivariable_association")) {
    stop("Current regression analysis only supports single response variables, please select only one response variable.", call. = FALSE)
  }
  prepared <- prepare_regression_data(df, settings$responses, settings$predictors,
                                      settings$group_var %||% "", settings$weight_var %||% "",
                                      c(settings$zero_predictors %||% character(),
                                        settings$trials_var %||% "",
                                        settings$dispersion_predictors %||% character(),
                                        settings$feature_id %||% "",
                                        settings$nested_group %||% "",
                                        settings$crossed_groups %||% character(),
                                        settings$random_slope_variable %||% ""))
  data <- prepared$data
  responses <- prepared$responses
  predictors <- prepared$predictors
  scenario <- settings$scenario %||% "overall"
  focus <- settings$focus_predictor %||% predictors[1]
  group_var <- settings$group_var %||% ""
  if (!scenario %in% c("overall", "mediation", "moderation", "microbiome_contrast", "microbiome_interaction") && !nzchar(group_var)) {
    stop("The current grouping scenario requires selecting a grouping variable.", call. = FALSE)
  }
  if (scenario == "group_independent" && method_id %in% c("pls1", "pls2", "pcr", "ridge", "lasso", "elastic_net")) {
    stop("The current method does not support group independent fitting.", call. = FALSE)
  }
  formula <- if (method_id == "aggregated_binomial") {
    trial_var <- settings$trials_var %||% ""
    stats::reformulate(predictors, response = sprintf("cbind(`%s`, `%s` - `%s`)", responses[1], trial_var, responses[1]))
  } else if (method_id == "nls") {
    starts <- parse_regression_nls_starts(settings$nls_start)
    build_regression_nls_formula(settings$nls_formula, responses[1], predictors, names(starts))
  } else if (method_id == "moderation") {
    stats::reformulate(c(sprintf("%s * %s", focus, settings$moderator), setdiff(predictors, c(focus, settings$moderator))), response = responses[1])
  } else if (method_id == "mediation") {
    stats::reformulate(c(focus, settings$mediators, setdiff(predictors, c(focus, settings$mediators))), response = responses[1])
  } else build_regression_formula(responses, predictors, focus, scenario, group_var,
                                  isTRUE(settings$random_slope), settings$degree %||% 2L, method_id,
                                  random_structure = settings$random_structure %||% "intercept",
                                  nested_group = settings$nested_group %||% "",
                                  crossed_groups = settings$crossed_groups %||% character(),
                                  random_slope_correlated = isTRUE(settings$random_slope_correlated %||% TRUE),
                                  random_slope_predictor = settings$random_slope_variable %||% focus)
  settings$focus_predictor <- focus
  settings$predictors <- predictors
  settings$responses <- responses
  validation_error <- tryCatch({
    validate_regression_data_for_capability(data, settings, capability)
    ""
  }, error = function(e) conditionMessage(e))
  if (nzchar(validation_error)) return(new_regression_result(
    status = "error", method_id = method_id, method_name = capability$label,
    responses = responses, predictors = predictors, focus_predictor = focus,
    group_var = group_var, formula = paste(deparse(formula), collapse = " "),
    settings = unclass(settings), model_data = data, data_summary = prepared$summary,
    actual_rows = data$.dava_row_id, errors = validation_error
  ))

  fit_one <- function(dd, formula_value = formula) {
    if (method_id %in% c("lm", "polynomial", "spline", "segmented", "nls", "multivariate_lm")) return(fit_regression_linear_adapter(dd, formula_value, method_id, settings))
    if (method_id %in% c("logistic", "aggregated_binomial", "weighted_binomial", "multinomial", "ordinal", "poisson", "negative_binomial", "gamma", "quasipoisson", "quasibinomial", "beta", "zip", "zinb", "hurdle", "hurdle_poisson", "hurdle_negbin")) return(fit_regression_glm_adapter(dd, formula_value, method_id, settings))
    if (method_id %in% c("lmm", "glmm", "gamm", "zip_mixed", "zinb_mixed")) return(fit_regression_mixed_adapter(dd, formula_value, method_id, settings))
    if (method_id %in% c("gam", "loess", "quantile", "robust")) return(fit_regression_semiparametric_adapter(dd, formula_value, method_id, settings))
    if (method_id %in% c("rpart", "random_forest", "gradient_boost", "xgboost", "svr", "neural_network")) return(fit_regression_ml_adapter(dd, formula_value, responses[1], predictors, method_id, settings))
    NULL
  }

  capture <- regression_capture({
    if (method_id %in% c("maaslin2", "ancombc2", "deseq2", "edger", "corncob", "aldex2", "metagenomeseq")) fit_regression_microbiome_count_adapter(data, method_id, settings)
    else if (method_id == "multivariable_association") fit_regression_feature_association_adapter(data, settings)
    else if (method_id == "pgls") fit_regression_pgls_adapter(data, formula, settings)
    else if (method_id == "mediation") fit_regression_mediation_adapter(data, settings)
    else if (method_id == "moderation") fit_regression_moderation_adapter(data, settings)
    else if (method_id %in% c("pls1", "pls2", "pcr")) fit_regression_pls_adapter(data, responses, predictors, method_id, settings)
    else if (method_id == "multivariate_tree") fit_regression_multivariate_tree_adapter(data, responses, predictors, settings)
    else if (method_id %in% c("rda", "cca", "dbrda", "manyglm", "gllvm", "jsdm", "rrr")) fit_regression_community_adapter(data, formula, method_id, settings)
    else if (method_id %in% c("ridge", "lasso", "elastic_net", "adaptive_lasso")) fit_regression_regularized_adapter(data, responses[1], predictors, method_id, settings)
    else if (scenario == "group_independent") {
      models <- lapply(split(data, data[[group_var]], drop = TRUE), function(dd) fit_one(dd, build_regression_formula(responses, predictors, focus, "overall", "", FALSE, settings$degree %||% 2L, method_id)))
      list(grouped_models = models)
    } else fit_one(data)
  })
  if (!is.null(capture$error) && nzchar(capture$error)) return(new_regression_result(
    status = "error", method_id = method_id, method_name = capability$label, responses = responses,
    predictors = predictors, formula = paste(deparse(formula), collapse = " "), errors = capture$error,
    warnings = capture$warnings, model_data = data, data_summary = prepared$summary
  ))

  wrapped <- capture$value
  wrapped_model <- inherits(wrapped, c(
    "lm", "glm", "nls", "merMod", "gam", "rq", "rlm", "loess", "polr", "multinom",
    "rpart", "ranger", "xgb.Booster", "svm", "nnet", "mvr", "cv.glmnet",
    "betareg", "zeroinfl", "hurdle", "glmmTMB", "cca", "manyglm", "gllvm", "Hmsc", "rrr", "phylolm"
  ))
  grouped_models <- if (is.list(wrapped) && !wrapped_model) wrapped[["grouped_models"]] %||% list() else list()
  model <- if (length(grouped_models)) NULL else if (wrapped_model) wrapped else wrapped[["model"]]
  if (method_id == "moderation" && is.list(wrapped) && is.data.frame(wrapped$model_data)) data <- wrapped$model_data
  ncomp <- if (is.list(wrapped) && !wrapped_model) wrapped[["ncomp"]] %||% NULL else NULL
  model_terms <- if (is.list(wrapped) && !wrapped_model) wrapped[["terms"]] %||% NULL else NULL
  lambda <- if (inherits(model, "cv.glmnet")) settings$lambda_rule %||% "lambda.min" else NULL
  if (inherits(model, "merMod") && lme4::isSingular(model, tol = 1e-4)) {
    capture$warnings <- unique(c(capture$warnings, "The mixed effects model is a singular fit, please check the random effects structure."))
  }
  full_model <- model
  selection <- tryCatch(
    if (!is.null(model) && !length(grouped_models)) {
      regression_variable_selection(model, settings, focus)
    } else list(model = model, path = data.frame()),
    error = function(error) error
  )
  if (inherits(selection, "error")) return(new_regression_result(
    status = "error", method_id = method_id, method_name = capability$label,
    responses = responses, predictors = predictors, focus_predictor = focus,
    group_var = group_var, formula = paste(deparse(formula), collapse = " "),
    settings = unclass(settings), model_data = data, data_summary = prepared$summary,
    actual_rows = data$.dava_row_id, errors = conditionMessage(selection), warnings = capture$warnings
  ))
  model <- selection$model
  variable_selection <- selection$path
  effective_formula <- if (!is.null(model)) tryCatch(stats::formula(model), error = function(e) formula) else formula

  coefficients <- data.frame()
  fit_metrics <- data.frame()
  observed_fitted <- data.frame()
  diagnostics <- data.frame()
  loadings <- data.frame()
  scores <- data.frame()
  importance <- data.frame()
  group_effects <- data.frame()
  slope_comparisons <- data.frame()
  fixed_effects <- data.frame()
  random_effects_table <- data.frame()
  variance_components <- data.frame()
  smooth_terms <- data.frame()
  thresholds <- data.frame()
  conditional_model <- data.frame()
  zero_inflation_model <- data.frame()
  dispersion_model <- data.frame()
  marginal_predictions <- data.frame()
  conditional_predictions <- data.frame()
  grouped_adjusted <- data.frame()
  community_results <- data.frame()
  feature_results <- if (is.list(wrapped) && !wrapped_model) wrapped$feature_results %||% data.frame() else data.frame()
  mediation_results <- if (is.list(wrapped) && !wrapped_model) wrapped$mediation_results %||% data.frame() else data.frame()
  moderation_results <- if (is.list(wrapped) && !wrapped_model) wrapped$moderation_results %||% data.frame() else data.frame()
  johnson_neyman <- if (is.list(wrapped) && !wrapped_model) wrapped$johnson_neyman %||% data.frame() else data.frame()
  filter_records <- if (is.list(wrapped) && !wrapped_model) wrapped$filter_records %||% data.frame() else data.frame()
  collinearity <- if (isTRUE(settings$collinearity) && !is.null(model)) {
    threshold <- as.numeric(settings$vif_threshold %||% 5)
    candidate <- regression_collinearity_table(full_model, threshold)
    if (nrow(candidate)) candidate$model_stage <- "candidate_full_model"
    selected <- if (!identical(settings$selection_method %||% "none", "none")) {
      regression_collinearity_table(model, threshold)
    } else data.frame()
    if (nrow(selected)) selected$model_stage <- "selected_final_model"
    dplyr::bind_rows(candidate, selected)
  } else data.frame()

  if (method_id %in% c("maaslin2", "ancombc2", "deseq2", "edger", "corncob", "aldex2", "metagenomeseq")) {
    fitted_matrix <- as.matrix(wrapped$fitted)
    observed_fitted <- dplyr::bind_rows(lapply(seq_along(responses), function(i) data.frame(
      .row = data$.dava_row_id, response = responses[i], observed = data[[responses[i]]],
      predicted = fitted_matrix[, i], stringsAsFactors = FALSE
    )))
    coefficients <- feature_results
    fit_metrics <- data.frame(
      tested_features = nrow(feature_results), retained_features = sum(filter_records$retained),
      significant_features = sum(feature_results$p.adjust < (settings$significance_threshold %||% 0.05), na.rm = TRUE),
      coefficient = wrapped$coefficient_name %||% "", stringsAsFactors = FALSE
    )
  } else if (method_id == "multivariable_association") {
    observed_fitted <- dplyr::bind_rows(lapply(responses, function(response) {
      fitted_values <- as.numeric(stats::fitted(model[[response]]))
      data.frame(.row = data$.dava_row_id, response = response,
                 observed = data[[response]], predicted = fitted_values)
    }))
    coefficients <- feature_results
    fit_metrics <- dplyr::bind_rows(lapply(responses, function(response) {
      dd <- observed_fitted[observed_fitted$response == response, , drop = FALSE]
      cbind(response = response, regression_metrics(dd$observed, dd$predicted, length(predictors)))
    }))
  } else if (length(grouped_models)) {
    group_rows <- lapply(names(grouped_models), function(g) {
      m <- grouped_models[[g]]
      dd <- data[data[[group_var]] == g, , drop = FALSE]
      pred <- as.numeric(if (inherits(m, "glm")) stats::predict(m, newdata = dd, type = "response") else stats::predict(m, newdata = dd))
      co <- regression_tidy_model(m); co[[group_var]] <- g
      metric <- cbind(group = g, regression_metrics(dd[[responses[1]]], pred, length(predictors)))
      metric$p.value <- regression_model_p_value(m, focus)
      group_grid <- build_adjusted_prediction_grid(
        dd, predictors, focus, reference_mode = settings$reference_mode %||% "mean"
      )
      group_prediction <- predict_regression_safe(m, group_grid, method_id)
      if (nrow(group_prediction)) {
        group_prediction[[group_var]] <- rep(dd[[group_var]][1], nrow(group_prediction))
        group_prediction$response <- responses[1]
      }
      list(
        co = co, metric = metric, adjusted = group_prediction,
        fitted = data.frame(.row = dd$.dava_row_id, group = g, response = responses[1], observed = dd[[responses[1]]], predicted = pred)
      )
    })
    coefficients <- dplyr::bind_rows(lapply(group_rows, `[[`, "co"))
    fit_metrics <- dplyr::bind_rows(lapply(group_rows, `[[`, "metric"))
    observed_fitted <- dplyr::bind_rows(lapply(group_rows, `[[`, "fitted"))
    grouped_adjusted <- dplyr::bind_rows(lapply(group_rows, `[[`, "adjusted"))
  } else if (inherits(model, "cca")) {
    permutations <- as.integer(settings$permutations %||% 999L)
    overall_test <- tryCatch(as.data.frame(stats::anova(model, permutations = permutations)), error = function(e) data.frame())
    if (nrow(overall_test)) {
      overall_test$term <- rownames(overall_test)
      rownames(overall_test) <- NULL
    }
    term_test <- tryCatch(as.data.frame(stats::anova(model, by = "term", permutations = permutations)), error = function(e) data.frame())
    if (nrow(term_test)) {
      term_test$term <- rownames(term_test)
      rownames(term_test) <- NULL
    }
    community_parts <- list()
    if (nrow(overall_test)) community_parts$overall <- transform(overall_test, test_type = "overall")
    if (nrow(term_test)) community_parts$term <- transform(term_test, test_type = "term")
    community_results <- dplyr::bind_rows(community_parts)
    scores <- tryCatch(as.data.frame(vegan::scores(model, display = "sites", choices = 1:2, scaling = 2)), error = function(e) data.frame())
    if (nrow(scores)) scores$.row <- data$.dava_row_id
    loadings <- tryCatch(as.data.frame(vegan::scores(model, display = "species", choices = 1:2, scaling = 2)), error = function(e) data.frame())
    if (nrow(loadings)) {
      loadings$variable <- rownames(loadings)
      rownames(loadings) <- NULL
    }
    coefficients <- term_test
    fit_metrics <- data.frame(
      constrained = model$CCA$tot.chi %||% NA_real_,
      unconstrained = model$CA$tot.chi %||% NA_real_, stringsAsFactors = FALSE
    )
  } else if (inherits(model, "manyglm")) {
    pred_matrix <- as.matrix(stats::fitted(model))
    observed_fitted <- dplyr::bind_rows(lapply(seq_along(responses), function(i) data.frame(
      .row = data$.dava_row_id, response = responses[i], observed = data[[responses[i]]], predicted = pred_matrix[, i]
    )))
    coefficient_matrix <- stats::coef(model)
    coefficients <- data.frame(
      term = rep(rownames(coefficient_matrix), times = ncol(coefficient_matrix)),
      response = rep(responses, each = nrow(coefficient_matrix)), estimate = as.numeric(coefficient_matrix),
      stringsAsFactors = FALSE
    )
    permutations <- max(99L, as.integer(settings$permutations %||% 999L))
    community_results <- tryCatch({
      test <- as.data.frame(mvabund::anova.manyglm(model, resamp = "pit.trap", nBoot = permutations, show.time = "none")$table)
      test$term <- rownames(test); rownames(test) <- NULL
      p_col <- grep("Pr", names(test), value = TRUE)[1] %||% ""
      if (nzchar(p_col)) test$p.adjust <- stats::p.adjust(test[[p_col]], method = settings$fdr_method %||% "BH")
      test
    }, error = function(e) data.frame(error = conditionMessage(e), stringsAsFactors = FALSE))
    fit_metrics <- dplyr::bind_rows(lapply(responses, function(y) {
      dd <- observed_fitted[observed_fitted$response == y, , drop = FALSE]
      cbind(response = y, regression_metrics(dd$observed, dd$predicted, length(predictors)))
    }))
  } else if (inherits(model, "gllvm")) {
    x_data <- attr(model, "dava_x")
    pred_matrix <- as.matrix(stats::predict(model, newX = x_data, type = "response"))
    observed_fitted <- dplyr::bind_rows(lapply(seq_along(responses), function(i) data.frame(
      .row = data$.dava_row_id, response = responses[i], observed = data[[responses[i]]], predicted = pred_matrix[, i]
    )))
    co <- stats::coef(model)
    xcoef <- as.matrix(co$Xcoef)
    coefficients <- data.frame(
      term = rep(colnames(xcoef), each = nrow(xcoef)),
      response = rep(rownames(xcoef), times = ncol(xcoef)), estimate = as.numeric(xcoef), stringsAsFactors = FALSE
    )
    scores <- as.data.frame(model$lvs); names(scores) <- paste0("LV", seq_len(ncol(scores))); scores$.row <- data$.dava_row_id
    loadings <- as.data.frame(co$Species.scores); names(loadings) <- paste0("LV", seq_len(ncol(loadings))); loadings$variable <- responses
    community_results <- data.frame(logLik = model$logL, convergence = model$convergence %||% NA, latent_variables = model$num.lv)
    fit_metrics <- dplyr::bind_rows(lapply(responses, function(y) {
      dd <- observed_fitted[observed_fitted$response == y, , drop = FALSE]
      cbind(response = y, regression_metrics(dd$observed, dd$predicted, length(predictors)))
    }))
  } else if (inherits(model, "Hmsc")) {
    posterior_predictions <- Hmsc::computePredictedValues(model, expected = TRUE, verbose = 0)
    pred_matrix <- apply(posterior_predictions, c(1, 2), mean)
    observed_fitted <- dplyr::bind_rows(lapply(seq_along(responses), function(i) data.frame(
      .row = data$.dava_row_id, response = responses[i], observed = data[[responses[i]]], predicted = pred_matrix[, i]
    )))
    beta <- Hmsc::getPostEstimate(model, "Beta")
    beta_mean <- beta$mean
    term_names <- rownames(beta_mean) %||% c("(Intercept)", predictors)
    coefficients <- data.frame(
      term = rep(term_names, times = ncol(beta_mean)), response = rep(responses, each = nrow(beta_mean)),
      estimate = as.numeric(beta_mean), posterior_support = as.numeric(beta$support), stringsAsFactors = FALSE
    )
    community_results <- data.frame(
      WAIC = as.numeric(Hmsc::computeWAIC(model)), posterior_samples = settings$mcmc_samples %||% 250L,
      transient = settings$mcmc_transient %||% 250L, distribution = settings$family %||% "normal"
    )
    fit_metrics <- dplyr::bind_rows(lapply(responses, function(y) {
      dd <- observed_fitted[observed_fitted$response == y, , drop = FALSE]
      cbind(response = y, regression_metrics(dd$observed, dd$predicted, length(predictors)))
    }))
  } else if (inherits(model, "rrr")) {
    x <- attr(model, "dava_x")
    pred_matrix <- x %*% model$coef
    colnames(pred_matrix) <- responses
    observed_fitted <- dplyr::bind_rows(lapply(seq_along(responses), function(i) data.frame(
      .row = data$.dava_row_id, response = responses[i], observed = data[[responses[i]]], predicted = pred_matrix[, i]
    )))
    coefficients <- data.frame(
      term = rep(rownames(model$coef) %||% colnames(x), times = ncol(model$coef)),
      response = rep(responses, each = nrow(model$coef)), estimate = as.numeric(model$coef), stringsAsFactors = FALSE
    )
    scores <- as.data.frame(x %*% model$U); names(scores) <- paste0("RR", seq_len(ncol(scores))); scores$.row <- data$.dava_row_id
    loadings <- as.data.frame(model$V); names(loadings) <- paste0("RR", seq_len(ncol(loadings))); loadings$variable <- responses
    community_results <- data.frame(rank = model$rank, sse = tail(model$sse, 1), information_criterion = tail(model$ic, 1))
    fit_metrics <- dplyr::bind_rows(lapply(responses, function(y) {
      dd <- observed_fitted[observed_fitted$response == y, , drop = FALSE]
      cbind(response = y, regression_metrics(dd$observed, dd$predicted, length(predictors)))
    }))
  } else if (inherits(model, "mlm")) {
    pred <- stats::predict(model, data)
    observed_fitted <- dplyr::bind_rows(lapply(seq_along(responses), function(i) data.frame(
      .row = data$.dava_row_id, response = responses[i], observed = data[[responses[i]]], predicted = pred[, i]
    )))
    coefficients <- data.frame(term = rownames(stats::coef(model)), stats::coef(model), row.names = NULL, check.names = FALSE)
    fit_metrics <- dplyr::bind_rows(lapply(responses, function(y) cbind(response = y, regression_metrics(observed_fitted$observed[observed_fitted$response == y], observed_fitted$predicted[observed_fitted$response == y], length(predictors)))))
  } else if (inherits(model, "phylolm")) {
    estimates <- stats::coef(model)
    standard_errors <- sqrt(diag(stats::vcov(model)))
    statistics <- estimates / standard_errors
    coefficients <- data.frame(
      term = names(estimates), estimate = unname(estimates), std.error = unname(standard_errors),
      statistic = unname(statistics), p.value = 2 * stats::pnorm(abs(statistics), lower.tail = FALSE),
      stringsAsFactors = FALSE
    )
    predicted <- as.numeric(stats::predict(model))
    observed_fitted <- data.frame(
      .row = data$.dava_row_id, response = responses[1], observed = data[[responses[1]]],
      predicted = predicted, feature_id = as.character(data[[settings$feature_id]]), stringsAsFactors = FALSE
    )
    fit_metrics <- cbind(
      regression_metrics(observed_fitted$observed, observed_fitted$predicted, length(predictors)),
      logLik = as.numeric(stats::logLik(model)), AIC = stats::AIC(model),
      phylogenetic_model = settings$phylogenetic_model %||% "lambda",
      phylogenetic_parameter = model$optpar %||% NA_real_
    )
    diagnostics <- transform(observed_fitted, residual = observed - predicted)
  } else {
    if (inherits(model, c("multinom", "polr"))) {
      probabilities <- as.matrix(stats::predict(model, newdata = data, type = "probs"))
      categories <- colnames(probabilities)
      predicted_index <- max.col(probabilities, ties.method = "first")
      observed_index <- match(as.character(data[[responses[1]]]), categories)
      observed_fitted <- data.frame(
        .row = data$.dava_row_id, response = responses[1], observed = observed_index,
        predicted = predicted_index, observed_category = as.character(data[[responses[1]]]),
        predicted_category = categories[predicted_index], predicted_probability = probabilities[cbind(seq_len(nrow(probabilities)), predicted_index)],
        stringsAsFactors = FALSE
      )
      if (inherits(model, "multinom")) {
        summary_model <- summary(model)
        estimates <- as.matrix(summary_model$coefficients)
        standard_errors <- as.matrix(summary_model$standard.errors)
        statistics <- estimates / standard_errors
        coefficients <- data.frame(
          category = rep(rownames(estimates), each = ncol(estimates)), term = rep(colnames(estimates), times = nrow(estimates)),
          estimate = as.numeric(t(estimates)), std.error = as.numeric(t(standard_errors)), statistic = as.numeric(t(statistics)),
          p.value = 2 * stats::pnorm(abs(as.numeric(t(statistics))), lower.tail = FALSE), stringsAsFactors = FALSE
        )
      } else {
        coefficients <- regression_tidy_model(model)
      }
      fit_metrics <- data.frame(
        accuracy = mean(observed_fitted$observed_category == observed_fitted$predicted_category),
        logLik = as.numeric(stats::logLik(model)), AIC = stats::AIC(model), n = nrow(data), stringsAsFactors = FALSE
      )
    } else if (method_id == "multivariate_tree" && inherits(model, "rpart")) {
      prediction_matrix <- as.matrix(stats::predict(model, newdata = data, type = "matrix"))
      prediction_matrix <- prediction_matrix[, seq_along(responses), drop = FALSE]
      prediction_matrix <- sweep(prediction_matrix, 2L, wrapped$response_scale, "*")
      prediction_matrix <- sweep(prediction_matrix, 2L, wrapped$response_center, "+")
      colnames(prediction_matrix) <- responses
      observed_fitted <- dplyr::bind_rows(lapply(seq_along(responses), function(i) data.frame(
        .row = data$.dava_row_id, response = responses[i], observed = data[[responses[i]]],
        predicted = prediction_matrix[, i], stringsAsFactors = FALSE
      )))
      diagnostics <- transform(observed_fitted, fitted = predicted, residual = observed - predicted)
      fit_metrics <- dplyr::bind_rows(lapply(responses, function(response) {
        values <- observed_fitted[observed_fitted$response == response, , drop = FALSE]
        cbind(response = response, regression_metrics(values$observed, values$predicted, length(predictors)))
      }))
      importance <- data.frame(
        term = names(model$variable.importance),
        importance = as.numeric(model$variable.importance), stringsAsFactors = FALSE
      )
      community_results <- data.frame(
        terminal_nodes = sum(model$frame$var == "<leaf>"),
        cp = settings$tree_cp %||% 0.01,
        cross_validation_folds = settings$cv_folds %||% 10L,
        stringsAsFactors = FALSE
      )
    } else if (inherits(model, "mvr")) {
      pred_array <- stats::predict(model, newdata = data, ncomp = ncomp)
      pred_matrix <- matrix(pred_array, nrow = nrow(data), ncol = length(responses))
      observed_fitted <- dplyr::bind_rows(lapply(seq_along(responses), function(i) data.frame(.row = data$.dava_row_id, response = responses[i], observed = data[[responses[i]]], predicted = pred_matrix[, i])))
      loadings <- as.data.frame(pls::loadings(model)[, seq_len(ncomp), drop = FALSE]); loadings$variable <- rownames(loadings); rownames(loadings) <- NULL
      scores <- as.data.frame(pls::scores(model)[, seq_len(ncomp), drop = FALSE]); scores$.row <- data$.dava_row_id
      coefficient_array <- stats::coef(model, ncomp = ncomp, intercept = FALSE)
      coefficient_matrix <- matrix(
        coefficient_array,
        nrow = dim(coefficient_array)[1],
        ncol = dim(coefficient_array)[2],
        dimnames = dimnames(coefficient_array)[1:2]
      )
      coefficients <- data.frame(
        term = rep(rownames(coefficient_matrix), times = ncol(coefficient_matrix)),
        response = rep(colnames(coefficient_matrix), each = nrow(coefficient_matrix)),
        estimate = as.numeric(coefficient_matrix),
        row.names = NULL,
        stringsAsFactors = FALSE
      )
    } else if (inherits(model, "cv.glmnet")) {
      pred <- as.numeric(stats::predict(model, newx = wrapped$x, s = lambda))
      observed_fitted <- data.frame(.row = data$.dava_row_id, response = responses[1], observed = data[[responses[1]]], predicted = pred)
      co <- as.matrix(stats::coef(model, s = lambda)); coefficients <- data.frame(term = rownames(co), estimate = as.numeric(co[, 1]), row.names = NULL)
      fit_metrics <- cbind(lambda.min = model$lambda.min, lambda.1se = model$lambda.1se, regression_metrics(data[[responses[1]]], pred, length(predictors)))
      importance <- transform(coefficients[coefficients$term != "(Intercept)", , drop = FALSE], importance = abs(estimate))
    } else {
      prediction <- tryCatch({
        if (inherits(model, "ranger")) stats::predict(model, data = data)$predictions
        else if (inherits(model, "xgb.Booster")) stats::predict(model, wrapped$x)
        else if (inherits(model, c("glm", "glmmTMB"))) stats::predict(model, newdata = data, type = "response")
        else stats::predict(model, newdata = data)
      }, error = function(e) stats::fitted(model))
      pred <- as.numeric(prediction)
      observed <- if (method_id == "aggregated_binomial") data[[responses[1]]] / data[[settings$trials_var]] else regression_numeric_response(data[[responses[1]]])
      observed_fitted <- data.frame(.row = data$.dava_row_id, response = responses[1], observed = observed, predicted = pred)
      coefficients <- regression_tidy_model(model)
      fit_metrics <- cbind(regression_glance_model(model), regression_metrics(observed_fitted$observed, pred, length(predictors)))
      if (method_id %in% c("quasipoisson", "quasibinomial")) {
        fit_metrics <- fit_metrics[, setdiff(names(fit_metrics), c("AIC", "BIC", "logLik", "deviance")), drop = FALSE]
      }
      diagnostics <- regression_linear_diagnostics(model, data, responses[1])
      if (inherits(model, "rpart")) importance <- data.frame(term = names(model$variable.importance), importance = as.numeric(model$variable.importance))
      if (inherits(model, "ranger")) importance <- data.frame(term = names(model$variable.importance), importance = as.numeric(model$variable.importance))
      if (inherits(model, "xgb.Booster")) importance <- xgboost::xgb.importance(model = model)
    }
    if (!nrow(fit_metrics) && nrow(observed_fitted)) fit_metrics <- dplyr::bind_rows(lapply(split(observed_fitted, observed_fitted$response), function(dd) cbind(response = dd$response[1], regression_metrics(dd$observed, dd$predicted, length(predictors)))))
  }

  grid <- if (!length(grouped_models) && method_id != "pgls" && (length(responses) == 1L || method_id == "pls2")) build_adjusted_prediction_grid(data, predictors, focus, group_var, scenario, settings$reference_mode %||% "mean") else data.frame()
  adjusted <- if (nrow(grid) && method_id %in% c("multinomial", "ordinal")) {
    regression_category_probability_table(model, grid, responses[1])
  } else if (nrow(grid) && method_id == "pls2") {
    prediction_array <- stats::predict(model, newdata = grid, ncomp = ncomp)
    prediction_matrix <- matrix(prediction_array, nrow = nrow(grid), ncol = length(responses))
    dplyr::bind_rows(lapply(seq_along(responses), function(i) cbind(
      grid, response = responses[i], predicted = prediction_matrix[, i],
      conf.low = NA_real_, conf.high = NA_real_, stringsAsFactors = FALSE
    )))
  } else if (nrow(grid)) {
    predict_regression_safe(model, grid, method_id, ncomp = ncomp, lambda = lambda, model_matrix_terms = model_terms)
  } else data.frame()
  if (length(grouped_models)) adjusted <- grouped_adjusted
  if (method_id == "moderation" && is.list(wrapped) && nrow(wrapped$moderation_predictions %||% data.frame())) {
    adjusted <- wrapped$moderation_predictions
  }
  if (nrow(adjusted) && !"response" %in% names(adjusted)) adjusted$response <- responses[1]
  if (inherits(model, c("merMod", "glmmTMB")) && nrow(grid)) {
    marginal_predictions <- predict_regression_safe(model, grid, method_id, conditional = FALSE)
    conditional_predictions <- predict_regression_safe(model, grid, method_id, conditional = TRUE)
    if (nrow(marginal_predictions)) marginal_predictions$response <- responses[1]
    if (nrow(conditional_predictions)) conditional_predictions$response <- responses[1]
    fixed_effects <- coefficients
    random_effects_table <- tryCatch(broom.mixed::tidy(model, effects = "ran_vals", conf.int = TRUE), error = function(e) data.frame())
    variance_components <- tryCatch(broom.mixed::tidy(model, effects = "ran_pars", conf.int = TRUE), error = function(e) data.frame())
    if (requireNamespace("performance", quietly = TRUE)) {
      metric_warnings <- character()
      collect_metric <- function(expr) tryCatch(withCallingHandlers(
        as.data.frame(expr),
        warning = function(w) {
          metric_warnings <<- c(metric_warnings, conditionMessage(w))
          invokeRestart("muffleWarning")
        }
      ), error = function(e) data.frame())
      r2 <- collect_metric(performance::r2_nakagawa(model))
      icc <- collect_metric(performance::icc(model))
      capture$warnings <- unique(c(capture$warnings, metric_warnings))
      if (nrow(r2)) fit_metrics <- cbind(fit_metrics, r2[1, , drop = FALSE])
      if (nrow(icc)) fit_metrics <- cbind(fit_metrics, icc[1, , drop = FALSE])
    }
  } else {
    fixed_effects <- coefficients
  }
  if (inherits(model, c("zeroinfl", "hurdle")) && "component" %in% names(coefficients)) {
    conditional_model <- coefficients[coefficients$component == "count", , drop = FALSE]
    zero_inflation_model <- coefficients[coefficients$component == "zero", , drop = FALSE]
  }
  if (inherits(model, "glmmTMB") && "component" %in% names(coefficients)) {
    conditional_model <- coefficients[coefficients$component == "cond", , drop = FALSE]
    zero_inflation_model <- coefficients[coefficients$component == "zi", , drop = FALSE]
    dispersion_model <- coefficients[coefficients$component == "disp", , drop = FALSE]
  }
  if (inherits(model, "betareg") && "component" %in% names(coefficients)) {
    conditional_model <- coefficients[coefficients$component %in% c("mean", "mu"), , drop = FALSE]
    dispersion_model <- coefficients[coefficients$component %in% c("precision", "phi"), , drop = FALSE]
  }
  if (inherits(model, "polr")) {
    thresholds <- data.frame(threshold = names(model$zeta), estimate = unname(model$zeta), stringsAsFactors = FALSE)
  }
  if (inherits(model, "gam")) smooth_terms <- tryCatch(broom::tidy(model, parametric = FALSE), error = function(e) data.frame())
  if (inherits(model, "segmented")) {
    thresholds <- tryCatch({
      psi <- as.data.frame(model$psi)
      psi$term <- rownames(psi)
      rownames(psi) <- NULL
      psi
    }, error = function(e) data.frame())
  }
  if (scenario == "group_interaction" && inherits(model, c("lm", "glm", "merMod")) && requireNamespace("emmeans", quietly = TRUE)) {
    trend <- tryCatch(emmeans::emtrends(model, specs = group_var, var = focus), error = function(e) NULL)
    if (!is.null(trend)) {
      group_effects <- as.data.frame(trend)
      slope_comparisons <- tryCatch(as.data.frame(pairs(trend, adjust = "tukey")), error = function(e) data.frame())
    }
  }
  if (scenario %in% c("group_main", "group_interaction") &&
      inherits(model, c("lm", "glm")) && nzchar(group_var) && group_var %in% names(data)) {
    focus_term <- which(gsub("`", "", coefficients$term %||% character()) == focus)[1]
    shared_p <- if (length(focus_term) && is.finite(focus_term) && "p.value" %in% names(coefficients)) coefficients$p.value[focus_term] else NA_real_
    groups <- unique(as.character(data[[group_var]]))
    fit_metrics <- dplyr::bind_rows(lapply(groups, function(group_value) {
      rows <- data$.dava_row_id[as.character(data[[group_var]]) == group_value]
      fitted_rows <- observed_fitted[observed_fitted$.row %in% rows, , drop = FALSE]
      metric <- regression_metrics(fitted_rows$observed, fitted_rows$predicted, length(predictors))
      p_value <- shared_p
      if (scenario == "group_interaction" && nrow(group_effects) &&
          group_var %in% names(group_effects) && "p.value" %in% names(group_effects)) {
        trend_row <- which(as.character(group_effects[[group_var]]) == group_value)[1]
        if (length(trend_row) && is.finite(trend_row)) p_value <- group_effects$p.value[trend_row]
      }
      metric$p.value <- suppressWarnings(as.numeric(p_value))
      metric[[group_var]] <- group_value
      metric
    }))
  }
  overall <- if (!is.null(model) && inherits(model, c("lm", "glm"))) tryCatch(broom::tidy(stats::anova(model)), error = function(e) data.frame()) else data.frame()
  model_text <- if (length(grouped_models)) {
    paste(vapply(names(grouped_models), function(g) paste0("[", g, "]\n", paste(capture.output(summary(grouped_models[[g]])), collapse = "\n")), character(1)), collapse = "\n\n")
  } else {
    paste(tryCatch(capture.output(summary(model)), error = function(e) capture.output(print(model))), collapse = "\n")
  }
  new_regression_result(
    status = if (length(capture$warnings)) "warning" else "valid", method_id = method_id,
    method_name = capability$label, response_structure = if (length(responses) > 1L) "multiple" else "single",
    predictor_structure = if (length(predictors) > 1L) "multivariate" else "univariate",
    responses = responses, predictors = predictors, focus_predictor = focus, group_var = group_var,
    random_effects = if (scenario == "hierarchical") group_var else character(), formula = paste(deparse(effective_formula), collapse = " "),
    readable_formula = regression_readable_formula(responses, predictors, scenario, group_var),
    numeric_equation = regression_numeric_equation(model, responses[1], group_var), model = model,
    grouped_models = grouped_models, model_data = data, data_summary = prepared$summary,
    settings = unclass(settings),
    prediction_settings = list(
      focus_predictor = focus, reference_mode = settings$reference_mode %||% "mean",
      grid_points = settings$prediction_points %||% 100L,
      confidence_level = settings$confidence_level %||% 0.95,
      prediction_scale = if (inherits(model, c("glm", "glmmTMB"))) "response" else "model"
    ),
    actual_rows = data$.dava_row_id,
    coefficients = coefficients, collinearity = collinearity,
    variable_selection = variable_selection, fixed_effects = fixed_effects,
    random_effects_table = random_effects_table, variance_components = variance_components,
    smooth_terms = smooth_terms, thresholds = thresholds,
    conditional_model = conditional_model, zero_inflation_model = zero_inflation_model,
    dispersion_model = dispersion_model, overall_tests = overall, fit_metrics = fit_metrics,
    group_effects = group_effects, slope_comparisons = slope_comparisons,
    mediation_results = mediation_results, moderation_results = moderation_results,
    predictions = observed_fitted, adjusted_predictions = adjusted,
    marginal_predictions = marginal_predictions, conditional_predictions = conditional_predictions,
    observed_fitted = observed_fitted, diagnostics = diagnostics, loadings = loadings,
    scores = scores, variable_importance = importance, community_results = community_results,
    feature_results = feature_results,
    microbiome_results = feature_results, filter_records = filter_records,
    package_versions = regression_package_versions(c(capability$package, "broom")),
    model_text = model_text,
    warnings = capture$warnings, metadata = list(scenario = scenario, ncomp = ncomp,
      model_matrix_terms = model_terms, johnson_neyman = johnson_neyman,
      workspace = if (is.list(wrapped) && !wrapped_model) wrapped$workspace %||% "" else "",
      centers = if (is.list(wrapped) && !wrapped_model) wrapped$centers %||% numeric() else numeric())
  )
}
