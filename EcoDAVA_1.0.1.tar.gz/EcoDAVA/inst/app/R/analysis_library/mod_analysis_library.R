# Central browsers for analysis outputs.  Both libraries use the project-wide
# registries, so an item remains available to the SVG editor and to workspaces.
dava_analysis_data_library_ui <- function(id) {
  ns <- shiny::NS(id)
  bslib::page_sidebar(
    title = "Data table repository",
    sidebar = bslib::sidebar(
      shiny::selectInput(ns("source"), "Source Project", choices = character()),
      shiny::selectInput(ns("table"), "Datasheet", choices = character()),
      shiny::uiOutput(ns("details")), width = 320
    ),
    shiny::h4("Analysis data table registered"),
    DT::DTOutput(ns("preview"))
  )
}

dava_analysis_data_library_server <- function(id, file_data) {
  shiny::moduleServer(id, function(input, output, session) {
    entries <- shiny::reactive({
      file_data$data_registry_version
      datasets <- file_data$global_datasets %||% list()
      sources <- file_data$dataset_sources %||% list()
      data.frame(name = names(datasets), source = vapply(names(datasets), function(x) sources[[x]] %||% "No source noted", character(1)), stringsAsFactors = FALSE)
    })
    shiny::observeEvent(entries(), {
      x <- entries(); choices <- unique(x$source)
      shiny::updateSelectInput(session, "source", choices = choices, selected = if (length(choices)) input$source %||% choices[[1]] else "")
    }, ignoreInit = FALSE)
    shiny::observeEvent(list(entries(), input$source), {
      x <- entries(); x <- x[x$source == (input$source %||% ""), , drop = FALSE]
      shiny::updateSelectInput(session, "table", choices = stats::setNames(x$name, x$name), selected = if (nrow(x)) input$table %||% x$name[[1]] else "")
    }, ignoreInit = FALSE)
    selected_data <- shiny::reactive({ shiny::req(input$table); (file_data$global_datasets %||% list())[[input$table]] })
    output$details <- shiny::renderUI({
      d <- selected_data(); shiny::req(d)
      shiny::tags$p(class = "small text-muted", sprintf("%s rows × %s columns", nrow(d), ncol(d)))
    })
    output$preview <- DT::renderDT({
      d <- selected_data(); shiny::req(d)
      DT::datatable(d, rownames = FALSE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })
  })
}

dava_analysis_plot_library_ui <- function(id) {
  ns <- shiny::NS(id)
  bslib::page_sidebar(
    title = "Analysis plot library",
    sidebar = bslib::sidebar(
      shiny::selectInput(ns("source"), "Source Project", choices = character()),
      shiny::selectInput(ns("plot"), "Analysis chart", choices = character()),
      shiny::uiOutput(ns("details")), width = 320
    ),
    shiny::h4("Registered analysis chart"), shiny::uiOutput(ns("preview"))
  )
}

dava_analysis_plot_library_server <- function(id, file_data) {
  shiny::moduleServer(id, function(input, output, session) {
    entries <- shiny::reactive({ file_data$plot_registry %||% list() })
    table <- shiny::reactive({
      x <- entries(); if (!length(x)) return(data.frame(path = character(), source = character(), title = character()))
      data.frame(path = names(x), source = vapply(x, function(z) z$source %||% "No source noted", character(1)), title = vapply(x, function(z) z$title %||% z$path %||% "", character(1)), stringsAsFactors = FALSE)
    })
    shiny::observeEvent(table(), {
      x <- table(); choices <- unique(x$source)
      shiny::updateSelectInput(session, "source", choices = choices, selected = if (length(choices)) input$source %||% choices[[1]] else "")
    }, ignoreInit = FALSE)
    shiny::observeEvent(list(table(), input$source), {
      x <- table(); x <- x[x$source == (input$source %||% ""), , drop = FALSE]
      shiny::updateSelectInput(session, "plot", choices = stats::setNames(x$path, x$title), selected = if (nrow(x)) input$plot %||% x$path[[1]] else "")
    }, ignoreInit = FALSE)
    selected <- shiny::reactive({ shiny::req(input$plot); entries()[[input$plot]] })
    output$details <- shiny::renderUI({
      x <- selected(); shiny::req(x)
      shiny::tags$div(
        class = "small text-muted dava-library-path-details",
        shiny::tags$div("Path:"),
        shiny::tags$div(
          class = "dava-library-path", x$path %||% "",
          style = paste(
            "white-space:normal;overflow-wrap:anywhere;word-break:break-word;",
            "padding-left:1.35em;text-indent:-1.35em;line-height:1.45;"
          )
        )
      )
    })
    output$preview <- shiny::renderUI({
      x <- selected(); shiny::req(x)
      if (identical(x$type, "svg") && is.character(x$svg)) return(shiny::HTML(x$svg[[1]]))
      if (inherits(x$plot %||% x$plot_object, "ggplot")) return(shiny::plotOutput(session$ns("plot_preview"), height = "650px"))
      shiny::tags$p(class = "text-muted", "This graphic cannot be previewed in the gallery.")
    })
    output$plot_preview <- shiny::renderPlot({ x <- selected(); p <- x$plot %||% x$plot_object; shiny::req(inherits(p, "ggplot")); print(p) })
  })
}
