# Central browsers for analysis outputs.  Both libraries use the project-wide
# registries, so an item remains available to the SVG editor and to workspaces.
dava_library_download_controls <- function(ns, formats, selected, button_id,
                                           label) {
  shiny::tags$div(
    class = "dava-library-download-controls",
    shiny::selectInput(ns("download_format"), "Download format",
      choices = formats, selected = selected),
    shiny::downloadButton(ns(button_id), label, icon = shiny::icon("download"),
      class = "btn-success w-100")
  )
}

dava_write_library_table <- function(data, file, format = c("csv", "xlsx"),
                                     sheet_name = "Datasheet") {
  format <- match.arg(format)
  data <- as.data.frame(data, stringsAsFactors = FALSE, check.names = FALSE)
  if (identical(format, "csv")) {
    # UTF-8 BOM keeps Chinese headers and values intact when the CSV is opened
    # directly in Microsoft Excel on Windows.
    dava_write_csv(data, file, include_rownames = TRUE,
      excel_compatible = TRUE)
  } else {
    sheet <- dava_download_safe_stem(sheet_name, "Datasheet")
    sheet <- gsub("\\[|\\]", "_", sheet)
    sheet <- substr(sheet, 1L, 31L)
    tables <- stats::setNames(list(data), sheet)
    dava_write_xlsx(tables, path = file, include_rownames = TRUE)
  }
  invisible(file)
}

dava_write_library_plot <- function(entry, file, format = c("png", "pdf"),
                                    width = 10, height = 7, dpi = 300) {
  format <- match.arg(format)
  plot <- entry$plot %||% entry$plot_object
  if (inherits(plot, c("ggplot", "grob", "trellis"))) {
    ggplot2::ggsave(file, plot = plot, device = format, width = width,
      height = height, units = "in", dpi = dpi, bg = "white", limitsize = FALSE)
    return(invisible(file))
  }
  if (inherits(plot, "recordedplot")) {
    if (identical(format, "png")) {
      grDevices::png(file, width = width, height = height, units = "in", res = dpi)
    } else {
      grDevices::pdf(file, width = width, height = height)
    }
    on.exit(grDevices::dev.off(), add = TRUE)
    grDevices::replayPlot(plot)
    return(invisible(file))
  }
  svg <- entry$svg %||% entry$editor_svg
  if (is.character(svg) && length(svg) && grepl("<svg", svg[[1L]], fixed = TRUE)) {
    svg <- svg[[1L]]
    if (requireNamespace("rsvg", quietly = TRUE) && identical(format, "png")) {
      rsvg::rsvg_png(charToRaw(enc2utf8(svg[[1L]])), file = file,
        width = as.integer(width * dpi), height = as.integer(height * dpi))
      return(invisible(file))
    }
    if (requireNamespace("rsvg", quietly = TRUE) && identical(format, "pdf")) {
      rsvg::rsvg_pdf(charToRaw(enc2utf8(svg[[1L]])), file = file)
      return(invisible(file))
    }

    # Packaged deployments may use Inkscape without installing the optional
    # rsvg R package. Reuse the editor's cross-platform tool discovery.
    tools <- if (exists("detect_svg_export_tools", mode = "function")) {
      detect_svg_export_tools(refresh = TRUE)
    } else NULL
    if (identical(format, "pdf") &&
        exists("export_svg_to_vector_pdf", mode = "function")) {
      export_svg_to_vector_pdf(svg, file, list(engine = "auto"))
      return(invisible(file))
    }
    inkscape <- tools$pdf$engines$inkscape$path %||% ""
    if (identical(format, "png") && nzchar(inkscape)) {
      input_svg <- tempfile(fileext = ".svg")
      on.exit(unlink(input_svg, force = TRUE), add = TRUE)
      writeLines(svg, input_svg, useBytes = TRUE)
      result <- suppressWarnings(system2(inkscape, c(
        input_svg, "--export-type=png", paste0("--export-filename=", file),
        paste0("--export-width=", as.integer(width * dpi)),
        paste0("--export-height=", as.integer(height * dpi))
      ), stdout = TRUE, stderr = TRUE, timeout = 60))
      if (is.null(attr(result, "status")) && file.exists(file) &&
          file.info(file)$size > 0) return(invisible(file))
    }
    stop("SVG chart export requires the rsvg package, Inkscape, or CairoSVG.",
      call. = FALSE)
  }
  stop("The selected chart is not available in an exportable format.", call. = FALSE)
}

dava_analysis_data_library_ui <- function(id) {
  ns <- shiny::NS(id)
  bslib::page_sidebar(
    title = "Data table repository",
    sidebar = bslib::sidebar(
      shiny::selectInput(ns("source"), "Source Project", choices = character()),
      shiny::selectInput(ns("table"), "Datasheet", choices = character()),
      shiny::uiOutput(ns("details")),
      dava_library_download_controls(ns,
        c("CSV (.csv)" = "csv", "Excel (.xlsx)" = "xlsx"), "csv",
        "download_table", "Download table"),
      width = 320
    ),
    shiny::h4("Analysis data table registered"),
    DT::DTOutput(ns("preview"))
  )
}

dava_analysis_data_library_server <- function(id, file_data) {
  shiny::moduleServer(id, function(input, output, session) {
    entries <- shiny::reactive({
      file_data$data_registry_version
      datasets <- file_data$global_datasets %||% list()
      sources <- file_data$dataset_sources %||% list()
      data.frame(name = names(datasets), source = vapply(names(datasets), function(x) sources[[x]] %||% "No source noted", character(1)), stringsAsFactors = FALSE)
    })
    shiny::observeEvent(entries(), {
      x <- entries(); choices <- unique(x$source)
      shiny::updateSelectInput(session, "source", choices = choices, selected = if (length(choices)) input$source %||% choices[[1]] else "")
    }, ignoreInit = FALSE)
    shiny::observeEvent(list(entries(), input$source), {
      x <- entries(); x <- x[x$source == (input$source %||% ""), , drop = FALSE]
      shiny::updateSelectInput(session, "table", choices = stats::setNames(x$name, x$name), selected = if (nrow(x)) input$table %||% x$name[[1]] else "")
    }, ignoreInit = FALSE)
    selected_data <- shiny::reactive({ shiny::req(input$table); (file_data$global_datasets %||% list())[[input$table]] })
    output$details <- shiny::renderUI({
      d <- selected_data(); shiny::req(d)
      shiny::tags$p(class = "small text-muted", sprintf("%s rows × %s columns", nrow(d), ncol(d)))
    })
    output$preview <- DT::renderDT({
      d <- selected_data(); shiny::req(d)
      DT::datatable(d, rownames = FALSE, filter = "top", options = list(scrollX = TRUE, pageLength = 20))
    })
    output$download_table <- shiny::downloadHandler(
      filename = function() paste0(dava_download_safe_stem(
        input$table, "Datasheet"), ".", input$download_format %||% "csv"),
      content = function(file) dava_write_library_table(
        selected_data(), file, input$download_format %||% "csv", input$table)
    )
  })
}

dava_analysis_plot_library_ui <- function(id) {
  ns <- shiny::NS(id)
  bslib::page_sidebar(
    title = "Analysis plot library",
    sidebar = bslib::sidebar(
      shiny::selectInput(ns("source"), "Source Project", choices = character()),
      shiny::selectInput(ns("plot"), "Analysis chart", choices = character()),
      shiny::uiOutput(ns("details")),
      dava_library_download_controls(ns,
        c("PNG (.png)" = "png", "PDF (.pdf)" = "pdf"), "png",
        "download_plot", "Download image"),
      width = 320
    ),
    shiny::h4("Registered analysis chart"), shiny::uiOutput(ns("preview"))
  )
}

dava_analysis_plot_library_server <- function(id, file_data) {
  shiny::moduleServer(id, function(input, output, session) {
    entries <- shiny::reactive({ file_data$plot_registry %||% list() })
    table <- shiny::reactive({
      x <- entries(); if (!length(x)) return(data.frame(path = character(), source = character(), title = character()))
      data.frame(path = names(x), source = vapply(x, function(z) z$source %||% "No source noted", character(1)), title = vapply(x, function(z) z$title %||% z$path %||% "", character(1)), stringsAsFactors = FALSE)
    })
    shiny::observeEvent(table(), {
      x <- table(); choices <- unique(x$source)
      shiny::updateSelectInput(session, "source", choices = choices, selected = if (length(choices)) input$source %||% choices[[1]] else "")
    }, ignoreInit = FALSE)
    shiny::observeEvent(list(table(), input$source), {
      x <- table(); x <- x[x$source == (input$source %||% ""), , drop = FALSE]
      shiny::updateSelectInput(session, "plot", choices = stats::setNames(x$path, x$title), selected = if (nrow(x)) input$plot %||% x$path[[1]] else "")
    }, ignoreInit = FALSE)
    selected <- shiny::reactive({ shiny::req(input$plot); entries()[[input$plot]] })
    output$details <- shiny::renderUI({
      x <- selected(); shiny::req(x)
      shiny::tags$div(
        class = "small text-muted dava-library-path-details",
        shiny::tags$div("Path:"),
        shiny::tags$div(
          class = "dava-library-path", x$path %||% "",
          style = paste(
            "white-space:normal;overflow-wrap:anywhere;word-break:break-word;",
            "padding-left:1.35em;text-indent:-1.35em;line-height:1.45;"
          )
        )
      )
    })
    output$preview <- shiny::renderUI({
      x <- selected(); shiny::req(x)
      if (identical(x$type, "svg") && is.character(x$svg)) return(shiny::HTML(x$svg[[1]]))
      if (inherits(x$plot %||% x$plot_object, "ggplot")) return(shiny::plotOutput(session$ns("plot_preview"), height = "650px"))
      shiny::tags$p(class = "text-muted", "This graphic cannot be previewed in the gallery.")
    })
    output$plot_preview <- shiny::renderPlot({ x <- selected(); p <- x$plot %||% x$plot_object; shiny::req(inherits(p, "ggplot")); print(p) })
    output$download_plot <- shiny::downloadHandler(
      filename = function() {
        x <- selected()
        paste0(dava_download_safe_stem(x$title %||% x$path,
          "Analysis_chart"), ".", input$download_format %||% "png")
      },
      content = function(file) dava_write_library_plot(
        selected(), file, input$download_format %||% "png")
    )
  })
}
