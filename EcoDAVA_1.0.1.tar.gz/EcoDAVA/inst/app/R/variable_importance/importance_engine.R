vi_required_packages <- function(method, model = vi_default_model(method)) {
  value <- vi_method_info(method)$required_packages[[1]]
  packages <- trimws(strsplit(value, ",", fixed = TRUE)[[1]])
  if (identical(model$type, "lmer")) packages <- c(packages, "lme4")
  if (identical(model$type, "glmmTMB")) packages <- c(packages, "glmmTMB")
  if (identical(method, "shap") && identical(model$type, "randomForest")) packages <- c(packages, "randomForest")
  if (identical(method, "shap") && identical(model$type, "xgboost")) packages <- c(packages, "xgboost")
  if (identical(method, "dominance") && identical(model$type, "lmer")) packages <- c(packages, "performance")
  if (identical(method, "rdacca_hp") && model$type %in% c("lmer", "glmer")) packages <- c(packages, "glmm.hp", "lme4")
  if (identical(method, "rdacca_hp") && identical(model$type, "glmmTMB")) packages <- c(packages, "glmm.hp", "glmmTMB")
  unique(packages)
}

vi_dependency_status <- function(method, model = vi_default_model(method)) {
  packages <- vi_required_packages(method, model)
  package_available <- function(package) suppressMessages(requireNamespace(package, quietly = TRUE))
  installed <- vapply(packages, package_available, logical(1))
  data.frame(package = packages, installed = installed,
    version = vapply(packages, function(package) if (package_available(package))
      as.character(utils::packageVersion(package)) else "", character(1)), stringsAsFactors = FALSE)
}

vi_check_dependencies <- function(method, model = vi_default_model(method)) {
  status <- vi_dependency_status(method, model)
  missing <- status$package[!status$installed]
  if (length(missing)) {
    dava_install_packages(missing, purpose = paste0("Variable Importance Method ", method))
    status <- vi_dependency_status(method, model)
  }
  invisible(status)
}

vi_numeric_variance <- function(value) {
  if (!is.numeric(value)) return(NA_real_)
  stats::var(value, na.rm = TRUE)
}

vi_suitability <- function(data, method, responses, predictors, correlation_cutoff = 0.95) {
  selected <- unique(c(responses, predictors))
  selected <- intersect(selected, names(data))
  numeric_predictors <- predictors[predictors %in% names(data) & vapply(data[predictors], is.numeric, logical(1))]
  high_correlations <- 0L
  max_correlation <- NA_real_
  if (length(numeric_predictors) >= 2L) {
    correlations <- abs(stats::cor(data[numeric_predictors], use = "pairwise.complete.obs"))
    correlations[lower.tri(correlations, diag = TRUE)] <- NA_real_
    max_correlation <- suppressWarnings(max(correlations, na.rm = TRUE))
    if (!is.finite(max_correlation)) max_correlation <- NA_real_
    high_correlations <- sum(correlations > correlation_cutoff, na.rm = TRUE)
  }
  data.frame(
    item = c("Sample size", "Selected response variable", "Selected explanatory variables", "Missing cells", "Zero variance variable",
      paste0("Highly correlated variable pairs (|r| > ", correlation_cutoff, ")"), "Maximum explanatory variable correlation coefficient", "Sample size/explanatory variable ratio"),
    value = c(nrow(data), length(responses), length(predictors), sum(is.na(data[selected])),
      sum(vapply(data[selected], function(value) is.numeric(value) && isTRUE(all.equal(stats::var(value, na.rm = TRUE), 0)), logical(1))),
      high_correlations, max_correlation, nrow(data) / max(1, length(predictors))),
    assessment = c(if (nrow(data) >= 50) "Sufficient" else "Sample size is low", if (length(responses)) "Passed" else "Not selected",
      if (length(predictors) >= 2L) "Passed" else "Recommend at least two", if (sum(is.na(data[selected])) == 0) "None missing" else "requires preprocessing",
      "should be 0", if (high_correlations) "Interpret with caution" else "Passed", if (is.finite(max_correlation) && max_correlation > correlation_cutoff) "Higher" else "Acceptable",
      if (nrow(data) / max(1, length(predictors)) >= 10) "Acceptable" else "Low"),
    stringsAsFactors = FALSE)
}

vi_impute_column <- function(value) {
  if (!anyNA(value)) return(value)
  if (is.numeric(value)) value[is.na(value)] <- stats::median(value, na.rm = TRUE)
  else {
    observed <- value[!is.na(value)]
    replacement <- if (length(observed)) names(sort(table(observed), decreasing = TRUE))[1] else "Missing"
    value[is.na(value)] <- replacement
    if (is.factor(value)) value <- droplevels(value)
  }
  value
}

vi_prepare_data <- function(data, method, responses, predictors, settings, auxiliary = character()) {
  phy_tree <- attr(data, "phy_tree", exact = TRUE)
  required <- unique(c(responses, predictors, auxiliary))
  missing_columns <- setdiff(required, names(data))
  if (length(missing_columns)) stop("Variables are missing from the data:", paste(missing_columns, collapse = "、"), call. = FALSE)
  prepared <- data[, required, drop = FALSE]
  original_rows <- nrow(prepared)
  if (identical(settings$missing, "complete")) prepared <- prepared[stats::complete.cases(prepared), , drop = FALSE]
  if (identical(settings$missing, "median")) prepared[] <- lapply(prepared, vi_impute_column)
  zero_variance <- names(prepared)[vapply(prepared, function(value) {
    if (is.numeric(value)) isTRUE(all.equal(stats::var(value, na.rm = TRUE), 0)) else length(unique(value)) < 2L
  }, logical(1))]
  if (isTRUE(settings$remove_zero_variance) && length(zero_variance)) {
    predictors <- setdiff(predictors, zero_variance)
    prepared <- prepared[, unique(c(responses, predictors, auxiliary)), drop = FALSE]
  }
  numeric_predictors <- predictors[vapply(prepared[predictors], is.numeric, logical(1))]
  if (identical(settings$predictor_transform, "log1p")) {
    prepared[numeric_predictors] <- lapply(prepared[numeric_predictors], function(value) log1p(value - min(value, na.rm = TRUE)))
  }
  if (isTRUE(settings$standardize)) {
    prepared[numeric_predictors] <- lapply(prepared[numeric_predictors], function(value) as.numeric(scale(value)))
  }
  if (method %in% c("relaimpo", "varpart", "rdacca_hp")) {
    checked <- unique(c(responses, predictors))
    non_numeric <- checked[!vapply(prepared[checked], is.numeric, logical(1))]
    if (length(non_numeric)) stop("This method requires that the selected response and explanatory variables are both numerical:", paste(non_numeric, collapse = "、"), call. = FALSE)
  }
  if (!is.null(phy_tree)) attr(prepared, "phy_tree") <- phy_tree
  list(data = prepared, responses = responses, predictors = predictors,
    report = data.frame(item = c("Original number of rows", "Number of lines analyzed", "Number of deleted/unused rows", "Remove zero variance variables"),
      value = c(original_rows, nrow(prepared), original_rows - nrow(prepared), paste(zero_variance, collapse = ", ")),
      stringsAsFactors = FALSE))
}

vi_variable_group_map <- function(terms, groups = list()) {
  groups <- groups %||% list()
  lookup <- stats::setNames(rep("Not grouped", length(terms)), terms)
  for (group_name in names(groups)) {
    members <- intersect(groups[[group_name]], terms)
    lookup[members] <- group_name
  }
  unname(lookup[terms])
}

vi_importance_plot_title <- function(method) switch(method,
  relaimpo = "relaimpo relative contribution", dominance = "Average delta R²", rf = "Random forest variable importance",
  mumin = "MuMIn variable importance", shap = "SHAP feature importance", varpart = "Independent explanatory power of explanatory variable group",
  rdacca_hp = "Hierarchical segmentation independent contribution", "Variable importance")

vi_importance_plot <- function(table, title, x_label = "Importance", groups = list()) {
  if (!is.data.frame(table) || !nrow(table)) return(NULL)
  term <- names(table)[tolower(names(table)) %in% c("term", "feature", "variable")][1]
  value <- names(table)[tolower(names(table)) %in% c("importance", "lmg", "individual", "mean_abs_shap")][1]
  if (is.na(term) || is.na(value)) return(NULL)
  grouped <- length(groups) > 0L
  table$variable_group <- vi_variable_group_map(as.character(table[[term]]), groups)
  plot <- ggplot2::ggplot(table, ggplot2::aes(x = .data[[value]],
    y = stats::reorder(.data[[term]], .data[[value]]))) +
    ggplot2::geom_col(ggplot2::aes(fill = .data$variable_group), width = 0.68, show.legend = grouped) +
    ggplot2::labs(title = title, x = x_label, y = NULL) + ggplot2::theme_bw(base_size = 12) +
    ggplot2::theme(panel.grid.major.y = ggplot2::element_blank(), plot.title = ggplot2::element_text(face = "bold"))
  if (!grouped) plot <- plot + ggplot2::scale_fill_manual(values = c("Not grouped" = "#1f8a78"))
  if (grouped) plot <- plot + ggplot2::facet_grid(variable_group ~ ., scales = "free_y", space = "free_y") +
    ggplot2::labs(fill = "Variable grouping") + ggplot2::theme(strip.text.y = ggplot2::element_text(face = "bold"))
  plot
}

vi_significance_label <- function(p_value) {
  ifelse(!is.finite(p_value), "",
    ifelse(p_value < 0.001, "***", ifelse(p_value < 0.01, "**", ifelse(p_value < 0.05, "*", "ns"))))
}

vi_model_r2_annotation <- function(fit) {
  if (inherits(fit, "lm")) {
    model_summary <- summary(fit)
    return(sprintf("R² = %.3f Adjustment R² = %.3f", model_summary$r.squared, model_summary$adj.r.squared))
  }
  if (inherits(fit, "glm")) {
    pseudo_r2 <- 1 - fit$deviance / fit$null.deviance
    return(sprintf("Explained deviation R² = %.3f", pseudo_r2))
  }
  if (inherits(fit, "merMod") && requireNamespace("performance", quietly = TRUE)) {
    r2 <- tryCatch(performance::r2_nakagawa(fit), error = function(error) NULL)
    if (!is.null(r2)) return(sprintf("Margin R² = %.3f Condition R² = %.3f",
      as.numeric(r2$R2_marginal), as.numeric(r2$R2_conditional)))
  }
  ""
}

vi_importance_coefficient_plot <- function(primary, fit, groups = list()) {
  if (!is.data.frame(primary) || !nrow(primary) || is.null(fit) || inherits(fit, "randomForest")) return(NULL)
  coefficients <- tryCatch({
    if (inherits(fit, "merMod")) broom.mixed::tidy(fit, effects = "fixed", conf.int = TRUE)
    else broom::tidy(fit, conf.int = TRUE)
  }, error = function(error) NULL)
  if (is.null(coefficients) || !nrow(coefficients)) return(NULL)
  coefficients <- coefficients[coefficients$term != "(Intercept)", , drop = FALSE]
  predictors <- as.character(primary$term)
  coefficients$variable <- vapply(coefficients$term, function(term) {
    matches <- predictors[term == predictors | startsWith(term, predictors)]
    if (length(matches)) matches[which.max(nchar(matches))] else term
  }, character(1))
  coefficients$importance <- primary$importance[match(coefficients$variable, primary$term)]
  if (!"p.value" %in% names(coefficients)) coefficients$p.value <- NA_real_
  missing_p <- !is.finite(coefficients$p.value) & is.finite(coefficients$estimate) &
    is.finite(coefficients$std.error) & coefficients$std.error > 0
  coefficients$p.value[missing_p] <- 2 * stats::pnorm(-abs(
    coefficients$estimate[missing_p] / coefficients$std.error[missing_p]))
  coefficients$significance <- vi_significance_label(coefficients$p.value)
  coefficients <- coefficients[is.finite(coefficients$estimate) & is.finite(coefficients$conf.low) &
    is.finite(coefficients$conf.high), , drop = FALSE]
  if (!nrow(coefficients)) return(NULL)
  coefficients$variable_group <- vi_variable_group_map(coefficients$variable, groups)
  if (!length(groups)) coefficients$variable_group <- coefficients$variable

  contribution <- primary
  contribution$variable_group <- vi_variable_group_map(as.character(contribution$term), groups)
  if (!length(groups)) contribution$variable_group <- as.character(contribution$term)
  contribution$importance <- abs(as.numeric(contribution$importance))
  group_contribution <- stats::aggregate(importance ~ variable_group, contribution, sum, na.rm = TRUE)
  total_importance <- sum(group_contribution$importance, na.rm = TRUE)
  if (!is.finite(total_importance) || total_importance <= 0) return(NULL)
  group_contribution$percentage <- 100 * group_contribution$importance / total_importance
  group_contribution <- group_contribution[order(group_contribution$percentage, decreasing = TRUE), , drop = FALSE]
  group_levels <- group_contribution$variable_group
  group_contribution$variable_group <- factor(group_contribution$variable_group, levels = group_levels)
  coefficients$variable_group <- factor(coefficients$variable_group, levels = group_levels)
  palette_values <- c("#82C57C", "#EE8B7D", "#8297C5", "#DF79B4", "#62B6CB", "#E6B566", "#9B87C7", "#73AE9B")
  group_colours <- stats::setNames(rep(palette_values, length.out = length(group_levels)), group_levels)

  left_plot <- ggplot2::ggplot(group_contribution,
    ggplot2::aes(x = factor("Relative contribution"), y = .data$percentage, fill = .data$variable_group)) +
    ggplot2::geom_col(width = 0.5, colour = "white", linewidth = 0.35) +
    ggplot2::geom_text(ggplot2::aes(label = ifelse(.data$percentage >= 3,
      sprintf("%.1f%%", .data$percentage), "")), position = ggplot2::position_stack(vjust = 0.5),
      colour = "white", fontface = "bold", size = 4) +
    ggplot2::scale_fill_manual(values = group_colours, drop = FALSE, name = "Variable grouping") +
    ggplot2::scale_y_continuous(breaks = seq(0, 100, 25),
      expand = ggplot2::expansion(mult = c(0, 0.02))) +
    ggplot2::coord_cartesian(ylim = c(0, 100), clip = "off") +
    ggplot2::labs(x = NULL, y = "Relative contribution rate (%)") +
    ggplot2::theme_classic(base_size = 12) +
    ggplot2::theme(axis.text.x = ggplot2::element_blank(), axis.ticks.x = ggplot2::element_blank(),
      legend.position = "right", legend.title = ggplot2::element_text(face = "bold"))

  term_order <- unique(coefficients$term[order(coefficients$estimate)])
  coefficients$term <- factor(coefficients$term, levels = term_order)
  coefficient_range <- range(c(coefficients$conf.low, coefficients$conf.high), na.rm = TRUE)
  label_padding <- max(diff(coefficient_range) * 0.045, 0.025)
  coefficients$label_x <- ifelse(coefficients$estimate >= 0,
    coefficients$conf.high + label_padding, coefficients$conf.low - label_padding)
  coefficients$label_hjust <- ifelse(coefficients$estimate >= 0, 0, 1)

  right_plot <- ggplot2::ggplot(coefficients, ggplot2::aes(x = .data$estimate,
    y = .data$term, fill = .data$variable_group)) +
    ggplot2::geom_vline(xintercept = 0, linetype = "dashed", colour = "#1f1f1f", linewidth = 0.7) +
    ggplot2::geom_errorbar(ggplot2::aes(xmin = .data$conf.low, xmax = .data$conf.high),
      width = 0, linewidth = 0.85, colour = "#646b70") +
    ggplot2::geom_point(shape = 21, size = 4.2, colour = "white", stroke = 0.35) +
    ggplot2::geom_text(ggplot2::aes(x = .data$label_x, label = .data$significance,
      hjust = .data$label_hjust), colour = "black", fontface = "bold", size = 4.2,
      show.legend = FALSE) +
    ggplot2::scale_fill_manual(values = group_colours, drop = FALSE, name = "Variable grouping") +
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0.13, 0.13))) +
    ggplot2::labs(x = "Regression coefficient estimates (95% CI)", y = NULL) +
    ggplot2::coord_cartesian(clip = "off") +
    ggplot2::theme_classic(base_size = 12) +
    ggplot2::theme(panel.grid = ggplot2::element_blank(), legend.position = "bottom")

  patchwork::wrap_plots(left_plot, right_plot, widths = c(0.85, 1.55)) +
    patchwork::plot_annotation(title = "Importance-Regression Coefficient Forest Plot",
      subtitle = vi_model_r2_annotation(fit), theme = ggplot2::theme(
        plot.title = ggplot2::element_text(face = "bold", size = 17, hjust = 0.5),
        plot.subtitle = ggplot2::element_text(size = 13, hjust = 0.5)))
}

vi_apply_plot_theme <- function(plot, theme_name = "publication", base_size = 13,
                                legend_position = "right", rotate_x = FALSE, show_legend = TRUE) {
  if (exists("dava_plot_theme", mode = "function")) {
    return(dava_plot_theme(plot, theme_name, base_size, legend_position, rotate_x, show_legend))
  }
  plot + ggplot2::theme_bw(base_size = base_size) +
    ggplot2::theme(legend.position = if (isTRUE(show_legend)) legend_position else "none",
      axis.text.x = ggplot2::element_text(angle = if (isTRUE(rotate_x)) 35 else 0,
        hjust = if (isTRUE(rotate_x)) 1 else 0.5))
}

vi_capture <- function(value) paste(capture.output(print(value)), collapse = "\n")

vi_validate_model <- function(data, response, predictors, model) {
  if (!response %in% names(data)) stop("Please select a valid response variable.", call. = FALSE)
  if (identical(model$type, "glm_binomial") && length(unique(data[[response]][!is.na(data[[response]])])) != 2L) {
    stop("The binomial distribution glm requires that the response variable contains exactly two valid levels.", call. = FALSE)
  }
  if (model$type %in% c("glm", "glmer", "glmmTMB")) {
    family_name <- model$family %||% "gaussian"
    response_value <- data[[response]]
    observed <- response_value[!is.na(response_value)]
    if (identical(family_name, "binomial") && length(unique(observed)) != 2L) {
      stop("The binomial distribution model requires that the response variable contains exactly two valid levels.", call. = FALSE)
    }
    if (family_name %in% c("poisson", "nbinom2") &&
        (!is.numeric(response_value) || any(observed < 0) || any(observed != floor(observed)))) {
      stop("Poisson or negative binomial models require the response variable to be nonnegative integer counts.", call. = FALSE)
    }
  }
  if (model$type %in% c("lmer", "glmer", "glmmTMB")) {
    if (identical(model$type, "lmer") && !is.numeric(data[[response]])) {
      stop("lmer Importance analysis requires a continuous numeric response variable.", call. = FALSE)
    }
    if (identical(model$type, "glmmTMB") && identical(model$family %||% "gaussian", "gaussian") &&
        !is.numeric(data[[response]])) {
      stop("The Gaussian glmmTMB model requires a continuous numeric response variable.", call. = FALSE)
    }
    if (!nzchar(model$random_group %||% "") || !model$random_group %in% names(data)) {
      stop("Please select a valid random variable.", call. = FALSE)
    }
    if (!identical(model$random_structure, "intercept") &&
        (!nzchar(model$random_slope %||% "") || !model$random_slope %in% predictors)) {
      stop("The random slope structure requires that the random slope variable be selected from the explanatory variables.", call. = FALSE)
    }
  }
  invisible(TRUE)
}

vi_fit_configured_model <- function(data, response, predictors, model, trees = 800L) {
  vi_validate_model(data, response, predictors, model)
  model_data <- data
  if (identical(model$type, "lmer")) model_data[[model$random_group]] <- factor(model_data[[model$random_group]])
  formula <- vi_model_formula(response, predictors, model)
  fit <- switch(model$type,
    lm = stats::lm(formula, data = model_data),
    glm_binomial = stats::glm(formula, data = model_data, family = stats::binomial(link = "logit")),
    lmer = lme4::lmer(formula, data = model_data, REML = FALSE),
    randomForest = randomForest::randomForest(formula, data = model_data, ntree = trees,
      importance = TRUE, na.action = stats::na.omit),
    stop("The selected model is not supported by the current importance method.", call. = FALSE))
  list(fit = fit, data = model_data, formula = formula)
}

vi_predict_configured_model <- function(fit, newdata, model) {
  if (identical(model$type, "glm_binomial")) return(as.numeric(stats::predict(fit, newdata = newdata, type = "response")))
  if (identical(model$type, "lmer")) return(as.numeric(stats::predict(fit, newdata = newdata,
    re.form = NULL, allow.new.levels = TRUE)))
  if (identical(model$type, "randomForest") && is.factor(fit$y)) {
    probabilities <- stats::predict(fit, newdata = newdata, type = "prob")
    return(as.numeric(probabilities[, ncol(probabilities)]))
  }
  as.numeric(stats::predict(fit, newdata = newdata))
}

vi_model_tables <- function(fit) {
  if (inherits(fit, "randomForest")) {
    oob_error <- if (is.matrix(fit$err.rate)) tail(fit$err.rate[, 1], 1) else tail(fit$mse, 1)
    return(list(model_summary = data.frame(model = "randomForest", trees = fit$ntree,
      mtry = fit$mtry, final_oob_error = unname(oob_error), stringsAsFactors = FALSE)))
  }
  if (inherits(fit, "merMod")) {
    return(list(model_summary = broom.mixed::glance(fit), coefficients = broom.mixed::tidy(fit, effects = "fixed")))
  }
  if (inherits(fit, "glmmTMB")) {
    return(list(model_summary = broom.mixed::glance(fit),
      coefficients = broom.mixed::tidy(fit, effects = "fixed", component = "cond")))
  }
  list(model_summary = broom::glance(fit), coefficients = broom::tidy(fit))
}

vi_relaimpo_tables <- function(calc, metrics) {
  rows <- lapply(metrics, function(metric) {
    values <- if (metric %in% methods::slotNames(calc)) methods::slot(calc, metric) else NULL
    if (is.null(values)) return(NULL)
    data.frame(term = names(values), metric = metric, importance = as.numeric(values), stringsAsFactors = FALSE)
  })
  do.call(rbind, Filter(Negate(is.null), rows))
}

vi_fit_relaimpo <- function(data, response, predictors, advanced) {
  formula <- stats::reformulate(predictors, response)
  fit <- stats::lm(formula, data = data)
  calc <- relaimpo::calc.relimp(fit, type = advanced$metrics, rela = isTRUE(advanced$relative))
  importance <- vi_relaimpo_tables(calc, advanced$metrics)
  primary <- importance[importance$metric == advanced$metrics[[1]], c("term", "importance"), drop = FALSE]
  tables <- list(model_summary = broom::glance(fit), coefficients = broom::tidy(fit), relative_importance = importance)
  bootstrap <- NULL
  if (isTRUE(advanced$bootstrap)) {
    set.seed(advanced$seed)
    bootstrap <- relaimpo::boot.relimp(fit, b = advanced$bootstrap_reps, type = advanced$metrics,
      rela = isTRUE(advanced$relative), rank = TRUE, diff = TRUE)
    evaluated <- relaimpo::booteval.relimp(bootstrap, level = advanced$confidence)
    tables$bootstrap_summary <- data.frame(output = capture.output(print(evaluated)), stringsAsFactors = FALSE)
  }
  list(tables = tables, text = paste("# lineSexmodel\n", vi_capture(summary(fit)), "\n\n# relativeImportance\n",
    vi_capture(calc), if (!is.null(bootstrap)) paste0("\n\n# Bootstrap\n", vi_capture(bootstrap)) else ""),
    primary = primary, model = fit, objects = list(relimp = calc, bootstrap = bootstrap),
    plots = list(importance = vi_importance_plot(primary, "relaimpo relative contribution"),
      importance_coefficients = vi_importance_coefficient_plot(primary, fit),
      diagnostics = function() plot(fit, which = 1, main = "Linear model residual diagnosis")))
}

vi_fit_dominance <- function(data, response, predictors, advanced, model) {
  if (length(predictors) > advanced$max_predictors) stop("The explanatory variable that dominates the analysis exceeds the upper limit of the advanced settings.", call. = FALSE)
  vi_validate_model(data, response, predictors, model)
  model_data <- data
  if (identical(model$type, "lmer")) model_data[[model$random_group]] <- factor(model_data[[model$random_group]])
  formula <- vi_model_formula(response, predictors, model)
  temporary_name <- paste0(".__dava_dominance_data_", Sys.getpid(), "_", format(Sys.time(), "%H%M%OS6"))
  temporary_name <- make.names(temporary_name)
  assign(temporary_name, model_data, envir = .GlobalEnv)
  on.exit(rm(list = temporary_name, envir = .GlobalEnv), add = TRUE)
  environment(formula) <- .GlobalEnv
  fit_call <- switch(model$type,
    lm = substitute(stats::lm(FORMULA, data = DATA, model = TRUE, x = TRUE, y = TRUE),
      list(FORMULA = formula, DATA = as.name(temporary_name))),
    glm_binomial = substitute(stats::glm(FORMULA, data = DATA, family = stats::binomial(link = "logit"),
      model = TRUE, x = TRUE, y = TRUE), list(FORMULA = formula, DATA = as.name(temporary_name))),
    lmer = substitute(lme4::lmer(FORMULA, data = DATA, REML = FALSE),
      list(FORMULA = formula, DATA = as.name(temporary_name))),
    stop("Dominance analysis does not support the selected model.", call. = FALSE))
  fit <- eval(fit_call, envir = .GlobalEnv)
  null_model <- NULL
  if (identical(model$type, "lmer")) {
    null_formula <- vi_model_formula(response, character(), model)
    environment(null_formula) <- .GlobalEnv
    null_call <- substitute(lme4::lmer(FORMULA, data = DATA, REML = FALSE),
      list(FORMULA = null_formula, DATA = as.name(temporary_name)))
    null_model <- eval(null_call, envir = .GlobalEnv)
  }
  dominance <- tryCatch(
    dominanceanalysis::dominanceAnalysis(fit, newdata = model_data, null.model = null_model),
    error = function(error) {
      if (identical(model$type, "lmer") && lme4::isSingular(fit)) {
        stop("lmer has a singular fit, and the current random effect variance is close to zero; please replace the random variable, simplify the random structure, or use lm instead.", call. = FALSE)
      }
      stop(conditionMessage(error), call. = FALSE)
    })
  average <- dominanceanalysis::averageContribution(dominance)
  briefing <- dominanceanalysis::dominanceBriefing(dominance)
  metric <- advanced$fit_metric %||% unname(vi_dominance_metric_choices(model$type))[1]
  if (!metric %in% names(average)) metric <- names(average)[1]
  values <- average[[metric]]
  primary <- data.frame(term = names(values), importance = as.numeric(values), stringsAsFactors = FALSE)
  primary <- primary[order(primary$importance, decreasing = TRUE), , drop = FALSE]
  briefing_table <- tryCatch(as.data.frame(briefing[[metric]]), error = function(error) data.frame(output = capture.output(print(briefing))))
  tables <- vi_model_tables(fit)
  tables$average_contribution <- primary
  tables$dominance_briefing <- briefing_table
  list(tables = tables,
    text = paste("# Fitting modelandformula\n", vi_model_formula_text(response, predictors, model), "\n\n", vi_capture(summary(fit)), "\n\n# DominateAnalyze\n", vi_capture(dominance),
      "\n\n# Average contribution\n", vi_capture(average), "\n\n# Dominance relationship\n", vi_capture(briefing)),
    primary = primary, model = fit, objects = list(dominance = dominance),
    plots = list(importance = vi_importance_plot(primary, "Average delta R²"),
      importance_coefficients = vi_importance_coefficient_plot(primary, fit),
      dominance = function() plot(dominance)))
}

vi_mumin_relative_importance <- function(importance, groups = list()) {
  if (!is.data.frame(importance) || !nrow(importance)) return(data.frame())
  values <- importance[, c("term", "importance"), drop = FALSE]
  values$term <- as.character(values$term)
  values$variable_group <- vi_variable_group_map(values$term, groups)
  ungrouped <- is.na(values$variable_group) | values$variable_group == "Not grouped"
  values$variable_group[ungrouped] <- values$term[ungrouped]
  group_order <- unique(values$variable_group)
  grouped <- stats::aggregate(importance ~ variable_group, data = values, FUN = sum, na.rm = TRUE)
  grouped <- grouped[match(group_order, grouped$variable_group), , drop = FALSE]
  total <- sum(grouped$importance, na.rm = TRUE)
  grouped$relative_percent <- if (is.finite(total) && total > 0) grouped$importance / total * 100 else 0
  grouped$variable_group <- factor(grouped$variable_group, levels = rev(group_order))
  grouped$label <- ifelse(grouped$relative_percent >= 7,
    paste0(vapply(as.character(grouped$variable_group), function(value)
      paste(strwrap(value, width = 16L), collapse = "\n"), character(1)),
      "\n", sprintf("%.1f%%", grouped$relative_percent)),
    sprintf("%.1f%%", grouped$relative_percent))
  grouped
}

vi_mumin_fit_statistic <- function(model) {
  if (inherits(model, "lm") && !inherits(model, "glm")) {
    value <- summary(model)$adj.r.squared
    return(list(label = "Adj. R2", value = as.numeric(value)))
  }
  if (inherits(model, "glm")) {
    value <- if (is.finite(model$null.deviance) && model$null.deviance > 0)
      1 - model$deviance / model$null.deviance else NA_real_
    return(list(label = "McFadden R2", value = as.numeric(value)))
  }
  value <- tryCatch(suppressWarnings(suppressMessages(MuMIn::r.squaredGLMM(model))),
    error = function(error) NULL)
  if (!is.null(value) && length(value)) {
    return(list(label = "Marginal R2", value = as.numeric(value[1L])))
  }
  list(label = "R2", value = NA_real_)
}

vi_mumin_inference_plot <- function(coefficients, importance, groups = list(), metadata = list()) {
  if (!is.data.frame(coefficients) || !nrow(coefficients) ||
      !is.data.frame(importance) || !nrow(importance)) return(NULL)
  relative <- vi_mumin_relative_importance(importance, groups)
  coefficients$variable_group <- vi_variable_group_map(as.character(coefficients$variable), groups)
  ungrouped <- is.na(coefficients$variable_group) | coefficients$variable_group == "Not grouped"
  coefficients$variable_group[ungrouped] <- as.character(coefficients$variable[ungrouped])
  group_levels <- unique(c(as.character(relative$variable_group), as.character(coefficients$variable_group)))
  palette_values <- c("#4776F3", "#F2A35E", "#E63B2E", "#78951F", "#9633D1",
    "#2A9D8F", "#D46A9E", "#6C78A8", "#C98B2E", "#4F8A5B")
  group_colours <- stats::setNames(rep(palette_values, length.out = length(group_levels)), group_levels)
  rgb <- grDevices::col2rgb(group_colours)
  luminance <- 0.299 * rgb[1, ] + 0.587 * rgb[2, ] + 0.114 * rgb[3, ]
  group_text <- stats::setNames(ifelse(luminance > 155, "#17212B", "white"), names(group_colours))
  relative$label_colour <- unname(group_text[as.character(relative$variable_group)])
  relative$ymin <- c(0, utils::head(cumsum(relative$relative_percent), -1L))
  relative$ymax <- cumsum(relative$relative_percent)
  relative$label_y <- (relative$ymin + relative$ymax) / 2

  fit_value <- as.numeric(metadata$fit_value %||% NA_real_)
  fit_label <- metadata$fit_label %||% "Adj. R2"
  fit_title <- if (is.finite(fit_value) && identical(fit_label, "Adj. R2")) {
    bquote(Adj.~R^2 == .(round(fit_value, 3L)))
  } else if (is.finite(fit_value)) {
    sprintf("%s = %.3f", fit_label, fit_value)
  } else "Relative importance"
  left <- ggplot2::ggplot(relative) +
    ggplot2::geom_rect(ggplot2::aes(xmin = 0.18, xmax = 0.82, ymin = .data$ymin,
      ymax = .data$ymax, fill = .data$variable_group), colour = "white", linewidth = 0.35) +
    ggplot2::geom_text(ggplot2::aes(x = 0.5, y = .data$label_y, label = .data$label,
      colour = .data$label_colour), size = 3.25, lineheight = 0.88,
      fontface = "bold", show.legend = FALSE) +
    ggplot2::scale_fill_manual(values = group_colours, drop = FALSE) +
    ggplot2::scale_colour_identity() +
    ggplot2::scale_y_continuous(limits = c(0, 100), breaks = seq(0, 100, 20),
      expand = ggplot2::expansion(mult = c(0, 0))) +
    ggplot2::scale_x_continuous(limits = c(0, 1), expand = ggplot2::expansion(mult = c(0, 0))) +
    ggplot2::labs(title = fit_title, x = NULL, y = "Relative effect of estimates (%)") +
    ggplot2::theme_classic(base_size = 12) +
    ggplot2::theme(plot.title = ggplot2::element_text(face = "plain", hjust = 0.5, size = 13),
      axis.text.x = ggplot2::element_blank(), axis.ticks.x = ggplot2::element_blank(),
      legend.position = "none")

  coefficients$term <- factor(coefficients$term,
    levels = unique(coefficients$term[order(coefficients$estimate)]))
  effect_range <- range(c(coefficients$conf.low, coefficients$conf.high), na.rm = TRUE)
  padding <- max(diff(effect_range) * 0.045, 0.025)
  coefficients$label_x <- ifelse(coefficients$estimate >= 0,
    coefficients$conf.high + padding, coefficients$conf.low - padding)
  coefficients$label_hjust <- ifelse(coefficients$estimate >= 0, 0, 1)
  right <- ggplot2::ggplot(coefficients, ggplot2::aes(x = .data$estimate, y = .data$term,
    fill = .data$variable_group, colour = .data$variable_group)) +
    ggplot2::geom_vline(xintercept = 0, linetype = "dashed", colour = "#555555", linewidth = 0.65) +
    ggplot2::geom_errorbar(ggplot2::aes(xmin = .data$conf.low, xmax = .data$conf.high),
      width = 0, linewidth = 0.8) +
    ggplot2::geom_point(shape = 21, size = 4.1, stroke = 0.4) +
    ggplot2::geom_text(ggplot2::aes(x = .data$label_x, label = .data$significance,
      hjust = .data$label_hjust), colour = "black", fontface = "bold", size = 3.8,
      show.legend = FALSE) +
    ggplot2::scale_fill_manual(values = group_colours, drop = FALSE) +
    ggplot2::scale_colour_manual(values = group_colours, drop = FALSE) +
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0.14, 0.14))) +
    ggplot2::coord_cartesian(clip = "off") +
    ggplot2::labs(title = "Model-averaged effects",
      x = "Model-averaged parameter estimates (95% CI)", y = NULL) +
    ggplot2::theme_classic(base_size = 12) +
    ggplot2::theme(plot.title = ggplot2::element_text(face = "bold", hjust = 0.5),
      legend.position = "none")

  subtitle <- sprintf("%s; %d candidate models; top-model weight = %.3f",
    metadata$rank %||% "AICc", metadata$candidate_count %||% 0L,
    metadata$top_weight %||% NA_real_)
  patchwork::wrap_plots(left, right, widths = c(0.62, 1.38)) +
    patchwork::plot_annotation(title = "Multimodel inference and variable importance",
      subtitle = subtitle,
      theme = ggplot2::theme(plot.title = ggplot2::element_text(face = "bold", size = 17, hjust = 0.5),
        plot.subtitle = ggplot2::element_text(size = 11.5, hjust = 0.5)))
}

vi_mumin_model_weights_plot <- function(model_selection, rank = "AICc") {
  if (!is.data.frame(model_selection) || !nrow(model_selection)) return(NULL)
  shown <- utils::head(model_selection, 20L)
  shown$model_id <- factor(shown$model_id, levels = rev(shown$model_id))
  ggplot2::ggplot(shown, ggplot2::aes(x = .data$weight, y = .data$model_id, fill = .data$delta)) +
    ggplot2::geom_col(width = 0.68) +
    ggplot2::scale_fill_viridis_c(option = "C", direction = -1, name = paste0("Δ", rank)) +
    ggplot2::labs(title = "Candidate model weights", subtitle = "Top 20 models sorted by information criteria",
      x = "Akaike weight", y = "Model number") +
    ggplot2::theme_bw(base_size = 12) +
    ggplot2::theme(panel.grid.major.y = ggplot2::element_blank(), plot.title = ggplot2::element_text(face = "bold"))
}

vi_fit_mumin <- function(data, response, predictors, advanced, model) {
  if (length(predictors) > as.integer(advanced$max_predictors %||% 10L)) {
    stop(sprintf("The MuMIn full subset model cannot have more than %d explanatory variables; please reduce the variables or increase the advanced parameter limit.",
      as.integer(advanced$max_predictors %||% 10L)), call. = FALSE)
  }
  vi_validate_model(data, response, predictors, model)
  model_data <- data
  if (model$type %in% c("lmer", "glmmTMB")) model_data[[model$random_group]] <- factor(model_data[[model$random_group]])
  formula <- vi_model_formula(response, predictors, model)
  temporary_name <- make.names(paste0(".__dava_mumin_data_", Sys.getpid(), "_", format(Sys.time(), "%H%M%OS6")))
  assign(temporary_name, model_data, envir = .GlobalEnv)
  on.exit(rm(list = temporary_name, envir = .GlobalEnv), add = TRUE)
  environment(formula) <- .GlobalEnv
  old_na_action <- options(na.action = "na.fail")
  on.exit(options(old_na_action), add = TRUE)
  model_call <- switch(model$type,
    lm = substitute(stats::lm(FORMULA, data = DATA),
      list(FORMULA = formula, DATA = as.name(temporary_name))),
    glm = substitute(stats::glm(FORMULA, data = DATA, family = FAMILY),
      list(FORMULA = formula, DATA = as.name(temporary_name), FAMILY = vi_model_family(model))),
    lmer = substitute(lme4::lmer(FORMULA, data = DATA, REML = FALSE),
      list(FORMULA = formula, DATA = as.name(temporary_name))),
    glmmTMB = substitute(glmmTMB::glmmTMB(FORMULA, data = DATA, family = FAMILY),
      list(FORMULA = formula, DATA = as.name(temporary_name), FAMILY = vi_model_family(model))),
    stop("MuMIn does not support the current model type.", call. = FALSE))
  global_model <- eval(model_call, envir = .GlobalEnv)
  rank_method <- advanced$rank %||% "AICc"
  requested_beta <- advanced$beta %||% "sd"
  effective_beta <- if (identical(model$type, "glm") && identical(model$family %||% "gaussian", "binomial")) {
    "none"
  } else requested_beta
  max_terms <- min(length(predictors), as.integer(advanced$max_predictors %||% 10L))
  selection <- suppressMessages(MuMIn::dredge(global_model, rank = rank_method,
    beta = effective_beta,
    m.lim = c(if (isTRUE(advanced$include_null)) 0L else 1L, max_terms), trace = FALSE))
  selection_table <- as.data.frame(selection, stringsAsFactors = FALSE)
  selection_table$model_id <- rownames(selection_table)
  selection_table <- selection_table[, c("model_id", setdiff(names(selection_table), "model_id")), drop = FALSE]
  valid_models <- is.finite(selection_table$delta) & is.finite(selection_table$weight)
  if (!any(valid_models)) {
    stop("None of the MuMIn candidate models received valid information criteria and weights; please simplify the global model or adjust the distribution family.", call. = FALSE)
  }
  keep <- if (identical(advanced$selection_rule, "weight")) {
    cumsum(ifelse(valid_models, selection_table$weight, 0)) <=
      as.numeric(advanced$cumulative_weight %||% 0.95) & valid_models
  } else selection_table$delta <= as.numeric(advanced$delta %||% 4) & valid_models
  keep[is.na(keep)] <- FALSE
  valid_indices <- which(valid_models)
  keep[valid_indices[1L]] <- TRUE
  if (sum(keep) < 2L && length(valid_indices) > 1L) keep[valid_indices[seq_len(2L)]] <- TRUE
  candidate_models <- MuMIn::get.models(selection, subset = which(keep))
  averaged <- MuMIn::model.avg(candidate_models, rank = rank_method,
    beta = effective_beta, revised.var = isTRUE(advanced$revised_variance))
  averaged_summary <- summary(averaged)
  full_average <- identical(advanced$averaging %||% "full", "full")
  coefficient_matrix <- if (full_average) averaged_summary$coefmat.full else averaged_summary$coefmat.subset
  coefficient_matrix <- as.data.frame(coefficient_matrix, stringsAsFactors = FALSE)
  coefficient_matrix$term <- rownames(coefficient_matrix)
  confidence_intervals <- as.data.frame(stats::confint(averaged,
    level = as.numeric(advanced$confidence %||% 0.95), full = full_average), stringsAsFactors = FALSE)
  confidence_intervals$term <- rownames(confidence_intervals)
  coefficient_table <- merge(coefficient_matrix, confidence_intervals, by = "term", all.x = TRUE, sort = FALSE)
  names(coefficient_table)[names(coefficient_table) == "Estimate"] <- "estimate"
  se_name <- intersect(c("Adjusted SE", "Std. Error"), names(coefficient_table))[1]
  p_name <- grep("Pr\\(", names(coefficient_table), value = TRUE)[1]
  ci_names <- setdiff(names(confidence_intervals), "term")
  coefficient_table$std.error <- coefficient_table[[se_name]]
  coefficient_table$p.value <- coefficient_table[[p_name]]
  coefficient_table$conf.low <- coefficient_table[[ci_names[1]]]
  coefficient_table$conf.high <- coefficient_table[[ci_names[2]]]
  coefficient_table <- coefficient_table[coefficient_table$term != "(Intercept)", , drop = FALSE]
  importance_values <- MuMIn::sw(averaged)
  primary <- data.frame(term = names(importance_values), importance = as.numeric(importance_values), stringsAsFactors = FALSE)
  primary <- primary[order(primary$importance, decreasing = TRUE), , drop = FALSE]
  coefficient_table$variable <- vapply(coefficient_table$term, function(term) {
    matches <- primary$term[term == primary$term | startsWith(term, primary$term)]
    if (length(matches)) matches[which.max(nchar(matches))] else term
  }, character(1))
  coefficient_table$importance <- primary$importance[match(coefficient_table$variable, primary$term)]
  coefficient_table$significance <- vi_significance_label(coefficient_table$p.value)
  candidate_table <- selection_table[keep, , drop = FALSE]
  fit_statistic <- vi_mumin_fit_statistic(global_model)
  metadata <- list(rank = rank_method, candidate_count = nrow(candidate_table),
    top_weight = selection_table$weight[1], requested_beta = requested_beta,
    effective_beta = effective_beta, fit_label = fit_statistic$label,
    fit_value = fit_statistic$value)
  tables <- c(vi_model_tables(global_model), list(model_selection = selection_table,
    candidate_models = candidate_table, model_averaged_coefficients = coefficient_table,
    variable_importance = primary))
  list(tables = tables,
    text = paste("# MuMIn Globalmodel\n", vi_capture(summary(global_model)),
      if (!identical(requested_beta, effective_beta))
        "\n\n# Parameter compatibility adjustment\n2Category glm responseNot applicable MuMIn The true whole of sd Coefficient normalization，This timemodelSelectandaverage usage beta = \"none\"。" else "",
      "\n\n# Full subsetmodelSelect\n", vi_capture(selection),
      "\n\n# Candidatemodelset\n", vi_capture(candidate_table),
      "\n\n# modelaverageResults\n", vi_capture(averaged_summary),
      "\n\n# modelaverageConfidence interval\n", vi_capture(confidence_intervals),
      "\n\n# Variable importance（Model weight sum）\n", vi_capture(primary)),
    primary = primary, model = global_model,
    objects = list(model_selection = selection, averaged_model = averaged, metadata = metadata),
    plots = list(figure4a = vi_mumin_inference_plot(coefficient_table, primary, metadata = metadata),
      importance = vi_importance_plot(primary, "MuMIn variable importance", "Model weight sum"),
      model_weights = vi_mumin_model_weights_plot(selection_table, rank_method)))
}

vi_rf_significance <- function(p_value, alpha = 0.05) {
  ifelse(!is.finite(p_value), "", ifelse(p_value < 0.001, "***",
    ifelse(p_value < 0.01, "**", ifelse(p_value < alpha, "*", ""))))
}

vi_rf_fit_permutation <- function(formula, data, advanced) {
  cores_available <- vi_available_cores(logical = FALSE)
  arguments <- list(formula = formula, data = data, importance = TRUE,
    ntree = as.integer(advanced$trees %||% 500L),
    num.cores = max(1L, min(as.integer(advanced$cores %||% 1L), cores_available)),
    nodesize = as.integer(advanced$nodesize %||% 5L), na.action = stats::na.omit)
  if ((advanced$mtry %||% 0L) > 0L) arguments$mtry <- min(as.integer(advanced$mtry), length(attr(stats::terms(formula), "term.labels")))
  formula_method <- utils::getS3method("rfPermute", "formula", envir = asNamespace("rfPermute"))
  repetition_name <- if ("num.rep" %in% names(formals(formula_method))) "num.rep" else "nrep"
  arguments[[repetition_name]] <- as.integer(advanced$permutations %||% 1000L)
  do.call(rfPermute::rfPermute, arguments)
}

vi_rf_a3_test <- function(formula, data, response, advanced) {
  if (!isTRUE(advanced$a3_enabled)) return(list(fit = NULL, table = data.frame()))
  if (!is.numeric(data[[response]])) {
    return(list(fit = NULL, table = data.frame(test = "A3 overall model test", status =
      "Not run: A3 model R2 is available only for a continuous response.", stringsAsFactors = FALSE)))
  }
  model_args <- list(importance = TRUE, ntree = as.integer(advanced$trees %||% 500L),
    nodesize = as.integer(advanced$nodesize %||% 5L))
  if ((advanced$mtry %||% 0L) > 0L) model_args$mtry <- as.integer(advanced$mtry)
  a3_formula <- stats::reformulate(attr(stats::terms(formula), "term.labels"), response = response, intercept = FALSE)
  fitted <- tryCatch({
    set.seed(as.integer(advanced$seed %||% 2026L))
    A3::a3(a3_formula, data = data, model.fn = randomForest::randomForest,
      p.acc = as.numeric(advanced$a3_p_acc %||% 0.01),
      n.folds = as.integer(advanced$a3_folds %||% 5L), model.args = model_args)
  }, error = function(error) error)
  if (inherits(fitted, "error")) {
    return(list(fit = NULL, table = data.frame(test = "A3 overall model test",
      status = conditionMessage(fitted), stringsAsFactors = FALSE)))
  }
  r_squared <- as.numeric(fitted$model.R2[[1]])
  p_value <- as.numeric(fitted$model.p[[1]])
  p_accuracy <- as.numeric(advanced$a3_p_acc %||% 0.01)
  p_display <- if (!is.finite(p_value)) "NA" else if (p_value <= 0) sprintf("< %.4g", p_accuracy) else sprintf("= %.4g", p_value)
  list(fit = fitted, table = data.frame(test = "A3 overall model test", cv_r_squared = r_squared,
    p_value = p_value, p_display = p_display, p_accuracy = p_accuracy,
    folds = as.integer(advanced$a3_folds %||% 5L), stringsAsFactors = FALSE))
}

vi_rf_importance_plot <- function(importance, model_test = data.frame(), settings = list()) {
  if (!is.data.frame(importance) || !nrow(importance)) return(NULL)
  top_n <- min(nrow(importance), max(1L, as.integer(settings$top_n %||% 20L)))
  plot_data <- importance[order(importance$importance, decreasing = TRUE), , drop = FALSE]
  plot_data <- utils::head(plot_data, top_n)
  plot_data$term <- factor(plot_data$term, levels = rev(plot_data$term))
  show_values <- isTRUE(settings$show_values %||% TRUE)
  show_significance <- isTRUE(settings$show_significance %||% TRUE)
  plot_data$plot_label <- if (show_values) sprintf("%.2f%% %s", plot_data$importance,
    if (show_significance) plot_data$significance else "") else if (show_significance) plot_data$significance else ""
  palette <- switch(settings$palette %||% "BlueYellowRed",
    Viridis = c("#3B528B", "#5DC863", "#FDE725"),
    BlueRed = c("#9ECAE1", "#FEE8C8", "#E34A33"),
    Forest = c("#B8D8D8", "#F4E6A2", "#D97941"),
    c("#A6CEE3", "#FFF2B2", "#FC8D59"))
  finite_importance <- plot_data$importance[is.finite(plot_data$importance)]
  upper <- if (length(finite_importance)) max(finite_importance) else 1
  lower <- if (length(finite_importance)) min(0, min(finite_importance)) else 0
  span <- max(upper - lower, 1)
  annotation <- ""
  if (isTRUE(settings$show_model_test %||% TRUE) && nrow(model_test) &&
      all(c("cv_r_squared", "p_display") %in% names(model_test)) && is.finite(model_test$cv_r_squared[[1]])) {
    annotation <- sprintf("A3 model test\nR² = %.3f\nP %s", model_test$cv_r_squared[[1]], model_test$p_display[[1]])
  }
  plot <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data$term, y = .data$importance,
      fill = .data$importance)) +
    ggplot2::geom_col(colour = settings$border_colour %||% "#202020",
      linewidth = 0.45, width = as.numeric(settings$bar_width %||% 0.78),
      alpha = as.numeric(settings$alpha %||% 0.95)) +
    ggplot2::scale_fill_gradientn(colours = palette, guide = "none") +
    ggplot2::coord_flip(clip = "off") +
    ggplot2::scale_y_continuous(limits = c(lower, upper + span * 0.55),
      expand = ggplot2::expansion(mult = c(0, 0))) +
    ggplot2::labs(title = settings$title %||% "Permutation importance with significance",
      x = NULL, y = "Increase in MSE (%)")
  if (nzchar(plot_data$plot_label[[1]] %||% "")) {
    plot <- plot + ggplot2::geom_text(ggplot2::aes(label = .data$plot_label), hjust = -0.12,
      size = as.numeric(settings$label_size %||% 3.2), colour = "#27313A")
  }
  if (nzchar(annotation)) {
    plot <- plot + ggplot2::annotate("text", x = max(1, top_n - 1), y = upper + span * 0.18,
      label = annotation, hjust = 0, vjust = 1, lineheight = 1.15,
      size = as.numeric(settings$model_text_size %||% 3.4), fontface = "plain")
  }
  vi_apply_plot_theme(plot, settings$theme %||% "publication",
    as.numeric(settings$base_size %||% 13), "none", FALSE, FALSE) +
    ggplot2::theme(panel.grid = ggplot2::element_blank(),
      plot.margin = ggplot2::margin(8, 35, 8, 8))
}

vi_fit_rf <- function(data, response, predictors, advanced) {
  set.seed(as.integer(advanced$seed %||% 2026L))
  formula <- stats::reformulate(predictors, response)
  fit <- vi_rf_fit_permutation(formula, data, advanced)
  rf <- fit[["rf"]]
  importance_matrix <- rfPermute::importance(fit, scale = isTRUE(advanced$scale_importance))
  importance <- as.data.frame(importance_matrix, check.names = FALSE) |>
    tibble::rownames_to_column("term")
  value_column <- if (is.factor(data[[response]])) "MeanDecreaseAccuracy" else "%IncMSE"
  numeric_columns <- names(importance)[vapply(importance, is.numeric, logical(1))]
  score_columns <- setdiff(numeric_columns, grep("\\.pval$", numeric_columns, value = TRUE))
  if (!value_column %in% names(importance)) value_column <- score_columns[[1]]
  p_column <- paste0(value_column, ".pval")
  if (!p_column %in% names(importance)) {
    candidate <- grep("\\.pval$", names(importance), value = TRUE)
    p_column <- if (length(candidate)) candidate[[1]] else NA_character_
  }
  primary <- data.frame(term = importance$term, importance = as.numeric(importance[[value_column]]),
    p.value = if (!is.na(p_column)) as.numeric(importance[[p_column]]) else NA_real_,
    metric = value_column, stringsAsFactors = FALSE)
  primary$significance <- vi_rf_significance(primary$p.value, advanced$alpha %||% 0.05)
  primary <- primary[order(primary$importance, decreasing = TRUE), , drop = FALSE]
  a3 <- vi_rf_a3_test(formula, data, response, advanced)
  error_table <- if (is.matrix(rf$err.rate)) as.data.frame(rf$err.rate) |> tibble::rownames_to_column("trees") else
    data.frame(trees = seq_along(rf$mse), mse = rf$mse, rsq = rf$rsq)
  list(tables = list(variable_importance = importance, permutation_significance = primary,
    overall_model_significance = a3$table, oob_error = error_table,
    confusion = if (!is.null(rf$confusion)) as.data.frame(rf$confusion) else data.frame()),
    text = paste("# rfPermute random forest\n", vi_capture(fit),
      "\n\n# Scaled variable importance and permutation P values\n", vi_capture(importance_matrix),
      "\n\n# Ranked importance and significance\n", vi_capture(primary),
      "\n\n# A3 overall model significance\n", if (is.null(a3$fit)) vi_capture(a3$table) else vi_capture(a3$fit)),
    primary = primary, model = rf, objects = list(rf_permutation = fit, a3 = a3$fit), plots = list(
      permutation_importance = vi_rf_importance_plot(primary, a3$table),
      oob = function() plot(rf, main = "OOB error")))
}

vi_xgb_matrix <- function(data, predictors) {
  model_matrix <- stats::model.matrix(stats::reformulate(predictors, response = NULL), data = data)
  model_matrix <- model_matrix[, colnames(model_matrix) != "(Intercept)", drop = FALSE]
  if (!ncol(model_matrix)) stop("XGBoost requires at least one valid numeric or categorical explanatory variable.", call. = FALSE)
  model_matrix
}

vi_xgb_target <- function(value) {
  observed <- value[!is.na(value)]
  categorical <- is.factor(value) || is.character(value)
  class_count <- if (categorical) length(unique(observed)) else 0L
  if (categorical && class_count > 2L) return(list(label = as.numeric(factor(value)) - 1,
    objective = "multi:softprob", metric = "mlogloss", type = "multiclass", num_class = class_count))
  binary <- categorical || (is.numeric(value) && length(unique(observed)) == 2L)
  if (binary) return(list(label = as.numeric(factor(value)) - 1, objective = "binary:logistic", metric = "logloss", type = "binary"))
  poisson <- is.numeric(value) && length(observed) > 0L && all(observed >= 0) && all(observed == floor(observed)) && max(observed) <= 20
  if (poisson) return(list(label = as.numeric(value), objective = "count:poisson", metric = "poisson-nloglik", type = "poisson"))
  list(label = as.numeric(value), objective = "reg:squarederror", metric = "rmse", type = "regression")
}

vi_xgb_interaction_matrix <- function(model, xgb_data, feature_count) {
  values <- tryCatch(stats::predict(model, xgb_data, predinteraction = TRUE), error = function(error) NULL)
  if (is.null(values)) return(NULL)
  if (length(dim(values)) == 3L) {
    values <- values[, seq_len(feature_count), seq_len(feature_count), drop = FALSE]
    return(list(signed = apply(values, c(2, 3), mean, na.rm = TRUE),
      strength = apply(abs(values), c(2, 3), mean, na.rm = TRUE)))
  }
  if (length(dim(values)) == 4L) {
    values <- values[, , seq_len(feature_count), seq_len(feature_count), drop = FALSE]
    return(list(signed = apply(values, c(3, 4), mean, na.rm = TRUE),
      strength = apply(abs(values), c(3, 4), mean, na.rm = TRUE)))
  }
  NULL
}

vi_fit_xgboost_shap <- function(data, response, predictors, advanced) {
  x <- vi_xgb_matrix(data, predictors)
  target <- vi_xgb_target(data[[response]])
  keep <- complete.cases(x) & is.finite(target$label)
  x <- x[keep, , drop = FALSE]
  y <- target$label[keep]
  if (nrow(x) < 10L) stop("XGBoost requires at least 10 complete observations.", call. = FALSE)
  dtrain <- xgboost::xgb.DMatrix(x, label = y)
  params <- list(objective = target$objective, eval_metric = target$metric,
    max_depth = as.integer(advanced$max_depth %||% 3L), eta = as.numeric(advanced$eta %||% 0.05),
    lambda = as.numeric(advanced$lambda %||% 1), alpha = as.numeric(advanced$alpha %||% 0.1),
    subsample = as.numeric(advanced$subsample %||% 0.8), colsample_bytree = as.numeric(advanced$colsample_bytree %||% 0.8))
  if (identical(target$type, "multiclass")) params$num_class <- target$num_class
  set.seed(advanced$seed %||% 2026L)
  nrounds <- as.integer(advanced$nrounds %||% 300L)
  cv <- NULL
  if (nrow(x) >= 20L && as.integer(advanced$nfold %||% 5L) >= 2L) {
    cv <- xgboost::xgb.cv(params = params, data = dtrain, nrounds = nrounds,
      nfold = min(as.integer(advanced$nfold %||% 5L), nrow(x) - 1L),
      early_stopping_rounds = as.integer(advanced$early_stopping_rounds %||% 20L), verbose = 0)
    nrounds <- cv$best_iteration %||% nrounds
  }
  fit <- xgboost::xgb.train(params = params, data = dtrain, nrounds = max(1L, nrounds), verbose = 0)
  contrib <- stats::predict(fit, dtrain, predcontrib = TRUE)
  if (length(dim(contrib)) == 3L) {
    probabilities <- stats::predict(fit, dtrain, strict_shape = TRUE)
    predicted_class <- max.col(probabilities)
    shap_matrix <- t(vapply(seq_len(nrow(x)), function(index)
      contrib[index, predicted_class[[index]], seq_len(ncol(x))], numeric(ncol(x))))
  } else {
    shap_matrix <- as.matrix(contrib[, seq_len(ncol(x)), drop = FALSE])
  }
  colnames(shap_matrix) <- colnames(x)
  shap_table <- as.data.frame(as.table(shap_matrix), stringsAsFactors = FALSE)
  names(shap_table) <- c("observation", "feature", "phi")
  shap_table$observation <- rep(seq_len(nrow(shap_matrix)), times = ncol(shap_matrix))
  shap_table$feature_value <- as.vector(t(x[, colnames(shap_matrix), drop = FALSE]))
  primary <- shap_table |>
    dplyr::group_by(feature) |>
    dplyr::summarise(importance = mean(abs(phi), na.rm = TRUE), mean_shap = mean(phi, na.rm = TRUE), .groups = "drop") |>
    dplyr::rename(term = feature) |>
    dplyr::arrange(dplyr::desc(importance))
  gain <- as.data.frame(xgboost::xgb.importance(model = fit, feature_names = colnames(x)), stringsAsFactors = FALSE)
  if (nrow(gain)) names(gain)[names(gain) == "Feature"] <- "term"
  interaction_result <- vi_xgb_interaction_matrix(fit, dtrain, ncol(x))
  interaction <- interaction_signed <- NULL
  if (!is.null(interaction_result)) {
    interaction <- interaction_result$strength
    interaction_signed <- interaction_result$signed
    dimnames(interaction) <- dimnames(interaction_signed) <- list(colnames(x), colnames(x))
  }
  list(fit = fit, x = x, y = y, shap_matrix = shap_matrix, shap_table = shap_table,
    primary = primary, gain = gain, interaction = interaction, interaction_signed = interaction_signed,
    cv = cv, target = target,
    nrounds = nrounds, formula = stats::reformulate(predictors, response))
}

vi_shap_plot <- function(result, plot_name = "beeswarm", settings = list()) {
  shap_table <- result$objects$shap_table
  primary <- result$tables$global_shap
  if (!is.data.frame(shap_table) || !nrow(shap_table)) return(NULL)
  settings$top_n <- min(as.integer(settings$top_n %||% 15L), nrow(primary))
  ordered <- primary$term[seq_len(max(1L, settings$top_n))]
  shap_table <- shap_table[shap_table$feature %in% ordered, , drop = FALSE]
  shap_table$feature <- factor(shap_table$feature, levels = rev(ordered))
  base_size <- as.numeric(settings$base_size %||% 13)
  point_size <- as.numeric(settings$point_size %||% 1.6)
  alpha <- as.numeric(settings$alpha %||% 0.65)
  theme_name <- settings$theme %||% "publication"
  colours <- switch(settings$palette %||% "Scientific",
    Nature = c("#3B6FB6", "#F7F7F7", "#C33C54"),
    Forest = c("#2A9D8F", "#F4F1DE", "#E76F51"),
    Viridis = c("#440154", "#21918C", "#FDE725"),
    c("#2878B5", "#F7F7F7", "#D94841"))
  if (plot_name == "beeswarm") {
    bars <- primary[match(ordered, primary$term), , drop = FALSE]
    bars$feature <- factor(bars$term, levels = rev(ordered))
    bars$feature_label <- sprintf("%s (%.4f)", bars$term, bars$importance)
    shap_range <- range(shap_table$phi, na.rm = TRUE)
    shap_span <- diff(shap_range)
    if (!is.finite(shap_span) || shap_span <= 0) shap_span <- 1
    max_importance <- max(bars$importance, na.rm = TRUE)
    if (!is.finite(max_importance) || max_importance <= 0) max_importance <- 1
    importance_to_shap <- function(value) shap_range[[1]] + value / max_importance * shap_span
    shap_to_importance <- function(value) pmax(0, (value - shap_range[[1]]) / shap_span * max_importance)
    bars$importance_scaled <- importance_to_shap(bars$importance)
    return(vi_apply_plot_theme(ggplot2::ggplot() +
      ggplot2::geom_segment(data = bars, ggplot2::aes(x = shap_range[[1]], xend = importance_scaled,
        y = feature, yend = feature), linewidth = 12, colour = "#D9E5EA", alpha = 0.62) +
      ggplot2::geom_point(data = shap_table, ggplot2::aes(x = phi, y = feature, colour = feature_value),
        position = ggplot2::position_jitter(height = 0.18, width = 0), size = point_size, alpha = alpha) +
      ggplot2::geom_vline(xintercept = 0, colour = "#6B7280", linewidth = 0.45) +
      ggplot2::scale_colour_gradient2(low = colours[[1]], mid = colours[[2]], high = colours[[3]], midpoint = 0) +
      ggplot2::scale_x_continuous(name = "SHAP value (impact on model output)",
        limits = shap_range, sec.axis = ggplot2::sec_axis(~ shap_to_importance(.),
          breaks = scales::breaks_pretty(5), name = "Mean(|SHAP value|) - Feature Importance")) +
      ggplot2::scale_y_discrete(labels = stats::setNames(bars$feature_label, bars$feature)) +
      ggplot2::labs(title = "SHAP global feature contribution map", y = NULL, colour = "Feature value"),
      theme_name, base_size, "right", FALSE, TRUE) + ggplot2::theme(
        axis.title.x.top = ggplot2::element_text(face = "bold"),
        axis.text.x.top = ggplot2::element_text(colour = "#34495E"),
        legend.title = ggplot2::element_text(angle = 90, vjust = 0.5)) +
      ggplot2::guides(colour = ggplot2::guide_colourbar(title.position = "right",
        barheight = grid::unit(52, "mm"), barwidth = grid::unit(3, "mm"))))
  }
  if (plot_name == "importance") {
    return(vi_apply_plot_theme(ggplot2::ggplot(primary[seq_len(max(1L, settings$top_n)), , drop = FALSE],
      ggplot2::aes(x = importance, y = stats::reorder(term, importance))) + ggplot2::geom_col(fill = "#1F6F8B", width = 0.68) +
      ggplot2::labs(title = "SHAP average absolute contribution ranking", x = "Mean(|SHAP value|)", y = NULL), theme_name, base_size, "right", FALSE, FALSE))
  }
  if (plot_name == "correlation") {
    label_digits <- max(1L, min(5L, as.integer(settings$label_digits %||% 3L)))
    label_format <- paste0("%.", label_digits, "f")
    interaction_signed <- result$objects$interaction_signed
    if (is.null(interaction_signed)) interaction_signed <- stats::cor(result$objects$shap_matrix,
      use = "pairwise.complete.obs")
    heat_features <- ordered[ordered %in% rownames(interaction_signed)]
    interaction_signed <- interaction_signed[heat_features, heat_features, drop = FALSE]
    n_features <- length(heat_features)
    pairs <- if (n_features >= 2L) utils::combn(seq_len(n_features), 2L) else matrix(integer(), nrow = 2L)
    heat_df <- if (ncol(pairs)) data.frame(
      x = pairs[2, ], y = n_features - pairs[1, ] + 1L,
      interaction = interaction_signed[cbind(pairs[1, ], pairs[2, ])]) else data.frame()
    max_interaction <- if (nrow(heat_df)) max(abs(heat_df$interaction), na.rm = TRUE) else 1
    if (!is.finite(max_interaction) || max_interaction <= 0) max_interaction <- 1
    if (nrow(heat_df)) heat_df$label_colour <- ifelse(
      abs(heat_df$interaction) / max_interaction >= 0.58, "#FFFFFF", "#28323C")
    format_diagonal_label <- function(value, width = 9L) {
      value <- gsub("([[:lower:][:digit:]])([[:upper:]])", "\\1 \\2", value, perl = TRUE)
      value <- gsub("[_\\.-]+", " ", value, perl = TRUE)
      words <- strsplit(trimws(value), "[[:space:]]+", perl = TRUE)[[1]]
      words <- unlist(lapply(words, function(word) {
        starts <- seq.int(1L, nchar(word), by = width)
        substring(word, starts, pmin(starts + width - 1L, nchar(word)))
      }), use.names = FALSE)
      paste(strwrap(paste(words, collapse = " "), width = width), collapse = "\n")
    }
    diagonal <- data.frame(x = seq_len(n_features), y = n_features - seq_len(n_features) + 1L,
      feature = heat_features, stringsAsFactors = FALSE)
    diagonal$feature_label <- vapply(diagonal$feature, format_diagonal_label, character(1))
    diagonal_line_count <- max(lengths(strsplit(diagonal$feature_label, "\n", fixed = TRUE)))
    diagonal_label_size <- max(base_size / 5.2,
      min(base_size / 4.1, base_size / (3.9 + 0.45 * (diagonal_line_count - 1L))))
    heat <- ggplot2::ggplot() +
      ggplot2::geom_tile(data = heat_df, ggplot2::aes(x, y, fill = interaction),
        colour = "#D8DEE3", linewidth = 0.35) +
      ggplot2::geom_text(data = heat_df,
        ggplot2::aes(x, y, label = sprintf(label_format, interaction), colour = label_colour),
        size = base_size / 4) +
      ggplot2::geom_tile(data = diagonal, ggplot2::aes(x, y), fill = "white", colour = "#D8DEE3", linewidth = 0.35) +
      ggplot2::geom_text(data = diagonal, ggplot2::aes(x, y, label = feature_label), fontface = "bold",
        size = diagonal_label_size, lineheight = 0.78, check_overlap = TRUE) +
      ggplot2::scale_fill_gradient2(low = colours[[1]], mid = colours[[2]], high = colours[[3]], midpoint = 0,
        limits = c(-max_interaction, max_interaction), name = "SHAP interaction") +
      ggplot2::scale_colour_identity() +
      ggplot2::coord_equal(xlim = c(0.5, n_features + 0.5), ylim = c(0.5, n_features + 0.5), clip = "off") +
      ggplot2::labs(title = "SHAP interaction heat map", x = NULL, y = NULL) + ggplot2::theme_void(base_size = base_size) +
      ggplot2::theme(plot.title = ggplot2::element_text(face = "bold", hjust = 0.5), legend.position = "right") +
      ggplot2::guides(fill = ggplot2::guide_colourbar(title.position = "top",
        barheight = grid::unit(38, "mm"), barwidth = grid::unit(4, "mm")))
    importance_data <- primary[seq_len(max(1L, settings$top_n)), , drop = FALSE]
    importance_data$term <- factor(importance_data$term, levels = importance_data$term)
    bars <- ggplot2::ggplot(importance_data, ggplot2::aes(term, importance, fill = importance)) +
      ggplot2::geom_col(width = 0.68) +
      ggplot2::scale_fill_gradient(low = colours[[1]], high = colours[[3]], guide = "none") +
      ggplot2::geom_text(ggplot2::aes(label = sprintf("%.4f", importance)), angle = 35, hjust = -0.05,
        vjust = 0.5, size = base_size / 4) +
      ggplot2::labs(title = "SHAP feature importance", x = NULL, y = "Feature importance") +
      ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0, 0.18)))
    bars <- vi_apply_plot_theme(bars, theme_name, base_size, "right", TRUE, FALSE) +
      ggplot2::theme(legend.position = "none")
    return((patchwork::plot_spacer() + heat) / (bars + patchwork::plot_spacer()) +
      patchwork::plot_layout(heights = c(1.9, 1), widths = c(1.05, 1.35)))
  }
  if (plot_name == "network") {
    node_size_min <- as.numeric(settings$node_size_min %||% 3)
    node_size_max <- max(node_size_min, as.numeric(settings$node_size_max %||% 11))
    edge_width_max <- max(0.25, as.numeric(settings$edge_width_max %||% 4))
    matrix <- result$objects$interaction
    if (is.null(matrix)) matrix <- abs(stats::cor(result$objects$shap_matrix, use = "pairwise.complete.obs"))
    nodes <- ordered[ordered %in% rownames(matrix)]
    if (length(nodes) < 2L) return(NULL)
    angle <- seq(0, 2 * pi, length.out = length(nodes) + 1L)[-(length(nodes) + 1L)]
    layout <- data.frame(feature = nodes, x = cos(angle), y = sin(angle), stringsAsFactors = FALSE)
    edges <- utils::combn(nodes, 2L, simplify = FALSE)
    edge_df <- dplyr::bind_rows(lapply(edges, function(pair) data.frame(from = pair[1], to = pair[2], strength = matrix[pair[1], pair[2]])))
    threshold <- as.numeric(settings$interaction_threshold %||% 0)
    edge_df <- edge_df[edge_df$strength >= threshold, , drop = FALSE]
    edge_df <- merge(edge_df, layout, by.x = "from", by.y = "feature")
    names(edge_df)[names(edge_df) %in% c("x", "y")] <- c("x_from", "y_from")
    edge_df <- merge(edge_df, layout, by.x = "to", by.y = "feature")
    names(edge_df)[names(edge_df) %in% c("x", "y")] <- c("x_to", "y_to")
    layout$importance <- primary$importance[match(layout$feature, primary$term)]
    p <- ggplot2::ggplot() + ggplot2::geom_segment(data = edge_df, ggplot2::aes(x = x_from, y = y_from, xend = x_to, yend = y_to, linewidth = strength, colour = strength), alpha = alpha) +
      ggplot2::geom_point(data = layout, ggplot2::aes(x, y, size = importance, fill = importance), colour = "#566573", shape = 21, stroke = 0.5, alpha = alpha) +
      ggplot2::geom_text(data = layout, ggplot2::aes(x, y, label = feature), nudge_y = 0.12, size = base_size / 4) +
      ggplot2::scale_linewidth_continuous(range = c(0.25, edge_width_max), name = "Interaction Intensity (Vint)") +
      ggplot2::scale_colour_gradient(low = colours[[1]], high = colours[[3]], name = "Interaction Intensity (Vint)") +
      ggplot2::scale_size_continuous(range = c(node_size_min, node_size_max), name = "Importance (Vimp)") +
      ggplot2::scale_fill_gradient(low = colours[[1]], high = colours[[3]], name = "Importance (Vimp)") +
      ggplot2::coord_equal(xlim = c(-1.35, 1.35), ylim = c(-1.35, 1.35), clip = "off") +
      ggplot2::labs(title = "SHAP interaction strength network diagram")
    return(p + ggplot2::theme_void() + ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = "white", colour = NA),
      panel.background = ggplot2::element_rect(fill = "white", colour = NA),
      legend.position = "right", legend.box = "vertical",
      plot.title = ggplot2::element_text(hjust = 0.5, face = "bold", colour = "#1F2937")))
  }
  shap_table <- shap_table[shap_table$feature %in% ordered, , drop = FALSE]
  loess_span <- max(0.05, min(1, as.numeric(settings$loess_span %||% 0.3)))
  line_width <- max(0.1, as.numeric(settings$line_width %||% 1.05))
  facet_columns <- max(1L, min(6L, as.integer(settings$facet_columns %||% 3L)))
  show_confidence <- isTRUE(settings$show_confidence %||% TRUE)
  show_thresholds <- isTRUE(settings$show_thresholds %||% TRUE)
  interaction <- result$objects$interaction
  x <- as.data.frame(result$objects$x, check.names = FALSE)
  normalize01 <- function(value) {
    value_range <- range(value, na.rm = TRUE)
    if (!all(is.finite(value_range)) || diff(value_range) <= 0) return(rep(0.5, length(value)))
    (value - value_range[[1]]) / diff(value_range)
  }
  feature_data <- lapply(ordered, function(feature_name) {
    current <- shap_table[as.character(shap_table$feature) == feature_name, , drop = FALSE]
    current$feature_value_normalized <- normalize01(current$feature_value)
    partner <- ""
    if (!is.null(interaction) && feature_name %in% rownames(interaction)) {
      strengths <- interaction[feature_name, , drop = TRUE]
      strengths[feature_name] <- NA_real_
      if (any(is.finite(strengths))) partner <- names(which.max(strengths))
    }
    if (nzchar(partner) && partner %in% names(x)) {
      current$interaction_value <- normalize01(x[[partner]][current$observation])
    } else {
      current$interaction_value <- current$feature_value_normalized
    }
    current$interaction_feature <- if (nzchar(partner)) partner else feature_name
    current
  })
  plot_data <- dplyr::bind_rows(feature_data)
  plot_data$feature <- factor(plot_data$feature, levels = ordered)
  threshold_rows <- lapply(ordered, function(feature_name) {
    current <- plot_data[as.character(plot_data$feature) == feature_name, , drop = FALSE]
    if (nrow(current) < 10L || length(unique(current$feature_value_normalized)) < 5L) return(NULL)
    fit <- tryCatch(stats::loess(phi ~ feature_value_normalized, data = current, span = loess_span),
      error = function(error) NULL)
    if (is.null(fit)) return(NULL)
    grid <- seq(0, 1, length.out = 301L)
    fitted <- suppressWarnings(stats::predict(fit, newdata = data.frame(feature_value_normalized = grid)))
    if (max(abs(fitted), na.rm = TRUE) < 0.02) return(NULL)
    crossing <- which(diff(sign(fitted)) != 0L & is.finite(fitted[-length(fitted)]) & is.finite(fitted[-1L]))
    if (!length(crossing)) return(NULL)
    crossing_values <- grid[crossing]
    crossing_values <- crossing_values[c(TRUE, diff(crossing_values) >= 0.08)]
    crossing_values <- utils::head(crossing_values, 4L)
    data.frame(feature = feature_name, threshold = crossing_values, label = sprintf("%.2f", crossing_values))
  })
  thresholds <- dplyr::bind_rows(threshold_rows)
  if (nrow(thresholds)) thresholds$feature <- factor(thresholds$feature, levels = ordered)
  panel_background <- data.frame(feature = factor(ordered, levels = ordered),
    xmin = -Inf, xmax = Inf, positive_min = 0, positive_max = Inf,
    negative_min = -Inf, negative_max = 0)
  panel_labels <- rbind(
    data.frame(feature = factor(ordered, levels = ordered), x = 0.97, y = Inf, label = "Positive", vjust = 1.4),
    data.frame(feature = factor(ordered, levels = ordered), x = 0.97, y = -Inf, label = "Negative", vjust = -0.5))
  p <- ggplot2::ggplot(plot_data, ggplot2::aes(feature_value_normalized, phi, colour = interaction_value)) +
    ggplot2::geom_rect(data = panel_background, ggplot2::aes(xmin = xmin, xmax = xmax,
      ymin = positive_min, ymax = positive_max),
      inherit.aes = FALSE, fill = "#F8E7A3", alpha = 0.42) +
    ggplot2::geom_rect(data = panel_background, ggplot2::aes(xmin = xmin, xmax = xmax,
      ymin = negative_min, ymax = negative_max),
      inherit.aes = FALSE, fill = "#A9D7EE", alpha = 0.50) +
    ggplot2::geom_point(size = point_size, alpha = alpha) +
    ggplot2::geom_smooth(method = "loess", formula = y ~ x, span = loess_span,
      se = show_confidence, colour = "#E1A719", fill = "#F4CE61", linewidth = line_width, alpha = 0.22) +
    ggplot2::geom_hline(yintercept = 0, linetype = 2)
  if (show_thresholds && nrow(thresholds)) {
    p <- p + ggplot2::geom_vline(data = thresholds, ggplot2::aes(xintercept = threshold),
      inherit.aes = FALSE, linetype = 3, colour = "#9A7B18", linewidth = 0.45) +
      ggplot2::geom_text(data = thresholds, ggplot2::aes(x = threshold, y = 0, label = label),
        inherit.aes = FALSE, angle = 90, hjust = -0.15, size = base_size / 4, colour = "#8A6D12")
  }
  p <- p +
    ggplot2::geom_text(data = panel_labels, ggplot2::aes(x = x, y = y, label = label, vjust = vjust),
      inherit.aes = FALSE, hjust = 1, size = base_size / 4.2,
      colour = c(rep("#8A6D12", length(ordered)), rep("#23688A", length(ordered)))) +
    ggplot2::facet_wrap(~ feature, scales = "free_x", ncol = facet_columns) +
    ggplot2::scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.25)) +
    ggplot2::scale_colour_gradient(low = colours[[1]], high = colours[[3]]) +
    ggplot2::labs(title = "SHAP dependency graph (all features)", x = "Feature value (Min-Max normalized)",
      y = "SHAP value", colour = "Interaction feature\nLow                  High")
  vi_apply_plot_theme(p, theme_name, base_size, "right", FALSE, TRUE)
}

vi_fit_shap <- function(data, response, predictors, advanced, model) {
  set.seed(advanced$seed)
  if (identical(model$type, "xgboost")) {
    configured <- vi_fit_xgboost_shap(data, response, predictors, advanced)
    tables <- list(model_summary = data.frame(model = "XGBoost", objective = configured$target$objective,
        nrounds = configured$nrounds, stringsAsFactors = FALSE),
      gain_importance = configured$gain, global_shap = configured$primary, local_shap = configured$shap_table)
    if (!is.null(configured$cv)) tables$cross_validation <- as.data.frame(configured$cv$evaluation_log)
    text <- paste("# XGBoost modelandparameters\n", vi_capture(configured$fit),
      "\n\n# Gain Variable importance\n", vi_capture(configured$gain),
      "\n\n# Global SHAP\n", vi_capture(configured$primary),
      "\n\n# Partial SHAP\n", vi_capture(configured$shap_table))
    if (!is.null(configured$cv)) text <- paste0(text, "\n\n# Cross validation\n", vi_capture(configured$cv))
    return(list(tables = tables, text = text, primary = configured$primary, model = configured$fit,
      objects = list(shap_table = configured$shap_table, shap_matrix = configured$shap_matrix,
        interaction = configured$interaction, interaction_signed = configured$interaction_signed,
        x = configured$x, y = configured$y, xgb_gain = configured$gain),
      plots = list(beeswarm = function() vi_shap_plot(list(tables = tables, objects = list(shap_table = configured$shap_table,
          shap_matrix = configured$shap_matrix, interaction = configured$interaction, x = configured$x)), "beeswarm"),
        importance = function() vi_shap_plot(list(tables = tables, objects = list(shap_table = configured$shap_table,
          shap_matrix = configured$shap_matrix, interaction = configured$interaction, x = configured$x)), "importance"),
        dependence = function() vi_shap_plot(list(tables = tables, objects = list(shap_table = configured$shap_table,
          shap_matrix = configured$shap_matrix, interaction = configured$interaction, x = configured$x)), "dependence"))))
  }
  configured <- vi_fit_configured_model(data, response, predictors, model, trees = advanced$trees)
  fit <- configured$fit
  model_data <- configured$data
  feature_names <- unique(c(predictors, if (identical(model$type, "lmer")) model$random_group else character()))
  x <- model_data[, feature_names, drop = FALSE]
  y <- model_data[[response]]
  if (identical(model$type, "glm_binomial") || (identical(model$type, "randomForest") && is.factor(y))) {
    y <- as.numeric(factor(y)) - 1L
  }
  predict_function <- function(fitted_model, newdata) vi_predict_configured_model(fitted_model, newdata, model)
  predictor <- iml::Predictor$new(fit, data = x, y = y, predict.function = predict_function)
  explain_index <- seq_len(min(advanced$explain_rows, nrow(x)))
  shap_rows <- lapply(explain_index, function(index) {
    value <- iml::Shapley$new(predictor, x.interest = x[index, , drop = FALSE], sample.size = advanced$sample_size)$results
    value$observation <- index
    value
  })
  shap_table <- dplyr::bind_rows(shap_rows)
  x_plot <- x
  x_plot[] <- lapply(x_plot, function(value) if (is.factor(value) || is.character(value)) as.numeric(factor(value)) else value)
  shap_table$feature_value <- mapply(function(observation, feature) x_plot[[feature]][observation],
    shap_table$observation, shap_table$feature, USE.NAMES = FALSE)
  primary <- shap_table |>
    dplyr::group_by(feature) |>
    dplyr::summarise(importance = mean(abs(phi), na.rm = TRUE), mean_shap = mean(phi, na.rm = TRUE), .groups = "drop") |>
    dplyr::rename(term = feature) |>
    dplyr::arrange(dplyr::desc(importance))
  shap_matrix <- unclass(stats::xtabs(phi ~ observation + feature, shap_table))
  names(dimnames(shap_matrix)) <- NULL
  shap_x <- x[explain_index, , drop = FALSE]
  shap_x[] <- lapply(shap_x, function(value) if (is.factor(value) || is.character(value)) as.numeric(factor(value)) else value)
  shap_object <- shapviz::shapviz(shap_matrix, X = shap_x)
  tables <- vi_model_tables(fit)
  tables$global_shap <- primary
  tables$local_shap <- shap_table
  list(tables = tables,
    text = paste("# Predictionmodelandformula\n", vi_model_formula_text(response, predictors, model), "\n\n", vi_capture(fit), "\n\n# Global SHAP\n", vi_capture(primary),
      "\n\n# Partial SHAP\n", vi_capture(shap_table)), primary = primary, model = fit,
    objects = list(shapviz = shap_object, shap_table = shap_table, shap_matrix = shap_matrix, x = shap_x,
      y = y[explain_index],
            interaction = abs(stats::cor(shap_matrix, use = "pairwise.complete.obs")),
            interaction_signed = stats::cor(shap_matrix, use = "pairwise.complete.obs")), plots = list(
      beeswarm = shapviz::sv_importance(shap_object, kind = "bee"),
      importance = shapviz::sv_importance(shap_object, kind = "bar"),
      dependence = shapviz::sv_dependence(shap_object, v = primary$term[[1]])))
}

vi_split_groups <- function(predictors, group_count, configured = list()) {
  configured <- lapply(configured, intersect, predictors)
  configured <- Filter(length, configured)
  if (length(configured) >= 2L && length(configured) <= 4L &&
      !anyDuplicated(unlist(configured, use.names = FALSE))) {
    groups <- configured
  } else {
    group_count <- max(2L, min(4L, as.integer(group_count), length(predictors)))
    groups <- split(predictors, rep(seq_len(group_count), length.out = length(predictors)))
  }
  if (is.null(names(groups)) || any(!nzchar(names(groups)))) names(groups) <- paste0("Group_", seq_along(groups))
  groups
}

vi_fit_varpart <- function(data, responses, predictors, advanced, preprocess) {
  response <- as.matrix(data[, responses, drop = FALSE])
  if (identical(preprocess$response_transform, "hellinger")) response <- vegan::decostand(response, method = "hellinger")
  groups <- vi_split_groups(predictors, advanced$groups, advanced$group_variables %||% list())
  group_data <- lapply(groups, function(variables) data[, variables, drop = FALSE])
  fit <- switch(as.character(length(group_data)),
    `2` = vegan::varpart(response, group_data[[1]], group_data[[2]]),
    `3` = vegan::varpart(response, group_data[[1]], group_data[[2]], group_data[[3]]),
    `4` = vegan::varpart(response, group_data[[1]], group_data[[2]], group_data[[3]], group_data[[4]]),
    stop("Variation decomposition requires 2-4 sets of valid explanatory variables.", call. = FALSE))
  full_rda <- vegan::rda(response ~ ., data = data[, predictors, drop = FALSE])
  overall <- vegan::anova.cca(full_rda, permutations = advanced$permutations)
  fractions <- tryCatch(as.data.frame(fit$part$indfract) |> tibble::rownames_to_column("fraction"),
    error = function(error) data.frame(output = capture.output(print(fit))))
  group_table <- data.frame(group = paste0("X", seq_along(groups)), variables = vapply(groups, paste, collapse = " + ", character(1)))
  primary <- data.frame(term = group_table$group, importance = vapply(group_data, function(group) {
    vegan::RsquareAdj(vegan::rda(response ~ ., data = group))$adj.r.squared
  }, numeric(1)))
  list(tables = list(explanatory_groups = group_table, variation_fractions = fractions,
    overall_permutation_test = as.data.frame(overall) |> tibble::rownames_to_column("term")),
    text = paste("# Variation decomposition\n", vi_capture(fit), "\n\n# AllmodelReplacementCheck\n", vi_capture(overall)),
    primary = primary, model = full_rda, objects = list(varpart = fit), plots = list(
      partition = function() plot(fit, bg = c("#a8dadc", "#ffd166", "#cdb4db", "#90be6d")[seq_along(groups)], Xnames = group_table$group),
      importance = vi_importance_plot(primary, "Independent explanatory power of explanatory variable group", "Adjust R²"),
      ordination = function() plot(full_rda, scaling = 2, main = "RDA sorting diagram")))
}

vi_rdacca_method <- function(model_type) switch(model_type,
  lm = "RDA", rda = "RDA", cca = "CCA", dbrda = "dbRDA", model_type)

vi_rdacca_predictor_object <- function(data, predictors, advanced) {
  if (!identical(advanced$predictor_mode %||% "variables", "groups")) {
    return(data[, predictors, drop = FALSE])
  }
  groups <- vi_split_groups(predictors, advanced$groups %||% 2L,
    advanced$group_variables %||% list())
  result <- lapply(groups, function(values) data[, values, drop = FALSE])
  names(result) <- names(groups)
  result
}

vi_rdacca_distance <- function(response, data, advanced) {
  method <- advanced$distance %||% "bray"
  if (identical(method, "unifrac")) {
    tree <- attr(data, "phy_tree", exact = TRUE)
    if (is.null(tree)) stop("UniFrac requires a phylogenetic tree stored in attr(data, 'phy_tree').", call. = FALSE)
    if (!requireNamespace("GUniFrac", quietly = TRUE)) stop("UniFrac requires the GUniFrac package.", call. = FALSE)
    array <- GUniFrac::GUniFrac(response, tree, alpha = c(0, 1))$unifracs
    layer <- if ("d_1" %in% dimnames(array)[[3]]) "d_1" else dimnames(array)[[3]][[1]]
    return(stats::as.dist(array[, , layer]))
  }
  arguments <- list(x = response, method = method)
  if (identical(method, "jaccard")) arguments$binary <- isTRUE(advanced$binary_jaccard)
  if (identical(method, "aitchison")) arguments$pseudocount <- advanced$aitchison_pseudocount %||% 0.5
  do.call(vegan::vegdist, arguments)
}

vi_rdacca_permutation_tests <- function(response, distance, environment, method, advanced) {
  response_object <- if (identical(method, "dbRDA")) distance else response
  formula <- stats::reformulate(names(environment), response = "response_object")
  add <- if (identical(advanced$add %||% "none", "none")) FALSE else advanced$add
  model <- tryCatch(switch(method,
    RDA = vegan::rda(formula, data = environment),
    CCA = vegan::cca(formula, data = environment),
    dbRDA = if (identical(advanced$dbrda_engine %||% "dbrda", "capscale"))
      vegan::capscale(formula, data = environment, add = add, sqrt.dist = isTRUE(advanced$sqrt_dist)) else
      vegan::dbrda(formula, data = environment, add = add, sqrt.dist = isTRUE(advanced$sqrt_dist))),
    error = function(error) error)
  if (inherits(model, "error")) return(list(model = NULL,
    overall = data.frame(error = conditionMessage(model)), terms = data.frame(error = conditionMessage(model))))
  set.seed(as.integer(advanced$seed %||% 2026L))
  overall <- tryCatch(as.data.frame(vegan::anova.cca(model,
    permutations = advanced$permutations %||% 999L)) |> tibble::rownames_to_column("term"),
    error = function(error) data.frame(error = conditionMessage(error)))
  set.seed(as.integer(advanced$seed %||% 2026L))
  terms <- tryCatch(as.data.frame(vegan::anova.cca(model, by = "term",
    permutations = advanced$permutations %||% 999L)) |> tibble::rownames_to_column("term"),
    error = function(error) data.frame(error = conditionMessage(error)))
  list(model = model, overall = overall, terms = terms)
}

vi_rdacca_p_values <- function(term_test, terms) {
  result <- stats::setNames(rep(NA_real_, length(terms)), terms)
  if (!is.data.frame(term_test) || !nrow(term_test) || !"term" %in% names(term_test)) return(result)
  p_column <- grep("^Pr\\(", names(term_test), value = TRUE)[1]
  if (is.na(p_column)) return(result)
  cleaned <- gsub("`", "", as.character(term_test$term), fixed = TRUE)
  for (term in terms) {
    index <- match(term, cleaned)
    if (!is.na(index)) result[[term]] <- as.numeric(term_test[[p_column]][[index]])
  }
  result
}

vi_rdacca_individual_plot <- function(hierarchy, title = "Independent contribution",
                                      stacked = FALSE, alpha = 0.05, settings = list()) {
  if (!is.data.frame(hierarchy) || !nrow(hierarchy)) return(NULL)
  data <- hierarchy
  individual <- names(data)[grepl("Individual", names(data), fixed = TRUE)][1]
  unique_name <- names(data)[grepl("^Unique$", names(data))][1]
  shared <- names(data)[grepl("Average", names(data), fixed = TRUE)][1]
  percentage <- names(data)[grepl("perc|Percentage", names(data), ignore.case = TRUE)][1]
  value_name <- if (!is.na(percentage)) percentage else individual
  if (isTRUE(stacked) && !is.na(unique_name) && !is.na(shared)) {
    long <- dplyr::bind_rows(
      data.frame(term = data$term, component = "Unique (I)", value = data[[unique_name]]),
      data.frame(term = data$term, component = "Average shared (J)", value = data[[shared]]))
    long$term <- factor(long$term, levels = rev(data$term[order(data[[individual]], decreasing = TRUE)]))
    plot <- ggplot2::ggplot(long, ggplot2::aes(.data$term, .data$value,
      fill = .data$component)) + ggplot2::geom_col(width = settings$bar_width %||% 0.72,
        colour = "white", linewidth = 0.25, alpha = settings$opacity %||% 0.95) +
      ggplot2::coord_flip() + ggplot2::scale_fill_manual(values = c(
        "Unique (I)" = settings$unique_colour %||% "#3B82B8",
        "Average shared (J)" = settings$shared_colour %||% "#9CC9DF")) +
      ggplot2::labs(title = settings$title %||% title, x = NULL,
        y = "Explained variation", fill = NULL)
    return(vi_apply_plot_theme(plot, settings$theme %||% "publication",
      settings$base_size %||% 13, settings$legend_position %||% "right", FALSE,
      isTRUE(settings$show_legend %||% TRUE)))
  }
  data$importance <- as.numeric(data[[value_name]])
  data$term <- factor(data$term, levels = rev(data$term[order(data$importance, decreasing = TRUE)]))
  p_values <- if ("p.value" %in% names(data)) data$p.value else rep(NA_real_, nrow(data))
  data$significance <- vi_rf_significance(p_values, alpha)
  data$display_label <- paste0(if (isTRUE(settings$show_values %||% TRUE))
    sprintf(paste0("%.", as.integer(settings$digits %||% 2L), "f"), data$importance) else "",
    if (isTRUE(settings$show_significance %||% TRUE)) paste0(" ", data$significance) else "")
  plot <- ggplot2::ggplot(data, ggplot2::aes(.data$term, .data$importance)) +
    ggplot2::geom_col(width = settings$bar_width %||% 0.72,
      fill = settings$fill_colour %||% "#4F86B5", colour = settings$border_colour %||% "#243746",
      linewidth = 0.35, alpha = settings$opacity %||% 0.95) +
    ggplot2::geom_text(ggplot2::aes(label = .data$display_label), hjust = -0.12,
      size = settings$label_size %||% 3.6, fontface = "bold") + ggplot2::coord_flip(clip = "off") +
    ggplot2::labs(title = settings$title %||% title, x = NULL,
      y = if (!is.na(percentage)) "Independent contribution (%)" else "Independent contribution") +
    ggplot2::theme(plot.margin = ggplot2::margin(8, 42, 8, 8))
  vi_apply_plot_theme(plot, settings$theme %||% "publication", settings$base_size %||% 13,
    "none", FALSE, FALSE)
}

vi_rdacca_mixed_tests <- function(fit, response, model, predictors) {
  fixed <- tryCatch(suppressWarnings(as.data.frame(stats::drop1(fit, test = "Chisq"))) |>
    tibble::rownames_to_column("term"), error = function(error) data.frame(error = conditionMessage(error)))
  null_formula <- vi_model_formula(response, character(), model)
  null <- tryCatch(suppressWarnings(update(fit, formula = null_formula)), error = function(error) NULL)
  overall <- if (is.null(null)) data.frame(status = "Null model could not be fitted") else
    tryCatch(suppressWarnings(as.data.frame(stats::anova(null, fit))) |> tibble::rownames_to_column("model"),
      error = function(error) data.frame(error = conditionMessage(error)))
  list(overall = overall, terms = fixed)
}

vi_glmm_hp_matrix <- function(result, commonality = FALSE, preferred = NULL) {
  canonical <- if (isTRUE(commonality)) "commonality.analysis" else "hierarchical.partitioning"
  if (!is.null(result[[canonical]])) return(result[[canonical]])
  candidates <- setdiff(names(result), c("r.squaredGLMM", "variables", "type"))
  if (!is.null(preferred) && preferred %in% candidates) return(result[[preferred]])
  candidates <- candidates[vapply(result[candidates], is.matrix, logical(1))]
  if (!length(candidates)) stop("glmm.hp did not return a usable partitioning matrix.", call. = FALSE)
  result[[candidates[[1]]]]
}

vi_fit_rdacca <- function(data, response, responses, predictors, advanced, preprocess, model) {
  set.seed(as.integer(advanced$seed %||% 2026L))
  if (model$type %in% c("lmer", "glmer", "glmmTMB")) {
    formula <- vi_model_formula(response, predictors, model)
    temporary_name <- make.names(paste0(".__dava_rdacca_data_", Sys.getpid(), "_", format(Sys.time(), "%H%M%OS6")))
    assign(temporary_name, data, envir = .GlobalEnv)
    on.exit(rm(list = temporary_name, envir = .GlobalEnv), add = TRUE)
    environment(formula) <- .GlobalEnv
    model_call <- switch(model$type,
      lmer = substitute(lme4::lmer(FORMULA, data = DATA, REML = FALSE),
        list(FORMULA = formula, DATA = as.name(temporary_name))),
      glmer = substitute(lme4::glmer(FORMULA, data = DATA, family = FAMILY),
        list(FORMULA = formula, DATA = as.name(temporary_name), FAMILY = str2lang(vi_model_family_text(model)))),
      glmmTMB = substitute(glmmTMB::glmmTMB(FORMULA, data = DATA, family = FAMILY),
        list(FORMULA = formula, DATA = as.name(temporary_name), FAMILY = str2lang(vi_model_family_text(model)))))
    fitted <- eval(model_call, envir = .GlobalEnv)
    iv_groups <- if (identical(advanced$predictor_mode %||% "variables", "groups"))
      vi_split_groups(predictors, advanced$groups %||% 2L, advanced$group_variables %||% list()) else NULL
    hp <- suppressWarnings(glmm.hp::glmm.hp(fitted, iv = iv_groups,
      type = advanced$type %||% "adjR2", commonality = FALSE))
    vp <- if (isTRUE(advanced$commonality %||% TRUE))
      suppressWarnings(glmm.hp::glmm.hp(fitted, iv = iv_groups,
        type = advanced$type %||% "adjR2", commonality = TRUE)) else NULL
    preferred <- if (identical(model$type, "glmer")) "theoretical" else if (identical(model$type, "glmmTMB")) "delta" else NULL
    hierarchy_matrix <- vi_glmm_hp_matrix(hp, FALSE, preferred)
    hierarchy <- as.data.frame(hierarchy_matrix, check.names = FALSE) |> tibble::rownames_to_column("term")
    tests <- suppressWarnings(vi_rdacca_mixed_tests(fitted, response, model, predictors))
    hierarchy$p.value <- unname(vi_rdacca_p_values(tests$terms, hierarchy$term))
    plots <- list(package_raw = suppressWarnings(plot(hp)),
      package_percentage = suppressWarnings(plot(hp, plot.perc = TRUE)),
      publication_individual = vi_rdacca_individual_plot(hierarchy),
      individual_shared = vi_rdacca_individual_plot(hierarchy, "Unique and shared contributions", TRUE))
    if (!is.null(vp) && requireNamespace("upset.hp", quietly = TRUE)) {
      commonality_matrix <- vi_glmm_hp_matrix(vp, TRUE, preferred)
      plots$upset <- suppressWarnings(upset.hp::upset.hp(commonality_matrix, hierarchy_matrix,
        nVar = min(30L, 2^nrow(hierarchy_matrix) - 1L), col = "nature"))
    }
    total <- hp$r.squaredGLMM %||% hp$Total.R2
    return(list(tables = list(hierarchical_partitioning = hierarchy,
      variation_partitioning = if (is.null(vp)) data.frame() else as.data.frame(
        vi_glmm_hp_matrix(vp, TRUE, preferred)),
      overall_model_test = tests$overall, predictor_significance = tests$terms,
      model_summary = data.frame(model = model$type, total_explained_variation = as.numeric(total[[1]]))),
      text = paste("# Fitted mixed model\n", vi_capture(summary(fitted)),
        "\n\n# glmm.hp hierarchical partitioning\n", vi_capture(hierarchy_matrix),
        "\n\n# Overall model test\n", vi_capture(tests$overall),
        "\n\n# Predictor significance\n", vi_capture(tests$terms)),
      primary = data.frame(term = hierarchy$term, importance = hierarchy[[grep("Individual", names(hierarchy), value = TRUE)[1]]],
        p.value = hierarchy$p.value), model = fitted, objects = list(hp = hp, vp = vp), plots = plots))
  }

  method <- vi_rdacca_method(model$type)
  response_matrix <- as.matrix(data[, responses, drop = FALSE])
  if (identical(preprocess$response_transform, "hellinger"))
    response_matrix <- vegan::decostand(response_matrix, method = "hellinger")
  distance <- if (identical(method, "dbRDA")) vi_rdacca_distance(response_matrix, data, advanced) else NULL
  response_object <- distance %||% if (identical(model$type, "lm")) as.numeric(response_matrix[, 1]) else response_matrix
  explanatory <- vi_rdacca_predictor_object(data, predictors, advanced)
  add <- if (identical(advanced$add %||% "none", "none")) FALSE else advanced$add
  fit <- suppressWarnings(rdacca.hp::rdacca.hp(response_object, explanatory, method = method,
    type = advanced$type %||% "adjR2", dbrdatype = advanced$dbrda_engine %||% "dbrda",
    scale = isTRUE(advanced$scale), add = add, sqrt.dist = isTRUE(advanced$sqrt_dist),
    n.perm = advanced$permutations %||% 999L, var.part = isTRUE(advanced$var_part)))
  hierarchy <- as.data.frame(fit$Hier.part, check.names = FALSE) |> tibble::rownames_to_column("term")
  environment <- if (is.list(explanatory) && !is.data.frame(explanatory)) {
    group_scores <- lapply(explanatory, function(group_data) {
      if (ncol(group_data) == 1L) return(as.numeric(group_data[[1]]))
      as.numeric(stats::prcomp(group_data, center = TRUE, scale. = TRUE)$x[, 1])
    })
    as.data.frame(group_scores, check.names = FALSE)
  } else data[, predictors, drop = FALSE]
  tests <- suppressWarnings(vi_rdacca_permutation_tests(response_matrix, distance, environment, method, advanced))
  hierarchy$p.value <- unname(vi_rdacca_p_values(tests$terms, hierarchy$term))
  individual_name <- grep("Individual", names(hierarchy), value = TRUE)[1]
  primary <- data.frame(term = hierarchy$term, importance = hierarchy[[individual_name]],
    p.value = hierarchy$p.value, stringsAsFactors = FALSE)
  primary <- primary[order(primary$importance, decreasing = TRUE), , drop = FALSE]
  hierarchy_fit <- fit
  hierarchy_fit$Var.part <- NULL
  plots <- list(package_raw = suppressWarnings(plot(hierarchy_fit)),
    package_percentage = suppressWarnings(plot(hierarchy_fit, plot.perc = TRUE)) + ggplot2::theme_classic(base_size = 12) +
      ggplot2::labs(x = NULL, y = "Independent contribution (%)"),
    publication_individual = vi_rdacca_individual_plot(hierarchy, "Independent contribution",
      FALSE, advanced$significance_alpha %||% 0.05),
    individual_shared = vi_rdacca_individual_plot(hierarchy, "Unique and shared contributions", TRUE))
  varpart <- NULL
  if (isTRUE(advanced$var_part) && !is.null(fit$Var.part) && requireNamespace("upset.hp", quietly = TRUE)) {
    plots$upset <- suppressWarnings(upset.hp::upset.hp(fit$Var.part, fit$Hier.part,
      nVar = min(30L, nrow(fit$Var.part) - 1L), col = "nature"))
  }
  if (is.list(explanatory) && !is.data.frame(explanatory) &&
      length(explanatory) %in% 2:4 && !identical(method, "dbRDA")) {
    varpart <- do.call(vegan::varpart, c(list(Y = response_matrix), unname(explanatory)))
    plots$venn <- function() plot(varpart, Xnames = names(explanatory))
  }
  list(tables = list(hierarchical_partitioning = hierarchy,
    variation_partitioning = if (is.null(fit$Var.part)) data.frame() else as.data.frame(fit$Var.part),
    overall_model_test = tests$overall, predictor_significance = tests$terms,
    model_summary = data.frame(method = fit$Method_Type[[1]], type = fit$Method_Type[[2]],
      total_explained_variation = fit$Total_explained_variation)),
    text = paste("# rdacca.hp hierarchical partitioning\n", vi_capture(fit),
      "\n\n# Unique, average shared, individual and percentage\n", vi_capture(fit$Hier.part),
      "\n\n# Overall permutation test\n", vi_capture(tests$overall),
      "\n\n# Predictor permutation tests\n", vi_capture(tests$terms)),
    primary = primary, model = tests$model %||% fit,
    objects = list(hp = fit, constrained_model = tests$model, response = response_object,
      explanatory = explanatory, varpart = varpart), plots = plots)
}

vi_fit_method <- function(data, method, response, responses, predictors, preprocess, advanced,
                          model = vi_default_model(method)) {
  vi_check_dependencies(method, model)
  rdacca_multivariate <- identical(method, "rdacca_hp") && model$type %in% c("rda", "cca", "dbrda")
  responses <- if (identical(method, "varpart") || rdacca_multivariate) responses else response
  if (!length(responses) || !all(responses %in% names(data))) stop("Please select a valid response variable.", call. = FALSE)
  if (length(predictors) < 2L) stop("Please select at least two explanatory variables.", call. = FALSE)
  auxiliary <- if (model$type %in% c("lmer", "glmer", "glmmTMB")) model$random_group %||% character() else character()
  prepared <- vi_prepare_data(data, method, responses, predictors, preprocess, auxiliary = auxiliary)
  fit <- switch(method,
    relaimpo = vi_fit_relaimpo(prepared$data, response, prepared$predictors, advanced),
    dominance = vi_fit_dominance(prepared$data, response, prepared$predictors, advanced, model),
    mumin = vi_fit_mumin(prepared$data, response, prepared$predictors, advanced, model),
    rf = vi_fit_rf(prepared$data, response, prepared$predictors, advanced),
    shap = vi_fit_shap(prepared$data, response, prepared$predictors, advanced, model),
    varpart = vi_fit_varpart(prepared$data, responses, prepared$predictors, advanced, preprocess),
    rdacca_hp = vi_fit_rdacca(prepared$data, response, responses, prepared$predictors, advanced, preprocess, model))
  fit$tables <- c(list(preprocessing = prepared$report,
    suitability = vi_suitability(data, method, responses, predictors, preprocess$correlation_cutoff)), fit$tables)
  fit$prepared_data <- prepared$data
  fit$method <- method
  fit$model_settings <- model
  fit
}
