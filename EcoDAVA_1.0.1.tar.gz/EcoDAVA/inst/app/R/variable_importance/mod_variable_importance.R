vi_method_choices <- function() stats::setNames(vi_method_registry()$id, vi_method_registry()$label)

vi_state_template <- function(method) {
  selection <- vi_demo_selection(method)
  list(preprocess = vi_default_preprocess(method), advanced = vi_default_advanced(method),
    model = vi_default_model(method),
    response = selection$response, responses = selection$responses, predictors = selection$predictors,
    grouping_enabled = FALSE, variable_groups = list(), result = NULL, error = "", code = "")
}

vi_grouped_variables <- function(groups) unique(unlist(groups %||% list(), use.names = FALSE))

vi_list_get <- function(values, index, default = character()) {
  if (!is.list(values) || length(values) < index || is.null(values[[index]])) return(default)
  values[[index]]
}

vi_clean_variable_groups <- function(groups, variables) {
  groups <- groups %||% list()
  cleaned <- lapply(groups, function(values) intersect(unique(values), variables))
  Filter(length, cleaned)
}

vi_variable_group_controls <- function(ns, predictors, state, enabled) {
  groups <- vi_clean_variable_groups(state$variable_groups, predictors)
  available <- setdiff(predictors, vi_grouped_variables(groups))
  group_summary <- if (length(groups)) {
    lapply(seq_along(groups), function(index) shiny::div(class = "vi-variable-group-row",
      shiny::tags$b(names(groups)[index]), shiny::span(paste(groups[[index]], collapse = "、"))))
  } else shiny::div(class = "small text-muted", "Variable grouping has not been added.")
  shiny::tagList(
    shiny::checkboxInput(ns("variable_group_enabled"), "Variable grouping", isTRUE(enabled)),
    shiny::conditionalPanel(
      condition = sprintf("input['%s'] === true", ns("variable_group_enabled")),
      shiny::textInput(ns("variable_group_name"), "Group name", placeholder = "Example: climate factors"),
      shinyWidgets::pickerInput(ns("variable_group_variables"), "Grouping variables", choices = available,
        multiple = TRUE, options = list(`live-search` = TRUE, `actions-box` = TRUE,
          `none-selected-text` = "Select variables that are not yet grouped")),
      shiny::actionButton(ns("add_variable_group"), "Add", icon = shiny::icon("plus"),
        class = "btn-outline-primary w-100"),
      shiny::div(class = "vi-variable-group-list", group_summary),
      if (length(groups)) shiny::tagList(
        shiny::selectInput(ns("remove_variable_group_name"), "Manage existing groups",
          choices = stats::setNames(names(groups), names(groups))),
        shiny::actionButton(ns("remove_variable_group"), "Delete selected group", icon = shiny::icon("trash"),
          class = "btn-outline-danger w-100"))
    )
  )
}

vi_sidebar_controls <- function(ns, method, data, state) {
  numeric_names <- names(data)[vapply(data, is.numeric, logical(1))]
  all_names <- names(data)
  multivariate <- identical(method, "varpart") ||
    (identical(method, "rdacca_hp") && state$model$type %in% c("rda", "cca", "dbrda"))
  capability <- vi_model_capability(method, state$model)
  binary_names <- all_names[vapply(data, function(value) {
    observed <- unique(value[!is.na(value)])
    length(observed) == 2L
  }, logical(1))]
  count_names <- all_names[vapply(data, function(value) {
    observed <- value[!is.na(value)]
    is.numeric(value) && length(observed) && all(observed >= 0) && all(observed == floor(observed))
  }, logical(1))]
  response_choices <- if (identical(method, "mumin") && state$model$type %in% c("glm", "glmmTMB")) {
    switch(state$model$family %||% "gaussian", binomial = binary_names,
      poisson = count_names, nbinom2 = count_names, numeric_names)
  } else switch(capability$response[[1]], continuous = numeric_names,
    binary = binary_names, any = all_names, numeric_names)
  response_selected <- intersect(state$response %||% "", response_choices)[1] %||% response_choices[1] %||% ""
  responses_selected <- intersect(state$responses %||% character(), numeric_names)
  if (!length(responses_selected) && multivariate) responses_selected <- utils::head(numeric_names, 5L)
  predictor_choices <- setdiff(if (method %in% c("rf", "shap", "mumin")) all_names else numeric_names,
    if (multivariate) responses_selected else response_selected)
  if (method %in% c("mumin", "rdacca_hp") && state$model$type %in% c("lmer", "glmer", "glmmTMB")) {
    predictor_choices <- setdiff(predictor_choices, state$model$random_group %||% "")
  }
  predictors_selected <- intersect(state$predictors %||% character(), predictor_choices)
  if (length(predictors_selected) < 2L) predictors_selected <- utils::head(predictor_choices, 5L)
  shiny::tagList(
    if (multivariate) shinyWidgets::pickerInput(ns("responses"), "Response variable matrix", choices = numeric_names,
      selected = responses_selected, multiple = TRUE, stateInput = TRUE,
      options = list(`live-search` = TRUE, `actions-box` = TRUE))
    else shiny::selectInput(ns("response"), "response variable", choices = response_choices, selected = response_selected),
    shinyWidgets::pickerInput(ns("predictors"), if (method == "varpart" ||
        (method == "rdacca_hp" && identical(state$advanced$predictor_mode, "groups"))) "Explanatory variables to be grouped" else "Explanatory variables",
      choices = predictor_choices, selected = predictors_selected, multiple = TRUE,
      stateInput = TRUE,
      options = list(`live-search` = TRUE, `actions-box` = TRUE)),
    shiny::div(class = "small text-muted mt-1", vi_method_info(method)$scenario)
  )
}

vi_model_controls <- function(ns, method, data, model, predictors) {
  choices <- vi_model_choices(method)
  if (!length(choices)) return(NULL)
  predictors <- intersect(predictors %||% character(), names(data))
  selected <- if (model$type %in% unname(choices)) model$type else unname(choices)[1]
  group_choices <- names(data)[vapply(data, function(value) {
    (is.factor(value) || is.character(value)) && length(unique(value[!is.na(value)])) >= 2L
  }, logical(1))]
  random_group <- if (model$random_group %in% group_choices) model$random_group else group_choices[1] %||% ""
  slope_choices <- predictors[predictors %in% names(data) & vapply(data[predictors], is.numeric, logical(1))]
  random_slope <- if (model$random_slope %in% slope_choices) model$random_slope else slope_choices[1] %||% ""
  random_model <- selected %in% c("lmer", "glmer", "glmmTMB")
  family_choices <- if (selected %in% c("glm", "glmer", "glmmTMB")) vi_model_family_choices(selected) else character()
  family_selected <- if ((model$family %||% "gaussian") %in% unname(family_choices)) model$family else unname(family_choices)[1] %||% "gaussian"
  shiny::tagList(
    shiny::selectInput(ns("model_type"), "model", choices = choices, selected = selected),
    if (length(family_choices)) shiny::selectInput(ns("model_family"), "Distribution family", choices = family_choices, selected = family_selected),
    if (random_model) shiny::selectInput(ns("random_structure"), "Random effects structure",
      choices = c("Random intercept" = "intercept", "Correlated random slope" = "slope", "Uncorrelated random slopes" = "uncorrelated_slope"),
      selected = model$random_structure %||% "intercept"),
    if (random_model) shiny::selectInput(ns("random_group"), "Random variable",
      choices = group_choices, selected = random_group),
    if (random_model && !identical(model$random_structure, "intercept"))
      shiny::selectInput(ns("random_slope"), "Random slope variable", choices = slope_choices, selected = random_slope)
  )
}

vi_rdacca_formula_preview <- function(response, responses, predictors, model, advanced) {
  if (model$type %in% c("lmer", "glmer", "glmmTMB")) {
    return(paste(vi_model_formula_text(response, predictors, model),
      sprintf("hp_result <- glmm.hp::glmm.hp(importance_model, type = %s)",
        dQuote(advanced$type %||% "adjR2", q = FALSE)), sep = "\n"))
  }
  response_line <- if (identical(model$type, "lm"))
    sprintf("response_object <- model_data[[%s]]", dQuote(response, q = FALSE)) else
    sprintf("response_matrix <- as.matrix(model_data[, c(%s), drop = FALSE])", vi_quote(responses))
  if (identical(model$type, "dbrda")) response_line <- paste(response_line,
    sprintf("response_object <- vegan::vegdist(response_matrix, method = %s)",
      dQuote(advanced$distance %||% "bray", q = FALSE)), sep = "\n")
  method <- vi_rdacca_method(model$type)
  response_name <- if (model$type %in% c("lm", "dbrda")) "response_object" else "response_matrix"
  paste(response_line, "explanatory_data <- model_data[, predictor_vars, drop = FALSE]",
    sprintf("hp_result <- rdacca.hp::rdacca.hp(%s, explanatory_data, method = %s)",
      response_name, dQuote(method, q = FALSE)), sep = "\n")
}

vi_advanced_controls <- function(ns, method, settings, numeric_names, model = vi_default_model(method)) {
  switch(method,
    relaimpo = shiny::tagList(
      shinyWidgets::pickerInput(ns("adv_metrics"), "Contribution decomposition index",
        choices = c("LMG/Shapley R²" = "lmg", "Last entry" = "last", "Enter first" = "first", "Pratt" = "pratt", "Genizi" = "genizi", "CAR" = "car"),
        selected = settings$metrics, multiple = TRUE, options = list(`actions-box` = TRUE)),
      shiny::checkboxInput(ns("adv_relative"), "Normalized to relative contribution", settings$relative),
      shiny::checkboxInput(ns("adv_bootstrap"), "Bootstrap confidence interval", settings$bootstrap),
      shiny::numericInput(ns("adv_bootstrap_reps"), "Bootstrap times", settings$bootstrap_reps, min = 100, max = 10000),
      shiny::sliderInput(ns("adv_confidence"), "Confidence level", min = 0.8, max = 0.99, value = settings$confidence, step = 0.01),
      shiny::numericInput(ns("adv_seed"), "Random seed", settings$seed, min = 1)),
    dominance = shiny::tagList(
      shiny::selectInput(ns("adv_fit_metric"), "Fitting contribution index", vi_dominance_metric_choices(model$type),
        selected = if (settings$fit_metric %in% unname(vi_dominance_metric_choices(model$type))) settings$fit_metric else unname(vi_dominance_metric_choices(model$type))[1]),
      shiny::numericInput(ns("adv_max_predictors"), "Maximum number of explanatory variables", settings$max_predictors, min = 2, max = 20),
      shiny::numericInput(ns("adv_seed"), "Random seed", settings$seed, min = 1)),
    mumin = shiny::tagList(
      shiny::selectInput(ns("adv_rank"), "Model ranking criteria",
        choices = c("Small sample correction AIC (AICc)" = "AICc", "AIC" = "AIC", "BIC" = "BIC"), selected = settings$rank),
      shiny::selectInput(ns("adv_selection_rule"), "Candidate model set rules",
        choices = c("ΔInformation Criterion Threshold" = "delta", "Cumulative model weight" = "weight"), selected = settings$selection_rule),
      shiny::numericInput(ns("adv_delta"), "ΔThreshold", settings$delta, min = 0, max = 20, step = 0.5),
      shiny::sliderInput(ns("adv_cumulative_weight"), "Cumulative model weight threshold", min = 0.5, max = 0.999,
        value = settings$cumulative_weight, step = 0.01),
      shiny::selectInput(ns("adv_averaging"), "Model averaging method",
        choices = c("Full model average (missing item coefficients are treated as 0)" = "full", "Conditional average (only models containing this term)" = "conditional"),
        selected = settings$averaging),
      shiny::selectInput(ns("adv_beta"), "Coefficient normalization",
        choices = c("Standard deviation normalization" = "sd", "standard deviation" = "partial.sd", "Not standardized" = "none"), selected = settings$beta),
      shiny::sliderInput(ns("adv_confidence"), "Confidence level", min = 0.80, max = 0.99,
        value = settings$confidence, step = 0.01),
      shiny::checkboxInput(ns("adv_revised_variance"), "Use modified unconditional variance", settings$revised_variance),
      shiny::checkboxInput(ns("adv_include_null"), "Allow null models in candidate set", settings$include_null),
      shiny::numericInput(ns("adv_max_predictors"), "Maximum number of explanatory variables", settings$max_predictors, min = 2, max = 15),
      shiny::numericInput(ns("adv_seed"), "Random seed", settings$seed, min = 1)),
    rf = shiny::tagList(
      shiny::numericInput(ns("adv_trees"), "Number of trees", settings$trees, min = 100, max = 10000, step = 100),
      shiny::numericInput(ns("adv_permutations"), "Importance replacement times", settings$permutations %||% 1000L, min = 9, max = 10000, step = 100),
      shiny::numericInput(ns("adv_cores"), "Number of parallel CPU cores", settings$cores %||% 6L,
        min = 1, max = vi_available_cores(), step = 1),
      shiny::numericInput(ns("adv_mtry"), "Number of candidate variables for each split (0=automatic)", settings$mtry, min = 0),
      shiny::numericInput(ns("adv_nodesize"), "Minimum sample size for endpoints", settings$nodesize, min = 1),
      shiny::checkboxInput(ns("adv_scale_importance"), "Normalized replacement importance", isTRUE(settings$scale_importance)),
      shiny::sliderInput(ns("adv_alpha"), "Variable importance significance threshold", min = 0.001, max = 0.10,
        value = settings$alpha %||% 0.05, step = 0.001),
      shiny::checkboxInput(ns("adv_a3_enabled"), "Using A3 to test the overall model", isTRUE(settings$a3_enabled)),
      shiny::selectInput(ns("adv_a3_p_acc"), "A3 P-value accuracy",
        choices = c("0.1 (fast)" = 0.1, "0.05" = 0.05, "0.01 (recommended)" = 0.01, "0.001 (fine, slower)" = 0.001),
        selected = as.character(settings$a3_p_acc %||% 0.01)),
      shiny::numericInput(ns("adv_a3_folds"), "A3 cross-validation fold (0=LOOCV)",
        settings$a3_folds %||% 5L, min = 0, max = 20, step = 1),
      shiny::numericInput(ns("adv_seed"), "Random seed", settings$seed, min = 1)),
    shap = shiny::tagList(
      if (identical(model$type, "randomForest")) shiny::numericInput(ns("adv_trees"), "Number of random forest trees", settings$trees, min = 100, max = 5000, step = 100),
      if (identical(model$type, "xgboost")) shiny::tagList(
        shiny::numericInput(ns("adv_nrounds"), "Maximum number of iteration rounds", settings$nrounds %||% 300L, min = 50, max = 3000, step = 50),
        shiny::numericInput(ns("adv_max_depth"), "Maximum depth of a single tree", settings$max_depth %||% 3L, min = 1, max = 10),
        shiny::sliderInput(ns("adv_eta"), "learning rate eta", min = 0.005, max = 0.3, value = settings$eta %||% 0.05, step = 0.005),
        shiny::numericInput(ns("adv_lambda"), "L2 regular lambda", settings$lambda %||% 1, min = 0, step = 0.1),
        shiny::numericInput(ns("adv_alpha"), "L1 regular alpha", settings$alpha %||% 0.1, min = 0, step = 0.1),
        shiny::sliderInput(ns("adv_subsample"), "Sample sampling ratio", min = 0.5, max = 1, value = settings$subsample %||% 0.8, step = 0.05),
        shiny::sliderInput(ns("adv_colsample"), "Feature sampling ratio", min = 0.5, max = 1, value = settings$colsample_bytree %||% 0.8, step = 0.05),
        shiny::numericInput(ns("adv_nfold"), "Cross validation fold", settings$nfold %||% 5L, min = 2, max = 10),
        shiny::numericInput(ns("adv_early_stopping"), "Early stopping rounds", settings$early_stopping_rounds %||% 20L, min = 5, max = 100)),
      if (!identical(model$type, "xgboost")) shiny::numericInput(ns("adv_explain_rows"), "Explain sample number", settings$explain_rows, min = 1, max = 200),
      if (!identical(model$type, "xgboost")) shiny::numericInput(ns("adv_sample_size"), "Shapley Monte Carlo times per sample", settings$sample_size, min = 20, max = 1000, step = 20),
      shiny::numericInput(ns("adv_seed"), "Random seed", settings$seed, min = 1)),
    varpart = shiny::tagList(
      shiny::numericInput(ns("adv_permutations"), "Number of replacements", settings$permutations, min = 99, max = 9999, step = 100),
      shiny::selectInput(ns("adv_groups"), "Number of explanatory variable groups", choices = 2:4, selected = settings$groups),
      lapply(seq_len(4L), function(index) shinyWidgets::pickerInput(ns(paste0("adv_group_", index)), paste0("Explanatory variable group X", index),
        choices = numeric_names, selected = vi_list_get(settings$group_variables, index), multiple = TRUE,
        options = list(`live-search` = TRUE, `actions-box` = TRUE))),
      shiny::checkboxInput(ns("adv_adjusted"), "Report Adjustment R²", settings$adjusted),
      shiny::numericInput(ns("adv_seed"), "Random seed", settings$seed, min = 1)),
    rdacca_hp = shiny::tagList(
      shiny::selectInput(ns("adv_type"), "Interpretation rate type", c("Adjust R²" = "adjR2", "R²" = "R2"), settings$type),
      shiny::numericInput(ns("adv_permutations"), "Number of replacements", settings$permutations, min = 99, max = 9999, step = 100),
      shiny::checkboxInput(ns("adv_var_part"), "Output full variation partition", settings$var_part),
      shiny::checkboxInput(ns("adv_scale"), "Normalized by rdacca.hp", settings$scale),
      shiny::selectInput(ns("adv_predictor_mode"), "Interpretation level",
        c("Predictor-by-predictor" = "variables", "Predictor Group/Explanatory Matrix" = "groups"), settings$predictor_mode %||% "variables"),
      shiny::conditionalPanel(condition = sprintf("input['%s'] === 'groups'", ns("adv_predictor_mode")),
        shiny::selectInput(ns("adv_groups"), "Explain the number of matrices", choices = 2:4, selected = settings$groups %||% 2L),
        lapply(seq_len(4L), function(index) shinyWidgets::pickerInput(ns(paste0("adv_group_", index)),
          paste0("Interpretation matrix X", index), choices = numeric_names,
          selected = vi_list_get(settings$group_variables, index), multiple = TRUE,
          options = list(`live-search` = TRUE, `actions-box` = TRUE)))),
      shiny::conditionalPanel(condition = sprintf("input['%s'] === 'dbrda'", ns("model_type")),
        shiny::selectInput(ns("adv_distance"), "Ecological distance",
          choices = c("Bray-Curtis" = "bray", "Jaccard" = "jaccard", "Aitchison" = "aitchison",
            "Euclidean" = "euclidean", "Manhattan" = "manhattan", "Canberra" = "canberra",
            "Kulczynski" = "kulczynski", "Morisita-Horn" = "horn", "Mountford" = "mountford",
            "UniFrac (requires phy_tree attribute)" = "unifrac"), selected = settings$distance %||% "bray"),
        shiny::selectInput(ns("adv_dbrda_engine"), "db-RDA engine",
          c("vegan::dbrda" = "dbrda", "vegan::capscale" = "capscale"), settings$dbrda_engine %||% "dbrda"),
        shiny::checkboxInput(ns("adv_binary_jaccard"), "Jaccard uses binary form", isTRUE(settings$binary_jaccard)),
        shiny::selectInput(ns("adv_add"), "Non-Euclidean distance correction",
          c("No correction" = "none", "Lingoes" = "lingoes", "Cailliez" = "cailliez"), settings$add %||% "lingoes"),
        shiny::checkboxInput(ns("adv_sqrt_dist"), "Take the square root of the distance", isTRUE(settings$sqrt_dist)),
        shiny::numericInput(ns("adv_aitchison_pseudocount"), "Aitchison pseudo count",
          settings$aitchison_pseudocount %||% 0.5, min = 1e-08, step = 0.1)),
      shiny::checkboxInput(ns("adv_commonality"), "Mixed model output commonality analysis", isTRUE(settings$commonality)),
      shiny::sliderInput(ns("adv_significance_alpha"), "Significance threshold", min = 0.001, max = 0.1,
        value = settings$significance_alpha %||% 0.05, step = 0.001),
      shiny::numericInput(ns("adv_seed"), "Random seed", settings$seed, min = 1)))
}

vi_shap_plot_settings_ui <- function(ns) {
  theme_choices <- if (exists("dava_plot_theme_choices", mode = "function")) dava_plot_theme_choices() else
    c("Publication" = "publication", "Classic" = "classic", "Minimal" = "minimal", "Science" = "science")
  show_for <- function(plot_name) sprintf("input['%s'] === '%s'", ns("shap_result_plot"), plot_name)
  shiny::tagList(
    shiny::tags$div(class = "stat-box", shiny::tags$strong("Graphics settings")),
    shiny::tags$p(class = "text-muted small", "The current result graph uses independent settings, and switching graphs will not overwrite other graph parameters."),
    shiny::conditionalPanel(condition = show_for("beeswarm"),
      shiny::selectInput(ns("shap_beeswarm_theme"), "Topic", choices = theme_choices, selected = "publication"),
      shiny::selectInput(ns("shap_beeswarm_palette"), "Eigenvalue color matching", choices = c("Scientific", "Nature", "Forest", "Viridis"), selected = "Scientific"),
      shiny::sliderInput(ns("shap_beeswarm_base_size"), "Basic font size", min = 8, max = 24, value = 13, step = 1),
      shiny::sliderInput(ns("shap_beeswarm_point_size"), "Scatter size", min = 0.5, max = 5, value = 1.6, step = 0.1),
      shiny::sliderInput(ns("shap_beeswarm_alpha"), "Scatter transparency", min = 0.1, max = 1, value = 0.65, step = 0.05),
      shiny::numericInput(ns("shap_beeswarm_top_n"), "Display the number of features", value = 12L, min = 2, max = 50)),
    shiny::conditionalPanel(condition = show_for("correlation"),
      shiny::selectInput(ns("shap_correlation_theme"), "Bar Chart Theme", choices = theme_choices, selected = "publication"),
      shiny::selectInput(ns("shap_correlation_palette"), "Heat map color matching", choices = c("Scientific", "Nature", "Forest", "Viridis"), selected = "Scientific"),
      shiny::sliderInput(ns("shap_correlation_base_size"), "Basic font size", min = 8, max = 24, value = 13, step = 1),
      shiny::numericInput(ns("shap_correlation_top_n"), "Display the number of features", value = 12L, min = 2, max = 30),
      shiny::sliderInput(ns("shap_correlation_digits"), "Interactive value decimal places", min = 1, max = 5, value = 3, step = 1)),
    shiny::conditionalPanel(condition = show_for("network"),
      shiny::selectInput(ns("shap_network_palette"), "Node and edge color matching", choices = c("Scientific", "Nature", "Forest", "Viridis"), selected = "Scientific"),
      shiny::sliderInput(ns("shap_network_base_size"), "Basic font size", min = 8, max = 24, value = 13, step = 1),
      shiny::numericInput(ns("shap_network_top_n"), "Display the number of features", value = 12L, min = 2, max = 30),
      shiny::sliderInput(ns("shap_network_node_min"), "Minimum node size", min = 1, max = 10, value = 3, step = 0.5),
      shiny::sliderInput(ns("shap_network_node_max"), "Maximum node size", min = 6, max = 24, value = 11, step = 0.5),
      shiny::sliderInput(ns("shap_network_edge_max"), "Maximum edge width", min = 1, max = 10, value = 4, step = 0.25),
      shiny::sliderInput(ns("shap_network_alpha"), "Graphic transparency", min = 0.1, max = 1, value = 0.62, step = 0.05),
      shiny::sliderInput(ns("shap_network_threshold"), "Interaction strength threshold", min = 0, max = 1, value = 0, step = 0.01)),
    shiny::conditionalPanel(condition = show_for("dependence"),
      shiny::selectInput(ns("shap_dependence_theme"), "Topic", choices = theme_choices, selected = "publication"),
      shiny::selectInput(ns("shap_dependence_palette"), "Interactive feature color matching", choices = c("Scientific", "Nature", "Forest", "Viridis"), selected = "Scientific"),
      shiny::sliderInput(ns("shap_dependence_base_size"), "Basic font size", min = 8, max = 24, value = 13, step = 1),
      shiny::sliderInput(ns("shap_dependence_point_size"), "Scatter size", min = 0.5, max = 5, value = 1.6, step = 0.1),
      shiny::sliderInput(ns("shap_dependence_alpha"), "Scatter transparency", min = 0.1, max = 1, value = 0.65, step = 0.05),
      shiny::numericInput(ns("shap_dependence_top_n"), "Display the number of features", value = 12L, min = 2, max = 30),
      shiny::sliderInput(ns("shap_dependence_loess_span"), "Loess smooth span", min = 0.15, max = 0.8, value = 0.3, step = 0.05),
      shiny::sliderInput(ns("shap_dependence_line_width"), "Trend line width", min = 0.3, max = 3, value = 1.05, step = 0.05),
      shiny::sliderInput(ns("shap_dependence_columns"), "Combination chart column number", min = 1, max = 5, value = 3, step = 1),
      shiny::checkboxInput(ns("shap_dependence_confidence"), "Show Loess confidence bands", TRUE),
      shiny::checkboxInput(ns("shap_dependence_thresholds"), "show SHAP=0 intersection threshold", TRUE))
  )
}

vi_result_plot_settings_prefix <- function(plot_name) {
  paste0("vi_result_plot_", gsub("[^A-Za-z0-9]+", "_", plot_name %||% "result"))
}

dava_vi_custom_result <- function(run, data, method, code = "") {
  dava_custom_run_assert(run)
  objects <- dava_custom_run_objects(run)
  tables <- list()
  for (name in names(objects)) {
    object <- objects[[name]]
    if (name %in% c("df", "vi_data", "analysis_data", "model_data")) next
    if (is.matrix(object)) object <- as.data.frame(object, check.names = FALSE)
    if (is.data.frame(object)) tables[[name]] <- object
  }
  value <- run$value
  if (is.list(value) && is.list(value$tables)) tables <- c(tables, value$tables)
  tables <- tables[!duplicated(names(tables))]
  if (!length(tables)) {
    tables$custom_objects <- data.frame(
      object = names(objects),
      class = vapply(objects, function(object) paste(class(object), collapse = "/"), character(1)),
      stringsAsFactors = FALSE
    )
  }
  plots <- Filter(dava_code_is_plot_object, objects)
  custom_plot <- dava_custom_run_plot(run)
  if (!is.null(custom_plot)) plots <- c(list(custom_plot = custom_plot), plots)
  plots <- plots[!duplicated(names(plots))]
  prepared <- objects$model_data %||% data
  list(
    tables = tables,
    prepared_data = as.data.frame(prepared, check.names = FALSE),
    method = method, primary = tables[[1]] %||% data.frame(),
    model = objects$importance_model %||% objects$global_model %||%
      objects$mixed_model %||% NULL,
    objects = objects, plots = plots,
    text = run$output %||% "", code = code %||% ""
  )
}

vi_code_plot_params <- function(input, method) {
  plot_name <- input$result_plot_name %||% switch(method,
    relaimpo = "importance", dominance = "importance", mumin = "figure4a",
    rf = "permutation_importance", shap = input$shap_result_plot %||% "beeswarm",
    varpart = "partition", rdacca_hp = "publication_individual", "result")
  settings <- if (identical(method, "shap")) {
    switch(plot_name,
      beeswarm = list(theme = input$shap_beeswarm_theme %||% "publication",
        palette = input$shap_beeswarm_palette %||% "Scientific",
        base_size = input$shap_beeswarm_base_size %||% 13,
        point_size = input$shap_beeswarm_point_size %||% 1.6,
        alpha = input$shap_beeswarm_alpha %||% 0.65,
        top_n = input$shap_beeswarm_top_n %||% 12L),
      correlation = list(theme = input$shap_correlation_theme %||% "publication",
        palette = input$shap_correlation_palette %||% "Scientific",
        base_size = input$shap_correlation_base_size %||% 13,
        top_n = input$shap_correlation_top_n %||% 12L,
        label_digits = input$shap_correlation_digits %||% 3L),
      network = list(palette = input$shap_network_palette %||% "Scientific",
        base_size = input$shap_network_base_size %||% 13,
        top_n = input$shap_network_top_n %||% 12L,
        node_size_min = input$shap_network_node_min %||% 3,
        node_size_max = input$shap_network_node_max %||% 11,
        edge_width_max = input$shap_network_edge_max %||% 4,
        alpha = input$shap_network_alpha %||% 0.62,
        interaction_threshold = input$shap_network_threshold %||% 0),
      dependence = list(theme = input$shap_dependence_theme %||% "publication",
        palette = input$shap_dependence_palette %||% "Scientific",
        base_size = input$shap_dependence_base_size %||% 13,
        point_size = input$shap_dependence_point_size %||% 1.6,
        alpha = input$shap_dependence_alpha %||% 0.65,
        top_n = input$shap_dependence_top_n %||% 12L,
        loess_span = input$shap_dependence_loess_span %||% 0.3,
        line_width = input$shap_dependence_line_width %||% 1.05,
        facet_columns = input$shap_dependence_columns %||% 3L,
        show_confidence = input$shap_dependence_confidence %||% TRUE,
        show_thresholds = input$shap_dependence_thresholds %||% TRUE))
  } else if (identical(method, "rf") && identical(plot_name, "permutation_importance")) {
    vi_rf_plot_settings(input)
  } else if (identical(method, "rdacca_hp")) {
    vi_rdacca_plot_settings(input, plot_name)
  } else if (exists("dava_result_plot_settings", mode = "function")) {
    dava_result_plot_settings(input, vi_result_plot_settings_prefix(plot_name))
  } else {
    list(theme = "publication", palette = "Scientific", base_size = 13,
      title = "", legend_position = "right")
  }
  c(list(plot = plot_name), settings)
}

vi_result_plot_choices <- function(method, plots) {
  plot_names <- names(plots %||% list())
  labels <- if (identical(method, "mumin")) c(
    figure4a = "Multi-model inference: variable importance and model average effect",
    importance = "MuMIn variable importance",
    model_weights = "Candidate model weights"
  ) else if (identical(method, "rf")) c(
    permutation_importance = "Permutation importance and significance",
    oob = "OOB error"
  ) else if (identical(method, "rdacca_hp")) c(
    package_raw = "Package plot: raw independent contribution",
    package_percentage = "Package plot: relative contribution (%)",
    publication_individual = "Publication plot: independent contribution",
    individual_shared = "Unique (I) and shared (J) contribution",
    upset = "Hierarchical-partitioning interaction UpSet",
    venn = "Grouped variation-partitioning Venn diagram"
  ) else stats::setNames(plot_names, plot_names)
  display_labels <- unname(labels[plot_names])
  display_labels[is.na(display_labels)] <- plot_names[is.na(display_labels)]
  stats::setNames(as.list(plot_names), display_labels)
}

vi_rf_plot_settings_ui <- function(ns) {
  theme_choices <- if (exists("dava_plot_theme_choices", mode = "function")) dava_plot_theme_choices() else
    c("Publication" = "publication", "Classic" = "classic", "Minimal" = "minimal")
  shiny::tagList(
    shiny::tags$div(class = "stat-box", shiny::tags$strong("Permutation-importance plot")),
    shiny::textInput(ns("rf_plot_title"), "Plot title", value = "Permutation importance with significance"),
    shiny::selectInput(ns("rf_plot_theme"), "Theme", choices = theme_choices, selected = "publication"),
    shiny::selectInput(ns("rf_plot_palette"), "Importance gradient",
      choices = c("Blue-Yellow-Red" = "BlueYellowRed", "Viridis" = "Viridis",
        "Blue-Red" = "BlueRed", "Forest" = "Forest"), selected = "BlueYellowRed"),
    shiny::numericInput(ns("rf_plot_top_n"), "Number of predictors", value = 20L, min = 1, max = 100),
    shiny::sliderInput(ns("rf_plot_base_size"), "Base font size", min = 8, max = 24, value = 13, step = 1),
    shiny::sliderInput(ns("rf_plot_label_size"), "Value-label size", min = 2, max = 8, value = 3.2, step = 0.1),
    shiny::sliderInput(ns("rf_plot_model_text_size"), "Model-test text size", min = 2, max = 8, value = 3.4, step = 0.1),
    shiny::sliderInput(ns("rf_plot_bar_width"), "Bar width", min = 0.3, max = 1, value = 0.78, step = 0.02),
    shiny::sliderInput(ns("rf_plot_alpha"), "Bar opacity", min = 0.2, max = 1, value = 0.95, step = 0.05),
    shiny::checkboxInput(ns("rf_plot_show_values"), "Show importance values", TRUE),
    shiny::checkboxInput(ns("rf_plot_show_significance"), "Show significance marks", TRUE),
    shiny::checkboxInput(ns("rf_plot_show_model_test"), "Show A3 R2 and P value", TRUE)
  )
}

vi_rf_plot_settings <- function(input) {
  list(title = input$rf_plot_title %||% "Permutation importance with significance",
    theme = input$rf_plot_theme %||% "publication", palette = input$rf_plot_palette %||% "BlueYellowRed",
    top_n = input$rf_plot_top_n %||% 20L, base_size = input$rf_plot_base_size %||% 13,
    label_size = input$rf_plot_label_size %||% 3.2, model_text_size = input$rf_plot_model_text_size %||% 3.4,
    bar_width = input$rf_plot_bar_width %||% 0.78, alpha = input$rf_plot_alpha %||% 0.95,
    show_values = isTRUE(input$rf_plot_show_values %||% TRUE),
    show_significance = isTRUE(input$rf_plot_show_significance %||% TRUE),
    show_model_test = isTRUE(input$rf_plot_show_model_test %||% TRUE))
}

vi_rdacca_plot_settings_ui <- function(ns, plot_name) {
  prefix <- paste0("rdacca_plot_", plot_name, "_")
  id <- function(name) ns(paste0(prefix, name))
  theme_choices <- if (exists("dava_plot_theme_choices", mode = "function")) dava_plot_theme_choices() else
    c("Publication" = "publication", "Classic" = "classic", "Minimal" = "minimal")
  common <- shiny::tagList(
    shiny::selectInput(id("theme"), "Theme", theme_choices, selected = "publication"),
    shiny::sliderInput(id("base_size"), "Base font size", 8, 24, 13, 1))
  shiny::tagList(
    shiny::tags$div(class = "stat-box", shiny::tags$strong(
      paste("Plot settings:", vi_result_plot_choices("rdacca_hp", stats::setNames(list(NULL), plot_name)) |> names()))),
    if (plot_name %in% c("package_raw", "package_percentage")) shiny::tagList(
      common, shiny::textInput(id("title"), "Plot title", ""),
      shiny::selectInput(id("fill_colour"), "Bar colour",
        c("Scientific blue" = "#4F86B5", "Forest green" = "#4D927B", "Warm orange" = "#D98252"), "#4F86B5")),
    if (identical(plot_name, "publication_individual")) shiny::tagList(
      common, shiny::textInput(id("title"), "Plot title", "Independent contribution"),
      shiny::selectInput(id("fill_colour"), "Bar colour",
        c("Scientific blue" = "#4F86B5", "Forest green" = "#4D927B", "Warm orange" = "#D98252"), "#4F86B5"),
      shiny::sliderInput(id("bar_width"), "Bar width", 0.3, 1, 0.72, 0.02),
      shiny::sliderInput(id("opacity"), "Bar opacity", 0.2, 1, 0.95, 0.05),
      shiny::sliderInput(id("label_size"), "Value-label size", 2, 8, 3.6, 0.1),
      shiny::sliderInput(id("digits"), "Displayed decimals", 0, 5, 2, 1),
      shiny::checkboxInput(id("show_values"), "Show contribution values", TRUE),
      shiny::checkboxInput(id("show_significance"), "Show significance marks", TRUE)),
    if (identical(plot_name, "individual_shared")) shiny::tagList(
      common, shiny::textInput(id("title"), "Plot title", "Unique and shared contributions"),
      shiny::selectInput(id("unique_colour"), "Unique-contribution colour",
        c("Scientific blue" = "#3B82B8", "Forest green" = "#4D927B", "Warm orange" = "#D98252"), "#3B82B8"),
      shiny::selectInput(id("shared_colour"), "Shared-contribution colour",
        c("Light blue" = "#9CC9DF", "Light green" = "#A7D7C5", "Light orange" = "#F1BE9B"), "#9CC9DF"),
      shiny::sliderInput(id("bar_width"), "Bar width", 0.3, 1, 0.72, 0.02),
      shiny::sliderInput(id("opacity"), "Bar opacity", 0.2, 1, 0.95, 0.05),
      shiny::selectInput(id("legend_position"), "Legend position",
        c("Right" = "right", "Bottom" = "bottom", "Top" = "top", "None" = "none"), "right")),
    if (identical(plot_name, "upset")) shiny::tagList(
      shiny::selectInput(id("palette"), "Colour scheme",
        c("Nature" = "nature", "Science" = "science", "Lancet" = "lancet", "JAMA" = "jama"), "nature"),
      shiny::numericInput(id("partitions"), "Maximum interaction fractions", 30L, min = 1L, max = 100L),
      shiny::sliderInput(id("bar_width"), "Fraction-bar width", 0.2, 1, 0.6, 0.05),
      shiny::sliderInput(id("point_size"), "Matrix-point size", 1, 8, 3, 0.25),
      shiny::sliderInput(id("line_width"), "Matrix-line width", 0.1, 3, 0.5, 0.1),
      shiny::sliderInput(id("digits"), "Displayed decimals", 0, 5, 2, 1),
      shiny::checkboxInput(id("show_effect"), "Show fraction values", TRUE)),
    if (identical(plot_name, "venn")) shiny::tagList(
      shiny::selectInput(id("palette"), "Group colour scheme",
        c("Scientific" = "scientific", "Nature" = "nature", "Pastel" = "pastel"), "scientific"),
      shiny::sliderInput(id("opacity"), "Region opacity", 0.1, 1, 0.55, 0.05),
      shiny::sliderInput(id("label_size"), "Label size", 0.6, 2, 1, 0.1))
  )
}

vi_rdacca_plot_settings <- function(input, plot_name) {
  prefix <- paste0("rdacca_plot_", plot_name, "_")
  value <- function(name, default = NULL) input[[paste0(prefix, name)]] %||% default
  list(theme = value("theme", "publication"), base_size = value("base_size", 13),
    title = value("title", ""), fill_colour = value("fill_colour", "#4F86B5"),
    unique_colour = value("unique_colour", "#3B82B8"), shared_colour = value("shared_colour", "#9CC9DF"),
    bar_width = value("bar_width", 0.72), opacity = value("opacity", 0.95),
    label_size = value("label_size", 3.6), digits = value("digits", 2L),
    show_values = isTRUE(value("show_values", TRUE)),
    show_significance = isTRUE(value("show_significance", TRUE)),
    show_legend = !identical(value("legend_position", "right"), "none"),
    legend_position = value("legend_position", "right"), palette = value("palette", "nature"),
    partitions = value("partitions", 30L), point_size = value("point_size", 3),
    line_width = value("line_width", 0.5), show_effect = isTRUE(value("show_effect", TRUE)))
}

vi_rdacca_result_plot <- function(result, plot_name, settings) {
  hp <- result$objects$hp
  hierarchy <- result$tables$hierarchical_partitioning
  if (identical(plot_name, "publication_individual")) return(vi_rdacca_individual_plot(
    hierarchy, "Independent contribution", FALSE, 0.05, settings))
  if (identical(plot_name, "individual_shared")) return(vi_rdacca_individual_plot(
    hierarchy, "Unique and shared contributions", TRUE, 0.05, settings))
  if (identical(plot_name, "upset")) {
    vp <- result$objects$vp %||% hp
    variation <- if (inherits(vp, "glmmhp")) vi_glmm_hp_matrix(vp, TRUE) else hp$Var.part
    hierarchy_matrix <- if (inherits(hp, "glmmhp")) vi_glmm_hp_matrix(hp, FALSE) else hp$Hier.part
    return(suppressWarnings(upset.hp::upset.hp(variation, hierarchy_matrix,
      nVar = min(as.integer(settings$partitions), max(1L, nrow(variation) - 1L)),
      col.width = settings$bar_width, pch.size = settings$point_size,
      line.lwd = settings$line_width, show.effect = settings$show_effect,
      col = settings$palette, digits = as.integer(settings$digits))))
  }
  if (identical(plot_name, "venn") && !is.null(result$objects$varpart)) {
    palettes <- list(scientific = c("#4F86B5", "#D98252", "#59A14F", "#AF7AA1"),
      nature = c("#3B8C88", "#E0A458", "#78A55A", "#B36A6A"),
      pastel = c("#9ECAE1", "#FDD0A2", "#A1D99B", "#DADAEB"))
    colours <- grDevices::adjustcolor(palettes[[settings$palette]] %||% palettes$scientific,
      alpha.f = settings$opacity)
    return(function() plot(result$objects$varpart, bg = colours,
      Xnames = names(result$objects$explanatory), cex = settings$label_size))
  }
  plot_hp <- hp
  if (inherits(plot_hp, "rdaccahp")) plot_hp$Var.part <- NULL
  plot <- suppressWarnings(if (identical(plot_name, "package_percentage"))
    plot(plot_hp, plot.perc = TRUE) else plot(plot_hp))
  if (inherits(plot, "ggplot")) {
    if (length(plot$layers)) plot$layers[[1]]$aes_params$fill <- settings$fill_colour
    plot <- vi_apply_plot_theme(plot, settings$theme, settings$base_size, "none", FALSE, FALSE)
    if (nzchar(trimws(settings$title))) plot <- plot + ggplot2::labs(title = trimws(settings$title))
  }
  plot
}

vi_apply_result_plot_settings <- function(plot, settings, allow_discrete_palette = TRUE) {
  if (isTRUE(allow_discrete_palette)) return(dava_apply_result_plot_settings(plot, settings))
  if (is.null(plot) || !inherits(plot, "ggplot")) return(plot)
  plot <- if (exists("dava_plot_theme", mode = "function")) {
    dava_plot_theme(plot, settings$theme %||% "publication", settings$base_size %||% 14,
      settings$legend_position %||% "right", FALSE, isTRUE(settings$show_legend))
  } else {
    plot + ggplot2::theme_bw(base_size = settings$base_size %||% 14) +
      ggplot2::theme(legend.position = if (isTRUE(settings$show_legend))
        settings$legend_position %||% "right" else "none")
  }
  plot <- plot +
    ggplot2::theme(axis.text.x = ggplot2::element_text(
      angle = settings$x_angle %||% 0,
      hjust = if ((settings$x_angle %||% 0) == 0) 0.5 else 1
    ))
  if (nzchar(trimws(settings$title %||% ""))) plot <- plot + ggplot2::labs(title = trimws(settings$title))
  if (isTRUE(settings$flip)) plot <- plot + ggplot2::coord_flip()
  plot
}

vi_preprocess_controls <- function(ns, method, settings) {
  shiny::tagList(
    shiny::selectInput(ns("prep_missing"), "Missing value handling", c("Complete sample" = "complete", "Median/mode interpolation" = "median"), settings$missing),
    shiny::checkboxInput(ns("prep_remove_zero"), "Remove zero variance variables", settings$remove_zero_variance),
    shiny::checkboxInput(ns("prep_standardize"), "Standardized numerical explanatory variable", settings$standardize),
    shiny::selectInput(ns("prep_predictor_transform"), "Explanatory variable transformation", c("No transformation" = "none", "log1p after translation" = "log1p"), settings$predictor_transform),
    if (method %in% c("varpart", "rdacca_hp")) shiny::selectInput(ns("prep_response_transform"), "Response matrix transformation",
      c("Hellinger (recommended community data)" = "hellinger", "No transformation" = "none"), settings$response_transform),
    shiny::sliderInput(ns("prep_correlation_cutoff"), "High correlation alert threshold", min = 0.7, max = 0.999,
      value = settings$correlation_cutoff, step = 0.01)
  )
}

mod_variable_importance_ui <- function(id) {
  ns <- shiny::NS(id)
  bslib::page_fillable(
    shiny::tags$style(shiny::HTML(".vi-sidebar .stat-box{border-bottom:1px solid #dce3e7;padding:8px 2px}.vi-sidebar .btn{margin-top:4px}.vi-status{font-size:12px;padding:6px;background:#f4f7f8;border:1px solid #dce3e7}.vi-result-table .dataTables_wrapper{font-size:12px}.vi-variable-group-list{margin:8px 0;display:grid;gap:5px}.vi-variable-group-row{padding:6px 7px;border:1px solid #dce3e7;background:#f8fafb;border-radius:4px}.vi-variable-group-row b{display:block;color:#243746}.vi-variable-group-row span{font-size:12px;color:#596a73;overflow-wrap:anywhere}")),
    bslib::layout_sidebar(
      sidebar = bslib::sidebar(width = 330, class = "vi-sidebar",
        shiny::div(class = "stat-box", shiny::strong("Importance method"),
          shiny::selectInput(ns("importance_method"), NULL, choices = vi_method_choices(), selected = "relaimpo"),
          shiny::uiOutput(ns("method_description"))),
        shiny::div(class = "stat-box", shiny::strong("Data source"),
          shiny::selectInput(ns("dataset"), "data set", choices = c("Method-specific simulation data" = "__demo__")),
          shiny::uiOutput(ns("data_summary"))),
        shiny::div(class = "stat-box", shiny::strong("Variable settings"), shiny::uiOutput(ns("method_controls")),
          shiny::uiOutput(ns("variable_group_controls"))),
        shiny::uiOutput(ns("model_settings_box")),
        shiny::div(class = "stat-box", shiny::strong("Analysis settings"),
          shiny::actionButton(ns("open_preprocess"), "Data preprocessing", icon = shiny::icon("filter"), class = "btn-outline-secondary w-100"),
          shiny::actionButton(ns("open_advanced"), "Advanced parameters", icon = shiny::icon("sliders"), class = "btn-outline-secondary w-100"),
          dava_dependency_button_ui(ns)),
        shiny::uiOutput(ns("dependency_status")),
        shiny::actionButton(ns("run"), "Run variable importance analysis", icon = shiny::icon("play"), class = "btn-primary w-100"),
        shiny::actionButton(ns("register_results"), "Add to data table repository", icon = shiny::icon("plus"),
          title = "Add to data table repository", class = "btn-success w-100 mt-2"),
        shiny::downloadButton(ns("download_results"), "Download analysis results table", icon = shiny::icon("download"), class = "btn-success w-100")),
      bslib::navset_card_tab(
        bslib::nav_panel("Data", bslib::navset_card_tab(
          bslib::nav_panel("Raw data", DT::DTOutput(ns("raw_data"))),
          bslib::nav_panel("Model data", DT::DTOutput(ns("model_data"))))),
        bslib::nav_panel("Data Suitability", DT::DTOutput(ns("suitability"))),
        bslib::nav_panel("Results", shiny::uiOutput(ns("result_selector")), DT::DTOutput(ns("result_table"))),
        bslib::nav_panel("Model text", shiny::verbatimTextOutput(ns("model_text"))),
        bslib::nav_panel("Plots", shiny::uiOutput(ns("plot_panel"))),
        bslib::nav_panel("R Markdown code document", dava_module_code_panel_ui(ns)),
        bslib::nav_panel("Warnings and Errors", shiny::verbatimTextOutput(ns("messages")))
      )
    )
  )
}

mod_variable_importance_server <- function(id, file_data) {
  shiny::moduleServer(id, function(input, output, session) {
    root_input <- session$rootScope()$input
    interface_language <- shiny::reactive({
      root_input$dava_interface_language
      dava_i18n_language(root_input$dava_interface_language)
    })
    states <- shiny::reactiveVal(stats::setNames(lapply(VI_METHOD_IDS, vi_state_template), VI_METHOD_IDS))
    method <- shiny::reactive(input$importance_method %||% "relaimpo")
    current_state <- shiny::reactive(states()[[method()]])
    update_state <- function(values) {
      all_states <- states(); all_states[[method()]] <- utils::modifyList(all_states[[method()]], values)
      states(all_states); invisible(all_states[[method()]])
    }
    raw_data <- shiny::reactive({
      selected <- input$dataset %||% "__demo__"
      if (identical(selected, "__demo__")) return(vi_demo_data(method()))
      shiny::validate(shiny::need(selected %in% dava_global_dataset_names(file_data), "The selected data set does not exist."))
      as.data.frame(file_data$global_datasets[[selected]], stringsAsFactors = FALSE, check.names = FALSE)
    })
    shiny::observe({
      names_value <- dava_global_dataset_names(file_data)
      selected <- shiny::isolate(input$dataset %||% "__demo__")
      shiny::updateSelectInput(session, "dataset", choices = c("Method-specific simulation data" = "__demo__", names_value),
        selected = if (selected %in% c("__demo__", names_value)) selected else "__demo__")
    })
    output$method_description <- shiny::renderUI({
      info <- vi_method_info(method())
      shiny::div(class = "vi-status", shiny::div(info$scenario), shiny::div("Response:", info$response))
    })
    output$data_summary <- shiny::renderUI({
      data <- raw_data(); shiny::div(class = "small text-muted", sprintf("%d rows × %d columns; %d numerical variables", nrow(data), ncol(data), sum(vapply(data, is.numeric, logical(1)))))
    })
    output$method_controls <- shiny::renderUI(vi_sidebar_controls(session$ns, method(), raw_data(), current_state()))
    output$variable_group_controls <- shiny::renderUI({
      predictors <- input$predictors %||% current_state()$predictors %||% character()
      vi_variable_group_controls(session$ns, predictors, current_state(),
        input$variable_group_enabled %||% current_state()$grouping_enabled)
    })
    active_variable_groups <- shiny::reactive({
      predictors <- input$predictors %||% current_state()$predictors %||% character()
      vi_clean_variable_groups(current_state()$variable_groups, predictors)
    })
    active_model <- shiny::reactive({
      value <- current_state()$model
      choices <- unname(vi_model_choices(method()))
      if (length(choices)) value$type <- if ((input$model_type %||% value$type) %in% choices) input$model_type %||% value$type else choices[1]
      if (value$type %in% c("glm", "glmer", "glmmTMB")) {
        allowed_families <- unname(vi_model_family_choices(value$type))
        value$family <- if ((input$model_family %||% value$family) %in% allowed_families)
          input$model_family %||% value$family else allowed_families[1]
      }
      if (value$type %in% c("lmer", "glmer", "glmmTMB")) {
        value$random_structure <- input$random_structure %||% value$random_structure %||% "intercept"
        value$random_group <- input$random_group %||% value$random_group %||% ""
        value$random_slope <- input$random_slope %||% value$random_slope %||% ""
      }
      value
    })
    vi_dependency_packages <- shiny::reactive({
      unique(c("stats", "ggplot2", "dplyr", "broom", "patchwork", "writexl",
        vi_required_packages(method(), active_model())))
    })
    dava_bind_dependency_checker(
      input, session, packages = vi_dependency_packages,
      method_label = function() vi_method_info(method())$label[[1]] %||% method())
    output$model_settings_box <- shiny::renderUI({
      if (!length(vi_model_choices(method()))) return(NULL)
      data <- raw_data()
      predictors <- intersect(input$predictors %||% character(), names(data))
      if (!length(predictors)) predictors <- intersect(current_state()$predictors %||% character(), names(data))
      response <- input$response %||% ""
      if (!response %in% names(data)) response <- current_state()$response %||% ""
      if (!response %in% names(data)) response <- names(data)[1] %||% "response"
      shiny::div(class = "stat-box", shiny::strong("Model settings"),
        vi_model_controls(session$ns, method(), data, active_model(), predictors),
        shiny::div(class = "small text-muted mt-2", "Model formula"),
        shiny::tags$pre(class = "vi-formula-preview",
          if (identical(method(), "rf")) sprintf("rf_permutation <- rfPermute::rfPermute(%s, data = model_data, importance = TRUE)",
            paste(deparse(vi_model_formula(response, predictors, active_model()), width.cutoff = 500L), collapse = ""))
          else if (identical(method(), "rdacca_hp")) vi_rdacca_formula_preview(response,
            input$responses %||% current_state()$responses, predictors, active_model(), current_state()$advanced)
          else vi_model_formula_text(response, predictors, active_model())))
    })
    output$dependency_status <- shiny::renderUI({
      status <- vi_dependency_status(method(), active_model())
      shiny::div(class = "vi-status mt-2", paste0(status$package, ifelse(status$installed, " ✓", " is missing"), collapse = " · "))
    })
    shiny::observeEvent(input$response, {
      update_state(list(response = input$response %||% current_state()$response))
    }, ignoreInit = TRUE)
    shiny::observeEvent(list(input$responses, input$responses_open), {
      if (isTRUE(input$responses_open)) return()
      update_state(list(responses = input$responses %||% current_state()$responses))
    }, ignoreInit = TRUE)
    shiny::observeEvent(list(input$predictors, input$predictors_open), {
      if (isTRUE(input$predictors_open)) return()
      update_state(list(predictors = input$predictors %||% current_state()$predictors))
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$variable_group_enabled, {
      enabled <- isTRUE(input$variable_group_enabled)
      if (!identical(enabled, isTRUE(current_state()$grouping_enabled))) {
        update_state(list(grouping_enabled = enabled))
      }
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$add_variable_group, {
      group_name <- trimws(input$variable_group_name %||% "")
      variables <- input$variable_group_variables %||% character()
      if (!nzchar(group_name)) {
        return(shiny::showNotification("Please enter a group name.", type = "warning"))
      }
      groups <- active_variable_groups()
      if (group_name %in% names(groups)) {
        return(shiny::showNotification("Group name already exists, please use another name.", type = "warning"))
      }
      available <- setdiff(input$predictors %||% current_state()$predictors %||% character(),
        vi_grouped_variables(groups))
      variables <- intersect(variables, available)
      if (!length(variables)) {
        return(shiny::showNotification("Please select at least one variable that is not yet grouped.", type = "warning"))
      }
      groups[[group_name]] <- variables
      all_states <- states()
      all_states[[method()]]$variable_groups <- groups
      all_states[[method()]]$grouping_enabled <- TRUE
      states(all_states)
      shiny::updateTextInput(session, "variable_group_name", value = "")
      shiny::showNotification(sprintf("Variable group '%s' has been added.", group_name), type = "message")
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$remove_variable_group, {
      group_name <- input$remove_variable_group_name %||% ""
      groups <- active_variable_groups()
      if (!nzchar(group_name) || !group_name %in% names(groups)) return()
      groups[[group_name]] <- NULL
      all_states <- states()
      all_states[[method()]]$variable_groups <- groups
      states(all_states)
      shiny::showNotification(sprintf("Variable group '%s' has been deleted.", group_name), type = "message")
    }, ignoreInit = TRUE)
    shiny::observeEvent(list(input$model_type, input$model_family, input$random_structure, input$random_group, input$random_slope), {
      model_value <- active_model()
      advanced_value <- current_state()$advanced
      if (method() == "dominance") {
        allowed_metrics <- unname(vi_dominance_metric_choices(model_value$type))
        if (!advanced_value$fit_metric %in% allowed_metrics) advanced_value$fit_metric <- allowed_metrics[1]
      }
      update_state(list(model = model_value, advanced = advanced_value, result = NULL))
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$open_preprocess, {
      shiny::showModal(shiny::modalDialog(title = paste0(vi_method_info(method())$label, ": Data preprocessing"),
        size = "l", vi_preprocess_controls(session$ns, method(), current_state()$preprocess),
        footer = shiny::tagList(shiny::modalButton("Cancel"), shiny::actionButton(session$ns("save_preprocess"), "Apply preprocessing", class = "btn-primary"))))
    })
    shiny::observeEvent(input$save_preprocess, {
      settings <- list(missing = input$prep_missing %||% "complete", remove_zero_variance = isTRUE(input$prep_remove_zero),
        standardize = isTRUE(input$prep_standardize), predictor_transform = input$prep_predictor_transform %||% "none",
        response_transform = input$prep_response_transform %||% "none", correlation_cutoff = input$prep_correlation_cutoff %||% 0.95)
      update_state(list(preprocess = settings, result = NULL)); shiny::removeModal()
    })
    shiny::observeEvent(input$open_advanced, {
      numeric_names <- names(raw_data())[vapply(raw_data(), is.numeric, logical(1))]
      shiny::showModal(shiny::modalDialog(title = paste0(vi_method_info(method())$label, ": Advanced parameters"), size = "l",
        vi_advanced_controls(session$ns, method(), current_state()$advanced, numeric_names, active_model()),
        footer = shiny::tagList(shiny::modalButton("Cancel"), shiny::actionButton(session$ns("save_advanced"), "Save advanced parameters", class = "btn-primary"))))
    })
    shiny::observeEvent(input$save_advanced, {
      old <- current_state()$advanced
      settings <- switch(method(),
        relaimpo = list(metrics = input$adv_metrics %||% "lmg", relative = isTRUE(input$adv_relative), bootstrap = isTRUE(input$adv_bootstrap),
          bootstrap_reps = input$adv_bootstrap_reps %||% 500L, confidence = input$adv_confidence %||% 0.95, seed = input$adv_seed %||% 2026L),
        dominance = list(fit_metric = input$adv_fit_metric %||% "r2", max_predictors = input$adv_max_predictors %||% 12L, seed = input$adv_seed %||% 2026L),
        mumin = list(rank = input$adv_rank %||% old$rank %||% "AICc",
          selection_rule = input$adv_selection_rule %||% old$selection_rule %||% "delta",
          delta = input$adv_delta %||% old$delta %||% 4,
          cumulative_weight = input$adv_cumulative_weight %||% old$cumulative_weight %||% 0.95,
          averaging = input$adv_averaging %||% old$averaging %||% "full",
          beta = input$adv_beta %||% old$beta %||% "sd",
          confidence = input$adv_confidence %||% old$confidence %||% 0.95,
          revised_variance = isTRUE(input$adv_revised_variance), include_null = isTRUE(input$adv_include_null),
          max_predictors = input$adv_max_predictors %||% old$max_predictors %||% 10L,
          seed = input$adv_seed %||% old$seed %||% 2026L),
        rf = list(trees = input$adv_trees %||% old$trees %||% 500L,
          permutations = input$adv_permutations %||% old$permutations %||% 1000L,
          cores = input$adv_cores %||% old$cores %||% 6L,
          mtry = input$adv_mtry %||% old$mtry %||% 0L,
          nodesize = input$adv_nodesize %||% old$nodesize %||% 5L,
          scale_importance = isTRUE(input$adv_scale_importance),
          alpha = input$adv_alpha %||% old$alpha %||% 0.05,
          a3_enabled = isTRUE(input$adv_a3_enabled),
          a3_p_acc = as.numeric(input$adv_a3_p_acc %||% old$a3_p_acc %||% 0.01),
          a3_folds = input$adv_a3_folds %||% old$a3_folds %||% 5L,
          seed = input$adv_seed %||% old$seed %||% 2026L),
        shap = list(model = active_model()$type, trees = input$adv_trees %||% old$trees %||% 800L,
          nrounds = input$adv_nrounds %||% old$nrounds %||% 300L,
          max_depth = input$adv_max_depth %||% old$max_depth %||% 3L,
          eta = input$adv_eta %||% old$eta %||% 0.05,
          lambda = input$adv_lambda %||% old$lambda %||% 1,
          alpha = input$adv_alpha %||% old$alpha %||% 0.1,
          subsample = input$adv_subsample %||% old$subsample %||% 0.8,
          colsample_bytree = input$adv_colsample %||% old$colsample_bytree %||% 0.8,
          nfold = input$adv_nfold %||% old$nfold %||% 5L,
          early_stopping_rounds = input$adv_early_stopping %||% old$early_stopping_rounds %||% 20L,
          explain_rows = input$adv_explain_rows %||% old$explain_rows %||% 20L,
          sample_size = input$adv_sample_size %||% old$sample_size %||% 100L,
          seed = input$adv_seed %||% 2026L),
        varpart = list(permutations = input$adv_permutations %||% 999L, groups = as.integer(input$adv_groups %||% 2L),
          group_variables = lapply(seq_len(4L), function(index) input[[paste0("adv_group_", index)]] %||% character()),
          adjusted = isTRUE(input$adv_adjusted), seed = input$adv_seed %||% 2026L),
        rdacca_hp = list(type = input$adv_type %||% old$type %||% "adjR2",
          permutations = input$adv_permutations %||% old$permutations %||% 999L,
          var_part = isTRUE(input$adv_var_part), scale = isTRUE(input$adv_scale),
          predictor_mode = input$adv_predictor_mode %||% old$predictor_mode %||% "variables",
          groups = as.integer(input$adv_groups %||% old$groups %||% 2L),
          group_variables = lapply(seq_len(4L), function(index)
            input[[paste0("adv_group_", index)]] %||% vi_list_get(old$group_variables, index)),
          distance = input$adv_distance %||% old$distance %||% "bray",
          dbrda_engine = input$adv_dbrda_engine %||% old$dbrda_engine %||% "dbrda",
          binary_jaccard = isTRUE(input$adv_binary_jaccard),
          add = input$adv_add %||% old$add %||% "lingoes", sqrt_dist = isTRUE(input$adv_sqrt_dist),
          aitchison_pseudocount = input$adv_aitchison_pseudocount %||% old$aitchison_pseudocount %||% 0.5,
          commonality = isTRUE(input$adv_commonality),
          significance_alpha = input$adv_significance_alpha %||% old$significance_alpha %||% 0.05,
          seed = input$adv_seed %||% old$seed %||% 2026L))
      update_state(list(advanced = settings, result = NULL)); shiny::removeModal()
    })
    analysis_code <- shiny::reactive(vi_analysis_code(method(), input$dataset %||% "__demo__",
      input$response %||% current_state()$response, input$responses %||% current_state()$responses,
      input$predictors %||% current_state()$predictors, current_state()$preprocess, current_state()$advanced,
      active_model(), workspace_data = TRUE))
    dava_module_code_panel_server(input, output, session, file_data,
      source_prefix = function() paste("variable_importance", method(), sep = "/"),
      default_code = function() analysis_code(), source = "Statistical analysis", title = "Variable importance R Markdown code document",
      kind = "analysis",
      plot_params = function() vi_code_plot_params(input, method()),
      data = function() raw_data(),
      dataset_name = function() input$dataset %||% "__demo__",
      function_mode = "none",
      standalone_bootstrap = FALSE,
      include_input_snapshot = FALSE,
      preview_result = function() result(),
      preview_plots = function() list("Current result figure" = current_display_plot()))
    shiny::observeEvent(input$run, {
      response <- input$response %||% current_state()$response
      responses <- input$responses %||% current_state()$responses
      predictors <- input$predictors %||% current_state()$predictors
      method_key <- paste("variable_importance", method(), sep = "/")
      custom <- dava_method_code_effective(
        original = function() NULL,
        file_data = file_data,
        method_key = method_key,
        adapter = function(run, entry) {
          current_run <- dava_method_code_execute(file_data, method_key,
            data = raw_data(), dataset_name = input$dataset %||% "__demo__",
            spec = dava_code_analysis_spec_from_input(input))
          dava_vi_custom_result(
            current_run, raw_data(), method(), entry$custom_code)
        },
        on_error = function(message) {
          shiny::showNotification(paste0(
            "User-defined variable importance method failed, original method has been run:",
            message), type = "error", duration = 6)
          NULL
        }
      )
      if (!is.null(custom)) {
        entry <- dava_method_code_get(file_data, method_key)
        update_state(list(error = "", result = custom,
          response = response, responses = responses,
          predictors = predictors, model = active_model(),
          code = entry$custom_code %||% analysis_code()))
        return()
      }
      value <- tryCatch(dava_with_progress(message = paste("Run", vi_method_info(method())$label), value = 0, {
        dava_inc_progress(0.15, detail = "Check and preprocess data")
        result <- vi_fit_method(raw_data(), method(), response, responses, predictors,
          current_state()$preprocess, current_state()$advanced, active_model())
        dava_inc_progress(0.75, detail = "Organize results and graphics")
        result$code <- analysis_code()
        dava_inc_progress(0.10, detail = "\u5206\u6790\u5b8c\u6210")
        result
      }), error = function(error) error)
      if (inherits(value, "error")) update_state(list(error = conditionMessage(value), result = NULL))
      else update_state(list(error = "", result = value, response = response, responses = responses,
        predictors = predictors, model = active_model(), code = analysis_code()))
    })
    result <- shiny::reactive(current_state()$result)
    output$raw_data <- DT::renderDT(DT::datatable(raw_data(), rownames = FALSE, filter = "top", options = list(scrollX = TRUE, pageLength = 15)))
    output$model_data <- DT::renderDT({ shiny::req(result()); DT::datatable(result()$prepared_data, rownames = FALSE, filter = "top", options = list(scrollX = TRUE, pageLength = 15)) })
    output$suitability <- DT::renderDT({
      responses <- if (method() %in% c("varpart", "rdacca_hp")) input$responses %||% current_state()$responses else input$response %||% current_state()$response
      DT::datatable(vi_suitability(raw_data(), method(), responses, input$predictors %||% current_state()$predictors,
        current_state()$preprocess$correlation_cutoff), rownames = FALSE, options = list(dom = "t", scrollX = TRUE))
    })
    output$result_selector <- shiny::renderUI({ shiny::req(result());
      shiny::selectInput(session$ns("result_name"), "Results table", choices = names(result()$tables), selected = names(result()$tables)[1]) })
    output$result_table <- DT::renderDT({ shiny::req(result()); name <- input$result_name %||% names(result()$tables)[1]
      DT::datatable(result()$tables[[name]], rownames = FALSE, filter = "top", class = "compact stripe hover",
        options = list(scrollX = TRUE, pageLength = 15, autoWidth = TRUE)) })
    shiny::observeEvent(input$register_results, {
      selected_dataset <- shiny::isolate(input$dataset_select_input %||% "__demo__")
      value <- result(); shiny::req(value, value$tables)
      registered <- dava_register_global_datasets(file_data, value$tables,
        source = paste("Statistical analysis /", vi_method_info(method())$label), prefix = "variable_importance")
      shiny::showNotification(paste0("has been added to the data table warehouse:", paste(unname(registered), collapse = "、")), type = "message", duration = 3)
      shiny::updateSelectInput(session, "dataset_select_input", selected = selected_dataset)
    })
    output$model_text <- shiny::renderText({
      text <- if (is.null(result())) "The current method has not been run yet." else result()$text
      dava_localize_model_text(
        text, interface_language(), dava_user_data_text(raw_data())
      )
    })
    output$plot_panel <- shiny::renderUI({
      if (identical(method(), "shap")) {
        return(bslib::layout_sidebar(
          sidebar = bslib::sidebar(
            width = 290, position = "right",
            dava_plot_action_buttons_ui(session$ns),
            vi_shap_plot_settings_ui(session$ns)
          ),
          shiny::selectInput(session$ns("shap_result_plot"), "Result graph", choices = c(
            "SHAP global feature contribution map" = "beeswarm",
            "Interaction heat map + feature importance" = "correlation",
            "SHAP interaction strength network diagram" = "network",
            "Single feature SHAP dependency graph" = "dependence"), selected = "beeswarm"),
          dava_plot_size_ui(session$ns, "plot_shap_selected", "vi_shap_plot_size", width = 900, height = 720)))
      }
      bslib::layout_sidebar(
        sidebar = bslib::sidebar(
          width = 300, position = "right",
          dava_plot_action_buttons_ui(session$ns),
          shiny::uiOutput(session$ns("result_plot_settings"))
        ),
        shiny::tagList(shiny::uiOutput(session$ns("result_plot_selector")),
          dava_plot_size_ui(session$ns, "plot_result_selected", "vi_result_plot_size", width = 900, height = 680))
      )
    })
    shap_plot_settings <- shiny::reactive({
      settings <- vi_code_plot_params(input, "shap")
      settings$plot <- NULL
      settings
    })
    current_shap_plot <- shiny::reactive({
      shiny::req(result(), identical(method(), "shap"))
      plot <- vi_shap_plot(result(), input$shap_result_plot %||% "beeswarm", shap_plot_settings())
      shiny::validate(shiny::need(!is.null(plot), "The current model has no data available for this results plot."))
      dava_plot_english_labels(plot)
    })
    output$plot_shap_selected <- shiny::renderPlot({
      print(current_shap_plot())
    }, res = 110)
    output$result_plot_selector <- shiny::renderUI({
      shiny::req(result(), !identical(method(), "shap"))
      plots <- result()$plots %||% list()
      shiny::validate(shiny::need(length(plots), "There is no result plot to display for the current method."))
      shiny::selectInput(session$ns("result_plot_name"), "Result graph",
        choices = vi_result_plot_choices(method(), plots))
    })
    output$result_plot_settings <- shiny::renderUI({
      shiny::req(result(), !identical(method(), "shap"))
      plot_names <- names(result()$plots %||% list())
      selector_id <- session$ns("result_plot_name")
      shiny::tagList(lapply(plot_names, function(plot_name) {
        condition_name <- gsub("'", "\\\\'", plot_name, fixed = TRUE)
        plot <- result()$plots[[plot_name]]
        if (is.function(plot)) plot <- NULL
        settings_ui <- if (identical(method(), "rf") && identical(plot_name, "permutation_importance")) {
          vi_rf_plot_settings_ui(session$ns)
        } else if (identical(method(), "rdacca_hp")) {
          vi_rdacca_plot_settings_ui(session$ns, plot_name)
        } else if (dava_is_composite_plot(plot)) {
          dava_composite_plot_settings_ui(session$ns, plot,
            vi_result_plot_settings_prefix(plot_name))
        } else {
          dava_result_plot_settings_ui(session$ns, vi_result_plot_settings_prefix(plot_name),
            paste0(
              dava_translate_text("Plot properties:", interface_language()),
              dava_translate_composed(plot_name, interface_language())
            ),
            include_palette = !(identical(method(), "mumin") && identical(plot_name, "model_weights")))
        }
        shiny::conditionalPanel(
          condition = sprintf("input['%s'] === '%s'", selector_id, condition_name),
          settings_ui
        )
      }))
    })
    current_result_plot <- shiny::reactive({
      shiny::req(result(), !identical(method(), "shap"))
      plots <- result()$plots %||% list()
      name <- input$result_plot_name %||% names(plots)[1]
      shiny::validate(shiny::need(name %in% names(plots), "Please select a valid result graph."))
      plot <- plots[[name]]
      plot <- if (is.function(plot)) plot() else plot
      groups <- if (isTRUE(input$variable_group_enabled %||% current_state()$grouping_enabled)) active_variable_groups() else list()
      if (identical(name, "importance") && length(groups) && is.data.frame(result()$primary)) {
        plot <- vi_importance_plot(result()$primary, vi_importance_plot_title(method()), groups = groups)
      }
      if (identical(name, "importance_coefficients")) {
        plot <- vi_importance_coefficient_plot(result()$primary, result()$model, groups = groups)
      }
      if (identical(method(), "mumin") && identical(name, "figure4a")) {
        plot <- vi_mumin_inference_plot(result()$tables$model_averaged_coefficients,
          result()$tables$variable_importance, groups = groups,
          metadata = result()$objects$metadata %||% list())
      }
      custom_rf_plot <- identical(method(), "rf") && identical(name, "permutation_importance")
      if (custom_rf_plot) {
        plot <- vi_rf_importance_plot(result()$tables$permutation_significance,
          result()$tables$overall_model_significance, vi_rf_plot_settings(input))
      }
      custom_rdacca_plot <- identical(method(), "rdacca_hp")
      if (custom_rdacca_plot) {
        plot <- vi_rdacca_result_plot(result(), name, vi_rdacca_plot_settings(input, name))
      }
      settings <- dava_result_plot_settings(input, vi_result_plot_settings_prefix(name))
      plot <- if (custom_rf_plot || custom_rdacca_plot) {
        plot
      } else if (dava_is_composite_plot(plot)) {
        dava_apply_composite_plot_settings(plot, input, vi_result_plot_settings_prefix(name))
      } else {
        vi_apply_result_plot_settings(plot, settings,
          allow_discrete_palette = !(identical(method(), "mumin") && identical(name, "model_weights")))
      }
      if (is.function(plot)) return(plot)
      dava_plot_english_labels(plot)
    })
    output$plot_result_selected <- shiny::renderPlot({
      plot <- current_result_plot()
      if (is.function(plot)) plot() else print(plot)
    }, res = 110)

    vi_shap_plot_dimensions <- dava_plot_size_server(
      input, output, session, "plot_shap_selected", "vi_shap_plot_size", 900, 720
    )
    vi_result_plot_dimensions <- dava_plot_size_server(
      input, output, session, "plot_result_selected", "vi_result_plot_size", 900, 680
    )
    vi_plot_dimensions <- shiny::reactive({
      if (identical(method(), "shap")) vi_shap_plot_dimensions() else vi_result_plot_dimensions()
    })
    current_display_plot <- shiny::reactive({
      if (identical(method(), "shap")) current_shap_plot() else current_result_plot()
    })
    shiny::observeEvent(input$add_plot_to_library, {
      plot <- current_display_plot()
      shiny::validate(shiny::need(!is.function(plot), "The current package's built-in basic graphics do not currently support adding layout beautification libraries."))
      dims <- vi_plot_dimensions()
      plot_name <- if (identical(method(), "shap")) input$shap_result_plot %||% "beeswarm" else input$result_plot_name %||% "result"
      ok <- dava_plot_register(
        file_data, paste("variable_importance", method(), plot_name, sep = "/"), plot,
        source = "Variable importance analysis", title = paste(method(), plot_name),
        meta = list(module = "variable_importance", method = method(), plot_name = plot_name, added_by = "manual"),
        params = c(list(width_px = dims$width_px, height_px = dims$height_px), dava_plot_input_params(input)),
        editor_svg = dava_plot_editor_svg_sized(plot, dims)
      )
      shiny::showNotification(
        if (isTRUE(ok)) "The current result graph has been added to the layout beautification library." else "Add failed: The current drawing is not a registrable object.",
        type = if (isTRUE(ok)) "message" else "error", duration = 3
      )
    })
    save_vi_plot <- function(file, device) {
      plot <- current_display_plot()
      dims <- vi_plot_dimensions()
      if (!is.function(plot)) return(dava_save_sized_plot(file, plot, device, dims, 300))
      if (identical(device, "png")) {
        dava_open_png_device(
          file, width = dims$width_px, height = dims$height_px, res = 96)
      } else {
        dava_open_pdf_device(
          file, width = dims$width_in, height = dims$height_in)
      }
      on.exit(grDevices::dev.off(), add = TRUE)
      plot()
      invisible(file)
    }
    output$download_plot_png <- shiny::downloadHandler(
      filename = function() sprintf("variable_importance_%s_%s.png", method(), Sys.Date()),
      content = function(file) save_vi_plot(file, "png")
    )
    output$download_plot_pdf <- shiny::downloadHandler(
      filename = function() sprintf("variable_importance_%s_%s.pdf", method(), Sys.Date()),
      content = function(file) save_vi_plot(file, "pdf")
    )
    output$generated_code <- shiny::renderText(analysis_code())
    output$messages <- shiny::renderText(dava_localize_model_text(
      current_state()$error %||% "", interface_language(),
      dava_user_data_text(raw_data())
    ))
    output$download_results <- shiny::downloadHandler(filename = function() paste0("variable_importance_", method(), "_", Sys.Date(), ".xlsx"),
      content = function(file) { shiny::req(result()); dava_write_xlsx(c(result()$tables,
        list(generated_code = data.frame(code = strsplit(result()$code, "\n", fixed = TRUE)[[1]]))), file) })
    invisible(list(states = states, current_state = current_state, raw_data = raw_data, result = result, analysis_code = analysis_code))
  })
}
