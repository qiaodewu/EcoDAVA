VI_METHOD_IDS <- c("relaimpo", "dominance", "mumin", "rf", "shap", "varpart", "rdacca_hp")

vi_available_cores <- function(logical = TRUE) {
  if (exists("dava_available_cores", mode = "function")) {
    return(dava_available_cores(logical = logical))
  }
  detected <- suppressWarnings(parallel::detectCores(logical = logical))
  if (!length(detected) || !is.finite(detected[[1]]) || detected[[1]] < 1L) {
    return(1L)
  }
  as.integer(detected[[1]])
}

vi_method_registry <- function() {
  data.frame(
    id = VI_METHOD_IDS,
    label = c("Linear model contribution (relaimpo)", "Dominance Analysis", "Multi-model inference (MuMIn)",
      "Random Forest (RF)", "Shapley Value (SHAP)", "Variation decomposition (varpart)", "Hierarchical segmentation (rdacca.hp)"),
    response = c("Single continuous response", "Single continuous response", "Continuous, binary, or counting responses", "Continuous or categorical response", "Continuous or categorical response",
      "One or more continuous/community responses", "One or more continuous/community responses"),
    scenario = c("Linear model R2 relative contribution", "Complete/conditional/general dominance of relevant predictors",
      "Full subset selection, model averaging and variable weights based on information criteria",
      "Nonlinear, interactive and high-dimensional predictions", "Explain the contribution of the model to the prediction of a single sample",
      "Shared and independent explanatory rates for 2-4 explanatory variable groups", "Independent hierarchical contributions to ordering of multiple response constraints"),
    required_packages = c("relaimpo,patchwork", "dominanceanalysis,patchwork", "MuMIn,patchwork",
      "rfPermute,A3", "iml,shapviz,patchwork", "vegan", "rdacca.hp,vegan,upset.hp"),
    stringsAsFactors = FALSE
  )
}

vi_method_info <- function(method) {
  registry <- vi_method_registry()
  registry[match(method, registry$id), , drop = FALSE]
}

vi_model_registry <- function() {
  data.frame(
    method = c("relaimpo", rep("dominance", 3L), rep("mumin", 4L), rep("shap", 5L),
      rep("rdacca_hp", 7L)),
    id = c("lm", "lm", "lmer", "glm_binomial", "lm", "glm", "lmer", "glmmTMB",
      "randomForest", "lm", "lmer", "glm_binomial", "xgboost",
      "lm", "rda", "cca", "dbrda", "lmer", "glmer", "glmmTMB"),
    label = c("Linear model lm", "Linear model lm", "Linear mixed effects model lmer", "Binomial distribution generalized linear model glm",
      "Linear model lm", "Generalized linear model glm", "Linear mixed effects model lmer", "Generalized linear mixed model glmmTMB",
      "Random Forest randomForest", "Linear model lm", "Linear mixed effects model lmer", "Binomial distribution generalized linear model glm",
      "Extreme gradient boosting model XGBoost", "Single response multiple linear regression lm", "Multiple response redundancy analysis RDA",
      "Multiple response canonical correspondence analysis CCA", "Distance constraint sorting db-RDA", "Linear mixed model lmer + glmm.hp",
      "Generalized linear mixed model glmer + glmm.hp", "Generalized linear mixed model glmmTMB + glmm.hp"),
    response = c("continuous", "continuous", "continuous", "binary", "continuous", "family", "continuous", "family",
      "any", "continuous", "continuous", "binary", "any",
      "continuous", "multivariate", "multivariate", "multivariate", "continuous", "family", "family"),
    random_effects = c(FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, TRUE, TRUE, FALSE, FALSE, TRUE, FALSE, FALSE,
      FALSE, FALSE, FALSE, FALSE, TRUE, TRUE, TRUE),
    stringsAsFactors = FALSE)
}

vi_model_choices <- function(method) {
  registry <- vi_model_registry()
  rows <- registry[registry$method == method, , drop = FALSE]
  stats::setNames(rows$id, rows$label)
}

vi_default_model <- function(method) {
  type <- switch(method, relaimpo = "lm", dominance = "lm", mumin = "lm", shap = "randomForest",
    rf = "randomForest", varpart = "varpart", rdacca_hp = "rda")
  list(type = type, family = "gaussian", random_structure = "intercept", random_group = "block", random_slope = "")
}

vi_model_capability <- function(method, model) {
  registry <- vi_model_registry()
  row <- registry[registry$method == method & registry$id == model$type, , drop = FALSE]
  if (nrow(row)) return(row[1, , drop = FALSE])
  data.frame(method = method, id = model$type, label = model$type, response = "method",
    random_effects = FALSE, stringsAsFactors = FALSE)
}

vi_quote_name <- function(value) paste0("`", gsub("`", "", value, fixed = TRUE), "`")

vi_random_effect_term <- function(model) {
  if (!model$type %in% c("lmer", "glmer", "glmmTMB")) return(character())
  group <- vi_quote_name(model$random_group %||% "Random grouping variable")
  if (identical(model$random_structure, "slope")) {
    slope <- vi_quote_name(model$random_slope %||% "Random slope variable")
    return(sprintf("(1 + %s | %s)", slope, group))
  }
  if (identical(model$random_structure, "uncorrelated_slope")) {
    slope <- vi_quote_name(model$random_slope %||% "Random slope variable")
    return(c(sprintf("(1 | %s)", group), sprintf("(0 + %s | %s)", slope, group)))
  }
  sprintf("(1 | %s)", group)
}

vi_model_family_choices <- function(model_type) {
  if (identical(model_type, "glmmTMB")) return(c("Gaussian distribution" = "gaussian", "Binomial distribution" = "binomial",
    "Poisson distribution" = "poisson", "Negative binomial distribution nbinom2" = "nbinom2"))
  if (identical(model_type, "glmer")) return(c("Binomial distribution" = "binomial", "Poisson distribution" = "poisson"))
  c("Gaussian distribution" = "gaussian", "Binomial distribution" = "binomial", "Poisson distribution" = "poisson")
}

vi_model_family <- function(model) {
  switch(model$family %||% "gaussian",
    binomial = stats::binomial(link = "logit"), poisson = stats::poisson(link = "log"),
    nbinom2 = glmmTMB::nbinom2(link = "log"), stats::gaussian(link = "identity"))
}

vi_model_family_text <- function(model) {
  switch(model$family %||% "gaussian", binomial = "binomial(link = \"logit\")",
    poisson = "poisson(link = \"log\")", nbinom2 = "glmmTMB::nbinom2(link = \"log\")",
    "gaussian(link = \"identity\")")
}

vi_model_formula <- function(response, predictors, model) {
  response <- response %||% "response variable"
  terms <- c(predictors %||% character(), vi_random_effect_term(model))
  if (!length(terms)) terms <- "1"
  stats::reformulate(terms, response = response)
}

vi_model_formula_text <- function(response, predictors, model, data_name = "model_data") {
  formula <- paste(deparse(vi_model_formula(response, predictors, model), width.cutoff = 500L), collapse = "")
  switch(model$type,
    lm = sprintf("importance_model <- lm(%s, data = %s)", formula, data_name),
    glm = sprintf("importance_model <- glm(%s, family = %s, data = %s)", formula, vi_model_family_text(model), data_name),
    lmer = sprintf("importance_model <- lme4::lmer(%s, data = %s, REML = FALSE)", formula, data_name),
    glmer = sprintf("importance_model <- lme4::glmer(%s, family = %s, data = %s)", formula, vi_model_family_text(model), data_name),
    glmmTMB = sprintf("importance_model <- glmmTMB::glmmTMB(%s, family = %s, data = %s)",
      formula, vi_model_family_text(model), data_name),
    glm_binomial = sprintf("importance_model <- glm(%s, family = binomial(link = \"logit\"), data = %s)", formula, data_name),
    randomForest = sprintf("importance_model <- randomForest::randomForest(%s, data = %s)", formula, data_name),
    xgboost = sprintf("importance_model <- xgboost::xgb.train(params = xgb_params, data = xgb_data, nrounds = xgb_nrounds)"),
    rda = "hp_result <- rdacca.hp::rdacca.hp(response_matrix, explanatory_data, method = \"RDA\")",
    cca = "hp_result <- rdacca.hp::rdacca.hp(response_matrix, explanatory_data, method = \"CCA\")",
    dbrda = "hp_result <- rdacca.hp::rdacca.hp(response_distance, explanatory_data, method = \"dbRDA\")",
    formula)
}

vi_dominance_metric_choices <- function(model_type) {
  switch(model_type,
    glm_binomial = c("Nagelkerke R²" = "r2.n", "McFadden R²" = "r2.m", "Cox-Snell R²" = "r2.cs", "Estrella R²" = "r2.e"),
    lmer = c("Nakagawa Margin R²" = "n.marg", "Nakagawa Condition R²" = "n.cond", "Raudenbush-Bryk R²" = "rb.r2.1"),
    c("R²" = "r2"))
}

vi_default_preprocess <- function(method) {
  list(missing = "complete", standardize = method %in% c("relaimpo", "dominance", "mumin", "varpart", "rdacca_hp"),
    predictor_transform = "none", response_transform = if (identical(method, "varpart")) "hellinger" else "none",
    correlation_cutoff = 0.95, remove_zero_variance = TRUE)
}

vi_default_advanced <- function(method) {
  switch(method,
    relaimpo = list(metrics = c("lmg", "last", "first", "pratt"), relative = TRUE,
      bootstrap = TRUE, bootstrap_reps = 500L, confidence = 0.95, seed = 2026L),
    dominance = list(fit_metric = "r2", max_predictors = 12L, seed = 2026L),
    mumin = list(rank = "AICc", selection_rule = "delta", delta = 4, cumulative_weight = 0.95,
      averaging = "full", beta = "sd", confidence = 0.95, revised_variance = TRUE,
      include_null = TRUE, max_predictors = 10L, seed = 2026L),
    rf = list(trees = 500L, permutations = 1000L, cores = 6L, mtry = 0L, nodesize = 5L,
      scale_importance = TRUE, alpha = 0.05, a3_enabled = TRUE, a3_p_acc = 0.01,
      a3_folds = 5L, seed = 2026L),
    shap = list(model = "randomForest", trees = 800L, nrounds = 300L, max_depth = 3L,
      eta = 0.05, lambda = 1, alpha = 0.1, subsample = 0.8, colsample_bytree = 0.8,
      nfold = 5L, early_stopping_rounds = 20L, explain_rows = 20L, sample_size = 100L, seed = 2026L),
    varpart = list(permutations = 999L, groups = 2L, group_variables = list(), adjusted = TRUE, seed = 2026L),
    rdacca_hp = list(type = "adjR2", permutations = 999L, var_part = TRUE, scale = FALSE,
      predictor_mode = "variables", groups = 2L, group_variables = list(),
      distance = "bray", dbrda_engine = "dbrda", binary_jaccard = TRUE,
      add = "lingoes", sqrt_dist = FALSE, aitchison_pseudocount = 0.5,
      commonality = TRUE, significance_alpha = 0.05, seed = 2026L),
    stop("Unknown variable-importance method.", call. = FALSE))
}

vi_demo_data_generate <- function(method, n = 180L, seed = 2026L) {
  set.seed(seed)
  climate <- stats::rnorm(n)
  soil <- 0.55 * climate + stats::rnorm(n, sd = 0.8)
  nutrient <- 0.65 * soil + stats::rnorm(n, sd = 0.65)
  moisture <- -0.35 * climate + stats::rnorm(n, sd = 0.9)
  diversity <- 0.35 * nutrient + 0.25 * moisture + stats::rnorm(n, sd = 0.8)
  treatment <- factor(sample(c("Control", "Low", "High"), n, replace = TRUE))
  block <- factor(rep(seq_len(max(3L, n %/% 18L)), length.out = n))
  block_effect <- stats::rnorm(nlevels(block), sd = 0.9)
  productivity <- 2.2 + 0.8 * soil + 0.5 * nutrient + 0.35 * diversity -
    0.45 * climate + block_effect[as.integer(block)] + stats::rnorm(n, sd = 0.8)
  base <- data.frame(productivity, climate, soil, nutrient, moisture, diversity, treatment, block)
  if (method == "relaimpo") return(base)
  if (method == "mumin") {
    trait_diversity <- as.numeric(scale(0.55 * diversity + stats::rnorm(n, sd = 0.7)))
    species_richness <- pmax(3L, stats::rpois(n, lambda = exp(2.7 - 0.18 * climate + 0.12 * moisture)))
    aridity <- as.numeric(scale(0.75 * climate - 0.45 * moisture + stats::rnorm(n, sd = 0.55)))
    soil_carbon <- as.numeric(scale(0.60 * soil + 0.25 * nutrient + stats::rnorm(n, sd = 0.65)))
    precipitation <- as.numeric(scale(-0.70 * aridity + stats::rnorm(n, sd = 0.7)))
    multifunctionality <- 0.80 * trait_diversity + 0.022 * species_richness - 0.55 * aridity +
      0.24 * soil_carbon + 0.10 * precipitation + block_effect[as.integer(block)] * 0.35 + stats::rnorm(n, sd = 0.75)
    high_multifunctionality <- factor(ifelse(multifunctionality > stats::median(multifunctionality), "High", "Low"))
    function_count <- stats::rpois(n, lambda = pmax(exp(1.5 + 0.24 * trait_diversity - 0.18 * aridity +
      0.015 * species_richness + block_effect[as.integer(block)] * 0.08), 0.05))
    return(data.frame(multifunctionality, high_multifunctionality, function_count, trait_diversity,
      species_richness, aridity, soil_carbon, precipitation, treatment, block))
  }
  if (method == "dominance") {
    base$response_class <- factor(ifelse(base$productivity > stats::median(base$productivity), "High", "Low"))
    return(base)
  }
  if (method %in% c("rf", "shap")) {
    base$productivity <- 3 + 1.2 * sin(climate) + 0.75 * soil^2 +
      0.8 * diversity * moisture + ifelse(treatment == "High", 1, 0) +
      block_effect[as.integer(block)] + stats::rnorm(n, sd = 0.7)
    base$response_class <- factor(ifelse(base$productivity > stats::median(base$productivity), "High", "Low"))
    return(base)
  }
  lambda <- function(eta) stats::rpois(n, lambda = pmax(exp(eta), 0.05))
  base$Species_A <- lambda(1.4 + 0.35 * climate + 0.30 * soil)
  base$Species_B <- lambda(1.2 - 0.25 * climate + 0.45 * moisture)
  base$Species_C <- lambda(1.0 + 0.30 * nutrient + 0.25 * diversity)
  base$Species_D <- lambda(1.1 + 0.20 * soil - 0.25 * moisture)
  base$Species_E <- lambda(0.9 + 0.35 * diversity)
  base
}

vi_demo_data <- function(method, n = 180L, seed = 2026L) {
  method <- match.arg(method, c("relaimpo", "mumin", "dominance", "rf", "shap", "varpart", "rdacca_hp"))
  value <- dava_local_demo_read(file.path("variable_importance", paste0(method, ".rds")))
  value[seq_len(min(as.integer(n), nrow(value))), , drop = FALSE]
}

vi_demo_selection <- function(method) {
  if (method %in% c("relaimpo", "dominance")) return(list(response = "productivity",
    responses = "productivity", predictors = c("climate", "soil", "nutrient", "moisture", "diversity")))
  if (method == "mumin") return(list(response = "multifunctionality", responses = "multifunctionality",
    predictors = c("trait_diversity", "species_richness", "aridity", "soil_carbon", "precipitation")))
  if (method %in% c("rf", "shap")) return(list(response = "productivity",
    responses = "productivity", predictors = c("climate", "soil", "nutrient", "moisture", "diversity", "treatment")))
  list(response = "Species_A", responses = paste0("Species_", LETTERS[1:5]),
    predictors = c("climate", "soil", "nutrient", "moisture", "diversity"))
}

vi_quote <- function(values) paste(dQuote(values, q = FALSE), collapse = ", ")

vi_demo_code <- function(method) {
  dava_local_demo_code(
    file.path("variable_importance", paste0(method, ".rds")), "vi_data"
  )
}

vi_analysis_code <- function(method, dataset_name, response, responses, predictors, preprocess, advanced,
                             model = vi_default_model(method), workspace_data = FALSE) {
  data_name <- if (isTRUE(workspace_data)) "analysis_input_data" else if (identical(dataset_name, "__demo__")) "vi_data" else make.names(dataset_name)
  auxiliary_vars <- if (model$type %in% c("lmer", "glmmTMB")) model$random_group %||% character() else character()
  prep <- c(sprintf("analysis_data <- %s", data_name),
    sprintf("response_vars <- c(%s)", vi_quote(responses)),
    sprintf("predictor_vars <- c(%s)", vi_quote(predictors)),
    sprintf("auxiliary_vars <- c(%s)", vi_quote(auxiliary_vars)),
    "model_data <- analysis_data[, unique(c(response_vars, predictor_vars, auxiliary_vars)), drop = FALSE]")
  if (identical(preprocess$missing, "complete")) prep <- c(prep, "model_data <- model_data[complete.cases(model_data), , drop = FALSE]")
  if (identical(preprocess$missing, "median")) prep <- c(prep,
    "model_data[] <- lapply(model_data, function(x) { if (is.numeric(x)) x[is.na(x)] <- median(x, na.rm = TRUE); x })")
  if (isTRUE(preprocess$standardize)) prep <- c(prep,
    "model_data[predictor_vars] <- lapply(model_data[predictor_vars], function(x) if (is.numeric(x)) as.numeric(scale(x)) else x)")
  formula_text <- paste(deparse(vi_model_formula(response, predictors, model), width.cutoff = 500L), collapse = "")
  formula_line <- sprintf("model_formula <- as.formula(%s)", dQuote(formula_text, q = FALSE))
  model_setup <- if (model$type %in% c("lmer", "glmer", "glmmTMB")) c(
    if (model$type %in% c("lmer", "glmer")) "library(lme4)" else "library(glmmTMB)",
    sprintf("model_data[[%s]] <- factor(model_data[[%s]])", dQuote(model$random_group, q = FALSE), dQuote(model$random_group, q = FALSE))) else character()
  model_fit_code <- switch(model$type,
    lm = "importance_model <- lm(model_formula, data = model_data)",
    glm = sprintf("importance_model <- glm(model_formula, family = %s, data = model_data)", vi_model_family_text(model)),
    lmer = "importance_model <- lmer(model_formula, data = model_data, REML = FALSE)",
    glmer = sprintf("importance_model <- glmer(model_formula, family = %s, data = model_data)", vi_model_family_text(model)),
    glmmTMB = sprintf("importance_model <- glmmTMB(model_formula, family = %s, data = model_data)", vi_model_family_text(model)),
    glm_binomial = "importance_model <- glm(model_formula, family = binomial(link = \"logit\"), data = model_data)",
    randomForest = sprintf("importance_model <- randomForest(model_formula, data = model_data, ntree = %d, importance = TRUE)", advanced$trees %||% 800L),
    "")
  mumin_beta <- if (identical(method, "mumin") && identical(model$type, "glm") &&
      identical(model$family %||% "gaussian", "binomial")) "none" else advanced$beta %||% "sd"
  varpart_groups <- list()
  if (identical(method, "varpart")) {
    configured <- lapply(advanced$group_variables %||% list(), intersect, predictors)
    configured <- Filter(length, configured)
    if (length(configured) >= 2L && length(configured) <= 4L && !anyDuplicated(unlist(configured, use.names = FALSE))) {
      varpart_groups <- configured
    } else {
      group_count <- max(2L, min(4L, as.integer(advanced$groups), length(predictors)))
      varpart_groups <- unname(split(predictors, rep(seq_len(group_count), length.out = length(predictors))))
    }
  }
  varpart_group_code <- if (length(varpart_groups)) vapply(seq_along(varpart_groups), function(index)
    sprintf("group_%d <- model_data[, c(%s), drop = FALSE]", index, vi_quote(varpart_groups[[index]])), character(1)) else character()
  varpart_fit_code <- if (length(varpart_groups)) sprintf("varpart_result <- varpart(community, %s)",
    paste0("group_", seq_along(varpart_groups), collapse = ", ")) else ""
  rdacca_groups <- list()
  if (identical(method, "rdacca_hp") && identical(advanced$predictor_mode %||% "variables", "groups")) {
    configured <- lapply(advanced$group_variables %||% list(), intersect, predictors)
    configured <- Filter(length, configured)
    if (length(configured) >= 2L && !anyDuplicated(unlist(configured, use.names = FALSE))) {
      rdacca_groups <- configured
    } else {
      group_count <- max(2L, min(as.integer(advanced$groups %||% 2L), length(predictors)))
      rdacca_groups <- unname(split(predictors, rep(seq_len(group_count), length.out = length(predictors))))
    }
    names(rdacca_groups) <- paste0("Group_", seq_along(rdacca_groups))
  }
  rdacca_explanatory_code <- if (length(rdacca_groups)) c(
    vapply(seq_along(rdacca_groups), function(index) sprintf(
      "explanatory_group_%d <- model_data[, c(%s), drop = FALSE]",
      index, vi_quote(rdacca_groups[[index]])), character(1)),
    sprintf("explanatory_data <- list(%s)", paste(sprintf("%s = explanatory_group_%d",
      names(rdacca_groups), seq_along(rdacca_groups)), collapse = ", "))
  ) else "explanatory_data <- model_data[, predictor_vars, drop = FALSE]"
  rdacca_iv_code <- if (length(rdacca_groups)) sprintf("iv_groups <- list(%s)", paste(
    sprintf("%s = c(%s)", names(rdacca_groups), vapply(rdacca_groups, vi_quote, character(1))),
    collapse = ", ")) else "iv_groups <- NULL"
  code <- switch(method,
    relaimpo = c("if (!requireNamespace('relaimpo', quietly = TRUE)) stop('Package relaimpo is required.')", prep, formula_line,
      "importance_model <- stats::lm(model_formula, data = model_data)",
      sprintf("importance_metrics <- c(%s) # <DAVA-UI-PARAM>", vi_quote(advanced$metrics)),
      sprintf("relative_scale <- %s # <DAVA-UI-PARAM>", toupper(as.character(isTRUE(advanced$relative)))),
      "relimp_result <- relaimpo::calc.relimp(importance_model, type = importance_metrics, rela = relative_scale)",
      "relative_importance <- do.call(rbind, lapply(importance_metrics, function(metric) { values <- if (metric %in% methods::slotNames(relimp_result)) methods::slot(relimp_result, metric) else NULL; if (is.null(values)) return(NULL); data.frame(term = names(values), metric = metric, importance = as.numeric(values), stringsAsFactors = FALSE) }))",
      "model_summary <- broom::glance(importance_model)",
      "coefficients <- broom::tidy(importance_model)",
      "print(summary(importance_model))", "print(relimp_result)", "print(relative_importance)",
      if (isTRUE(advanced$bootstrap)) c(sprintf("set.seed(%d)", advanced$seed),
        sprintf("relimp_boot <- relaimpo::boot.relimp(importance_model, b = %d, type = importance_metrics, rela = relative_scale, rank = TRUE, diff = TRUE)", advanced$bootstrap_reps),
        sprintf("relimp_ci <- relaimpo::booteval.relimp(relimp_boot, level = %s)", format(advanced$confidence)),
        "bootstrap_summary <- data.frame(output = capture.output(print(relimp_ci)), stringsAsFactors = FALSE)", "print(relimp_ci)") else character()),
    dominance = c("library(dominanceanalysis)", prep, model_setup, formula_line, model_fit_code,
      if (identical(model$type, "lmer")) c(
        sprintf("null_formula <- as.formula(%s)", dQuote(paste(deparse(vi_model_formula(response, character(), model), width.cutoff = 500L), collapse = ""), q = FALSE)),
        "null_model <- lmer(null_formula, data = model_data, REML = FALSE)") else "null_model <- NULL",
      "dominance_result <- dominanceAnalysis(importance_model, newdata = model_data, null.model = null_model)",
      "average_contribution <- averageContribution(dominance_result)", "dominance_briefing <- dominanceBriefing(dominance_result)",
      "print(model_formula)", "print(summary(importance_model))", "print(dominance_result)", "print(average_contribution)", "print(dominance_briefing)"),
    mumin = c("suppressPackageStartupMessages(library(MuMIn))",
      "suppressPackageStartupMessages(library(patchwork))", prep, model_setup, formula_line,
      "old_na_action <- getOption(\"na.action\")",
      "options(na.action = \"na.fail\")",
      switch(model$type,
        lm = "global_model <- lm(model_formula, data = model_data)",
        glm = sprintf("global_model <- glm(model_formula, family = %s, data = model_data)", vi_model_family_text(model)),
        lmer = "global_model <- lmer(model_formula, data = model_data, REML = FALSE)",
        glmmTMB = sprintf("global_model <- glmmTMB(model_formula, family = %s, data = model_data)", vi_model_family_text(model))),
      sprintf("rank_method <- %s", dQuote(advanced$rank %||% "AICc", q = FALSE)),
      sprintf("model_selection <- suppressMessages(dredge(global_model, rank = rank_method, beta = %s, m.lim = c(%dL, %dL), trace = FALSE))",
        dQuote(mumin_beta, q = FALSE), if (isTRUE(advanced$include_null)) 0L else 1L,
        min(as.integer(advanced$max_predictors %||% 10L), length(predictors))),
      "valid_models <- is.finite(model_selection$delta) & is.finite(model_selection$weight)",
      "if (!any(valid_models)) stop(\"No converged candidate model has a finite information criterion and weight.\")",
      if (identical(advanced$selection_rule, "weight"))
        sprintf("candidate_keep <- cumsum(ifelse(valid_models, model_selection$weight, 0)) <= %.3f & valid_models",
          advanced$cumulative_weight %||% 0.95) else
        sprintf("candidate_keep <- model_selection$delta <= %.3f & valid_models", advanced$delta %||% 4),
      "candidate_keep[is.na(candidate_keep)] <- FALSE",
      "valid_indices <- which(valid_models)",
      "candidate_keep[valid_indices[1L]] <- TRUE",
      "if (sum(candidate_keep) < 2L && length(valid_indices) > 1L) candidate_keep[valid_indices[seq_len(2L)]] <- TRUE",
      "candidate_models <- get.models(model_selection, subset = which(candidate_keep))",
      sprintf("averaged_model <- model.avg(candidate_models, rank = rank_method, beta = %s, revised.var = %s)",
        dQuote(mumin_beta, q = FALSE), toupper(as.character(isTRUE(advanced$revised_variance)))),
      "average_summary <- summary(averaged_model)",
      sprintf("averaged_coefficients <- if (%s) average_summary$coefmat.full else average_summary$coefmat.subset",
        toupper(as.character(identical(advanced$averaging, "full")))),
      sprintf("averaged_confidence_intervals <- confint(averaged_model, level = %.3f, full = %s)",
        advanced$confidence %||% 0.95, toupper(as.character(identical(advanced$averaging, "full")))),
      "variable_importance <- sw(averaged_model)",
      "print(summary(global_model))", "print(model_selection)", "print(average_summary)",
      "print(averaged_confidence_intervals)", "print(variable_importance)",
      "options(na.action = old_na_action)"),
    rf = c("library(rfPermute)", "library(A3)", prep, formula_line,
      sprintf("set.seed(%d)", advanced$seed),
      sprintf(paste0("rf_permutation <- rfPermute(model_formula, data = model_data, importance = TRUE, ",
        "ntree = %d, num.rep = %d, num.cores = %d, nodesize = %d%s)"),
        advanced$trees %||% 500L, advanced$permutations %||% 1000L,
        advanced$cores %||% 6L, advanced$nodesize %||% 5L,
        if ((advanced$mtry %||% 0L) > 0L) sprintf(", mtry = %d", advanced$mtry) else ""),
      sprintf("rf_importance <- importance(rf_permutation, scale = %s)",
        toupper(as.character(isTRUE(advanced$scale_importance)))),
      "importance_metric <- if (is.factor(model_data[[response_vars[[1]]]])) \"MeanDecreaseAccuracy\" else \"%IncMSE\"",
      "importance_p_column <- paste0(importance_metric, \".pval\")",
      "rf_importance <- rf_importance[order(rf_importance[, importance_metric], decreasing = TRUE), , drop = FALSE]",
      sprintf(paste0("rf_importance$significance <- ifelse(rf_importance[, importance_p_column] < 0.001, \"***\", ",
        "ifelse(rf_importance[, importance_p_column] < 0.01, \"**\", ",
        "ifelse(rf_importance[, importance_p_column] < %.4f, \"*\", \"\")))"),
        advanced$alpha %||% 0.05),
      if (isTRUE(advanced$a3_enabled)) c(
        "a3_result <- NULL",
        "if (is.numeric(model_data[[response_vars[[1]]]])) {",
        sprintf("  set.seed(%d)", advanced$seed),
        sprintf(paste0("  a3_result <- A3::a3(update(model_formula, . ~ . + 0), model_data, ",
          "randomForest::randomForest, p.acc = %.4f, n.folds = %d, ",
          "model.args = list(importance = TRUE, ntree = %d, nodesize = %d%s))"),
          advanced$a3_p_acc %||% 0.01, advanced$a3_folds %||% 5L,
          advanced$trees %||% 500L, advanced$nodesize %||% 5L,
          if ((advanced$mtry %||% 0L) > 0L) sprintf(", mtry = %d", advanced$mtry) else ""),
        "}") else character(),
      "print(rf_permutation)", "print(rf_importance)",
      if (isTRUE(advanced$a3_enabled)) "if (!is.null(a3_result)) print(a3_result)" else character()),
    shap = if (identical(model$type, "xgboost")) c("library(xgboost)", prep, formula_line,
      "x_data <- model.matrix(~ . - 1, data = model_data[, predictor_vars, drop = FALSE])",
      sprintf("y_data <- model_data[[%s]]", dQuote(response, q = FALSE)),
      "categorical_response <- is.factor(y_data) || is.character(y_data)",
      "class_count <- if (categorical_response) length(unique(y_data)) else 0L",
      "is_multiclass <- categorical_response && class_count > 2L",
      "is_binary <- (categorical_response && class_count == 2L) || (is.numeric(y_data) && length(unique(y_data)) == 2L && all(y_data %in% c(0, 1)))",
      "is_poisson <- !categorical_response && all(y_data >= 0) && all(y_data == floor(y_data)) && max(y_data) <= 20",
      "if (categorical_response) y_data <- as.numeric(factor(y_data)) - 1L",
      "objective <- if (is_multiclass) \"multi:softprob\" else if (is_binary) \"binary:logistic\" else if (is_poisson) \"count:poisson\" else \"reg:squarederror\"",
      "eval_metric <- if (is_multiclass) \"mlogloss\" else if (is_binary) \"logloss\" else if (is_poisson) \"poisson-nloglik\" else \"rmse\"",
      "xgb_data <- xgb.DMatrix(x_data, label = y_data)",
      sprintf("xgb_params <- list(objective = objective, eval_metric = eval_metric, max_depth = %dL, eta = %s, lambda = %s, alpha = %s, subsample = %s, colsample_bytree = %s)",
        as.integer(advanced$max_depth %||% 3L), format(advanced$eta %||% 0.05), format(advanced$lambda %||% 1),
        format(advanced$alpha %||% 0.1), format(advanced$subsample %||% 0.8), format(advanced$colsample_bytree %||% 0.8)),
      "if (is_multiclass) xgb_params$num_class <- class_count",
      sprintf("set.seed(%dL)", as.integer(advanced$seed %||% 2026L)),
      sprintf("xgb_cv <- xgb.cv(params = xgb_params, data = xgb_data, nrounds = %dL, nfold = %dL, early_stopping_rounds = %dL, verbose = 0)",
        as.integer(advanced$nrounds %||% 300L), as.integer(advanced$nfold %||% 5L), as.integer(advanced$early_stopping_rounds %||% 20L)),
      sprintf("xgb_nrounds <- if (is.null(xgb_cv$best_iteration)) %dL else xgb_cv$best_iteration", as.integer(advanced$nrounds %||% 300L)),
      "importance_model <- xgb.train(params = xgb_params, data = xgb_data, nrounds = xgb_nrounds, verbose = 0)",
      "gain_importance <- xgb.importance(model = importance_model, feature_names = colnames(x_data))",
      "shap_contrib <- predict(importance_model, xgb_data, predcontrib = TRUE)",
      "if (length(dim(shap_contrib)) == 3L) {",
      "  predicted_class <- max.col(predict(importance_model, xgb_data, strict_shape = TRUE))",
      "  shap_matrix <- t(vapply(seq_len(nrow(x_data)), function(i) shap_contrib[i, predicted_class[i], seq_len(ncol(x_data))], numeric(ncol(x_data))))",
      "} else shap_matrix <- shap_contrib[, seq_len(ncol(x_data)), drop = FALSE]",
      "colnames(shap_matrix) <- colnames(x_data)",
      "interaction_values <- predict(importance_model, xgb_data, predinteraction = TRUE)",
      "global_shap <- sort(colMeans(abs(shap_matrix)), decreasing = TRUE)",
      "print(importance_model)", "print(xgb_cv$evaluation_log)", "print(gain_importance)", "print(global_shap)") else
      c(if (identical(model$type, "randomForest")) "library(randomForest)" else character(), "library(iml)", "library(shapviz)",
      prep, model_setup, formula_line, sprintf("set.seed(%d)", advanced$seed), model_fit_code,
      "model_feature_vars <- unique(c(predictor_vars, auxiliary_vars))",
      "x_data <- model_data[, model_feature_vars, drop = FALSE]", sprintf("y_data <- model_data[[%s]]", dQuote(response, q = FALSE)),
      if (identical(model$type, "glm_binomial") || identical(model$type, "randomForest"))
        "if (is.factor(y_data) || is.character(y_data)) y_data <- as.numeric(factor(y_data)) - 1L" else character(),
      switch(model$type,
        glm_binomial = "predict_function <- function(model, newdata) as.numeric(predict(model, newdata = newdata, type = \"response\"))",
        lmer = "predict_function <- function(model, newdata) as.numeric(predict(model, newdata = newdata, re.form = NULL, allow.new.levels = TRUE))",
        randomForest = "predict_function <- function(model, newdata) { value <- predict(model, newdata = newdata, type = if (is.factor(model$y)) \"prob\" else \"response\"); if (is.matrix(value)) value[, ncol(value)] else as.numeric(value) }",
        "predict_function <- function(model, newdata) as.numeric(predict(model, newdata = newdata))"),
      "predictor <- Predictor$new(importance_model, data = x_data, y = y_data, predict.function = predict_function)",
      sprintf("explain_index <- seq_len(min(%d, nrow(x_data)))", advanced$explain_rows),
      sprintf("shap_values <- lapply(explain_index, function(i) Shapley$new(predictor, x.interest = x_data[i, , drop = FALSE], sample.size = %d)$results)", advanced$sample_size),
      "shap_table <- do.call(rbind, Map(function(x, i) transform(x, observation = i), shap_values, explain_index))",
      "global_shap <- aggregate(abs(phi) ~ feature, shap_table, mean)",
      "shap_matrix <- unclass(xtabs(phi ~ observation + feature, shap_table))",
      "names(dimnames(shap_matrix)) <- NULL",
      "shap_x <- x_data[explain_index, , drop = FALSE]",
      "shap_x[] <- lapply(shap_x, function(x) if (is.factor(x) || is.character(x)) as.numeric(factor(x)) else x)",
      "shap_object <- shapviz(shap_matrix, X = shap_x)",
      "print(model_formula)", "print(summary(importance_model))", "print(global_shap)", "print(shap_table)",
      "shap_importance_plot <- sv_importance(shap_object, kind = \"bee\")",
      "print(shap_importance_plot)"),
    varpart = c("library(vegan)", prep, sprintf("community <- as.matrix(model_data[, c(%s), drop = FALSE])", vi_quote(responses)),
      "community <- decostand(community, method = \"hellinger\")",
      "# Explicit 2-4 explanatory tables.", varpart_group_code, varpart_fit_code,
      "print(varpart_result)", "plot(varpart_result)",
      sprintf("rda_test <- anova.cca(rda(community ~ ., data = model_data[, predictor_vars, drop = FALSE]), permutations = %d)", advanced$permutations), "print(rda_test)"),
    rdacca_hp = if (model$type %in% c("lmer", "glmer", "glmmTMB")) c(
      "library(glmm.hp)", prep, model_setup, formula_line, rdacca_iv_code,
      switch(model$type,
        lmer = "mixed_model <- lmer(model_formula, data = model_data, REML = FALSE)",
        glmer = sprintf("mixed_model <- glmer(model_formula, family = %s, data = model_data)", vi_model_family_text(model)),
        glmmTMB = sprintf("mixed_model <- glmmTMB(model_formula, family = %s, data = model_data)", vi_model_family_text(model))),
      sprintf("hp_result <- glmm.hp(mixed_model, iv = iv_groups, type = %s, commonality = FALSE)",
        dQuote(advanced$type %||% "adjR2", q = FALSE)),
      if (isTRUE(advanced$commonality %||% TRUE)) sprintf(
        "commonality_result <- glmm.hp(mixed_model, iv = iv_groups, type = %s, commonality = TRUE)",
        dQuote(advanced$type %||% "adjR2", q = FALSE)) else "commonality_result <- NULL",
      sprintf("null_formula <- as.formula(%s)", dQuote(paste(deparse(
        vi_model_formula(response, character(), model), width.cutoff = 500L), collapse = ""), q = FALSE)),
      "overall_model_test <- anova(update(mixed_model, formula = null_formula), mixed_model)",
      "predictor_tests <- drop1(mixed_model, test = \"Chisq\")",
      "print(summary(mixed_model))", "print(hp_result$hierarchical.partitioning)",
      "print(overall_model_test)", "print(predictor_tests)",
      "plot(hp_result)", "plot(hp_result, plot.perc = TRUE)",
      if (isTRUE(advanced$commonality %||% TRUE))
        "upset.hp::upset.hp(commonality_result$commonality.analysis, hp_result$hierarchical.partitioning)" else character()
    ) else c("library(rdacca.hp)", "library(vegan)", "library(upset.hp)", prep,
      sprintf("response_matrix <- as.matrix(model_data[, c(%s), drop = FALSE])", vi_quote(responses)),
      if (identical(preprocess$response_transform %||% "none", "hellinger"))
        "response_matrix <- decostand(response_matrix, method = \"hellinger\")" else character(),
      rdacca_explanatory_code,
      if (identical(model$type, "lm")) sprintf("response_object <- model_data[[%s]]", dQuote(response, q = FALSE)) else
        if (identical(model$type, "dbrda")) switch(advanced$distance %||% "bray",
          unifrac = c("phy_tree <- attr(model_data, \"phy_tree\")",
            "if (is.null(phy_tree)) stop(\"UniFrac requires attr(model_data, 'phy_tree').\")",
            "unifrac_array <- GUniFrac::GUniFrac(response_matrix, phy_tree, alpha = c(0, 1))$unifracs",
            "response_object <- as.dist(unifrac_array[, , \"d_1\"])") ,
          sprintf("response_object <- vegdist(response_matrix, method = %s%s%s)",
            dQuote(advanced$distance %||% "bray", q = FALSE),
            if (identical(advanced$distance %||% "bray", "jaccard")) sprintf(", binary = %s", toupper(as.character(isTRUE(advanced$binary_jaccard)))) else "",
            if (identical(advanced$distance %||% "bray", "aitchison")) sprintf(", pseudocount = %s", format(advanced$aitchison_pseudocount %||% 0.5)) else "")) else
          "response_object <- response_matrix",
      sprintf(paste0("hp_result <- rdacca.hp(response_object, explanatory_data, method = %s, type = %s, ",
        "dbrdatype = %s, scale = %s, add = %s, sqrt.dist = %s, n.perm = %dL, var.part = %s)"),
        dQuote(vi_rdacca_method(model$type), q = FALSE), dQuote(advanced$type %||% "adjR2", q = FALSE),
        dQuote(advanced$dbrda_engine %||% "dbrda", q = FALSE), toupper(as.character(isTRUE(advanced$scale))),
        if (identical(advanced$add %||% "none", "none")) "FALSE" else dQuote(advanced$add, q = FALSE),
        toupper(as.character(isTRUE(advanced$sqrt_dist))), as.integer(advanced$permutations %||% 999L),
        toupper(as.character(isTRUE(advanced$var_part)))),
      "environment <- model_data[, predictor_vars, drop = FALSE]",
      "test_formula <- reformulate(names(environment), response = \"response_object\")",
      switch(model$type,
        lm = "constrained_model <- rda(test_formula, data = environment)",
        rda = "constrained_model <- rda(test_formula, data = environment)",
        cca = "constrained_model <- cca(test_formula, data = environment)",
        dbrda = if (identical(advanced$dbrda_engine %||% "dbrda", "capscale"))
          "constrained_model <- capscale(test_formula, data = environment)" else
          "constrained_model <- dbrda(test_formula, data = environment)"),
      sprintf("overall_model_test <- anova.cca(constrained_model, permutations = %dL)", as.integer(advanced$permutations %||% 999L)),
      sprintf("predictor_tests <- anova.cca(constrained_model, by = \"term\", permutations = %dL)", as.integer(advanced$permutations %||% 999L)),
      "print(hp_result)", "print(hp_result$Hier.part)", "print(overall_model_test)", "print(predictor_tests)",
      "hp_hierarchy_plot <- hp_result", "hp_hierarchy_plot$Var.part <- NULL",
      "plot(hp_hierarchy_plot)", "plot(hp_hierarchy_plot, plot.perc = TRUE)",
      if (isTRUE(advanced$var_part))
        "if (!is.null(hp_result$Var.part)) upset.hp(hp_result$Var.part, hp_result$Hier.part)" else character()))
  primary_metric <- (advanced$metrics %||% character())[1]
  if (!length(primary_metric) || is.na(primary_metric) || !nzchar(primary_metric)) primary_metric <- "lmg"
  reproducible_plot_code <- switch(method,
    relaimpo = c(
      sprintf("primary_metric <- %s", dQuote(primary_metric, q = FALSE)),
      "importance_plot_data <- relative_importance[relative_importance$metric == primary_metric, c('term', 'importance'), drop = FALSE]",
      "names(importance_plot_data)[names(importance_plot_data) == 'term'] <- 'variable'",
      "importance_plot_data$variable_group <- 'Not grouped'",
      "importance_plot <- ggplot2::ggplot(importance_plot_data, ggplot2::aes(x = importance, y = stats::reorder(variable, importance))) +",
      "  ggplot2::geom_col(ggplot2::aes(fill = variable_group), width = 0.68, show.legend = FALSE) +",
      "  ggplot2::labs(title = 'relaimpo relative contribution', x = 'Importance', y = NULL) +",
      "  ggplot2::theme_bw(base_size = 12) +",
      "  ggplot2::theme(panel.grid.major.y = ggplot2::element_blank(), plot.title = ggplot2::element_text(face = 'bold')) +",
      "  ggplot2::scale_fill_manual(values = c('Not grouped' = '#1f8a78'))",
      "print(importance_plot)"
    ),
    dominance = c(
      "dominance_values <- unlist(average_contribution, use.names = TRUE)",
      "dominance_plot_data <- data.frame(variable = names(dominance_values), importance = as.numeric(dominance_values))",
      "dominance_plot <- ggplot2::ggplot(dominance_plot_data, ggplot2::aes(stats::reorder(variable, importance), importance)) +",
      "  ggplot2::geom_col(fill = '#4F86B5', width = 0.72) + ggplot2::coord_flip() + ggplot2::theme_bw()",
      "print(dominance_plot)"
    ),
    mumin = c(
      "mumin_plot_data <- data.frame(variable = names(variable_importance), importance = as.numeric(variable_importance))",
      "mumin_importance_plot <- ggplot2::ggplot(mumin_plot_data, ggplot2::aes(stats::reorder(variable, importance), importance)) +",
      "  ggplot2::geom_col(fill = '#4F86B5', width = 0.72) + ggplot2::coord_flip() + ggplot2::theme_bw()",
      "print(mumin_importance_plot)"
    ),
    rf = c(
      "rf_plot_data <- data.frame(variable = rownames(rf_importance), importance = rf_importance[, importance_metric], check.names = FALSE)",
      "rf_importance_plot <- ggplot2::ggplot(rf_plot_data, ggplot2::aes(stats::reorder(variable, importance), importance)) +",
      "  ggplot2::geom_col(fill = '#4F86B5', width = 0.72) + ggplot2::coord_flip() + ggplot2::theme_bw()",
      "print(rf_importance_plot)"
    ),
    shap = c(
      "shap_plot_data <- if (is.data.frame(global_shap)) data.frame(variable = global_shap[[1]], importance = global_shap[[2]]) else data.frame(variable = names(global_shap), importance = as.numeric(global_shap))",
      "shap_global_plot <- ggplot2::ggplot(shap_plot_data, ggplot2::aes(stats::reorder(variable, importance), importance)) +",
      "  ggplot2::geom_col(fill = '#4F86B5', width = 0.72) + ggplot2::coord_flip() + ggplot2::theme_bw()",
      "print(shap_global_plot)"
    ),
    character()
  )
  paste(c(sprintf("# %s", vi_method_info(method)$label),
    if (!isTRUE(workspace_data) && identical(dataset_name, "__demo__")) vi_demo_code(method) else character(),
    "", code, "", reproducible_plot_code), collapse = "\n")
}
