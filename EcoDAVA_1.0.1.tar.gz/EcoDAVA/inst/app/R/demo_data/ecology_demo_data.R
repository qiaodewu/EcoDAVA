grassland_demo_data_generate <- function(seed = 20260716L) {
  set.seed(seed)
  design <- expand.grid(
    Block = paste0("B", 1:4),
    Grazing = c("Ungrazed", "Moderate", "Heavy"),
    Fertilization = c("Control", "Nitrogen"),
    Season = c("Spring", "Summer", "Autumn", "Winter"),
    KEEP.OUT.ATTRS = FALSE,
    stringsAsFactors = FALSE
  )
  n <- nrow(design)
  grazing <- match(design$Grazing, c("Ungrazed", "Moderate", "Heavy")) - 1
  nitrogen <- as.integer(design$Fertilization == "Nitrogen")
  season <- match(design$Season, c("Spring", "Summer", "Autumn", "Winter"))
  site_effect <- rep(rnorm(4, 0, 0.7), each = 24)
  soil_moisture <- 31 - 3.8 * grazing + 1.5 * nitrogen + 4 * sin(season * pi / 2) + rnorm(n, 0, 2.5)
  soil_ph <- 6.55 + 0.18 * grazing - 0.12 * nitrogen + rnorm(n, 0, 0.18)
  soc <- 24 - 2.1 * grazing + 1.3 * nitrogen + 0.14 * soil_moisture + site_effect + rnorm(n, 0, 1.8)
  plant_richness <- pmax(4, round(18 - 2.5 * grazing + 1.2 * nitrogen + rnorm(n, 0, 2.2)))
  biomass <- pmax(0.2, 220 - 48 * grazing + 42 * nitrogen + 3.1 * soil_moisture + 7 * plant_richness + rnorm(n, 0, 28))
  microbial_biomass <- pmax(20, 95 + 2.5 * soc + 1.4 * soil_moisture - 10 * grazing + rnorm(n, 0, 12))
  enzyme_activity <- pmax(0.1, 8 + 0.16 * microbial_biomass + 0.55 * soc + rnorm(n, 0, 3))
  respiration <- pmax(0.05, 0.3 + 0.018 * microbial_biomass + 0.04 * soil_moisture + rnorm(n, 0, 0.35))
  disease_prob <- stats::plogis(-2.8 + 0.55 * grazing - 0.035 * soil_moisture + 0.06 * plant_richness)
  data.frame(
    SampleID = sprintf("GRASS_%03d", seq_len(n)), Plot = paste0(design$Block, "_", design$Grazing, "_", design$Fertilization),
    Site = rep(c("Meadow", "Steppe", "Alpine", "Restored"), each = 24), design,
    SoilMoisture = round(soil_moisture, 2), SoilPH = round(soil_ph, 2), SOC = round(soc, 2),
    TotalNitrogen = round(1.1 + 0.055 * soc + 0.22 * nitrogen + rnorm(n, 0, 0.15), 3),
    PlantRichness = plant_richness, AbovegroundBiomass = round(biomass, 2),
    MicrobialBiomassC = round(microbial_biomass, 2), EnzymeActivity = round(enzyme_activity, 2),
    SoilRespiration = round(respiration, 3), FungalBacterialRatio = round(exp(rnorm(n, log(0.7 + 0.08 * grazing), 0.2)), 3),
    PathogenDetected = factor(rbinom(n, 1, disease_prob), levels = 0:1, labels = c("No", "Yes")),
    ASVRichness = rpois(n, lambda = pmax(15, 52 + 1.2 * soc - 6 * grazing)),
    RootColonization = pmin(0.99, pmax(0.01, stats::plogis(-0.8 + 0.05 * soc - 0.25 * grazing + rnorm(n, 0, 0.35)))),
    Condition = ordered(c("Poor", "Fair", "Good")[pmax(1, pmin(3, round(1 + scale(biomass)[, 1] + 1.5)))]),
    Subject = paste0("P", seq_len(n)), Time = factor(paste0("T", season)),
    A = factor(ifelse(nitrogen == 1, "A2", "A1")), B = factor(ifelse(grazing > 0, "B2", "B1")),
    C = factor(ifelse(season %in% c(2, 3), "C2", "C1")), Cov1 = round(soil_moisture, 2),
    Height = round(18 + 0.035 * biomass - 1.4 * grazing + rnorm(n, 0, 1.8), 2),
    Biomass = round(biomass / 100, 3), Root = round(7 + 0.12 * soc + 0.8 * nitrogen + rnorm(n, 0, 1), 2),
    check.names = FALSE
  )
}

grassland_demo_data <- function(seed = 20260716L) {
  dava_local_demo_read("statistics/ecology_demo.rds")
}
