# Unified access to versioned local simulated-data assets.

dava_demo_asset_root <- function() {
  configured <- getOption("dava.project_root", Sys.getenv("DAVA_PROJECT_ROOT", unset = ""))
  candidates <- unique(c(configured, ".", "..", file.path("..", ".."), file.path("..", "..", "..")))
  candidates <- candidates[nzchar(candidates) & !is.na(candidates)]
  roots <- candidates[file.exists(file.path(candidates, "data", "simulated_datasets", "manifest.csv"))]
  if (!length(roots)) {
    stop("Cannot locate the local simulated_datasets directory.", call. = FALSE)
  }
  normalizePath(file.path(roots[[1]], "data", "simulated_datasets"),
    winslash = "/", mustWork = TRUE)
}

dava_demo_asset_path <- function(relative_path, must_work = TRUE) {
  relative_path <- gsub("\\\\", "/", as.character(relative_path %||% ""))
  if (!nzchar(relative_path) || grepl("(^|/)\\.\\.(/|$)", relative_path) ||
      grepl("^[A-Za-z]:|^/", relative_path)) {
    stop("Invalid simulated-data asset path.", call. = FALSE)
  }
  parts <- strsplit(relative_path, "/", fixed = TRUE)[[1]]
  path <- do.call(file.path, as.list(c(dava_demo_asset_root(), parts)))
  if (isTRUE(must_work) && !file.exists(path)) {
    stop("The local simulated-data asset is missing: ", relative_path,
      ". Run scripts/build_simulated_datasets.R to rebuild it.", call. = FALSE)
  }
  normalizePath(path, winslash = "/", mustWork = must_work)
}

dava_local_demo_read <- function(relative_path) {
  readRDS(dava_demo_asset_path(relative_path, must_work = TRUE))
}

dava_microbiome_demo_asset <- function(method_id) {
  paste0("microbiome/methods/", gsub("[^A-Za-z0-9_.-]", "_", method_id), ".rds")
}
