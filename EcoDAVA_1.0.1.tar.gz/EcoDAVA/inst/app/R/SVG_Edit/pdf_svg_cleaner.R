pdf_import_read_text <- function(path) {
  paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
}

pdf_import_write_text <- function(text, path) {
  writeLines(enc2utf8(text), path, useBytes = TRUE)
}

pdf_import_make_prefix <- function(file_id, page) {
  paste0("pdfimp-", gsub("[^A-Za-z0-9_-]+", "-", file_id), "-p", as.integer(page), "-")
}

pdf_import_first <- function(value, fallback = "") {
  if (is.null(value) || length(value) == 0 || is.na(value[[1]])) fallback else value[[1]]
}

pdf_import_escape_regex <- function(x) {
  gsub("([][{}()+*^$|\\\\?.])", "\\\\\\1", x)
}

pdf_import_has_suspicious_text <- function(svg_text) {
  if (!nzchar(svg_text %||% "")) return(FALSE)
  text_nodes <- regmatches(svg_text, gregexpr("<text\\b[^>]*>[\\s\\S]*?</text>", svg_text, ignore.case = TRUE, perl = TRUE))[[1]]
  if (!length(text_nodes) || identical(text_nodes[[1]], -1)) return(FALSE)
  plain <- gsub("<[^>]+>", " ", paste(text_nodes, collapse = " "), perl = TRUE)
  plain <- gsub("&[#A-Za-z0-9]+;", " ", plain, perl = TRUE)
  tokens <- unlist(strsplit(trimws(plain), "\\s+"))
  tokens <- tokens[nzchar(tokens)]
  if (!length(tokens)) return(FALSE)
  hexish <- grepl("^[0-9A-F]{2,4}$", tokens)
  high_hexish_ratio <- mean(hexish) > 0.45 && length(tokens) >= 4
  has_replacement <- grepl("\ufffd|\\.notdef|cid:[0-9]+", plain, ignore.case = TRUE, perl = TRUE)
  high_hexish_ratio || has_replacement
}

pdf_import_cjk_font_family <- function() {
  paste(
    "Arial", "Microsoft YaHei", "SimHei", "SimSun", "Noto Sans CJK SC",
    "Source Han Sans SC", "PingFang SC", "WenQuanYi Micro Hei", "sans-serif",
    sep = ", "
  )
}

pdf_import_add_cjk_font_fallback <- function(svg) {
  if (!nzchar(svg %||% "") || !grepl("<text\\b", svg, ignore.case = TRUE)) return(svg)
  fallback <- pdf_import_cjk_font_family()
  svg <- gsub(
    "font-family\\s*=\\s*(['\"])([^'\"]*)\\1",
    paste0("font-family=\"\\2, ", fallback, "\""),
    svg,
    ignore.case = TRUE,
    perl = TRUE
  )
  gsub(
    "<text\\b((?:(?!font-family=)[^>])*)>",
    paste0("<text\\1 font-family=\"", fallback, "\">"),
    svg,
    ignore.case = TRUE,
    perl = TRUE
  )
}

pdf_import_parse_length_px <- function(value) {
  value <- trimws(as.character(value %||% ""))
  if (!nzchar(value)) return(NA_real_)
  num <- suppressWarnings(as.numeric(sub("^\\s*([0-9.]+).*$", "\\1", value)))
  if (!is.finite(num)) return(NA_real_)
  unit <- tolower(sub("^\\s*[0-9.]+\\s*([a-z%]*)\\s*$", "\\1", value))
  if (!nzchar(unit) || unit == "px") return(num)
  if (unit == "pt") return(num * 96 / 72)
  if (unit == "in") return(num * 96)
  if (unit == "cm") return(num * 96 / 2.54)
  if (unit == "mm") return(num * 96 / 25.4)
  num
}

pdf_import_node_name <- function(node) {
  tolower(xml2::xml_name(node))
}

pdf_import_strip_unsafe_svg_dom <- function(doc, keepImages = TRUE) {
  xml2::xml_remove(xml2::xml_find_all(doc, "//*[local-name()='script' or local-name()='foreignObject' or local-name()='metadata']"))
  nodes <- xml2::xml_find_all(doc, "//*")
  for (node in nodes) {
    attrs <- xml2::xml_attrs(node)
    if (!length(attrs)) next
    for (name in names(attrs)) {
      value <- attrs[[name]]
      lname <- tolower(name)
      if (grepl("^on", lname) || grepl("^\\s*javascript:", value, ignore.case = TRUE)) {
        xml2::xml_attr(node, name) <- NULL
        next
      }
      if (lname %in% c("href", "xlink:href") && grepl("^(https?:)?//", trimws(value), ignore.case = TRUE)) {
        xml2::xml_attr(node, name) <- NULL
      }
      if (pdf_import_node_name(node) == "image" && lname %in% c("href", "xlink:href")) {
        if (!grepl("^\\s*data:image/", value, ignore.case = TRUE)) {
          xml2::xml_attr(node, name) <- NULL
        }
      }
    }
  }
  images <- xml2::xml_find_all(doc, "//*[local-name()='image']")
  if (!isTRUE(keepImages) && length(images)) {
    stop("Converted SVG contains raster images and the import option rejects image content.")
  }
  for (img in images) {
    attrs <- xml2::xml_attrs(img)
    href <- attrs[["href"]] %||% attrs[["xlink:href"]] %||% ""
    if (!nzchar(href)) xml2::xml_remove(img)
  }
  invisible(doc)
}

pdf_import_materialize_paint_styles <- function(doc) {
  supported <- c(
    "fill", "fill-opacity", "fill-rule", "stroke", "stroke-opacity",
    "stroke-width", "stroke-linecap", "stroke-linejoin", "stroke-dasharray",
    "opacity", "color", "font-family", "font-size", "font-style", "font-weight",
    "text-anchor", "letter-spacing", "display", "visibility"
  )
  nodes <- xml2::xml_find_all(doc, "//*[@style]")
  for (node in nodes) {
    style <- xml2::xml_attr(node, "style")
    if (is.na(style) || !nzchar(style)) next
    declarations <- strsplit(style, ";", fixed = TRUE)[[1]]
    for (declaration in declarations) {
      parts <- strsplit(declaration, ":", fixed = TRUE)[[1]]
      if (length(parts) < 2) next
      property <- tolower(trimws(parts[[1]]))
      if (!(property %in% supported)) next
      value <- trimws(paste(parts[-1], collapse = ":"))
      value <- trimws(gsub("\\s+icc-color\\([^)]*\\)", "", value, ignore.case = TRUE, perl = TRUE))
      if (nzchar(value)) xml2::xml_set_attr(node, property, value)
    }
  }
  invisible(doc)
}

prefix_svg_ids_dom <- function(doc, prefix) {
  nodes <- xml2::xml_find_all(doc, "//*[@id]")
  old_ids <- xml2::xml_attr(nodes, "id")
  old_ids <- old_ids[nzchar(old_ids)]
  if (!length(old_ids)) return(list(doc = doc, map = character()))
  map <- setNames(paste0(prefix, old_ids), old_ids)
  for (node in nodes) {
    old <- xml2::xml_attr(node, "id")
    if (nzchar(old %||% "") && old %in% names(map)) xml2::xml_attr(node, "id") <- map[[old]]
  }
  all_nodes <- xml2::xml_find_all(doc, "//*")
  for (node in all_nodes) {
    attrs <- xml2::xml_attrs(node)
    if (!length(attrs)) next
    for (attr_name in names(attrs)) {
      value <- attrs[[attr_name]]
      if (!grepl("url\\(\\s*#|^#", value, perl = TRUE)) next
      new_value <- value
      refs <- regmatches(value, gregexpr("#[A-Za-z_][A-Za-z0-9_.:-]*", value, perl = TRUE))[[1]]
      refs <- unique(sub("^#", "", refs))
      refs <- refs[refs %in% names(map)]
      for (old in refs) new_value <- gsub(paste0("#", old), paste0("#", map[[old]]), new_value, fixed = TRUE)
      if (!identical(value, new_value)) xml2::xml_attr(node, attr_name) <- new_value
    }
  }
  list(doc = doc, map = map)
}

normalize_svg_root_geometry <- function(root) {
  view_box <- xml2::xml_attr(root, "viewBox") %||% xml2::xml_attr(root, "viewbox") %||% ""
  width <- xml2::xml_attr(root, "width") %||% ""
  height <- xml2::xml_attr(root, "height") %||% ""
  if (nzchar(view_box)) {
    parts <- suppressWarnings(as.numeric(strsplit(gsub(",", " ", view_box), "\\s+")[[1]]))
    if (length(parts) >= 4 && all(is.finite(parts[1:4]))) {
      return(list(viewBox = paste(parts[1:4], collapse = " "), width = parts[[3]], height = parts[[4]]))
    }
  }
  w <- pdf_import_parse_length_px(width)
  h <- pdf_import_parse_length_px(height)
  if (!is.finite(w) || w <= 0) w <- 800
  if (!is.finite(h) || h <= 0) h <- 600
  list(viewBox = paste(c(0, 0, round(w, 3), round(h, 3)), collapse = " "), width = w, height = h)
}

pdf_import_count_tag_dom <- function(doc, tag) {
  length(xml2::xml_find_all(doc, sprintf("//*[local-name()='%s']", tag)))
}

analyze_converted_svg <- function(svg) {
  value <- as.character(svg %||% "")
  is_path <- length(value) == 1 && nchar(value, type = "bytes") < 1024 && file.exists(value)
  text <- if (isTRUE(is_path)) pdf_import_read_text(value) else paste(value, collapse = "\n")
  if (exists("dava_ensure_svg_namespace_attrs", mode = "function")) {
    text <- dava_ensure_svg_namespace_attrs(
      text, needs_xlink = grepl("\\bxlink:href\\s*=", text, perl = TRUE))
  }
  doc <- tryCatch(xml2::read_xml(charToRaw(text), options = c("RECOVER", "NOERROR", "NOWARNING")), error = function(e) NULL)
  count <- function(tag) {
    if (!is.null(doc)) return(pdf_import_count_tag_dom(doc, tag))
    m <- gregexpr(paste0("<", tag, "\\b"), text, ignore.case = TRUE, perl = TRUE)[[1]]
    sum(m > 0)
  }
  image_count <- count("image")
  path_count <- count("path")
  text_count <- count("text")
  tspan_count <- count("tspan")
  group_count <- count("g")
  defs_count <- count("defs")
  clip_count <- count("clipPath")
  mask_count <- count("mask")
  filter_count <- count("filter")
  gradient_count <- count("linearGradient") + count("radialGradient")
  use_count <- count("use")
  shape_count <- sum(vapply(c("rect", "circle", "ellipse", "line", "polyline", "polygon"), count, integer(1)))
  warnings <- character()
  suspicious_text <- pdf_import_has_suspicious_text(text)
  if (image_count > 0) warnings <- c(warnings, "This PDF page contains raster images.")
  if (image_count > 0 && path_count == 0 && text_count == 0 && shape_count == 0) {
    warnings <- c(warnings, "This page is mainly raster image content and cannot be converted into truly editable vector artwork.")
  }
  if (path_count > 20000) warnings <- c(warnings, "This page has more than 20000 paths; editing may be slow.")
  if (text_count == 0 && path_count > 500) warnings <- c(warnings, "Text may have been outlined and may not be directly editable.")
  if (suspicious_text) warnings <- c(warnings, "Suspicious garbled PDF text was detected. Re-import with Outline text to preserve Chinese/CJK appearance.")
  if (clip_count > 0 || mask_count > 0 || filter_count > 0) warnings <- c(warnings, "This page uses clipping, masks, or filters; ungrouping may change appearance.")
  list(
    isPureVector = image_count == 0,
    hasRasterImages = image_count > 0,
    imageCount = image_count,
    pathCount = path_count,
    textCount = text_count,
    tspanCount = tspan_count,
    shapeCount = shape_count,
    groupCount = group_count,
    defsCount = defs_count,
    clipPathCount = clip_count,
    maskCount = mask_count,
    filterCount = filter_count,
    gradientCount = gradient_count,
    useCount = use_count,
    warningLevel = if (image_count > 0 && path_count == 0 && text_count == 0 && shape_count == 0) "error" else if (length(warnings)) "warning" else "ok",
    warnings = warnings
  )
}

clean_pdf_svg <- function(input_svg, output_svg, options = list()) {
  if (!requireNamespace("xml2", quietly = TRUE)) stop("Package 'xml2' is required for PDF SVG cleaning.")
  options <- modifyList(list(fileId = "pdf", fileName = "PDF", page = 1, cleanLevel = "standard", keepImages = TRUE), options)
  raw_svg <- pdf_import_read_text(input_svg)
  if (exists("dava_ensure_svg_namespace_attrs", mode = "function")) {
    raw_svg <- dava_ensure_svg_namespace_attrs(
      raw_svg, needs_xlink = grepl("\\bxlink:href\\s*=", raw_svg, perl = TRUE))
  }
  doc <- xml2::read_xml(charToRaw(raw_svg), options = c("RECOVER", "NOERROR", "NOWARNING"))
  pdf_import_strip_unsafe_svg_dom(doc, keepImages = isTRUE(options$keepImages))
  pdf_import_materialize_paint_styles(doc)
  prefix_svg_ids_dom(doc, pdf_import_make_prefix(options$fileId, options$page))
  root <- xml2::xml_root(doc)
  geometry <- normalize_svg_root_geometry(root)

  new_doc <- xml2::read_xml(charToRaw(sprintf(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="%s"></svg>',
    geometry$viewBox
  )))
  new_root <- xml2::xml_root(new_doc)
  xml2::xml_set_attr(new_root, "width", as.character(round(geometry$width, 3)))
  xml2::xml_set_attr(new_root, "height", as.character(round(geometry$height, 3)))
  wrapper <- xml2::xml_add_child(new_root, "g")
  xml2::xml_set_attr(wrapper, "data-type", "imported-pdf")
  xml2::xml_set_attr(wrapper, "data-source-format", "pdf")
  xml2::xml_set_attr(wrapper, "data-dava-source", "pdf-import")
  xml2::xml_set_attr(wrapper, "data-dava-edit-policy", "group-first")
  xml2::xml_set_attr(wrapper, "data-pdf-file", options$fileName %||% "PDF")
  xml2::xml_set_attr(wrapper, "data-pdf-page", as.character(as.integer(options$page %||% 1)))

  children <- xml2::xml_children(root)
  for (child in children) {
    xml2::xml_add_child(wrapper, child)
  }

  clean <- as.character(new_doc, options = "format")
  clean <- pdf_import_add_cjk_font_fallback(clean)
  pdf_import_write_text(clean, output_svg)
  list(svg = clean, stats = analyze_converted_svg(clean))
}
