svg_export_write_temp_svg <- function(svg_string) {
  path <- tempfile("dava-export-", fileext = ".svg")
  writeLines(svg_string, path, useBytes = TRUE)
  path
}

svg_export_run <- function(command, args, timeout) {
  out <- character()
  status <- 0
  out <- tryCatch(
    suppressWarnings(system2(command, args, stdout = TRUE, stderr = TRUE, timeout = timeout)),
    error = function(e) {
      status <<- 1
      conditionMessage(e)
    }
  )
  list(status = status, output = paste(out, collapse = "\n"), command = command, args = args)
}

export_svg_to_vector_pdf <- function(svg_string, output_pdf, options = list()) {
  options <- modifyList(list(
    engine = "rsvg",
    background = "white",
    backgroundColor = "#ffffff",
    textMode = "keep-text",
    pageWidth = NULL,
    pageHeight = NULL,
    unit = "px",
    cropToViewBox = TRUE,
    keepEditableSvg = TRUE,
    allowRasterFallback = FALSE,
    timeoutSec = 60
  ), options %||% list())
  cleaned <- clean_svg_for_export(svg_string, options)
  cleaned_svg <- svg_export_write_temp_svg(cleaned$svg)
  on.exit(unlink(cleaned_svg, force = TRUE), add = TRUE)
  tools <- if (identical(options$engine, "rsvg")) NULL else detect_svg_export_tools()
  engine <- options$engine %||% "auto"
  if (identical(engine, "pdf_vector")) engine <- "auto"
  if (identical(engine, "auto")) engine <- tools$pdf$primary
  attempts <- character()
  timeout <- as.integer(options$timeoutSec %||% 60)
  unlink(output_pdf, force = TRUE)

  try_engine <- function(engine_name) {
    attempts <<- c(attempts, engine_name)
    if (identical(engine_name, "inkscape")) {
      exe <- tools$pdf$engines$inkscape$path
      if (!nzchar(exe)) stop("Inkscape is not available.", call. = FALSE)
      args <- c(cleaned_svg, "--export-type=pdf", paste0("--export-filename=", output_pdf))
      if (identical(options$textMode, "text-to-path")) args <- c(args, "--export-text-to-path")
      res <- svg_export_run(exe, args, timeout)
      if (res$status != 0 || !file.exists(output_pdf) || file.info(output_pdf)$size <= 0) {
        stop(paste("Inkscape PDF export failed.", res$output), call. = FALSE)
      }
      return("inkscape")
    }
    if (identical(engine_name, "rsvg")) {
      if (!requireNamespace("rsvg", quietly = TRUE)) stop("R package rsvg is not available.", call. = FALSE)
      rsvg::rsvg_pdf(cleaned_svg, output_pdf)
      if (!file.exists(output_pdf) || file.info(output_pdf)$size <= 0) stop("rsvg_pdf produced an empty PDF.", call. = FALSE)
      return("rsvg")
    }
    if (identical(engine_name, "cairosvg")) {
      exe <- tools$pdf$engines$cairosvg$path
      if (!nzchar(exe)) stop("CairoSVG command is not available.", call. = FALSE)
      res <- svg_export_run(exe, c(cleaned_svg, "-o", output_pdf), timeout)
      if (res$status != 0 || !file.exists(output_pdf) || file.info(output_pdf)$size <= 0) {
        stop(paste("CairoSVG PDF export failed.", res$output), call. = FALSE)
      }
      return("cairosvg")
    }
    if (identical(engine_name, "python_cairosvg")) {
      exe <- tools$pdf$engines$python_cairosvg$path
      if (!nzchar(exe)) stop("Python CairoSVG is not available.", call. = FALSE)
      res <- svg_export_run(exe, c("-m", "cairosvg", cleaned_svg, "-o", output_pdf), timeout)
      if (res$status != 0 || !file.exists(output_pdf) || file.info(output_pdf)$size <= 0) {
        stop(paste("Python CairoSVG PDF export failed.", res$output), call. = FALSE)
      }
      return("python_cairosvg")
    }
    stop(paste("Unsupported vector PDF engine:", engine_name), call. = FALSE)
  }

  engines <- if (is.null(engine) || !nzchar(engine)) character() else engine
  if (identical(options$engine, "auto") || identical(options$engine, "pdf_vector")) {
    engines <- unique(c(engine, "inkscape", "rsvg", "cairosvg", "python_cairosvg"))
  }
  last_error <- NULL
  used <- NULL
  for (candidate in engines[nzchar(engines)]) {
    used <- tryCatch(try_engine(candidate), error = function(e) {
      last_error <<- conditionMessage(e)
      NULL
    })
    if (!is.null(used)) break
  }
  if (is.null(used)) {
    stop(paste(
      "Vector PDF export failed. Tried engines:",
      paste(unique(attempts), collapse = ", "),
      "\nLast error:", last_error %||% "none",
      "\nInstall Inkscape, R package rsvg, or CairoSVG."
    ), call. = FALSE)
  }
  info <- svg_export_file_info(output_pdf)
  list(
    success = TRUE,
    engine = used,
    output = output_pdf,
    file_size = info$size,
    vectorExpected = TRUE,
    rasterPdf = FALSE,
    warnings = cleaned$warnings,
    stats = cleaned$stats
  )
}
