if (!exists("%||%", mode = "function")) {
  `%||%` <- function(x, y) if (is.null(x)) y else x
}

sanitize_export_filename <- function(name, ext) {
  name <- as.character(name %||% "")
  ext <- tolower(gsub("^\\.", "", as.character(ext %||% "svg")))
  name <- gsub("[/\\\\:*?\"<>|]", "_", name)
  name <- trimws(name)
  if (!nzchar(name)) name <- "untitled"
  if (nchar(name, type = "chars") > 120) {
    name <- substr(name, 1, 120)
  }
  if (!grepl(paste0("\\.", ext, "$"), name, ignore.case = TRUE)) {
    name <- paste0(name, ".", ext)
  }
  name
}

svg_export_file_info <- function(path) {
  if (!file.exists(path)) return(list(exists = FALSE, size = 0))
  info <- file.info(path)
  list(exists = TRUE, size = unname(info$size %||% 0))
}

svg_export_pkg <- function(pkg) {
  available <- requireNamespace(pkg, quietly = TRUE)
  version <- if (available) as.character(utils::packageVersion(pkg)) else NULL
  list(available = available, version = version)
}

svg_export_cmd <- function(name, args = "--version", extra_paths = character()) {
  candidates <- unique(c(Sys.which(name), extra_paths))
  candidates <- candidates[!is.na(candidates) & nzchar(candidates)]
  existing <- candidates[file.exists(candidates)]
  path <- if (length(existing)) existing[1] else ""
  available <- nzchar(path)
  version <- NULL
  if (available) {
    version <- tryCatch({
      out <- suppressWarnings(system2(path, args, stdout = TRUE, stderr = TRUE, timeout = 5))
      paste(head(out, 2), collapse = " ")
    }, error = function(e) NULL)
    if (identical(tolower(name), "convert") && !grepl("imagemagick|image magick", version %||% "", ignore.case = TRUE)) {
      available <- FALSE
      path <- ""
    }
  }
  list(available = available, path = path, version = version)
}

detect_svg_export_tools <- local({
  cached <- NULL
  function(refresh = FALSE) {
    if (!refresh && !is.null(cached)) return(cached)
  os <- Sys.info()[["sysname"]] %||% ""
  inkscape_extra <- character()
  magick_extra <- character()
  if (identical(os, "Windows")) {
    inkscape_extra <- c(
      "C:/Program Files/Inkscape/bin/inkscape.exe",
      "C:/Program Files/Inkscape/inkscape.exe"
    )
    magick_extra <- c(
      "C:/Program Files/ImageMagick-7.1.1-Q16-HDRI/magick.exe",
      "C:/Program Files/ImageMagick-7.1.1-Q16/magick.exe",
      Sys.glob("C:/Program Files/ImageMagick-*/magick.exe")
    )
  } else if (identical(os, "Darwin")) {
    inkscape_extra <- c(
      "/Applications/Inkscape.app/Contents/MacOS/inkscape",
      "/opt/homebrew/bin/inkscape", "/usr/local/bin/inkscape",
      "/opt/local/bin/inkscape")
    magick_extra <- c(
      "/opt/homebrew/bin/magick", "/usr/local/bin/magick",
      "/opt/local/bin/magick")
  } else if (identical(os, "Linux")) {
    inkscape_extra <- c("/usr/bin/inkscape", "/usr/local/bin/inkscape")
    magick_extra <- c("/usr/bin/magick", "/usr/local/bin/magick")
  }

  pkgs <- list(
    rsvg = svg_export_pkg("rsvg"),
    xml2 = svg_export_pkg("xml2"),
    magick = svg_export_pkg("magick"),
    jsonlite = svg_export_pkg("jsonlite"),
    shiny = svg_export_pkg("shiny")
  )
  cmds <- list(
    inkscape = svg_export_cmd("inkscape", "--version", inkscape_extra),
    cairosvg = svg_export_cmd("cairosvg", "--version"),
    python = {
      candidates <- c("python3", "python", if (identical(os, "Windows")) "py")
      detected <- lapply(candidates, svg_export_cmd, args = "--version")
      available <- vapply(detected, function(value) isTRUE(value$available), logical(1))
      if (any(available)) detected[[which(available)[[1]]]] else detected[[1]]
    },
    magick = svg_export_cmd("magick", "-version", magick_extra),
    convert = svg_export_cmd("convert", "-version")
  )

  python_cairosvg <- FALSE
  if (isTRUE(cmds$python$available)) {
    python_cairosvg <- tryCatch({
      out <- suppressWarnings(system2(cmds$python$path, c("-m", "cairosvg", "--version"), stdout = TRUE, stderr = TRUE, timeout = 5))
      length(out) > 0 && is.null(attr(out, "status"))
    }, error = function(e) FALSE)
  }

  pdf_primary <- NULL
  # rsvg stays in-process and avoids launching a heavyweight CLI for each export.
  if (isTRUE(pkgs$rsvg$available)) pdf_primary <- "rsvg"
  else if (isTRUE(cmds$inkscape$available)) pdf_primary <- "inkscape"
  else if (isTRUE(cmds$cairosvg$available)) pdf_primary <- "cairosvg"
  else if (isTRUE(python_cairosvg)) pdf_primary <- "python_cairosvg"

  tiff_primary <- NULL
  if (isTRUE(pkgs$rsvg$available) && isTRUE(pkgs$magick$available)) tiff_primary <- "rsvg_magick"
  else if (isTRUE(pkgs$rsvg$available) && isTRUE(capabilities("tiff"))) tiff_primary <- "rsvg_grdevices"
  else if (isTRUE(cmds$inkscape$available) && isTRUE(cmds$magick$available)) tiff_primary <- "inkscape_magick"
  else if (isTRUE(cmds$magick$available)) tiff_primary <- "imagemagick"

  warnings <- character()
  if (is.null(pdf_primary)) {
    warnings <- c(warnings, "Vector PDF export is unavailable. Install Inkscape, rsvg, or CairoSVG.")
  }
  if (is.null(tiff_primary)) {
    warnings <- c(warnings, "TIFF export is unavailable. Install R package magick plus rsvg, or ImageMagick.")
  }
  if (!isTRUE(pkgs$xml2$available)) {
    warnings <- c(warnings, "R package xml2 is missing; export SVG cleaning will use a limited fallback.")
  }

  cached <<- list(
    available = !is.null(pdf_primary) || !is.null(tiff_primary),
    packages = pkgs,
    commands = cmds,
    pdf = list(
      primary = pdf_primary,
      engines = list(
        inkscape = cmds$inkscape,
        rsvg = pkgs$rsvg,
        cairosvg = cmds$cairosvg,
        python_cairosvg = list(available = python_cairosvg, path = cmds$python$path, version = cmds$python$version)
      )
    ),
    tiff = list(
      primary = tiff_primary,
      engines = list(
        rsvg = pkgs$rsvg,
        magick = pkgs$magick,
        grdevices_tiff = list(available = isTRUE(capabilities("tiff")), version = as.character(getRversion())),
        imagemagick_cli = cmds$magick,
        convert = cmds$convert
      )
    ),
    warnings = warnings
  )
    cached
  }
})
