register_svg_export_server <- function(input, output, session, file_data = NULL) {
  export_dir <- file.path(tempdir(), paste0("dava-svg-export-", as.integer(Sys.getpid())))
  dir.create(export_dir, recursive = TRUE, showWarnings = FALSE)
  resource_name <- paste0("dava-svg-export-", as.integer(Sys.getpid()), "-", sample.int(1000000, 1))
  tryCatch(shiny::addResourcePath(resource_name, export_dir), error = function(e) NULL)

  pending_export <- NULL
  dependency_dialog <- function(payload, packages, detail = NULL) {
    pending_export <<- list(payload = payload, packages = packages)
    shiny::showModal(shiny::modalDialog(
      title = paste0(toupper(payload$format), " 保存需要安装 R 包"),
      shiny::tags$p("当前导出内容和设置已保留。安装成功后将自动继续保存。"),
      shiny::tags$p(paste("需要安装或修复：", paste(packages, collapse = ", "))),
      if (!is.null(detail)) shiny::tags$pre(detail),
      shiny::tags$p("安装需要网络连接。若系统依赖或权限导致安装失败，将保留本次任务以便重试。"),
      footer = shiny::tagList(
        shiny::actionButton(session$ns("svg_export_cancel"), "取消"),
        shiny::actionButton(session$ns("svg_export_install"), "安装并继续保存", class = "btn-primary")
      ), easyClose = FALSE
    ), session = session)
  }
  run_export <- function(payload, offer_install = TRUE) {
    request_id <- if (is.list(payload)) payload$requestId %||% "" else ""
    document_id <- if (is.list(payload)) payload$documentId %||% "active" else "active"
    format <- if (is.list(payload)) payload$format %||% "svg" else "svg"
    if (identical(format, "pdf_vector")) format <- "pdf"
    if (identical(format, "tif")) format <- "tiff"
    svg <- if (is.list(payload)) payload$svgString %||% "" else ""
    name <- if (is.list(payload)) payload$name %||% "untitled" else "untitled"
    options <- if (is.list(payload) && is.list(payload$options)) payload$options else list()
    ext <- switch(format, pdf = "pdf", tiff = "tiff", png = "png", svg = "svg", "svg")
    file_name <- sanitize_export_filename(name, ext)
    output_file <- file.path(export_dir, file_name)
    if (file.exists(output_file)) {
      stem <- tools::file_path_sans_ext(file_name)
      output_file <- file.path(export_dir, paste0(stem, "_", format(Sys.time(), "%Y%m%d%H%M%S"), ".", ext))
      file_name <- basename(output_file)
    }

    if (!is.character(svg) || !nzchar(svg) || !grepl("<svg\\b", svg, ignore.case = TRUE)) {
      session$sendCustomMessage("svg_editor_export_result", list(
        type = "svg_editor_export_result",
        requestId = request_id,
        documentId = document_id,
        format = format,
        success = FALSE,
        error = "Invalid SVG string.",
        warnings = character()
      ))
      return()
    }

    packages <- switch(format, png = "rsvg", pdf = "rsvg", tiff = c("rsvg", "magick"), character())
    missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
    # The editor uses R packages for every export; no Python/CLI is required.
    if (length(missing) && offer_install) {
      dependency_dialog(payload, missing)
      return(invisible(NULL))
    }
    if (identical(format, "pdf")) options$engine <- "rsvg"
    showNotification(paste0("Exporting ", toupper(format), "..."), type = "message", duration = 2)
    result <- export_svg_document(svg, format, output_file, options)
    if (!isTRUE(result$success) && offer_install && length(missing)) {
      dependency_dialog(payload, missing, result$error)
      return(invisible(NULL))
    }
    if (isTRUE(result$success)) {
      session$sendCustomMessage("svg_editor_export_result", list(
        type = "svg_editor_export_result",
        requestId = request_id,
        documentId = document_id,
        format = format,
        success = TRUE,
        fileName = result$file_name,
        downloadUrl = paste0("/", resource_name, "/", utils::URLencode(result$file_name, reserved = TRUE)),
        report = result$report,
        warnings = result$warnings
      ))
      showNotification(paste0("Export complete: ", result$file_name), type = "message", duration = 4)
    } else {
      session$sendCustomMessage("svg_editor_export_result", list(
        type = "svg_editor_export_result",
        requestId = request_id,
        documentId = document_id,
        format = format,
        success = FALSE,
        error = result$error,
        warnings = c(result$warnings, "Install Inkscape/rsvg/CairoSVG for vector PDF, or rsvg + magick/ImageMagick for TIFF.")
      ))
      showNotification(paste0("Export failed: ", result$error), type = "error", duration = 8)
    }
  }
  observeEvent(input$svg_editor_export_request, {
    if (!is.null(pending_export)) return()
    run_export(input$svg_editor_export_request)
  }, ignoreInit = TRUE)
  observeEvent(input$svg_export_cancel, {
    if (is.null(pending_export)) return()
    payload <- pending_export$payload
    pending_export <<- NULL
    shiny::removeModal(session = session)
    session$sendCustomMessage("svg_editor_export_result", list(
      requestId = payload$requestId, documentId = payload$documentId,
      success = FALSE, error = "已取消保存；编辑内容仍保留。", warnings = list()
    ))
  }, ignoreInit = TRUE)
  observeEvent(input$svg_export_install, {
    if (is.null(pending_export)) return()
    task <- pending_export
    installation_error <- NULL
    shiny::withProgress(message = "正在安装导出依赖", value = 0, {
      tryCatch({
        writable <- .libPaths()[file.access(.libPaths(), 2) == 0]
        if (!length(writable)) {
          user_lib <- path.expand(Sys.getenv("R_LIBS_USER"))
          user_lib <- strsplit(user_lib, .Platform$path.sep, fixed = TRUE)[[1]][1]
          if (!nzchar(user_lib)) stop("没有可写的 R 包库，请配置 R_LIBS_USER。")
          dir.create(user_lib, recursive = TRUE, showWarnings = FALSE)
          .libPaths(c(user_lib, .libPaths()))
          writable <- user_lib
        }
        repos <- getOption("repos")
        if (is.null(repos) || !length(repos) || any(repos == "@CRAN@")) repos <- c(CRAN = "https://cloud.r-project.org")
        utils::install.packages(task$packages, lib = writable[1], repos = repos)
        remaining <- task$packages[!vapply(task$packages, requireNamespace, logical(1), quietly = TRUE)]
        if (length(remaining)) stop(paste("安装后仍无法加载：", paste(remaining, collapse = ", "), "。请检查 R 控制台的安装日志和系统依赖。"))
        detect_svg_export_tools(refresh = TRUE)
      }, error = function(e) installation_error <<- conditionMessage(e))
    }, session = session)
    if (!is.null(installation_error)) {
      dependency_dialog(task$payload, task$packages, installation_error)
      return()
    }
    pending_export <<- NULL
    shiny::removeModal(session = session)
    run_export(task$payload, offer_install = FALSE)
  }, ignoreInit = TRUE)
}
