register_svg_export_server <- function(input, output, session, file_data = NULL) {
  export_dir <- file.path(tempdir(), paste0("dava-svg-export-", as.integer(Sys.getpid())))
  dir.create(export_dir, recursive = TRUE, showWarnings = FALSE)
  resource_name <- paste0("dava-svg-export-", as.integer(Sys.getpid()), "-", sample.int(1000000, 1))
  tryCatch(shiny::addResourcePath(resource_name, export_dir), error = function(e) NULL)

  observeEvent(input$svg_editor_export_request, {
    payload <- input$svg_editor_export_request
    request_id <- if (is.list(payload)) payload$requestId %||% "" else ""
    document_id <- if (is.list(payload)) payload$documentId %||% "active" else "active"
    format <- if (is.list(payload)) payload$format %||% "svg" else "svg"
    if (identical(format, "pdf_vector")) format <- "pdf"
    svg <- if (is.list(payload)) payload$svgString %||% "" else ""
    name <- if (is.list(payload)) payload$name %||% "untitled" else "untitled"
    options <- if (is.list(payload) && is.list(payload$options)) payload$options else list()
    ext <- switch(format, pdf = "pdf", tiff = "tiff", png = "png", svg = "svg", "svg")
    file_name <- sanitize_export_filename(name, ext)
    output_file <- file.path(export_dir, file_name)
    if (file.exists(output_file)) {
      stem <- tools::file_path_sans_ext(file_name)
      output_file <- file.path(export_dir, paste0(stem, "_", format(Sys.time(), "%Y%m%d%H%M%S"), ".", ext))
      file_name <- basename(output_file)
    }

    if (!is.character(svg) || !nzchar(svg) || !grepl("<svg\\b", svg, ignore.case = TRUE)) {
      session$sendCustomMessage("svg_editor_export_result", list(
        type = "svg_editor_export_result",
        requestId = request_id,
        documentId = document_id,
        format = format,
        success = FALSE,
        error = "Invalid SVG string.",
        warnings = character()
      ))
      return()
    }

    showNotification(paste0("Exporting ", toupper(format), "..."), type = "message", duration = 2)
    result <- export_svg_document(svg, format, output_file, options)
    if (isTRUE(result$success)) {
      session$sendCustomMessage("svg_editor_export_result", list(
        type = "svg_editor_export_result",
        requestId = request_id,
        documentId = document_id,
        format = format,
        success = TRUE,
        fileName = result$file_name,
        downloadUrl = paste0("/", resource_name, "/", utils::URLencode(result$file_name, reserved = TRUE)),
        report = result$report,
        warnings = result$warnings
      ))
      showNotification(paste0("Export complete: ", result$file_name), type = "message", duration = 4)
    } else {
      session$sendCustomMessage("svg_editor_export_result", list(
        type = "svg_editor_export_result",
        requestId = request_id,
        documentId = document_id,
        format = format,
        success = FALSE,
        error = result$error,
        warnings = c(result$warnings, "Install Inkscape/rsvg/CairoSVG for vector PDF, or rsvg + magick/ImageMagick for TIFF.")
      ))
      showNotification(paste0("Export failed: ", result$error), type = "error", duration = 8)
    }
  }, ignoreInit = TRUE)
}
