register_svg_export_server <- function(input, output, session, file_data = NULL) {
  export_dir <- file.path(tempdir(), paste0("dava-svg-export-", as.integer(Sys.getpid())))
  dir.create(export_dir, recursive = TRUE, showWarnings = FALSE)
  resource_name <- paste0("dava-svg-export-", as.integer(Sys.getpid()), "-", sample.int(1000000, 1))
  shiny::addResourcePath(resource_name, export_dir)

  pending_export <- NULL
  send_result <- function(payload, result) {
    session$sendCustomMessage("svg_editor_export_result", c(list(
      requestId = payload$requestId, documentId = payload$documentId,
      iframeId = payload$iframeId %||% "dava_svg_editor_iframe"
    ), result))
  }
  dependency_dialog <- function(payload, packages, detail = NULL) {
    pending_export <<- list(payload = payload, packages = packages)
    send_result(payload, list(status = "dependencies", packages = as.list(packages),
      format = payload$format, detail = detail %||% ""))
  }
  run_export <- function(payload, offer_install = TRUE) {
    send_result(payload, list(status = "working"))
    request_id <- if (is.list(payload)) payload$requestId %||% "" else ""
    document_id <- if (is.list(payload)) payload$documentId %||% "active" else "active"
    format <- if (is.list(payload)) payload$format %||% "svg" else "svg"
    if (identical(format, "pdf_vector")) format <- "pdf"
    if (identical(format, "tif")) format <- "tiff"
    svg <- if (is.list(payload)) payload$svgString %||% "" else ""
    name <- if (is.list(payload)) payload$name %||% "untitled" else "untitled"
    options <- if (is.list(payload) && is.list(payload$options)) payload$options else list()
    ext <- switch(format, pdf = "pdf", tiff = "tiff", png = "png", svg = "svg", "svg")
    file_name <- sanitize_export_filename(name, ext)
    output_file <- file.path(export_dir, file_name)
    if (file.exists(output_file)) {
      stem <- tools::file_path_sans_ext(file_name)
      output_file <- file.path(export_dir, paste0(stem, "_", format(Sys.time(), "%Y%m%d%H%M%S"), ".", ext))
      file_name <- basename(output_file)
    }

    if (!is.character(svg) || !nzchar(svg) || !grepl("<svg\\b", svg, ignore.case = TRUE)) {
      session$sendCustomMessage("svg_editor_export_result", list(
        type = "svg_editor_export_result",
        requestId = request_id,
        documentId = document_id,
        format = format,
        success = FALSE,
        error = "Invalid SVG string.",
        warnings = character()
      ))
      return()
    }

    packages <- switch(format, png = "rsvg", pdf = "rsvg",
      tiff = c("rsvg", if (identical(tolower(options$colorspace %||% "rgb"), "cmyk")) "magick" else "ragg"),
      character())
    missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
    # The editor uses R packages for every export; no Python/CLI is required.
    # Check the actual loadable namespace, not only a partially unpacked package
    # directory. This ensures the dependency dialog appears when a package is
    # present but broken/incomplete.
    if (length(missing) && offer_install) {
      dependency_dialog(payload, missing,
        paste0("The following R package(s) are unavailable or cannot be loaded: ",
          paste(missing, collapse = ", "), "."))
      return(invisible(NULL))
    }
    if (identical(format, "pdf")) options$engine <- "rsvg"
    showNotification(paste0("Exporting ", toupper(format), "..."), type = "message", duration = 2)
    result <- export_svg_document(svg, format, output_file, options)
    if (!isTRUE(result$success) && offer_install && length(missing)) {
      dependency_dialog(payload, missing, result$error)
      return(invisible(NULL))
    }
    if (isTRUE(result$success)) {
      session$sendCustomMessage("svg_editor_export_result", list(
        type = "svg_editor_export_result",
        requestId = request_id,
        documentId = document_id,
        format = format,
        success = TRUE,
        fileName = result$file_name,
        iframeId = payload$iframeId %||% "dava_svg_editor_iframe",
        downloadUrl = paste0(resource_name, "/", utils::URLencode(result$file_name, reserved = TRUE)),
        fileSize = unname(file.info(result$output_file)$size),
        report = result$report,
        warnings = result$warnings
      ))
      showNotification(paste0("Export complete: ", result$file_name), type = "message", duration = 4)
    } else {
      session$sendCustomMessage("svg_editor_export_result", list(
        type = "svg_editor_export_result",
        requestId = request_id,
        documentId = document_id,
        format = format,
        success = FALSE,
        error = result$error,
        warnings = result$warnings
      ))
      showNotification(paste0("Export failed: ", result$error), type = "error", duration = 8)
    }
  }
  observeEvent(input$svg_editor_export_request, {
    if (!is.null(pending_export)) {
      send_result(input$svg_editor_export_request, list(success = FALSE,
        error = "Another export is waiting for dependency installation. Complete or cancel it first."))
      return()
    }
    tryCatch(run_export(input$svg_editor_export_request), error = function(e) {
      send_result(input$svg_editor_export_request, list(success = FALSE, error = conditionMessage(e)))
    })
  }, ignoreInit = TRUE)
  observeEvent(input$svg_export_cancel, {
    if (is.null(pending_export)) return()
    if (is.list(input$svg_export_cancel) && !identical(input$svg_export_cancel$requestId,
        pending_export$payload$requestId)) return()
    payload <- pending_export$payload
    pending_export <<- NULL
    session$sendCustomMessage("svg_editor_export_result", list(
      requestId = payload$requestId, documentId = payload$documentId,
      success = FALSE, error = "已取消保存；编辑内容仍保留。", warnings = list()
    ))
  }, ignoreInit = TRUE)
  observeEvent(input$svg_export_install, {
    if (is.null(pending_export)) return()
    if (is.list(input$svg_export_install) && !identical(input$svg_export_install$requestId,
        pending_export$payload$requestId)) return()
    task <- pending_export
    installation_error <- NULL
    shiny::withProgress(message = "正在安装导出依赖", value = 0, {
      tryCatch({
        writable <- .libPaths()[file.access(.libPaths(), 2) == 0]
        if (!length(writable)) {
          user_lib <- path.expand(Sys.getenv("R_LIBS_USER"))
          user_lib <- strsplit(user_lib, .Platform$path.sep, fixed = TRUE)[[1]][1]
          if (!nzchar(user_lib)) stop("没有可写的 R 包库，请配置 R_LIBS_USER。")
          dir.create(user_lib, recursive = TRUE, showWarnings = FALSE)
          .libPaths(c(user_lib, .libPaths()))
          writable <- user_lib
        }
        repos <- getOption("repos")
        if (is.null(repos) || !length(repos) || any(repos == "@CRAN@")) repos <- c(CRAN = "https://cloud.r-project.org")
        utils::install.packages(
          task$packages,
          lib = writable[1],
          repos = repos,
          dependencies = TRUE
        )
        # Drop stale namespace/package metadata after installation and force a
        # fresh loadability check before resuming the original request.
        for (pkg in task$packages) {
          tryCatch({
            if (pkg %in% loadedNamespaces()) unloadNamespace(pkg)
          }, error = function(e) NULL)
        }
        remaining <- task$packages[!vapply(task$packages, requireNamespace, logical(1), quietly = TRUE)]
        if (length(remaining)) stop(paste("安装后仍无法加载：", paste(remaining, collapse = ", "), "。请检查 R 控制台的安装日志和系统依赖。"))
      }, error = function(e) installation_error <<- conditionMessage(e))
    }, session = session)
    if (!is.null(installation_error)) {
      dependency_dialog(task$payload, task$packages, installation_error)
      return()
    }
    pending_export <<- NULL
    tryCatch(run_export(task$payload, offer_install = FALSE), error = function(e) {
      send_result(task$payload, list(success = FALSE, error = conditionMessage(e)))
    })
  }, ignoreInit = TRUE)
}
