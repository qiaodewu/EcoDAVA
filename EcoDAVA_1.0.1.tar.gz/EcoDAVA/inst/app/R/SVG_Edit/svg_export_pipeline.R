export_svg_document <- function(svg_string, format, output_file, options = list()) {
  format <- tolower(as.character(format %||% "svg"))
  if (identical(format, "pdf_vector")) format <- "pdf"
  tryCatch({
    report <- NULL
    warnings <- character()
    if (identical(format, "svg")) {
      cleaned <- clean_svg_for_export(svg_string, options)
      writeLines(cleaned$svg, output_file, useBytes = TRUE)
      report <- list(success = TRUE, output = output_file, file_size = svg_export_file_info(output_file)$size, stats = cleaned$stats)
      warnings <- cleaned$warnings
    } else if (identical(format, "pdf")) {
      report <- export_svg_to_vector_pdf(svg_string, output_file, options)
      warnings <- report$warnings %||% character()
    } else if (identical(format, "tiff")) {
      report <- export_svg_to_tiff(svg_string, output_file, options)
      warnings <- report$warnings %||% character()
    } else if (identical(format, "png")) {
      png_file <- output_file
      tiff_options <- modifyList(options %||% list(), list(compression = "none"))
      cleaned <- clean_svg_for_export(svg_string, tiff_options)
      dims <- svg_export_pixel_dimensions(cleaned$svg, tiff_options$dpi %||% 300, tiff_options$width, tiff_options$height)
      tmp_svg <- svg_export_write_temp_svg(cleaned$svg)
      on.exit(unlink(tmp_svg, force = TRUE), add = TRUE)
      if (requireNamespace("rsvg", quietly = TRUE)) {
        rsvg::rsvg_png(tmp_svg, png_file, width = dims$pixelWidth, height = dims$pixelHeight)
      } else {
        stop("PNG export requires R package rsvg.", call. = FALSE)
      }
      report <- list(success = TRUE, output = png_file, dpi = dims$dpi, pixelWidth = dims$pixelWidth, pixelHeight = dims$pixelHeight, file_size = svg_export_file_info(png_file)$size, stats = cleaned$stats)
      warnings <- cleaned$warnings
    } else {
      stop(paste("Unsupported export format:", format), call. = FALSE)
    }
    if (!file.exists(output_file) || file.info(output_file)$size <= 0) {
      stop("Export output file was not created.", call. = FALSE)
    }
    list(success = TRUE, format = format, output_file = output_file, file_name = basename(output_file), report = report, warnings = warnings, error = NULL)
  }, error = function(e) {
    list(success = FALSE, format = format, output_file = output_file, file_name = basename(output_file), report = NULL, warnings = character(), error = conditionMessage(e))
  })
}
