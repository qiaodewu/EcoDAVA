svg_export_option <- function(options, name, default = NULL) {
  if (is.null(options) || is.null(options[[name]])) default else options[[name]]
}

# SVGs created by third-party tools sometimes keep xlink:href attributes but
# omit xmlns:xlink.  Add it before every export-side XML parse so libxml2 does
# not emit namespace warnings to the R console.
svg_export_prepare_xml <- function(svg_string) {
  text <- paste(enc2utf8(as.character(svg_string %||% "")), collapse = "\n")
  if (exists("dava_ensure_svg_namespace_attrs", mode = "function")) {
    return(dava_ensure_svg_namespace_attrs(
      text, needs_xlink = grepl("\\bxlink:href\\s*=", text, perl = TRUE)))
  }
  text
}

svg_export_count_nodes <- function(doc, xpath) {
  if (!requireNamespace("xml2", quietly = TRUE)) return(NA_integer_)
  length(xml2::xml_find_all(doc, xpath))
}

svg_export_dimensions <- function(svg_string) {
  dims <- list(width = 960, height = 720, viewBox = "0 0 960 720")
  if (!requireNamespace("xml2", quietly = TRUE)) return(dims)
  doc <- xml2::read_xml(svg_export_prepare_xml(svg_string), options = c("NOBLANKS", "HUGE", "NOERROR", "NOWARNING"))
  root <- xml2::xml_root(doc)
  width <- suppressWarnings(as.numeric(gsub("[^0-9.\\-]", "", xml2::xml_attr(root, "width") %||% "")))
  height <- suppressWarnings(as.numeric(gsub("[^0-9.\\-]", "", xml2::xml_attr(root, "height") %||% "")))
  viewBox <- xml2::xml_attr(root, "viewBox") %||% xml2::xml_attr(root, "viewbox") %||% ""
  if (nzchar(viewBox)) {
    parts <- suppressWarnings(as.numeric(strsplit(trimws(viewBox), "\\s+|,")[[1]]))
    if (length(parts) >= 4 && all(is.finite(parts[3:4]))) {
      width <- if (is.finite(width)) width else parts[3]
      height <- if (is.finite(height)) height else parts[4]
    }
  }
  if (!is.finite(width) || width <= 0) width <- dims$width
  if (!is.finite(height) || height <= 0) height <- dims$height
  if (!nzchar(viewBox)) viewBox <- paste("0 0", width, height)
  list(width = width, height = height, viewBox = viewBox)
}

svg_export_cjk_font_family <- function() {
  paste(
    "Arial",
    "Microsoft YaHei",
    "SimHei",
    "SimSun",
    "Noto Sans CJK SC",
    "Source Han Sans SC",
    "PingFang SC",
    "WenQuanYi Micro Hei",
    "sans-serif",
    sep = ", "
  )
}

svg_export_append_cjk_font_fallback <- function(doc) {
  if (!requireNamespace("xml2", quietly = TRUE)) return(invisible(FALSE))
  fallback <- svg_export_cjk_font_family()
  nodes <- xml2::xml_find_all(doc, "//*[local-name()='text' or local-name()='tspan']")
  if (!length(nodes)) return(invisible(FALSE))
  for (node in nodes) {
    current <- xml2::xml_attr(node, "font-family") %||% ""
    if (nzchar(current)) {
      if (!grepl("Microsoft YaHei|SimHei|SimSun|Noto Sans CJK|Source Han|PingFang|WenQuanYi", current, ignore.case = TRUE)) {
        xml2::xml_set_attr(node, "font-family", paste(current, fallback, sep = ", "))
      }
    } else {
      xml2::xml_set_attr(node, "font-family", fallback)
    }
  }
  invisible(TRUE)
}

svg_export_num <- function(value, default = NA_real_) {
  value <- as.character(value %||% "")
  if (!nzchar(value) || grepl("%", value, fixed = TRUE)) return(default)
  number <- suppressWarnings(as.numeric(sub("^\\s*([-+]?(?:[0-9]*\\.)?[0-9]+).*", "\\1", value, perl = TRUE)))
  if (!is.finite(number)) return(default)
  unit <- tolower(sub("^\\s*[-+]?(?:[0-9]*\\.)?[0-9]+\\s*", "", value, perl = TRUE))
  # Unit-less SVG lengths are already expressed in user units (normally px).
  # Keep that case as the switch default because an empty string cannot be a
  # named switch arm in R.
  multiplier <- switch(unit,
    px = 1, pt = 96 / 72, pc = 16, mm = 96 / 25.4,
    cm = 96 / 2.54, `in` = 96, 1
  )
  number * multiplier
}

svg_export_matrix_identity <- function() c(1, 0, 0, 1, 0, 0)

svg_export_matrix_multiply <- function(left, right) {
  c(
    left[1] * right[1] + left[3] * right[2],
    left[2] * right[1] + left[4] * right[2],
    left[1] * right[3] + left[3] * right[4],
    left[2] * right[3] + left[4] * right[4],
    left[1] * right[5] + left[3] * right[6] + left[5],
    left[2] * right[5] + left[4] * right[6] + left[6]
  )
}

svg_export_transform_matrix <- function(transform) {
  result <- svg_export_matrix_identity()
  transform <- as.character(transform %||% "")
  if (!nzchar(transform)) return(result)
  matches <- gregexpr("([a-zA-Z]+)\\s*\\(([^)]*)\\)", transform, perl = TRUE)
  pieces <- regmatches(transform, matches)[[1]]
  if (!length(pieces)) return(result)
  for (piece in pieces) {
    name <- tolower(sub("\\s*\\(.*$", "", piece))
    values <- suppressWarnings(as.numeric(strsplit(gsub("^[^(]*\\(|\\)$", "", piece), "[,\\s]+")[[1]]))
    values <- values[is.finite(values)]
    local <- svg_export_matrix_identity()
    if (name == "matrix" && length(values) >= 6) {
      local <- values[1:6]
    } else if (name == "translate" && length(values) >= 1) {
      local[5:6] <- c(values[1], if (length(values) >= 2) values[2] else 0)
    } else if (name == "scale" && length(values) >= 1) {
      local[c(1, 4)] <- c(values[1], if (length(values) >= 2) values[2] else values[1])
    } else if (name == "rotate" && length(values) >= 1) {
      angle <- values[1] * pi / 180
      rotation <- c(cos(angle), sin(angle), -sin(angle), cos(angle), 0, 0)
      if (length(values) >= 3) {
        cx <- values[2]; cy <- values[3]
        local <- svg_export_matrix_multiply(
          svg_export_matrix_multiply(c(1, 0, 0, 1, cx, cy), rotation),
          c(1, 0, 0, 1, -cx, -cy)
        )
      } else {
        local <- rotation
      }
    }
    result <- svg_export_matrix_multiply(result, local)
  }
  result
}

svg_export_apply_matrix <- function(points, matrix) {
  if (!length(points)) return(points)
  x <- points[, 1]; y <- points[, 2]
  cbind(matrix[1] * x + matrix[3] * y + matrix[5],
        matrix[2] * x + matrix[4] * y + matrix[6])
}

svg_export_node_matrix <- function(node) {
  chain <- list()
  current <- node
  while (!is.null(current) && inherits(current, "xml_node")) {
    chain[[length(chain) + 1L]] <- current
    parent <- tryCatch(xml2::xml_parent(current), error = function(e) NULL)
    if (is.null(parent) || identical(xml2::xml_name(parent), "document")) break
    current <- parent
  }
  matrix <- svg_export_matrix_identity()
  for (item in rev(chain)) {
    matrix <- svg_export_matrix_multiply(matrix, svg_export_transform_matrix(xml2::xml_attr(item, "transform")))
  }
  matrix
}

svg_export_element_points <- function(node) {
  name <- tolower(xml2::xml_name(node))
  n <- function(attr, default = 0) svg_export_num(xml2::xml_attr(node, attr), default)
  if (name %in% c("rect", "image", "svg", "use")) {
    x <- n("x"); y <- n("y"); w <- n("width"); h <- n("height")
    if (is.finite(w) && is.finite(h) && w > 0 && h > 0) return(rbind(c(x, y), c(x + w, y), c(x, y + h), c(x + w, y + h)))
  } else if (name == "circle") {
    cx <- n("cx"); cy <- n("cy"); r <- n("r", NA_real_)
    if (is.finite(r) && r > 0) return(rbind(c(cx - r, cy - r), c(cx + r, cy - r), c(cx - r, cy + r), c(cx + r, cy + r)))
  } else if (name == "ellipse") {
    cx <- n("cx"); cy <- n("cy"); rx <- n("rx", NA_real_); ry <- n("ry", NA_real_)
    if (is.finite(rx) && is.finite(ry) && rx > 0 && ry > 0) return(rbind(c(cx - rx, cy - ry), c(cx + rx, cy - ry), c(cx - rx, cy + ry), c(cx + rx, cy + ry)))
  } else if (name == "line") {
    return(rbind(c(n("x1"), n("y1")), c(n("x2"), n("y2"))))
  } else if (name %in% c("polyline", "polygon")) {
    raw <- gsub("[,\\s]+", " ", trimws(xml2::xml_attr(node, "points") %||% ""))
    values <- suppressWarnings(as.numeric(strsplit(raw, " ")[[1]]))
    values <- values[is.finite(values)]
    if (length(values) >= 2) return(matrix(values[seq_len(length(values) - length(values) %% 2)], ncol = 2, byrow = TRUE))
  } else if (name == "path") {
    raw <- xml2::xml_attr(node, "d") %||% ""
    values <- suppressWarnings(as.numeric(unlist(regmatches(raw, gregexpr(
      "[-+]?(?:[0-9]*\\.)?[0-9]+(?:[eE][-+]?[0-9]+)?", raw, perl = TRUE
    )))))
    values <- values[is.finite(values)]
    if (length(values) >= 2) return(matrix(values[seq_len(length(values) - length(values) %% 2)], ncol = 2, byrow = TRUE))
  } else if (name %in% c("text", "tspan")) {
    x <- n("x"); y <- n("y"); size <- n("font-size", 12)
    text <- paste(xml2::xml_text(node), collapse = "")
    width <- max(1, nchar(text, type = "chars") * size * 0.62)
    return(rbind(c(x, y - size), c(x + width, y), c(x, y), c(x + width, y - size)))
  }
  NULL
}

svg_export_canvas_bounds <- function(root) {
  view_box <- xml2::xml_attr(root, "viewBox") %||% xml2::xml_attr(root, "viewbox") %||% ""
  base <- suppressWarnings(as.numeric(strsplit(trimws(view_box), "\\s+|,")[[1]]))
  if (length(base) < 4 || !all(is.finite(base[1:4])) || base[3] <= 0 || base[4] <= 0) {
    width <- svg_export_num(xml2::xml_attr(root, "width"), 960)
    height <- svg_export_num(xml2::xml_attr(root, "height"), 720)
    if (!is.finite(width) || width <= 0) width <- 960
    if (!is.finite(height) || height <= 0) height <- 720
    base <- c(0, 0, width, height)
  }
  c(base[1], base[2], base[1] + base[3], base[2] + base[4])
}

svg_export_supplied_bounds <- function(value) {
  if (is.null(value)) return(NULL)
  if (is.list(value) && all(c("x", "y", "width", "height") %in% names(value))) {
    value <- unlist(value[c("x", "y", "width", "height")], use.names = FALSE)
  }
  value <- suppressWarnings(as.numeric(value))
  if (length(value) < 4 || !all(is.finite(value[1:4])) || value[3] <= 0 || value[4] <= 0) return(NULL)
  c(value[1], value[2], value[1] + value[3], value[2] + value[4])
}

svg_export_node_is_visible <- function(node) {
  chain <- c(list(node), as.list(xml2::xml_parents(node)))
  for (item in chain) {
    style <- tolower(xml2::xml_attr(item, "style") %||% "")
    display <- tolower(trimws(xml2::xml_attr(item, "display") %||% ""))
    visibility <- tolower(trimws(xml2::xml_attr(item, "visibility") %||% ""))
    opacity <- svg_export_num(xml2::xml_attr(item, "opacity"), 1)
    if (identical(display, "none") || visibility %in% c("hidden", "collapse") ||
        (is.finite(opacity) && opacity <= 0) ||
        grepl("(^|;)\\s*display\\s*:\\s*none\\s*(;|$)", style, perl = TRUE) ||
        grepl("(^|;)\\s*visibility\\s*:\\s*(hidden|collapse)\\s*(;|$)", style, perl = TRUE) ||
        grepl("(^|;)\\s*opacity\\s*:\\s*(0+(?:\\.0*)?|\\.0+)\\s*(;|$)", style, perl = TRUE)) {
      return(FALSE)
    }
  }
  TRUE
}

svg_export_content_bounds <- function(doc, root, padding = 0, supplied_bounds = NULL) {
  bounds <- svg_export_supplied_bounds(supplied_bounds)
  if (!is.null(bounds)) {
    return(bounds + c(-padding, -padding, padding, padding))
  }
  bounds <- c(Inf, Inf, -Inf, -Inf)

  # Descendants only: the root SVG represents the editor page/viewport, not a
  # drawing object.  Starting from its viewBox was the reason exports retained
  # the complete canvas even when the artwork occupied only a small region.
  nodes <- xml2::xml_find_all(root, paste0(
    ".//*[not(ancestor-or-self::*[local-name()='defs' or local-name()='clipPath' or ",
    "local-name()='mask' or local-name()='style' or local-name()='script']) and ",
    "not(@data-dava-export-background='1') and not(@id='canvas_background')]"
  ))
  for (node in nodes) {
    if (!svg_export_node_is_visible(node)) next
    if (identical(xml2::xml_attr(node, "data-dava-background") %||% "", "transparent")) next
    points <- svg_export_element_points(node)
    if (is.null(points) || !nrow(points)) next
    points <- svg_export_apply_matrix(points, svg_export_node_matrix(node))
    bounds <- c(min(bounds[1], min(points[, 1], na.rm = TRUE)),
                min(bounds[2], min(points[, 2], na.rm = TRUE)),
                max(bounds[3], max(points[, 1], na.rm = TRUE)),
                max(bounds[4], max(points[, 2], na.rm = TRUE)))
  }
  if (!all(is.finite(bounds)) || bounds[3] <= bounds[1] || bounds[4] <= bounds[2]) {
    return(svg_export_canvas_bounds(root))
  }
  stroke_values <- suppressWarnings(as.numeric(unlist(lapply(nodes, function(node) svg_export_num(xml2::xml_attr(node, "stroke-width"), 0)))))
  margin <- max(c(padding, stroke_values / 2), na.rm = TRUE)
  bounds + c(-margin, -margin, margin, margin)
}

svg_export_expand_to_content <- function(doc, root, options = list()) {
  if (!isTRUE(svg_export_option(options, "expandToContent", TRUE))) return(invisible(NULL))
  padding <- svg_export_num(svg_export_option(options, "contentPadding", 0), 0)
  bounds <- svg_export_content_bounds(
    doc, root,
    padding = max(0, padding),
    supplied_bounds = svg_export_option(options, "contentBounds", NULL)
  )
  width <- max(1, bounds[3] - bounds[1]); height <- max(1, bounds[4] - bounds[2])
  view_box <- paste(format(c(bounds[1], bounds[2], width, height), scientific = FALSE, trim = TRUE), collapse = " ")
  xml2::xml_set_attr(root, "viewBox", view_box)
  xml2::xml_set_attr(root, "width", format(width, scientific = FALSE, trim = TRUE))
  xml2::xml_set_attr(root, "height", format(height, scientific = FALSE, trim = TRUE))
  invisible(bounds)
}

clean_svg_for_export <- function(svg_string, options = list()) {
  if (!is.character(svg_string) || !nzchar(svg_string) || !grepl("<svg\\b", svg_string, ignore.case = TRUE)) {
    stop("Invalid SVG string for export.", call. = FALSE)
  }
  svg_string <- svg_export_prepare_xml(svg_string)
  options <- modifyList(list(
    background = "white",
    backgroundColor = "#ffffff",
    removeEditorArtifacts = TRUE,
    allowForeignObject = FALSE,
    expandToContent = TRUE,
    contentPadding = 0
  ), options %||% list())
  warnings <- character()

  if (!requireNamespace("xml2", quietly = TRUE)) {
    cleaned <- gsub("<script[\\s\\S]*?</script>", "", svg_string, ignore.case = TRUE)
    cleaned <- gsub("<foreignObject[\\s\\S]*?</foreignObject>", "", cleaned, ignore.case = TRUE)
    cleaned <- gsub("\\s+on[a-zA-Z]+\\s*=\\s*(['\"])[\\s\\S]*?\\1", "", cleaned, perl = TRUE)
    cleaned <- gsub("javascript:", "", cleaned, ignore.case = TRUE)
    return(list(
      svg = cleaned,
      warnings = c(warnings, "xml2 is not installed; used limited regex SVG cleaning."),
      stats = list(pathCount = NA_integer_, textCount = NA_integer_, imageCount = NA_integer_, clipPathCount = NA_integer_, filterCount = NA_integer_)
    ))
  }

  doc <- xml2::read_xml(svg_string, options = c("NOBLANKS", "HUGE", "NOERROR", "NOWARNING"))
  root <- xml2::xml_root(doc)
  if (!identical(tolower(xml2::xml_name(root)), "svg")) {
    stop("Export input root is not SVG.", call. = FALSE)
  }
  if (is.na(xml2::xml_attr(root, "xmlns"))) {
    xml2::xml_set_attr(root, "xmlns", "http://www.w3.org/2000/svg")
  }

  remove_nodes <- function(xpath) {
    nodes <- xml2::xml_find_all(doc, xpath)
    if (length(nodes)) xml2::xml_remove(nodes)
  }
  remove_nodes("//*[local-name()='script']")
  if (!isTRUE(options$allowForeignObject)) remove_nodes("//*[local-name()='foreignObject']")
  if (isTRUE(options$removeEditorArtifacts)) {
    remove_nodes("//*[@id='selectorParentGroup' or @id='hover_group' or @id='canvasGrid' or @data-editor-only='1' or @data-dava-editor-ui='1']")
    remove_nodes("//*[contains(@class,'selector') or contains(@class,'selection') or contains(@class,'hover')]")
  }

  nodes <- xml2::xml_find_all(doc, "//*")
  for (node in nodes) {
    attrs <- xml2::xml_attrs(node)
    if (!length(attrs)) next
    for (attr_name in names(attrs)) {
      attr_value <- attrs[[attr_name]]
      lower_name <- tolower(attr_name)
      lower_value <- tolower(attr_value)
      if (grepl("^on", lower_name) ||
          lower_name %in% c("data-selection", "data-temp", "data-editor-only", "data-dava-editor-ui") ||
          grepl("javascript:", lower_value, fixed = TRUE)) {
        xml2::xml_attr(node, attr_name) <- NULL
      }
    }
  }
  svg_export_append_cjk_font_fallback(doc)

  width <- xml2::xml_attr(root, "width") %||% ""
  height <- xml2::xml_attr(root, "height") %||% ""
  viewBox <- xml2::xml_attr(root, "viewBox") %||% xml2::xml_attr(root, "viewbox") %||% ""
  numeric_width <- suppressWarnings(as.numeric(gsub("[^0-9.\\-]", "", width)))
  numeric_height <- suppressWarnings(as.numeric(gsub("[^0-9.\\-]", "", height)))
  if (!nzchar(viewBox)) {
    if (!is.finite(numeric_width) || numeric_width <= 0) numeric_width <- 960
    if (!is.finite(numeric_height) || numeric_height <= 0) numeric_height <- 720
    viewBox <- paste("0 0", numeric_width, numeric_height)
    xml2::xml_set_attr(root, "viewBox", viewBox)
  }
  if (!nzchar(width)) xml2::xml_set_attr(root, "width", if (is.finite(numeric_width)) as.character(numeric_width) else "960")
  if (!nzchar(height)) xml2::xml_set_attr(root, "height", if (is.finite(numeric_height)) as.character(numeric_height) else "720")

  # Export the complete drawing page rather than the visible editor viewport.
  # This keeps objects positioned outside the current canvas/scroll window.
  svg_export_expand_to_content(doc, root, options)
  viewBox <- xml2::xml_attr(root, "viewBox") %||% viewBox

  background <- svg_export_option(options, "background", "white")
  if (background %in% c("white", "custom")) {
    color <- if (identical(background, "custom")) options$backgroundColor %||% "#ffffff" else "#ffffff"
    parts <- suppressWarnings(as.numeric(strsplit(trimws(viewBox), "\\s+|,")[[1]]))
    if (length(parts) >= 4 && all(is.finite(parts[1:4]))) {
      bg <- xml2::xml_add_child(root, "rect", .where = 0)
      xml2::xml_set_attr(bg, "x", as.character(parts[1]))
      xml2::xml_set_attr(bg, "y", as.character(parts[2]))
      xml2::xml_set_attr(bg, "width", as.character(parts[3]))
      xml2::xml_set_attr(bg, "height", as.character(parts[4]))
      xml2::xml_set_attr(bg, "fill", color)
      xml2::xml_set_attr(bg, "data-dava-export-background", "1")
    }
  }

  # Reuse the single full-tree traversal above instead of running five more XPath scans.
  node_names <- tolower(xml2::xml_name(nodes))
  stats <- list(
    pathCount = sum(node_names == "path"),
    textCount = sum(node_names %in% c("text", "tspan")),
    imageCount = sum(node_names == "image"),
    clipPathCount = sum(node_names == "clippath"),
    filterCount = sum(node_names == "filter")
  )
  list(svg = as.character(doc), warnings = warnings, stats = stats)
}


