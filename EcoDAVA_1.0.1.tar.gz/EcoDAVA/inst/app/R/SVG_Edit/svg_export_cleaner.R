svg_export_option <- function(options, name, default = NULL) {
  if (is.null(options) || is.null(options[[name]])) default else options[[name]]
}

# SVGs created by third-party tools sometimes keep xlink:href attributes but
# omit xmlns:xlink.  Add it before every export-side XML parse so libxml2 does
# not emit namespace warnings to the R console.
svg_export_prepare_xml <- function(svg_string) {
  text <- paste(enc2utf8(as.character(svg_string %||% "")), collapse = "\n")
  if (exists("dava_ensure_svg_namespace_attrs", mode = "function")) {
    return(dava_ensure_svg_namespace_attrs(
      text, needs_xlink = grepl("\\bxlink:href\\s*=", text, perl = TRUE)))
  }
  text
}

svg_export_count_nodes <- function(doc, xpath) {
  if (!requireNamespace("xml2", quietly = TRUE)) return(NA_integer_)
  length(xml2::xml_find_all(doc, xpath))
}

svg_export_dimensions <- function(svg_string) {
  dims <- list(width = 960, height = 720, viewBox = "0 0 960 720")
  if (!requireNamespace("xml2", quietly = TRUE)) return(dims)
  doc <- xml2::read_xml(svg_export_prepare_xml(svg_string), options = c("NOBLANKS", "HUGE", "NOERROR", "NOWARNING"))
  root <- xml2::xml_root(doc)
  width <- suppressWarnings(as.numeric(gsub("[^0-9.\\-]", "", xml2::xml_attr(root, "width") %||% "")))
  height <- suppressWarnings(as.numeric(gsub("[^0-9.\\-]", "", xml2::xml_attr(root, "height") %||% "")))
  viewBox <- xml2::xml_attr(root, "viewBox") %||% xml2::xml_attr(root, "viewbox") %||% ""
  if (nzchar(viewBox)) {
    parts <- suppressWarnings(as.numeric(strsplit(trimws(viewBox), "\\s+|,")[[1]]))
    if (length(parts) >= 4 && all(is.finite(parts[3:4]))) {
      width <- if (is.finite(width)) width else parts[3]
      height <- if (is.finite(height)) height else parts[4]
    }
  }
  if (!is.finite(width) || width <= 0) width <- dims$width
  if (!is.finite(height) || height <= 0) height <- dims$height
  if (!nzchar(viewBox)) viewBox <- paste("0 0", width, height)
  list(width = width, height = height, viewBox = viewBox)
}

svg_export_cjk_font_family <- function() {
  paste(
    "Arial",
    "Microsoft YaHei",
    "SimHei",
    "SimSun",
    "Noto Sans CJK SC",
    "Source Han Sans SC",
    "PingFang SC",
    "WenQuanYi Micro Hei",
    "sans-serif",
    sep = ", "
  )
}

svg_export_append_cjk_font_fallback <- function(doc) {
  if (!requireNamespace("xml2", quietly = TRUE)) return(invisible(FALSE))
  fallback <- svg_export_cjk_font_family()
  nodes <- xml2::xml_find_all(doc, "//*[local-name()='text' or local-name()='tspan']")
  if (!length(nodes)) return(invisible(FALSE))
  for (node in nodes) {
    current <- xml2::xml_attr(node, "font-family") %||% ""
    if (nzchar(current)) {
      if (!grepl("Microsoft YaHei|SimHei|SimSun|Noto Sans CJK|Source Han|PingFang|WenQuanYi", current, ignore.case = TRUE)) {
        xml2::xml_set_attr(node, "font-family", paste(current, fallback, sep = ", "))
      }
    } else {
      xml2::xml_set_attr(node, "font-family", fallback)
    }
  }
  invisible(TRUE)
}

clean_svg_for_export <- function(svg_string, options = list()) {
  if (!is.character(svg_string) || !nzchar(svg_string) || !grepl("<svg\\b", svg_string, ignore.case = TRUE)) {
    stop("Invalid SVG string for export.", call. = FALSE)
  }
  svg_string <- svg_export_prepare_xml(svg_string)
  options <- modifyList(list(
    background = "white",
    backgroundColor = "#ffffff",
    removeEditorArtifacts = TRUE,
    allowForeignObject = FALSE
  ), options %||% list())
  warnings <- character()

  if (!requireNamespace("xml2", quietly = TRUE)) {
    cleaned <- gsub("<script[\\s\\S]*?</script>", "", svg_string, ignore.case = TRUE)
    cleaned <- gsub("<foreignObject[\\s\\S]*?</foreignObject>", "", cleaned, ignore.case = TRUE)
    cleaned <- gsub("\\s+on[a-zA-Z]+\\s*=\\s*(['\"])[\\s\\S]*?\\1", "", cleaned, perl = TRUE)
    cleaned <- gsub("javascript:", "", cleaned, ignore.case = TRUE)
    return(list(
      svg = cleaned,
      warnings = c(warnings, "xml2 is not installed; used limited regex SVG cleaning."),
      stats = list(pathCount = NA_integer_, textCount = NA_integer_, imageCount = NA_integer_, clipPathCount = NA_integer_, filterCount = NA_integer_)
    ))
  }

  doc <- xml2::read_xml(svg_string, options = c("NOBLANKS", "HUGE", "NOERROR", "NOWARNING"))
  root <- xml2::xml_root(doc)
  if (!identical(tolower(xml2::xml_name(root)), "svg")) {
    stop("Export input root is not SVG.", call. = FALSE)
  }
  if (is.na(xml2::xml_attr(root, "xmlns"))) {
    xml2::xml_set_attr(root, "xmlns", "http://www.w3.org/2000/svg")
  }

  remove_nodes <- function(xpath) {
    nodes <- xml2::xml_find_all(doc, xpath)
    if (length(nodes)) xml2::xml_remove(nodes)
  }
  remove_nodes("//*[local-name()='script']")
  if (!isTRUE(options$allowForeignObject)) remove_nodes("//*[local-name()='foreignObject']")
  if (isTRUE(options$removeEditorArtifacts)) {
    remove_nodes("//*[@id='selectorParentGroup' or @id='hover_group' or @id='canvasGrid' or @data-editor-only='1' or @data-dava-editor-ui='1']")
    remove_nodes("//*[contains(@class,'selector') or contains(@class,'selection') or contains(@class,'hover')]")
  }

  nodes <- xml2::xml_find_all(doc, "//*")
  for (node in nodes) {
    attrs <- xml2::xml_attrs(node)
    if (!length(attrs)) next
    for (attr_name in names(attrs)) {
      attr_value <- attrs[[attr_name]]
      lower_name <- tolower(attr_name)
      lower_value <- tolower(attr_value)
      if (grepl("^on", lower_name) ||
          lower_name %in% c("data-selection", "data-temp", "data-editor-only", "data-dava-editor-ui") ||
          grepl("javascript:", lower_value, fixed = TRUE)) {
        xml2::xml_attr(node, attr_name) <- NULL
      }
    }
  }
  svg_export_append_cjk_font_fallback(doc)

  width <- xml2::xml_attr(root, "width") %||% ""
  height <- xml2::xml_attr(root, "height") %||% ""
  viewBox <- xml2::xml_attr(root, "viewBox") %||% xml2::xml_attr(root, "viewbox") %||% ""
  numeric_width <- suppressWarnings(as.numeric(gsub("[^0-9.\\-]", "", width)))
  numeric_height <- suppressWarnings(as.numeric(gsub("[^0-9.\\-]", "", height)))
  if (!nzchar(viewBox)) {
    if (!is.finite(numeric_width) || numeric_width <= 0) numeric_width <- 960
    if (!is.finite(numeric_height) || numeric_height <= 0) numeric_height <- 720
    viewBox <- paste("0 0", numeric_width, numeric_height)
    xml2::xml_set_attr(root, "viewBox", viewBox)
  }
  if (!nzchar(width)) xml2::xml_set_attr(root, "width", if (is.finite(numeric_width)) as.character(numeric_width) else "960")
  if (!nzchar(height)) xml2::xml_set_attr(root, "height", if (is.finite(numeric_height)) as.character(numeric_height) else "720")

  background <- svg_export_option(options, "background", "white")
  if (background %in% c("white", "custom")) {
    color <- if (identical(background, "custom")) options$backgroundColor %||% "#ffffff" else "#ffffff"
    parts <- suppressWarnings(as.numeric(strsplit(trimws(viewBox), "\\s+|,")[[1]]))
    if (length(parts) >= 4 && all(is.finite(parts[1:4]))) {
      bg <- xml2::xml_add_child(root, "rect", .where = 0)
      xml2::xml_set_attr(bg, "x", as.character(parts[1]))
      xml2::xml_set_attr(bg, "y", as.character(parts[2]))
      xml2::xml_set_attr(bg, "width", as.character(parts[3]))
      xml2::xml_set_attr(bg, "height", as.character(parts[4]))
      xml2::xml_set_attr(bg, "fill", color)
      xml2::xml_set_attr(bg, "data-dava-export-background", "1")
    }
  }

  # Reuse the single full-tree traversal above instead of running five more XPath scans.
  node_names <- tolower(xml2::xml_name(nodes))
  stats <- list(
    pathCount = sum(node_names == "path"),
    textCount = sum(node_names %in% c("text", "tspan")),
    imageCount = sum(node_names == "image"),
    clipPathCount = sum(node_names == "clippath"),
    filterCount = sum(node_names == "filter")
  )
  list(svg = as.character(doc), warnings = warnings, stats = stats)
}
