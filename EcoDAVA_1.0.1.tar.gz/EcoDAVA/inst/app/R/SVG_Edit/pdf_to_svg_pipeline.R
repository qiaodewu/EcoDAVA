detect_pdf_vector_tools <- function() {
  find_tool <- function(name, extra_paths = character()) {
    candidates <- unique(as.character(c(unname(Sys.which(name)), extra_paths)))
    candidates <- candidates[!is.na(candidates) & nzchar(candidates)]
    candidates <- candidates[file.exists(candidates)]
    path <- if (length(candidates)) normalizePath(candidates[[1]], winslash = "/", mustWork = FALSE) else ""
    available <- isTRUE(nzchar(path)) && file.exists(path)
    version <- ""
    if (isTRUE(available)) {
      version <- tryCatch({
        args <- switch(name,
          pdf2svg = "--version",
          pdftocairo = "-v",
          inkscape = "--version",
          mutool = "-v",
          "--version"
        )
        out <- suppressWarnings(system2(path, args, stdout = TRUE, stderr = TRUE, timeout = 5))
        paste(head(out, 2), collapse = " ")
      }, error = function(e) "")
    }
    list(available = available, path = path, version = version)
  }

  local_appdata <- Sys.getenv("LOCALAPPDATA", unset = "")
  windows_winget_poppler <- if (nzchar(local_appdata)) {
    Sys.glob(file.path(local_appdata, "Microsoft", "WinGet", "Packages", "oschwartz10612.Poppler_*", "poppler-*", "Library", "bin", "pdftocairo.exe"))
  } else {
    character()
  }
  windows_poppler <- c(
    "C:/Program Files/poppler/Library/bin/pdftocairo.exe",
    "C:/Program Files/poppler/bin/pdftocairo.exe",
    "C:/tools/poppler/bin/pdftocairo.exe",
    windows_winget_poppler
  )
  windows_pdf2svg <- c(
    "C:/ProgramData/chocolatey/bin/pdf2svg.exe",
    "C:/ProgramData/chocolatey/lib/pdf2svg-win/tools/pdf2svg-windows-1.0/dist-64bits/pdf2svg.exe",
    "C:/ProgramData/chocolatey/lib/pdf2svg-win/tools/pdf2svg-windows-1.0/dist-32bits/pdf2svg.exe"
  )
  mac_paths <- list(
    pdf2svg = c("/opt/homebrew/bin/pdf2svg", "/usr/local/bin/pdf2svg",
      "/opt/local/bin/pdf2svg"),
    pdftocairo = c("/opt/homebrew/bin/pdftocairo",
      "/usr/local/bin/pdftocairo", "/opt/local/bin/pdftocairo"),
    inkscape = c("/Applications/Inkscape.app/Contents/MacOS/inkscape",
      "/opt/homebrew/bin/inkscape", "/usr/local/bin/inkscape"),
    mutool = c("/opt/homebrew/bin/mutool", "/usr/local/bin/mutool",
      "/opt/local/bin/mutool")
  )
  linux_paths <- list(
    pdf2svg = c("/usr/bin/pdf2svg", "/usr/local/bin/pdf2svg"),
    pdftocairo = c("/usr/bin/pdftocairo", "/usr/local/bin/pdftocairo"),
    inkscape = c("/usr/bin/inkscape", "/usr/local/bin/inkscape"),
    mutool = c("/usr/bin/mutool", "/usr/local/bin/mutool")
  )

  os <- Sys.info()[["sysname"]]
  if (is.null(os) || is.na(os)) os <- ""
  extra <- list(pdf2svg = character(), pdftocairo = character(), inkscape = character(), mutool = character())
  if (identical(os, "Windows")) {
    extra$pdf2svg <- windows_pdf2svg
    extra$pdftocairo <- windows_poppler
    extra$inkscape <- c(
      "C:/Program Files/Inkscape/bin/inkscape.exe",
      "C:/Program Files/Inkscape/bin/inkscape.com",
      "C:/Program Files/Inkscape/inkscape.exe"
    )
  }
  if (identical(os, "Darwin")) extra <- modifyList(extra, mac_paths)
  if (identical(os, "Linux")) extra <- modifyList(extra, linux_paths)

  tools <- list(
    pdf2svg = find_tool("pdf2svg", extra$pdf2svg),
    pdftocairo = find_tool("pdftocairo", extra$pdftocairo),
    inkscape = find_tool("inkscape", extra$inkscape),
    mutool = find_tool("mutool", extra$mutool)
  )
  order <- c("pdf2svg", "pdftocairo", "inkscape", "mutool")
  available_order <- order[vapply(order, function(x) isTRUE(tools[[x]]$available), logical(1))]
  primary <- if (length(available_order)) available_order[[1]] else NULL
  warnings <- character()
  if (is.null(primary)) {
    warnings <- c(warnings, "No PDF-to-SVG vector converter was found. Install Poppler (pdftocairo) or Inkscape, then restart DAVA.")
  }
  list(available = !is.null(primary), primary = primary, tools = tools, warnings = warnings)
}

detect_pdf_page_tools <- function() {
  extra_pdfinfo <- character()
  os <- Sys.info()[["sysname"]]
  if (is.null(os) || is.na(os)) os <- ""
  if (identical(os, "Windows")) {
    local_appdata <- Sys.getenv("LOCALAPPDATA", unset = "")
    winget_pdfinfo <- if (nzchar(local_appdata)) {
      Sys.glob(file.path(local_appdata, "Microsoft", "WinGet", "Packages", "oschwartz10612.Poppler_*", "poppler-*", "Library", "bin", "pdfinfo.exe"))
    } else {
      character()
    }
    extra_pdfinfo <- c(
      "C:/Program Files/poppler/Library/bin/pdfinfo.exe",
      "C:/Program Files/poppler/bin/pdfinfo.exe",
      "C:/tools/poppler/bin/pdfinfo.exe",
      winget_pdfinfo
    )
  } else if (identical(os, "Darwin")) {
    extra_pdfinfo <- c(
      "/opt/homebrew/bin/pdfinfo", "/usr/local/bin/pdfinfo",
      "/opt/local/bin/pdfinfo")
  } else if (identical(os, "Linux")) {
    extra_pdfinfo <- c("/usr/bin/pdfinfo", "/usr/local/bin/pdfinfo")
  }
  pick <- function(name, extra = character()) {
    candidates <- unique(as.character(c(unname(Sys.which(name)), extra)))
    candidates <- candidates[!is.na(candidates) & nzchar(candidates)]
    candidates <- candidates[file.exists(candidates)]
    if (length(candidates)) normalizePath(candidates[[1]], winslash = "/", mustWork = FALSE) else ""
  }
  list(pdfinfo = pick("pdfinfo", extra_pdfinfo), qpdf = pick("qpdf"), pdftk = pick("pdftk"))
}

pdf_import_compact_log <- function(x, max_chars = 1600) {
  text <- paste(as.character(x %||% character()), collapse = "\n")
  if (nchar(text, type = "chars") > max_chars) {
    text <- paste0(substr(text, 1, max_chars), "\n... [truncated]")
  }
  text
}

run_pdf_import_command <- function(exe, args, timeoutSec = 60) {
  if (is.null(exe) || length(exe) == 0 || is.na(exe[[1]]) || !nzchar(exe[[1]]) || !file.exists(exe[[1]])) {
    return(list(
      status = 127L,
      output = sprintf("Executable was not found: %s", as.character(exe %||% "")),
      command = paste(c(shQuote(as.character(exe %||% "")), shQuote(args)), collapse = " "),
      ok = FALSE,
      timedOut = FALSE
    ))
  }
  command <- paste(c(shQuote(exe), shQuote(args)), collapse = " ")
  status <- 0L
  timed_out <- FALSE
  output <- character()
  output <- tryCatch({
    out <- suppressWarnings(system2(exe, args, stdout = TRUE, stderr = TRUE, timeout = as.integer(timeoutSec %||% 60)))
    st <- attr(out, "status")
    if (!is.null(st)) status <<- as.integer(st)
    out
  }, warning = function(w) {
    msg <- conditionMessage(w)
    if (grepl("timed out|timeout", msg, ignore.case = TRUE)) timed_out <<- TRUE
    status <<- 124L
    msg
  }, error = function(e) {
    msg <- conditionMessage(e)
    if (grepl("timed out|timeout", msg, ignore.case = TRUE)) timed_out <<- TRUE
    status <<- 1L
    msg
  })
  list(
    status = status,
    output = paste(as.character(output), collapse = "\n"),
    command = command,
    ok = identical(status, 0L) && !isTRUE(timed_out),
    timedOut = isTRUE(timed_out)
  )
}

pdf_import_file_contains_svg <- function(path) {
  if (!file.exists(path) || file.info(path)$size <= 0) return(FALSE)
  con <- file(path, open = "rb")
  on.exit(close(con), add = TRUE)
  raw <- readBin(con, what = "raw", n = min(file.info(path)$size, 65536))
  text <- rawToChar(raw, multiple = FALSE)
  grepl("<svg\\b", text, ignore.case = TRUE, perl = TRUE)
}

resolve_converted_svg_output <- function(output_svg, prefix = NULL, page = 1) {
  page <- as.integer(page %||% 1)
  prefix <- prefix %||% sub("\\.svg$", "", output_svg, ignore.case = TRUE)
  candidates <- unique(c(
    output_svg,
    prefix,
    paste0(prefix, ".svg"),
    paste0(prefix, "-", page, ".svg"),
    paste0(prefix, "-", sprintf("%03d", page), ".svg")
  ))
  dir <- dirname(prefix)
  base <- basename(prefix)
  if (dir.exists(dir)) {
    matches <- list.files(dir, pattern = paste0("^", gsub("([][{}()+*^$|\\\\?.])", "\\\\\\1", base)), full.names = TRUE)
    matches <- matches[file.exists(matches) & file.info(matches)$size > 0]
    if (length(matches)) {
      matches <- matches[order(file.info(matches)$mtime, decreasing = TRUE)]
      candidates <- unique(c(candidates, matches))
    }
  }
  existing_svg <- candidates[file.exists(candidates) & file.info(candidates)$size > 0]
  existing_svg <- existing_svg[vapply(existing_svg, pdf_import_file_contains_svg, logical(1))]
  if (!length(existing_svg)) {
    return(list(ok = FALSE, output = output_svg, candidates = candidates, error = paste(
      "No converted SVG output was found. Checked:",
      paste(candidates, collapse = "; ")
    )))
  }
  made <- existing_svg[[1]]
  if (!identical(normalizePath(made, winslash = "/", mustWork = FALSE), normalizePath(output_svg, winslash = "/", mustWork = FALSE))) {
    file.copy(made, output_svg, overwrite = TRUE)
  }
  if (!pdf_import_file_contains_svg(output_svg)) {
    return(list(ok = FALSE, output = output_svg, candidates = candidates, error = "Converted output does not contain an SVG root."))
  }
  list(ok = TRUE, output = output_svg, actual = made, candidates = candidates, error = NULL)
}

pdf_import_first_matching_line <- function(output, pattern) {
  output <- as.character(output %||% character())
  output <- output[!is.na(output)]
  hit <- grep(pattern, output, value = TRUE, useBytes = TRUE)
  if (length(hit)) hit[[1]] else ""
}

get_pdf_page_count <- function(pdf_file) {
  tools <- detect_pdf_page_tools()
  if (nzchar(tools$pdfinfo)) {
    out <- tryCatch(system2(tools$pdfinfo, pdf_file, stdout = TRUE, stderr = TRUE, timeout = 10), error = function(e) character())
    pages <- sub("^Pages:\\s*", "", pdf_import_first_matching_line(out, "^Pages:\\s*"), useBytes = TRUE)
    pages <- suppressWarnings(as.integer(pages))
    if (is.finite(pages) && pages > 0) return(list(pageCount = pages, method = "pdfinfo", warnings = character()))
  }
  if (nzchar(tools$qpdf)) {
    out <- tryCatch(system2(tools$qpdf, c("--show-npages", pdf_file), stdout = TRUE, stderr = TRUE, timeout = 10), error = function(e) character())
    pages <- suppressWarnings(as.integer(trimws(out[1] %||% "")))
    if (is.finite(pages) && pages > 0) return(list(pageCount = pages, method = "qpdf", warnings = character()))
  }
  if (nzchar(tools$pdftk)) {
    out <- tryCatch(system2(tools$pdftk, c(pdf_file, "dump_data"), stdout = TRUE, stderr = TRUE, timeout = 10), error = function(e) character())
    pages <- sub("^NumberOfPages:\\s*", "", pdf_import_first_matching_line(out, "^NumberOfPages:\\s*"), useBytes = TRUE)
    pages <- suppressWarnings(as.integer(pages))
    if (is.finite(pages) && pages > 0) return(list(pageCount = pages, method = "pdftk", warnings = character()))
  }
  list(pageCount = NA_integer_, method = "manual", warnings = "PDF page count tool was not found. Please enter pages manually.")
}

parse_pdf_page_spec <- function(spec, page_count = NA_integer_) {
  spec <- trimws(as.character(spec %||% "1"))
  if (!nzchar(spec) || identical(tolower(spec), "current")) spec <- "1"
  if (identical(tolower(spec), "all")) {
    if (is.finite(page_count)) return(seq_len(page_count))
    stop("Unable to detect PDF page count. Please enter page numbers manually.")
  }
  pages <- integer()
  for (part in unlist(strsplit(spec, "[,;\\s]+"))) {
    if (!nzchar(part)) next
    if (grepl("^\\d+-\\d+$", part)) {
      ends <- as.integer(strsplit(part, "-", fixed = TRUE)[[1]])
      pages <- c(pages, seq(min(ends), max(ends)))
    } else {
      pages <- c(pages, suppressWarnings(as.integer(part)))
    }
  }
  pages <- unique(pages[is.finite(pages) & pages > 0])
  if (is.finite(page_count) && any(pages > page_count)) {
    stop(sprintf("Selected page exceeds the PDF page count (%s).", page_count))
  }
  if (is.finite(page_count)) pages <- pages[pages <= page_count]
  pages
}

pdf_import_engine_order <- function(engine = "auto", textMode = "preserve-text", tools = detect_pdf_vector_tools()) {
  available <- names(tools$tools)[vapply(tools$tools, function(x) {
    isTRUE(x$available) && isTRUE(nzchar(x$path)) && file.exists(x$path)
  }, logical(1))]
  if (!identical(engine %||% "auto", "auto")) {
    if (!engine %in% names(tools$tools) || !engine %in% available) {
      stop(sprintf("Requested PDF conversion engine '%s' is not available.", engine))
    }
    return(engine)
  }
  # Inkscape's PDF importer preserves text objects and font attributes more
  # reliably than Cairo/pdf2svg; Cairo remains the fast visual fallback.
  preferred <- c("inkscape", "pdftocairo", "pdf2svg", "mutool")
  preferred[preferred %in% available]
}

convert_pdf_page_to_svg <- function(pdf_file, page, output_svg, options = list()) {
  stopifnot(file.exists(pdf_file))
  page <- as.integer(page %||% 1)
  if (!is.finite(page) || page < 1) stop("Invalid PDF page.")
  options <- modifyList(list(
    engine = "auto",
    textMode = "preserve-text",
    cropMode = "page",
    cleanLevel = "standard",
    keepImages = TRUE,
    timeoutSec = 60
  ), options)
  tools <- detect_pdf_vector_tools()
  engines <- pdf_import_engine_order(options$engine %||% "auto", options$textMode, tools)
  if (!length(engines)) stop("No available PDF vector conversion engine. Please install Poppler (pdftocairo) or Inkscape and restart DAVA.")
  engine <- engines[[1]]
  exe <- tools$tools[[engine]]$path
  if (is.null(exe) || length(exe) == 0 || is.na(exe[[1]]) || !nzchar(exe[[1]]) || !file.exists(exe[[1]])) {
    stop(sprintf("Selected PDF conversion engine '%s' was not found on disk.", engine))
  }
  unlink(output_svg, force = TRUE)
  timeout <- as.integer(options$timeoutSec %||% 60)
  prefix <- sub("\\.svg$", "", output_svg, ignore.case = TRUE)
  run <- NULL
  if (identical(engine, "pdf2svg")) {
    run <- run_pdf_import_command(exe, c(pdf_file, output_svg, as.character(page)), timeout)
  } else if (identical(engine, "pdftocairo")) {
    run <- run_pdf_import_command(exe, c("-svg", "-f", as.character(page), "-l", as.character(page), pdf_file, prefix), timeout)
  } else if (identical(engine, "inkscape")) {
    args <- c(
      pdf_file,
      paste0("--pages=", page),
      "--export-type=svg",
      "--export-plain-svg",
      paste0("--export-filename=", output_svg)
    )
    if (identical(options$textMode, "outline-text")) {
      args <- c(args, "--export-text-to-path")
    } else {
      args <- c(args, "--pdf-font-strategy=keep")
    }
    run <- run_pdf_import_command(exe, args, timeout)
  } else if (identical(engine, "mutool")) {
    run <- run_pdf_import_command(exe, c("convert", "-o", output_svg, pdf_file, as.character(page)), timeout)
  } else {
    stop("Unsupported PDF conversion engine.")
  }
  resolved <- resolve_converted_svg_output(output_svg, prefix, page)
  if (!isTRUE(run$ok) || !isTRUE(resolved$ok)) {
    stop(paste(
      sprintf("PDF conversion failed. engine=%s page=%s", engine, page),
      paste0("command: ", run$command),
      paste0("status: ", run$status),
      if (isTRUE(run$timedOut)) "timeout: true" else NULL,
      paste0("output: ", pdf_import_compact_log(run$output)),
      if (!isTRUE(resolved$ok)) paste0("resolver: ", resolved$error) else NULL,
      sep = "\n"
    ))
  }
  list(ok = TRUE, engine = engine, output_svg = output_svg, actual_output = resolved$actual,
    command = run$command, status = run$status, log = pdf_import_compact_log(run$output))
}
