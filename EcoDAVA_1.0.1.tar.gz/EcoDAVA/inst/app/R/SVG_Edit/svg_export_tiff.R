svg_export_pixel_dimensions <- function(svg_string, dpi = 600, width = NULL, height = NULL) {
  dims <- svg_export_dimensions(svg_string)
  dpi <- max(150, as.numeric(dpi %||% 600))
  if (!is.null(width) && !is.null(height) && is.finite(as.numeric(width)) && is.finite(as.numeric(height))) {
    return(list(pixelWidth = as.integer(width), pixelHeight = as.integer(height), dpi = dpi, svg = dims))
  }
  # SVG px are treated as CSS px at 96 dpi.
  list(
    pixelWidth = max(1L, as.integer(round(dims$width / 96 * dpi))),
    pixelHeight = max(1L, as.integer(round(dims$height / 96 * dpi))),
    dpi = dpi,
    svg = dims
  )
}

export_svg_to_tiff <- function(svg_string, output_tiff, options = list()) {
  options <- modifyList(list(
    dpi = 600,
    width = NULL,
    height = NULL,
    unit = "px",
    background = "white",
    backgroundColor = "#ffffff",
    compression = "lzw",
    colorspace = "rgb",
    antialias = TRUE,
    engine = "auto",
    timeoutSec = 120
  ), options %||% list())
  warnings <- character()
  dpi <- as.numeric(options$dpi %||% 600)
  if (!is.finite(dpi)) dpi <- 600
  if (dpi < 150) {
    dpi <- 150
    warnings <- c(warnings, "DPI was raised to the minimum supported value: 150.")
  }
  if (dpi > 1200) warnings <- c(warnings, "DPI is above 1200; output TIFF may be very large.")
  cleaned <- clean_svg_for_export(svg_string, options)
  warnings <- c(warnings, cleaned$warnings)
  dims <- svg_export_pixel_dimensions(cleaned$svg, dpi, options$width, options$height)
  cleaned_svg <- svg_export_write_temp_svg(cleaned$svg)
  on.exit(unlink(cleaned_svg, force = TRUE), add = TRUE)
  unlink(output_tiff, force = TRUE)

  compression <- tolower(options$compression %||% "lzw")
  compression <- if (compression %in% c("zip", "none", "lzw")) compression else "lzw"
  colorspace <- tolower(options$colorspace %||% "rgb")
  colorspace <- if (colorspace %in% c("rgb", "cmyk")) colorspace else "rgb"

  if (requireNamespace("rsvg", quietly = TRUE) && requireNamespace("magick", quietly = TRUE)) {
    png_tmp <- tempfile("dava-export-", fileext = ".png")
    on.exit(unlink(png_tmp, force = TRUE), add = TRUE)
    rsvg::rsvg_png(cleaned_svg, png_tmp, width = dims$pixelWidth, height = dims$pixelHeight)
    img <- magick::image_read(png_tmp)
    if (identical(options$background, "white") || identical(options$background, "custom")) {
      bg <- if (identical(options$background, "custom")) options$backgroundColor %||% "white" else "white"
      img <- magick::image_background(img, bg, flatten = TRUE)
    }
    if (identical(colorspace, "cmyk")) {
      img <- tryCatch(magick::image_convert(img, colorspace = "cmyk"), error = function(e) {
        warnings <<- c(warnings, paste("CMYK conversion failed; exported RGB TIFF instead:", conditionMessage(e)))
        img
      })
    }
    defines <- character()
    if (identical(compression, "lzw")) defines <- c(defines, "tiff:compression=lzw")
    if (identical(compression, "zip")) defines <- c(defines, "tiff:compression=zip")
    magick::image_write(img, path = output_tiff, format = "tiff", density = as.character(dpi), defines = defines)
  } else if (requireNamespace("rsvg", quietly = TRUE) && isTRUE(capabilities("tiff"))) {
    if (identical(colorspace, "cmyk")) {
      warnings <- c(warnings, "CMYK TIFF requires magick/ImageMagick; exported RGB TIFF with grDevices fallback.")
      colorspace <- "rgb"
    }
    warnings <- c(warnings, "TIFF was exported with rsvg + grDevices fallback. Advanced compression metadata may be limited; install magick for full TIFF controls.")
    bitmap <- rsvg::rsvg(cleaned_svg, width = dims$pixelWidth, height = dims$pixelHeight)
    raster <- grDevices::as.raster(bitmap)
    comp <- switch(compression, lzw = "lzw", zip = "zip", none = "none", "lzw")
    opened <- tryCatch({
      grDevices::tiff(output_tiff, width = dims$pixelWidth, height = dims$pixelHeight, units = "px", res = dpi, compression = comp)
      TRUE
    }, error = function(e) {
      warnings <<- c(warnings, paste("Requested TIFF compression is unavailable; retried without compression:", conditionMessage(e)))
      grDevices::tiff(output_tiff, width = dims$pixelWidth, height = dims$pixelHeight, units = "px", res = dpi, compression = "none")
      TRUE
    })
    if (isTRUE(opened)) {
      oldpar <- graphics::par(mar = c(0, 0, 0, 0), xaxs = "i", yaxs = "i")
      on.exit(graphics::par(oldpar), add = TRUE)
      graphics::plot.new()
      graphics::plot.window(xlim = c(0, 1), ylim = c(0, 1), asp = NA)
      graphics::rasterImage(raster, 0, 0, 1, 1, interpolate = isTRUE(options$antialias))
      grDevices::dev.off()
    }
  } else {
    tools <- detect_svg_export_tools()
    exe <- tools$tiff$engines$imagemagick_cli$path
    if (!nzchar(exe)) stop("TIFF export requires R packages rsvg + magick, or ImageMagick CLI.", call. = FALSE)
    density <- as.character(dpi)
    resize <- paste0(dims$pixelWidth, "x", dims$pixelHeight)
    args <- c("-density", density, "-background", if (identical(options$background, "transparent")) "none" else options$backgroundColor %||% "white", cleaned_svg, "-resize", resize)
    if (identical(compression, "lzw")) args <- c(args, "-compress", "LZW")
    else if (identical(compression, "zip")) args <- c(args, "-compress", "Zip")
    else args <- c(args, "-compress", "None")
    if (identical(colorspace, "cmyk")) args <- c(args, "-colorspace", "CMYK")
    args <- c(args, output_tiff)
    res <- svg_export_run(exe, args, as.integer(options$timeoutSec %||% 120))
    if (res$status != 0) stop(paste("ImageMagick TIFF export failed.", res$output), call. = FALSE)
  }
  if (!file.exists(output_tiff) || file.info(output_tiff)$size <= 0) {
    stop("TIFF export produced an empty file.", call. = FALSE)
  }
  info <- svg_export_file_info(output_tiff)
  list(
    success = TRUE,
    output = output_tiff,
    dpi = dpi,
    pixelWidth = dims$pixelWidth,
    pixelHeight = dims$pixelHeight,
    compression = compression,
    colorspace = colorspace,
    file_size = info$size,
    warnings = warnings,
    stats = cleaned$stats
  )
}
