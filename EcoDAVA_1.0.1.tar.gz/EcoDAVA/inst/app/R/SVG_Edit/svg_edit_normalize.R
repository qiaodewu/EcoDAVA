# SVG normalization helpers for importing R plots into SVG-Edit.
# This file intentionally contains only R-side conversion utilities. It does
# not wire UI controls, iframe behavior, or JavaScript bridge calls.

if (!exists("%||%", mode = "function")) {
  `%||%` <- function(x, y) if (is.null(x)) y else x
}

dava_require_svg_package <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    stop(
      "Package '", pkg, "' is required for SVG-Edit import normalization. ",
      "Please install it with install.packages(\"", pkg, "\").",
      call. = FALSE
    )
  }
  invisible(TRUE)
}

dava_as_utf8_text <- function(x) {
  x <- paste(enc2utf8(as.character(x)), collapse = "\n")
  Encoding(x) <- "UTF-8"
  x
}

dava_strip_xml_declaration <- function(svg_text) {
  svg_text <- dava_as_utf8_text(svg_text)
  sub("^\\s*<\\?xml[^>]*\\?>\\s*", "", svg_text, perl = TRUE)
}

dava_xml_escape_attr <- function(x) {
  x <- as.character(x)
  x <- gsub("&", "&amp;", x, fixed = TRUE)
  x <- gsub("\"", "&quot;", x, fixed = TRUE)
  x <- gsub("<", "&lt;", x, fixed = TRUE)
  x <- gsub(">", "&gt;", x, fixed = TRUE)
  x
}

dava_ensure_svg_namespace_attrs <- function(svg_text, needs_xlink = FALSE) {
  svg_text <- dava_strip_xml_declaration(svg_text)
  if (!grepl("^\\s*<svg\\b", svg_text, perl = TRUE)) {
    return(svg_text)
  }

  if (!grepl("^\\s*<svg\\b[^>]*\\sxmlns\\s*=", svg_text, perl = TRUE)) {
    svg_text <- sub(
      "^(\\s*<svg\\b)",
      "\\1 xmlns=\"http://www.w3.org/2000/svg\"",
      svg_text,
      perl = TRUE
    )
  }

  if (isTRUE(needs_xlink) && !grepl("^\\s*<svg\\b[^>]*\\sxmlns:xlink\\s*=", svg_text, perl = TRUE)) {
    svg_text <- sub(
      "^(\\s*<svg\\b)",
      "\\1 xmlns:xlink=\"http://www.w3.org/1999/xlink\"",
      svg_text,
      perl = TRUE
    )
  }

  svg_text
}

dava_regex_escape <- function(x) {
  gsub("([][{}()+*^$|\\\\?.])", "\\\\\\1", x, perl = TRUE)
}

dava_format_svg_number <- function(x) {
  x <- suppressWarnings(as.numeric(x))
  if (!is.finite(x)) {
    return("0")
  }
  sub("\\.?0+$", "", sprintf("%.6f", x))
}

dava_svg_attr <- function(attrs, name, default = NA_character_) {
  if (!is.null(attrs) && length(attrs) > 0 && name %in% names(attrs)) {
    unname(attrs[[name]])
  } else {
    default
  }
}

dava_parse_svg_length <- function(value, default = NA_real_) {
  if (is.null(value) || length(value) == 0 || is.na(value)) {
    return(default)
  }

  value <- trimws(as.character(value[[1]]))
  if (!nzchar(value) || grepl("%$", value)) {
    return(default)
  }

  match <- regexec("^([-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?)\\s*([A-Za-z]*)", value, perl = TRUE)
  parts <- regmatches(value, match)[[1]]
  if (length(parts) < 2) {
    return(default)
  }

  number <- suppressWarnings(as.numeric(parts[[2]]))
  if (!is.finite(number)) {
    return(default)
  }

  unit <- tolower(if (length(parts) >= 3) parts[[3]] else "")
  if (unit %in% c("", "px")) {
    number
  } else if (unit == "pt") {
    number * 96 / 72
  } else if (unit == "pc") {
    number * 16
  } else if (unit == "in") {
    number * 96
  } else if (unit == "cm") {
    number * 96 / 2.54
  } else if (unit == "mm") {
    number * 96 / 25.4
  } else {
    number
  }
}

dava_parse_viewbox_size <- function(view_box) {
  if (is.null(view_box) || length(view_box) == 0 || is.na(view_box) || !nzchar(trimws(view_box))) {
    return(c(width = NA_real_, height = NA_real_))
  }

  nums <- suppressWarnings(as.numeric(strsplit(trimws(view_box), "[,[:space:]]+", perl = TRUE)[[1]]))
  nums <- nums[is.finite(nums)]
  if (length(nums) >= 4) {
    c(width = nums[[3]], height = nums[[4]])
  } else {
    c(width = NA_real_, height = NA_real_)
  }
}

dava_read_svg_root <- function(svg_text) {
  dava_require_svg_package("xml2")

  svg_text <- dava_strip_xml_declaration(svg_text)
  needs_xlink <- grepl("\\bxlink:href\\s*=", svg_text, perl = TRUE)
  svg_text <- dava_ensure_svg_namespace_attrs(
    svg_text, needs_xlink = needs_xlink)
  doc <- tryCatch(
    xml2::read_xml(svg_text, options = c("RECOVER", "NOERROR", "NOWARNING", "HUGE")),
    error = function(e) {
      stop("Unable to parse SVG text: ", conditionMessage(e), call. = FALSE)
    }
  )

  root <- xml2::xml_root(doc)
  if (identical(xml2::xml_name(root), "svg")) {
    return(root)
  }

  svg_nodes <- xml2::xml_find_all(root, ".//*[local-name()='svg']")
  if (length(svg_nodes) < 1) {
    stop("SVG text does not contain an <svg> root node.", call. = FALSE)
  }
  if (length(svg_nodes) > 1) {
    stop("SVG text contains multiple <svg> nodes; a single SVG root is required.", call. = FALSE)
  }

  svg_nodes[[1]]
}

dava_extract_svg_size <- function(svg_text, default_width = 800, default_height = 560) {
  root <- if (inherits(svg_text, "xml_node")) {
    svg_text
  } else {
    dava_read_svg_root(svg_text)
  }

  attrs <- xml2::xml_attrs(root)
  view_box <- dava_svg_attr(attrs, "viewBox", dava_svg_attr(attrs, "viewbox", NA_character_))
  view_box_size <- dava_parse_viewbox_size(view_box)

  width <- dava_parse_svg_length(dava_svg_attr(attrs, "width", NA_character_), default = NA_real_)
  height <- dava_parse_svg_length(dava_svg_attr(attrs, "height", NA_character_), default = NA_real_)

  if (!is.finite(width) && is.finite(view_box_size[["width"]])) {
    width <- view_box_size[["width"]]
  }
  if (!is.finite(height) && is.finite(view_box_size[["height"]])) {
    height <- view_box_size[["height"]]
  }
  if (!is.finite(width)) {
    width <- default_width
  }
  if (!is.finite(height)) {
    height <- default_height
  }

  list(
    width = width,
    height = height,
    viewBox = if (is.na(view_box) || !nzchar(trimws(view_box))) {
      paste("0 0", dava_format_svg_number(width), dava_format_svg_number(height))
    } else {
      trimws(view_box)
    }
  )
}

dava_remove_unsafe_svg_nodes <- function(svg_root) {
  unsafe_nodes <- xml2::xml_find_all(
    svg_root,
    ".//*[local-name()='script' or local-name()='foreignObject' or local-name()='metadata' or local-name()='desc']"
  )
  if (length(unsafe_nodes) > 0) {
    for (unsafe_node in as.list(unsafe_nodes)) {
      xml2::xml_remove(unsafe_node)
    }
  }
  invisible(svg_root)
}

dava_clean_svg_style_external_refs <- function(svg_root) {
  style_nodes <- xml2::xml_find_all(svg_root, ".//*[local-name()='style']")
  for (style_node in as.list(style_nodes)) {
    style_text <- xml2::xml_text(style_node)
    style_text <- gsub("@import\\s+url\\([^;]+\\)\\s*;?", "", style_text, ignore.case = TRUE, perl = TRUE)
    style_text <- gsub("@import\\s+['\"][^'\"]+['\"]\\s*;?", "", style_text, ignore.case = TRUE, perl = TRUE)
    style_text <- gsub("url\\(\\s*['\"]?https?://[^\\)]+\\)", "none", style_text, ignore.case = TRUE, perl = TRUE)
    xml2::xml_text(style_node) <- style_text
  }
  invisible(svg_root)
}

dava_materialize_svg_presentation_styles <- function(svg_root) {
  presentation_attrs <- c(
    "fill", "fill-opacity", "fill-rule",
    "stroke", "stroke-opacity", "stroke-width", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-dasharray",
    "opacity", "font-family", "font-size", "font-style", "font-weight", "text-anchor"
  )
  styled_nodes <- xml2::xml_find_all(svg_root, ".//*[@style]")
  for (node in as.list(styled_nodes)) {
    style <- xml2::xml_attr(node, "style")
    if (is.na(style) || !nzchar(trimws(style))) next
    declarations <- strsplit(style, ";", fixed = TRUE)[[1]]
    for (declaration in declarations) {
      parts <- strsplit(declaration, ":", fixed = TRUE)[[1]]
      if (length(parts) < 2) next
      name <- tolower(trimws(parts[[1]]))
      if (!name %in% presentation_attrs) next
      value <- trimws(paste(parts[-1], collapse = ":"))
      if (!nzchar(value)) next
      if (name %in% c("fill", "stroke") && identical(tolower(value), "transparent")) value <- "none"
      xml2::xml_set_attr(node, name, value)
    }
  }
  invisible(svg_root)
}

dava_materialize_svglite_shape_defaults <- function(svg_root) {
  svglite_groups <- xml2::xml_find_all(
    svg_root,
    ".//*[local-name()='g' and contains(concat(' ', normalize-space(@class), ' '), ' svglite ')]"
  )
  if (length(svglite_groups) == 0) return(invisible(svg_root))

  defaults <- c(
    fill = "none",
    stroke = "#000000",
    `stroke-linecap` = "round",
    `stroke-linejoin` = "round",
    `stroke-miterlimit` = "10.00"
  )
  for (group in as.list(svglite_groups)) {
    shape_test <- "local-name()='line' or local-name()='polyline' or local-name()='polygon' or local-name()='path' or local-name()='rect' or local-name()='circle'"
    for (attr_name in names(defaults)) {
      missing_attr <- xml2::xml_find_all(
        group,
        sprintf(".//*[(%s) and not(@%s)]", shape_test, attr_name)
      )
      if (length(missing_attr) > 0) {
        xml2::xml_set_attr(missing_attr, attr_name, unname(defaults[[attr_name]]))
      }
    }
  }

  style_nodes <- xml2::xml_find_all(svg_root, ".//*[local-name()='style']")
  for (style_node in as.list(style_nodes)) {
    css <- xml2::xml_text(style_node)
    if (!grepl("\\.svglite\\s+line\\s*,", css, perl = TRUE)) next
    css <- sub("\\.svglite\\s+line\\s*,[\\s\\S]*?\\}", "", css, perl = TRUE)
    xml2::xml_text(style_node) <- css
  }
  invisible(svg_root)
}

dava_make_svg_backgrounds_explicitly_transparent <- function(svg_root) {
  background_rects <- xml2::xml_find_all(
    svg_root,
    ".//*[local-name()='rect' and not(ancestor::*[local-name()='defs' or local-name()='clipPath' or local-name()='mask' or local-name()='pattern'])]"
  )
  for (rect in as.list(background_rects)) {
    fill <- xml2::xml_attr(rect, "fill")
    fill_opacity <- suppressWarnings(as.numeric(xml2::xml_attr(rect, "fill-opacity")))
    style <- xml2::xml_attr(rect, "style")
    style_zero_opacity <- !is.na(style) && grepl(
      "(^|;)\\s*fill-opacity\\s*:\\s*(0+(?:\\.0*)?|\\.0+)\\s*(;|$)",
      style,
      ignore.case = TRUE,
      perl = TRUE
    )
    explicit_transparent_fill <- !is.na(fill) &&
      tolower(trimws(fill)) %in% c("none", "transparent", "rgba(0,0,0,0)", "rgba(255,255,255,0)")
    fully_transparent <- explicit_transparent_fill ||
      (length(fill_opacity) == 1 && is.finite(fill_opacity) && fill_opacity <= 0) ||
      style_zero_opacity
    if (!fully_transparent) next

    xml2::xml_set_attr(rect, "fill", "none")
    xml2::xml_set_attr(rect, "fill-opacity", "0")
    xml2::xml_set_attr(rect, "data-dava-background", "transparent")
    if (!is.na(style) && nzchar(style)) {
      style <- gsub(
        "(^|;)\\s*fill\\s*:[^;]*",
        "\\1 fill: none",
        style,
        ignore.case = TRUE,
        perl = TRUE
      )
      style <- gsub(
        "(^|;)\\s*fill-opacity\\s*:[^;]*",
        "\\1 fill-opacity: 0",
        style,
        ignore.case = TRUE,
        perl = TRUE
      )
      xml2::xml_set_attr(rect, "style", style)
    }
  }
  invisible(svg_root)
}

dava_enforce_marked_svg_backgrounds <- function(svg_root) {
  background_rects <- xml2::xml_find_all(
    svg_root,
    paste0(
      ".//*[local-name()='rect' and (",
      "@data-dava-r-device-role='plot_background' or ",
      "@data-dava-r-device-role='coordinate_background' or ",
      "@data-dava-background-region='plot_background' or ",
      "@data-dava-background-region='coordinate_background' or ",
      "@data-dava-background='transparent')]"
    )
  )
  for (rect in as.list(background_rects)) {
    xml2::xml_set_attr(rect, "fill", "none")
    xml2::xml_set_attr(rect, "fill-opacity", "0")
    xml2::xml_set_attr(rect, "opacity", "1")
    xml2::xml_set_attr(rect, "data-dava-background", "transparent")

    # BackgroundnodeStrictly placed at the end of the same parent layerBottom，Avoid overwriting coordinates、Dataandtextobject。
    parent <- xml2::xml_parent(rect)
    if (!inherits(parent, "xml_missing")) {
      xml2::xml_add_child(parent, rect, .where = 0)
      xml2::xml_remove(rect)
    }
  }
  invisible(svg_root)
}

dava_make_safe_svg_id <- function(x, fallback = NULL) {
  if (is.null(x) || length(x) == 0 || is.na(x) || !nzchar(trimws(as.character(x[[1]])))) {
    x <- fallback %||% paste0("dava-svg-", format(Sys.time(), "%Y%m%d-%H%M%S"))
  }

  x <- gsub("[^A-Za-z0-9_-]+", "-", as.character(x[[1]]), perl = TRUE)
  x <- gsub("^-+|-+$", "", x)
  if (!nzchar(x)) {
    x <- fallback %||% paste0("dava-svg-", format(Sys.time(), "%Y%m%d-%H%M%S"))
  }
  if (grepl("^[0-9]", x)) {
    x <- paste0("dava-", x)
  }
  x
}

dava_make_unique_import_id <- function(prefix = "dava-r-plot") {
  suffix <- paste(sample(c(0:9, letters), 8, replace = TRUE), collapse = "")
  dava_make_safe_svg_id(paste(prefix, format(Sys.time(), "%Y%m%d-%H%M%S"), suffix, sep = "-"))
}

dava_plot_to_svg_string <- function(plot_obj = NULL,
                                    plot_expr = NULL,
                                    width = 10,
                                    height = 7,
                                    pointsize = 12,
                                    bg = "transparent") {
  dava_require_svg_package("svglite")
  dava_require_svg_package("xml2")

  plot_expr_code <- substitute(plot_expr)
  has_plot_expr <- !missing(plot_expr) && !identical(plot_expr_code, quote(NULL))
  has_plot_obj <- !is.null(plot_obj)

  if (!has_plot_obj && !has_plot_expr) {
    stop("No R plot object or plot expression provided.", call. = FALSE)
  }

  tmp <- tempfile(fileext = ".svg")
  on.exit(unlink(tmp), add = TRUE)

  device_id <- NULL
  on.exit({
    if (!is.null(device_id)) {
      open_devices <- grDevices::dev.list()
      if (!is.null(open_devices) && device_id %in% open_devices) {
        grDevices::dev.set(device_id)
        grDevices::dev.off()
      }
    }
  }, add = TRUE)

  svglite::svglite(filename = tmp, width = width, height = height, pointsize = pointsize, bg = bg)
  device_id <- grDevices::dev.cur()

  if (has_plot_expr) {
    expr_value <- eval(plot_expr_code, envir = parent.frame())
    if (is.call(expr_value) || is.expression(expr_value)) {
      eval(expr_value, envir = parent.frame())
    }
  } else if (inherits(plot_obj, "ggplot")) {
    transparent_theme <- ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = "transparent", color = NA),
      panel.background = ggplot2::element_rect(fill = "transparent", color = NA),
      legend.background = ggplot2::element_rect(fill = "transparent", color = NA),
      legend.key = ggplot2::element_rect(fill = "transparent", color = NA)
    )
    render_plot <- if (inherits(plot_obj, "patchwork")) plot_obj & transparent_theme else plot_obj + transparent_theme
    print(render_plot)
  } else if (inherits(plot_obj, "recordedplot")) {
    grDevices::replayPlot(plot_obj)
  } else {
    print(plot_obj)
  }

  grDevices::dev.off()
  device_id <- NULL

  if (!file.exists(tmp)) {
    stop("svglite did not produce an SVG file.", call. = FALSE)
  }

  svg_text <- paste(readLines(tmp, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
  dava_as_utf8_text(svg_text)
}

dava_clean_svg_for_svgedit <- function(svg_text,
                                       default_width = 800,
                                       default_height = 560) {
  dava_require_svg_package("xml2")
  if (is.null(svg_text) || length(svg_text) == 0 || !nzchar(trimws(paste(svg_text, collapse = "")))) {
    stop("svg_text must be a non-empty SVG string.", call. = FALSE)
  }

  root <- dava_read_svg_root(svg_text)
  dava_remove_unsafe_svg_nodes(root)
  dava_clean_svg_style_external_refs(root)
  dava_materialize_svg_presentation_styles(root)
  dava_materialize_svglite_shape_defaults(root)
  dava_make_svg_backgrounds_explicitly_transparent(root)
  dava_enforce_marked_svg_backgrounds(root)

  size <- dava_extract_svg_size(root, default_width = default_width, default_height = default_height)
  xml2::xml_set_attr(root, "width", dava_format_svg_number(size$width))
  xml2::xml_set_attr(root, "height", dava_format_svg_number(size$height))
  xml2::xml_set_attr(root, "viewBox", size$viewBox)

  root_text <- as.character(root)
  needs_xlink <- grepl("\\bxlink:href\\s*=", root_text, perl = TRUE)

  out <- dava_ensure_svg_namespace_attrs(as.character(root), needs_xlink = needs_xlink)
  out <- sub("^\\s+", "", out, perl = TRUE)
  if (!grepl("^<svg\\b", out, perl = TRUE)) {
    stop("Cleaned SVG output must start with an <svg> root node.", call. = FALSE)
  }
  dava_as_utf8_text(out)
}

dava_prefix_svg_ids <- function(svg_text, prefix) {
  dava_require_svg_package("xml2")

  if (missing(prefix) || is.null(prefix) || !nzchar(trimws(as.character(prefix)))) {
    prefix <- paste0("dava-import-", format(Sys.time(), "%Y%m%d-%H%M%S"), "-", paste(sample(c(0:9, letters), 6, TRUE), collapse = ""))
  }
  prefix <- dava_make_safe_svg_id(prefix, fallback = "dava-import")

  root <- dava_read_svg_root(svg_text)
  id_nodes <- xml2::xml_find_all(root, ".//*[@id]")
  if (length(id_nodes) == 0) {
    return(dava_as_utf8_text(dava_strip_xml_declaration(as.character(root))))
  }

  old_ids <- character()
  new_ids <- character()
  for (node in as.list(id_nodes)) {
    old_id <- xml2::xml_attr(node, "id")
    if (is.na(old_id) || !nzchar(old_id)) {
      next
    }

    safe_old_id <- dava_make_safe_svg_id(old_id, fallback = "svg-id")
    new_id <- if (startsWith(old_id, paste0(prefix, "-"))) {
      old_id
    } else {
      paste0(prefix, "-", safe_old_id)
    }

    xml2::xml_set_attr(node, "id", new_id)
    old_ids <- c(old_ids, old_id)
    new_ids <- c(new_ids, new_id)
  }

  id_map <- stats::setNames(new_ids, old_ids)

  replace_refs <- function(value, attr_name = "") {
    if (is.null(value) || is.na(value) || !nzchar(value)) {
      return(value)
    }
    id_list_attr <- attr_name %in% c("aria-labelledby", "aria-describedby")
    if (!id_list_attr && !grepl("#", value, fixed = TRUE)) {
      return(value)
    }

    out <- value
    for (old_id in names(id_map)) {
      new_id <- unname(id_map[[old_id]])
      if (identical(old_id, new_id)) {
        next
      }
      old_rx <- dava_regex_escape(old_id)
      out <- gsub(
        paste0("url\\(\\s*#", old_rx, "\\s*\\)"),
        paste0("url(#", new_id, ")"),
        out,
        perl = TRUE
      )
      if (attr_name %in% c("href", "xlink:href") && identical(out, paste0("#", old_id))) {
        out <- paste0("#", new_id)
      }
      if (id_list_attr) {
        tokens <- strsplit(out, "\\s+", perl = TRUE)[[1]]
        tokens[tokens == old_id] <- new_id
        out <- paste(tokens, collapse = " ")
      }
    }
    out
  }

  all_nodes <- c(list(root), as.list(xml2::xml_find_all(root, ".//*")))
  for (node in all_nodes) {
    attrs <- xml2::xml_attrs(node)
    if (length(attrs) > 0) {
      for (attr_name in names(attrs)) {
        new_value <- replace_refs(unname(attrs[[attr_name]]), attr_name)
        if (!identical(new_value, unname(attrs[[attr_name]]))) {
          xml2::xml_set_attr(node, attr_name, new_value)
        }
      }
    }
  }

  style_nodes <- xml2::xml_find_all(root, ".//*[local-name()='style']")
  for (style_node in as.list(style_nodes)) {
    xml2::xml_text(style_node) <- replace_refs(xml2::xml_text(style_node), "style")
  }

  dava_as_utf8_text(dava_strip_xml_declaration(as.character(root)))
}

dava_wrap_svg_for_svgedit_import <- function(svg_text,
                                             object_id = NULL,
                                             x_offset = 0,
                                             y_offset = 0,
                                             group_first = TRUE,
                                             already_clean = FALSE,
                                             validate_output = TRUE) {
  dava_require_svg_package("xml2")

  cleaned_svg <- if (isTRUE(already_clean)) {
    dava_as_utf8_text(paste(svg_text, collapse = "\n"))
  } else {
    dava_clean_svg_for_svgedit(svg_text)
  }
  root <- dava_read_svg_root(cleaned_svg)
  size <- dava_extract_svg_size(root)

  object_id <- dava_make_safe_svg_id(object_id, fallback = dava_make_unique_import_id())
  edit_policy <- if (isTRUE(group_first)) "group-first" else "free-edit"

  children <- xml2::xml_children(root)
  child_list <- as.list(children)
  defs_text <- vapply(
    child_list[vapply(child_list, function(child) identical(xml2::xml_name(child), "defs"), logical(1))],
    as.character,
    character(1)
  )
  body_text <- vapply(
    child_list[!vapply(child_list, function(child) identical(xml2::xml_name(child), "defs"), logical(1))],
    as.character,
    character(1)
  )

  root_attrs <- paste0(
    "xmlns=\"http://www.w3.org/2000/svg\"",
    if (grepl("\\bxlink:href\\s*=", as.character(root), perl = TRUE)) {
      " xmlns:xlink=\"http://www.w3.org/1999/xlink\""
    } else {
      ""
    },
    " width=\"", dava_format_svg_number(size$width), "\"",
    " height=\"", dava_format_svg_number(size$height), "\"",
    " viewBox=\"", dava_xml_escape_attr(size$viewBox), "\""
  )

  group_attrs <- paste0(
    "id=\"", dava_xml_escape_attr(object_id), "\" ",
    "data-dava-type=\"r-plot\" ",
    "data-dava-import-mode=\"import\" ",
    "data-dava-edit-policy=\"", dava_xml_escape_attr(edit_policy), "\" ",
    "data-dava-source=\"R\" ",
    "data-dava-width=\"", dava_format_svg_number(size$width), "\" ",
    "data-dava-height=\"", dava_format_svg_number(size$height), "\"",
    if (isTRUE(x_offset != 0 || y_offset != 0)) {
      paste0(
        " transform=\"translate(",
        dava_format_svg_number(x_offset),
        " ",
        dava_format_svg_number(y_offset),
        ")\""
      )
    } else {
      ""
    }
  )

  wrapper_text <- paste0(
    "<svg ", root_attrs, ">",
    paste(defs_text, collapse = "\n"),
    "<g ", group_attrs, ">",
    paste(body_text, collapse = "\n"),
    "</g></svg>"
  )
  if (!isTRUE(validate_output)) return(dava_as_utf8_text(wrapper_text))
  wrapper_root <- xml2::xml_root(xml2::read_xml(wrapper_text, options = c("RECOVER", "NOERROR", "NOWARNING", "HUGE")))
  dava_as_utf8_text(dava_strip_xml_declaration(as.character(wrapper_root)))
}

dava_svg_import_template_token <- function() "dava-import-template-token"

dava_prepare_svg_import_template <- function(svg_text) {
  token <- dava_svg_import_template_token()
  prepared_svg <- dava_clean_svg_for_svgedit(svg_text)
  if (exists("layout_svg_mark_r_plot_layers", mode = "function") &&
      !grepl("data-dava-r-plot-layer", prepared_svg, fixed = TRUE)) {
    prepared_svg <- layout_svg_mark_r_plot_layers(prepared_svg)
  }
  dava_wrap_svg_for_svgedit_import(
    prepared_svg,
    object_id = token,
    group_first = TRUE,
    already_clean = TRUE,
    validate_output = FALSE
  )
}

dava_materialize_svg_import_template <- function(template, object_id) {
  token <- dava_svg_import_template_token()
  if (!is.character(template) || length(template) != 1L ||
      !nzchar(template) || !grepl(token, template, fixed = TRUE)) {
    stop("Invalid SVG import template.", call. = FALSE)
  }
  object_id <- dava_make_safe_svg_id(object_id, fallback = dava_make_unique_import_id())
  dava_as_utf8_text(gsub(token, object_id, template, fixed = TRUE))
}

dava_normalize_r_plot_for_svgedit <- function(plot_obj = NULL,
                                              plot_expr = NULL,
                                              width = 10,
                                              height = 7,
                                              pointsize = 12,
                                              bg = "transparent",
                                              import_offset_x = 0,
                                              import_offset_y = 0) {
  tryCatch({
    plot_expr_code <- substitute(plot_expr)
    has_plot_expr <- !missing(plot_expr) && !identical(plot_expr_code, quote(NULL))

    raw_svg <- if (has_plot_expr) {
      dava_plot_to_svg_string(
        plot_obj = plot_obj,
        plot_expr = eval(plot_expr_code, envir = parent.frame(2)),
        width = width,
        height = height,
        pointsize = pointsize,
        bg = bg
      )
    } else {
      dava_plot_to_svg_string(
        plot_obj = plot_obj,
        width = width,
        height = height,
        pointsize = pointsize,
        bg = bg
      )
    }

    cleaned_svg <- dava_clean_svg_for_svgedit(raw_svg)
    object_id <- dava_make_unique_import_id()
    prefixed_svg <- dava_prefix_svg_ids(cleaned_svg, object_id)
    normalized_svg <- dava_wrap_svg_for_svgedit_import(
      prefixed_svg,
      object_id = object_id,
      x_offset = import_offset_x,
      y_offset = import_offset_y,
      group_first = TRUE,
      already_clean = TRUE,
      validate_output = FALSE
    )
    size <- dava_extract_svg_size(normalized_svg)

    list(
      svg = normalized_svg,
      object_id = object_id,
      width = size$width,
      height = size$height,
      mode = "import"
    )
  }, error = function(e) {
    stop("Failed to normalize R plot for SVG-Edit import: ", conditionMessage(e), call. = FALSE)
  })
}

dava_send_svg_to_svgedit_import <- function(session,
                                            svg_text,
                                            object_id = NULL,
                                            select_after_import = TRUE) {
  if (is.null(session) || !is.function(session$sendCustomMessage)) {
    stop("A valid Shiny session with sendCustomMessage() is required.", call. = FALSE)
  }
  if (is.null(svg_text) || length(svg_text) != 1 || !nzchar(trimws(svg_text))) {
    stop("svg_text must be a non-empty SVG string.", call. = FALSE)
  }
  if (!grepl("<svg\\b", svg_text, perl = TRUE)) {
    stop("svg_text must contain an <svg> root node.", call. = FALSE)
  }

  session$sendCustomMessage(
    "dava-import-svg-into-svgedit",
    list(
      svg = dava_as_utf8_text(svg_text),
      mode = "import",
      object_id = object_id,
      select_after_import = isTRUE(select_after_import),
      preserve_size = TRUE
    )
  )
  invisible(TRUE)
}
