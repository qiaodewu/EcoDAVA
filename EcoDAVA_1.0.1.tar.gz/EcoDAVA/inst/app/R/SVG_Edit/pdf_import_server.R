register_pdf_import_server <- function(input, output, session, file_data = NULL, max_file_size = 100 * 1024^2) {
  pdf_store <- new.env(parent = emptyenv())
  pdf_store$files <- list()
  pdf_store$cache <- list()

  send_pdf_message <- function(type, payload) {
    session$sendCustomMessage(type, payload)
  }

  observeEvent(input$svgedit_pdf_import_file, {
    file <- input$svgedit_pdf_import_file
    if (is.null(file) || !nzchar(file$datapath %||% "")) return()
    if (!grepl("\\.pdf$", file$name %||% "", ignore.case = TRUE)) {
      send_pdf_message("pdf_import_error", list(message = "Only PDF files are allowed."))
      return()
    }
    size <- file$size %||% file.info(file$datapath)$size
    if (is.finite(size) && size > max_file_size) {
      send_pdf_message("pdf_import_error", list(message = "PDF file is larger than the configured limit."))
      return()
    }
    file_id <- paste0("pdf-", format(Sys.time(), "%Y%m%d%H%M%OS3"), "-", sample.int(99999, 1))
    safe_pdf <- tempfile(pattern = paste0(file_id, "-"), fileext = ".pdf")
    file.copy(file$datapath, safe_pdf, overwrite = TRUE)
    pages <- get_pdf_page_count(safe_pdf)
    tools <- detect_pdf_vector_tools()
    pdf_store$files[[file_id]] <- list(path = safe_pdf, name = basename(file$name), size = size, pageCount = pages$pageCount)
    send_pdf_message("pdf_conversion_result", list(
      stage = "uploaded",
      fileId = file_id,
      fileName = basename(file$name),
      pageCount = pages$pageCount,
      fileSize = size,
      availableTools = tools,
      warnings = c(pages$warnings, tools$warnings)
    ))
  }, ignoreInit = TRUE)

  observeEvent(input$pdf_import_convert_request, {
    req <- input$pdf_import_convert_request
    if (!is.list(req)) return()
    file_id <- req$fileId %||% ""
    record <- pdf_store$files[[file_id]]
    if (is.null(record) || !file.exists(record$path)) {
      send_pdf_message("pdf_import_error", list(fileId = file_id, message = "Uploaded PDF was not found in this session."))
      return()
    }
    pages <- tryCatch(parse_pdf_page_spec(req$pageSpec %||% req$page %||% "1", record$pageCount), error = function(e) {
      send_pdf_message("pdf_import_error", list(fileId = file_id, message = conditionMessage(e)))
      integer()
    })
    if (!length(pages)) {
      send_pdf_message("pdf_import_error", list(fileId = file_id, message = "No valid PDF pages were selected."))
      return()
    }
    results <- list()
    for (page in pages) {
      text_mode <- req$textMode %||% "preserve-text"
      cache_key <- paste(
        file_id, page, req$engine %||% "auto", text_mode,
        req$cropMode %||% "page", req$cleanLevel %||% "standard",
        isTRUE(req$keepImages), sep = "|"
      )
      cached <- pdf_store$cache[[cache_key]]
      if (!is.null(cached) && isTRUE(cached$ok)) {
        cached$cached <- TRUE
        cached$elapsedMs <- 0
        results[[length(results) + 1]] <- cached
        next
      }
      send_pdf_message("pdf_conversion_result", list(
        stage = "converting",
        fileId = file_id,
        fileName = record$name,
        page = page,
        engine = req$engine %||% "auto",
        timestamp = as.numeric(Sys.time()) * 1000
      ))
      raw_svg <- tempfile(pattern = paste0(file_id, "-p", page, "-raw-"), fileext = ".svg")
      clean_svg <- tempfile(pattern = paste0(file_id, "-p", page, "-clean-"), fileext = ".svg")
      started_at <- proc.time()[["elapsed"]]
      one <- tryCatch({
        tools <- detect_pdf_vector_tools()
        requested_engine <- req$engine %||% "auto"
        engines <- pdf_import_engine_order(requested_engine, text_mode, tools)
        if (!length(engines)) stop("No available PDF vector conversion engine.")
        converted <- NULL
        errors <- character()
        for (candidate_engine in engines) {
          raw_candidate <- if (identical(candidate_engine, engines[[1]])) raw_svg else tempfile(pattern = paste0(file_id, "-p", page, "-", candidate_engine, "-raw-"), fileext = ".svg")
          converted <- tryCatch(convert_pdf_page_to_svg(record$path, page, raw_candidate, list(
            engine = candidate_engine,
            textMode = text_mode,
            cropMode = req$cropMode %||% "page",
            cleanLevel = req$cleanLevel %||% "standard",
            keepImages = isTRUE(req$keepImages),
            timeoutSec = req$timeoutSec %||% 60
          )), error = function(e) {
            errors <<- c(errors, sprintf("[%s] %s", candidate_engine, conditionMessage(e)))
            NULL
          })
          if (!is.null(converted) && file.exists(raw_candidate) && file.info(raw_candidate)$size > 0) {
            raw_svg <- raw_candidate
            break
          }
          converted <- NULL
          if (!identical(requested_engine, "auto")) break
        }
        if (is.null(converted)) stop(paste(c("PDF conversion failed for all attempted engines.", errors), collapse = "\n"))
        raw_text <- pdf_import_read_text(raw_svg)
        raw_analysis <- analyze_converted_svg(raw_text)
        if (!identical(text_mode, "outline-text") && isTRUE(pdf_import_has_suspicious_text(raw_text))) {
          raw_analysis$warnings <- unique(c(
            raw_analysis$warnings,
            "Chinese/CJK text still looks garbled after text-preserving import. The PDF may lack proper Unicode font mapping. Text was not outlined automatically; choose Outline text manually only when visual fidelity is more important than editable text."
          ))
        }
        if (identical(text_mode, "outline-text") && !identical(converted$engine, "inkscape")) {
          raw_analysis$warnings <- unique(c(
            raw_analysis$warnings,
            "Outline text requires Inkscape for the most reliable Chinese/CJK PDF import. Current engine may preserve broken PDF text if fonts are not embedded."
          ))
        }
        cleaned <- clean_pdf_svg(raw_svg, clean_svg, list(
          fileId = file_id,
          fileName = record$name,
          page = page,
          cleanLevel = req$cleanLevel %||% "standard",
          keepImages = isTRUE(req$keepImages)
        ))
        list(ok = TRUE, fileId = file_id, fileName = record$name, page = page, engine = converted$engine,
          textMode = text_mode, cleanSvg = cleaned$svg, stats = cleaned$stats,
          warnings = unique(c(raw_analysis$warnings, cleaned$stats$warnings)), log = converted$log,
          cached = FALSE, elapsedMs = round((proc.time()[["elapsed"]] - started_at) * 1000))
      }, error = function(e) {
        list(ok = FALSE, fileId = file_id, fileName = record$name, page = page, engine = req$engine %||% "auto",
          error = conditionMessage(e), warnings = conditionMessage(e), log = conditionMessage(e))
      })
      if (isTRUE(one$ok)) pdf_store$cache[[cache_key]] <- one
      results[[length(results) + 1]] <- one
    }
    send_pdf_message("pdf_conversion_result", list(
      stage = "converted",
      fileId = file_id,
      fileName = record$name,
      target = req$target %||% "current",
      results = results,
      timestamp = as.numeric(Sys.time()) * 1000
    ))
  }, ignoreInit = TRUE)
}
