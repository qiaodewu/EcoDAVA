DAVA_VERSION <- "1.0.1"
DAVA_COPYRIGHT <- "qiaoyangui@imu.edu.cn"

dava_about_page_ui <- function() {
  tags$div(
    class = "dava-about-page",
    tags$style(HTML(".dava-about-page{min-height:calc(100vh - 90px);padding:42px;background:linear-gradient(145deg,#eef6f4,#f8fbfc)}.dava-about-card{max-width:920px;margin:auto;background:#fff;border:1px solid #d9e5e7;border-radius:14px;box-shadow:0 18px 50px rgba(25,54,67,.1);overflow:hidden}.dava-about-hero{padding:42px;background:linear-gradient(135deg,#173746,#2f7f86);color:#fff}.dava-about-hero h1{margin:0 0 10px;font-size:38px}.dava-about-body{padding:32px}.dava-about-meta{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.dava-about-item{padding:18px;border:1px solid #dce7e9;border-radius:9px;background:#f8fbfb}.dava-about-item span{display:block;color:#61747c;font-size:13px}.dava-about-item strong{display:block;margin-top:5px;color:#183540;font-size:18px}.dava-about-note{margin-top:22px;line-height:1.8;color:#4f626b}@media(max-width:700px){.dava-about-page{padding:16px}.dava-about-meta{grid-template-columns:1fr}}")),
    tags$article(
      class = "dava-about-card",
      tags$header(class = "dava-about-hero",
        tags$h1("EcoDAVA: ecological data analysis and visualization assistant"),
        tags$p("An integrated workbench based on the Shiny framework for interactive data wrangling, statistical modeling, microbiome analysis and plot editing.")
      ),
      tags$section(class = "dava-about-body",
        tags$div(class = "dava-about-meta",
          tags$div(class = "dava-about-item", tags$span("Software version"), tags$strong(DAVA_VERSION)),
          tags$div(class = "dava-about-item", tags$span("Copyright and contact"), tags$strong(DAVA_COPYRIGHT)),
          tags$div(class = "dava-about-item", tags$span("Operating environment"), tags$strong("R / Shiny")),
          tags$div(class = "dava-about-item", tags$span("Software positioning"), tags$strong("R Language Data Analysis Assistant"))
        ),
        tags$div(class = "dava-about-note",
          tags$h4("Copyright statement"),
          tags$p("The interface, analysis workflow, and supporting documentation of EcoDAVA are copyrighted by qiaoyangui@imu.edu.cn. Third-party R packages and their algorithms remain subject to their own licenses. Users must verify data quality, model assumptions, parameter settings, and statistical interpretations, and cite the methods and packages used.")
        )
      )
    )
  )
}

dava_help_section <- function(id, number, title, ..., class = "") {
  tags$section(id = id, class = paste("dava-book-section", class),
    tags$div(class = "dava-chapter-number", number), tags$h2(title), ...)
}

dava_help_callout <- function(title, ..., type = "info") {
  tags$div(class = paste("dava-help-callout", paste0("is-", type)),
    tags$strong(title), tags$div(...))
}

dava_help_table <- function(headers, rows) {
  tags$div(class = "table-responsive", tags$table(
    class = "table table-sm table-hover dava-help-table",
    tags$thead(tags$tr(lapply(headers, tags$th))),
    tags$tbody(lapply(rows, function(row) tags$tr(lapply(row, tags$td))))
  ))
}

dava_help_list <- function(values) {
  values <- as.character(values)
  values <- values[!is.na(values) & nzchar(trimws(values))]
  tags$ul(lapply(values, tags$li))
}

dava_help_split <- function(value, fallback = "Method defaults") {
  value <- paste(value %||% "", collapse = ",")
  values <- trimws(unlist(strsplit(value, ",", fixed = TRUE), use.names = FALSE))
  values <- values[nzchar(values)]
  if (!length(values)) fallback else gsub("_", " ", values, fixed = TRUE)
}

dava_help_field <- function(title, value) {
  tags$div(class = "dava-help-field", tags$dt(title), tags$dd(value))
}

dava_help_method_card <- function(name, purpose, use_when, inputs, key_parameters,
                                  workflow, outputs, reporting, cautions,
                                  badge = "Method guide", open = FALSE) {
  tags$details(
    class = "dava-method-card", open = if (isTRUE(open)) NA else NULL,
    tags$summary(
      tags$span(class = "dava-method-name", name),
      tags$span(class = "dava-method-badge", badge)
    ),
    tags$div(class = "dava-method-body",
      tags$dl(
        dava_help_field("Purpose", purpose),
        dava_help_field("Use when", use_when),
        dava_help_field("Required data", dava_help_list(inputs)),
        dava_help_field("Key parameters", dava_help_list(key_parameters)),
        dava_help_field("Operation", dava_help_list(workflow)),
        dava_help_field("Results", dava_help_list(outputs)),
        dava_help_field("What to report", dava_help_list(reporting)),
        dava_help_field("Cautions", dava_help_list(cautions))
      )
    )
  )
}

dava_help_static_method <- function(name, purpose, use_when, inputs, parameters,
                                    outputs, report, cautions) {
  dava_help_method_card(
    name = name, purpose = purpose, use_when = use_when, inputs = inputs,
    key_parameters = parameters,
    workflow = c("Select a dataset and assign variables according to the study design.",
      "Set the test or model options, then run the analysis.",
      "Read assumptions and warnings before interpreting tables or plots."),
    outputs = outputs, reporting = report, cautions = cautions
  )
}

dava_help_regression_catalog <- function() {
  if (!all(vapply(c("REGRESSION_MODEL_REGISTRY", "regression_methods_for_entry"),
    exists, logical(1), inherits = TRUE))) return(NULL)
  entry_labels <- c(
    reg_classic = "Ordinary least squares regression",
    reg_glm = "Generalized linear model regression",
    reg_mixed_zero = "Mixed effects model regression",
    reg_nonlinear_regularized = "Partial least squares regression",
    reg_mediation = "Piecewise threshold regression",
    reg_community = "Multiple regression tree"
  )
  lapply(names(entry_labels), function(entry_id) {
    rows <- tryCatch(regression_methods_for_entry(entry_id), error = function(error) NULL)
    if (is.null(rows) || !nrow(rows)) return(NULL)
    tags$div(class = "dava-catalog-group",
      tags$h3(unname(entry_labels[[entry_id]])),
      tags$p(paste("Methods available from the current", entry_labels[[entry_id]], "menu entry.")),
      tags$div(class = "dava-method-grid", lapply(seq_len(nrow(rows)), function(index) {
        row <- rows[index, , drop = FALSE]
        response <- dava_help_split(row$response_types, "method-compatible response")
        family <- dava_help_split(row$families, "method-specific distribution")
        variables <- dava_help_split(row$variable_controls, "response and explanatory variables")
        parameters <- dava_help_split(row$parameter_controls, "model defaults")
        tables <- dava_help_split(row$result_tables, "model summary")
        plots <- dava_help_split(row$plot_types, "method-specific plot")
        dava_help_method_card(
          name = row$label,
          purpose = paste("Fit this method from the", entry_labels[[entry_id]], "workflow."),
          use_when = paste("Use when the response is compatible with", paste(response, collapse = ", "),
            "and the assumed family is", paste(family, collapse = ", "), "."),
          inputs = c(paste("Variables:", paste(variables, collapse = ", ")),
            paste("Response mode:", row$response_support)),
          key_parameters = parameters,
          workflow = c("Choose the response, focal predictor, and any covariates or grouping variables.",
            "Confirm the analysis scenario and distribution-specific settings.",
            "Run the model, inspect diagnostics, then select the required result or plot type."),
          outputs = c(paste("Tables:", paste(tables, collapse = ", ")),
            paste("Plots:", paste(plots, collapse = ", "))),
          reporting = c("Model formula and analysis sample size.",
            "Coefficient or effect estimate with confidence interval and test statistic.",
            "Fit metrics, diagnostics, prediction scale, and software engine."),
          cautions = c("Match the response distribution and link to the data-generating process.",
            "Do not interpret a fitted curve before checking residuals, influential observations, and convergence.",
            "Use the same rows and response scale when comparing models."),
          badge = row$package
        )
      }))
    )
  })
}

dava_help_sem_catalog <- function() {
  if (!exists("SEM_METHOD_REGISTRY", inherits = TRUE)) return(NULL)
  registry <- get("SEM_METHOD_REGISTRY", inherits = TRUE)
  registry <- registry[registry$status == "implemented" & registry$visibility %in% TRUE, , drop = FALSE]
  tags$div(class = "dava-method-grid", lapply(seq_len(nrow(registry)), function(index) {
    row <- registry[index, , drop = FALSE]
    dava_help_method_card(
      name = row$label_en,
      purpose = switch(row$id,
        covariance_sem = "Estimate observed and latent-variable path models from a covariance structure.",
        piecewise_sem = "Combine component models into a causal network while retaining mixed, generalized, or hierarchical model structures.",
        pls_pm = "Estimate component-based path models for prediction-oriented latent constructs.",
        "Estimate a structural equation model."),
      use_when = paste("Supported input mode:", paste(row$input_modes[[1]], collapse = ", "), "."),
      inputs = c(paste("Data fields:", paste(row$data_fields[[1]], collapse = ", ")),
        paste("Supported data types:", paste(row$supported_data_types[[1]], collapse = ", "))),
      key_parameters = c("Path and measurement specification", "Estimator or component-model family",
        "Missing-data, bootstrap, and model-comparison settings where supported"),
      workflow = c("Prepare variables and define the path structure.",
        "Validate identification and model-specific assumptions.",
        "Fit the model and inspect global fit, local paths, residuals, and indirect effects."),
      outputs = c(paste("Result sections:", paste(row$result_sections[[1]], collapse = ", ")),
        paste("Plots:", paste(row$plot_types[[1]], collapse = ", "))),
      reporting = c("A priori path structure and estimator.", "Standardized and unstandardized path estimates.",
        "Fit or component-model tests, indirect effects, R-squared, and diagnostics."),
      cautions = c("A plausible path diagram does not establish causality.",
        "Report identification, convergence, and any post hoc model modification."),
      badge = row$primary_engine
    )
  }))
}

dava_help_vi_catalog <- function() {
  if (!exists("vi_method_registry", mode = "function", inherits = TRUE)) return(NULL)
  registry <- vi_method_registry()
  tags$div(class = "dava-method-grid", lapply(seq_len(nrow(registry)), function(index) {
    row <- registry[index, , drop = FALSE]
    dava_help_method_card(
      name = row$label, purpose = row$scenario,
      use_when = row$response,
      inputs = c("One response or a response matrix as required by the selected method.",
        "Candidate predictors; explanatory groups are required for variation partitioning."),
      key_parameters = c("Model type", "Predictor or explanatory-group assignment",
        "Resampling, permutation, cross-validation, or seed settings when available"),
      workflow = c("Choose a method that matches the inferential or predictive goal.",
        "Assign response and predictor variables, then fit the base model.",
        "Inspect the importance table and method-specific stability or uncertainty output."),
      outputs = c("Ranked importance or explained-variation table.",
        "Method-specific model summary and importance plot."),
      reporting = c("Importance definition and model engine.", "Response, candidate predictors, and preprocessing.",
        "Resampling or permutation design and uncertainty where available."),
      cautions = c("Importance is method-dependent and is not automatically a causal effect.",
        "Correlated predictors can share or redistribute importance."),
      badge = strsplit(row$required_packages, ",", fixed = TRUE)[[1]][[1]]
    )
  }))
}

dava_help_microbiome_category_spec <- function(category) {
  specs <- list(
    preprocess = list(
      purpose = "Validate feature-table orientation and sample matching, then filter or transform the analysis matrix.",
      use_when = "Before every downstream microbiome analysis.",
      parameters = c("Sample and feature identifier fields", "Minimum abundance and prevalence", "Transformation, pseudocount, and rarefaction settings"),
      outputs = c("Integrity and matching report", "Filtered or transformed feature table", "Sequencing-depth and coverage diagnostics"),
      report = c("Original and retained sample and feature counts", "Filtering thresholds and transformation", "Any unmatched identifiers or excluded observations"),
      cautions = c("Keep raw counts for methods that explicitly require counts.", "Do not rarefy or transform automatically without matching the scientific question.")),
    composition = list(
      purpose = "Summarize taxonomic composition, occupancy, core taxa, indicator taxa, and shared feature sets.",
      use_when = "The objective is to describe which taxa are present and how composition changes by rank or group.",
      parameters = c("Taxonomic rank", "Top-taxa or abundance threshold", "Core prevalence and abundance thresholds", "Grouping variable"),
      outputs = c("Composition and taxonomy summary tables", "Stacked, heatmap, bubble, occupancy, indicator, or set plots"),
      report = c("Taxonomic rank and aggregation rule", "Denominator and abundance scale", "Thresholds used to define core, dominant, or rare taxa"),
      cautions = c("Relative abundance is compositional.", "State how unclassified and low-abundance taxa were handled.")),
    alpha = list(
      purpose = "Quantify within-sample richness, diversity, evenness, or phylogenetic diversity.",
      use_when = "Each sample has a feature profile and the question concerns within-sample diversity.",
      parameters = c("Diversity index", "Group or environmental predictor", "Rarefaction depth or coverage", "Phylogenetic tree and null-model settings when required"),
      outputs = c("Sample-level alpha table", "Group comparison or regression table", "Diversity, rarefaction, and phylogenetic plots"),
      report = c("Index definition and abundance scale", "Sequencing-depth treatment", "Test or model, effect size, uncertainty, and multiplicity correction"),
      cautions = c("Observed richness is sensitive to sequencing depth.", "Phylogenetic indices require a correctly matched tree.")),
    beta = list(
      purpose = "Quantify between-sample dissimilarity and display or test multivariate community structure.",
      use_when = "The question concerns separation, dispersion, clustering, or trajectories among whole-community profiles.",
      parameters = c("Distance measure and transformation", "Ordination dimensions", "Permutation count and restriction strata", "Group, interaction, or trajectory variables"),
      outputs = c("Distance matrix", "Ordination scores and stress or eigenvalues", "PERMANOVA, PERMDISP, ANOSIM, MRPP, clustering, or trajectory results"),
      report = c("Distance and preprocessing", "Permutation design", "Effect size and explained variation", "Dispersion test with location test"),
      cautions = c("PERMANOVA can respond to dispersion differences.", "Use restricted permutations for paired, blocked, or repeated designs.")),
    environment_spatial = list(
      purpose = "Relate community variation to environmental, spatial, or matrix-level predictors.",
      use_when = "Community composition must be explained by constrained variables, distance matrices, or spatial structure.",
      parameters = c("RDA, CCA, or dbRDA engine", "Conditioning variables", "Distance and transformation", "Permutation scheme and term tests"),
      outputs = c("Constrained ordination", "Environmental vectors and term tests", "Variation partitioning or matrix association"),
      report = c("Response preprocessing and distance", "Constrained and conditioned terms", "Adjusted explained variation and permutation design"),
      cautions = c("Check collinearity and gradient assumptions.", "Use partial methods only with scientifically justified conditioning variables.")),
    differential = list(
      purpose = "Identify taxa associated with groups, covariates, interactions, or environmental gradients.",
      use_when = "Feature-level effects and multiplicity-controlled inference are required.",
      parameters = c("Design formula, contrast, and reference level", "Filtering threshold", "Normalization or transformation", "False-discovery-rate method"),
      outputs = c("Feature-level estimates, uncertainty, raw P values, and adjusted P values", "Volcano, effect, abundance, or biomarker plots"),
      report = c("Full design and contrast", "Count handling and filtering", "Effect scale and confidence interval", "Multiple-testing procedure"),
      cautions = c("Do not substitute relative abundance for raw counts in count-required engines.", "Small groups, confounding, and sparse features can destabilize estimates.")),
    network = list(
      purpose = "Infer or describe taxon-taxon, cross-domain, or microbe-environment association networks.",
      use_when = "The objective is exploratory association structure rather than direct causal interaction.",
      parameters = c("Association or compositional network engine", "Prevalence and abundance filters", "Edge threshold or stability selection", "Module and topology settings"),
      outputs = c("Node and edge tables", "Network, module, topology, comparison, or robustness plots"),
      report = c("Inference engine and filtering", "Edge-selection and sign rules", "Number of nodes and edges", "Stability or sensitivity analysis"),
      cautions = c("Network edges are associations, not confirmed ecological interactions.", "Threshold selection can strongly alter topology.")),
    `function` = list(
      purpose = "Import or infer microbial functional profiles and summarize downstream functional patterns.",
      use_when = "Taxonomic profiles or validated external functional results are available.",
      parameters = c("Marker type and reference database", "Taxonomic or representative-sequence mapping", "Function level and confidence filters"),
      outputs = c("Function abundance or annotation table", "Functional composition, difference, environment, or guild results"),
      report = c("Prediction or import tool and database version", "Mapping success and excluded features", "Functional level and statistical model"),
      cautions = c("Predicted functions are not direct metagenomic measurements.", "Database and marker compatibility must be documented.")),
    assembly_source = list(
      purpose = "Estimate stochasticity, phylogenetic turnover, ecological-process fractions, or source contributions.",
      use_when = "The question concerns community assembly or source-sink mixing.",
      parameters = c("Null-model randomizations", "Abundance and phylogenetic distance", "Metacommunity or source definition", "Parallel and seed settings"),
      outputs = c("Assembly metric or process-fraction table", "Null distribution, process, or source-contribution plots"),
      report = c("Null model and randomization count", "Phylogeny and distance choices", "Process classification thresholds or source definitions"),
      cautions = c("Assembly metrics depend on null-model assumptions.", "Source tracking requires representative and clearly labeled sources.")),
    longitudinal_stability = list(
      purpose = "Analyze temporal turnover, stability, resistance, resilience, or repeated trajectories.",
      use_when = "Samples are repeatedly observed through time or stages.",
      parameters = c("Subject and time fields", "Baseline or disturbance time", "Random-effects or permutation structure", "Trend or change-point settings"),
      outputs = c("Longitudinal metric and model tables", "Trajectory, time-decay, stability, or trend plots"),
      report = c("Sampling schedule and repeated unit", "Time scale and baseline", "Model correlation or random structure", "Estimated temporal effect and uncertainty"),
      cautions = c("Do not treat repeated observations as independent.", "Irregular time intervals require an explicit time scale.")),
    integration_ml = list(
      purpose = "Integrate domains or build predictive and interpretable biomarker models.",
      use_when = "Cross-domain concordance, classification, regression, feature selection, or prediction is the primary goal.",
      parameters = c("Outcome and feature blocks", "Cross-validation and resampling", "Tuning grid and seed", "Importance or explanation method"),
      outputs = c("Resampled performance and prediction tables", "Selected features or cross-domain associations", "Importance, SHAP, score, or validation plots"),
      report = c("Training and validation design", "Preprocessing inside resampling", "Performance with uncertainty", "Final feature set and interpretation method"),
      cautions = c("All preprocessing and feature selection must remain inside resampling.", "Use independent validation when making performance claims."))
  )
  specs[[category]] %||% list(
    purpose = "Run the selected microbiome analysis.", use_when = "The data meet the method requirements.",
    parameters = "Method-specific settings", outputs = "Method-specific tables and plots",
    report = "Method, data, parameters, and effect estimates", cautions = "Inspect warnings before interpretation")
}

dava_help_microbiome_inputs <- function(row) {
  inputs <- "Feature abundance table"
  flags <- c(
    taxonomy_required = "Taxonomic annotation table",
    metadata_required = "Sample metadata",
    phylogeny_required = "Matched phylogenetic tree",
    representative_sequences_required = "Representative sequences",
    environment_table_required = "Environmental-variable table",
    function_table_required = "Functional profile table",
    source_sink_required = "Source and sink labels",
    longitudinal_required = "Subject and time metadata",
    second_microbiome_dataset_required = "Second microbiome dataset"
  )
  for (field in names(flags)) {
    if (field %in% names(row) && isTRUE(row[[field]][[1]])) inputs <- c(inputs, flags[[field]])
  }
  if ("raw_count_required" %in% names(row) && isTRUE(row$raw_count_required[[1]])) {
    inputs[[1]] <- "Raw count feature table"
  }
  unique(inputs)
}

dava_help_microbiome_catalog <- function() {
  required <- c("MICROBIOME_METHOD_REGISTRY", "microbiome_category_registry",
    "microbiome_panel_registry")
  if (!all(vapply(required, exists, logical(1), inherits = TRUE))) return(NULL)
  registry <- get("MICROBIOME_METHOD_REGISTRY", inherits = TRUE)
  categories <- microbiome_category_registry()
  panels <- microbiome_panel_registry()
  category_labels <- stats::setNames(categories$label_cn, categories$id)
  category_blocks <- lapply(seq_len(nrow(categories)), function(category_index) {
    category_id <- categories$id[[category_index]]
    category_panels <- panels[panels$secondary_category == category_id, , drop = FALSE]
    panel_blocks <- lapply(seq_len(nrow(category_panels)), function(panel_index) {
      panel_id <- category_panels$id[[panel_index]]
      rows <- registry[
        registry$navigation_category == category_id &
          registry$navigation_panel == panel_id &
          registry$status == "implemented" & registry$visibility %in% TRUE,
        , drop = FALSE]
      if (!nrow(rows)) return(NULL)
      spec_category <- unique(rows$secondary_category)[[1]] %||% "preprocess"
      spec <- dava_help_microbiome_category_spec(spec_category)
      tags$div(class = "dava-catalog-panel",
        tags$h4(category_panels$label_cn[[panel_index]]),
        tags$p(spec$purpose),
        tags$div(class = "dava-method-grid", lapply(seq_len(nrow(rows)), function(index) {
          row <- rows[index, , drop = FALSE]
          engine <- if (nzchar(row$engine)) row$engine else "DAVA method adapter"
          packages <- if (nzchar(row$required_packages)) row$required_packages else "base R"
          marker <- if (row$marker_type %in% c("16S", "ITS")) paste("Marker:", row$marker_type) else "Marker: 16S or ITS"
          dava_help_method_card(
            name = row$label_cn, purpose = spec$purpose, use_when = spec$use_when,
            inputs = c(dava_help_microbiome_inputs(row), marker),
            key_parameters = spec$parameters,
            workflow = c("Open this method from the current microbiome menu panel.",
              "Review sample-feature matching and preprocessing shown in the code document.",
              "Set method parameters, run the analysis, and inspect every result table and selected plot type."),
            outputs = spec$outputs,
            reporting = c(spec$report, paste("Engine:", engine)),
            cautions = c(spec$cautions, "The code document must use the same data, parameters, analysis steps, tables, and plots as the main analysis."),
            badge = packages
          )
        }))
      )
    })
    panel_blocks <- Filter(Negate(is.null), panel_blocks)
    if (!length(panel_blocks)) return(NULL)
    tags$div(class = "dava-catalog-group",
      tags$h3(category_labels[[category_id]] %||% category_id), panel_blocks)
  })
  Filter(Negate(is.null), category_blocks)
}

dava_help_page_ui <- function() {
  toc <- list(
    c("overview", "1 Overview and common workflow"),
    c("files", "2 File management and data preparation"),
    c("statistics", "3 Ecological statistical analysis"),
    c("regression", "4 Regression model analysis"),
    c("multivariate", "5 Correlation, SEM, and importance"),
    c("microbiome", "6 Microbiome analysis"),
    c("repositories", "7 Data and plot repositories"),
    c("graphics", "8 Figure layout and SVG editing"),
    c("code", "9 Code documents and plug-ins"),
    c("reporting", "10 Results reporting guide"),
    c("troubleshooting", "11 Troubleshooting and reproducibility")
  )
  tags$div(
    class = "dava-help-book",
    tags$style(HTML(".dava-help-book{height:calc(100vh - 78px);display:grid;grid-template-columns:285px minmax(0,1fr);background:#f2f5f4;color:#263b43}.dava-book-toc{overflow:auto;padding:26px 18px;background:#183640;color:#e8f2f2;border-right:1px solid #cbd8d9}.dava-book-brand{padding:0 10px 20px;border-bottom:1px solid rgba(255,255,255,.16);margin-bottom:15px}.dava-book-brand h3{margin:0 0 5px;color:#fff}.dava-book-brand small{color:#bdd1d2}.dava-book-toc a{display:block;padding:9px 11px;margin:3px 0;color:#dceaea;text-decoration:none;border-radius:6px;font-size:13px;line-height:1.35}.dava-book-toc a:hover{background:rgba(255,255,255,.12);color:#fff}.dava-book-main{overflow:auto;scroll-behavior:smooth}.dava-book-paper{max-width:1180px;margin:0 auto;padding:48px 62px 90px;background:#fff;min-height:100%}.dava-book-cover{padding-bottom:42px;border-bottom:2px solid #2b777d;margin-bottom:46px}.dava-book-cover h1{font-family:Georgia,serif;font-size:42px;color:#173640;margin:12px 0}.dava-book-cover p{font-size:17px;line-height:1.8;color:#587078;max-width:880px}.dava-book-section{scroll-margin-top:18px;padding:8px 0 42px;border-bottom:1px solid #e0e8e8;margin-bottom:38px}.dava-book-section h2{font-family:Georgia,serif;color:#1b5058;font-size:29px;margin:0 0 20px}.dava-book-section h3{font-size:20px;color:#244c54;margin:30px 0 12px}.dava-book-section h4{font-size:16px;color:#2e6268;margin:22px 0 10px}.dava-book-section p,.dava-book-section li{line-height:1.75;color:#465d65}.dava-chapter-number{font-size:12px;font-weight:700;letter-spacing:.12em;color:#2e8587;text-transform:uppercase;margin-bottom:5px}.dava-help-callout{padding:15px 18px;margin:18px 0;border-left:4px solid #33878b;background:#edf7f6;border-radius:4px;line-height:1.7}.dava-help-callout.is-warning{border-color:#d99a31;background:#fff8e9}.dava-help-callout.is-rule{border-color:#6a6f9b;background:#f2f2fa}.dava-help-table{font-size:13px;border-color:#dce5e6}.dava-help-table th{background:#edf4f3;color:#234d53;white-space:nowrap}.dava-step-list{counter-reset:dava-step;list-style:none;padding:0}.dava-step-list li{counter-increment:dava-step;position:relative;padding:0 0 15px 42px}.dava-step-list li:before{content:counter(dava-step);position:absolute;left:0;top:2px;width:27px;height:27px;border-radius:50%;background:#2d7e82;color:#fff;text-align:center;line-height:27px;font-weight:700}.dava-method-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;align-items:start}.dava-method-card{border:1px solid #d6e3e3;border-radius:9px;background:#fbfdfd;overflow:hidden}.dava-method-card[open]{box-shadow:0 8px 24px rgba(27,75,82,.08)}.dava-method-card summary{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:15px;cursor:pointer;color:#20545b;font-weight:700}.dava-method-card summary:hover{background:#f0f7f6}.dava-method-name{min-width:0}.dava-method-badge{max-width:48%;padding:3px 7px;border-radius:999px;background:#e5f1ef;color:#397078;font-size:10px;font-weight:600;overflow-wrap:anywhere;text-align:right}.dava-method-body{padding:0 16px 15px;border-top:1px solid #e3ebeb}.dava-method-body dl{margin:0}.dava-help-field{display:grid;grid-template-columns:122px minmax(0,1fr);gap:12px;padding:11px 0;border-bottom:1px dashed #e2e9e9}.dava-help-field:last-child{border-bottom:0}.dava-help-field dt{color:#285a61;font-size:12px}.dava-help-field dd{margin:0;color:#4a6067;font-size:12px;min-width:0}.dava-help-field ul{margin:0;padding-left:18px}.dava-help-field li{font-size:12px;line-height:1.55}.dava-catalog-group{margin:24px 0 32px}.dava-result-map{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.dava-result-map>div{padding:14px;border:1px solid #dce7e7;border-radius:8px;background:#f8fbfb}.dava-result-map strong{display:block;color:#25565d;margin-bottom:5px}@media(max-width:900px){.dava-help-book{grid-template-columns:1fr;height:auto}.dava-book-toc{position:relative;max-height:290px}.dava-book-main{overflow:visible}.dava-book-paper{padding:30px 20px}.dava-method-grid,.dava-result-map{grid-template-columns:1fr}.dava-help-field{grid-template-columns:1fr;gap:4px}}")),
    tags$aside(class = "dava-book-toc",
      tags$div(class = "dava-book-brand", tags$h3("EcoDAVA Help Documentation"),
        tags$small(paste("Version", DAVA_VERSION))),
      lapply(toc, function(item) tags$a(href = paste0("#", item[[1]]), item[[2]]))
    ),
    tags$main(class = "dava-book-main", tags$article(class = "dava-book-paper",
      tags$header(class = "dava-book-cover",
        tags$div(class = "dava-chapter-number", paste("USER GUIDE | VERSION", DAVA_VERSION)),
        tags$h1("EcoDAVA Help Documentation"),
        tags$p("A task-oriented manual synchronized with the current DAVA navigation and method registries. Each method guide explains its function, appropriate use, data requirements, operating logic, parameters, outputs, reporting requirements, and common cautions."),
        tags$small(paste("Copyright and contact:", DAVA_COPYRIGHT))
      ),

      dava_help_section("overview", "CHAPTER 01", "Overview and common workflow",
        tags$p("DAVA combines data management, ecological statistics, microbiome analysis, result reporting, reproducible code, and publication graphics in one project workspace. The main navigation defines the available modules; each analysis page normally contains a left parameter sidebar, central result tabs, and plot properties when graphics are available."),
        tags$div(class = "dava-result-map",
          tags$div(tags$strong("File management"), "Import microbial or tabular data, edit tables, restore a workspace, and review the operation log."),
          tags$div(tags$strong("Ecological statistics"), "Run assumption checks, tests, ANOVA, regression, correlation, SEM, and variable-importance analyses."),
          tags$div(tags$strong("Microbiome analysis"), "Use method-specific workflows for preprocessing, diversity, differential abundance, ordination, networks, functions, assembly, time series, and machine learning."),
          tags$div(tags$strong("Data table repository"), "Register analysis result tables with project and method provenance."),
          tags$div(tags$strong("Analysis plot library"), "Register analysis graphics and supply source plots to the SVG editor."),
          tags$div(tags$strong("Figure layout and styling"), "Arrange, edit, annotate, and export vector graphics without changing the statistical analysis.")),
        tags$h3("Common analysis workflow"),
        tags$ol(class = "dava-step-list",
          tags$li("Import or select a project dataset and verify identifiers, variable types, missing values, and analysis units."),
          tags$li("Choose a method that matches the response type, sampling design, and scientific question."),
          tags$li("Assign response, explanatory, grouping, subject, block, taxonomic, or phylogenetic fields as required."),
          tags$li("Set parameters and run the analysis. Read warnings and errors in the code or code-document console."),
          tags$li("Inspect assumptions, result tables, diagnostics, effect plots, and the complete code document."),
          tags$li("Download the analysis result table, add reusable tables to the Data table repository, and add graphics to the Analysis plot library."),
          tags$li("Save the DAVA workspace when the data, settings, tables, plots, and code need to be restored together.")),
        dava_help_callout("Interpretation rule", "DAVA automates computation and presentation, not scientific judgment. Confirm the sampling unit, independence, model assumptions, effective sample size, multiplicity, effect size, and uncertainty before reporting a result.", type = "warning")
      ),

      dava_help_section("files", "CHAPTER 02", "File management and data preparation",
        dava_help_table(c("Module", "Function", "Operating logic", "Output"), list(
          c("Microbial data import", "Build a project analysis bundle from abundance, taxonomy, metadata, phylogeny, sequence, environment, function, or source tables.", "Assign table roles, orientations, and identifier fields; validate matching before registration.", "A reusable project dataset and validation summary."),
          c("Dataset importing and editing", "Inspect and edit project tables.", "Filter, sort, transform, reshape, join, or convert types while preserving the original table when possible.", "A named edited table registered in the workspace."),
          c("Import working environment", "Restore a DAVA workspace or compatible RDS file.", "Select the saved file, import it, review the object summary, and resolve missing package or asset warnings.", "Restored data, settings, results, code, and graphics."),
          c("Operation log", "Review actions performed in the current project.", "Filter or inspect entries to trace data and analysis changes.", "An auditable action history."))),
        tags$h3("Data organization"),
        dava_help_list(c(
          "For conventional statistics, use one observation per row and one variable per column.",
          "For microbiome analysis, align abundance-table sample names with metadata row names and feature names with taxonomy identifiers.",
          "Use unique, non-missing sample identifiers. Keep categorical levels explicit and numeric variables truly numeric.",
          "Record whether abundance values are raw counts, proportions, percentages, transformed values, or standardized scores.",
          "User-provided table names, row names, column names, and custom text remain unchanged when the interface language changes.")),
        dava_help_callout("Project asset rule", "Method-specific demonstration data are read from the installed local simulated-dataset assets. Imported user data remain the authoritative source for project analyses.", type = "rule")
      ),

      dava_help_section("statistics", "CHAPTER 03", "Ecological statistical analysis",
        tags$h3("Assumption diagnostics"),
        dava_help_static_method("Normality-Homogeneity of Variances test",
          "Evaluate distributional and variance assumptions before mean-based tests or models.",
          "A continuous response is compared across one or more groups.",
          c("Continuous response", "Optional grouping variable"),
          c("Normality test", "Variance-homogeneity test", "Grouping and missing-value handling"),
          c("Descriptive statistics", "Normality and homogeneity tables", "Q-Q and diagnostic plots"),
          c("Test names and statistics", "Group sample sizes", "Graphical evidence and the decision made"),
          c("Normality is usually more relevant for residuals than raw observations.", "Large samples can make small deviations statistically significant.")),
        tags$h3("t tests"),
        tags$div(class = "dava-method-grid",
          dava_help_static_method("One-sample t test", "Compare a sample mean with a reference value.", "One continuous sample is independent and its mean is the target.", c("Continuous response", "Reference mean"), c("Alternative hypothesis", "Confidence level"), c("Mean difference", "t statistic, degrees of freedom, P value, confidence interval", "Distribution and effect plot"), c("Mean, SD, n, reference, mean difference, t, df, P, confidence interval"), c("Check independence and approximate normality of the response.")),
          dava_help_static_method("Two-sample t test", "Compare means of two independent groups.", "Each observation belongs to one of two independent groups.", c("Continuous response", "Two-level group"), c("Welch or equal-variance form", "Alternative hypothesis", "Confidence level"), c("Group summaries", "Mean difference and test table", "Comparison plot"), c("Group means and SDs, mean difference, t, df, P, confidence interval, effect size"), c("Prefer Welch unless equal variance is justified.", "Do not use for paired observations.")),
          dava_help_static_method("Two-sample paired t test", "Compare the mean within-pair change.", "The same unit is measured twice or observations are explicitly matched.", c("Two numeric measurements or long-format response", "Pair identifier when required"), c("Pairing direction", "Alternative hypothesis", "Confidence level"), c("Paired differences", "Paired test table", "Paired-value plot"), c("Mean paired difference, SD of differences, n pairs, t, df, P, confidence interval"), c("Analyze complete pairs and verify the normality of paired differences."))
        ),
        tags$h3("Analysis of variance and covariance"),
        tags$div(class = "dava-method-grid",
          dava_help_static_method("Completely Randomized ANOVA", "Test fixed-factor mean differences in an independent design.", "One or more fixed factors define independent treatment groups.", c("Continuous response", "Fixed factor or factors"), c("Main effects and interactions", "Post hoc comparison", "Multiplicity correction"), c("ANOVA table", "Estimated means and pairwise comparisons", "Diagnostic and group plots"), c("Design, F tests, degrees of freedom, P values, effect sizes, post hoc contrasts"), c("Interpret interactions before lower-order main effects.", "Check residual and variance assumptions.")),
          dava_help_static_method("Random block analysis of variance", "Separate treatment effects from block variation.", "Each block contains comparable treatment units.", c("Continuous response", "Treatment factor", "Block factor"), c("Treatment and block terms", "Post hoc comparison"), c("Blocked ANOVA table", "Treatment comparisons", "Block-adjusted plots"), c("Blocking design, treatment effect, block effect, adjusted comparisons"), c("A block is a design factor, not an arbitrary covariate.")),
          dava_help_static_method("Repeated Measures Analysis of Variance", "Test within-unit changes and interactions over repeated conditions.", "The same subject or unit is observed repeatedly.", c("Continuous response", "Subject identifier", "Within-subject factor", "Optional between-subject factor"), c("Within and between effects", "Sphericity correction", "Post hoc contrasts"), c("Repeated-measures tests", "Corrections and contrasts", "Profile and diagnostic plots"), c("Subject structure, effects, correction used, test statistics, contrasts"), c("Do not analyze repeated rows as independent.", "Report the correction when sphericity is violated.")),
          dava_help_static_method("Analysis of covariance", "Compare groups while adjusting for continuous covariates.", "A group effect is estimated conditional on one or more covariates.", c("Continuous response", "Factor", "Continuous covariate"), c("Factor-covariate interaction", "Adjusted means", "Contrast and confidence level"), c("ANCOVA table", "Adjusted means and contrasts", "Adjusted fit plot"), c("Model formula, slope-homogeneity test, adjusted means, effect size, uncertainty"), c("A significant factor-covariate interaction means parallel-slope ANCOVA is inappropriate."))
        ),
        tags$h3("Non-parametric tests"),
        dava_help_table(c("Method", "Use when", "Primary result", "Key caution"), list(
          c("One-sample Wilcoxon signed-rank test", "A one-sample or paired-difference location is compared with a reference.", "Signed-rank statistic, P value, location estimate.", "Requires a meaningful symmetry assumption for location interpretation."),
          c("Two-sample paired signed-rank test", "Paired differences are not suitably modeled by a paired t test.", "Signed-rank statistic and paired location shift.", "Use only complete, correctly ordered pairs."),
          c("Two-sample Wilcoxon-Mann-Whitney test", "Two independent groups are compared by ranks.", "Rank statistic, P value, and effect estimate where available.", "A general distributional comparison is not automatically a mean or median test."),
          c("One-way Kruskal-Wallis test", "Three or more independent groups are compared by ranks.", "Overall rank test and adjusted post hoc comparisons.", "Inspect distribution shapes and report the post hoc correction."),
          c("One-way with Blocks Friedman test", "Treatments are compared within blocks or subjects.", "Friedman statistic and post hoc contrasts.", "Every block must represent the intended matched design."),
          c("Two-way Scheirer-Ray-Hare test", "A rank-based approximation is needed for two factors.", "Main-effect and interaction rank tests.", "Interpret interactions cautiously; ART is often preferable for factorial inference."),
          c("Aligned Ranks Transformation ANOVA", "Factorial non-parametric main effects and interactions are required.", "ANOVA-style tests on aligned ranks.", "Post hoc contrasts must match the aligned effect being interpreted."))),
        tags$h3("Mixed-effects models"),
        tags$div(class = "dava-method-grid",
          dava_help_static_method("Linear Mixed Effects Model (LMM)", "Estimate continuous-response fixed effects with hierarchical or repeated random variation.", "Observations are clustered by subject, site, block, batch, or another sampling unit.", c("Continuous response", "Fixed effects", "Random grouping variable", "Optional random slope"), c("REML or ML", "Random intercept, slope, nested, or crossed structure", "Post hoc contrasts"), c("Fixed effects", "Random-effect variance", "Fit metrics, diagnostics, predictions"), c("Formula, estimation method, fixed effects, random structure, variance components, fit and diagnostics"), c("Choose random effects from the design.", "Singular fits indicate unsupported complexity.")),
          dava_help_static_method("Generalized Linear Mixed Effects Model (GLMM)", "Fit non-Gaussian responses with hierarchical or repeated random variation.", "Binary, count, or other supported responses are clustered.", c("Response", "Fixed effects", "Random grouping variable", "Optional random slope"), c("Distribution and link", "Random structure", "Optimizer or convergence settings"), c("Fixed effects on link and response scales", "Random effects", "Dispersion, zero, and residual diagnostics"), c("Family, link, formula, effects with intervals, random variance, convergence and diagnostics"), c("Check overdispersion, zero inflation, convergence, and boundary estimates."))
        )
      ),

      dava_help_section("regression", "CHAPTER 04", "Regression model analysis",
        tags$p("The six regression navigation entries expose model families from the current regression capability registry. Open a method below for its required variables, active parameters, result tables, plot types, and reporting requirements."),
        dava_help_callout("Model selection rule", "Choose a model from the response distribution, sampling design, and scientific estimand. Do not choose solely from the appearance of the fitted curve or the smallest P value.", type = "rule"),
        dava_help_regression_catalog()
      ),

      dava_help_section("multivariate", "CHAPTER 05", "Correlation, structural equation models, and variable importance",
        tags$h3("Correlation analysis"),
        tags$div(class = "dava-method-grid",
          dava_help_static_method("Correlation analysis", "Estimate pairwise associations among numeric variables.", "At least two numeric variables are available for overall or group-specific association analysis.", c("Two or more numeric variables", "Optional grouping variable"), c("Pearson, Spearman, or Kendall method", "Missing-value handling", "Multiplicity correction"), c("Correlation, P-value, and adjusted-P matrices", "Heatmap or pairwise plot"), c("Method, n, coefficient, uncertainty or P value, multiplicity correction"), c("Correlation is not causation.", "Grouped correlations require adequate within-group sample size.")),
          dava_help_static_method("Network correlation analysis", "Display thresholded pairwise associations as a network.", "Exploratory network structure is needed from a correlation matrix.", c("Numeric variables", "Optional grouping variable"), c("Correlation method", "Absolute edge threshold", "P or adjusted-P threshold", "Layout and node settings"), c("Node and edge tables", "Overall or grouped network plots"), c("Correlation and threshold rules, node and edge counts, grouping and correction"), c("Display thresholds do not replace inferential validation.", "Topology changes with filtering and thresholds."))
        ),
        tags$h3("Structural equation models"),
        dava_help_sem_catalog(),
        tags$h3("Variable importance analysis"),
        dava_help_vi_catalog()
      ),

      dava_help_section("microbiome", "CHAPTER 06", "Microbiome analysis",
        tags$p("The method directory below is generated from the current implemented and visible microbiome registry. It therefore follows the actual data requirements, engines, marker compatibility, and navigation categories used by the application."),
        dava_help_callout("Reproducibility contract", "For every microbiome method, the code document must show the selected data source, import and preprocessing, analysis context and bundle construction, method parameters, main analysis calls, result objects, and selected plots. Running the document must reproduce the main analysis tables and plot types.", type = "rule"),
        dava_help_microbiome_catalog()
      ),

      dava_help_section("repositories", "CHAPTER 07", "Data table repository and Analysis plot library",
        tags$h3("Data table repository"),
        dava_help_table(c("Action", "Operation", "Expected behavior"), list(
          c("Add analysis results", "Use Add to Data table repository above Download analysis results XLSX in the analysis sidebar.", "All structured result tables from the current analysis are registered with project, module, method, and result-source provenance."),
          c("Browse sources", "Open Chart library > Data table repository and expand project, module, method, run, and table levels.", "The left sidebar shows the provenance tree; the selected table appears in the main panel."),
          c("Reuse or export", "Inspect, select, and download the registered table.", "The stored table remains linked to its analysis origin and does not overwrite user data."))),
        tags$h3("Analysis plot library"),
        dava_help_table(c("Action", "Operation", "Expected behavior"), list(
          c("Add a plot", "Use Add to Analysis plot library in an analysis plot area.", "The current plot and its provenance are registered."),
          c("Browse sources", "Open Chart library > Analysis plot library and expand the source hierarchy.", "The left sidebar lists plots by project and analysis source; the selected plot appears in the main panel."),
          c("Edit layout", "Open Figure layout and styling and choose a source from the Analysis plot library.", "The plot is imported into the SVG editor for layout and annotation; the statistical result is unchanged."))),
        dava_help_callout("Repository scope", "The repositories store analysis outputs with provenance. They are not replacements for the original imported data or the saved DAVA workspace.", type = "warning")
      ),

      dava_help_section("graphics", "CHAPTER 08", "Figure layout, plot properties, and SVG editing",
        tags$h3("Analysis plot properties"),
        dava_help_list(c(
          "Overall plot properties control global palette, labels, axes, theme, legend, and common layers.",
          "When a fitted plot has groups, group-layer properties control each selected group independently and reflect the current global palette.",
          "Property changes are applied in operation order. A later global palette can replace group colors; a later group edit can override one group.",
          "Use opacity controls for points, fit lines, confidence regions, and other supported layers.",
          "Only properties supported by the actual plot layers are shown.")),
        tags$h3("SVG editor operation"),
        dava_help_table(c("Task", "Operation", "Result"), list(
          c("Select and transform", "Click an object; drag handles or use the property panel.", "Move, resize, rotate, align, order, or style the selected object."),
          c("Edit text", "Double-click any imported R text or inserted text box.", "Use mouse drag to select partial text; apply font, size, weight, italic, underline, color, superscript, or subscript."),
          c("Create line breaks", "Press Enter while editing text.", "Line breaks persist after leaving edit mode and after re-entering the text object."),
          c("Leave text editing", "Press Escape or click an empty area outside the text box.", "The current text and inline formatting are committed without removing line breaks."),
          c("Zoom the page", "Use Ctrl/Cmd with + or -.", "The whole editing page zooms while object geometry remains unchanged."),
          c("Undo and redo", "Use the toolbar or standard keyboard shortcuts.", "The history indicator shows the currently available undo and redo steps."),
          c("Export", "Choose the required vector or raster output and export settings.", "The current layout is rendered without rerunning the analysis."))),
        dava_help_callout("Editing boundary", "Figure editing changes presentation only. Return to the analysis module when the data, statistical method, model parameters, or generated plot data must change.", type = "rule")
      ),

      dava_help_section("code", "CHAPTER 09", "R Markdown code documents and plug-ins",
        tags$h3("R Markdown code document"),
        dava_help_table(c("Area", "Purpose", "Rule"), list(
          c("R Markdown code document", "Display the complete source for the current method, results and figures.", "The document is read-only and is regenerated from the same method-specific settings used by the main analysis."),
          c("Analysis", "Show data preparation, formulas, package calls and fitted objects.", "No project-level multi-method dispatcher is used in the displayed source."),
          c("Results and plots", "Create the result tables, plot objects and displayed figures.", "The selected result and plot branches match the current main-analysis run."))),
        tags$h3("Code management"),
        dava_help_list(c("Save the displayed .Rmd source together with the matching data and run provenance.", "Review required packages and documented input objects before knitting the file in another project.", "Changing the interface language never translates code, variable names, model text, or data values inside the document.")),
        tags$h3("Plug-in management"),
        dava_help_list(c("Install or enable only trusted plug-ins.", "Review declared dependencies, inputs, outputs, and permissions.", "A plug-in must not change core analysis behavior outside its declared scope.")),
        dava_help_callout("Code-document acceptance test", "A code document is complete only when a clean run from its documented inputs creates the same analysis objects, result tables, and selected plot types as the main method.", type = "warning")
      ),

      dava_help_section("reporting", "CHAPTER 10", "Results reporting guide",
        tags$h3("Minimum report structure"),
        dava_help_table(c("Report element", "Include"), list(
          c("Data and design", "Analysis unit, sample size, groups, repeated or blocked structure, exclusions, and missing-data handling."),
          c("Preprocessing", "Filtering, transformation, normalization, scaling, taxonomic aggregation, rarefaction, and identifier matching."),
          c("Method", "Exact method, engine or package, model formula, distribution, link, distance, estimator, or null model."),
          c("Parameters", "Non-default thresholds, contrasts, reference levels, permutations, bootstrap, resampling, seed, and multiple-testing correction."),
          c("Primary result", "Effect estimate or explained variation with uncertainty, test statistic, degrees of freedom where relevant, and adjusted P value."),
          c("Diagnostics", "Assumptions, convergence, residuals, dispersion, collinearity, sensitivity, and warnings."),
          c("Graphics", "What is displayed, abundance or response scale, grouping, uncertainty representation, and any visual thresholds."),
          c("Reproducibility", "DAVA version, package versions, data source, saved code document, and workspace or exported result tables."))),
        tags$h3("Recommended reading order inside an analysis"),
        tags$ol(class = "dava-step-list",
          tags$li("Confirm the data summary and effective analysis sample size."),
          tags$li("Read the model formula, method text, preprocessing, and parameter summary."),
          tags$li("Read the primary result table and effect uncertainty."),
          tags$li("Inspect assumptions, diagnostics, warnings, and sensitivity outputs."),
          tags$li("Interpret plots together with the tables rather than as independent evidence."),
          tags$li("Export tables, plots, and code with matching run provenance.")),
        dava_help_callout("P-value reporting", "Do not report only a significance label. Include the effect definition, estimate, uncertainty, sample size, model or test, and multiplicity correction.", type = "warning")
      ),

      dava_help_section("troubleshooting", "CHAPTER 11", "Troubleshooting and reproducibility",
        dava_help_table(c("Symptom", "Likely cause", "Resolution"), list(
          c("Sample names do not match", "Feature-table column names and metadata row names differ.", "Normalize identifiers, remove accidental spaces or duplicates, and rerun the matching check."),
          c("A package was built under another R version", "The installed binary was built with a different patch release.", "If the method runs, record the warning; otherwise reinstall the package for the current R version."),
          c("No plot object after running a code document", "The selected plot type was not constructed or printed.", "Confirm that the document contains the same plot branch as the main analysis and explicitly prints every selected plot object."),
          c("Main and code-document plots differ", "Data, preprocessing, parameters, seed, factor levels, or plot selection differ.", "Compare the documented analysis context and bundle with the main run, then rerun from a clean environment."),
          c("A count method warns about non-count values", "The analysis received transformed or relative abundance values.", "Select the raw count table and leave transformation disabled for count-required methods."),
          c("A documented input object is unavailable", "The R Markdown file was opened outside its saved DAVA data context.", "Load the documented input tables or the saved DAVA workspace before knitting the file."),
          c("A model fails to converge", "The model is too complex, sparse, separated, or poorly scaled.", "Check data support, scale numeric predictors, simplify justified terms, and review optimizer diagnostics."),
          c("A plot color is interpreted as a group name", "A layer received a category label where a color value was expected.", "Reset the layer property, apply a valid color, and confirm global palette and group-layer settings."),
          c("Installed DAVA cannot find simulated datasets", "Package assets were not installed under the expected inst/app directory.", "Reinstall the standard package build and verify the installed simulated_datasets asset directory."))),
        tags$h3("Reproducibility checklist"),
        dava_help_list(c(
          "Save the exact input tables or the DAVA workspace.",
          "Record the selected method, complete parameter set, factor references, and random seed.",
          "Keep all warnings and diagnostic decisions with the result.",
          "Run the code document in a clean environment and compare tables and plot types with the main analysis.",
          "Export result tables and graphics from the same run.",
          "Record DAVA, R, and package versions for archived or published analyses.")),
        dava_help_callout("When requesting support", "Provide the module and method name, DAVA and R versions, a minimal reproducible dataset when possible, the selected parameters, the R Markdown source, and the first point where the main analysis and document differ.", type = "info")
      )
    ))
  )
}
