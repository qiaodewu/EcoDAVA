# Style.R

my_header_style <- function() {
  tagList(
    useShinyjs(),
    tags$link(rel = "stylesheet", href = "dava-responsive.css?v=20260922-1"),
    tags$script(src = "dava-sidebar-resize.js?v=20260909-2", defer = NA),

    tags$style(HTML("
      /* Theme settings */
      .bslib-sidebar-layout { min-height: calc(100vh - 70px); }
      .rhandsontable { font-size: 13px; }
      .small-muted { color: #6c757d; font-size: 0.92rem; }
      .stat-box {
        border: 1px solid #dee2e6;
        border-radius: 0.5rem;
        padding: 0.75rem 1rem;
        background: #fff;
        margin-bottom: 0.75rem;
      }
      .microbiome-package-status {
        display: flex;
        flex-wrap: wrap;
        gap: 0.3rem 0.55rem;
        margin: 0.15rem 0 0.75rem;
        padding: 0.55rem 0.65rem;
        border: 1px solid #dce3e7;
        background: #f7f9fa;
        color: #314552;
        font-size: 0.78rem;
        line-height: 1.35;
      }
      .microbiome-package-status .package-ok { color: #176b52; }
      .microbiome-package-status .package-missing { color: #a33a35; font-weight: 600; }

      /*
       * Left-sidebar controls must remain readable when labels or option values
       * are wider than the sidebar.  Keep this rule out of right-hand plot
       * property panels and navbar menus.
       */
      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar {
        min-width: 0;
      }

      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .shiny-input-container,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .shiny-input-container,
      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .form-group,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .form-group {
        min-width: 0;
        max-width: 100%;
      }

      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .selectize-input,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .selectize-input {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        height: auto !important;
        min-height: calc(2.25rem + 2px);
        overflow: visible;
        padding-right: 2rem;
      }

      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar select.form-select,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar select.form-select,
      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar select.shiny-input-select,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar select.shiny-input-select,
      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar select option,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar select option {
        max-width: 100%;
        white-space: normal;
        overflow-wrap: anywhere;
        word-break: break-word;
        text-overflow: clip;
      }

      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .selectize-input > .item,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .selectize-input > .item,
      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .selectize-dropdown .option,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .selectize-dropdown .option,
      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .selectize-dropdown [data-selectable],
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .selectize-dropdown [data-selectable] {
        min-width: 0;
        max-width: 100%;
        white-space: normal !important;
        overflow-wrap: anywhere;
        word-break: break-word;
        line-height: 1.35;
        padding-left: 0.75rem;
        text-indent: -0.75rem;
      }

      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .selectize-input > .item {
        flex: 0 1 auto;
      }

      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .bootstrap-select > .dropdown-toggle,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .bootstrap-select > .dropdown-toggle {
        height: auto;
        min-height: calc(2.25rem + 2px);
        align-items: flex-start;
      }

      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .bootstrap-select .filter-option-inner-inner,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .bootstrap-select .filter-option-inner-inner,
      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .bootstrap-select .dropdown-item .text,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .bootstrap-select .dropdown-item .text {
        display: block;
        white-space: normal !important;
        overflow-wrap: anywhere;
        word-break: break-word;
        line-height: 1.35;
        padding-left: 0.75rem;
        text-indent: -0.75rem;
      }

      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .choices__inner,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .choices__inner {
        height: auto;
        min-height: calc(2.25rem + 2px);
      }

      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .choices__item,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .choices__item {
        max-width: 100%;
        white-space: normal;
        overflow-wrap: anywhere;
        word-break: break-word;
        line-height: 1.35;
        padding-left: 0.75rem;
        text-indent: -0.75rem;
      }

      .bslib-sidebar-layout:not(.sidebar-right) > .sidebar .btn,
      .bslib-sidebar-layout:not(.sidebar-right) > aside.sidebar .btn {
        height: auto;
        min-height: calc(2.25rem + 2px);
        white-space: normal;
        overflow-wrap: anywhere;
        line-height: 1.35;
      }

      /* Allow nested navbar menus */
      .navbar .dropdown-menu {
        overflow: visible !important;
      }

      .navbar .dropdown-menu .dropdown {
        position: relative;
      }

      .navbar .dropdown-menu .dropdown-menu {
        top: 0;
        left: 100%;
        margin-top: 0;
        display: none;
      }

      .navbar .dropdown-menu .dropdown:hover > .dropdown-menu {
        display: block;
      }

      .navbar .dropdown-menu .dropdown-item,
      .navbar .dropdown-menu .nav-link {
        display: flex !important;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        padding: 0.45rem 1rem !important;
        margin: 0 !important;
        line-height: 1.4;
        color: var(--bs-dropdown-link-color) !important;
        text-align: left !important;
        white-space: nowrap;
      }

      .navbar .dropdown-menu .dropdown-item:hover,
      .navbar .dropdown-menu .nav-link:hover {
        color: var(--bs-dropdown-link-hover-color) !important;
        background-color: var(--bs-dropdown-link-hover-bg) !important;
      }

      .navbar .dropdown-menu .dropdown-toggle::after {
        margin-left: 1.5rem;
        flex-shrink: 0;
      }

      .navbar .dropdown-menu .dropdown > .dropdown-toggle::after {
        transform: rotate(-90deg);
      }

      /*
       * DAVA visual system
       * Presentation-only rules: do not change component structure, sizing
       * contracts, input bindings, or analysis behaviour.
       */
      :root {
        --dava-canvas: #f3f7f9;
        --dava-canvas-deep: #eaf1f4;
        --dava-surface: rgba(255, 255, 255, 0.96);
        --dava-surface-soft: #f7fafb;
        --dava-border: #d8e4e8;
        --dava-border-strong: #c5d7dc;
        --dava-ink: #20363d;
        --dava-muted: #667d84;
        --dava-primary: #147d78;
        --dava-primary-dark: #0e625f;
        --dava-primary-soft: #e4f4f2;
        --dava-accent: #49a88e;
        --dava-info: #397eae;
        --dava-warning: #d68a25;
        --dava-danger: #c55252;
        --dava-radius-sm: 0.55rem;
        --dava-radius: 0.8rem;
        --dava-radius-lg: 1rem;
        --dava-shadow-sm: 0 2px 8px rgba(30, 65, 75, 0.07);
        --dava-shadow: 0 8px 24px rgba(30, 65, 75, 0.09);
        --dava-shadow-hover: 0 12px 30px rgba(30, 65, 75, 0.13);
      }

      html,
      body {
        color: var(--dava-ink);
        background-color: var(--dava-canvas);
      }

      body {
        background-image:
          radial-gradient(circle at 7% 4%, rgba(73, 168, 142, 0.09), transparent 24rem),
          linear-gradient(145deg, var(--dava-canvas) 0%, #f8fafb 46%, var(--dava-canvas-deep) 100%);
        background-attachment: fixed;
      }

      body > .container-fluid,
      .bslib-page-fill,
      .bslib-page-sidebar {
        background-color: transparent;
      }

      /* Global navigation: stronger hierarchy without altering menu behaviour. */
      .navbar {
        border: 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.13);
        background: linear-gradient(115deg, #103f49 0%, #116b68 54%, #148175 100%) !important;
        box-shadow: 0 5px 18px rgba(18, 61, 69, 0.18);
      }

      .navbar .navbar-brand {
        color: #fff !important;
        font-weight: 700;
        letter-spacing: 0.02em;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      }

      .navbar > .container-fluid > .navbar-collapse > .navbar-nav > .nav-item > .nav-link,
      .navbar > .container-fluid > .navbar-collapse > .navbar-nav > .nav-link {
        position: relative;
        color: rgba(255, 255, 255, 0.84) !important;
        border-radius: var(--dava-radius-sm);
        font-weight: 500;
      }

      .navbar > .container-fluid > .navbar-collapse > .navbar-nav > .nav-item > .nav-link:hover,
      .navbar > .container-fluid > .navbar-collapse > .navbar-nav > .nav-item > .nav-link:focus,
      .navbar > .container-fluid > .navbar-collapse > .navbar-nav > .nav-item > .nav-link.active,
      .navbar > .container-fluid > .navbar-collapse > .navbar-nav > .nav-link.active {
        color: #fff !important;
        background-color: rgba(255, 255, 255, 0.12);
      }

      .navbar > .container-fluid > .navbar-collapse > .navbar-nav > .nav-item > .nav-link.active::after,
      .navbar > .container-fluid > .navbar-collapse > .navbar-nav > .nav-link.active::after {
        position: absolute;
        right: 0.7rem;
        bottom: 0.18rem;
        left: 0.7rem;
        height: 2px;
        content: \"\";
        border-radius: 999px;
        background: #bce7da;
      }

      .navbar .dropdown-menu {
        padding: 0.4rem;
        border: 1px solid var(--dava-border);
        border-radius: var(--dava-radius);
        background: rgba(255, 255, 255, 0.98);
        box-shadow: var(--dava-shadow);
      }

      .navbar .dropdown-menu .dropdown-item,
      .navbar .dropdown-menu .nav-link {
        border-radius: 0.45rem;
      }

      .navbar .dropdown-menu .dropdown-item:hover,
      .navbar .dropdown-menu .nav-link:hover,
      .navbar .dropdown-menu .dropdown-item:focus,
      .navbar .dropdown-menu .nav-link:focus {
        color: var(--dava-primary-dark) !important;
        background-color: var(--dava-primary-soft) !important;
      }

      /* Left analysis controls and right property panels. */
      .bslib-sidebar-layout > .sidebar,
      .bslib-sidebar-layout > aside.sidebar {
        border-color: var(--dava-border) !important;
        background:
          linear-gradient(180deg, rgba(255, 255, 255, 0.98), rgba(244, 249, 249, 0.97)) !important;
        box-shadow: 4px 0 16px rgba(38, 76, 85, 0.045);
      }

      .bslib-sidebar-layout.sidebar-right > .sidebar,
      .bslib-sidebar-layout.sidebar-right > aside.sidebar {
        box-shadow: -4px 0 16px rgba(38, 76, 85, 0.045);
      }

      .sidebar h1,
      .sidebar h2,
      .sidebar h3,
      .sidebar h4,
      .sidebar h5,
      .sidebar h6 {
        color: #25454d;
        font-weight: 650;
      }

      .sidebar hr {
        border-color: var(--dava-border);
        opacity: 0.9;
      }

      /* Reusable analysis sections and Bootstrap/bslib cards. */
      .stat-box,
      .card,
      .bslib-card {
        border-color: var(--dava-border) !important;
        border-radius: var(--dava-radius) !important;
        background-color: var(--dava-surface);
        box-shadow: var(--dava-shadow-sm);
      }

      .stat-box {
        position: relative;
        padding: 0.9rem 1rem;
        border-left: 3px solid rgba(20, 125, 120, 0.55) !important;
      }

      .card-header,
      .bslib-card .card-header {
        border-bottom-color: var(--dava-border);
        border-radius: calc(var(--dava-radius) - 1px) calc(var(--dava-radius) - 1px) 0 0 !important;
        background: linear-gradient(180deg, #fbfdfd 0%, #f2f7f8 100%);
        color: #284950;
        font-weight: 600;
      }

      .card-footer,
      .bslib-card .card-footer {
        border-top-color: var(--dava-border);
        background-color: var(--dava-surface-soft);
      }

      .card-title {
        color: #23464d;
        font-weight: 650;
      }

      /* Tabs read as interactive navigation instead of flat text. */
      .nav-tabs {
        gap: 0.2rem;
        padding: 0.25rem 0.3rem 0;
        border-bottom-color: var(--dava-border-strong);
      }

      .nav-tabs .nav-link {
        margin-bottom: -1px;
        border: 1px solid transparent;
        border-radius: 0.6rem 0.6rem 0 0;
        color: var(--dava-muted);
        font-weight: 500;
      }

      .nav-tabs .nav-link:hover,
      .nav-tabs .nav-link:focus {
        border-color: var(--dava-border) var(--dava-border) transparent;
        color: var(--dava-primary-dark);
        background-color: rgba(228, 244, 242, 0.65);
      }

      .nav-tabs .nav-link.active,
      .nav-tabs .nav-item.show .nav-link {
        border-color: var(--dava-border-strong) var(--dava-border-strong) #fff;
        color: var(--dava-primary-dark);
        background-color: #fff;
        box-shadow: 0 -2px 8px rgba(30, 65, 75, 0.04);
      }

      .nav-pills {
        gap: 0.25rem;
        padding: 0.25rem;
        border-radius: 0.7rem;
        background-color: #eaf1f3;
      }

      .nav-pills .nav-link {
        border-radius: 0.5rem;
        color: var(--dava-muted);
      }

      .nav-pills .nav-link.active,
      .nav-pills .show > .nav-link {
        color: #fff;
        background: linear-gradient(135deg, var(--dava-primary), var(--dava-accent));
        box-shadow: 0 3px 8px rgba(20, 125, 120, 0.22);
      }

      /* Form controls retain native bindings and dimensions. */
      .form-label,
      .control-label,
      .shiny-input-container > label {
        color: #36535a;
        font-weight: 550;
      }

      .form-control,
      .form-select,
      .selectize-input,
      .bootstrap-select > .dropdown-toggle,
      .choices__inner,
      .input-group-text {
        border-color: var(--dava-border-strong) !important;
        border-radius: var(--dava-radius-sm);
        background-color: rgba(255, 255, 255, 0.95);
        color: var(--dava-ink);
        box-shadow: inset 0 1px 2px rgba(30, 65, 75, 0.025);
      }

      .form-control:hover,
      .form-select:hover,
      .selectize-input:hover,
      .bootstrap-select > .dropdown-toggle:hover,
      .choices__inner:hover {
        border-color: #9fbfc3 !important;
      }

      .form-control:focus,
      .form-select:focus,
      .selectize-input.focus,
      .bootstrap-select > .dropdown-toggle:focus,
      .bootstrap-select.show > .dropdown-toggle,
      .choices.is-focused .choices__inner,
      .choices.is-open .choices__inner {
        border-color: var(--dava-primary) !important;
        box-shadow: 0 0 0 0.2rem rgba(20, 125, 120, 0.14) !important;
      }

      .selectize-dropdown,
      .bootstrap-select .dropdown-menu,
      .choices__list--dropdown {
        border-color: var(--dava-border);
        border-radius: var(--dava-radius-sm);
        box-shadow: var(--dava-shadow);
      }

      .selectize-dropdown .active,
      .bootstrap-select .dropdown-item.active,
      .bootstrap-select .dropdown-item:active,
      .choices__item--choice.is-highlighted {
        color: var(--dava-primary-dark);
        background-color: var(--dava-primary-soft);
      }

      .form-check-input:checked {
        border-color: var(--dava-primary);
        background-color: var(--dava-primary);
      }

      .form-check-input:focus,
      .irs--shiny .irs-handle:focus {
        border-color: var(--dava-primary);
        box-shadow: 0 0 0 0.2rem rgba(20, 125, 120, 0.14);
      }

      .irs--shiny .irs-bar,
      .irs--shiny .irs-single,
      .irs--shiny .irs-from,
      .irs--shiny .irs-to {
        border-color: var(--dava-primary);
        background: var(--dava-primary);
      }

      /* Buttons: consistent depth while preserving their existing semantics. */
      .btn {
        border-radius: var(--dava-radius-sm);
        font-weight: 550;
        box-shadow: 0 2px 5px rgba(30, 65, 75, 0.08);
      }

      .btn-primary {
        border-color: var(--dava-primary-dark);
        background: linear-gradient(135deg, var(--dava-primary), #16948a);
      }

      .btn-primary:hover,
      .btn-primary:focus,
      .btn-primary:active {
        border-color: #0b5855 !important;
        background: linear-gradient(135deg, var(--dava-primary-dark), var(--dava-primary)) !important;
      }

      .btn-success {
        border-color: #2f8068;
        background: linear-gradient(135deg, #3b9478, #54ad8d);
      }

      .btn-light,
      .btn-default,
      .btn-secondary {
        border-color: var(--dava-border-strong);
      }

      .btn:focus-visible {
        box-shadow: 0 0 0 0.22rem rgba(20, 125, 120, 0.2) !important;
      }

      /* Data-rich outputs: softer grid, clearer header and selection states. */
      table.dataTable,
      .table,
      .rhandsontable {
        border-color: var(--dava-border);
        background-color: rgba(255, 255, 255, 0.94);
      }

      .table > :not(caption) > * > *,
      table.dataTable > thead > tr > th,
      table.dataTable > tbody > tr > td {
        border-color: #e1eaed;
      }

      .table thead th,
      table.dataTable thead th,
      table.dataTable thead td {
        color: #31525a;
        background-color: #edf5f5;
        font-weight: 650;
      }

      .table-hover > tbody > tr:hover > *,
      table.dataTable.hover > tbody > tr:hover > *,
      table.dataTable.display > tbody > tr:hover > * {
        background-color: #eef8f6 !important;
      }

      .dataTables_wrapper .dataTables_paginate .paginate_button.current,
      .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
        border-color: var(--dava-primary) !important;
        border-radius: 0.4rem;
        color: #fff !important;
        background: var(--dava-primary) !important;
      }

      /* Secondary UI surfaces. */
      .accordion-item {
        overflow: hidden;
        border-color: var(--dava-border);
        border-radius: var(--dava-radius-sm) !important;
        background-color: var(--dava-surface);
      }

      .accordion-button {
        color: #31525a;
        background-color: var(--dava-surface-soft);
        font-weight: 600;
      }

      .accordion-button:not(.collapsed) {
        color: var(--dava-primary-dark);
        background-color: var(--dava-primary-soft);
        box-shadow: inset 0 -1px 0 var(--dava-border);
      }

      .accordion-button:focus {
        border-color: var(--dava-primary);
        box-shadow: 0 0 0 0.2rem rgba(20, 125, 120, 0.14);
      }

      .alert,
      .modal-content,
      .popover,
      .toast,
      .well {
        border-color: var(--dava-border);
        border-radius: var(--dava-radius);
        box-shadow: var(--dava-shadow-sm);
      }

      .modal-header,
      .modal-footer {
        border-color: var(--dava-border);
        background-color: var(--dava-surface-soft);
      }

      .progress {
        border-radius: 999px;
        background-color: #dfeaec;
        box-shadow: inset 0 1px 2px rgba(30, 65, 75, 0.08);
      }

      .progress-bar {
        background: linear-gradient(90deg, var(--dava-primary), var(--dava-accent));
      }

      .shiny-notification {
        border-color: var(--dava-border);
        border-radius: var(--dava-radius);
        box-shadow: var(--dava-shadow);
      }

      code,
      pre {
        border-radius: var(--dava-radius-sm);
      }

      pre {
        border: 1px solid var(--dava-border);
        background-color: #f5f8f9;
      }

      @media (prefers-reduced-motion: no-preference) {
        .btn,
        .card,
        .bslib-card,
        .stat-box,
        .nav-link,
        .form-control,
        .form-select,
        .selectize-input,
        .bootstrap-select > .dropdown-toggle {
          transition:
            color 140ms ease,
            background-color 140ms ease,
            border-color 140ms ease,
            box-shadow 140ms ease,
            transform 140ms ease;
        }

        .btn:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 5px 10px rgba(30, 65, 75, 0.13);
        }

        .card:hover,
        .bslib-card:hover {
          box-shadow: var(--dava-shadow-hover);
        }
      }

      @media (max-width: 767.98px) {
        body {
          background-image: linear-gradient(160deg, #f7fafb 0%, var(--dava-canvas-deep) 100%);
        }

        .navbar > .container-fluid > .navbar-collapse > .navbar-nav > .nav-item > .nav-link.active::after,
        .navbar > .container-fluid > .navbar-collapse > .navbar-nav > .nav-link.active::after {
          display: none;
        }

        .stat-box {
          padding: 0.75rem 0.8rem;
        }
      }
    "))
  )
}
