# R/file_management/mod_file_manager.R
# Unified file-management module.
#
# This module merges the previous five modules:
#   1. data import
#   2. workbook/sheet manager
#   3. table editor and preview
#   4. column operations
#   5. Excel export
#
# It keeps the original logic and exposes current_df(), rv, and update_df()
# so other modules can reuse the active dataset.

# ------------------------------
# UI: sidebar
# ------------------------------

mod_file_manger_ui<- function(id){
  ns <- NS(id)
  
  layout_sidebar(
    sidebar = sidebar(
      width = 285, 
      tagList(
        tags$div(
          class = "stat-box",
          tags$strong("1. Import data"),
          fileInput(
            ns("files"),
            "Upload Excel / CSV / TSV",
            multiple = TRUE,
            accept = c(".xlsx", ".xls", ".csv", ".tsv", ".txt")
          ),
          tags$div(class = "small-muted", "Supports importing multiple files at the same time; Excel automatically reads all worksheets.")
        ),
        
        tags$div(
          class = "stat-box",
          tags$strong("2. Original data set"),
          selectInput(
            ns("book_select"),
            "workbook",
            choices = stats::setNames("", "No workbook selected"),
            selected = "",
            selectize = FALSE
          ),
          selectInput(
            ns("sheet_select"),
            "worksheet",
            choices = stats::setNames("", "No worksheet selected"),
            selected = "",
            selectize = FALSE
          ),
          tags$div(class = "small-muted mt-2", "The original data cannot be modified directly!")
          
        ),
        
        tags$div(
          class = "stat-box",
          tags$strong("3. Dataset editing"),
          div(
            class = "d-grid gap-2",
            uiOutput(ns("global_dataset_ui")),
            actionButton(ns("save_as_new_open"), "Save as new dataset", class = "btn-success"),
            actionButton(ns("create_blank_open"), "Create a new blank form", class = "btn-outline-primary"),
            actionButton(ns("delete_global_dataset"), "Delete data set", class = "btn-outline-danger")
          ),
          
          tags$div(class = "small-muted mt-2", "Only manages edited datasets; the original data will not be deleted.")
        ),
        
        tags$div(
          class = "stat-box",
          tags$strong("4. Export file"),
          downloadButton(ns("download_current"), "Export current worksheet .csv", class = "btn-success"),
          tags$br(),
          tags$br(),
          downloadButton(ns("download_all"), "Export all workbooks .xlsx", class = "btn-success")
        )
      )
    ),
    
    layout_sidebar(
      sidebar = sidebar(
        width = 245,
        position = "right", 
        
        div(
          class = "stat-box",
          div(class = "tool-title"),
          tags$strong("1. Undo / redo"),
          tags$div(
            class = "d-grid gap-2",
            actionButton(ns("undo"), "Undo", class = "btn-outline-primary"),
            actionButton(ns("redo"), "Redo", class = "btn-outline-primary"),
          ),
          div(class = "small-muted", textOutput(ns("history_text")))
        ),
        
        tags$div(
          class = "stat-box",
          tags$strong("2. Table tools"),
          #uiOutput(ns("column_select_ui"), style = "display:none;"),
          tags$div(
            class = "d-grid gap-2",
            actionButton(ns("remove_dups"), "Rename row names", class = "btn-outline-secondary"),
            actionButton(ns("rename_col_open"), "Rename column names", class = "btn-outline-primary"),
            actionButton(ns("convert_col_open"), "Convert column type", class = "btn-outline-secondary"),
            actionButton(ns("replace_na_open"), "Move row and column position", class = "btn-outline-secondary"),
            actionButton(ns("insert_names_open"), "Row and column name insertion", class = "btn-outline-primary"),
            actionButton(ns("find_open"), "Find and Replace", class = "btn-outline-primary"),
            actionButton(ns("select_col_open"), "Filter/keep columns", class = "btn-outline-primary"),
            actionButton(ns("transpose_open"), "Table transpose", class = "btn-outline-secondary"),
            actionButton(ns("split_open"), "sort", class = "btn-outline-secondary"),
            actionButton(ns("merge_open"), "Merge columns", class = "btn-outline-secondary"),
            actionButton(ns("formula_open"), "Formula column", class = "btn-outline-secondary"),
            actionButton(ns("fill_open"), "Bulk filling", class = "btn-outline-secondary")
          )
        ),
        
        tags$div(
          class = "stat-box",
          tags$strong("3. Dataset operations"),
          div(
            class = "d-grid gap-2",
            actionButton(ns("join_open"), "Dataset key connection", class = "btn-outline-primary"),
            actionButton(ns("bind_rows_open"), "Dataset appended by rows", class = "btn-outline-primary"),
            actionButton(ns("bind_cols_open"), "Datasets merged by columns", class = "btn-outline-primary"),
            actionButton(ns("pivot_long_open"), "Convert to long data", class = "btn-outline-secondary"),
            actionButton(ns("pivot_wide_open"), "Convert to wide data", class = "btn-outline-secondary"),
            actionButton(ns("summarise_open"), "Group summary", class = "btn-outline-secondary")
          )
        )
        
      ),
      
      card(
        class = "dava-hot-card border-0 shadow-none",
        full_screen = TRUE,
        card_body(
          class = "dava-hot-card-body",
          tags$style(HTML("
          .dava-hot-toolbar {
            display: grid;
            gap: 8px;
            margin-bottom: 8px;
          }
          .dava-hot-card {
            border: 0 !important;
            box-shadow: none !important;
          }
          .dava-hot-card-body {
            padding: 0 !important;
          }
          .dava-hot-scroll {
            width: 100%;
            max-width: 100%;
            overflow-x: auto;
            overflow-y: hidden;
            padding: 0 8px 8px 8px;
          }
          .dava-hot-card-body .rhandsontable,
          .dava-hot-card-body .html-widget {
            width: 100% !important;
          }
          .dava-hot-card-body .html-widget {
            overflow: visible !important;
          }
          .dava-hot-card-body .handsontable .wtHolder {
            overflow: auto !important;
          }
          .dava-hot-card-body .handsontable .dava-hot-type-label {
            color: #6c757d;
            font-size: 12px;
            font-weight: 400;
            line-height: 14px;
          }
          .dava-hot-card-body .handsontable .dava-hot-name-label {
            color: #2f3e46;
            font-size: 13px;
            font-weight: 400;
            line-height: 18px;
          }
          .dava-hot-summary {
            display: block;
            color: #52606d;
            font-size: 13px;
            line-height: 1.45;
            padding-bottom: 2px;
          }
          .dava-hot-stats {
            display: block;
            margin-bottom: 4px;
            font-size: 12px;
            color: #6c757d;
          }
          .dava-hot-info {
            display: block;
            font-size: 12px;
            color: #6c757d;
          }
          .dava-hot-controls {
            display: grid;
            grid-template-columns: 120px 140px 120px 140px 140px;
            gap: 12px;
            align-items: end;
          }
          .dava-hot-controls .form-group,
          .dava-hot-controls .shiny-input-container {
            margin-bottom: 0;
          }
          @media (max-width: 760px) {
            .dava-hot-controls { grid-template-columns: 1fr; }
          }
        ")),
          tags$div(
            class = "dava-hot-toolbar",
            tags$div(class = "dava-hot-summary",
                     textOutput(ns("table_page_summary"))
            ),
            tags$div(
              class = "dava-hot-controls",
              numericInput(ns("hot_page"), "Page", value = 1, min = 1, step = 1, width = "100%"),
              selectInput(
                ns("hot_page_size"),
                "Rows per page",
                choices = c(50, 100, 200, 500, 1000),
                selected = 200,
                width = "100%",
                selectize = FALSE
              ),
              numericInput(ns("hot_col_page"), "Column page", value = 1, min = 1, step = 1, width = "100%"),
              selectInput(
                ns("hot_col_page_size"),
                "Columns per page",
                choices = c(50, 100, 200, 500, 1000),
                selected = 50,
                width = "100%",
                selectize = FALSE
              ),
              actionButton(ns("hot_apply_page"), "Refresh", class = "btn-outline-primary")
            )
          ),
          tags$div(
            class = "dava-hot-scroll",
            rHandsontableOutput(ns("hot"), height = "calc(100vh - 210px)")
          )
        )
      )
    )
    
  )
  
}



mod_file_manager_log_ui <- function(id) {
  ns <- NS(id)

  card(
    full_screen = TRUE,
    card_header("Operation log"),
    card_body(DTOutput(ns("log_table")))
  )
}

mod_file_manager_micro_import_ui <- function(id) {
  ns <- NS(id)

  card(
    card_header(
      div(
        style = "display:flex; justify-content:space-between; align-items:center; gap:12px;",
        h4("Microbial data import", style = "margin:0;"),
        uiOutput(ns("micro_package_status"))
      )
    ),
    layout_sidebar(
      sidebar = sidebar(
        width = 350,
        tags$div(
          class = "stat-box",
          tags$strong("Data file upload"),
          fileInput(ns("micro_otu_file"), "OTU/ASV abundance table", accept = c(".csv", ".tsv", ".txt", ".xlsx", ".xls", ".biom", ".json", ".qza")),
          fileInput(ns("micro_tax_file"), "Classification annotation table", accept = c(".csv", ".tsv", ".txt", ".xlsx", ".xls", ".qza")),
          fileInput(ns("micro_seq_file"), "represents the sequence", accept = c(".fa", ".fasta", ".fna", ".txt", ".qza")),
          fileInput(ns("micro_tree_file"), "Phylogenetic tree", accept = c(".nwk", ".tree", ".tre", ".txt", ".qza")),
          fileInput(ns("micro_meta_file"), "sample metadata", accept = c(".csv", ".tsv", ".txt", ".xlsx", ".xls", ".qza")),
          fileInput(ns("micro_other_files"), "Other tools export files", multiple = TRUE, accept = c(".csv", ".tsv", ".txt", ".xlsx", ".xls", ".biom", ".json", ".qza", ".fa", ".fasta", ".nwk", ".tree", ".tre")),
          tags$div(
            class = "small-muted",
            "After selecting the file, it will be automatically imported and synchronized to the table editing module. Compatible with QIIME2, BIOM, FASTA/Newick, Excel/CSV/TSV."
          )
        ),
        tags$div(
          class = "stat-box",
          tags$strong("Sample data"),
          actionButton(ns("micro_load_demo"), "Load sample data", icon = icon("flask"), class = "btn-outline-primary w-100"),
          tags$div(
            class = "small-muted mt-2",
            "The sample data is consistent with the simulated data in the Microbial Data Analysis module Alpha Diversity Analysis."
          )
        )
      ),
      navset_card_tab(
        id = ns("micro_import_tab"),
        nav_panel("OTU/ASV abundance table", DTOutput(ns("micro_abundance_preview"))),
        nav_panel("Classification annotation table", DTOutput(ns("micro_taxonomy_preview"))),
        nav_panel("represents the sequence", DTOutput(ns("micro_sequences_preview"))),
        nav_panel("Phylogenetic tree", DTOutput(ns("micro_tree_preview"))),
        nav_panel("sample metadata", DTOutput(ns("micro_metadata_preview"))),
        nav_panel(
          "Other tools export files",
          uiOutput(ns("micro_other_preview_select")),
          DTOutput(ns("micro_other_preview"))
        ),
        nav_panel(
          "Errors and Diagnostics",
          tags$div(
            class = "d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2",
            uiOutput(ns("micro_diagnostic_summary")),
            actionButton(
              ns("micro_clear_diagnostics"), "Clear diagnostics",
              icon = icon("trash-can"), class = "btn-outline-secondary btn-sm"
            )
          ),
          DTOutput(ns("micro_diagnostics"))
        )
      )
    )
  )
}
dava_micro_optional_packages <- function() {
  c("ape", "Biostrings", "biomformat", "rhdf5", "phyloseq")
}

dava_micro_package_table <- function() {
  pkgs <- dava_micro_optional_packages()
  data.frame(
    package = pkgs,
    installed = vapply(pkgs, requireNamespace, logical(1), quietly = TRUE),
    role = c("Newick tree parsing", "FASTA parsing", "BIOM JSON parsing", "BIOM HDF5 parsing", "integrated microbiome objects"),
    stringsAsFactors = FALSE
  )
}

dava_micro_is_hdf5 <- function(path) {
  magic <- tryCatch(readBin(path, what = "raw", n = 8), error = function(e) raw())
  length(magic) >= 4 && identical(as.integer(magic[1:4]), c(137L, 72L, 68L, 70L))
}

dava_micro_h5_read_first <- function(path, candidates) {
  for (candidate in candidates) {
    value <- tryCatch(rhdf5::h5read(path, candidate), error = function(e) NULL)
    if (!is.null(value)) return(value)
  }
  NULL
}

dava_micro_read_hdf5_biom <- function(path) {
  if (!requireNamespace("rhdf5", quietly = TRUE)) {
    stop("Reading HDF5 BIOM requires the rhdf5 package to be installed.", call. = FALSE)
  }
  obs_ids <- dava_micro_h5_read_first(path, c("/observation/ids", "observation/ids"))
  sample_ids <- dava_micro_h5_read_first(path, c("/sample/ids", "sample/ids"))
  data <- dava_micro_h5_read_first(path, c("/observation/matrix/data", "observation/matrix/data"))
  indices <- dava_micro_h5_read_first(path, c("/observation/matrix/indices", "observation/matrix/indices"))
  indptr <- dava_micro_h5_read_first(path, c("/observation/matrix/indptr", "observation/matrix/indptr"))

  if (is.null(obs_ids) || is.null(sample_ids) || is.null(data) || is.null(indices) || is.null(indptr)) {
    stop("HDF5 BIOM missing observation/sample ids or sparse matrix data.", call. = FALSE)
  }

  obs_ids <- as.character(obs_ids)
  sample_ids <- as.character(sample_ids)
  mat <- matrix(0, nrow = length(obs_ids), ncol = length(sample_ids), dimnames = list(obs_ids, sample_ids))
  indices <- as.integer(indices)
  indptr <- as.integer(indptr)
  data <- as.numeric(data)

  for (i in seq_len(length(obs_ids))) {
    start <- indptr[i] + 1L
    end <- indptr[i + 1L]
    if (end >= start) {
      pos <- seq.int(start, end)
      mat[i, indices[pos] + 1L] <- data[pos]
    }
  }
  out <- data.frame(Feature = rownames(mat), mat, check.names = FALSE)
  rownames(out) <- NULL
  normalize_df(out)
}

dava_micro_first_existing <- function(paths, pattern) {
  hits <- paths[grepl(pattern, basename(paths), ignore.case = TRUE)]
  hits[1] %||% NA_character_
}

dava_micro_qza_extract <- function(path) {
  td <- tempfile("dava_qza_")
  dir.create(td, recursive = TRUE, showWarnings = FALSE)
  utils::unzip(path, exdir = td)
  list(root = td, files = list.files(td, recursive = TRUE, full.names = TRUE))
}

dava_excel_format <- function(path, original_name = basename(path)) {
  magic <- tryCatch(readBin(path, what = "raw", n = 8L),
    error = function(error) raw())
  bytes <- as.integer(magic)
  if (length(bytes) >= 8L && identical(bytes[1:8],
      c(208L, 207L, 17L, 224L, 161L, 177L, 26L, 225L))) return("xls")
  if (length(bytes) >= 4L && identical(bytes[1:4],
      c(80L, 75L, 3L, 4L))) return("xlsx")
  extension <- tolower(tools::file_ext(original_name))
  if (extension %in% c("xls", "xlsx")) extension else ""
}

dava_with_excel_upload <- function(path, original_name, callback) {
  if (!requireNamespace("readxl", quietly = TRUE)) {
    stop("Reading Excel files requires the readxl package to be installed.", call. = FALSE)
  }
  format <- dava_excel_format(path, original_name)
  if (!nzchar(format)) {
    stop(paste0(
      "The Excel file format is not recognized.",
      " The file may be an HTML/text file but uses the .xls extension."
    ), call. = FALSE)
  }
  excel_path <- path
  temporary_path <- NULL
  if (!identical(tolower(tools::file_ext(path)), format)) {
    temporary_path <- tempfile("dava_excel_upload_", fileext = paste0(".", format))
    if (!file.copy(path, temporary_path, overwrite = TRUE)) {
      stop("Unable to create a temporary copy of the Excel upload file.", call. = FALSE)
    }
    excel_path <- temporary_path
  }
  if (!is.null(temporary_path)) on.exit(unlink(temporary_path), add = TRUE)
  tryCatch(
    callback(excel_path, format),
    error = function(error) {
      guidance <- if (identical(format, "xls")) {
        "Please confirm that this is an unencrypted Excel 97-2003 workbook; if it still fails, save as .xlsx in Excel."
      } else {
        "Please confirm that the workbook is not encrypted, not damaged, and the extension is consistent with the real format."
      }
      stop(sprintf("Excel read failed (%s): %s %s",
        format, conditionMessage(error), guidance), call. = FALSE)
    }
  )
}

dava_read_excel_sheet <- function(path, original_name = basename(path), sheet = 1) {
  dava_with_excel_upload(path, original_name, function(excel_path, format) {
    reader <- if (identical(format, "xls")) readxl::read_xls else readxl::read_xlsx
    reader(excel_path, sheet = sheet)
  })
}

dava_excel_sheets <- function(path, original_name = basename(path)) {
  dava_with_excel_upload(path, original_name, function(excel_path, format) {
    readxl::excel_sheets(excel_path)
  })
}

dava_micro_read_table_file <- function(path, original_name = basename(path)) {
  ext <- tolower(tools::file_ext(original_name))
  if (ext == "qza") {
    qza <- dava_micro_qza_extract(path)
    biom <- dava_micro_first_existing(qza$files, "\\.biom$")
    table <- dava_micro_first_existing(qza$files, "\\.(tsv|txt|csv)$")
    if (!is.na(biom)) return(dava_micro_read_table_file(biom, basename(biom)))
    if (!is.na(table)) return(dava_micro_read_table_file(table, basename(table)))
    stop("No parsable BIOM/CSV/TSV/TXT data file found in QZA.", call. = FALSE)
  }
  if (ext %in% c("xlsx", "xls")) {
    return(normalize_df(dava_read_excel_sheet(path, original_name, sheet = 1)))
  }
  if (ext %in% c("csv", "tsv", "txt")) {
    out <- if (ext == "csv") {
      utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE, comment.char = "")
    } else {
      utils::read.delim(path, stringsAsFactors = FALSE, check.names = FALSE, comment.char = "")
    }
    return(normalize_df(out))
  }
  if (ext %in% c("biom", "json")) {
    if (dava_micro_is_hdf5(path)) {
      return(dava_micro_read_hdf5_biom(path))
    }
    if (!requireNamespace("biomformat", quietly = TRUE)) {
      stop("Reading the BIOM requires the biomformat package to be installed.", call. = FALSE)
    }
    biom <- biomformat::read_biom(path)
    mat <- as.matrix(biomformat::biom_data(biom))
    out <- data.frame(Feature = rownames(mat), mat, check.names = FALSE)
    rownames(out) <- NULL
    return(normalize_df(out))
  }
  stop(sprintf("This table type is not supported yet: %s", ext), call. = FALSE)
}

dava_micro_read_fasta <- function(path, original_name = basename(path)) {
  ext <- tolower(tools::file_ext(original_name))
  if (ext == "qza") {
    qza <- dava_micro_qza_extract(path)
    fasta <- dava_micro_first_existing(qza$files, "\\.(fa|fasta|fna)$")
    if (!is.na(fasta)) return(dava_micro_read_fasta(fasta, basename(fasta)))
    stop("FASTA sequence file not found in QZA.", call. = FALSE)
  }
  if (requireNamespace("Biostrings", quietly = TRUE)) {
    dna <- Biostrings::readDNAStringSet(path)
    return(data.frame(
      Feature = names(dna),
      Sequence = as.character(dna),
      Length = Biostrings::width(dna),
      stringsAsFactors = FALSE,
      check.names = FALSE
    ))
  }
  lines <- readLines(path, warn = FALSE)
  headers <- grep("^>", lines)
  if (!length(headers)) stop("FASTA header not recognized.", call. = FALSE)
  ends <- c(headers[-1] - 1, length(lines))
  data.frame(
    Feature = sub("^>", "", lines[headers]),
    Sequence = vapply(seq_along(headers), function(i) paste(lines[(headers[i] + 1):ends[i]], collapse = ""), character(1)),
    Length = ends - headers,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

dava_micro_read_tree <- function(path, original_name = basename(path)) {
  ext <- tolower(tools::file_ext(original_name))
  if (ext == "qza") {
    qza <- dava_micro_qza_extract(path)
    tree <- dava_micro_first_existing(qza$files, "\\.(nwk|tree|tre)$")
    if (!is.na(tree)) return(dava_micro_read_tree(tree, basename(tree)))
    stop("Newick tree file not found in QZA.", call. = FALSE)
  }
  newick <- trimws(paste(readLines(path, warn = FALSE), collapse = ""))
  if (nzchar(newick) && !grepl(";\\s*$", newick, perl = TRUE)) {
    newick <- paste0(newick, ";")
  }
  if (requireNamespace("ape", quietly = TRUE)) {
    tree <- dava_parse_newick_tree(newick)
    return(list(
      table = data.frame(Tip = tree$tip.label, stringsAsFactors = FALSE),
      object = tree,
      newick = newick
    ))
  }
  list(table = data.frame(Newick = newick, stringsAsFactors = FALSE), object = NULL, newick = newick)
}

dava_micro_tree_analysis_table <- function(value) {
  if (is.null(value)) return(NULL)
  newick <- trimws(as.character(value$newick %||% ""))
  if (!nzchar(newick) && inherits(value$object %||% NULL, "phylo") &&
      requireNamespace("ape", quietly = TRUE)) {
    newick <- ape::write.tree(value$object)
  }
  if (!nzchar(newick)) return(NULL)
  if (!grepl(";\\s*$", newick, perl = TRUE)) newick <- paste0(newick, ";")
  data.frame(Newick = newick, stringsAsFactors = FALSE,
    check.names = FALSE)
}

dava_micro_standardize_abundance <- function(df) {
  df <- normalize_df(df)
  if (!ncol(df)) return(df)
  first <- names(df)[1]
  names(df)[1] <- "Feature"
  df$Feature <- make.unique(as.character(df$Feature))
  for (nm in setdiff(names(df), "Feature")) df[[nm]] <- suppressWarnings(as.numeric(df[[nm]]))
  df
}

dava_micro_taxonomy_first_row_is_header <- function(df) {
  if (!is.data.frame(df) || ncol(df) < 2L) return(FALSE)
  headers <- names(df)
  first_is_feature_value <- grepl(
    "^(asv|otu|zotu|feature)[._-]?[[:alnum:]_-]*[0-9][[:alnum:]_.-]*$",
    headers[1], ignore.case = TRUE
  )
  remaining_contain_taxonomy <- any(grepl(
    ";|(^|[[:space:]])[dkpcofgs]__",
    headers[-1], ignore.case = TRUE
  ))
  isTRUE(first_is_feature_value && remaining_contain_taxonomy)
}

dava_micro_tax_from_semicolon <- function(df) {
  df <- normalize_df(df)
  if (!ncol(df)) return(df)
  # Headerless taxonomy exports are intentionally read with the first record
  # as column headers. Preserve that record verbatim instead of rewriting its
  # first value (for example ASV1) to the conventional name "Feature".
  if (dava_micro_taxonomy_first_row_is_header(df)) return(df)
  names(df)[1] <- "Feature"
  tax_col <- names(df)[grepl("taxon|taxonomy|classification", names(df), ignore.case = TRUE)][1]
  if (!is.na(tax_col)) {
    ranks <- c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species")
    parts <- strsplit(as.character(df[[tax_col]]), ";")
    parsed <- as.data.frame(do.call(rbind, lapply(parts, function(x) {
      x <- trimws(gsub("^[a-z]__", "", x))
      length(x) <- length(ranks)
      x
    })), stringsAsFactors = FALSE, check.names = FALSE)
    names(parsed) <- ranks
    df <- cbind(df["Feature"], parsed, df[, setdiff(names(df), c("Feature", ranks)), drop = FALSE])
  }
  normalize_df(df)
}

dava_micro_standardize_metadata <- function(df) {
  df <- normalize_df(df)
  if (!ncol(df)) return(df)
  sample_col <- names(df)[grepl("^sample(id)?$|sample[_ ]?name|#sampleid|^id$", names(df), ignore.case = TRUE)][1]
  if (is.na(sample_col)) sample_col <- names(df)[1]
  names(df)[names(df) == sample_col] <- "SampleID"
  df$SampleID <- make.unique(as.character(df$SampleID))
  df
}

dava_micro_demo_components <- function(seed = 20260726L) {
  if (exists("dava_local_demo_read", mode = "function", inherits = TRUE)) {
    bundle <- get("dava_local_demo_read", mode = "function", inherits = TRUE)("microbiome/base_16s.rds")
    counts <- as.data.frame(bundle$counts, check.names = FALSE)
    abundance <- data.frame(
      Feature = colnames(counts), t(counts), check.names = FALSE,
      stringsAsFactors = FALSE
    )
    taxonomy <- as.data.frame(bundle$taxonomy, check.names = FALSE)
    if (!"Feature" %in% names(taxonomy)) {
      taxonomy <- data.frame(
        Feature = rownames(taxonomy), taxonomy, check.names = FALSE,
        stringsAsFactors = FALSE
      )
    }
    metadata <- as.data.frame(bundle$metadata, check.names = FALSE)
    if (!"SampleID" %in% names(metadata)) {
      metadata <- data.frame(
        SampleID = rownames(metadata), metadata, check.names = FALSE,
        stringsAsFactors = FALSE
      )
    }
    environment <- as.data.frame(bundle$environment, check.names = FALSE)
    if (!NROW(environment)) {
      numeric_columns <- names(metadata)[vapply(metadata, is.numeric, logical(1))]
      environment <- metadata[, unique(c("SampleID", numeric_columns)), drop = FALSE]
    } else if (!"SampleID" %in% names(environment)) {
      environment <- data.frame(
        SampleID = rownames(environment), environment, check.names = FALSE,
        stringsAsFactors = FALSE
      )
    }
    grouping_columns <- setdiff(names(metadata)[vapply(
      metadata, function(value) is.factor(value) || is.character(value) ||
        is.logical(value), logical(1))], "SampleID")
    group <- metadata[, unique(c("SampleID", grouping_columns)), drop = FALSE]
    return(list(
      otu = abundance, taxonomy = taxonomy, group = group,
      env = environment, metadata = metadata
    ))
  }
  stop("The local microbiome simulated-data asset loader is unavailable.", call. = FALSE)
}


# ------------------------------
# Server
# ------------------------------

dava_split_column <- function(df, col_name, sep, n_into = 2L,
                              prefix = NULL, remove_original = FALSE) {
  if (!is.data.frame(df)) stop("Column data must be a data frame.", call. = FALSE)
  if (!is.character(col_name) || length(col_name) != 1L ||
      !nzchar(col_name) || !(col_name %in% names(df))) {
    stop("Please select a valid field.", call. = FALSE)
  }
  if (!is.character(sep) || length(sep) != 1L || !nzchar(sep)) {
    stop("Delimiter cannot be empty.", call. = FALSE)
  }
  n_into <- suppressWarnings(as.integer(n_into)[1])
  if (is.na(n_into) || n_into < 2L) {
    stop("The maximum number of split columns must be an integer no less than 2.", call. = FALSE)
  }

  prefix <- trimws(as.character(prefix %||% "")[1])
  if (!nzchar(prefix)) prefix <- paste0(col_name, "_")
  split_values <- strsplit(as.character(df[[col_name]]), split = sep, fixed = TRUE)
  new_values <- matrix(NA_character_, nrow = nrow(df), ncol = n_into)
  for (row_index in seq_along(split_values)) {
    values <- utils::head(split_values[[row_index]], n_into)
    if (length(values)) new_values[row_index, seq_along(values)] <- values
  }

  new_columns <- as.data.frame(new_values, stringsAsFactors = FALSE, check.names = FALSE)
  names(new_columns) <- paste0(prefix, seq_len(n_into))
  result <- df
  if (isTRUE(remove_original)) result[[col_name]] <- NULL
  result <- dplyr::bind_cols(result, new_columns)
  names(result) <- make_unique_names(names(result))
  result
}

file_manager_state <- function() {
  reactiveValues(
      books = list(),
      book_sources = list(),
      dataset_sources = list(),
      active_book = NULL,
      active_sheet = NULL,
      log = tibble::tibble(
        time = character(),
        book = character(),
        sheet = character(),
        action = character(),
        detail = character()
      ),
      undo_stack = list(),
      redo_stack = list(),
      max_history = 50,
      
      readOnly = TRUE,
      file_library = list(
        books = list(),
        global_datasets = list(),
        book_sources = list(),
        dataset_sources = list(),
        active_book = NULL,
        active_sheet = NULL,
        active_dataset = NULL,
        readOnly = TRUE
      ),
      global_datasets=list(),
      active_dataset = NULL,
      plot_registry = list(),
      svg_gallery = list(),
      code_registry = list(),
      method_code_overrides = list(),
      method_code_revision = 0L,
      plugin_registry = list(),
      code_settings = dava_code_settings_defaults(),
      microbiome_import = list(),
      workspace_import_request = NULL,
      workspace_import_error = "",
      workspace_pending_inputs = list(),
      workspace_loaded_modules = character(),
      workspace_last_saved = NULL,
      workspace_last_loaded = NULL,
      workspace_restore_in_progress = FALSE,
      workspace_restore_generation = 0L,
      workspace_restore_phase = "idle",
      workspace_restore_error = "",
      workspace_restore_backup = NULL,
      workspace_restore_backup_missing = character(),
      workspace_restore_target_registry_version = NULL,
      workspace_restore_required_modules = character(),
      workspace_restored_modules = character(),
      workspace_module_states = list()
  )
}

dava_register_global_datasets <- function(rv, tables, source, prefix = "result", overwrite = FALSE) {
  if (!is.list(tables) || !length(tables) || is.null(names(tables)) || any(!nzchar(names(tables)))) {
    stop("Bulk registration requires a non-empty named result table list.", call. = FALSE)
  }
  datasets <- shiny::isolate(rv$global_datasets %||% list())
  sources <- shiny::isolate(rv$dataset_sources %||% list())
  registered <- character(length(tables))
  existing <- names(datasets)
  safe_name <- function(value) {
    value <- gsub("[^[:alnum:]_\u4e00-\u9fff]+", "_", value)
    value <- gsub("_+", "_", value)
    trimws(value, whitespace = "_")
  }
  for (index in seq_along(tables)) {
    base <- safe_name(paste(prefix, names(tables)[index], sep = "_"))
    candidate <- base
    if (!isTRUE(overwrite)) {
      suffix <- 1L
      while (candidate %in% c(existing, registered)) {
        suffix <- suffix + 1L
        candidate <- paste0(base, "_", suffix)
      }
    }
    datasets[[candidate]] <- normalize_df_keep_rownames(as.data.frame(tables[[index]], check.names = FALSE))
    sources[[candidate]] <- source
    registered[index] <- candidate
  }
  active <- shiny::isolate(rv$active_dataset %||% NULL)
  read_only <- shiny::isolate(rv$readOnly %||% TRUE)
  active_book <- shiny::isolate(rv$active_book %||% NULL)
  active_sheet <- shiny::isolate(rv$active_sheet %||% NULL)
  rv$global_datasets <- datasets
  rv$dataset_sources <- sources
  rv$active_dataset <- active
  rv$readOnly <- read_only
  rv$active_book <- active_book
  rv$active_sheet <- active_sheet
  rv$data_registry_version <- shiny::isolate(rv$data_registry_version %||% 0L) + 1L
  stats::setNames(registered, names(tables))
}

dava_find_table_cells <- function(df, query, scope = "all", columns = NULL,
                                  row_from = NULL, row_to = NULL,
                                  match_case = FALSE, whole_cell = FALSE,
                                  use_regex = FALSE, find_empty = FALSE) {
  df <- as.data.frame(df, check.names = FALSE)
  query <- as.character(query %||% "")[1]
  if (!isTRUE(find_empty) && (is.na(query) || !nzchar(query))) {
    stop("The search content cannot be empty; if you need to find null values, please check \"Find null values\".", call. = FALSE)
  }
  if (!scope %in% c("all", "columns", "rows")) stop("Invalid search range.", call. = FALSE)

  column_indices <- seq_len(ncol(df))
  row_indices <- seq_len(nrow(df))
  if (identical(scope, "columns")) {
    columns <- intersect(as.character(columns %||% character(0)), names(df))
    if (!length(columns)) stop("Please select at least one lookup column.", call. = FALSE)
    column_indices <- match(columns, names(df))
  } else if (identical(scope, "rows")) {
    from <- suppressWarnings(as.integer(row_from %||% 1L))
    to <- suppressWarnings(as.integer(row_to %||% nrow(df)))
    if (is.na(from) || is.na(to) || from < 1L || to < from || to > nrow(df)) {
      stop(sprintf("The search row range must be between 1-%s.", nrow(df)), call. = FALSE)
    }
    row_indices <- seq.int(from, to)
  }

  match_value <- function(value) {
    if (isTRUE(find_empty)) return(is.na(value) || identical(as.character(value), ""))
    if (is.na(value)) return(FALSE)
    value <- as.character(value)
    if (isTRUE(use_regex)) {
      pattern <- if (isTRUE(whole_cell)) paste0("^(?:", query, ")$") else query
      return(isTRUE(suppressWarnings(grepl(
        pattern, value, ignore.case = !isTRUE(match_case), perl = TRUE
      ))))
    }
    if (!isTRUE(match_case)) {
      value <- tolower(value)
      needle <- tolower(query)
    } else {
      needle <- query
    }
    if (isTRUE(whole_cell)) identical(value, needle) else grepl(needle, value, fixed = TRUE)
  }

  details <- vector("list", length(row_indices) * length(column_indices))
  detail_index <- 0L
  for (row_index in row_indices) {
    for (column_index in column_indices) {
      value <- df[[column_index]][row_index]
      if (match_value(value)) {
        detail_index <- detail_index + 1L
        details[[detail_index]] <- data.frame(
          row_index = row_index,
          row_name = rownames(df)[row_index] %||% as.character(row_index),
          column_index = column_index,
          column_name = names(df)[column_index],
          value = as.character(value),
          stringsAsFactors = FALSE,
          check.names = FALSE
        )
      }
    }
  }
  details <- if (detail_index) {
    dplyr::bind_rows(details[seq_len(detail_index)])
  } else {
    data.frame(row_index = integer(), row_name = character(), column_index = integer(),
               column_name = character(), value = character(), check.names = FALSE)
  }
  searched <- length(row_indices) * length(column_indices)
  list(
    query = if (isTRUE(find_empty)) "<null value>" else query, scope = scope, searched = searched,
    matched = nrow(details), unmatched = searched - nrow(details),
    matched_rows = length(unique(details$row_index)),
    matched_columns = length(unique(details$column_index)),
    details = details
  )
}

mod_file_manager_server <- function(id, shared_rv = NULL) {
  moduleServer(id, function(input, output, session) {

    root_input <- session$rootScope()$input
    interface_language <- reactive({
      root_input$dava_interface_language
      dava_i18n_language(root_input$dava_interface_language)
    })

    rv <- shared_rv %||% file_manager_state()
    data_registry_token <- reactiveVal(0)
    rename_row_modal_token <- reactiveVal(0)
    rename_col_instance <- reactiveVal(0L)
    rename_row_instance <- reactiveVal(0L)
    rename_row_context <- reactiveVal(NULL)
    rename_col_context <- reactiveVal(NULL)
    advanced_modal_context <- reactiveVal(NULL)
    active_table_generation <- reactiveVal(0L)
    last_active_table_identity <- reactiveVal(NULL)
    displayed_table_context <- reactiveVal(NULL)
    table_find_result <- reactiveVal(NULL)
    file_manager_selectors_bound <- reactiveVal(FALSE)
    skip_global_dataset_select <- reactiveVal(NULL)

    observeEvent(input$workspace_import, {
      upload <- input$workspace_file
      if (is.null(upload) || !nzchar(upload$datapath %||% "")) {
        showNotification("Please select the .davaws working environment file first.", type = "warning")
        return()
      }
      extension <- tolower(tools::file_ext(upload$name %||% ""))
      if (!extension %in% c("davaws", "rds")) {
        showNotification("Only .davaws or compatible .rds work environment files are supported.",
          type = "error")
        return()
      }
      rv$workspace_import_error <- ""
      rv$workspace_import_request <- list(
        path = upload$datapath,
        name = upload$name,
        token = as.numeric(Sys.time()))
    })

    output$workspace_import_status <- renderText({
      if (nzchar(rv$workspace_import_error %||% "")) {
        return(paste0("Import failed:", rv$workspace_import_error))
      }
      if (nzchar(rv$workspace_last_loaded %||% "")) {
        return(paste0("Restored saved at:", rv$workspace_last_loaded))
      }
      "The working environment has not been imported yet."
    })

    touch_data_registry <- function() {
      data_registry_token(isolate(data_registry_token()) + 1)
    }
    workspace_restore_locked <- function() {
      isTRUE(isolate(rv$workspace_restore_in_progress %||% FALSE))
    }
    # UI and initialisation observers deliberately use this reactive reader so
    # panels first created during restoration rerun when the lock is released.
    workspace_restore_lock <- reactive({
      isTRUE(rv$workspace_restore_in_progress %||% FALSE)
    })
    observeEvent(rv$data_registry_version, {
      if (workspace_restore_locked()) return()
      touch_data_registry()
    }, ignoreInit = TRUE)
    
    current_df <- reactive({
      if (isTRUE(rv$readOnly)) {
        req(rv$books, rv$active_book, rv$active_sheet)
        req(!is.null((rv$books %||% list())[[rv$active_book]][[rv$active_sheet]]))
        rv$books[[rv$active_book]][[rv$active_sheet]]
      } else {
        req(rv$global_datasets, rv$active_dataset)
        req(!is.null((rv$global_datasets %||% list())[[rv$active_dataset]]))
        rv$global_datasets[[rv$active_dataset]]
      }
    })

    active_table_identity <- reactive({
      if (isTRUE(rv$readOnly)) {
        table <- (rv$books %||% list())[[rv$active_book %||% ""]][[rv$active_sheet %||% ""]]
        list(mode = "book", book = rv$active_book %||% "", sheet = rv$active_sheet %||% "",
             columns = names(table), rows = rownames(table))
      } else {
        table <- (rv$global_datasets %||% list())[[rv$active_dataset %||% ""]]
        list(mode = "dataset", dataset = rv$active_dataset %||% "",
             columns = names(table), rows = rownames(table))
      }
    })

    observeEvent(active_table_identity(), {
      identity <- active_table_identity()
      previous <- isolate(last_active_table_identity())
      if (is.null(previous)) {
        last_active_table_identity(identity)
      } else if (!identical(identity, previous)) {
        last_active_table_identity(identity)
        active_table_generation(isolate(active_table_generation()) + 1L)
        rename_row_context(NULL)
        rename_col_context(NULL)
        advanced_modal_context(NULL)
        displayed_table_context(NULL)
        rename_row_modal_token(isolate(rename_row_modal_token()) + 1L)
        hot_render_token(isolate(hot_render_token()) + 1L)
        table_summary_token(isolate(table_summary_token()) + 1L)
        removeModal()
      }
    }, ignoreInit = FALSE)
    
    
    log_event <- function(action, detail = "") {
      rv$log <- dplyr::bind_rows(
        rv$log,
        tibble::tibble(
          time = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
          book = rv$active_book %||% "",
          sheet = rv$active_sheet %||% "",
          global_datasets= rv$acteive_dataset %||% "",
          action = action,
          detail = detail
        )
      )
    }
    
    update_df <- function(df, action = NULL, detail = NULL, reset_page = FALSE, track = TRUE) {
      datasets <- isolate(rv$global_datasets %||% list())
      dataset_name <- isolate(rv$active_dataset %||% "")
      if (isTRUE(isolate(rv$readOnly)) || !nzchar(dataset_name) || is.null(datasets[[dataset_name]])) {
        stop("The current table is read-only or does not have a valid editable data set.", call. = FALSE)
      }
      
      if (isTRUE(track)) {
        push_undo(action %||% "Data operations", detail %||% "")
      }
      datasets[[dataset_name]] <- normalize_df_keep_rownames(df)
      rv$global_datasets <- datasets
      
      if (isTRUE(reset_page)) {
        updateNumericInput(session, "page", value = 1)
      }
      
      hot_render_token(isolate(hot_render_token()) + 1)
      table_summary_token(isolate(table_summary_token()) + 1)
      
      if (!is.null(action)) {
        log_event(action, detail %||% "")
      }
    }

    ensure_editable_table <- function(action = "Do this") {
      datasets <- isolate(rv$global_datasets %||% list())
      dataset_name <- isolate(rv$active_dataset %||% "")
      if (isTRUE(isolate(rv$readOnly)) || !nzchar(dataset_name) || is.null(datasets[[dataset_name]])) {
        showNotification(
          sprintf("The current table is read-only, please save it as a new data set before %s.", action),
          type = "warning", duration = 6
        )
        return(FALSE)
      }
      TRUE
    }

    # Shiny may interpret unnamed/named character vectors differently when a
    # modal input is recreated. Advanced-operation selectors always use an
    # explicit label -> value mapping so the visible text and submitted value
    # remain the actual field name.
    stable_name_choices <- function(values) {
      values <- enc2utf8(as.character(values %||% character(0)))
      stats::setNames(values, values)
    }

    modal_rename_payload_js <- function(payload_id, target_id, new_name_id) {
      sprintf(
        paste0(
          "var target=document.getElementById(%s);",
          "var newName=document.getElementById(%s);",
          "if(window.Shiny&&target&&newName){",
          "Shiny.setInputValue(%s,{target:target.value,new_name:newName.value,nonce:Math.random()},{priority:'event'});",
          "}"
        ),
        jsonlite::toJSON(session$ns(target_id), auto_unbox = TRUE),
        jsonlite::toJSON(session$ns(new_name_id), auto_unbox = TRUE),
        jsonlite::toJSON(session$ns(payload_id), auto_unbox = TRUE)
      )
    }

    sync_modal_inputs_before_action_js <- paste0(
      "if(this.dataset.davaInputsSynced==='1'){delete this.dataset.davaInputsSynced;return true;}",
      "event.preventDefault();event.stopImmediatePropagation();",
      "var button=this,modal=button.closest('.modal');if(!modal||!window.Shiny){return false;}",
      "var sent={};modal.querySelectorAll('input,select,textarea').forEach(function(el){",
      "if(el===button||el.type==='button'||el.type==='submit'||el.type==='file')return;",
      "var key=(el.type==='radio'?el.name:el.id);if(!key||sent[key])return;",
      "var value;if(el.type==='radio'){var checked=modal.querySelector('input[type=radio][name=\"'+key+'\"]:checked');if(!checked)return;value=checked.value;}",
      "else if(el.type==='checkbox'){value=!!el.checked;}",
      "else if(el.tagName==='SELECT'&&el.multiple){value=Array.from(el.selectedOptions).map(function(o){return o.value;});}",
      "else{value=el.value;}",
      "sent[key]=true;Shiny.setInputValue(key,value,{priority:'event'});",
      "});",
      "button.dataset.davaInputsSynced='1';setTimeout(function(){button.click();},100);return false;"
    )

    commit_single_name_rename <- function(axis, dataset_name, opened_names,
                                          target_value, new_name) {
      datasets <- isolate(rv$global_datasets %||% list())
      active <- isolate(rv$active_dataset %||% "")
      current <- datasets[[dataset_name]]
      current_names <- if (identical(axis, "column")) names(current) else rownames(current)
      if (!identical(active, dataset_name) || is.null(current) ||
          !identical(current_names, opened_names)) {
        showNotification("The currently displayed table has changed. Please close the pop-up window and reopen it.", type = "error", duration = 6)
        return(FALSE)
      }
      target_value <- as.character(target_value %||% "")[1]
      new_name <- trimws(as.character(new_name %||% "")[1])
      clean_name <- function(value) trimws(sub("^\ufeff", "", enc2utf8(as.character(value))))
      target_index <- match(target_value, opened_names)
      if (is.na(target_index)) {
        matches <- which(clean_name(opened_names) == clean_name(target_value))
        if (length(matches) == 1L) target_index <- matches
      }
      if (length(target_index) != 1L || is.na(target_index)) {
        showNotification(sprintf("Please select the valid target %s in the current pop-up window.",
          if (identical(axis, "column")) "column" else "OK"), type = "error")
        return(FALSE)
      }
      if (!nzchar(new_name)) {
        showNotification(sprintf("The new %s name cannot be empty.",
          if (identical(axis, "column")) "column" else "OK"), type = "error")
        return(FALSE)
      }
      old_name <- current_names[target_index]
      current_names[target_index] <- new_name
      current_names <- make_unique_names(current_names)
      if (identical(axis, "column")) names(current) <- current_names else rownames(current) <- current_names
      action <- if (identical(axis, "column")) "Rename column names" else "Rename row names"
      detail_text <- sprintf("%s -> %s", old_name, current_names[target_index])
      push_undo(action, detail_text)
      datasets[[dataset_name]] <- normalize_df_keep_rownames(current)
      rv$global_datasets <- datasets
      hot_render_token(isolate(hot_render_token()) + 1L)
      table_summary_token(isolate(table_summary_token()) + 1L)
      log_event(action, detail_text)
      showNotification(paste0(action, "Done."), type = "message")
      removeModal()
      TRUE
    }

    capture_advanced_modal_context <- function(df = isolate(current_df())) {
      context <- list(
        dataset = isolate(rv$active_dataset %||% ""),
        generation = isolate(active_table_generation()),
        column_names = names(df),
        row_names = rownames(df),
        data = df
      )
      advanced_modal_context(context)
      context
    }

    ensure_displayed_table_current <- function(action) {
      shown <- isolate(displayed_table_context())
      active_dataset <- isolate(rv$active_dataset %||% "")
      if (is.null(shown) && inherits(session, "MockShinySession")) {
        shown <- list(
          mode = "dataset", dataset = active_dataset,
          generation = isolate(active_table_generation())
        )
        displayed_table_context(shown)
      }
      valid <- !is.null(shown) && identical(shown$mode, "dataset") &&
        identical(shown$dataset, active_dataset) &&
        identical(shown$generation, isolate(active_table_generation()))
      if (!valid) {
        hot_render_token(isolate(hot_render_token()) + 1L)
        showNotification(
          sprintf("The table is switching or refreshing, and the %s operation has been blocked; please try again after the current table is displayed.", action),
          type = "warning", duration = 5
        )
      }
      valid
    }

    advanced_modal_df <- function() {
      context <- advanced_modal_context()
      req(context, context$data)
      context$data
    }

    advanced_modal_is_current <- function(action) {
      context <- isolate(advanced_modal_context())
      if (is.null(context)) {
        context <- capture_advanced_modal_context(isolate(current_df()))
      }
      datasets <- isolate(rv$global_datasets %||% list())
      active <- isolate(rv$active_dataset %||% "")
      current <- datasets[[active]]
      valid <- !is.null(context) && identical(active, context$dataset) &&
        identical(isolate(active_table_generation()), context$generation) &&
        !is.null(current) && identical(names(current), context$column_names) &&
        identical(rownames(current), context$row_names)
      if (!valid) {
        showNotification(
          sprintf("%sThe current table structure has changed after the pop-up window was opened. Please reopen the pop-up window.", action),
          type = "error", duration = 6
        )
      }
      valid
    }
    

  #--------------Globaldata setManagement
    
    #Update global editabledata set
    book_source <- function(book) {
      (rv$book_sources %||% list())[[book]] %||% "Universal file import"
    }

    dataset_source <- function(dataset) {
      (rv$dataset_sources %||% list())[[dataset]] %||% "Universal file import"
    }

    grouped_book_choices <- function() {
      books <- names(rv$books %||% list())
      if (!length(books)) return(character(0))
      sources <- vapply(books, book_source, character(1))
      split(stats::setNames(books, books), sources)
    }

    grouped_dataset_choices <- function() {
      datasets <- names(rv$global_datasets %||% list())
      if (!length(datasets)) return(character(0))
      sources <- vapply(datasets, dataset_source, character(1))
      split(stats::setNames(datasets, datasets), sources)
    }

    choices_with_blank <- function(choices, label = "No data set selected") {
      if (!length(choices)) return(stats::setNames("", label))
      c(stats::setNames("", label), choices)
    }

    update_global_dataset_input <- function(choices = grouped_dataset_choices(), selected = NULL) {
      shinyWidgets::updatePickerInput(
        session,
        "select_global_dataset",
        choices = choices_with_blank(choices, "No data set selected"),
        selected = selected %||% ""
      )
    }

    register_global_dataset <- function(name, data, source = "Universal file import", activate = TRUE, sync = TRUE) {
      datasets <- isolate(rv$global_datasets %||% list())
      datasets[[name]] <- normalize_df_keep_rownames(data)
      rv$global_datasets <- datasets

      sources <- isolate(rv$dataset_sources %||% list())
      sources[[name]] <- source
      rv$dataset_sources <- sources

      if (isTRUE(activate)) {
        rv$active_dataset <- name
        rv$active_book <- NULL
        rv$active_sheet <- NULL
        rv$readOnly <- FALSE
      }
      if (isTRUE(sync)) {
        commit_file_library(refresh = FALSE)
      }
      invisible(name)
    }

    register_original_sheet <- function(book, sheet, data, source = "Universal file import",
                                        activate = TRUE, sync = TRUE) {
      sheet <- safe_sheet_name(sheet)
      books <- isolate(rv$books %||% list())
      if (is.null(books[[book]])) books[[book]] <- list()
      books[[book]][[sheet]] <- normalize_df_keep_rownames(data)
      rv$books <- books

      sources <- isolate(rv$book_sources %||% list())
      sources[[book]] <- source
      rv$book_sources <- sources

      if (isTRUE(activate)) {
        rv$active_book <- book
        rv$active_sheet <- sheet
        rv$active_dataset <- NULL
        rv$readOnly <- TRUE
      }
      if (isTRUE(sync)) commit_file_library(refresh = FALSE)
      invisible(sheet)
    }

    is_empty_import_table <- function(df) {
      if (is.null(df) || !is.data.frame(df)) return(TRUE)
      if (nrow(df) == 0 || ncol(df) == 0) return(TRUE)
      vals <- unlist(df, use.names = FALSE)
      if (!length(vals)) return(TRUE)
      vals_chr <- suppressWarnings(trimws(as.character(vals)))
      all(is.na(vals_chr) | vals_chr == "")
    }

    ensure_active_original_sheet <- function(book = NULL, sheet = NULL) {
      books <- isolate(rv$books %||% list())
      if (!length(books)) return(invisible(FALSE))
      if (!is.null(book) && book %in% names(books)) {
        rv$active_book <- book
      } else if (is.null(rv$active_book) || !rv$active_book %in% names(books)) {
        rv$active_book <- names(books)[1]
      }
      active_sheets <- names(books[[rv$active_book]] %||% list())
      if (!length(active_sheets)) return(invisible(FALSE))
      if (!is.null(sheet) && sheet %in% active_sheets) {
        rv$active_sheet <- sheet
      } else if (is.null(rv$active_sheet) || !rv$active_sheet %in% active_sheets) {
        rv$active_sheet <- active_sheets[1]
      }
      invisible(TRUE)
    }

    ensure_active_global_dataset <- function(dataset = NULL) {
      datasets <- isolate(rv$global_datasets %||% list())
      dataset_names <- names(datasets)
      if (!length(dataset_names)) return(invisible(FALSE))
      if (!is.null(dataset) && dataset %in% dataset_names) {
        rv$active_dataset <- dataset
      } else if (is.null(rv$active_dataset) || !rv$active_dataset %in% dataset_names) {
        rv$active_dataset <- dataset_names[1]
      }
      invisible(TRUE)
    }

    capture_active_view <- function() {
      list(
        readOnly = isolate(isTRUE(rv$readOnly)),
        active_book = isolate(rv$active_book %||% NULL),
        active_sheet = isolate(rv$active_sheet %||% NULL),
        active_dataset = isolate(rv$active_dataset %||% NULL)
      )
    }

    active_view_valid <- function(view = capture_active_view()) {
      if (isTRUE(view$readOnly)) {
        books <- isolate(rv$books %||% list())
        return(!is.null(view$active_book) &&
          !is.null(view$active_sheet) &&
          !is.null(books[[view$active_book]][[view$active_sheet]]))
      }
      datasets <- isolate(rv$global_datasets %||% list())
      !is.null(view$active_dataset) && !is.null(datasets[[view$active_dataset]])
    }

    restore_active_view <- function(view) {
      if (!isTRUE(active_view_valid(view))) return(FALSE)
      rv$readOnly <- isTRUE(view$readOnly)
      rv$active_book <- view$active_book
      rv$active_sheet <- view$active_sheet
      rv$active_dataset <- view$active_dataset
      TRUE
    }

    refresh_file_manager_selectors <- function() {
      if (workspace_restore_locked()) return(invisible(FALSE))
      state <- isolate(list(
        books = rv$books %||% list(),
        global_datasets = rv$global_datasets %||% list(),
        book_sources = rv$book_sources %||% list(),
        dataset_sources = rv$dataset_sources %||% list(),
        active_book = rv$active_book %||% "",
        active_sheet = rv$active_sheet %||% "",
        active_dataset = rv$active_dataset %||% "",
        readOnly = isTRUE(rv$readOnly)
      ))
      book_choices <- {
        books <- names(state$books)
        if (!length(books)) character(0) else {
          sources <- vapply(books, function(book) state$book_sources[[book]] %||% "Universal file import", character(1))
          split(stats::setNames(books, books), sources)
        }
      }
      dataset_choices <- {
        datasets <- names(state$global_datasets)
        if (!length(datasets)) character(0) else {
          sources <- vapply(datasets, function(dataset) state$dataset_sources[[dataset]] %||% "Universal file import", character(1))
          split(stats::setNames(datasets, datasets), sources)
        }
      }
      book_selected <- if (isTRUE(state$readOnly)) state$active_book else ""
      updateSelectInput(
        session,
        "book_select",
        choices = choices_with_blank(book_choices, "No workbook selected"),
        selected = book_selected
      )
      if (isTRUE(state$readOnly) && nzchar(state$active_book) && !is.null(state$books[[state$active_book]])) {
        sheet_names <- names(state$books[[state$active_book]])
        updateSelectInput(
          session,
          "sheet_select",
          choices = choices_with_blank(stats::setNames(sheet_names, sheet_names), "No worksheet selected"),
          selected = state$active_sheet
        )
      } else {
        updateSelectInput(
          session,
          "sheet_select",
          choices = stats::setNames("", "No worksheet selected"),
          selected = ""
        )
      }
      dataset_selected <- if (!isTRUE(state$readOnly)) state$active_dataset else ""
      update_global_dataset_input(dataset_choices, dataset_selected)
    }

    activate_available_original_book <- function(prefer_micro = FALSE) {
      books <- isolate(rv$books %||% list())
      if (!length(books)) return(invisible(FALSE))

      book_names <- names(books)
      selected_book <- NULL
      if (is.null(selected_book) && !is.null(rv$active_book) && rv$active_book %in% book_names) {
        selected_book <- rv$active_book
      }
      if (is.null(selected_book) && isTRUE(prefer_micro)) {
        micro_books <- intersect(c("Microbiological standard documents", "Microbial sample data", "Microbiology other tools export files"), book_names)
        selected_book <- micro_books[1] %||% NULL
      }
      if (is.null(selected_book)) selected_book <- book_names[1]

      sheets <- names(books[[selected_book]] %||% list())
      if (!length(sheets)) return(invisible(FALSE))

      rv$active_book <- selected_book
      if (is.null(rv$active_sheet) || !rv$active_sheet %in% sheets) {
        rv$active_sheet <- sheets[1]
      }
      rv$readOnly <- TRUE
      rv$active_dataset <- NULL
      invisible(TRUE)
    }

    commit_file_library <- function(prefer_micro = FALSE, refresh = TRUE) {
      if (workspace_restore_locked()) return(invisible(NULL))
      if (isTRUE(prefer_micro)) {
        activate_available_original_book(prefer_micro = TRUE)
      }
      library_state <- list(
        books = isolate(rv$books %||% list()),
        global_datasets = isolate(rv$global_datasets %||% list()),
        book_sources = isolate(rv$book_sources %||% list()),
        dataset_sources = isolate(rv$dataset_sources %||% list()),
        active_book = isolate(rv$active_book %||% NULL),
        active_sheet = isolate(rv$active_sheet %||% NULL),
        active_dataset = isolate(rv$active_dataset %||% NULL),
        readOnly = isolate(rv$readOnly %||% TRUE)
      )
      rv$file_library <- library_state
      touch_data_registry()
      if (isTRUE(refresh)) refresh_file_manager_selectors()
      invisible(library_state)
    }

    mark_micro_import_synced <- function() {
      if (workspace_restore_locked()) return(invisible(FALSE))
      commit_file_library(refresh = TRUE)
      hot_render_token(isolate(hot_render_token()) + 1)
      preview_render_token(isolate(preview_render_token()) + 1)
      table_summary_token(isolate(table_summary_token()) + 1)
    }

    observe({
      if (workspace_restore_lock()) return()
      if (isTRUE(file_manager_selectors_bound())) return()
      if (is.null(input$book_select) && is.null(input$select_global_dataset)) return()
      file_manager_selectors_bound(TRUE)
      ensure_micro_import_registered()
      if (length(isolate(rv$books %||% list())) || length(isolate(rv$global_datasets %||% list()))) {
        commit_file_library(refresh = TRUE)
      }
    })

    observe({
      data_registry_token()
      if (workspace_restore_lock()) return()
      session$onFlushed(refresh_file_manager_selectors, once = TRUE)
    })

    output$global_dataset_ui <- renderUI({
      if (!workspace_restore_lock()) ensure_micro_import_registered()
      data_registry_token()
      choices <- grouped_dataset_choices()
      if (!length(names(rv$global_datasets %||% list()))) {
        return(tags$div(
          class = "small-muted",
          "The editable data set has not been created; it will appear automatically after importing a file or loading microbial data."
        ))
      }
      shinyWidgets::pickerInput(
        session$ns("select_global_dataset"),
        "Select data set",
        choices = choices_with_blank(choices, "No data set selected"),
        selected = rv$active_dataset %||% "",
        width = "100%",
        options = list(
          `live-search` = TRUE,
          size = 8,
          `none-selected-text` = "No data set selected"
        )
      )
    })
    
    observeEvent(input$select_global_dataset, {
      if (workspace_restore_locked()) return()
      selected <- input$select_global_dataset %||% ""
      skip_selected <- isolate(skip_global_dataset_select())
      if (!is.null(skip_selected) && identical(selected, skip_selected)) {
        skip_global_dataset_select(NULL)
        return()
      }
      previous_dataset <- isolate(rv$active_dataset %||% "")
      if (!nzchar(selected)) {
        if (!isTRUE(rv$readOnly)) {
          rv$active_dataset <- NULL
        }
      } else if (selected %in% names(rv$global_datasets %||% list())) {
        rv$readOnly <- FALSE
        rv$active_dataset <- selected
        rv$active_book <- NULL
        rv$active_sheet <- NULL
      }
      if (!identical(selected, previous_dataset)) {
        clear_edit_history()
      }
    }, ignoreInit = TRUE)
    
    
    #Delete data set
    observeEvent(input$delete_global_dataset, {
      req(input$select_global_dataset)
      
      dataset_name <- input$select_global_dataset
      
      if (is.null(rv$global_datasets[[dataset_name]])) {
        showNotification("The selected data set does not exist or has been deleted.", type = "error")
        return()
      }
      
      showModal(
        modalDialog(
          title = "Confirm deletion of data set",
          tags$p(sprintf("Are you sure you want to delete the edited data set: %s?", dataset_name)),
          tags$p(class = "small-muted", "This operation only deletes the edited data set and does not delete the original imported data."),
          footer = tagList(
            modalButton("Cancel"),
            actionButton(session$ns("delete_global_dataset_confirm"), "Confirm deletion", class = "btn-danger")
          ),
          easyClose = TRUE
        )
      )
      # Key：will pop up content areaSettingsis draggable
      jqui_draggable(".modal-content")
    })
    
    observeEvent(input$delete_global_dataset_confirm, {
      req(input$select_global_dataset)
      removeModal()
      
      dataset_name <- input$select_global_dataset
      
      if (is.null(rv$global_datasets[[dataset_name]])) {
        showNotification("The selected data set does not exist or has been deleted.", type = "error")
        return()
      }
      
      datasets <- isolate(rv$global_datasets %||% list())
      datasets[[dataset_name]] <- NULL
      rv$global_datasets <- datasets

      sources <- isolate(rv$dataset_sources %||% list())
      sources[[dataset_name]] <- NULL
      rv$dataset_sources <- sources
      clear_edit_history()
      log_event("Delete global edit data set", dataset_name)
      
      showNotification("The selected edit data set has been deleted.", type = "warning")
    })
    
    #Save edits toCurrent data set
    # observeEvent(input$save_edit, {
    #   req(input$select_global_dataset,rv$global_datasets, rv$active_dataset)
    #   rv$readOnly = FALSE
    #   dataset_name <- input$select_global_dataset
    #   rv$active_dataset <- dataset_name
    #   rv$global_datasets[[rv$active_dataset]] <- normalize_df(current_df())
    #   log_event("Save changes to current editcopy", sprintf("%s", rv$active_dataset))
    #   showNotification("Modifications saved to current editcopy。", type = "message")
    # })
    
    #Save as new dataset
    observeEvent(input$save_as_new_open, {
      showModal(modalDialog(
        title = "Save as new dataset",
        textInput(session$ns("new_dataset_name"), "New dataset name", value = paste0((if(rv$readOnly) rv$active_sheet else rv$active_dataset) %||% "dataset", "_copy")),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("save_as_new_confirm"), "Confirm save", class = "btn-success")),
        easyClose = TRUE
      ))
    })
    
    observeEvent(input$save_as_new_confirm, {
      req(input$new_dataset_name)
      removeModal()
      new_dataset <- trimws(input$new_dataset_name)
      if (new_dataset == "") new_dataset <- "new_dataset"
      new_dataset <- make_unique_names(c(names(rv$global_datasets), new_dataset))[length(rv$global_datasets) + 1]
      new_dataset <- safe_sheet_name(new_dataset)
      
      df_copy <- isolate({
        if (!isTRUE(rv$readOnly) && !is.null(rv$active_dataset)) {
          rv$global_datasets[[rv$active_dataset]]
        } else {
          req(rv$active_book, rv$active_sheet)
          rv$books[[rv$active_book]][[rv$active_sheet]]
        }
      })       
      # Preserve the complete editor table. Converting through tibble here
      # drops row names, so renamed rows were lost when saving a copy.
      register_global_dataset(
        new_dataset,
        data.frame(df_copy, check.names = FALSE, stringsAsFactors = FALSE),
        source = if (isTRUE(rv$readOnly)) book_source(rv$active_book %||% "") else dataset_source(rv$active_dataset %||% ""),
        activate = TRUE
      )
      rv$readOnly <- FALSE
      clear_edit_history()
      
      update_global_dataset_input(selected = new_dataset)
      
      
      log_event("Save as new dataset", sprintf("Save as %s", new_dataset))
      showNotification("The current modified data has been saved as a new data set.", type = "message")
      
    })

    make_blank_table <- function(n_rows, n_cols) {
      n_rows <- suppressWarnings(as.integer(n_rows %||% 10))
      n_cols <- suppressWarnings(as.integer(n_cols %||% 5))
      if (is.na(n_rows) || n_rows < 1) n_rows <- 10
      if (is.na(n_cols) || n_cols < 1) n_cols <- 5
      n_rows <- min(n_rows, 100000)
      n_cols <- min(n_cols, 1000)
      out <- as.data.frame(
        matrix(NA_character_, nrow = n_rows, ncol = n_cols),
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
      names(out) <- paste0("Column", seq_len(n_cols))
      normalize_df_keep_rownames(out)
    }

    observeEvent(input$create_blank_open, {
      showModal(modalDialog(
        title = "Create a new blank form",
        textInput(session$ns("blank_dataset_name"), "Data set name", value = "blank_table"),
        numericInput(session$ns("blank_rows"), "Rows", value = 30, min = 1, max = 100000, step = 1),
        numericInput(session$ns("blank_cols"), "Columns", value = 15, min = 1, max = 1000, step = 1),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("create_blank_confirm"), "Confirm new creation", class = "btn-primary")),
        easyClose = TRUE
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    })

    observeEvent(input$create_blank_confirm, {
      removeModal()
      blank_name <- trimws(input$blank_dataset_name %||% "")
      if (blank_name == "") blank_name <- "blank_table"
      blank_name <- make_unique_names(c(names(rv$global_datasets %||% list()), safe_sheet_name(blank_name)))[length(rv$global_datasets %||% list()) + 1]
      df_blank <- make_blank_table(input$blank_rows, input$blank_cols)
      register_global_dataset(blank_name, df_blank, source = "Blank form", activate = TRUE)
      clear_edit_history()
      update_global_dataset_input(selected = blank_name)
      updateSelectInput(session, "book_select", selected = "")
      updateSelectInput(session, "sheet_select", selected = "")
      updateNumericInput(session, "hot_page", value = 1)
      updateNumericInput(session, "hot_preview_page", value = 1)
      hot_render_token(isolate(hot_render_token()) + 1)
      preview_render_token(isolate(preview_render_token()) + 1)
      log_event("Create a new blank form", sprintf("%s: %s rows x %s columns", blank_name, nrow(df_blank), ncol(df_blank)))
      showNotification(sprintf("New blank form: %s", blank_name), type = "message")
    })
    
   #------------ 
    
    # ------------------------------
    # Import files
    # ------------------------------
    
    observeEvent(input$files, {
      req(input$files)
      first_book <- NULL
      first_sheet <- NULL
      first_dataset <- NULL
      skipped_empty <- character(0)
      failed_files <- character(0)
      
      for (i in seq_len(nrow(input$files))) {
        nm <- input$files$name[i]
        path <- input$files$datapath[i]
        ext <- tolower(tools::file_ext(nm))
        existing_books <- names(isolate(rv$books %||% list()))
        book_name <- make_unique_names(c(existing_books, safe_file_stem(nm)))[length(existing_books) + 1]
        
        if (ext %in% c("xlsx", "xls")) {
          sheets <- tryCatch(
            dava_excel_sheets(path, nm),
            error = function(error) {
              failed_files <<- c(failed_files, sprintf("%s: %s", nm, conditionMessage(error)))
              character()
            }
          )
          if (!length(sheets)) next

          for (s in sheets) {
            dat <- tryCatch(
              suppressWarnings(dava_read_excel_sheet(path, nm, sheet = s)),
              error = function(e) {
                failed_files <<- c(failed_files, sprintf("%s/%s: %s", nm, s, e$message))
                NULL
              }
            )
            if (is_empty_import_table(dat)) {
              skipped_empty <- c(skipped_empty, sprintf("%s/%s", nm, s))
              next
            }
            dat <- normalize_df(dat)

            sheet_name <- safe_sheet_name(s)
            dataset_base <- safe_sheet_name(if (length(sheets) == 1) book_name else paste(book_name, sheet_name, sep = "_"))
            existing_datasets <- names(isolate(rv$global_datasets %||% list()))
            dataset_name <- make_unique_names(c(existing_datasets, dataset_base))[length(existing_datasets) + 1]
            activate_this <- is.null(first_book)
            register_original_sheet(book_name, sheet_name, dat, source = "Universal file import", activate = activate_this)
            register_global_dataset(dataset_name, dat, source = "Universal file import", activate = activate_this)
            if (is.null(first_book)) {
              first_book <- book_name
              first_sheet <- sheet_name
              first_dataset <- dataset_name
            }
          }
          
        } else if (ext %in% c("csv", "tsv", "txt")) {
          dat <- tryCatch(
            suppressWarnings(guess_and_read_delim(path, ifelse(ext == "csv", "csv", "tsv"))),
            error = function(e) {
              failed_files <<- c(failed_files, sprintf("%s: %s", nm, e$message))
              NULL
            }
          )
          if (is_empty_import_table(dat)) {
            skipped_empty <- c(skipped_empty, nm)
            next
          }
          dat <- normalize_df(dat)

          sheet_name <- "Sheet1"
          dataset_base <- safe_sheet_name(book_name)
          existing_datasets <- names(isolate(rv$global_datasets %||% list()))
          dataset_name <- make_unique_names(c(existing_datasets, dataset_base))[length(existing_datasets) + 1]
          activate_this <- is.null(first_book)
          register_original_sheet(book_name, sheet_name, dat, source = "Universal file import", activate = activate_this)
          register_global_dataset(dataset_name, dat, source = "Universal file import", activate = activate_this)
          if (is.null(first_book)) {
            first_book <- book_name
            first_sheet <- sheet_name
            first_dataset <- dataset_name
          }
          
        } else {
          next
        }
      }

      if (!is.null(first_book)) {
        ensure_active_original_sheet(first_book, first_sheet)
        ensure_active_global_dataset(first_dataset)
        rv$readOnly = TRUE
        commit_file_library(refresh = TRUE)
        showNotification("file import completed.", type = "message")
      } else {
        showNotification("No valid data was imported; empty tables or files that failed to read were skipped.", type = "warning", duration = 8)
      }
      
      log_event("Import file", paste(input$files$name, collapse = "; "))
      if (length(skipped_empty)) {
        showNotification(sprintf("%s empty tables skipped.", length(skipped_empty)), type = "warning", duration = 8)
      }
      if (length(failed_files)) {
        showNotification(sprintf("%s files or worksheets failed to read and were skipped.", length(failed_files)), type = "error", duration = 8)
      }
    })

    # ------------------------------
    # Microbiome import and preview
    # ------------------------------

    micro_dataset_names <- list(
      abundance = "micro_otu_asv_table",
      taxonomy = "micro_taxonomy_table",
      group = "micro_group_table",
      env = "micro_env_table",
      metadata = "micro_metadata",
      sequences = "micro_representative_sequences",
      tree_table = "micro_phylogenetic_tree_tips"
    )

    micro_sheet_labels <- list(
      abundance = "OTU_ASV abundance table",
      taxonomy = "Classification annotation table",
      group = "Group information table",
      env = "Environment variable table",
      metadata = "sample metadata",
      sequences = "represents the sequence",
      tree_table = "Phylogenetic tree"
    )

    micro_empty_diagnostics <- function() {
      data.frame(
        time = character(), level = character(), file = character(),
        data_type = character(), stage = character(), message = character(),
        suggestion = character(), stringsAsFactors = FALSE,
        check.names = FALSE
      )
    }
    micro_import_diagnostics <- reactiveVal(micro_empty_diagnostics())

    micro_add_diagnostic <- function(level = c("info", "warning", "error"),
        file = "", data_type = "", stage = "", message = "",
        suggestion = "") {
      level <- match.arg(level)
      row <- data.frame(
        time = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
        level = level, file = as.character(file %||% ""),
        data_type = as.character(data_type %||% ""),
        stage = as.character(stage %||% ""),
        message = as.character(message %||% ""),
        suggestion = as.character(suggestion %||% ""),
        stringsAsFactors = FALSE, check.names = FALSE
      )
      current <- isolate(micro_import_diagnostics())
      micro_import_diagnostics(utils::tail(rbind(current, row), 500L))
      invisible(row)
    }

    micro_validate_import <- function(kind, value, source = "") {
      kind_label <- switch(kind,
        abundance = "OTU/ASV abundance table", taxonomy = "Classification annotation table",
        metadata = "sample metadata", sequences = "represents the sequence",
        tree = "Phylogenetic tree", kind)
      add <- function(level, stage, message, suggestion = "") {
        micro_add_diagnostic(level, source, kind_label, stage, message, suggestion)
      }
      table_value <- if (identical(kind, "tree")) value$table else value
      if (!is.data.frame(table_value) || !NROW(table_value) || !NCOL(table_value)) {
        add("error", "Content inspection", "The import result is an empty table.",
          "Check whether the file contains headers and valid data.")
        return(invisible(FALSE))
      }

      add("info", "File reading", sprintf("%s rows x %s columns read.",
        format(NROW(table_value), big.mark = ","),
        format(NCOL(table_value), big.mark = ",")))
      items <- isolate(rv$microbiome_import %||% list())

      if (identical(kind, "abundance")) {
        if (!"Feature" %in% names(table_value) || NCOL(table_value) < 2L) {
          add("error", "Structure check",
            "The abundance table requires a Feature ID column and at least one sample column.",
            "Confirm that the first column is the OTU/ASV ID and the remaining columns are samples.")
          return(invisible(FALSE))
        }
        feature_ids <- trimws(as.character(table_value$Feature))
        if (any(!nzchar(feature_ids))) add("error", "ID check",
          sprintf("Found %d empty Feature IDs.", sum(!nzchar(feature_ids))),
          "Provide a non-empty and unique ID for each OTU/ASV.")
        abundance <- table_value[, setdiff(names(table_value), "Feature"), drop = FALSE]
        numeric_matrix <- suppressWarnings(as.matrix(data.frame(
          lapply(abundance, as.numeric), check.names = FALSE)))
        non_finite <- sum(!is.finite(numeric_matrix))
        negative <- sum(is.finite(numeric_matrix) & numeric_matrix < 0)
        if (non_finite) add("error", "Value check",
          sprintf("Found %d non-numeric/NA/Inf.", non_finite),
          "Abundance cells can only contain non-negative finite values.")
        if (negative) add("error", "Value check",
          sprintf("Found %d negative values.", negative),
          "The raw abundance table should not contain negative values.")
        safe_matrix <- numeric_matrix
        safe_matrix[!is.finite(safe_matrix)] <- 0
        zero_features <- sum(rowSums(safe_matrix) == 0)
        zero_samples <- sum(colSums(safe_matrix) == 0)
        if (zero_features) add("warning", "Sparsity check",
          sprintf("Found %d all-zero OTUs/ASVs.", zero_features),
          "It is recommended to remove all-zero features before analysis.")
        if (zero_samples) add("error", "Sample Check",
          sprintf("Found %d samples with a total abundance of 0.", zero_samples),
          "Remove empty samples or recheck data direction.")
      }

      reference_features <- as.character(items$abundance$Feature %||% character())
      reference_samples <- setdiff(names(items$abundance %||% data.frame()), "Feature")
      if (identical(kind, "taxonomy")) {
        ids <- as.character(table_value$Feature %||% character())
        ranks <- intersect(c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species"), names(table_value))
        if (!length(ranks)) add("warning", "Classification hierarchy check",
          "The standard classification hierarchy column was not recognized.",
          "Use the Kingdom/Phylum/Class/Order/Family/Genus/Species column name.")
        missing_ids <- setdiff(reference_features, ids)
        if (length(reference_features) && length(missing_ids)) add("warning", "ID match",
          sprintf("%d/%d abundance features are missing taxonomic annotations.",
            length(missing_ids), length(reference_features)),
          "Ensure that the classification table Feature ID is exactly the same as the abundance table.")
      }
      if (identical(kind, "metadata")) {
        ids <- as.character(table_value$SampleID %||% character())
        missing_ids <- setdiff(reference_samples, ids)
        if (!"SampleID" %in% names(table_value)) add("error", "Structure check",
          "SampleID column not recognized.", "Name the Sample ID column SampleID.")
        if (length(reference_samples) && length(missing_ids)) add("warning", "ID match",
          sprintf("%d/%d abundance table samples are missing metadata.",
            length(missing_ids), length(reference_samples)),
          "Make sure the metadata SampleID is consistent with the abundance table sample column name.")
      }
      if (identical(kind, "sequences")) {
        ids <- as.character(table_value$Feature %||% character())
        sequences <- toupper(as.character(table_value$Sequence %||% character()))
        invalid <- !nzchar(sequences) | !grepl("^[ACGTURYSWKMBDHVN-]+$", sequences)
        if (any(invalid)) add("error", "Sequence check",
          sprintf("found %d empty or non-IUPAC nucleic acid sequences.", sum(invalid)),
          "Check FASTA sequence content and encoding.")
        missing_ids <- setdiff(reference_features, ids)
        if (length(reference_features) && length(missing_ids)) add("warning", "ID match",
          sprintf("%d/%d abundance features are missing representative sequences.",
            length(missing_ids), length(reference_features)),
          "Ensure that the FASTA header matches the abundance table Feature ID.")
      }
      if (identical(kind, "tree")) {
        tips <- as.character(table_value$Tip %||% character())
        missing_ids <- setdiff(reference_features, tips)
        if (length(reference_features) && length(missing_ids)) add("warning", "ID match",
          sprintf("%d/%d abundant features are not in the phylogenetic tree.",
            length(missing_ids), length(reference_features)),
          "Prune the tree and ensure the tip label matches the Feature ID.")
        if (!is.null(value$object) && requireNamespace("ape", quietly = TRUE) &&
            !ape::is.rooted(value$object)) add("warning", "Tree structure check",
          "The phylogenetic tree is currently unrooted.",
          "Faith's PD, iCAMP, etc. methods require a rooted tree.")
      }
      invisible(TRUE)
    }

    micro_blank_table <- function(message = "This type of file has not been imported yet.") {
      data.frame(message = message, stringsAsFactors = FALSE, check.names = FALSE)
    }

    sync_micro_import_to_file_manager <- function(activate = FALSE,
                                                  overwrite_existing = FALSE) {
      # microbiome_import is the immutable import cache; global_datasets/books
      # are the editable workspace state. Automatic reconciliation may fill
      # missing registrations, but must never roll edited workspace data back.
      items <- isolate(rv$microbiome_import %||% list())
      current_datasets <- names(isolate(rv$global_datasets %||% list()))
      current_books <- isolate(rv$books %||% list())
      standard <- list(
        abundance = items$abundance,
        taxonomy = items$taxonomy,
        group = items$group,
        env = items$env,
        metadata = items$metadata,
        sequences = items$sequences,
        tree_table = dava_micro_tree_analysis_table(items$tree)
      )
      for (key in names(standard)) {
        value <- standard[[key]]
        ds_name <- micro_dataset_names[[key]]
        if (is.data.frame(value) && !is.null(ds_name)) {
          invalid_tree_registration <- identical(key, "tree_table") &&
            ds_name %in% current_datasets &&
            !"Newick" %in% names(
              isolate(rv$global_datasets[[ds_name]]) %||% data.frame())
          if (isTRUE(overwrite_existing) ||
              !ds_name %in% current_datasets ||
              invalid_tree_registration) {
            register_global_dataset(ds_name, value, source = "Microbial data import",
              activate = isTRUE(activate), sync = FALSE)
            current_datasets <- union(current_datasets, ds_name)
          }
          sheet_name <- safe_sheet_name(micro_sheet_labels[[key]] %||% key)
          book_sheets <- names(current_books[["Microbiological standard documents"]] %||% list())
          if (isTRUE(overwrite_existing) || !sheet_name %in% book_sheets) {
            register_original_sheet(
              "Microbiological standard documents", sheet_name, value,
              source = "Microbial data import", activate = isTRUE(activate),
              sync = FALSE
            )
            current_books <- isolate(rv$books %||% list())
          }
          activate <- FALSE
        }
      }
      other <- items$other %||% list()
      for (nm in names(other)) {
        value <- other[[nm]]
        if (is.data.frame(value)) {
          ds_name <- safe_sheet_name(paste0("micro_other_", safe_file_stem(nm)))
          if (isTRUE(overwrite_existing) || !ds_name %in% current_datasets) {
            register_global_dataset(ds_name, value, source = "Microbial data import",
              activate = FALSE, sync = FALSE)
            current_datasets <- union(current_datasets, ds_name)
          }
          sheet_name <- safe_sheet_name(safe_file_stem(nm))
          book_sheets <- names(current_books[["Microbiology other tools export files"]] %||% list())
          if (isTRUE(overwrite_existing) || !sheet_name %in% book_sheets) {
            register_original_sheet("Microbiology other tools export files", sheet_name,
              value, source = "Microbial data import", activate = FALSE,
              sync = FALSE)
            current_books <- isolate(rv$books %||% list())
          }
        }
      }
      invisible(TRUE)
    }

    ensure_micro_import_registered <- function() {
      items <- isolate(rv$microbiome_import %||% list())
      if (!length(items)) return(invisible(FALSE))

      standard <- list(
        abundance = items$abundance,
        taxonomy = items$taxonomy,
        group = items$group,
        env = items$env,
        metadata = items$metadata,
        sequences = items$sequences,
        tree_table = dava_micro_tree_analysis_table(items$tree)
      )
      has_standard <- vapply(standard, is.data.frame, logical(1))
      expected_datasets <- unname(unlist(micro_dataset_names[names(standard)[has_standard]], use.names = FALSE))
      expected_sheets <- vapply(names(standard)[has_standard], function(key) {
        safe_sheet_name(micro_sheet_labels[[key]] %||% key)
      }, character(1))
      current_datasets <- names(isolate(rv$global_datasets %||% list()))
      current_books <- isolate(rv$books %||% list())

      needs_sync <- any(!expected_datasets %in% current_datasets)
      tree_dataset_name <- micro_dataset_names$tree_table
      if (is.data.frame(standard$tree_table) &&
          tree_dataset_name %in% current_datasets) {
        needs_sync <- needs_sync || !"Newick" %in% names(
          isolate(rv$global_datasets[[tree_dataset_name]]) %||%
            data.frame())
      }
      if (any(has_standard)) {
        current_sheets <- names(current_books[["Microbiological standard documents"]] %||% list())
        needs_sync <- needs_sync || any(!expected_sheets %in% current_sheets)
      }

      other <- items$other %||% list()
      if (length(other)) {
        expected_other <- vapply(names(other), function(nm) safe_sheet_name(paste0("micro_other_", safe_file_stem(nm))), character(1))
        expected_other_sheets <- vapply(names(other), function(nm) {
          safe_sheet_name(safe_file_stem(nm))
        }, character(1))
        needs_sync <- needs_sync || any(!expected_other %in% current_datasets)
        if (any(vapply(other, is.data.frame, logical(1)))) {
          current_other_sheets <- names(
            current_books[["Microbiology other tools export files"]] %||% list())
          needs_sync <- needs_sync ||
            any(!expected_other_sheets %in% current_other_sheets)
        }
      }

      if (isTRUE(needs_sync)) {
        sync_micro_import_to_file_manager(activate = FALSE)
      }
      invisible(isTRUE(needs_sync))
    }

    micro_store_item <- function(key, value, source = "") {
      previous_view <- capture_active_view()
      had_active_view <- active_view_valid(previous_view)
      items <- isolate(rv$microbiome_import %||% list())
      items[[key]] <- value
      rv$microbiome_import <- items

      ds_key <- if (identical(key, "tree")) "tree_table" else key
      ds_name <- micro_dataset_names[[ds_key]]
      table_value <- if (identical(key, "tree")) {
        dava_micro_tree_analysis_table(value)
      } else {
        value
      }
      if (!is.null(ds_name) && is.data.frame(table_value)) {
        register_global_dataset(ds_name, table_value, source = "Microbial data import",
          activate = TRUE, sync = FALSE)
        register_original_sheet(
          "Microbiological standard documents",
          micro_sheet_labels[[ds_key]] %||% ds_key,
          table_value,
          source = "Microbial data import",
          activate = TRUE, sync = FALSE
        )
      }

      if (isTRUE(had_active_view)) {
        restore_active_view(previous_view)
      } else {
        rv$readOnly <- FALSE
        rv$active_dataset <- ds_name
        rv$active_book <- NULL
        rv$active_sheet <- NULL
      }
      log_event("Automatic import of microbial data", source)
      mark_micro_import_synced()
    }

    micro_read_uploaded <- function(input_file, kind) {
      if (is.null(input_file) || !nrow(input_file)) return(NULL)
      path <- input_file$datapath[1]
      nm <- input_file$name[1]
      switch(
        kind,
        abundance = dava_micro_standardize_abundance(dava_micro_read_table_file(path, nm)),
        taxonomy = dava_micro_tax_from_semicolon(dava_micro_read_table_file(path, nm)),
        metadata = dava_micro_standardize_metadata(dava_micro_read_table_file(path, nm)),
        sequences = normalize_df(dava_micro_read_fasta(path, nm)),
        tree = dava_micro_read_tree(path, nm)
      )
    }

    micro_auto_import <- function(input_file, kind, label) {
      if (is.null(input_file) || !nrow(input_file)) return()
      tryCatch({
        value <- micro_read_uploaded(input_file, kind)
        if (!is.null(value)) {
          micro_store_item(kind, value, input_file$name[1])
          micro_validate_import(kind, value, input_file$name[1])
          showNotification(sprintf("%s has been automatically imported.", label), type = "message")
        }
      }, error = function(e) {
        micro_add_diagnostic(
          "error", input_file$name[1], label, "Read/Parse",
          conditionMessage(e),
          "Check the file format, encoding, extension and required R packages and re-upload."
        )
        showNotification(sprintf("%s Automatic import failed: %s", label, e$message), type = "error", duration = 8)
      })
    }

    micro_preview_table <- function(key) {
      items <- rv$microbiome_import %||% list()
      if (identical(key, "tree")) {
        if (!is.null(items$tree) && is.data.frame(items$tree$table)) return(items$tree$table)
        return(micro_blank_table("The phylogenetic tree has not been imported yet."))
      }
      items[[key]] %||% micro_blank_table()
    }

    micro_preview_options <- function(scroll_y = "620px") {
      list(
        scrollX = TRUE,
        scrollY = scroll_y,
        pageLength = 20,
        infoCallback = JS(
          "function(settings, start, end, max, total, pre) {",
          "  var cols = settings.aoColumns ? settings.aoColumns.length : 0;",
          "  var base = 'Showing ' + start + ' to ' + end + ' of ' + total + ' entries';",
          "  if (total !== max) base += ' (filtered from ' + max + ' total entries)';",
          "  return base + ' | Columns: ' + cols;",
          "}"
        )
      )
    }

    micro_render_preview <- function(key) {
      renderDT({
        datatable(
          micro_preview_table(key),
          rownames = FALSE,
          filter = "top",
          options = micro_preview_options("620px")
        )
      }, server = TRUE)
    }

    output$micro_package_status <- renderUI({
      tab <- dava_micro_package_table()
      tags$div(
        class = "small-muted",
        sprintf("Enhanced parsing package: %s/%s is installed. JSON BIOM requires biomformat, HDF5 BIOM requires rhdf5, FASTA recommends Biostrings, and Newick recommends ape.", sum(tab$installed), nrow(tab))
      )
    })

    output$micro_diagnostic_summary <- renderUI({
      diagnostics <- micro_import_diagnostics()
      counts <- table(factor(
        diagnostics$level, levels = c("error", "warning", "info")))
      tags$div(
        class = "d-flex flex-wrap gap-2 align-items-center",
        tags$strong("Import diagnostics"),
        tags$span(class = "badge text-bg-danger",
          paste0("Error ", counts[["error"]])),
        tags$span(class = "badge text-bg-warning",
          paste0("Warning ", counts[["warning"]])),
        tags$span(class = "badge text-bg-secondary",
          paste0("Message ", counts[["info"]]))
      )
    })

    output$micro_diagnostics <- renderDT({
      diagnostics <- micro_import_diagnostics()
      if (!NROW(diagnostics)) {
        diagnostics <- data.frame(
          time = "", level = "info", file = "", data_type = "",
          stage = "Waiting for import",
          message = "No errors or diagnostics have been logged yet.",
          suggestion = "Microbiological data files will be checked automatically after selection.",
          stringsAsFactors = FALSE
        )
      }
      display <- data.frame(
        "time" = diagnostics$time,
        "Level" = c(error = "Error", warning = "Warning", info = "Message")[diagnostics$level],
        "file" = diagnostics$file,
        "data type" = diagnostics$data_type,
        "Inspection phase" = diagnostics$stage,
        "Details" = diagnostics$message,
        "Handling suggestions" = diagnostics$suggestion,
        stringsAsFactors = FALSE, check.names = FALSE
      )
      datatable(
        display, rownames = FALSE, filter = "top",
        options = list(
          scrollX = TRUE, pageLength = 15, order = list(list(0, "desc")),
          columnDefs = list(list(className = "dt-left", targets = "_all"))
        )
      )
    }, server = TRUE)

    observeEvent(input$micro_clear_diagnostics, {
      micro_import_diagnostics(micro_empty_diagnostics())
      showNotification("Cleared microbial data import diagnostics.", type = "message")
    }, ignoreInit = TRUE)

    output$micro_abundance_preview <- micro_render_preview("abundance")
    output$micro_taxonomy_preview <- micro_render_preview("taxonomy")
    output$micro_sequences_preview <- micro_render_preview("sequences")
    output$micro_tree_preview <- micro_render_preview("tree")
    output$micro_metadata_preview <- micro_render_preview("metadata")

    observe({
      items <- rv$microbiome_import %||% list()
      if (!length(items)) return()
      if (isTRUE(ensure_micro_import_registered())) {
        commit_file_library(refresh = TRUE)
        hot_render_token(isolate(hot_render_token()) + 1)
        preview_render_token(isolate(preview_render_token()) + 1)
      }
    })

    output$micro_other_preview_select <- renderUI({
      items <- rv$microbiome_import$other %||% list()
      if (!length(items)) return(tags$div(class = "small-muted mb-2", "No other tool export files have been imported yet."))
      selectInput(session$ns("micro_other_selected"), "Select preview file", choices = names(items), selected = names(items)[1], width = "320px")
    })

    output$micro_other_preview <- renderDT({
      items <- rv$microbiome_import$other %||% list()
      selected <- input$micro_other_selected %||% names(items)[1] %||% ""
      df <- items[[selected]] %||% micro_blank_table("No other tool export files have been imported yet.")
      datatable(df, rownames = FALSE, filter = "top", options = micro_preview_options("580px"))
    }, server = TRUE)

    observeEvent(input$micro_otu_file, {
      micro_auto_import(input$micro_otu_file, "abundance", "OTU/ASV abundance table")
    }, ignoreInit = TRUE)

    observeEvent(input$micro_tax_file, {
      micro_auto_import(input$micro_tax_file, "taxonomy", "Classification annotation table")
    }, ignoreInit = TRUE)

    observeEvent(input$micro_seq_file, {
      micro_auto_import(input$micro_seq_file, "sequences", "represents the sequence")
    }, ignoreInit = TRUE)

    observeEvent(input$micro_tree_file, {
      micro_auto_import(input$micro_tree_file, "tree", "Phylogenetic tree")
    }, ignoreInit = TRUE)

    observeEvent(input$micro_meta_file, {
      micro_auto_import(input$micro_meta_file, "metadata", "sample metadata")
    }, ignoreInit = TRUE)

    observeEvent(input$micro_other_files, {
      if (is.null(input$micro_other_files) || !nrow(input$micro_other_files)) return()
      previous_view <- capture_active_view()
      had_active_view <- active_view_valid(previous_view)
      items <- isolate(rv$microbiome_import %||% list())
      other <- items$other %||% list()
      for (i in seq_len(nrow(input$micro_other_files))) {
        row <- input$micro_other_files[i, , drop = FALSE]
        nm <- row$name[1]
        ext <- tolower(tools::file_ext(nm))
        guessed <- if (ext %in% c("fa", "fasta", "fna")) {
          "sequences"
        } else if (ext %in% c("nwk", "tree", "tre")) {
          "tree"
        } else if (grepl("tax", nm, ignore.case = TRUE)) {
          "taxonomy"
        } else if (grepl("meta|mapping|sample", nm, ignore.case = TRUE)) {
          "metadata"
        } else {
          "abundance"
        }
        val <- tryCatch(micro_read_uploaded(row, guessed), error = function(e) {
          micro_add_diagnostic(
            "error", nm, guessed, "Read/Parse", conditionMessage(e),
            "Check the file format, encoding, extension and required R packages and re-upload."
          )
          showNotification(sprintf("%s Automatic import failed: %s", nm, e$message), type = "error", duration = 8)
          NULL
        })
        if (!is.null(val)) {
          micro_validate_import(guessed, val, nm)
          analysis_value <- if (identical(guessed, "tree")) {
            dava_micro_tree_analysis_table(val)
          } else {
            val
          }
          other[[nm]] <- analysis_value
          dataset_name <- safe_sheet_name(paste0("micro_other_", safe_file_stem(nm)))
          table_value <- analysis_value
          register_global_dataset(dataset_name, table_value, source = "Microbial data import",
            activate = TRUE, sync = FALSE)
          register_original_sheet(
            "Microbiology other tools export files",
            safe_file_stem(nm),
            table_value,
            source = "Microbial data import",
            activate = TRUE, sync = FALSE
          )
          rv$active_dataset <- dataset_name
        }
      }
      items$other <- other
      rv$microbiome_import <- items
      if (isTRUE(had_active_view)) {
        restore_active_view(previous_view)
      } else {
        rv$readOnly <- FALSE
        rv$active_book <- NULL
        rv$active_sheet <- NULL
      }
      log_event("Automatically import other microorganism files", paste(input$micro_other_files$name, collapse = "; "))
      mark_micro_import_synced()
      showNotification("Other tool export files have been automatically imported.", type = "message")
    }, ignoreInit = TRUE)

    observeEvent(input$micro_load_demo, {
      previous_view <- capture_active_view()
      had_active_view <- active_view_valid(previous_view)
      demo <- dava_micro_demo_components()
      items <- isolate(rv$microbiome_import %||% list())
      items$abundance <- normalize_df(demo$otu)
      items$taxonomy <- normalize_df(demo$taxonomy)
      items$group <- normalize_df(demo$group)
      items$env <- normalize_df(demo$env)
      items$metadata <- normalize_df(demo$metadata)
      rv$microbiome_import <- items
      micro_validate_import("abundance", items$abundance, "Built-in sample data")
      micro_validate_import("taxonomy", items$taxonomy, "Built-in sample data")
      micro_validate_import("metadata", items$metadata, "Built-in sample data")

      register_global_dataset("micro_otu_asv_table", items$abundance, source = "Microbial data import", activate = TRUE, sync = FALSE)
      register_global_dataset("micro_taxonomy_table", items$taxonomy, source = "Microbial data import", activate = FALSE, sync = FALSE)
      register_global_dataset("micro_group_table", items$group, source = "Microbial data import", activate = FALSE, sync = FALSE)
      register_global_dataset("micro_env_table", items$env, source = "Microbial data import", activate = FALSE, sync = FALSE)
      register_global_dataset("micro_metadata", items$metadata, source = "Microbial data import", activate = FALSE, sync = FALSE)
      register_original_sheet("Microbial sample data", "OTU_ASV abundance table", items$abundance, source = "Microbial data import", activate = TRUE, sync = FALSE)
      register_original_sheet("Microbial sample data", "Classification annotation table", items$taxonomy, source = "Microbial data import", activate = FALSE, sync = FALSE)
      register_original_sheet("Microbial sample data", "Group information table", items$group, source = "Microbial data import", activate = FALSE, sync = FALSE)
      register_original_sheet("Microbial sample data", "Environment variable table", items$env, source = "Microbial data import", activate = FALSE, sync = FALSE)
      register_original_sheet("Microbial sample data", "sample metadata", items$metadata, source = "Microbial data import", activate = FALSE, sync = FALSE)
      if (isTRUE(had_active_view)) {
        restore_active_view(previous_view)
      } else {
        rv$active_dataset <- "micro_otu_asv_table"
        rv$active_book <- NULL
        rv$active_sheet <- NULL
        rv$readOnly <- FALSE
      }
      log_event("Load microbial sample data", "dava_micro_demo_components")
      mark_micro_import_synced()
      showNotification("Loaded sample data consistent with Alpha diversity analysis.", type = "message")
    })
    
    # ------------------------------
    # Workbook / sheet selectors
    # ------------------------------
    
    output$book_ui <- renderUI({
      if (!workspace_restore_lock()) ensure_micro_import_registered()
      data_registry_token()
      if (length(rv$books) == 0) {
        return(tags$div(class = "small-muted", "The data has not been imported yet."))
      }
      
      selectInput(
        session$ns("book_select"),
        "workbook",
        choices = choices_with_blank(grouped_book_choices(), "No workbook selected"),
        selected = rv$active_book %||% ""
      )
    })
    
    observeEvent(input$book_select, {
      if (workspace_restore_locked()) return()
      selected <- input$book_select %||% ""
      previous_book <- isolate(rv$active_book %||% "")
      if (!nzchar(selected)) {
        if (isTRUE(rv$readOnly)) {
          rv$active_book <- NULL
          rv$active_sheet <- NULL
        }
      } else if (selected %in% names(rv$books %||% list())) {
        rv$readOnly <- TRUE
        rv$active_book <- selected
        rv$active_sheet <- names(rv$books[[rv$active_book]] %||% list())[1] %||% NULL
        rv$active_dataset <- NULL
      }
      if (!identical(selected, previous_book)) {
        clear_edit_history()
        sheet_names <- if (!is.null(rv$active_book) && !is.null((rv$books %||% list())[[rv$active_book]])) {
          names(rv$books[[rv$active_book]])
        } else {
          character(0)
        }
        updateSelectInput(
          session,
          "sheet_select",
          choices = choices_with_blank(stats::setNames(sheet_names, sheet_names), "No worksheet selected"),
          selected = rv$active_sheet %||% ""
        )
      }
    }, ignoreInit = TRUE)
    
    output$sheet_ui <- renderUI({
      if (!workspace_restore_lock()) ensure_micro_import_registered()
      data_registry_token()
      if (is.null(rv$active_book) || is.null(rv$books[[rv$active_book]])) {
        return(selectInput(
          session$ns("sheet_select"),
          "worksheet",
          choices = stats::setNames("", "No worksheet selected"),
          selected = ""
        ))
      }
      
      selectInput(
        session$ns("sheet_select"),
        "worksheet",
        choices = choices_with_blank(stats::setNames(names(rv$books[[rv$active_book]]), names(rv$books[[rv$active_book]])), "No worksheet selected"),
        selected = rv$active_sheet %||% ""
      )
    })
    
    observeEvent(input$sheet_select, {
      if (workspace_restore_locked()) return()
      selected <- input$sheet_select %||% ""
      previous_sheet <- isolate(rv$active_sheet %||% "")
      if (!nzchar(selected)) {
        if (isTRUE(rv$readOnly)) {
          rv$active_sheet <- NULL
        }
      } else if (!is.null(rv$active_book) && selected %in% names((rv$books %||% list())[[rv$active_book]] %||% list())) {
        rv$active_sheet <- selected
        rv$readOnly <- TRUE
        rv$active_dataset <- NULL
      }
      if (!identical(selected, previous_sheet)) {
        clear_edit_history()
      }
    }, ignoreInit = TRUE)
    
    safe_positive_int <- function(x, default) {
      value <- suppressWarnings(as.integer(x %||% default))
      if (length(value) == 0L || is.na(value[1]) || value[1] < 1L) default else value[1]
    }

    table_page_summary_text <- function(df, page, page_size, col_page, col_page_size, language = "en") {
      n_rows <- nrow(df)
      n_cols <- ncol(df)
      page <- safe_positive_int(page, 1L)
      page_size <- safe_positive_int(page_size, 200L)
      col_page <- safe_positive_int(col_page, 1L)
      col_page_size <- safe_positive_int(col_page_size, 100L)

      row_total_pages <- max(1L, ceiling(n_rows / page_size))
      col_total_pages <- max(1L, ceiling(n_cols / col_page_size))
      page <- min(page, row_total_pages)
      col_page <- min(col_page, col_total_pages)

      row_start <- if (n_rows == 0L) 0L else (page - 1L) * page_size + 1L
      row_end <- if (n_rows == 0L) 0L else min(n_rows, page * page_size)
      col_start <- if (n_cols == 0L) 0L else (col_page - 1L) * col_page_size + 1L
      col_end <- if (n_cols == 0L) 0L else min(n_cols, col_page * col_page_size)

      dava_tr(
        "\u884c\u6570: %s  \u5217\u6570: %s  \u5f53\u524d\u663e\u793a\u7b2c%s-%s\u884c\uff1b\u603b\u8ba1%s\u884c\uff1b\u7b2c%s/%s\u9875\uff1b\u6bcf\u9875%s\u884c\uff1b\u5f53\u524d\u663e\u793a\u7b2c%s-%s\u5217\uff1b\u603b\u8ba1%s\u5217\uff1b\u7b2c%s/%s\u9875\uff1b\u6bcf\u9875%s\u5217",
        language,
        format(n_rows, big.mark = ","),
        format(n_cols, big.mark = ","),
        format(row_start, big.mark = ","),
        format(row_end, big.mark = ","),
        format(n_rows, big.mark = ","),
        format(page, big.mark = ","),
        format(row_total_pages, big.mark = ","),
        format(page_size, big.mark = ","),
        format(col_start, big.mark = ","),
        format(col_end, big.mark = ","),
        format(n_cols, big.mark = ","),
        format(col_page, big.mark = ","),
        format(col_total_pages, big.mark = ","),
        format(col_page_size, big.mark = ",")
      )
    }

    output$table_page_summary <- renderText({
      table_summary_token()
      df <- isolate(current_df())
      req(df, hot_data())
      table_page_summary_text(
        df,
        page = input$hot_page,
        page_size = input$hot_page_size,
        col_page = input$hot_col_page,
        col_page_size = input$hot_col_page_size,
        language = interface_language()
      )
    })

#-------------------------    
#--------UndoandRedo-------
#-------------------------

    snapshot_state <- function(action = "", detail = "") {
      dataset_name <- isolate(rv$active_dataset %||% NULL)
      if (isTRUE(rv$readOnly) || is.null(dataset_name) || is.null((isolate(rv$global_datasets %||% list()))[[dataset_name]])) {
        return(NULL)
      }
      list(
        dataset = dataset_name,
        data = normalize_df_keep_rownames((isolate(rv$global_datasets %||% list()))[[dataset_name]]),
        page = isolate(input$hot_page %||% 1),
        action = action,
        detail = detail,
        time = Sys.time()
      )
    }
    
    push_undo <- function(action = "", detail = "") {
      snap <- snapshot_state(action, detail)
      if (is.null(snap)) return(invisible(FALSE))
      rv$undo_stack[[length(rv$undo_stack) + 1]] <- snap
      
      if (length(rv$undo_stack) > rv$max_history) {
        rv$undo_stack <- rv$undo_stack[
          (length(rv$undo_stack) - rv$max_history + 1):length(rv$undo_stack)
        ]
      }
      
      rv$redo_stack <- list()
      invisible(TRUE)
    }

    clear_edit_history <- function() {
      rv$undo_stack <- list()
      rv$redo_stack <- list()
    }
    
    restore_state <- function(snap) {
      if (is.null(snap$dataset) || !identical(snap$dataset, isolate(rv$active_dataset %||% NULL))) {
        return(invisible(FALSE))
      }
      datasets <- isolate(rv$global_datasets %||% list())
      if (is.null(datasets[[snap$dataset]])) return(invisible(FALSE))
      datasets[[snap$dataset]] <- snap$data
      rv$global_datasets <- datasets
      updateNumericInput(session, "hot_page", value = snap$page %||% 1)
      hot_render_token(isolate(hot_render_token()) + 1)
      table_summary_token(isolate(table_summary_token()) + 1)
      invisible(TRUE)
    }
    
    output$history_text <- renderText({
      dava_tr(
        "Undo: %s step(s); redo: %s step(s)",
        interface_language(),
        length(rv$undo_stack),
        length(rv$redo_stack)
      )
    })
    
    observeEvent(input$undo, {
      if (length(rv$undo_stack) == 0) {
        showNotification("There are no undoable actions.", type = "warning")
        return()
      }
      
      current <- snapshot_state("Redo snapshot", "")
      if (is.null(current)) {
        clear_edit_history()
        showNotification("There are no undoable edits to the current dataset.", type = "warning")
        return()
      }
      rv$redo_stack[[length(rv$redo_stack) + 1]] <- current
      
      snap <- rv$undo_stack[[length(rv$undo_stack)]]
      rv$undo_stack <- rv$undo_stack[-length(rv$undo_stack)]
      
      if (isTRUE(restore_state(snap))) {
        log_event("Undo", paste0(snap$action %||% "", " ", snap$detail %||% ""))
        showNotification("Revoked.", type = "message")
      }
    })
    
    observeEvent(input$redo, {
      if (length(rv$redo_stack) == 0) {
        showNotification("There are no redoable operations.", type = "warning")
        return()
      }
      
      current <- snapshot_state("Undo snapshot", "")
      if (is.null(current)) {
        clear_edit_history()
        showNotification("There are no redoable edits to the current dataset.", type = "warning")
        return()
      }
      rv$undo_stack[[length(rv$undo_stack) + 1]] <- current
      
      snap <- rv$redo_stack[[length(rv$redo_stack)]]
      rv$redo_stack <- rv$redo_stack[-length(rv$redo_stack)]
      
      if (isTRUE(restore_state(snap))) {
        log_event("Redo", paste0(snap$action %||% "", " ", snap$detail %||% ""))
        showNotification("has been redone.", type = "message")
      }
    })
    
    observeEvent(input$refresh_page, {
      hot_render_token(isolate(hot_render_token()) + 1)
    })
    
    
 #------------------   
  
    hot_data <- reactiveVal(NULL)               # stores the actual tableData
    hot_render_token <- reactiveVal(0)          # 【Key】used to control rendering“token”or“Counter”，ThisYesA purely digital counter。It does notYesStorageData，AndYesas a dependencyitem。When this number changes，Shiny would think“The dependencies have changed”，thereby triggering a redraw。
    preview_render_token <- reactiveVal(0)      # Same as above，is used to preview the table
    table_summary_token <- reactiveVal(0)
    table_clipboard <- reactiveVal(NULL)
    
    
    
    reset_table_pages <- function() {
      update_numeric_if_changed <- function(id, value) {
        current <- suppressWarnings(as.numeric(isolate(input[[id]] %||% NA)))
        if (is.na(current) || !identical(current, as.numeric(value))) {
          updateNumericInput(session, id, value = value, min = 1)
        }
      }
      update_select_if_changed <- function(id, value) {
        current <- as.character(isolate(input[[id]] %||% ""))
        if (!identical(current, as.character(value))) {
          updateSelectInput(session, id, selected = value)
        }
      }
      update_numeric_if_changed("hot_page", 1)
      update_numeric_if_changed("hot_preview_page", 1)
      update_numeric_if_changed("hot_col_page", 1)
      update_numeric_if_changed("hot_preview_col_page", 1)
      update_select_if_changed("hot_col_page_size", "100")
      update_select_if_changed("hot_preview_col_page_size", "100")
      hot_render_token(isolate(hot_render_token()) + 1)    #Write back the new value reactiveVal。isolate(hot_render_token()): Read the current count value（For example 0），but does not build reactive dependencies（Prevent infinite loops）。
      preview_render_token(isolate(preview_render_token()) + 1)
      table_summary_token(isolate(table_summary_token()) + 1)
    }

    observeEvent(current_df(), {
      if (workspace_restore_locked()) return()
      # Do not cache/render the whole table in rhandsontable.
      # Keep only a token so hidden pages do not rebuild large widgets.
      reset_table_pages()
    }, ignoreNULL = FALSE)


   

# ------------------------------
# rhandsontable editor
# ------------------------------

    observeEvent(input$refresh_hot, {
      hot_render_token(isolate(hot_render_token()) + 1)
      showNotification("The edit form has been refreshed.", type = "message")
    })

	observeEvent(input$hot_apply_page, {
      hot_render_token(isolate(hot_render_token()) + 1)
    })

    observeEvent(input$hot_col_page, {
      hot_render_token(isolate(hot_render_token()) + 1)
    })

    observeEvent(input$hot_col_page_size, {
      hot_render_token(isolate(hot_render_token()) + 1)
    })

    observeEvent(input$preview_apply_page, {
      preview_render_token(isolate(preview_render_token()) + 1)
    })

    observeEvent(input$hot_preview_col_page, {
      preview_render_token(isolate(preview_render_token()) + 1)
    })

    observeEvent(input$hot_preview_col_page_size, {
      preview_render_token(isolate(preview_render_token()) + 1)
    })

    output$hot <- renderRHandsontable({
      language <- interface_language()
      hot_render_token()
      df <- isolate(current_df())
      req(df)
      displayed_table_context(list(
        mode = if (isTRUE(isolate(rv$readOnly))) "book" else "dataset",
        dataset = isolate(rv$active_dataset %||% ""),
        book = isolate(rv$active_book %||% ""),
        sheet = isolate(rv$active_sheet %||% ""),
        generation = isolate(active_table_generation()),
        column_names = names(df),
        row_names = rownames(df)
      ))

	    df_page <- slice_df(
        df,
        page = isolate(input$hot_page %||% 1),
        page_size = isolate(input$hot_page_size %||% 200),
        col_page = isolate(input$hot_col_page %||% 1),
        col_page_size = isolate(input$hot_col_page_size %||% 2000)
      )
      hot_data(df_page)

      column_type_label <- function(x) {
        if (is.factor(x)) return("fct")
        if (inherits(x, "Date")) return("date")
        if (inherits(x, "POSIXt")) return("dttm")
        if (is.logical(x)) return("lgl")
        if (is.integer(x)) return("int")
        if (is.numeric(x)) return("dbl")
        if (is.character(x)) return("chr")
        substr(class(x)[1] %||% "obj", 1, 6)
      }
      type_headers <- unname(vapply(df_page, column_type_label, character(1)))
      column_header_js <- htmlwidgets::JS(sprintf(
        "function(col, TH) {
          if (col < 0) return;
          var types = %s;
          var names = %s;
          if (col >= names.length) return;
          var holder = TH.querySelector('.colHeader') || TH;
          holder.textContent = '';
          var typeLabel = document.createElement('div');
          typeLabel.className = 'dava-hot-type-label';
          typeLabel.textContent = types[col] || '';
          var nameLabel = document.createElement('div');
          nameLabel.className = 'dava-hot-name-label';
          nameLabel.textContent = names[col] || '';
          holder.appendChild(typeLabel);
          holder.appendChild(nameLabel);
        }",
        jsonlite::toJSON(type_headers, auto_unbox = FALSE),
        jsonlite::toJSON(names(df_page), auto_unbox = FALSE)
      ))
	    
      context_menu_js <- paste0(
        "function(el, x) {
          var hot = this.hot;
          var inputId = '__DAVA_HOT_CONTEXT_INPUT__';
          var sourceRows = __DAVA_HOT_SOURCE_ROWS__;
          var menuLabels = __DAVA_HOT_MENU_LABELS__;
          function selectedPayload(action) {
            var sel = hot.getSelectedLast() || [0, 0, 0, 0];
            var r1 = Math.min(sel[0], sel[2]);
            var r2 = Math.max(sel[0], sel[2]);
            var c1 = Math.min(sel[1], sel[3]);
            var c2 = Math.max(sel[1], sel[3]);
            if (r1 < 0) r1 = 0;
            if (c1 < 0) c1 = 0;
            var colHeaders = hot.getColHeader();
            var cellValue = null;
            try { cellValue = hot.getDataAtCell(r1, c1); } catch(e) {}
            return {
              action: action,
              row: r1,
              row2: r2,
              col: c1,
              col2: c2,
              colName: colHeaders && colHeaders[c1] ? colHeaders[c1] : null,
              colNames: colHeaders ? colHeaders.slice(c1, c2 + 1) : [],
              value: cellValue,
              nonce: Math.random()
            };
          }
          function send(action) {
            if (window.Shiny) Shiny.setInputValue(inputId, selectedPayload(action), {priority: 'event'});
          }
          function storeClipboardText(text) {
            var payload = selectedPayload('clipboard_store');
            payload.text = text || '';
            if (window.Shiny) Shiny.setInputValue(inputId, payload, {priority: 'event'});
          }
          function matrixText(data) {
            if (!data || !data.length) return '';
            return data.map(function(row) {
              return (row || []).map(function(value) {
                return value == null ? '' : String(value);
              }).join('\\t');
            }).join('\\n');
          }
          function rangeText() {
            var sel = hot.getSelectedLast();
            if (!sel) return '';
            var r1 = Math.min(sel[0], sel[2]);
            var r2 = Math.max(sel[0], sel[2]);
            var c1 = Math.min(sel[1], sel[3]);
            var c2 = Math.max(sel[1], sel[3]);
            var rows = [];
            for (var r = r1; r <= r2; r++) {
              var vals = [];
              for (var c = c1; c <= c2; c++) vals.push(hot.getDataAtCell(r, c));
              rows.push(vals.join('\\t'));
            }
            return rows.join('\\n');
          }
          function selectedRowNamesText() {
            var sel = hot.getSelectedLast();
            if (!sel) return '';
            var r1 = Math.max(0, Math.min(sel[0], sel[2]));
            var r2 = Math.min(sourceRows - 1, Math.max(sel[0], sel[2]));
            if (r2 < r1) return '';
            var names = [];
            for (var r = r1; r <= r2; r++) {
              var name = hot.getRowHeader(r);
              names.push(name == null ? '' : String(name));
            }
            return names.join('\\n');
          }
          function selectedColumnNamesText() {
            var sel = hot.getSelectedLast();
            if (!sel) return '';
            var c1 = Math.max(0, Math.min(sel[1], sel[3]));
            var c2 = Math.min(hot.countCols() - 1, Math.max(sel[1], sel[3]));
            if (c2 < c1) return '';
            var names = [];
            for (var c = c1; c <= c2; c++) {
              var name = hot.getColHeader(c);
              names.push(name == null ? '' : String(name));
            }
            return names.join('\\t');
          }
          function legacyCopy(text) {
            var ta = document.createElement('textarea');
            ta.value = text || '';
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
          }
          function writeClipboard(text) {
            storeClipboardText(text);
            if (navigator.clipboard && navigator.clipboard.writeText) {
              navigator.clipboard.writeText(text || '').catch(function() {
                legacyCopy(text);
              });
            } else {
              legacyCopy(text);
            }
          }
          function clearSelectionAfterCut() {
            if (hot.getSettings().readOnly) return;
            var sel = hot.getSelectedLast();
            if (!sel) return;
            for (var r = Math.min(sel[0], sel[2]); r <= Math.max(sel[0], sel[2]); r++) {
              for (var c = Math.min(sel[1], sel[3]); c <= Math.max(sel[1], sel[3]); c++) {
                if (r >= 0 && c >= 0) hot.setDataAtCell(r, c, null, 'context-cut');
              }
            }
          }
          function pasteClipboard() {
            if (hot.getSettings().readOnly) return;
            if (!(navigator.clipboard && navigator.clipboard.readText)) return send('paste_from_server');
            navigator.clipboard.readText().then(function(text) {
              var payload = selectedPayload('paste_from_text');
              payload.text = text || '';
              if (window.Shiny) Shiny.setInputValue(inputId, payload, {priority: 'event'});
            }).catch(function() {
              send('paste_from_server');
            });
          }
          function hasCellValue(value) {
            return value !== null && value !== undefined && String(value).trim() !== '';
          }
          function selectUsedDataRange() {
            var lastRow = -1;
            var lastCol = -1;
            var rows = hot.countRows();
            var cols = hot.countCols();
            for (var r = 0; r < rows; r++) {
              for (var c = 0; c < cols; c++) {
                if (hasCellValue(hot.getDataAtCell(r, c))) {
                  if (r > lastRow) lastRow = r;
                  if (c > lastCol) lastCol = c;
                }
              }
            }
            if (lastRow >= 0 && lastCol >= 0) {
              hot.selectCells([[0, 0, lastRow, lastCol]], false, false);
              return true;
            }
            return false;
          }
          function excelFillSeries(values, count, direction) {
            if (!values || values.length < 2 || count < 1) return null;
            function constantStep(series) {
              var step = series[1] - series[0];
              var tolerance = Math.max(1e-10, Math.abs(step) * 1e-10);
              for (var i = 2; i < series.length; i++) {
                if (Math.abs((series[i] - series[i - 1]) - step) > tolerance) return null;
              }
              return step;
            }
            var strings = values.map(function(value) { return value == null ? '' : String(value).trim(); });
            var numbers = strings.map(function(value) { return value === '' ? NaN : Number(value); });
            if (numbers.every(function(value) { return Number.isFinite(value); })) {
              var numberStep = constantStep(numbers);
              if (numberStep !== null) {
                return Array.from({length: count}, function(_, index) {
                  var offset = direction === 'down' ? index + 1 : count - index;
                  var value = direction === 'down' ? numbers[numbers.length - 1] + numberStep * offset : numbers[0] - numberStep * offset;
                  return Number(value.toPrecision(15));
                });
              }
            }
            var datePattern = /^\\d{4}-\\d{2}-\\d{2}$/;
            if (strings.every(function(value) { return datePattern.test(value); })) {
              var dates = strings.map(function(value) { return Date.parse(value + 'T00:00:00Z'); });
              if (dates.every(function(value) { return Number.isFinite(value); })) {
                var dateStep = constantStep(dates);
                if (dateStep !== null) {
                  return Array.from({length: count}, function(_, index) {
                    var offset = direction === 'down' ? index + 1 : count - index;
                    var value = direction === 'down' ? dates[dates.length - 1] + dateStep * offset : dates[0] - dateStep * offset;
                    return new Date(value).toISOString().slice(0, 10);
                  });
                }
              }
            }
            var suffixes = strings.map(function(value) { return value.match(/^(.*?)(-?\\d+)$/); });
            if (suffixes.every(Boolean)) {
              var prefix = suffixes[0][1];
              if (suffixes.every(function(match) { return match[1] === prefix; })) {
                var suffixNumbers = suffixes.map(function(match) { return Number(match[2]); });
                var suffixStep = constantStep(suffixNumbers);
                if (suffixStep === null) return null;
                var padWidth = Math.max.apply(null, suffixes.map(function(match) { return match[2].replace(/^-/, '').length; }));
                return Array.from({length: count}, function(_, index) {
                  var offset = direction === 'down' ? index + 1 : count - index;
                  var value = direction === 'down' ? suffixNumbers[suffixNumbers.length - 1] + suffixStep * offset : suffixNumbers[0] - suffixStep * offset;
                  if (!Number.isInteger(value)) return prefix + value;
                  var sign = value < 0 ? '-' : '';
                  return prefix + sign + String(Math.abs(value)).padStart(padWidth, '0');
                });
              }
            }
            return null;
          }
          function applyExcelAutofill(start, end, data) {
            var selection = hot.getSelectedLast();
            if (!selection || !data || data.length < 2 || !data[0] || !data[0].length) return;
            var top = Math.min(selection[0], selection[2]);
            var bottom = Math.max(selection[0], selection[2]);
            var direction = start.row > bottom ? 'down' : (end.row < top ? 'up' : '');
            if (!direction || start.col !== end.col && data[0].length === 1) return;
            var count = Math.abs(end.row - start.row) + 1;
            var columns = data[0].length;
            var generatedColumns = [];
            var inferred = false;
            for (var col = 0; col < columns; col++) {
              var source = data.map(function(row) { return row[col]; });
              var series = excelFillSeries(source, count, direction);
              if (series) inferred = true;
              generatedColumns.push(series);
            }
            if (!inferred) return;
            var generated = Array.from({length: count}, function(_, rowIndex) {
              return Array.from({length: columns}, function(_, colIndex) {
                var series = generatedColumns[colIndex];
                if (series) return series[rowIndex];
                var sourceIndex = direction === 'down'
                  ? rowIndex % data.length
                  : (data.length - (count % data.length) + rowIndex) % data.length;
                return data[sourceIndex][colIndex];
              });
            });
            data.splice.apply(data, [0, data.length].concat(generated));
          }
          hot.updateSettings({
            beforeAutofill: applyExcelAutofill,
            beforeKeyDown: function(event) {
              var key = String(event.key || '').toLowerCase();
              if ((event.ctrlKey || event.metaKey) && key === 'a') {
                if (selectUsedDataRange()) {
                  event.preventDefault();
                  event.stopImmediatePropagation();
                }
              }
            },
            afterCopy: function(data) {
              storeClipboardText(matrixText(data));
            },
            afterCut: function(data) {
              storeClipboardText(matrixText(data));
            },
            contextMenu: {
              callback: function(key) {
                if (key === 'ctx_copy') return writeClipboard(rangeText());
                if (key === 'ctx_copy_row_names') return writeClipboard(selectedRowNamesText());
                if (key === 'ctx_copy_col_names') return writeClipboard(selectedColumnNamesText());
                if (key === 'ctx_cut') { writeClipboard(rangeText()); return clearSelectionAfterCut(); }
                if (key === 'ctx_paste') return pasteClipboard();
                send(key);
              },
              items: {
                ctx_copy: {name: menuLabels.ctx_copy},
                ctx_copy_row_names: {name: menuLabels.ctx_copy_row_names},
                ctx_copy_col_names: {name: menuLabels.ctx_copy_col_names},
                ctx_cut: {name: menuLabels.ctx_cut},
                ctx_paste: {name: menuLabels.ctx_paste},
                sep_clip: '---------',
                ctx_transpose_selection: {name: menuLabels.ctx_transpose_selection},
                sep_transpose: '---------',
                ctx_insert_row_above: {name: menuLabels.ctx_insert_row_above},
                ctx_insert_row_below: {name: menuLabels.ctx_insert_row_below},
                ctx_delete_rows: {name: menuLabels.ctx_delete_rows},
                sep_rows: '---------',
                ctx_insert_col_left: {name: menuLabels.ctx_insert_col_left},
                ctx_insert_col_right: {name: menuLabels.ctx_insert_col_right},
                ctx_duplicate_col: {name: menuLabels.ctx_duplicate_col},
                ctx_delete_cols: {name: menuLabels.ctx_delete_cols},
                sep_sort: '---------',
                ctx_sort_asc: {name: menuLabels.ctx_sort_asc},
                ctx_sort_desc: {name: menuLabels.ctx_sort_desc}
              }
            }
          });
          function resizeDavaHot() {
            var rect = el.getBoundingClientRect();
            var available = window.innerHeight - rect.top - 18;
            var h = Math.max(360, available);
            var rowHeight = 24;
            var visibleRows = Math.max(8, Math.floor((h - 32) / rowHeight));
            var spareRows = Math.max(0, visibleRows - sourceRows);
            hot.updateSettings({
              height: h,
              minSpareRows: Math.min(spareRows, 3)
            });
            if (typeof hot.refreshDimensions === 'function') hot.refreshDimensions();
            hot.render();
          }
          resizeDavaHot();
          if (!el.__davaHotResizeBound) {
            el.__davaHotResizeBound = true;
            window.addEventListener('resize', resizeDavaHot);
          }
        }",
        ""
      )
      context_menu_js <- sub(
        "__DAVA_HOT_CONTEXT_INPUT__",
        session$ns("hot_context_action"),
        context_menu_js,
        fixed = TRUE
      )
      context_menu_js <- sub(
        "__DAVA_HOT_SOURCE_ROWS__",
        as.character(nrow(df_page)),
        context_menu_js,
        fixed = TRUE
      )
      menu_labels <- c(
        ctx_copy = "Copy", ctx_copy_row_names = "Copy row name", ctx_copy_col_names = "Copy column name",
        ctx_cut = "Cut", ctx_paste = "Paste", ctx_transpose_selection = "Transpose selected data",
        ctx_insert_row_above = "Insert row above", ctx_insert_row_below = "Insert row below",
        ctx_delete_rows = "Delete selected rows", ctx_insert_col_left = "Insert columns on the left",
        ctx_insert_col_right = "Insert column on the right", ctx_duplicate_col = "Copy the current column",
        ctx_delete_cols = "Delete selected column", ctx_sort_asc = "Sort ascending by current column",
        ctx_sort_desc = "Sort descending by current column"
      )
      menu_labels <- stats::setNames(
        dava_translate_text(unname(menu_labels), language), names(menu_labels)
      )
      context_menu_js <- sub(
        "__DAVA_HOT_MENU_LABELS__",
        jsonlite::toJSON(as.list(menu_labels), auto_unbox = TRUE),
        context_menu_js,
        fixed = TRUE
      )

	    rh <- rhandsontable(
	      df_page,
	      rowHeaders = rownames(df_page),
	      stretchH = "none",
        colWidths = 90,
	      manualColumnResize = TRUE,
	      manualRowResize = TRUE,
	      contextMenu = TRUE,
	      selectCallback = TRUE,
	      height = 650,
        minSpareRows = 1,
	      fillHandle = list(autoInsertRow = TRUE),
	      readOnly = isTRUE(rv$readOnly)
	    )
      rh <- hot_table(
        rh,
        columnHeaderHeight = 40,
        afterGetColHeader = column_header_js
      )
	    
      # for (nm in names(df)) {
      #   col <- df[[nm]]
      # 
      #   if (inherits(col, "Date")) {
      #     rh <- hot_col(rh, nm, type = "date", dateFormat = "YYYY-MM-DD", correctFormat = TRUE)
      #   } else if (is.numeric(col) || is.integer(col)) {
      #     rh <- hot_col(rh, nm, type = "numeric")
      #   } else if (is.logical(col)) {
      #     rh <- hot_col(rh, nm, type = "checkbox")
      #   } else {
      #     rh <- hot_col(rh, nm, type = "text")
      #   }
      # }

      htmlwidgets::onRender(rh, context_menu_js)
    })

    is_blank_table_row <- function(row_df) {
      if (!ncol(row_df)) return(TRUE)
      vals <- unlist(row_df[1, , drop = TRUE], use.names = FALSE)
      all(is.na(vals) | trimws(as.character(vals)) == "")
    }

    trim_trailing_spare_rows <- function(df_page, keep_min = 0) {
      keep_min <- max(0, as.integer(keep_min %||% 0))
      while (nrow(df_page) > keep_min && is_blank_table_row(df_page[nrow(df_page), , drop = FALSE])) {
        df_page <- df_page[-nrow(df_page), , drop = FALSE]
      }
      df_page
    }

	observeEvent(input$hot, {
	  req(input$hot)
	  if (isTRUE(rv$readOnly)) {
	    showNotification("The original data is read-only, please save it as a new data set before editing.", type = "warning")
	    return()
	  }
	  req(rv$active_dataset)
    
	  df_page <- tryCatch(
        hot_to_r(input$hot),
        error = function(e) NULL
      )
      req(!is.null(df_page))
      
      df <- current_df()
      
      page <- as.integer(input$hot_page %||% 1)
      page_size <- as.integer(input$hot_page_size %||% 200)
      if (is.na(page) || page < 1) page <- 1
      if (is.na(page_size) || page_size < 1) page_size <- 200
      
      if (nrow(df) >= 0) {
        max_page <- max(1, ceiling(max(1, nrow(df)) / page_size))
        page <- min(page, max_page)
        i1 <- (page - 1) * page_size + 1
        original_rows <- if (i1 <= nrow(df)) min(page_size, nrow(df) - i1 + 1) else 0
        df_page <- trim_trailing_spare_rows(df_page, keep_min = original_rows)
        if (!nrow(df_page)) return()

        i2 <- i1 + nrow(df_page) - 1
        if (i2 > nrow(df)) {
          add_n <- i2 - nrow(df)
          add_df <- as.data.frame(matrix(NA, nrow = add_n, ncol = ncol(df)), stringsAsFactors = FALSE, check.names = FALSE)
          names(add_df) <- names(df)
          df <- dplyr::bind_rows(df, add_df)
        }

        common_cols <- intersect(names(df_page), names(df))
        if (!length(common_cols)) return()
        df_page <- df_page[, common_cols, drop = FALSE]

        old_slice <- df[i1:i2, common_cols, drop = FALSE]
        changed <- !identical(normalize_df(old_slice), normalize_df(df_page))
        if (changed) {
          push_undo("Cell editing", sprintf("Line %s-%s current page edit", i1, i2))
        }

        old_rn <- rownames(df)
        df[i1:i2, common_cols] <- df_page
        rownames(df) <- old_rn
        datasets <- isolate(rv$global_datasets %||% list())
        datasets[[rv$active_dataset]] <- normalize_df_keep_rownames(df)
        rv$global_datasets <- datasets

        if (changed) {
          log_event("Cell editing", sprintf("Line %s-%s current page edit", i1, i2))
        }
      }
    }, ignoreInit = TRUE)

    selected_global_rows <- function(payload, df) {
      page <- as.integer(input$hot_page %||% 1)
      page_size <- as.integer(input$hot_page_size %||% 200)
      if (is.na(page) || page < 1) page <- 1
      if (is.na(page_size) || page_size < 1) page_size <- 200
      row1 <- suppressWarnings(as.integer(payload$row %||% 0)) + 1
      row2 <- suppressWarnings(as.integer(payload$row2 %||% payload$row %||% 0)) + 1
      rows <- seq.int(min(row1, row2), max(row1, row2)) + (page - 1) * page_size
      rows[rows >= 1 & rows <= nrow(df)]
    }

    selected_columns <- function(payload, df) {
      cols <- unlist(payload$colNames %||% character(0), use.names = FALSE)
      cols <- as.character(cols)
      cols <- cols[cols %in% names(df)]
      if (length(cols)) return(cols)
      col_name <- as.character(unlist(payload$colName %||% character(0), use.names = FALSE))[1]
      if (!is.na(col_name) && nzchar(col_name) && col_name %in% names(df)) return(col_name)
      col <- suppressWarnings(as.integer(payload$col %||% 0)) + 1
      if (is.na(col) || col < 1 || col > ncol(df)) return(character(0))
      names(df)[col]
    }

    parse_clipboard_table <- function(text) {
      text <- as.character(text %||% "")
      text <- gsub("\r\n?", "\n", text)
      if (!nzchar(text)) return(NULL)
      lines <- strsplit(text, "\n", fixed = TRUE)[[1]]
      while (length(lines) && identical(lines[[length(lines)]], "")) {
        lines <- lines[-length(lines)]
      }
      if (!length(lines)) return(NULL)

      rows <- lapply(lines, function(line) {
        cells <- strsplit(line, "\t", fixed = TRUE)[[1]]
        if (!length(cells)) cells <- ""
        cells
      })
      width <- max(lengths(rows), 1L)
      rows <- lapply(rows, function(cells) {
        length(cells) <- width
        cells[is.na(cells)] <- ""
        cells
      })
      as.data.frame(do.call(rbind, rows), stringsAsFactors = FALSE, check.names = FALSE)
    }

    selected_global_cell <- function(payload, df) {
      page <- safe_positive_int(input$hot_page, 1L)
      page_size <- safe_positive_int(input$hot_page_size, 200L)
      col_page <- safe_positive_int(input$hot_col_page, 1L)
      col_page_size <- safe_positive_int(input$hot_col_page_size, 100L)
      row <- suppressWarnings(as.integer(payload$row %||% 0L)) + 1L
      col <- suppressWarnings(as.integer(payload$col %||% 0L)) + 1L
      if (is.na(row) || row < 1L) row <- 1L
      if (is.na(col) || col < 1L) col <- 1L
      list(
        row = max(1L, (page - 1L) * page_size + row),
        col = max(1L, (col_page - 1L) * col_page_size + col)
      )
    }

    extend_df_for_paste <- function(df, min_rows, min_cols) {
      min_rows <- max(1L, safe_positive_int(min_rows, 1L))
      min_cols <- max(1L, safe_positive_int(min_cols, 1L))

      if (ncol(df) == 0L) {
        df <- as.data.frame(
          matrix(NA_character_, nrow = max(nrow(df), min_rows), ncol = min_cols),
          stringsAsFactors = FALSE,
          check.names = FALSE
        )
        names(df) <- make_unique_names(paste0("Column", seq_len(min_cols)))
        return(df)
      }

      if (nrow(df) < min_rows) {
        add <- as.data.frame(
          matrix(NA, nrow = min_rows - nrow(df), ncol = ncol(df)),
          stringsAsFactors = FALSE,
          check.names = FALSE
        )
        names(add) <- names(df)
        df <- dplyr::bind_rows(df, add)
      }

      if (ncol(df) < min_cols) {
        add_n <- min_cols - ncol(df)
        new_names <- make_unique_names(c(names(df), paste0("Column", seq_len(add_n))))
        for (i in seq_len(add_n)) {
          df[[new_names[ncol(df) + 1L]]] <- NA_character_
        }
      }
      df
    }

    paste_table_text <- function(payload, text) {
      if (isTRUE(rv$readOnly)) {
        showNotification("Original data is read-only. Please select an editable dataset before pasting.", type = "warning")
        return(FALSE)
      }
      req(rv$active_dataset, current_df())

      paste_df <- parse_clipboard_table(text)
      if (is.null(paste_df) || nrow(paste_df) == 0L || ncol(paste_df) == 0L) {
        showNotification("Clipboard is empty.", type = "warning")
        return(FALSE)
      }

      df <- current_df()
      target <- selected_global_cell(payload, df)
      row_idx <- seq.int(target$row, length.out = nrow(paste_df))
      col_idx <- seq.int(target$col, length.out = ncol(paste_df))
      df <- extend_df_for_paste(df, max(row_idx), max(col_idx))

      for (j in seq_along(col_idx)) {
        idx <- col_idx[[j]]
        values <- paste_df[[j]]
        assigned <- tryCatch({
          df[row_idx, idx] <- values
          TRUE
        }, error = function(e) FALSE)
        if (!isTRUE(assigned)) {
          df[[idx]] <- as.character(df[[idx]])
          df[row_idx, idx] <- values
        }
      }

      update_df(
        df,
        "Paste table cells",
        sprintf(
          "start row=%s; start col=%s; rows=%s; cols=%s",
          target$row,
          target$col,
          nrow(paste_df),
          ncol(paste_df)
        )
      )
      showNotification(sprintf("Pasted %s x %s cells.", nrow(paste_df), ncol(paste_df)), type = "message")
      TRUE
    }

    context_col_position <- function(payload, df, after = FALSE) {
      col <- suppressWarnings(as.integer(payload$col %||% 0)) + 1
      if (is.na(col) || col < 1) col <- 1
      col <- min(col, ncol(df))
      if (isTRUE(after)) col + 1 else col
    }

    open_context_rename_col <- function(col_name) {
      showModal(modalDialog(
        title = "Rename columns",
        textInput(session$ns("context_new_col_name"), "New column name", value = col_name),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("context_rename_col_confirm"), "Confirm", class = "btn-primary")),
        easyClose = TRUE
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    }

    open_context_convert_col <- function(col_name) {
      showModal(modalDialog(
        title = sprintf("Convert column type: %s", col_name),
        selectInput(session$ns("context_target_type"), "target type", choices = c("character", "factor", "numeric", "integer", "logical", "date"), selected = "character"),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("context_convert_col_confirm"), "Confirm", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)),
        easyClose = TRUE
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    }

    open_context_replace_na <- function(col_name) {
      showModal(modalDialog(
        title = sprintf("Replace NA/null value: %s", col_name),
        textInput(session$ns("context_replace_value"), "replaced by", value = ""),
        checkboxInput(session$ns("context_replace_blank_too"), "Also replace empty strings/whitespace characters", value = TRUE),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("context_replace_na_confirm"), "Confirm", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)),
        easyClose = TRUE
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    }

    open_context_select_cols <- function(cols = character(0)) {
      df <- current_df()
      selected <- intersect(cols, names(df))
      if (!length(selected)) selected <- names(df)
      showModal(modalDialog(
        title = "Filter/keep columns",
        shinyWidgets::pickerInput(
          session$ns("context_subset_cols"),
          "reserved fields",
          choices = names(df),
          selected = selected,
          multiple = TRUE,
          options = list(`actions-box` = TRUE, `live-search` = TRUE)
        ),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("context_subset_cols_confirm"), "Confirm", class = "btn-primary")),
        easyClose = TRUE
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    }

    open_context_split_col <- function(col_name) {
      df <- current_df()
      showModal(modalDialog(
        title = "sort",
        selectInput(session$ns("split_col"), "Fields that need to be sorted", choices = names(df), selected = col_name),
        textInput(session$ns("split_sep"), "delimiter", value = "_"),
        numericInput(session$ns("split_into_n"), "Maximum number of columns to split", value = 2, min = 2, step = 1),
        textInput(session$ns("split_prefix"), "New column name prefix", value = paste0(col_name, "_")),
        checkboxInput(session$ns("split_remove_original"), "Delete original field", value = FALSE),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("split_confirm"), "Confirm split", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)),
        easyClose = TRUE
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    }

    open_context_merge_cols <- function(cols = character(0)) {
      df <- current_df()
      selected <- intersect(cols, names(df))
      if (length(selected) < 2) selected <- names(df)[seq_len(min(2, ncol(df)))]
      showModal(modalDialog(
        title = "Merge columns",
        shinyWidgets::pickerInput(session$ns("merge_cols"), "Select the fields to be merged", choices = names(df), selected = selected, multiple = TRUE, options = list(`actions-box` = TRUE, `live-search` = TRUE)),
        textInput(session$ns("merge_sep"), "connector", value = "_"),
        textInput(session$ns("merge_new_col"), "New column name", value = "merged_col"),
        checkboxInput(session$ns("merge_remove_original"), "Delete original field", value = FALSE),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("merge_confirm"), "Confirm merge", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)),
        easyClose = TRUE
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    }

    open_context_formula_col <- function(col_name) {
      showModal(modalDialog(
        title = "Formula column",
        textInput(session$ns("formula_col"), "New column name", value = paste0(col_name, "_calc")),
        textAreaInput(session$ns("formula_expr"), "R expression", value = col_name, placeholder = "Example：height * weight\nExample：ifelse(group == 'A', 1, 0)", height = "140px"),
        tags$div(class = "small-muted", "can directly quote the column name; use backticks when the column name contains spaces."),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("formula_confirm"), "Confirm", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)),
        easyClose = TRUE,
        size = "l"
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    }

    open_context_fill_col <- function(col_name, rows = integer(0)) {
      df <- current_df()
      i1 <- if (length(rows)) min(rows) else 1
      i2 <- if (length(rows)) max(rows) else min(10, nrow(df))
      showModal(modalDialog(
        title = "Cell batch filling",
        selectInput(session$ns("fill_col"), "Populate fields", choices = names(df), selected = col_name),
        numericInput(session$ns("fill_from"), "start line", value = i1, min = 1, step = 1),
        numericInput(session$ns("fill_to"), "end line", value = i2, min = 1, step = 1),
        selectInput(session$ns("fill_mode"), "Filling method", choices = c("Fixed value" = "constant", "Serial number" = "sequence", "Fill down with the previous non-null value" = "down")),
        textInput(session$ns("fill_value"), "Fixed value/sequence starting value", value = ""),
        numericInput(session$ns("fill_step"), "sequence step size", value = 1),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("fill_confirm"), "Confirm", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)),
        easyClose = TRUE
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    }

    open_context_replace_col <- function(col_name) {
      df <- current_df()
      showModal(modalDialog(
        title = "Batch replacement",
        selectInput(session$ns("replace_col"), "field", choices = names(df), selected = col_name),
        textInput(session$ns("find_value"), "Find value", value = ""),
        textInput(session$ns("replace_value"), "replaced by", value = ""),
        checkboxInput(session$ns("replace_exact"), "Exactly match the entire cell", TRUE),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("replace_confirm"), "Confirm", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)),
        easyClose = TRUE
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    }

    context_pending <- reactiveVal(list())

    observeEvent(input$hot_context_action, {
      payload <- input$hot_context_action %||% list()
      action <- payload$action %||% ""
      if (identical(action, "clipboard_store")) {
        table_clipboard(list(text = as.character(payload$text %||% ""), saved_at = Sys.time()))
        return()
      }
      if (identical(action, "paste_from_text")) {
        text <- as.character(payload$text %||% "")
        if (!nzchar(text)) {
          clip <- table_clipboard()
          text <- as.character(clip$text %||% "")
        }
        if (nzchar(text)) table_clipboard(list(text = text, saved_at = Sys.time()))
        paste_table_text(payload, text)
        return()
      }
      if (identical(action, "paste_from_server")) {
        clip <- table_clipboard()
        if (is.null(clip) || !nzchar(as.character(clip$text %||% ""))) {
          showNotification("Clipboard is empty or unavailable. Copy cells in the table first, then paste again.", type = "warning")
          return()
        }
        paste_table_text(payload, clip$text)
        return()
      }
      if (identical(action, "paste_unavailable")) {
        showNotification("The current browser does not allow reading the clipboard from the right-click menu, please use Ctrl+V to paste.", type = "warning")
        return()
      }
      if (isTRUE(rv$readOnly)) {
        showNotification("The original data is read-only. Please save it as a new data set before using right-click data operations.", type = "warning")
        return()
      }
      req(rv$active_dataset, current_df())
      df <- current_df()
      cols <- selected_columns(payload, df)
      col_name <- cols[1] %||% names(df)[1]
      context_pending(list(col = col_name, payload = payload))

      if (action == "ctx_insert_row_above" || action == "ctx_insert_row_below") {
        rows <- selected_global_rows(payload, df)
        pos <- if (length(rows)) {
          if (action == "ctx_insert_row_above") min(rows) else max(rows) + 1
        } else {
          nrow(df) + 1
        }
        new_row <- empty_like_row(df)
        top <- if (pos > 1) df[seq_len(pos - 1), , drop = FALSE] else df[0, , drop = FALSE]
        bottom <- if (pos <= nrow(df)) df[pos:nrow(df), , drop = FALSE] else df[0, , drop = FALSE]
        update_df(dplyr::bind_rows(top, new_row, bottom), "Right-click to insert a row", sprintf("location=%s", pos))
        showNotification("1 row inserted.", type = "message")
      } else if (action == "ctx_transpose_selection") {
        rows <- selected_global_rows(payload, df)
        if (!length(rows) || !length(cols)) {
          showNotification("Please select the data area to be transposed in the table first.", type = "error")
          return()
        }
        out <- tryCatch(transpose_selection_in_place(df, rows, cols), error = function(e) e)
        if (inherits(out, "error")) {
          showNotification(paste("Selected data transposition failed:", out$message), type = "error", duration = 8)
          return()
        }
        update_df(
          out,
          "Select data transpose",
          sprintf("rows=%s; cols=%s", paste(range(rows), collapse = "-"), paste(cols, collapse = ",")),
          reset_page = FALSE
        )
        showNotification("The selected data has been transposed in the current table.", type = "message")
      } else if (action == "ctx_delete_rows") {
        rows <- selected_global_rows(payload, df)
        if (!length(rows)) { showNotification("No rows are selected for deletion.", type = "error"); return() }
        update_df(df[-rows, , drop = FALSE], "Right click to delete row", sprintf("row=%s", paste(range(rows), collapse = "-")))
        showNotification(sprintf("%s rows deleted.", length(rows)), type = "warning")
      } else if (action == "ctx_remove_dups") {
        before <- nrow(df)
        df2 <- dplyr::distinct(df)
        update_df(df2, "Right-click to delete duplicate rows", sprintf("Delete %s rows", before - nrow(df2)))
        showNotification(sprintf("Duplicate row deletion completed, deleted %s rows.", before - nrow(df2)), type = "message")
      } else if (action == "ctx_insert_col_left" || action == "ctx_insert_col_right") {
        pos <- context_col_position(payload, df, after = action == "ctx_insert_col_right")
        new_name <- make_unique_names(c(names(df), "new_col"))[ncol(df) + 1]
        out <- tryCatch(insert_column_at(df, new_name, NA_character_, pos), error = function(e) e)
        if (inherits(out, "error")) { showNotification(out$message, type = "error"); return() }
        update_df(out, "Right click to insert column", sprintf("%s; location=%s", new_name, pos))
      } else if (action == "ctx_duplicate_col") {
        req(col_name)
        pos <- match(col_name, names(df)) + 1
        new_name <- make_unique_names(c(names(df), paste0(col_name, "_copy")))[ncol(df) + 1]
        out <- tryCatch(insert_column_at(df, new_name, df[[col_name]], pos), error = function(e) e)
        if (inherits(out, "error")) { showNotification(out$message, type = "error"); return() }
        update_df(out, "Right-click to copy the column", sprintf("%s -> %s", col_name, new_name))
      } else if (action == "ctx_delete_cols") {
        if (!length(cols)) { showNotification("Columns are not selected for deletion.", type = "error"); return() }
        if (ncol(df) <= length(cols)) { showNotification("Keep at least one column.", type = "error"); return() }
        update_df(df[, setdiff(names(df), cols), drop = FALSE], "Right click to delete column", paste(cols, collapse = ","))
      } else if (action == "ctx_sort_asc" || action == "ctx_sort_desc") {
        req(col_name)
        df2 <- if (action == "ctx_sort_desc") dplyr::arrange(df, dplyr::desc(.data[[col_name]])) else dplyr::arrange(df, .data[[col_name]])
        update_df(df2, "Right click to sort", sprintf("%s %s", col_name, if (action == "ctx_sort_desc") "desc" else "asc"))
      } else if (action == "ctx_rename_col") {
        updateSelectInput(session, "selected_col", selected = col_name)
        open_context_rename_col(col_name)
      } else if (action == "ctx_convert_col") {
        updateSelectInput(session, "selected_col", selected = col_name)
        open_context_convert_col(col_name)
      } else if (action == "ctx_replace_na") {
        updateSelectInput(session, "selected_col", selected = col_name)
        open_context_replace_na(col_name)
      } else if (action == "ctx_select_cols") {
        updateSelectInput(session, "selected_col", selected = col_name)
        open_context_select_cols(cols)
      } else if (action == "ctx_split_col") {
        updateSelectInput(session, "selected_col", selected = col_name)
        open_context_split_col(col_name)
      } else if (action == "ctx_merge_cols") {
        updateSelectInput(session, "selected_col", selected = col_name)
        open_context_merge_cols(cols)
      } else if (action == "ctx_formula_col") {
        updateSelectInput(session, "selected_col", selected = col_name)
        open_context_formula_col(col_name)
      } else if (action == "ctx_fill_col") {
        updateSelectInput(session, "selected_col", selected = col_name)
        open_context_fill_col(col_name, selected_global_rows(payload, df))
      } else if (action == "ctx_replace_col") {
        updateSelectInput(session, "selected_col", selected = col_name)
        open_context_replace_col(col_name)
      }
      hot_render_token(isolate(hot_render_token()) + 1)
      preview_render_token(isolate(preview_render_token()) + 1)
    }, ignoreInit = TRUE)

    observeEvent(input$context_rename_col_confirm, {
      pending <- context_pending()
      old_name <- pending$col %||% ""
      req(old_name, input$context_new_col_name)
      removeModal()
      df <- current_df()
      new_name <- trimws(input$context_new_col_name)
      if (new_name == "") { showNotification("New column name cannot be empty.", type = "error"); return() }
      names(df)[names(df) == old_name] <- new_name
      names(df) <- make_unique_names(names(df))
      update_df(df, "Right-click to rename the column", sprintf("%s -> %s", old_name, new_name))
    }, ignoreInit = TRUE)

    observeEvent(input$context_convert_col_confirm, {
      pending <- context_pending()
      col_name <- pending$col %||% ""
      req(col_name, input$context_target_type)
      removeModal()
      df <- current_df()
      df[[col_name]] <- coerce_column(df[[col_name]], input$context_target_type)
      update_df(df, "Right-click to convert column type", sprintf("%s -> %s", col_name, input$context_target_type))
    }, ignoreInit = TRUE)

    observeEvent(input$context_replace_na_confirm, {
      pending <- context_pending()
      col_name <- pending$col %||% ""
      req(col_name)
      removeModal()
      df <- current_df()
      repl <- input$context_replace_value %||% ""
      col <- df[[col_name]]
      miss_idx <- is.na(col)
      if (isTRUE(input$context_replace_blank_too) && is.character(col)) {
        miss_idx <- miss_idx | trimws(col) == ""
      }
      if (inherits(col, "Date")) {
        col[miss_idx] <- suppressWarnings(as.Date(repl))
      } else if (is.numeric(col)) {
        col[miss_idx] <- suppressWarnings(as.numeric(repl))
      } else if (is.integer(col)) {
        col[miss_idx] <- suppressWarnings(as.integer(repl))
      } else if (is.logical(col)) {
        col[miss_idx] <- as.logical(repl)
      } else {
        col[miss_idx] <- repl
      }
      df[[col_name]] <- col
      update_df(df, "Right-click to replace NA/null value", sprintf("%s -> %s", col_name, repl))
    }, ignoreInit = TRUE)

    observeEvent(input$context_subset_cols_confirm, {
      req(input$context_subset_cols)
      removeModal()
      df <- current_df()
      cols <- intersect(input$context_subset_cols, names(df))
      if (!length(cols)) { showNotification("Please keep at least one column.", type = "error"); return() }
      update_df(df[, cols, drop = FALSE], "Right-click to filter columns", sprintf("Reserve %s column", length(cols)))
    }, ignoreInit = TRUE)
	
	
    # ------------------------------
    # DT preview
    # ------------------------------

	output$hot_preview_info <- renderText({
      req(current_df())
      paged_info_text(
        current_df(),
        page = input$hot_preview_page %||% 1,
        page_size = input$hot_preview_page_size %||% 200,
        col_page = input$hot_preview_col_page %||% 1,
        col_page_size = input$hot_preview_col_page_size %||% 2000,
        language = interface_language()
      )
    })
	
    output$dt <- renderDT({
    req(current_df())
	  preview_render_token()
	  
	  df_page <- slice_df(
        current_df(),
        page = isolate(input$hot_preview_page %||% 1),
        page_size = isolate(input$hot_preview_page_size %||% 200),
        col_page = isolate(input$hot_preview_col_page %||% 1),
        col_page_size = isolate(input$hot_preview_col_page_size %||% 2000)
      )
	  
      datatable(
        df_page, 
        editable = list(target = "cell",server = TRUE),
        filter = "top",
        rownames = FALSE,
        selection = list(mode = "multiple", target = "row"),
        options = list(
		    scroller = TRUE,
		    pageLength = 20,
		    lengthMenu = list(c(10, 20, 50, 100), c('10', '20', '50', '100')),
        scrollY = "500px",
        searchDelay = 500
        )
      )
    }, server = TRUE)

 
    # ------------------------------
    # Metadata and logs
    # ------------------------------

    output$meta_table <- renderDT({
      req(current_df())

      datatable(
        df_summary(current_df()),
        rownames = FALSE,
        options = list(scrollX = TRUE, pageLength = 20)
      )
    })

    output$log_table <- renderDT({
      datatable(
        rv$log,
        rownames = FALSE,
        options = list(scrollX = TRUE, pageLength = 20, order = list(list(0, "desc")))
      )
    })

#-----------------
#----OKOperation------
#----------------


    #-----Row add-----
     observeEvent(input$add_row, {
      req(current_df())

      df <- current_df()
      new_row <- empty_like_row(df)
      df2 <- dplyr::bind_rows(df, new_row)

      update_df(df2, "New row", "Add 1 blank record")

      showNotification("A new row has been added.", type = "message")
    })

    #----Row delete----
    observeEvent(input$delete_rows, {
      req(current_df())
      df <- current_df()
      row_from <- suppressWarnings(as.integer(input$delete_row_from))
      row_to <- suppressWarnings(as.integer(input$delete_row_to))
      if (is.na(row_from) || is.na(row_to)) {
        showNotification("Please fill in the starting line number and ending line number to be deleted.", type = "error")
        return()
      }
      row_from <- max(1, row_from)
      row_to <- min(nrow(df), row_to)
      if (row_from > row_to || row_from > nrow(df)) {
        showNotification("Invalid deletion of row range.", type = "error")
        return()
      }
      rows <- seq.int(row_from, row_to)
      df2 <- df[-rows, , drop = FALSE]
      update_df(
        df2,
        "Delete the specified line range",
        sprintf("Delete line number: %s-%s", row_from, row_to)
      )
      showNotification(sprintf("%s rows deleted.", length(rows)), type = "warning")
    })

    observeEvent(input$remove_dups, {
      if (!ensure_displayed_table_current("Rename row names")) return()
      req(current_df())
      df <- current_df()
      row_names <- rownames(df)
      if (is.null(row_names) || length(row_names) != nrow(df)) {
        row_names <- paste0("row_", seq_len(nrow(df)))
      }
      instance <- isolate(rename_row_instance()) + 1L
      rename_row_instance(instance)
      target_input_id <- paste0("rename_row_target_", instance)
      new_name_input_id <- paste0("rename_row_new_name_", instance)
      confirm_input_id <- paste0("rename_row_confirm_", instance)
      payload_input_id <- paste0("rename_row_payload_", instance)
      opened_dataset <- isolate(rv$active_dataset %||% "")
      opened_row_names <- row_names
      rename_row_context(list(
        dataset = isolate(rv$active_dataset %||% ""),
        generation = isolate(active_table_generation()),
        row_names = row_names,
        selected_index = if (length(row_names)) 1L else NA_integer_,
        target_input_id = target_input_id,
        new_name_input_id = new_name_input_id
      ))
      observeEvent(input[[target_input_id]], {
        selected_name <- input[[target_input_id]] %||% ""
        if (nzchar(selected_name)) {
          updateTextInput(session, new_name_input_id, value = selected_name)
        }
      }, ignoreInit = TRUE)
      rename_row_modal_token(isolate(rename_row_modal_token()) + 1L)
      showModal(
        modalDialog(
          title = "Rename row names",
          radioButtons(
            session$ns("rename_row_type"),
            label = "Select renaming method",
            choices = c("Single row name rename", "Multiple row names renamed by rules", "Use first column as row name"),
            selected = "Single row name rename"
          ),
          conditionalPanel(
            condition = "input.rename_row_type == 'Single row name rename'",
            selectizeInput(
              session$ns(target_input_id), "Select row name",
              choices = NULL, selected = NULL,
              options = list(placeholder = "Enter row name to search", maxOptions = 100L)
            ),
            textInput(session$ns(new_name_input_id), "New row name", value = row_names[1]),
            ns = session$ns
          ),
          conditionalPanel(
            condition = "input.rename_row_type == 'Multiple row names renamed by rules'",
            shinyWidgets::pickerInput(
              session$ns("rename_row_target_indices"), "Select multiple row names",
              choices = stable_name_choices(row_names), selected = character(0),
              multiple = TRUE,
              options = list(`actions-box` = TRUE, `live-search` = TRUE,
                             `selected-text-format` = "count > 3")
            ),
            textInput(session$ns("rename_row_prefix"), "New prefix", value = "row"),
            textInput(session$ns("rename_row_sep"), "delimiter", value = "_"),
            numericInput(session$ns("rename_row_start"), "Starting number", value = 1, min = 1, step = 1),
            ns = session$ns
          ),
          conditionalPanel(
            condition = "input.rename_row_type == 'Use first column as row name'",
            tags$div(class = "small-muted", "Use the value of the first column as the row name."),
            radioButtons(
              session$ns("rename_row_source_action"), "Whether to delete the first column after conversion",
              choices = c("Keep the first column" = "keep", "Delete the first column" = "delete"),
              selected = "delete", inline = TRUE
            ),
            ns = session$ns
          ),
          footer = tagList(
            modalButton("Cancel"),
            conditionalPanel(
              condition = "input.rename_row_type == 'Single row name rename'",
              actionButton(
                session$ns(confirm_input_id), "Confirm rename", class = "btn-primary",
                onclick = modal_rename_payload_js(payload_input_id, target_input_id, new_name_input_id)
              ),
              ns = session$ns
            ),
            conditionalPanel(
              condition = "input.rename_row_type != 'Single row name rename'",
              actionButton(session$ns("rename_row_confirm"), "Confirm rename", class = "btn-primary", onclick = sync_modal_inputs_before_action_js),
              ns = session$ns
            )
          ),
          easyClose = TRUE
        )
      )
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
      session$onFlushed(function() {
        updateSelectizeInput(
          session, target_input_id,
          choices = stable_name_choices(row_names),
          selected = row_names[1], server = TRUE
        )
      }, once = TRUE)
      observeEvent(input[[payload_input_id]], {
        payload <- input[[payload_input_id]]
        commit_single_name_rename(
          "row", opened_dataset, opened_row_names,
          payload$target, payload$new_name
        )
      }, ignoreInit = TRUE)
    })

    observeEvent(input$rename_row_target_index, {
      context <- rename_row_context()
      req(context, input$rename_row_target_index)
      raw_target <- as.character(input$rename_row_target_index)[1]
      index <- match(raw_target, context$row_names)
      if (is.na(index)) index <- suppressWarnings(as.integer(raw_target))
      if (length(index) == 1L && !is.na(index) && index >= 1L && index <= length(context$row_names)) {
        updateTextInput(session, "rename_row_new_name", value = context$row_names[index])
      }
    }, ignoreInit = TRUE)

    observeEvent(input$rename_row_confirm, {
      rename_type <- input$rename_row_type %||% ""
      if (!nzchar(rename_type)) {
        showNotification("Please select a row name renaming method.", type = "error")
        return()
      }
      if (!ensure_editable_table("Rename row names")) return()
      df <- current_df()
      req(df)
      row_context <- isolate(rename_row_context())
      if (is.null(row_context)) {
        row_context <- list(
          dataset = isolate(rv$active_dataset %||% ""),
          generation = isolate(active_table_generation()),
          row_names = rownames(df),
          selected_index = 1L
        )
      }
      if (!identical(isolate(rv$active_dataset %||% ""), row_context$dataset) ||
          !identical(isolate(active_table_generation()), row_context$generation) ||
          !identical(rownames(df), row_context$row_names)) {
        showNotification(
          "The current data set or row structure has changed after the pop-up window is opened. Please reopen the rename window.",
          type = "error", duration = 6
        )
        return()
      }
      if (rename_type == "Single row name rename") {
        rn <- rownames(df)
        raw_target <- if (!is.null(row_context$target_input_id)) {
          input[[row_context$target_input_id]]
        } else {
          input$rename_row_target_index %||% input$rename_row_target
        }
        if (is.null(raw_target)) {
          raw_target <- input$rename_row_target_index %||% input$rename_row_target
        }
        raw_target <- raw_target %||% NA_character_
        target_index <- match(as.character(raw_target)[1], row_context$row_names)
        if (length(target_index) != 1L || is.na(target_index)) {
          target_index <- suppressWarnings(as.integer(raw_target))
        }
        new_name_value <- if (!is.null(row_context$new_name_input_id)) {
          input[[row_context$new_name_input_id]]
        } else {
          input$rename_row_new_name
        }
        if (is.null(new_name_value)) {
          new_name_value <- input$rename_row_new_name
        }
        new_name <- trimws(new_name_value %||% "")
        if (length(target_index) != 1L || is.na(target_index) ||
            target_index < 1L || target_index > nrow(df)) {
          showNotification("Please select a valid target row name.", type = "error")
          return()
        }
        if (new_name == "") {
          showNotification("New row name cannot be empty.", type = "error")
          return()
        }
        old_name <- rn[target_index]
        rn[target_index] <- new_name
        rownames(df) <- make_unique_names(rn)
        update_df(df, "Rename row names", sprintf("%s -> %s", old_name, rownames(df)[target_index]))
        showNotification("Row names updated.", type = "message")
      } else if (rename_type == "Multiple row names renamed by rules") {
        rn <- rownames(df)
        raw_targets <- input$rename_row_target_indices %||% input$rename_row_targets %||% character(0)
        raw_targets <- as.character(unlist(raw_targets, use.names = FALSE))
        idx <- match(raw_targets, row_context$row_names)
        unresolved <- is.na(idx)
        if (any(unresolved)) idx[unresolved] <- suppressWarnings(as.integer(raw_targets[unresolved]))
        idx <- unique(idx[!is.na(idx) & idx >= 1L & idx <= nrow(df)])
        if (!length(idx)) {
          showNotification("Please select at least one row name.", type = "error")
          return()
        }
        prefix <- trimws(input$rename_row_prefix %||% "row")
        if (prefix == "") prefix <- "row"
        sep <- input$rename_row_sep %||% "_"
        start <- suppressWarnings(as.integer(input$rename_row_start %||% 1))
        if (is.na(start) || start < 1) start <- 1
        new_names <- paste0(prefix, sep, seq.int(start, length.out = length(idx)))
        rn[idx] <- new_names
        rownames(df) <- make_unique_names(rn)
        update_df(df, "Rename row names", sprintf("Batch rename %s row names", length(idx)))
        showNotification("Multiple row names have been renamed per rule.", type = "message")
      } else if (rename_type == "Use first column as row name") {
        if (ncol(df) < 1) {
          showNotification("There are no available columns in the current table.", type = "error")
          return()
        }
        new_rn <- as.character(df[[1]])
        if (any(is.na(new_rn) | trimws(new_rn) == "")) {
          showNotification("The first column cannot contain NA or null values.", type = "error")
          return()
        }
        if (length(new_rn) != nrow(df)) {
          showNotification("The number of values ​​in the first column must match the current number of rows.", type = "error")
          return()
        }
        delete_source <- identical(input$rename_row_source_action %||% "delete", "delete")
        if (delete_source) df <- df[, -1, drop = FALSE]
        rownames(df) <- make_unique_names(new_rn)
        source_action <- if (delete_source) "Delete the first column" else "Keep the first column"
        update_df(df, "Rename row names", sprintf("The first column is converted to row name; %s; %s rows in total", source_action, nrow(df)))
        showNotification("Already used the first column as the row name.", type = "message")
      }
      removeModal()
    })

    #-----Row sort------
    observeEvent(input$sort_open, {
      req(current_df())
      capture_advanced_modal_context(current_df())
      
      showModal(
        modalDialog(
          title = "Sort",
          selectInput(
            session$ns("sort_col"),
            "Sort field",
            choices = stable_name_choices(names(current_df())),
            selected = names(current_df())[1]
          ),
          radioButtons(
            session$ns("sort_dir"),
            "Sort by",
            choices = c("Ascending" = "asc", "Descending" = "desc"),
            selected = "asc",
            inline = TRUE
          ),
          footer = tagList(
            modalButton("Cancel"),
            actionButton(session$ns("sort_confirm"), "Confirm sorting", class = "btn-primary")
          ),
          easyClose = TRUE
        )
      )
      #jqui_draggable(".modal-content")       #will pop up content areaSettingsis draggable，requiredlibrary(shinyjqui)
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",     #SettingsHead drag，Does not affect other components in the window
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
      
    })
    
    observeEvent(input$sort_confirm, {
      if (!advanced_modal_is_current("Sort")) return()
      req(input$sort_col)
      removeModal()
      df <- current_df()
      col <- input$sort_col
      if (input$sort_dir == "desc") {
        df2 <- df %>% arrange(desc(.data[[col]]))
      } else {
        df2 <- df %>% arrange(.data[[col]])
      }
      #rownames(df2) <- NULL
      update_df(df2, "Sort", sprintf("%s %s", col, input$sort_dir))
      showNotification("Sorting completed.", type = "message")
    })
    
    #-----Row filter-----
    observeEvent(input$filter_open, {
      req(current_df())
      capture_advanced_modal_context(current_df())
      
      showModal(
        modalDialog(
          title = "Filter",
          selectInput(
            session$ns("filter_col"),
            "Filter fields",
            choices = stable_name_choices(names(current_df())),
            selected = names(current_df())[1]
          ),
          selectInput(
            session$ns("filter_op"),
            "Conditions",
            choices = c(
              "contains" = "contains",
              "equals" = "equal",
              "is not equal to" = "not_equal",
              "is greater than" = "gt",
              "Greater than or equal to" = "gte",
              "less than" = "lt",
              "Less than or equal to" = "lte",
              "not empty" = "not_empty",
              "is empty" = "empty"
            ),
            selected = "contains"
          ),
          textInput(session$ns("filter_value"), "filter value", value = ""),
          footer = tagList(
            modalButton("Cancel"),
            actionButton(session$ns("filter_confirm"), "Confirm filter", class = "btn-primary")
          ),
          easyClose = TRUE
        )
      )
      #jqui_draggable(".modal-content")
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
    })
    
    observeEvent(input$filter_confirm, {
      if (!advanced_modal_is_current("Filter")) return()
      req(input$filter_col, input$filter_op)
      removeModal()
      
      df <- current_df()
      col <- df[[input$filter_col]]
      val <- input$filter_value %||% ""
      op <- input$filter_op
      
      keep <- rep(TRUE, nrow(df))
      
      if (op == "contains") {
        keep <- grepl(val, as.character(col), ignore.case = TRUE)
      } else if (op == "equal") {
        keep <- as.character(col) == val
      } else if (op == "not_equal") {
        keep <- as.character(col) != val
      } else if (op %in% c("gt", "gte", "lt", "lte")) {
        x <- suppressWarnings(as.numeric(col))
        y <- suppressWarnings(as.numeric(val))
        
        keep <- switch(
          op,
          gt = x > y,
          gte = x >= y,
          lt = x < y,
          lte = x <= y
        )
        
        keep[is.na(keep)] <- FALSE
      } else if (op == "not_empty") {
        keep <- !is.na(col) & trimws(as.character(col)) != ""
      } else if (op == "empty") {
        keep <- is.na(col) | trimws(as.character(col)) == ""
      }
      
      df2 <- df[keep, , drop = FALSE]
      #rownames(df2) <- NULL
      
      update_df(
        df2,
        "Filter",
        sprintf("%s %s %s; keep %s line", input$filter_col, op, val, nrow(df2))
      )
      
      showNotification(sprintf("Filtering completed, retaining %s rows.", nrow(df2)), type = "message")
    })
    
    
#------------------------------
#--------columnOperation----------
#------------------------------  
    
    #-------Column selector-------
    
    output$column_select_ui <- renderUI({
      req(current_df())
      
      selectInput(
        session$ns("selected_col"),
        "field",
        choices = stable_name_choices(names(current_df())),
        selected = names(current_df())[1]
      )
    })
    
    
    # ------------------------------
    # Column rename
    # ------------------------------
    observeEvent(input$rename_col_open, {
      if (!ensure_displayed_table_current("Rename column names")) return()
      req(current_df())
      df <- current_df()
      selected <- input$selected_col %||% names(df)[1]
      if (!selected %in% names(df)) selected <- names(df)[1]
      selected_index <- match(selected, names(df))
      instance <- isolate(rename_col_instance()) + 1L
      rename_col_instance(instance)
      target_input_id <- paste0("rename_col_target_", instance)
      new_name_input_id <- paste0("rename_col_new_name_", instance)
      confirm_input_id <- paste0("rename_col_confirm_", instance)
      payload_input_id <- paste0("rename_col_payload_", instance)
      opened_dataset <- isolate(rv$active_dataset %||% "")
      opened_column_names <- names(df)
      rename_col_context(list(
        dataset = isolate(rv$active_dataset %||% ""),
        generation = isolate(active_table_generation()),
        column_names = names(df),
        selected_index = selected_index,
        target_input_id = target_input_id,
        new_name_input_id = new_name_input_id
      ))
      observeEvent(input[[target_input_id]], {
        selected_name <- input[[target_input_id]] %||% ""
        if (nzchar(selected_name)) {
          updateTextInput(session, new_name_input_id, value = selected_name)
        }
      }, ignoreInit = TRUE)

      showModal(
        modalDialog(
          title = "Rename column names",
          radioButtons(
            session$ns("rename_col_type"),
            label = "Select renaming method",
            choices = c("Single column name rename", "Multiple column names are renamed by rules", "Use first row as column name"),
            selected = "Single column name rename"
          ),
          conditionalPanel(
            condition = "input.rename_col_type == 'Single column name rename'",
            selectInput(
              session$ns(target_input_id), "target column",
              choices = stable_name_choices(names(df)),
              selected = selected
            ),
            textInput(session$ns(new_name_input_id), "New column name", value = selected),
            ns = session$ns
          ),
          conditionalPanel(
            condition = "input.rename_col_type == 'Multiple column names are renamed by rules'",
            shinyWidgets::pickerInput(
              session$ns("rename_col_target_indices"), "Select multiple columns",
              choices = stable_name_choices(names(df)),
              selected = character(0), multiple = TRUE,
              options = list(`actions-box` = TRUE, `live-search` = TRUE,
                             `selected-text-format` = "count > 3")
            ),
            textInput(session$ns("rename_col_prefix"), "New prefix", value = "Column"),
            textInput(session$ns("rename_col_sep"), "delimiter", value = "_"),
            numericInput(session$ns("rename_col_start"), "Starting number", value = 1, min = 1, step = 1),
            ns = session$ns
          ),
          conditionalPanel(
            condition = "input.rename_col_type == 'Use first row as column name'",
            tags$div(class = "small-muted", "Use the value of the first row as the column name."),
            radioButtons(
              session$ns("rename_col_source_action"), "Whether to delete the first line after conversion",
              choices = c("Keep the first line" = "keep", "Delete the first line" = "delete"),
              selected = "delete", inline = TRUE
            ),
            ns = session$ns
          ),
          footer = tagList(
            modalButton("Cancel"),
            conditionalPanel(
              condition = "input.rename_col_type == 'Single column name rename'",
              actionButton(
                session$ns(confirm_input_id), "Confirm rename", class = "btn-primary",
                onclick = modal_rename_payload_js(payload_input_id, target_input_id, new_name_input_id)
              ),
              ns = session$ns
            ),
            conditionalPanel(
              condition = "input.rename_col_type != 'Single column name rename'",
              actionButton(session$ns("rename_col_confirm"), "Confirm rename", class = "btn-primary", onclick = sync_modal_inputs_before_action_js),
              ns = session$ns
            )
          ),
          easyClose = TRUE
        )
      )
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
      observeEvent(input[[payload_input_id]], {
        payload <- input[[payload_input_id]]
        commit_single_name_rename(
          "column", opened_dataset, opened_column_names,
          payload$target, payload$new_name
        )
      }, ignoreInit = TRUE)
    })

    observeEvent(input$rename_col_target_index, {
      context <- rename_col_context()
      if (is.null(context)) return()
      raw_target <- as.character(input$rename_col_target_index)[1]
      index <- match(resolve_current_column_name(raw_target, context$column_names), context$column_names)
      if (length(index) != 1L || is.na(index)) index <- suppressWarnings(as.integer(raw_target))
      if (!is.null(context) && length(index) == 1L && !is.na(index) &&
          index >= 1L && index <= length(context$column_names)) {
        updateTextInput(session, "new_col_name", value = context$column_names[index])
      }
    }, ignoreInit = TRUE)

    resolve_current_column_name <- function(value, available) {
      candidate <- as.character(unlist(value %||% character(0), use.names = FALSE))[1]
      if (length(candidate) == 0L || is.na(candidate) || !nzchar(candidate)) return(NA_character_)
      if (candidate %in% available) return(candidate)
      clean <- function(x) trimws(sub("^\ufeff", "", enc2utf8(as.character(x))))
      matched <- which(clean(available) == clean(candidate))
      if (length(matched) == 1L) available[matched] else NA_character_
    }

    observeEvent(input$rename_col_confirm, {
      rename_type <- trimws(as.character(input$rename_col_type %||% "")[1])
      valid_types <- c("Single column name rename", "Multiple column names are renamed by rules", "Use first row as column name")
      if (!rename_type %in% valid_types) {
        showNotification("Please select a column name renaming method.", type = "error")
        return()
      }
      context <- isolate(rename_col_context())
      if (is.null(context)) {
        # Compatibility for programmatic callers; the browser always creates
        # this immutable context when the modal opens.
        fallback_df <- isolate(current_df())
        context <- list(
          dataset = isolate(rv$active_dataset %||% ""),
          generation = isolate(active_table_generation()),
          column_names = names(fallback_df),
          selected_index = match(input$rename_col_target %||% names(fallback_df)[1], names(fallback_df))
        )
      }
      datasets <- isolate(rv$global_datasets %||% list())
      active_dataset <- isolate(rv$active_dataset %||% "")
      if (isTRUE(isolate(rv$readOnly)) || !nzchar(context$dataset) ||
          !identical(active_dataset, context$dataset) ||
          !identical(isolate(active_table_generation()), context$generation) ||
          is.null(datasets[[context$dataset]])) {
        showNotification("The current data set has been switched after the pop-up window opens. Please reopen the rename window.", type = "error", duration = 6)
        return()
      }
      df <- datasets[[context$dataset]]
      if (!identical(names(df), context$column_names)) {
        showNotification("The table column structure has changed after the pop-up window is opened. Please reopen the rename window.", type = "error", duration = 6)
        return()
      }
      result_df <- df
      detail_text <- ""
      if (rename_type == "Single column name rename") {
        raw_target <- if (!is.null(context$target_input_id)) {
          input[[context$target_input_id]]
        } else {
          input$rename_col_target_index %||% input$rename_col_target
        }
        if (is.null(raw_target)) {
          raw_target <- input$rename_col_target_index %||% input$rename_col_target
        }
        raw_target <- raw_target %||% NA_character_
        submitted_name <- resolve_current_column_name(raw_target, context$column_names)
        target_index <- match(submitted_name, context$column_names)
        if (is.na(target_index)) {
          target_index <- suppressWarnings(as.integer(raw_target))
        }
        new_name_value <- if (!is.null(context$new_name_input_id)) {
          input[[context$new_name_input_id]]
        } else {
          input$new_col_name
        }
        if (is.null(new_name_value)) {
          new_name_value <- input$new_col_name
        }
        new_name <- trimws(new_name_value %||% "")
        if (length(target_index) != 1L || is.na(target_index) || target_index < 1L || target_index > ncol(result_df)) {
          showNotification(
            "The target column has changed. Please close the pop-up window, reopen it and select the current column.",
            type = "error", duration = 6
          )
          return()
        }
        if (new_name == "") {
          showNotification("New column name cannot be empty.", type = "error")
          return()
        }
        old_name <- names(result_df)[target_index]
        names(result_df)[target_index] <- new_name
        names(result_df) <- make_unique_names(names(result_df))
        detail_text <- sprintf("%s -> %s", old_name, names(result_df)[target_index])
      } else if (rename_type == "Multiple column names are renamed by rules") {
        raw_targets <- input$rename_col_target_indices %||% input$rename_col_targets %||% character(0)
        raw_targets <- as.character(unlist(raw_targets, use.names = FALSE))
        idx <- vapply(raw_targets, function(value) {
          matched_name <- resolve_current_column_name(value, context$column_names)
          matched_index <- match(matched_name, context$column_names)
          if (is.na(matched_index)) matched_index <- suppressWarnings(as.integer(value))
          matched_index
        }, integer(1))
        idx <- unique(idx[!is.na(idx) & idx >= 1L & idx <= ncol(result_df)])
        if (!length(idx)) {
          targets <- normalize_advanced_column_selection(input$rename_col_targets, names(result_df))
          idx <- match(targets, names(result_df))
          idx <- idx[!is.na(idx)]
        }
        if (!length(idx)) {
          showNotification("Please select at least one column name.", type = "error")
          return()
        }
        prefix <- trimws(input$rename_col_prefix %||% "Column")
        if (prefix == "") prefix <- "Column"
        sep <- input$rename_col_sep %||% "_"
        start <- suppressWarnings(as.integer(input$rename_col_start %||% 1))
        if (is.na(start) || start < 1) start <- 1
        names(result_df)[idx] <- paste0(prefix, sep, seq.int(start, length.out = length(idx)))
        names(result_df) <- make_unique_names(names(result_df))
        detail_text <- sprintf("Batch rename %s column names", length(idx))
      } else if (rename_type == "Use first row as column name") {
        if (nrow(result_df) < 1) {
          showNotification("There are no rows available in the current table.", type = "error")
          return()
        }
        new_names <- as.character(result_df[1, , drop = TRUE])
        if (any(is.na(new_names) | trimws(new_names) == "")) {
          showNotification("The first row cannot contain NA or null values.", type = "error")
          return()
        }
        if (length(new_names) != ncol(result_df)) {
          showNotification("The number of values ​​in the first row must match the current number of columns.", type = "error")
          return()
        }
        names(result_df) <- make_unique_names(new_names)
        delete_source <- identical(input$rename_col_source_action %||% "delete", "delete")
        if (delete_source) result_df <- result_df[-1, , drop = FALSE]
        source_action <- if (delete_source) "Delete the first line" else "Keep the first line"
        detail_text <- sprintf("The first row is converted to column names; %s; total %s columns", source_action, ncol(result_df))
      }
      # Atomic, rename-only commit. Do not route the operation through a
      # reactive current table that may have changed while the modal was open.
      push_undo("Rename column names", detail_text)
      datasets[[context$dataset]] <- normalize_df_keep_rownames(result_df)
      rv$global_datasets <- datasets
      hot_render_token(isolate(hot_render_token()) + 1L)
      table_summary_token(isolate(table_summary_token()) + 1L)
      log_event("Rename column names", detail_text)
      rename_col_context(NULL)
      showNotification("Column name renaming completed.", type = "message")
      removeModal()
    })

    # ------------------------------
    # Column type conversion
    # ------------------------------

    normalize_advanced_column_selection <- function(value, available) {
      selected <- as.character(unlist(value %||% character(0), use.names = FALSE))
      selected <- trimws(selected[!is.na(selected) & nzchar(trimws(selected))])
      if (length(selected) == 1L && !selected %in% available && grepl(",", selected, fixed = TRUE)) {
        selected <- trimws(strsplit(selected, ",", fixed = TRUE)[[1]])
      }
      unique(selected[selected %in% available])
    }

    # ------------------------------
    # Column type conversion
    # ------------------------------

    observeEvent(input$convert_col_open, {
      if (!ensure_displayed_table_current("Convert column type")) return()
      req(current_df())
      capture_advanced_modal_context(current_df())
      df <- current_df()
      selected <- input$selected_col %||% names(df)[1]
      if (!selected %in% names(df)) selected <- names(df)[1]

      showModal(
        modalDialog(
          title = "Convert column type",
            shinyWidgets::pickerInput(
              session$ns("convert_col_target"),
              "Target column (multiple selections possible)",
              choices = stable_name_choices(names(df)),
            selected = selected,
            multiple = TRUE,
            options = list(
              `actions-box` = TRUE,
              `live-search` = TRUE,
              `selected-text-format` = "count > 3",
              `max-options` = 20
            )
          ),
          selectInput(
            session$ns("target_type"),
            "target type",
            choices = c("character", "factor", "numeric", "integer", "logical", "date"),
            selected = "character"
          ),
          tags$div(
            class = "small-muted",
            "Description: Values ​​that fail to be converted become NA. Date supports Excel serial values ​​and common text dates such as YYYY-MM-DD."
          ),
          footer = tagList(
            modalButton("Cancel"),
            actionButton(session$ns("convert_col_confirm"), "Confirm", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)
          ),
          easyClose = TRUE
        )
      )
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
    })

    observeEvent(input$convert_col_confirm, {
      if (!advanced_modal_is_current("Convert column type")) return()
      if (is.null(input$convert_col_target) || !nzchar(input$target_type %||% "")) {
        showNotification("Please select a target column and target type.", type = "error")
        return()
      }
      if (!ensure_editable_table("Convert column type")) return()

      df <- current_df()
      col_names <- normalize_advanced_column_selection(input$convert_col_target, names(df))
      target <- input$target_type
      if (!length(col_names)) {
        showNotification("Please select a valid target column.", type = "error")
        return()
      }

      for (col_name in col_names) {
        df[[col_name]] <- coerce_column(df[[col_name]], target)
      }

      update_df(df, "Convert column type", sprintf("%s -> %s", paste(col_names, collapse = ", "), target))

      showNotification(sprintf("Completed type conversion of column %s.", length(col_names)), type = "message")
      removeModal()
    })

    # ------------------------------
    # Move rows / columns
    # ------------------------------

    observeEvent(input$replace_na_open, {
      if (!ensure_displayed_table_current("Move row")) return()
      req(current_df())
      df <- current_df()
      capture_advanced_modal_context(df)
      selected <- input$selected_col %||% names(df)[1]
      if (!selected %in% names(df)) selected <- names(df)[1]
      move_row_names <- rownames(df)
      if (is.null(move_row_names) || length(move_row_names) != nrow(df)) {
        move_row_names <- as.character(seq_len(nrow(df)))
      }

      showModal(modalDialog(
        title = "Move row and column position",
        radioButtons(
          session$ns("move_axis"),
          "Movement type",
          choices = c("Move row" = "row", "Move columns" = "col"),
          selected = "row",
          inline = TRUE
        ),
        conditionalPanel(
          condition = "input.move_axis == 'row'",
          selectizeInput(
            session$ns("move_row_target"), "Specify row",
            choices = NULL, selected = NULL,
            options = list(placeholder = "Enter row name to search", maxOptions = 100L)
          ),
          ns = session$ns
        ),
        conditionalPanel(
          condition = "input.move_axis == 'col'",
          selectizeInput(
            session$ns("move_col_target"), "Specify column",
            choices = NULL, selected = NULL,
            options = list(placeholder = "Enter column name to search", maxOptions = 100L)
          ),
          ns = session$ns
        ),
        numericInput(session$ns("move_position"), "Move to location", value = 1, min = 1, step = 1),
        footer = tagList(
          modalButton("Cancel"),
          actionButton(session$ns("replace_na_confirm"), "Confirm move", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)
        ),
        easyClose = TRUE
      ))
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
      session$onFlushed(function() {
        updateSelectizeInput(
          session, "move_row_target",
          choices = stable_name_choices(move_row_names),
          selected = move_row_names[1], server = TRUE
        )
        updateSelectizeInput(
          session, "move_col_target",
          choices = stable_name_choices(names(df)),
          selected = selected, server = TRUE
        )
      }, once = TRUE)
    })

    observeEvent(input$replace_na_confirm, {
      axis <- input$move_axis %||% "row"
      move_target <- if (identical(axis, "row")) input$move_row_target else input$move_col_target
      move_target <- move_target %||% input$move_target %||% ""
      if (!nzchar(move_target) || is.null(input$move_position)) {
        showNotification("Please select a moving target and fill in the target location.", type = "error")
        return()
      }
      if (!ensure_editable_table("Move row")) return()
      if (!advanced_modal_is_current("Move row")) return()

      df <- current_df()
      pos <- suppressWarnings(as.integer(input$move_position))
      if (is.na(pos) || pos < 1) pos <- 1

      if (axis == "row") {
        row_idx <- match(move_target, rownames(df))
        if (is.na(row_idx)) {
          showNotification("Please select a valid row.", type = "error")
          return()
        }
        remaining <- setdiff(seq_len(nrow(df)), row_idx)
        pos <- min(pos, length(remaining) + 1)
        order_idx <- append(remaining, row_idx, after = pos - 1)
        df2 <- df[order_idx, , drop = FALSE]
        update_df(df2, "Move row and column position", sprintf("Move row=%s, to position=%s", row_idx, pos))
      } else {
        col_name <- move_target
        if (!col_name %in% names(df)) {
          showNotification("Please select a valid column.", type = "error")
          return()
        }
        col_idx <- match(col_name, names(df))
        remaining <- setdiff(seq_len(ncol(df)), col_idx)
        pos <- min(pos, length(remaining) + 1)
        order_idx <- append(remaining, col_idx, after = pos - 1)
        df2 <- df[, order_idx, drop = FALSE]
        update_df(df2, "Move row and column position", sprintf("Move column=%s, to position=%s", col_name, pos))
      }

      hot_render_token(isolate(hot_render_token()) + 1)
      preview_render_token(isolate(preview_render_token()) + 1)
      showNotification("Move completed.", type = "message")
      removeModal()
    })

    # ------------------------------
    # Insert column names as a row / row names as a column
    # ------------------------------

    observeEvent(input$insert_names_open, {
      if (!ensure_displayed_table_current("Row and column name insertion")) return()
      req(current_df())
      capture_advanced_modal_context(current_df())
      showModal(modalDialog(
        title = "Row and column name insertion",
        radioButtons(
          session$ns("insert_names_mode"),
          "Insertion method",
          choices = c(
            "Insert the current column name as a new row" = "columns_as_row",
            "Insert current row name as new column" = "rows_as_column"
          ),
          selected = "columns_as_row"
        ),
        numericInput(
          session$ns("insert_names_position"),
          "insert position",
          value = 1, min = 1, step = 1
        ),
        conditionalPanel(
          condition = sprintf("input['%s'] == 'columns_as_row'", session$ns("insert_names_mode")),
          textInput(session$ns("insert_names_row_name"), "New line name", value = "column_names")
        ),
        conditionalPanel(
          condition = sprintf("input['%s'] == 'rows_as_column'", session$ns("insert_names_mode")),
          textInput(session$ns("insert_names_col_name"), "New column name", value = "row_names")
        ),
        tags$div(
          class = "small-muted",
          "After insertion, the original rows or columns will be moved back in sequence; if the names are repeated, a unique name will be automatically generated."
        ),
        footer = tagList(
          modalButton("Cancel"),
          actionButton(session$ns("insert_names_confirm"), "Confirm insertion", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)
        ),
        easyClose = TRUE
      ))
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
    })

    observeEvent(input$insert_names_confirm, {
      if (!advanced_modal_is_current("Row and column name insertion")) return()
      if (!ensure_editable_table("Insert row and column names")) return()
      mode <- input$insert_names_mode %||% ""
      position <- suppressWarnings(as.integer(input$insert_names_position %||% NA_integer_))
      if (!mode %in% c("columns_as_row", "rows_as_column")) {
        showNotification("Please select a valid insertion method.", type = "error")
        return()
      }
      if (is.na(position) || position < 1L) {
        showNotification("The insertion position must be an integer not less than 1.", type = "error")
        return()
      }

      df <- current_df()
      result <- tryCatch({
        if (identical(mode, "columns_as_row")) {
          row_name <- trimws(input$insert_names_row_name %||% "")
          if (!nzchar(row_name)) row_name <- "column_names"
          insert_column_names_at_row(df, position, row_name)
        } else {
          col_name <- trimws(input$insert_names_col_name %||% "")
          if (!nzchar(col_name)) col_name <- "row_names"
          insert_row_names_at_column(df, position, col_name)
        }
      }, error = function(error) error)
      if (inherits(result, "error")) {
        showNotification(
          paste0("Column name insertion failed:", conditionMessage(result)),
          type = "error", duration = 8
        )
        return()
      }

      detail <- if (identical(mode, "columns_as_row")) {
        sprintf("Column names inserted as row %s", min(position, nrow(df) + 1L))
      } else {
        sprintf("Row name inserted as column %s", min(position, ncol(df) + 1L))
      }
      update_df(result, "Row and column name insertion", detail)
      showNotification("Row and column name insertion completed.", type = "message")
      removeModal()
    })

    # ------------------------------
    # Find cells (Excel-style search)
    # ------------------------------
    observeEvent(input$find_open, {
      if (!ensure_displayed_table_current("Find")) return()
      df <- current_df()
      capture_advanced_modal_context(df)
      table_find_result(NULL)
      showModal(modalDialog(
        title = "Find and Replace",
        radioButtons(
          session$ns("find_action"), "Operation",
          choices = c("Find" = "find", "Replace" = "replace"),
          selected = "find", inline = TRUE
        ),
        textInput(session$ns("find_query"), "Find content", value = "",
                  placeholder = "Enter the text or value you want to find"),
        checkboxInput(session$ns("find_empty"), "Find null values (NA and empty strings)", FALSE),
        conditionalPanel(
          condition = "input.find_action == 'replace'",
          radioButtons(
            session$ns("find_replacement_mode"), "replaced by",
            choices = c("Specify content" = "text", "empty string" = "empty", "NA null value" = "na"),
            selected = "text", inline = TRUE
          ),
          conditionalPanel(
            condition = "input.find_replacement_mode == 'text'",
            textInput(session$ns("find_replacement"), "Replace content", value = ""),
            ns = session$ns
          ),
          ns = session$ns
        ),
        radioButtons(
          session$ns("find_scope"), "Search range",
          choices = c("Full table search" = "all", "Search by column" = "columns", "Search by row" = "rows"),
          selected = "all", inline = TRUE
        ),
        conditionalPanel(
          condition = "input.find_scope == 'columns'",
          shinyWidgets::pickerInput(
            session$ns("find_columns"), "Select lookup column",
            choices = stable_name_choices(names(df)), selected = names(df)[1],
            multiple = TRUE,
            options = list(`actions-box` = TRUE, `live-search` = TRUE,
                           `selected-text-format` = "count > 3")
          ),
          ns = session$ns
        ),
        conditionalPanel(
          condition = "input.find_scope == 'rows'",
          fluidRow(
            column(6, numericInput(session$ns("find_row_from"), "start line", 1, min = 1, max = nrow(df))),
            column(6, numericInput(session$ns("find_row_to"), "end line", nrow(df), min = 1, max = nrow(df)))
          ),
          ns = session$ns
        ),
        tags$hr(),
        checkboxInput(session$ns("find_match_case"), "Case sensitive", FALSE),
        checkboxInput(session$ns("find_whole_cell"), "matches the entire cell content", FALSE),
        checkboxInput(session$ns("find_use_regex"), "Using regular expressions (advanced)", FALSE),
        tags$div(
          class = "small-muted",
          "By default, Excel's \"Find All\" rule is used for case-insensitive inclusion matching; NA and empty strings are matched after \"Find Null Values\" is checked."
        ),
        footer = tagList(
          modalButton("Cancel"),
          actionButton(session$ns("find_confirm"), "Execute", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)
        ),
        easyClose = TRUE,
        size = "l"
      ))
      jqui_draggable(".modal-dialog", options = list(
        handle = ".modal-header",
        cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
      ))
    })

    observeEvent(input$find_confirm, {
      if (!advanced_modal_is_current("Find")) return()
      result <- tryCatch(
        dava_find_table_cells(
          current_df(), input$find_query,
          scope = input$find_scope %||% "all",
          columns = input$find_columns,
          row_from = input$find_row_from,
          row_to = input$find_row_to,
          match_case = isTRUE(input$find_match_case),
          whole_cell = isTRUE(input$find_whole_cell),
          use_regex = isTRUE(input$find_use_regex),
          find_empty = isTRUE(input$find_empty)
        ),
        error = function(error) error
      )
      if (inherits(result, "error")) {
        showNotification(conditionMessage(result), type = "error", duration = 7)
        return()
      }
      action_mode <- input$find_action %||% "find"
      if (identical(action_mode, "replace") && result$matched > 0L) {
        if (!ensure_editable_table("Perform find and replace")) return()
        replacement_mode <- input$find_replacement_mode %||% "text"
        replacement <- switch(
          replacement_mode,
          na = NA_character_,
          empty = "",
          input$find_replacement %||% ""
        )
        updated <- current_df()
        for (column_index in unique(result$details$column_index)) {
          rows <- result$details$row_index[result$details$column_index == column_index]
          if (!identical(replacement_mode, "na") && !is.character(updated[[column_index]])) {
            updated[[column_index]] <- as.character(updated[[column_index]])
          }
          updated[[column_index]][rows] <- if (identical(replacement_mode, "na")) NA else replacement
        }
        replacement_label <- if (identical(replacement_mode, "na")) "<NA>" else if (
          identical(replacement_mode, "empty")) "<empty string>" else replacement
        result$details$replacement <- replacement_label
        result$replacement <- replacement_label
        result$action <- "replace"
        update_df(
          updated, "Find and Replace",
          sprintf("Find=%s;Replace with=%s;Replace %s cells",
                  result$query, replacement_label, result$matched)
        )
      } else {
        result$action <- action_mode
        if (identical(action_mode, "replace")) {
          replacement_mode <- input$find_replacement_mode %||% "text"
          result$replacement <- switch(
            replacement_mode,
            na = "<NA>", empty = "<empty string>", input$find_replacement %||% ""
          )
        }
      }
      table_find_result(result)
      match_rate <- if (result$searched) 100 * result$matched / result$searched else 0
      showModal(modalDialog(
        title = "Search results",
        tags$div(
          class = "mb-3",
          tags$strong(sprintf("Looking for: %s%s", result$query,
            if (identical(result$action, "replace")) paste0(";replace with:", result$replacement) else ""))
        ),
        fluidRow(
          column(4, tags$div(class = "stat-box", tags$strong(result$matched), tags$div("Match cells"))),
          column(4, tags$div(class = "stat-box", tags$strong(result$unmatched), tags$div("does not match cells"))),
          column(4, tags$div(class = "stat-box", tags$strong(result$searched), tags$div("Cell found")))
        ),
        tags$hr(),
        tags$p(sprintf(
          "%s rate %.2f%%; involving %s rows and %s columns.",
          if (identical(result$action, "replace")) "Replace" else "match",
          match_rate, result$matched_rows, result$matched_columns
        )),
        footer = tagList(
          modalButton("Close"),
          actionButton(session$ns("find_show_details"), "View details", class = "btn-primary")
        ),
        easyClose = TRUE
      ))
    })

    observeEvent(input$find_show_details, {
      result <- table_find_result()
      req(result)
      details <- result$details
      names(details) <- if ("replacement" %in% names(details)) {
        c("line number", "row name", "Serial number", "Listing", "Original match value", "replaced by")
      } else {
        c("line number", "row name", "Serial number", "Listing", "match value")
      }
      output$find_details_table <- renderDT({
        datatable(
          details, rownames = FALSE, filter = "top",
          options = list(pageLength = 20, scrollX = TRUE,
                         language = list(emptyTable = "No matching cells"))
        )
      })
      showModal(modalDialog(
        title = sprintf("Find details (%s matches)", result$matched),
        DTOutput(session$ns("find_details_table")),
        footer = modalButton("Close"),
        easyClose = TRUE,
        size = "l"
      ))
    })

    # --------delete col----------


    # --------delete col----------
    observeEvent(input$delete_col_open, {
      req(input$selected_col)
      
      df <- current_df()
      if (ncol(df) <= 1) {
        showNotification("Keep at least one column.", type = "error")
        return()
      }
      
      col <- input$selected_col
      df2 <- df[, setdiff(names(df), col), drop = FALSE]
      update_df(df2, "Delete column", col)
    })
    
    #-------add col---------
    observeEvent(input$add_col_open, {
      if (!ensure_displayed_table_current("Insert column")) return()
      req(current_df())
      df <- current_df()
      capture_advanced_modal_context(df)
      
      showModal(
        modalDialog(
          title = "Insert column",
          
          radioButtons(
            session$ns("add_col_type"), label = "Select type",
            choices = c("Convert row names to columns", "Copy column to specified location", "Custom fill columns"),
            selected = "Convert row names to columns"
          ),
          
          hr(),
          conditionalPanel(
            condition = "input.add_col_type == 'Convert row names to columns'",
            textInput(session$ns("rownames_col_name"), "New column name", value = "rowname"),
            numericInput(session$ns("rownames_col_pos"), "insert position", value = 1, min = 1, step = 1),
            ns = session$ns
          ),
          conditionalPanel(
            condition = "input.add_col_type == 'Copy column to specified location'",
            selectInput(
              session$ns("copy_source_col"), "Source column",
              choices = stable_name_choices(names(df)), selected = names(df)[1]
            ),
            textInput(session$ns("copy_new_col"), "New column name", value = paste0(names(df)[1], "_copy")),
            numericInput(session$ns("copy_col_pos"), "insert position", value = ncol(df) + 1, min = 1, step = 1),
            ns = session$ns
          ),
          conditionalPanel(
            condition = "input.add_col_type == 'Custom filled column'",
            textInput(session$ns("custom_col_name"), "New column name", value = "custom_col"),
            selectInput(
              session$ns("custom_col_type"), "column type",
              choices = c("character", "numeric", "integer", "logical", "date"), selected = "character"
            ),
            textInput(session$ns("custom_col_value"), "fill value", value = ""),
            numericInput(session$ns("custom_col_pos"), "insert position", value = ncol(df) + 1, min = 1, step = 1),
            ns = session$ns
          ),
          
          footer = tagList(
            modalButton("Cancel"),
            actionButton(session$ns("add_col_confirm"), "Confirm insertion", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)
          ),
          easyClose = TRUE
        )
      )
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
    })
    
    observeEvent(input$add_col_confirm, {
      req(input$add_col_type)
      if (!advanced_modal_is_current("Insert column")) return()
      
      df <- current_df()
      req(df)
      
      if (input$add_col_type == "Convert row names to columns") {
        req(input$rownames_col_name, input$rownames_col_pos)
        
        df <- current_df()
        rn <- rownames(df)
        if (is.null(rn) || identical(rn, as.character(seq_len(nrow(df))))) rn <- as.character(seq_len(nrow(df)))
        out <- tryCatch(insert_column_at(df, input$rownames_col_name, rn, input$rownames_col_pos), error = function(e) e)
        if (inherits(out, "error")) { showNotification(out$message, type = "error"); return() }
        update_df(out, "Convert row name to column", sprintf("new column=%s; position=%s", input$rownames_col_name, input$rownames_col_pos))
        
      } else if (input$add_col_type == "Copy column to specified location") {
        req(input$copy_source_col, input$copy_new_col, input$copy_col_pos)
        
        df <- current_df()
        out <- tryCatch(insert_column_at(df, input$copy_new_col, df[[input$copy_source_col]], input$copy_col_pos), error = function(e) e)
        if (inherits(out, "error")) { showNotification(out$message, type = "error"); return() }
        update_df(out, "Copy column", sprintf("%s -> %s; position=%s", input$copy_source_col, input$copy_new_col, input$copy_col_pos))
        
      } else if (input$add_col_type == "Custom fill columns") {
        req(input$custom_col_name, input$custom_col_type, input$custom_col_value, input$custom_col_pos)
        
        df <- current_df()
        val <- coerce_column(input$custom_col_value %||% "", input$custom_col_type %||% "character")
        out <- tryCatch(insert_column_at(df, input$custom_col_name, val, input$custom_col_pos), error = function(e) e)
        if (inherits(out, "error")) { showNotification(out$message, type = "error"); return() }
        update_df(out, "Custom fill columns", sprintf("new column=%s; type=%s; position=%s", input$custom_col_name, input$custom_col_type, input$custom_col_pos))
      }
      
      showNotification(
        sprintf("Row name renaming completed, %s rows have been renamed.", nrow(out)),
        type = "message"
      )
      
      removeModal()
    })
    
    
    
    #-----subset col---------
    observeEvent(input$select_col_open, {
      if (!ensure_displayed_table_current("Filter/keep columns")) return()
      req(current_df())
      capture_advanced_modal_context(current_df())
      df <- current_df()
      
      showModal(
        modalDialog(
          title = "Filter / Keep",
          radioButtons(
            session$ns("subset_mode"),
            "Operation type",
            choices = c("Keep specified columns" = "columns", "Filter rows by column value" = "rows"),
            selected = "columns",
            inline = TRUE
          ),
          tags$hr(),
          pickerInput(
            inputId = session$ns("subset_col"),
            label = "Reserved column fields",
            choices = stable_name_choices(names(df)),
            selected = names(df),
            multiple = TRUE,
            options = list(
              `live-search` = TRUE, # Start search
              `actions-box` = TRUE, # Turn onSelect all/Invert button
              `selected-text-format` = "count > 3" # Selected more than3Display quantity per hour in
            )
          ),
          tags$hr(),
          selectInput(
            session$ns("subset_filter_col"),
            "Filter fields",
            choices = stable_name_choices(names(df)),
            selected = input$selected_col %||% names(df)[1]
          ),
          textInput(session$ns("subset_filter_value"), "Keep rows equal to this value", value = ""),
          checkboxInput(session$ns("subset_filter_keep_na"), "Keep NA/null rows when value is null", value = TRUE),
          footer = tagList(
            modalButton("Cancel"),
            actionButton(session$ns("subset_col_confirm"), "Confirm execution", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)
          ),
          easyClose = TRUE
        )
      )
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
    })
    
    observeEvent(input$subset_col_confirm, {
      if (!advanced_modal_is_current("Filter/keep columns")) return()
      if (!nzchar(input$subset_mode %||% "")) {
        showNotification("Please select a filter operation type.", type = "error")
        return()
      }
      if (!ensure_editable_table("Filter data")) return()
      df <- current_df()
      req(df)
      if (identical(input$subset_mode, "rows")) {
        if (!nzchar(input$subset_filter_col %||% "")) {
          showNotification("Please select a filter field.", type = "error")
          return()
        }
        col_name <- input$subset_filter_col
        val <- input$subset_filter_value %||% ""
        col <- df[[col_name]]
        if (identical(val, "") && isTRUE(input$subset_filter_keep_na)) {
          keep <- is.na(col) | trimws(as.character(col)) == ""
        } else {
          keep <- as.character(col) == val
          keep[is.na(keep)] <- FALSE
        }
        df2 <- df[keep, , drop = FALSE]
        update_df(df2, "Filter rows by value", sprintf("%s == %s; keep %s line", col_name, val, nrow(df2)))
        showNotification(sprintf("Filtering by value completed, retaining %s rows.", nrow(df2)), type = "message")
      } else {
        select_colname <- intersect(input$subset_col %||% character(0), names(df))
        if (!length(select_colname)) {
          showNotification("Please keep at least one column.", type = "error")
          return()
        }
        df2 <- df[select_colname]
        update_df(df2, "Filter columns", sprintf("Select %s column", length(select_colname)))
        showNotification("Filtering columns completed.", type = "message")
      }
      removeModal()
    })
    
    #-----------split col--------
    observeEvent(input$split_open, {
      if (!ensure_displayed_table_current("sort")) return()
      req(current_df())
      capture_advanced_modal_context(current_df())
      df <- current_df()
      cols <- names(df)
      req(length(cols) > 0)
      selected_col <- input$selected_col %||% cols[1]
      if (!selected_col %in% cols) selected_col <- cols[1]
      
      showModal(
        modalDialog(
          title = "sort",
          selectInput(
            session$ns("split_col"),
            "Fields that need to be sorted",
            choices = stable_name_choices(cols),
            selected = selected_col
          ),
          textInput(session$ns("split_sep"), "delimiter", value = "_"),
          numericInput(session$ns("split_into_n"), "Maximum number of columns to split", value = 2, min = 2, step = 1),
          textInput(session$ns("split_prefix"), "New column name prefix", value = paste0(selected_col, "_")),
          checkboxInput(session$ns("split_remove_original"), "Delete original field", value = FALSE),
          footer = tagList(
            modalButton("Cancel"),
            actionButton(session$ns("split_confirm"), "Confirm split", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)
          ),
          easyClose = TRUE
        )
      )
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
    })
    
    observeEvent(input$split_confirm, {
      if (!advanced_modal_is_current("sort")) return()
      params <- list(
        col_name = input$split_col %||% "",
        sep = input$split_sep %||% "",
        n_into = input$split_into_n %||% NA_integer_,
        prefix = input$split_prefix %||% "",
        remove_original = isTRUE(input$split_remove_original)
      )
      editable_datasets <- isolate(rv$global_datasets %||% list())
      active_dataset <- isolate(rv$active_dataset %||% "")
      if (isTRUE(isolate(rv$readOnly)) || !nzchar(active_dataset) ||
          is.null(editable_datasets[[active_dataset]])) {
        showNotification("The original data set is read-only. Please save it as a new data set before sorting.", type = "warning", duration = NULL)
        return()
      }

      result <- tryCatch({
        split_df <- dava_split_column(
          current_df(), params$col_name, params$sep, params$n_into,
          params$prefix, params$remove_original
        )
        update_df(
          split_df, "sort",
          sprintf("field=%s, separator=%s", params$col_name, params$sep)
        )
        TRUE
      }, error = function(error) {
        showNotification(
          paste0("Column separation failed:", conditionMessage(error)),
          type = "error", duration = NULL
        )
        FALSE
      })
      if (!isTRUE(result)) return()

      removeModal()
      showNotification("Completed in columns.", type = "message")
    }, ignoreInit = TRUE)
    
    #----merge col------
    observeEvent(input$merge_open, {
      if (!ensure_displayed_table_current("Merge columns")) return()
      req(current_df())
      capture_advanced_modal_context(current_df())
      
      showModal(
        modalDialog(
          title = "Merge columns",
          pickerInput(
            session$ns("merge_cols"),
            "Select the fields to be merged",
            choices = stable_name_choices(names(current_df())),
            selected = input$selected_col,
            multiple = TRUE,
            options = list(`actions-box` = TRUE, `live-search` = TRUE)
          ),
          textInput(session$ns("merge_sep"), "connector", value = "_"),
          textInput(session$ns("merge_new_col"), "New column name", value = "merged_col"),
          checkboxInput(session$ns("merge_remove_original"), "Delete original field", value = FALSE),
          footer = tagList(
            modalButton("Cancel"),
            actionButton(session$ns("merge_confirm"), "Confirm merge", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)
          ),
          easyClose = TRUE
        )
      )
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
    })
    
    observeEvent(input$merge_confirm, {
      if (!advanced_modal_is_current("Merge columns")) return()
      if (!ensure_editable_table("Merge columns")) return()
      df <- current_df()
      cols <- input$merge_cols %||% character(0)
      cols <- cols[cols %in% names(df)]
      
      if (length(cols) < 2) {
        showNotification("Select at least 2 fields.", type = "error")
        return()
      }
      new_col <- trimws(input$merge_new_col %||% "")
      if (!nzchar(new_col)) {
        showNotification("New column name cannot be empty.", type = "error")
        return()
      }
      sep <- input$merge_sep %||% ""
      df[[new_col]] <- apply(
        df[, cols, drop = FALSE],
        1,
        function(z) paste(as.character(z), collapse = sep)
      )
      if (isTRUE(input$merge_remove_original)) {
        df[, cols] <- NULL
      }
      names(df) <- make_unique_names(names(df))
      update_df(df, "Merge columns", sprintf("%s -> %s", paste(cols, collapse = ","), new_col))

      showNotification("Merging columns completed.", type = "message")
      removeModal()
    })
    
    #----formula col-----
    observeEvent(input$formula_open, {
      if (!ensure_displayed_table_current("Formula column")) return()
      req(current_df())
      capture_advanced_modal_context(current_df())
      
      showModal(modalDialog(
        title = "Formula column",
        textInput(session$ns("formula_col"), "New column name", value = "new_col"),
        textAreaInput(
          session$ns("formula_expr"),
          "R expression",
          value = "",
          placeholder = "Example：height * weight\nExample：ifelse(group == 'A', 1, 0)\nExample：paste(site, treatment, sep = '_')",
          height = "140px"
        ),
        tags$div(
          class = "small-muted",
          "Note: Column names can be quoted directly. Use backticks when column names contain spaces, for example `Sepal Length` + 1."
        ),
        footer = tagList(
          modalButton("Cancel"),
          actionButton(session$ns("formula_confirm"), "Confirm", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)
        ),
        easyClose = TRUE,
        size = "l"
      ))
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
    })
    
    observeEvent(input$formula_confirm, {
      if (!advanced_modal_is_current("Formula column")) return()
      if (!ensure_editable_table("Create formula column")) return()
      df <- current_df()
      new_col <- trimws(input$formula_col %||% "")
      expr_txt <- trimws(input$formula_expr %||% "")
      
      if (new_col == "" || expr_txt == "") {
        showNotification("New column name and expression cannot be empty.", type = "error")
        return()
      }
      res <- tryCatch({
        expr <- rlang::parse_expr(expr_txt)
        dplyr::mutate(df, "{new_col}" := eval(expr))
      }, error = function(e) e)
      
      if (inherits(res, "error")) {
        showNotification(paste("Formula execution failed:", res$message), type = "error", duration = 8)
        return()
      }
      update_df(res, "Formula column", sprintf("%s = %s", new_col, expr_txt))
      showNotification("The formula column is created.", type = "message")
      removeModal()
    })
    
    #----fill col-----
    observeEvent(input$fill_open, {
      if (!ensure_displayed_table_current("Bulk filling")) return()
      req(current_df())
      capture_advanced_modal_context(current_df())
      
      showModal(modalDialog(
        title = "Cell batch filling",
        selectInput(session$ns("fill_col"), "Populate fields", choices = stable_name_choices(names(current_df())), selected = input$selected_col),
        numericInput(session$ns("fill_from"), "start line", value = 1, min = 1, step = 1),
        numericInput(session$ns("fill_to"), "end line", value = min(10, nrow(current_df())), min = 1, step = 1),
        selectInput(
          session$ns("fill_mode"),
          "Filling method",
          choices = c("Fixed value" = "constant", "Serial number" = "sequence", "Fill down with the previous non-null value" = "down")
        ),
        textInput(session$ns("fill_value"), "Fixed value/sequence starting value", value = ""),
        numericInput(session$ns("fill_step"), "sequence step size", value = 1),
        footer = tagList(
          modalButton("Cancel"),
          actionButton(session$ns("fill_confirm"), "Confirm", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)
        ),
        easyClose = TRUE
      ))
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
    })
    
    observeEvent(input$fill_confirm, {
      if (!advanced_modal_is_current("Bulk filling")) return()
      if (!ensure_editable_table("Bulk filling")) return()
      df <- current_df()
      col <- input$fill_col %||% ""
      if (!col %in% names(df)) {
        showNotification("Please select a valid fill field.", type = "error")
        return()
      }
      i1 <- as.integer(input$fill_from)
      i2 <- as.integer(input$fill_to)
      
      if (is.na(i1) || is.na(i2) || i1 < 1 || i2 < i1 || i1 > nrow(df)) {
        showNotification("Invalid padding range.", type = "error")
        return()
      }
      
      i2 <- min(i2, nrow(df))
      rows <- seq(i1, i2)
      
      if (input$fill_mode == "constant") {
        val <- input$fill_value
        if (is.numeric(df[[col]])) val <- suppressWarnings(as.numeric(val))
        if (is.integer(df[[col]])) val <- suppressWarnings(as.integer(val))
        if (inherits(df[[col]], "Date")) val <- suppressWarnings(as.Date(val))
        df[[col]][rows] <- val
      }
      
      if (input$fill_mode == "sequence") {
        start <- suppressWarnings(as.numeric(input$fill_value))
        step <- suppressWarnings(as.numeric(input$fill_step))
        if (is.na(start)) start <- 1
        if (is.na(step)) step <- 1
        df[[col]][rows] <- start + (seq_along(rows) - 1) * step
      }
      
      if (input$fill_mode == "down") {
        x <- df[[col]]
        for (i in rows) {
          if (i > 1 && (is.na(x[i]) || (is.character(x) && trimws(x[i]) == ""))) {
            x[i] <- x[i - 1]
          }
        }
        df[[col]] <- x
      }
      
      update_df(df, "Bulk filling", sprintf("%s row %s-%s", col, i1, i2))
      showNotification("Batch filling completed.", type = "message")
      removeModal()
    })
    
    #----replace col-----
    observeEvent(input$replace_open, {
      if (!ensure_displayed_table_current("Batch replacement")) return()
      req(current_df())
      capture_advanced_modal_context(current_df())
      
      showModal(modalDialog(
        title = "Batch replacement",
        selectInput(session$ns("replace_col"), "field", choices = stable_name_choices(names(current_df())), selected = input$selected_col),
        textInput(session$ns("find_value"), "Find value", value = ""),
        textInput(session$ns("replace_value"), "replaced by", value = ""),
        checkboxInput(session$ns("replace_exact"), "Exactly match the entire cell", TRUE),
        footer = tagList(
          modalButton("Cancel"),
          actionButton(session$ns("replace_confirm"), "Confirm", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)
        ),
        easyClose = TRUE
      ))
      jqui_draggable(
        ".modal-dialog",
        options = list(
          handle = ".modal-header",
          cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"
        )
      )
    })
    
    observeEvent(input$replace_confirm, {
      if (!advanced_modal_is_current("Batch replacement")) return()
      if (!ensure_editable_table("Batch replacement")) return()
      df <- current_df()
      col <- input$replace_col %||% ""
      if (!col %in% names(df)) {
        showNotification("Please select a valid replacement field.", type = "error")
        return()
      }
      
      x <- as.character(df[[col]])
      find <- input$find_value %||% ""
      repl <- input$replace_value %||% ""
      
      if (isTRUE(input$replace_exact)) {
        x[x == find] <- repl
      } else {
        x <- gsub(find, repl, x, fixed = TRUE)
      }
      
      df[[col]] <- x
      
      update_df(df, "Batch replacement", sprintf("%s: %s -> %s", col, find, repl))
      showNotification("Batch replacement completed.", type = "message")
      removeModal()
    })
    
 
#------------------
#---data setOperation-----
#------------------
    
    dataset_names <- reactive({
      names(rv$global_datasets)
    })
    
    get_dataset <- function(name) {
      name <- name %||% ""
      if (name == "" || is.null(rv$global_datasets[[name]])) {
        stop(sprintf("Data set does not exist: %s", name), call. = FALSE)
      }
      as.data.frame(rv$global_datasets[[name]], stringsAsFactors = FALSE, check.names = FALSE)
    }
    
    make_result_name <- function(name) {
      name <- trimws(name %||% "")
      if (name == "") name <- "result_dataset"
      name <- safe_sheet_name(name)
      make_unique_names(c(names(rv$global_datasets), name))[length(rv$global_datasets) + 1]
    }
    
    save_result_dataset <- function(df, name, action, detail = "") {
      result_name <- make_result_name(name)
      register_global_dataset(result_name, df, source = "Table editing results", activate = TRUE, sync = FALSE)
      clear_edit_history()
      skip_global_dataset_select(result_name)
      update_global_dataset_input(selected = result_name)
      log_event(action, sprintf("%s; result data set = %s", detail %||% "", result_name))
      showNotification(sprintf("%s completed, the result has been saved as: %s", action, result_name), type = "message", duration = 5)
      invisible(result_name)
    }

    summarise_dataset_fast <- function(df, group_cols, value_cols, funs) {
      dt <- data.table::as.data.table(df)
      if (!length(value_cols)) {
        out <- if (length(group_cols)) dt[, .(n = .N), by = group_cols] else dt[, .(n = .N)]
        out <- as.data.frame(out, stringsAsFactors = FALSE, check.names = FALSE)
        rownames(out) <- NULL
        return(out)
      }

      item_col <- make_unique_names(c(group_cols, "Item"))[length(group_cols) + 1]
      value_col <- ".dava_summary_value"
      dt <- data.table::melt(
        dt,
        id.vars = group_cols,
        measure.vars = value_cols,
        variable.name = item_col,
        value.name = value_col,
        variable.factor = FALSE
      )

      exprs <- list()
      for (fun in funs) {
        exprs[[fun]] <- switch(
          fun,
          mean = quote(if (all(is.na(.dava_summary_value))) NA_real_ else mean(.dava_summary_value, na.rm = TRUE)),
          n = quote(sum(!is.na(.dava_summary_value))),
          sd = quote(if (sum(!is.na(.dava_summary_value)) < 2) NA_real_ else stats::sd(.dava_summary_value, na.rm = TRUE)),
          se = quote({
            n_valid <- sum(!is.na(.dava_summary_value))
            if (n_valid < 2) NA_real_ else stats::sd(.dava_summary_value, na.rm = TRUE) / sqrt(n_valid)
          }),
          lower_CI95 = quote({
            n_valid <- sum(!is.na(.dava_summary_value))
            if (n_valid < 2) NA_real_ else {
              avg <- mean(.dava_summary_value, na.rm = TRUE)
              se_value <- stats::sd(.dava_summary_value, na.rm = TRUE) / sqrt(n_valid)
              avg - stats::qt(0.975, df = n_valid - 1) * se_value
            }
          }),
          upper_CI95 = quote({
            n_valid <- sum(!is.na(.dava_summary_value))
            if (n_valid < 2) NA_real_ else {
              avg <- mean(.dava_summary_value, na.rm = TRUE)
              se_value <- stats::sd(.dava_summary_value, na.rm = TRUE) / sqrt(n_valid)
              avg + stats::qt(0.975, df = n_valid - 1) * se_value
            }
          }),
          sum = quote(sum(.dava_summary_value, na.rm = TRUE)),
          min = quote(if (all(is.na(.dava_summary_value))) NA_real_ else min(.dava_summary_value, na.rm = TRUE)),
          max = quote(if (all(is.na(.dava_summary_value))) NA_real_ else max(.dava_summary_value, na.rm = TRUE)),
          median = quote(if (all(is.na(.dava_summary_value))) NA_real_ else stats::median(.dava_summary_value, na.rm = TRUE)),
          NULL
        )
      }
      exprs <- Filter(Negate(is.null), exprs)
      j <- as.call(c(quote(list), exprs))
      summary_groups <- c(group_cols, item_col)
      out <- dt[, eval(j), by = summary_groups]
      out <- as.data.frame(out, stringsAsFactors = FALSE, check.names = FALSE)
      rownames(out) <- NULL
      out
    }

    transpose_df <- function(df, mode = c("normal", "keep_col_as_first", "keep_row_as_first"), col_field = "Col_Field", row_field = "Row_Field") {
      mode <- match.arg(mode)
      df <- as.data.frame(df, stringsAsFactors = FALSE, check.names = FALSE)
      if (nrow(df) == 0 || ncol(df) == 0) {
        stop("The current table is empty and cannot be transposed.", call. = FALSE)
      }

      rn <- rownames(df)
      if (is.null(rn) || any(!nzchar(rn))) rn <- paste0("Row", seq_len(nrow(df)))
      cn <- names(df)
      if (is.null(cn) || any(!nzchar(cn))) cn <- paste0("Col", seq_len(ncol(df)))

      out <- as.data.frame(t(as.matrix(df)), stringsAsFactors = FALSE, check.names = FALSE)
      out[] <- lapply(out, as.character)

      if (mode == "normal") {
        rownames(out) <- cn
        names(out) <- rn
        return(normalize_df_keep_rownames(out))
      }

      if (mode == "keep_col_as_first") {
        out <- cbind(setNames(data.frame(cn, stringsAsFactors = FALSE, check.names = FALSE), col_field), out)
        names(out) <- c(col_field, rn)
        rownames(out) <- NULL
        return(normalize_df_keep_rownames(out))
      }

      if (mode == "keep_row_as_first") {
        header <- as.data.frame(as.list(c(row_field, rn)), stringsAsFactors = FALSE, check.names = FALSE)
        names(header) <- c(row_field, rn)
        body <- data.frame(cn, out, stringsAsFactors = FALSE, check.names = FALSE)
        names(body) <- c(row_field, rn)
        out <- rbind(header, body)
        rownames(out) <- NULL
        return(normalize_df_keep_rownames(out))
      }

      normalize_df_keep_rownames(out)
    }

    transpose_selection_in_place <- function(df, rows, cols) {
      rows <- rows[rows >= 1L & rows <= nrow(df)]
      col_pos <- match(cols, names(df))
      col_pos <- col_pos[!is.na(col_pos)]
      if (!length(rows) || !length(col_pos)) {
        stop("No selected cells to transpose.", call. = FALSE)
      }

      selected <- df[rows, col_pos, drop = FALSE]
      values <- t(as.matrix(selected))
      start_row <- min(rows)
      start_col <- min(col_pos)
      target_rows <- seq.int(start_row, length.out = nrow(values))
      target_cols <- seq.int(start_col, length.out = ncol(values))

      df <- extend_df_for_paste(df, max(target_rows), max(target_cols))
      df[rows, col_pos] <- NA_character_
      for (j in seq_along(target_cols)) {
        idx <- target_cols[[j]]
        assigned <- tryCatch({
          df[target_rows, idx] <- values[, j]
          TRUE
        }, error = function(e) FALSE)
        if (!isTRUE(assigned)) {
          df[[idx]] <- as.character(df[[idx]])
          df[target_rows, idx] <- values[, j]
        }
      }
      normalize_df_keep_rownames(df)
    }

    parse_cols <- function(x) {
      x <- trimws(x %||% "")
      if (x == "") return(character(0))
      z <- trimws(unlist(strsplit(x, ",", fixed = TRUE)))
      z[z != ""]
    }

    insert_column_names_at_row <- function(df, position, row_name = "column_names") {
      if (!is.data.frame(df) || ncol(df) < 1L) {
        stop("There are no insertable column names in the current table.", call. = FALSE)
      }
      position <- suppressWarnings(as.integer(position)[1])
      if (is.na(position)) position <- nrow(df) + 1L
      position <- max(1L, min(position, nrow(df) + 1L))

      original_names <- names(df)
      original_rows <- rownames(df)
      if (is.null(original_rows) || length(original_rows) != nrow(df)) {
        original_rows <- as.character(seq_len(nrow(df)))
      }
      body <- as.data.frame(
        lapply(df, as.character),
        stringsAsFactors = FALSE, check.names = FALSE
      )
      names(body) <- original_names
      header_row <- as.data.frame(
        as.list(original_names),
        stringsAsFactors = FALSE, check.names = FALSE
      )
      names(header_row) <- original_names
      top <- if (position > 1L) body[seq_len(position - 1L), , drop = FALSE] else body[0, , drop = FALSE]
      bottom <- if (position <= nrow(body)) body[position:nrow(body), , drop = FALSE] else body[0, , drop = FALSE]
      result <- rbind(top, header_row, bottom)
      inserted_name <- trimws(as.character(row_name %||% "column_names")[1])
      if (!nzchar(inserted_name)) inserted_name <- "column_names"
      rownames(result) <- make_unique_names(
        append(original_rows, inserted_name, after = position - 1L)
      )
      normalize_df_keep_rownames(result)
    }

    insert_row_names_at_column <- function(df, position, col_name = "row_names") {
      if (!is.data.frame(df)) stop("The current table is invalid.", call. = FALSE)
      row_values <- rownames(df)
      if (is.null(row_values) || length(row_values) != nrow(df)) {
        row_values <- as.character(seq_len(nrow(df)))
      }
      insert_column_at(df, col_name, as.character(row_values), position)
    }
    
    insert_column_at <- function(df, col_name, values, position = ncol(df) + 1) {
      col_name <- trimws(col_name %||% "")
      if (col_name == "") col_name <- "new_col"
      position <- suppressWarnings(as.integer(position))
      if (is.na(position)) position <- ncol(df) + 1
      position <- max(1, min(position, ncol(df) + 1))
      if (length(values) == 1) values <- rep(values, nrow(df))
      if (length(values) != nrow(df)) stop("The inserted column length must be 1 or equal to the current number of data rows.", call. = FALSE)
      left <- if (position > 1) df[, seq_len(position - 1), drop = FALSE] else df[, 0, drop = FALSE]
      right <- if (position <= ncol(df)) df[, position:ncol(df), drop = FALSE] else df[, 0, drop = FALSE]
      new_df <- dplyr::bind_cols(left, setNames(data.frame(values, check.names = FALSE), col_name), right)
      names(new_df) <- make_unique_names(names(new_df))
      normalize_df_keep_rownames(new_df)
    }
    
  # ---------Dataset join----------
    observeEvent(input$join_open, {
      req(length(dataset_names()) >= 2)
      choices <- dataset_names()
      showModal(modalDialog(
        title = "Two data sets are connected by key join",
        selectInput(session$ns("join_x"), "Left table / Main table X", choices = choices, selected = rv$active_dataset %||% choices[1]),
        selectInput(session$ns("join_y"), "Right table / matching table Y", choices = choices, selected = choices[min(2, length(choices))]),
        selectInput(session$ns("join_type"), "Connection method", choices = c("left_join" = "left", "right_join" = "right", "full_join" = "full", "inner_join" = "inner"), selected = "left"),
        textInput(session$ns("join_by"), "Join key column name", value = "", placeholder = "Multiple columns are separated by English commas; leave blank to automatically use columns with the same name."),
        textInput(session$ns("join_result_name"), "Result dataset name", value = "joined_dataset"),
        tags$div(class = "small-muted", "The join key must exist in both X and Y; when left blank, fields with the same name in both data sets will be automatically taken."),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("join_confirm"), "Confirm connection", class = "btn-primary")),
        easyClose = TRUE,
        size = "l"
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    })
    
    observeEvent(input$join_confirm, {
      if (!nzchar(input$join_x %||% "") || !nzchar(input$join_y %||% "") || !nzchar(input$join_type %||% "")) {
        showNotification("Please select the left and right data sets and connection method.", type = "error")
        return()
      }
      x <- tryCatch(get_dataset(input$join_x), error = function(e) e)
      y <- tryCatch(get_dataset(input$join_y), error = function(e) e)
      if (inherits(x, "error") || inherits(y, "error")) { showNotification("Failed to read data set.", type = "error"); return() }
      by <- parse_cols(input$join_by)
      if (length(by) == 0) by <- intersect(names(x), names(y))
      if (length(by) == 0) { showNotification("No field with the same name available for the join was found, please enter the join key column name manually.", type = "error", duration = 8); return() }
      miss_x <- setdiff(by, names(x)); miss_y <- setdiff(by, names(y))
      if (length(miss_x) > 0 || length(miss_y) > 0) {
        showNotification(sprintf("Join key does not exist: X is missing [%s]; Y is missing [%s]", paste(miss_x, collapse = ","), paste(miss_y, collapse = ",")), type = "error", duration = 8)
        return()
      }
      out <- tryCatch({
        switch(input$join_type,
               left = dplyr::left_join(x, y, by = by),
               right = dplyr::right_join(x, y, by = by),
               full = dplyr::full_join(x, y, by = by),
               inner = dplyr::inner_join(x, y, by = by)
        )
      }, error = function(e) e)
      if (inherits(out, "error")) { showNotification(paste("Connection failed:", out$message), type = "error", duration = 10); return() }
      save_result_dataset(out, input$join_result_name, "Dataset connection", sprintf("X=%s; Y=%s; type=%s; by=%s", input$join_x, input$join_y, input$join_type, paste(by, collapse = ",")))
      removeModal()
    })
    
    # --------Dataset bind rows----------
    observeEvent(input$bind_rows_open, {
      req(length(dataset_names()) >= 2)
      choices <- dataset_names()
      showModal(modalDialog(
        title = "Two data sets are appended by row bind_rows",
        selectInput(session$ns("bind_rows_x"), "Data set X", choices = choices, selected = rv$active_dataset %||% choices[1]),
        selectInput(session$ns("bind_rows_y"), "Data set Y", choices = choices, selected = choices[min(2, length(choices))]),
        textInput(session$ns("bind_rows_id"), "Source identification column name", value = ".source", placeholder = "Leave blank to not add the source identifier column"),
        textInput(session$ns("bind_rows_result_name"), "Result dataset name", value = "bind_rows_dataset"),
        tags$div(class = "small-muted", "Appending by row will automatically align columns with the same name; missing columns will be filled with NA."),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("bind_rows_confirm"), "Confirm append by line", class = "btn-primary")),
        easyClose = TRUE,
        size = "l"
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    })
    
    observeEvent(input$bind_rows_confirm, {
      if (!nzchar(input$bind_rows_x %||% "") || !nzchar(input$bind_rows_y %||% "")) {
        showNotification("Please select two data sets to append row by row.", type = "error")
        return()
      }
      x <- tryCatch(get_dataset(input$bind_rows_x), error = function(e) e)
      y <- tryCatch(get_dataset(input$bind_rows_y), error = function(e) e)
      if (inherits(x, "error") || inherits(y, "error")) {
        showNotification("Failed to read the data set to be appended.", type = "error")
        return()
      }
      id_col <- trimws(input$bind_rows_id %||% "")
      out <- tryCatch({
        if (id_col == "") dplyr::bind_rows(x, y) else dplyr::bind_rows(setNames(list(x, y), c(input$bind_rows_x, input$bind_rows_y)), .id = id_col)
      }, error = function(e) e)
      if (inherits(out, "error")) { showNotification(paste("Append by row failed:", out$message), type = "error", duration = 10); return() }
      save_result_dataset(out, input$bind_rows_result_name, "Append data set by rows", sprintf("X=%s row=%s; Y=%s row=%s", input$bind_rows_x, nrow(x), input$bind_rows_y, nrow(y)))
      removeModal()
    })
    
    # --------Dataset bind cols----------
    observeEvent(input$bind_cols_open, {
      req(length(dataset_names()) >= 2)
      choices <- dataset_names()
      showModal(modalDialog(
        title = "Merge two data sets by columns",
        selectInput(session$ns("bind_x"), "Data set X", choices = choices, selected = rv$active_dataset %||% choices[1]),
        selectInput(session$ns("bind_y"), "Data set Y", choices = choices, selected = choices[min(2, length(choices))]),
        checkboxInput(session$ns("bind_recycle"), "Use NA to pad shorter data sets when the number of rows is inconsistent", value = TRUE),
        textInput(session$ns("bind_result_name"), "Result dataset name", value = "bind_cols_dataset"),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("bind_cols_confirm"), "Confirm merge by column", class = "btn-primary")),
        easyClose = TRUE,
        size = "l"
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    })
    
    observeEvent(input$bind_cols_confirm, {
      if (!nzchar(input$bind_x %||% "") || !nzchar(input$bind_y %||% "")) {
        showNotification("Please select two data sets that need to be merged by columns.", type = "error")
        return()
      }
      x <- tryCatch(get_dataset(input$bind_x), error = function(e) e)
      y <- tryCatch(get_dataset(input$bind_y), error = function(e) e)
      if (inherits(x, "error") || inherits(y, "error")) {
        showNotification("Failed to read the data set to be merged.", type = "error")
        return()
      }
      if (nrow(x) != nrow(y)) {
        if (!isTRUE(input$bind_recycle)) { showNotification("The number of rows in the two data sets is inconsistent and cannot be directly merged by column.", type = "error"); return() }
        n <- max(nrow(x), nrow(y))
        pad_df <- function(df, n) {
          if (nrow(df) == n) return(df)
          add <- as.data.frame(matrix(NA, nrow = n - nrow(df), ncol = ncol(df)), stringsAsFactors = FALSE)
          names(add) <- names(df)
          dplyr::bind_rows(df, add)
        }
        x <- pad_df(x, n); y <- pad_df(y, n)
      }
      names(y) <- make_unique_names(c(names(x), names(y)))[(ncol(x) + 1):(ncol(x) + ncol(y))]
      out <- dplyr::bind_cols(x, y)
      save_result_dataset(out, input$bind_result_name, "Merge datasets by columns", sprintf("X=%s row=%s; Y=%s row=%s", input$bind_x, nrow(x), input$bind_y, nrow(y)))
      removeModal()
    })
    
    # ------------Dataset reshape -------------
    observeEvent(input$transpose_open, {
      if (!ensure_displayed_table_current("Table transpose")) return()
      req(current_df())
      capture_advanced_modal_context(current_df())
      showModal(modalDialog(
        title = "Table transpose",
        radioButtons(
          session$ns("transpose_mode"),
          NULL,
          choices = c(
            "Normal transpose" = "normal",
            "The original column name is used as the first column" = "keep_col_as_first",
            "Original row name as first row" = "keep_row_as_first"
          ),
          selected = "normal"
        ),
        conditionalPanel(
          condition = sprintf("input['%s'] == 'keep_col_as_first'", session$ns("transpose_mode")),
          textInput(session$ns("transpose_col_field"), "First column name", value = "Col_Field")
        ),
        conditionalPanel(
          condition = sprintf("input['%s'] == 'keep_row_as_first'", session$ns("transpose_mode")),
          textInput(session$ns("transpose_row_field"), "First line name", value = "Row_Field")
        ),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("transpose_confirm"), "Confirm transpose", class = "btn-primary", onclick = sync_modal_inputs_before_action_js)),
        easyClose = TRUE
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    })

    observeEvent(input$transpose_confirm, {
      if (!advanced_modal_is_current("Table transpose")) return()
      req(current_df())
      if (!ensure_editable_table("Transpose table")) return()
      df <- current_df()
      mode <- input$transpose_mode %||% "normal"
      col_field <- trimws(input$transpose_col_field %||% "Col_Field")
      row_field <- trimws(input$transpose_row_field %||% "Row_Field")
      if (!nzchar(col_field)) col_field <- "Col_Field"
      if (!nzchar(row_field)) row_field <- "Row_Field"
      out <- tryCatch(transpose_df(df, mode = mode, col_field = col_field, row_field = row_field), error = function(e) e)
      if (inherits(out, "error")) {
        showNotification(paste("Table transposition failed:", conditionMessage(out)), type = "error", duration = 8)
        return()
      }
      update_df(out, "Table transpose", sprintf("Original table = %s rows x %s columns", nrow(df), ncol(df)), reset_page = TRUE)
      updateNumericInput(session, "hot_col_page", value = 1, min = 1)
      updateNumericInput(session, "hot_preview_col_page", value = 1, min = 1)
      preview_render_token(isolate(preview_render_token()) + 1)
      showNotification("The table has been transposed in the current dataset.", type = "message")
      removeModal()
    })

    observeEvent(input$pivot_long_open, {
      if (!ensure_displayed_table_current("Convert to long data")) return()
      req(current_df())
      showModal(modalDialog(
        title = "Convert current data to long data pivot_longer",
        pickerInput(session$ns("long_id_cols"), "Column reserved as ID", choices = names(current_df()), selected = NULL, multiple = TRUE, options = list(`actions-box` = TRUE, `live-search` = TRUE)),
        pickerInput(session$ns("long_value_cols"), "Column that needs to be stretched", choices = names(current_df()), selected = names(current_df()), multiple = TRUE, options = list(`actions-box` = TRUE, `live-search` = TRUE)),
        textInput(session$ns("long_names_to"), "Variable name list names_to", value = "variable"),
        textInput(session$ns("long_values_to"), "Numeric column values_to", value = "value"),
        textInput(session$ns("long_result_name"), "Result dataset name", value = "long_dataset"),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("pivot_long_confirm"), "Confirm conversion", class = "btn-primary")),
        easyClose = TRUE,
        size = "l"
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    })

    observeEvent(input$pivot_long_confirm, {
      df <- current_df()
      value_cols <- intersect(input$long_value_cols %||% character(0), names(df))
      id_cols <- intersect(input$long_id_cols %||% character(0), names(df))
      if (length(value_cols) == 0) { showNotification("Please select at least one column that needs to be stretched.", type = "error"); return() }
      if (!nzchar(trimws(input$long_names_to %||% "")) || !nzchar(trimws(input$long_values_to %||% ""))) {
        showNotification("Variable name column and numeric column name cannot be empty.", type = "error")
        return()
      }
      out <- tryCatch(tidyr::pivot_longer(df, cols = dplyr::all_of(value_cols), names_to = input$long_names_to, values_to = input$long_values_to), error = function(e) e)
      if (inherits(out, "error")) { showNotification(paste("Long data conversion failed:", conditionMessage(out)), type = "error", duration = 10); return() }
      if (length(id_cols) > 0) out <- out[, c(id_cols, setdiff(names(out), id_cols)), drop = FALSE]
      save_result_dataset(out, input$long_result_name, "Convert to long data", sprintf("value_cols=%s", paste(value_cols, collapse = ",")))
      removeModal()
    })
    
    observeEvent(input$pivot_wide_open, {
      if (!ensure_displayed_table_current("Convert to wide data")) return()
      req(current_df())
      showModal(modalDialog(
        title = "Convert current data to wide data pivot_wider",
        pickerInput(session$ns("wide_id_cols"), "ID column", choices = names(current_df()), selected = NULL, multiple = TRUE, options = list(`actions-box` = TRUE, `live-search` = TRUE)),
        selectInput(session$ns("wide_names_from"), "Name source names_from", choices = names(current_df()), selected = names(current_df())[1]),
        selectInput(session$ns("wide_values_from"), "Value source values_from", choices = names(current_df()), selected = names(current_df())[min(2, ncol(current_df()))]),
        selectInput(session$ns("wide_values_fn"), "Repeat key aggregation method", choices = c("No aggregation" = "none", "mean", "sum", "first", "length"), selected = "none"),
        textInput(session$ns("wide_result_name"), "Result dataset name", value = "wide_dataset"),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("pivot_wide_confirm"), "Confirm conversion", class = "btn-primary")),
        easyClose = TRUE,
        size = "l"
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    })
    
    observeEvent(input$pivot_wide_confirm, {
      df <- current_df()
      if (!(input$wide_names_from %||% "") %in% names(df) || !(input$wide_values_from %||% "") %in% names(df)) {
        showNotification("Please select a valid column name source and value source field.", type = "error")
        return()
      }
      id_cols <- intersect(input$wide_id_cols %||% character(0), names(df))
      fn <- switch(input$wide_values_fn %||% "none",
                   mean = function(x) mean(x, na.rm = TRUE),
                   sum = function(x) sum(x, na.rm = TRUE),
                   first = dplyr::first,
                   length = length,
                   none = NULL)
      out <- tryCatch({
        args <- list(data = df, names_from = dplyr::all_of(input$wide_names_from), values_from = dplyr::all_of(input$wide_values_from))
        if (length(id_cols) > 0) args$id_cols <- dplyr::all_of(id_cols)
        if (!is.null(fn)) args$values_fn <- fn
        do.call(tidyr::pivot_wider, args)
      }, error = function(e) e)
      if (inherits(out, "error")) { showNotification(paste("Wide data conversion failed:", out$message), type = "error", duration = 10); return() }
      save_result_dataset(out, input$wide_result_name, "Convert to wide data", sprintf("names_from=%s; values_from=%s", input$wide_names_from, input$wide_values_from))
      removeModal()
    })
    
    # -----------Dataset summarize operations------------
    observeEvent(input$summarise_open, {
      if (!ensure_displayed_table_current("Group summary")) return()
      req(current_df())
      numeric_cols <- names(current_df())[vapply(current_df(), is.numeric, logical(1))]
      showModal(modalDialog(
        title = "Single data set group summary",
        pickerInput(session$ns("sum_group_cols"), "grouping column", choices = names(current_df()), selected = NULL, multiple = TRUE, options = list(`actions-box` = TRUE, `live-search` = TRUE)),
        pickerInput(session$ns("sum_value_cols"), "Summarize numeric columns", choices = numeric_cols, selected = numeric_cols, multiple = TRUE, options = list(`actions-box` = TRUE, `live-search` = TRUE)),
        pickerInput(
          session$ns("sum_funs"),
          "Summary function",
          choices = c(
            "mean" = "mean",
            "Sample size (n)" = "n",
            "Standard deviation (sd)" = "sd",
            "Standard error (se)" = "se",
            "95% confidence interval lower limit" = "lower_CI95",
            "Upper limit of 95% confidence interval" = "upper_CI95",
            "sum" = "sum",
            "Minimum value (min)" = "min",
            "Maximum value (max)" = "max",
            "median" = "median"
          ),
          selected = c("mean", "n", "sd", "se", "lower_CI95", "upper_CI95"),
          multiple = TRUE,
          options = list(`actions-box` = TRUE)
        ),
        textInput(session$ns("sum_result_name"), "Result dataset name", value = "summary_dataset"),
        footer = tagList(modalButton("Cancel"), actionButton(session$ns("summarise_confirm"), "Confirmation summary", class = "btn-primary")),
        easyClose = TRUE,
        size = "l"
      ))
      jqui_draggable(".modal-dialog", options = list(handle = ".modal-header", cancel = "input, textarea, button, select, option, .selectize-input, .selectize-dropdown"))
    })
    
    observeEvent(input$summarise_confirm, {
      df <- current_df()
      group_cols <- intersect(input$sum_group_cols %||% character(0), names(df))
      value_cols <- intersect(input$sum_value_cols %||% character(0), names(df))
      funs <- input$sum_funs %||% character(0)
      if (!length(funs)) {
        showNotification("Please select at least one summary function.", type = "error")
        return()
      }
      if (length(value_cols) == 0 && !("n" %in% funs)) { showNotification("Please select a numeric column, or at least n for the count summary.", type = "error"); return() }
      out <- tryCatch({
        summarise_dataset_fast(df, group_cols, value_cols, funs)
      }, error = function(e) e)
      if (inherits(out, "error")) { showNotification(paste("Group summary failed:", out$message), type = "error", duration = 10); return() }
      save_result_dataset(out, input$sum_result_name, "Group summary", sprintf("groups=%s; values=%s; funs=%s", paste(group_cols, collapse = ","), paste(value_cols, collapse = ","), paste(funs, collapse = ",")))
      removeModal()
    })



    
# ------------------------------
# Download  sheet
# ------------------------------

    output$download_current <- downloadHandler(
      filename = function() paste0(rv$active_dataset, "_", Sys.Date(), ".csv"),
      contentType = "text/csv; charset=utf-8",
      content = function(file) {
        dava_write_csv(current_df(), file, include_rownames = TRUE,
          excel_compatible = TRUE)
      }
    )
    
	
	output$download_all <- downloadHandler(
	filename = function() {
			sprintf("all_workbooks_%s.xlsx", Sys.Date())
		},
	contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
		content = function(file) {
		tables <- shiny::isolate(rv$global_datasets %||% list())
		dava_write_xlsx(tables, path = file, include_rownames = TRUE)
		}
	)
	
	
    outputOptions(output, "book_ui", suspendWhenHidden = FALSE)
    outputOptions(output, "sheet_ui", suspendWhenHidden = FALSE)
    outputOptions(output, "global_dataset_ui", suspendWhenHidden = FALSE)
    outputOptions(output, "table_page_summary", suspendWhenHidden = FALSE)
    outputOptions(output, "hot", suspendWhenHidden = TRUE)
    outputOptions(output, "meta_table", suspendWhenHidden = TRUE)
    outputOptions(output, "log_table", suspendWhenHidden = TRUE)
	
    
    # ------------------------------
    # Exposed API for other modules
    # ------------------------------
    
    flie_data <- list(
      rv = rv,
      microbiome_import_diagnostics = micro_import_diagnostics,
      validate_microbiome_import = micro_validate_import
    )
    
    return(flie_data)
    
  })
}
