microbiome_category_registry <- function() {
  data.frame(
    id = c("diversity", "composition_differential", "network_keystone",
      "function_analysis", "community_modeling", "association"),
    label_cn = c("Diversity Analysis", "Species composition and diversity", "Microbial association network",
      "Function prediction and analysis", "Community model construction", "Microbiome-environment correlation analysis"),
    order = seq_len(6), stringsAsFactors = FALSE
  )
}

microbiome_panel_registry <- function() {
  groups <- list(
    diversity = c(alpha_diversity = "Alpha Diversity", beta_diversity = "Beta Diversity",
      phylogenetic_diversity = "Phylogenetic diversity"),
    composition_differential = c(exploratory_composition = "Species composition and diversity"),
    association = c(multivariable_association = "Species-environment association", community_environment = "Microbial community-environmental factors"),
  network_keystone = c(microbial_network = "Co-occurrence network analysis", cross_domain_network = "Cross-domain network analysis"),
    function_analysis = c(bacterial_function = "Bacterial function", fungal_function = "Fungal function"),
    community_modeling = c(community_assembly = "Community building", niche_breadth = "Niche breadth")
  )
  rows <- do.call(rbind, lapply(names(groups), function(category) {
    values <- groups[[category]]
    data.frame(id = names(values), label_cn = unname(values), secondary_category = category,
      order = seq_along(values), stringsAsFactors = FALSE)
  }))
  rownames(rows) <- NULL
  rows
}

microbiome_workflow_method_map <- function() {
  list(
    alpha_diversity = c("alpha_core", "richness_indices", "diversity_indices", "evenness_indices",
      "alpha_group_comparison", "alpha_multifactor_model", "alpha_repeated_mixed", "alpha_environment_regression",
      "alpha_rarefaction"),
    beta_diversity = c("pcoa", "nmds", "pca", "robust_aitchison_pca", "distance_matrix",
      "permanova_permdisp", "permanova_interaction", "permanova_restricted", "permdisp", "anosim", "mrpp",
      "between_group_distance", "community_trajectory"),
    phylogenetic_diversity = c("phylogenetic_tree_build", "faith_pd", "mpd_mntd_nri_nti", "phylogenetic_tree"),
    exploratory_composition = c("taxonomic_composition", "core_microbiome", "indicator_taxa",
      "shared_unique_features", "venn_upset", "anova_welch", "wilcoxon_kruskal", "lefse",
      "differential_indicator_species", "ancombc2"),
    multivariable_association = c(
      "species_env_spearman", "mantel_correlation", "maaslin2"),
    community_environment = c("rda", "cca", "dbrda", "envfit", "mantel"),
    microbial_network = "netcomi_network",
    cross_domain_network = c("cross_domain_network"),
    bacterial_function = c("faprotax", "tax4fun2", "picrust2_import", "bugbase_import"),
    fungal_function = c("funguild", "fungaltraits"),
    community_assembly = c("ncm", "nst", "tnst", "pnst", "beta_mntd", "beta_nti", "rcbray",
      "bnti_rcbray", "icamp", "assembly_nri_nti"),
    niche_breadth = c("niche_breadth_assembly")
  )
}

microbiome_workflow_category <- function(panel_id) {
  panels <- microbiome_panel_registry()
  value <- panels$secondary_category[match(panel_id, panels$id)]
  if (length(value) && !is.na(value)) value else ""
}

microbiome_apply_workflow_registry <- function(registry) {
  registry$navigation_panel <- ""
  registry$navigation_category <- ""
  mapping <- microbiome_workflow_method_map()
  for (panel_id in names(mapping)) {
    matched <- registry$id %in% mapping[[panel_id]]
    registry$navigation_panel[matched] <- panel_id
    registry$navigation_category[matched] <- microbiome_workflow_category(panel_id)
  }
  registry$navigation_visibility <- nzchar(registry$navigation_panel)
  registry
}

MICROBIOME_METHOD_REGISTRY <- microbiome_apply_workflow_registry(MICROBIOME_METHOD_REGISTRY)

microbiome_panel_method_choices <- function(category_id, panel_id, include_planned = TRUE) {
  methods <- MICROBIOME_METHOD_REGISTRY[
    MICROBIOME_METHOD_REGISTRY$navigation_category == category_id &
      MICROBIOME_METHOD_REGISTRY$navigation_panel == panel_id &
      MICROBIOME_METHOD_REGISTRY$navigation_visibility, , drop = FALSE]
  if (!include_planned) methods <- methods[methods$status == "implemented" & methods$visibility, , drop = FALSE]
  stats::setNames(methods$id, paste0(methods$label_cn,
    ifelse(methods$status == "implemented", "", "(under planning)")))
}

microbiome_beta_method_groups <- function(include_planned = TRUE) {
  available <- unname(microbiome_panel_method_choices(
    "diversity", "beta_diversity", include_planned = include_planned))
  groups <- list(
    ordination = c("pcoa", "nmds", "pca"),
    distance = c("distance_matrix", "beta_cluster_heatmap", "between_group_distance", "community_trajectory"),
    test = c("permanova_permdisp", "permanova_interaction", "permanova_restricted",
      "permdisp", "anosim", "mrpp")
  )
  lapply(groups, intersect, y = available)
}

microbiome_method_choices_for_ids <- function(method_ids) {
  methods <- MICROBIOME_METHOD_REGISTRY[
    match(method_ids, MICROBIOME_METHOD_REGISTRY$id), , drop = FALSE]
  methods <- methods[!is.na(methods$id), , drop = FALSE]
  stats::setNames(methods$id, paste0(methods$label_cn,
    ifelse(methods$status == "implemented", "", "(under planning)")))
}

microbiome_category_method_choices <- function(category_id, include_planned = FALSE) {
  methods <- MICROBIOME_METHOD_REGISTRY[
    MICROBIOME_METHOD_REGISTRY$navigation_category == category_id & MICROBIOME_METHOD_REGISTRY$navigation_visibility,
    , drop = FALSE]
  if (!include_planned) methods <- methods[methods$status == "implemented" & methods$visibility, , drop = FALSE]
  stats::setNames(methods$id, paste0(methods$label_cn,
    ifelse(methods$status == "implemented", "", "(under planning)")))
}

microbiome_preprocessing_profile <- function(method) {
  panel <- method$navigation_panel[[1]] %||% ""
  if (method$id[[1]] %in%
      c("species_env_spearman", "mantel_correlation", "maaslin2")) {
    return(list(strategy = "none",
      reason = "Taxonomic aggregation uses raw counts; CLR is applied inside the association model."))
  }
  if (identical(method$id[[1]], "tax4fun2")) {
    return(list(
      strategy = "none",
      reason = paste(
        "Tax4Fun2 uses the original OTU/ASV abundance together with",
        "representative sequences; copy-number normalization is performed",
        "inside microeco::trans_func$cal_tax4fun2().")))
  }
  if (method$id[[1]] %in% c("funguild", "fungaltraits")) {
    return(list(
      strategy = "none",
      reason = paste(
        "microeco fungal trait prediction uses the original ITS",
        "OTU/ASV abundance and the complete Kingdom-Species taxonomy;",
        "relative functional redundancy is calculated by cal_func_FR().")))
  }
  if (method$id[[1]] %in% c("netcomi_network", "cross_domain_network")) {
    return(list(strategy = "none",
      reason = "NetCoMi performs zero replacement and normalization inside netConstruct()."))
  }
  if (method$id[[1]] %in% "ancombc2") return(list(
    strategy = "none",
    reason = "Differential taxa methods require raw integer counts."))
  if (panel == "alpha_diversity") return(list(strategy = "rarefy", reason = "Alpha diversity requires comparable sequencing depth."))
  if (panel == "community_environment") {
    if (identical(method$id[[1]], "rda")) {
      return(list(strategy = "hellinger", reason = "RDA uses Hellinger-transformed community abundance."))
    }
    return(list(strategy = "none", reason = "The selected method applies its distance or chi-square transformation internally."))
  }
  if (panel == "beta_diversity") return(list(strategy = "hellinger", reason = "Hellinger transformation is suitable for community ordination."))
  if (panel %in% c("microbial_network", "cross_domain_network", "multivariable_association", "species_environment_response")) {
    return(list(strategy = "clr", reason = "CLR respects the compositional structure of abundance data."))
  }
  if (panel %in% c("exploratory_composition", "bacterial_function", "fungal_function")) return(list(strategy = "relative", reason = "Relative abundance is intended for composition display."))
  list(strategy = "none", reason = "Use raw counts unless the selected method requires a transformation.")
}

microbiome_method_capabilities <- function(method) {
  panel <- method$navigation_panel[[1]] %||% ""
  list(
    supports_group = panel %in% c("alpha_diversity", "beta_diversity", "phylogenetic_diversity",
      "exploratory_composition", "multivariable_association"),
    supports_random = panel %in% c("alpha_diversity", "multivariable_association", "species_environment_response"),
    supports_permutation = panel %in% c("beta_diversity", "phylogenetic_diversity", "community_environment",
      "microbial_network", "cross_domain_network", "community_assembly"),
    requires_phylogeny = (panel %in% c("phylogenetic_diversity") &&
      !identical(method$id[[1]], "phylogenetic_tree_build")) ||
      method$id[[1]] %in% c(
        "pnst", "beta_mntd", "beta_nti", "bnti_rcbray", "icamp",
        "assembly_nri_nti"),
    raw_counts = method$id[[1]] %in% "ancombc2",
    preprocessing = microbiome_preprocessing_profile(method)$strategy
  )
}
