new_microbiome_bundle <- function(counts, taxonomy = data.frame(), metadata = data.frame(), phylogeny = NULL,
                                  representative_sequences = NULL, environment = data.frame(), function_table = data.frame(),
                                  function_metadata = list(), functional_mapping = data.frame(), marker_type = c("16S", "ITS"),
                                  data_version = "", provenance = list()) {
  marker_type <- match.arg(marker_type)
  counts <- as.data.frame(counts, check.names = FALSE)
  if (!nrow(counts) || !ncol(counts)) stop("The microbial abundance table cannot be empty.", call. = FALSE)
  values <- suppressWarnings(as.matrix(data.frame(lapply(counts, as.numeric), check.names = FALSE)))
  invalid_non_finite <- !is.finite(values)
  invalid_negative <- is.finite(values) & values < 0
  if (any(invalid_non_finite | invalid_negative)) {
    stop(sprintf(
      paste0(
        "\u4e30\u5ea6\u8868\u53ea\u80fd\u5305\u542b\u975e\u8d1f\u6709\u9650\u6570\u503c\u3002",
        " \u68c0\u6d4b\u5230 %d \u4e2a\u975e\u6570\u503c/NA/Inf \u548c %d \u4e2a\u8d1f\u503c\u3002"
      ),
      sum(invalid_non_finite), sum(invalid_negative)
    ), call. = FALSE)
  }
  structure(list(
    counts = counts, taxonomy = as.data.frame(taxonomy, check.names = FALSE),
    metadata = as.data.frame(metadata, check.names = FALSE), phylogeny = phylogeny,
    representative_sequences = representative_sequences, environment = as.data.frame(environment, check.names = FALSE),
    function_table = as.data.frame(function_table, check.names = FALSE), function_metadata = function_metadata,
    functional_mapping = as.data.frame(functional_mapping, check.names = FALSE),
    marker_type = marker_type, data_version = data_version, provenance = provenance,
    sample_ids = rownames(counts), feature_ids = colnames(counts), transform = "none", is_raw_count = all(values == floor(values))
  ), class = c("microbiome_bundle", "list"))
}

validate_microbiome_bundle <- function(bundle) {
  errors <- character()
  if (!inherits(bundle, "microbiome_bundle")) errors <- c(errors, "The object is not a microbiome_bundle.")
  if (inherits(bundle, "microbiome_bundle") && anyDuplicated(bundle$sample_ids)) errors <- c(errors, "Sample ID is not unique.")
  if (inherits(bundle, "microbiome_bundle") && anyDuplicated(bundle$feature_ids)) errors <- c(errors, "Feature ID is not unique.")
  list(valid = !length(errors), errors = errors, warnings = character())
}
new_microbiome_result <- function(method_id, status = c("success", "warning", "error"), ...) {
  status <- match.arg(status)
  defaults <- list(
    status = status, method_id = method_id, method_label = method_id, category = "", marker_type = "",
    data_version = "", input_summary = data.frame(), analysis_spec = list(), actual_parameters = list(),
    package_versions = data.frame(), random_seed = NA_integer_, execution_time = NA_real_, model_objects = list(),
    tables = list(), statistics = data.frame(), posthoc = data.frame(), feature_results = data.frame(),
    ordination_scores = data.frame(), distance_matrix = NULL, network_objects = list(), network_tables = list(),
    functional_tables = list(), assembly_tables = list(), source_tracking_tables = list(), predictions = data.frame(),
    diagnostics = data.frame(), runtime_log = character(),
    warnings = character(), errors = character(), plots = list(),
    available_outputs = character(), available_plots = character(), generated_code = "", registration_manifest = list()
  )
  supplied <- list(...)
  defaults[names(supplied)] <- supplied
  structure(defaults, class = c("microbiome_result", "list"))
}

validate_microbiome_result <- function(result) {
  required <- c("status", "method_id", "tables", "warnings", "errors", "generated_code", "registration_manifest")
  missing <- setdiff(required, names(result))
  list(valid = inherits(result, "microbiome_result") && !length(missing), missing = missing)
}
