microbiome_legacy_panel_registry <- function() {
  panels <- list(
    preprocess = c(integrity_quality = "Data integrity and quality checks", filtering_contamination = "Feature filtering and pollution control", transformation = "Standardization and data conversion", rarefaction_coverage = "Dilution and Coverage Analysis"),
    composition = c(taxonomic_composition = "Classification composition and hierarchical summary", core_dominant_rare = "Core, Advantages and Rare Groups", indicator_specificity = "Indicates cluster and group specificity", sets_taxonomy_tree = "Collection and classification tree display"),
    alpha = c(alpha_indices = "Alpha indicator calculation", alpha_comparison = "Alpha statistical comparison between groups", alpha_longitudinal = "Alpha Regression and Longitudinal Models", alpha_visualization = "Alpha comprehensive display"),
    beta = c(distance_ordination = "Distance matrix and non-constrained sorting", community_tests = "Community difference significance test", clustering_distance = "Clustering and sample distance display", trajectory_distance = "Community trajectories and inter-group distances"),
    environment_spatial = c(constrained_ordination = "Constraint sorting and environment fitting", matrix_association = "Variation decomposition and matrix association", spatial_decay = "Spatial pattern and distance attenuation", species_environment = "Species—Environmental response"),
    differential = c(exploratory_differential = "Exploratory Difference Test", compositional_bias_corrected = "Compositional and bias correction models", multivariable_mixed = "Multivariable and mixed effects correlations"),
    network = c(network_inference = "Network inference", cross_domain_environment = "Cross-domain and microbial-environmental networks", topology_modules = "Network topology and modules", comparison_stability = "Network comparison and stability"),
    `function` = c(function_prediction_import = "16S function prediction and result import", element_cycles = "16S element cycle function group", fungal_function = "ITS fungal ecological function", function_downstream = "Functional Differences, Associations, and Networks"),
    assembly_source = c(neutral_stochasticity = "Neutral models and randomness", phylogenetic_assembly = "Phylogenetic community construction", ecological_processes = "Comprehensive division of ecological processes", source_tracking = "Source tracking and contribution comparison"),
    longitudinal_stability = c(turnover_time_distance = "Community turnover and time distance", stability_resilience = "Stability, resistance and resilience", repeated_longitudinal = "Repeated Measures and Longitudinal Models", temporal_stages = "Time trajectories, phases and seasonality"),
    integration_ml = c(cross_domain_integration = "16S–ITS cross-domain integration", prediction = "Classification and regression prediction", feature_explanation = "Feature selection and model interpretation", biomarker_evaluation = "Biomarker panel and model evaluation")
  )
  rows <- do.call(rbind, lapply(names(panels), function(category) {
    values <- panels[[category]]
    data.frame(id = names(values), label_cn = unname(values), secondary_category = category,
      order = seq_along(values), stringsAsFactors = FALSE)
  }))
  rownames(rows) <- NULL
  rows
}

microbiome_panel_nav_value <- function(panel_id) paste0("microbiome_panel_", panel_id)

microbiome_panel_from_nav_value <- function(value) {
  prefix <- "microbiome_panel_"
  if (!is.character(value) || length(value) != 1L || !startsWith(value, prefix)) return("")
  panel_id <- substring(value, nchar(prefix) + 1L)
  if (panel_id %in% microbiome_panel_registry()$id) panel_id else ""
}

microbiome_method_panel_groups <- function() list(
  integrity_quality = c("data_integrity", "sample_feature_matching", "sequencing_quality", "batch_outlier_check"),
  filtering_contamination = c("filter_prevalence", "contaminant_detection"), transformation = c("clr_transform", "tss_relative", "hellinger_transform", "presence_absence"), rarefaction_coverage = c("rarefaction_curve_coverage", "rarefaction_resampling"),
  taxonomic_composition = c("taxonomic_composition", "top_taxa", "taxonomic_aggregation", "taxonomic_heatmap", "taxonomic_bubble"), core_dominant_rare = c("core_microbiome", "dominant_rare_taxa", "abundance_occupancy"), indicator_specificity = c("indicator_taxa", "differential_indicator_species"), sets_taxonomy_tree = c("shared_unique_features", "venn_upset", "taxonomy_tree_abundance"),
  alpha_indices = c("alpha_core", "phylogenetic_tree_build", "faith_pd", "richness_indices", "diversity_indices", "evenness_indices", "mpd_mntd_nri_nti"), alpha_comparison = c("alpha_group_comparison", "alpha_multifactor_model"), alpha_longitudinal = c("alpha_repeated_mixed", "alpha_environment_regression"), alpha_visualization = "alpha_rarefaction",
  distance_ordination = c("pcoa", "nmds", "distance_matrix", "pca", "robust_aitchison_pca"), community_tests = c("permanova_permdisp", "permanova_interaction", "permanova_restricted", "permdisp", "anosim", "mrpp"), clustering_distance = c("beta_cluster_heatmap", "between_group_distance"), trajectory_distance = "community_trajectory",
  constrained_ordination = c("rda", "cca", "dbrda", "partial_rda", "partial_cca", "envfit", "constrained_term_tests"), matrix_association = c("mantel", "varpart", "partial_mantel", "procrustes_environment", "coinertia"), spatial_decay = c("distance_decay", "morans_i", "pcnm_dbmem", "environment_space_varpart"), species_environment = c("niche_breadth_environment", "species_environment_response"),
  exploratory_differential = c("wilcoxon_kruskal", "anova_welch", "lefse", "simper"), compositional_bias_corrected = c("ancombc2", "ancombc", "aldex2", "linda", "corncob"), multivariable_mixed = c("species_env_spearman", "maaslin2", "feature_glm", "feature_mixed_model", "interaction_association", "continuous_gradient_association"),
  network_inference = c("spearman_network", "pearson_network", "partial_correlation_network", "sparcc", "spieceasi", "spring_network", "netcomi_network"), cross_domain_environment = c("cross_domain_network", "microbe_environment_network", "grouped_network"), topology_modules = c("network_topology", "network_modules", "zipi_roles", "keystone_taxa"), comparison_stability = c("network_comparison", "network_robustness", "node_removal", "differential_edges"),
  function_prediction_import = c("faprotax", "tax4fun2", "picrust2_import", "bugbase_import"), element_cycles = c("nitrogen_cycle", "phosphorus_cycle", "carbon_cycle", "sulfur_cycle"), fungal_function = c("funguild", "fungaltraits", "trophic_mode_composition", "fungal_ecological_groups"), function_downstream = c("function_composition_differential", "function_environment", "guild_differential", "guild_environment", "guild_network"),
  neutral_stochasticity = c("ncm", "nst", "tnst", "pnst", "niche_breadth_assembly"), phylogenetic_assembly = c("beta_mntd", "beta_nti", "assembly_nri_nti"), ecological_processes = c("bnti_rcbray", "rcbray", "icamp", "qpe_null"), source_tracking = c("feast", "sourcetracker2_import", "source_sink_comparison"),
  turnover_time_distance = c("temporal_beta", "turnover_nestedness", "time_lag_decay"), stability_resilience = c("community_stability", "resistance", "resilience", "community_synchrony"), repeated_longitudinal = c("longitudinal_lmm", "alpha_longitudinal", "beta_longitudinal", "gamm_time_trend", "repeated_permanova"), temporal_stages = c("longitudinal_trajectory", "change_point", "seasonality"),
  cross_domain_integration = c("procrustes_cross_domain", "alpha_coupling", "cross_domain_distance_correlation", "cross_domain_modules", "function_guild_association"), prediction = c("rf_classification", "rf_regression", "elastic_net", "xgboost", "svm", "plsda_splsda"), feature_explanation = c("boruta", "permutation_importance", "shap"), biomarker_evaluation = "minimal_biomarker_panel"
)

microbiome_method_panel_map <- function() {
  groups <- microbiome_method_panel_groups()
  stats::setNames(rep(names(groups), lengths(groups)), unlist(groups, use.names = FALSE))
}

microbiome_method_panel <- function(method_id, category_id = "") {
  panel <- unname(microbiome_method_panel_map()[method_id])
  if (length(panel) && !is.na(panel) && nzchar(panel)) return(panel)
  candidates <- microbiome_legacy_panel_registry()
  match_index <- which(candidates$secondary_category == category_id)[1]
  if (length(match_index) && !is.na(match_index)) candidates$id[[match_index]] else ""
}

microbiome_full_method_catalog <- function() {
  groups <- list(
    preprocess = c(
      sample_feature_matching = "Sample matches feature name", sequencing_quality = "Sequencing depth and data quality overview",
      contaminant_detection = "Pollution feature identification", rarefaction_curve_coverage = "Dilution curve and coverage",
      rarefaction_resampling = "Dilution/Resampling", tss_relative = "Relative abundance and TSS",
      hellinger_transform = "Hellinger conversion",
      presence_absence = "presence-absence conversion", batch_outlier_check = "Batch and abnormal sample inspection"
    ),
    composition = c(
      top_taxa = "Top taxa composition", taxonomic_aggregation = "Classification level summary",
      taxonomic_heatmap = "Classification abundance heatmap", taxonomic_bubble = "Classification abundance bubble chart",
      dominant_rare_taxa = "Dominant taxa and rare taxa", abundance_occupancy = "abundance-occupancy relationship",
      shared_unique_features = "Common and Unique ASV/OTUs", venn_upset = "Venn/UpSet Set Analysis",
      taxonomy_tree_abundance = "Classification tree and abundance circle diagram"
    ),
    alpha = c(
      richness_indices = "Richness indicator (Observed/Chao1/ACE/Fisher alpha)",
      diversity_indices = "Diversity indicators (Shannon/Simpson/Hill numbers)", evenness_indices = "Uniformity index (Pielou)",
      mpd_mntd_nri_nti = "Phylogenetic diversity (MPD/MNTD/NRI/NTI)", alpha_group_comparison = "Comparison between two groups and multiple groups",
      alpha_multifactor_model = "Multifactor Alpha Model", alpha_repeated_mixed = "Repeated Measures and Mixed Effects Alpha Model",
      alpha_environment_regression = "Alpha and environment variable regression", alpha_rarefaction = "Dilution curve"
    ),
    beta = c(
      distance_matrix = "Distance matrix (Bray/Jaccard/Sorensen/Euclidean/Hellinger/Aitchison/UniFrac)",
      pca = "PCA", robust_aitchison_pca = "robust Aitchison PCA", beta_cluster_heatmap = "Hierarchical clustering and sample distance heat map",
      permanova_interaction = "Multiple factors and interaction PERMANOVA",
      permanova_restricted = "Stratified/Blocked/Paired PERMANOVA", permdisp = "PERMDISP/betadisper",
      anosim = "ANOSIM", mrpp = "MRPP", between_group_distance = "Distance comparison between groups", community_trajectory = "Community trajectory display"
    ),
    environment_spatial = c(
      partial_rda = "partial RDA", partial_cca = "partial CCA", envfit = "envfit environment fitting",
      constrained_term_tests = "Single factor and marginal permutation test", varpart = "mutation decomposition varpart", partial_mantel = "partial Mantel",
      procrustes_environment = "Procrustes/Protest", coinertia = "co-inertia", distance_decay = "Distance attenuation relationship",
      morans_i = "Moran's I", pcnm_dbmem = "PCNM/dbMEM", environment_space_varpart = "Environment-spatial variation decomposition",
      niche_breadth_environment = "Niche breadth", species_environment_response = "Species-Environment Response"
    ),
    differential = c(
      anova_welch = "ANOVA/Welch", lefse = "LEfSe", differential_indicator_species = "indicator species",
      simper = "SIMPER (contribution description)", ancombc = "ANCOM-BC",
      aldex2 = "ALDEx2", linda = "LinDA", corncob = "corncob", feature_glm = "Feature-level GLM",
      feature_mixed_model = "Feature-level mixed effects model", interaction_association = "Interaction Effect Correlation",
      continuous_gradient_association = "Continuous environmental gradient correlation"
    ),
    network = c(
      pearson_network = "Pearson Exploratory Correlation Network", partial_correlation_network = "partial correlation", sparcc = "SparCC",
      spring_network = "SPRING", netcomi_network = "NetCoMi Network", cross_domain_network = "Bacterial-fungal cross-domain network",
      microbe_environment_network = "Microbiome-Environment Network", grouped_network = "Packet Network", network_topology = "Network topology",
      network_modules = "Module identification", zipi_roles = "Zi-Pi Node Role", keystone_taxa = "keystone taxa",
      network_comparison = "Network comparison", network_robustness = "Network Robustness and Vulnerability",
      node_removal = "Random/directed node removal", differential_edges = "Difference associated edges"
    ),
    "function" = c(
      tax4fun2 = "Tax4Fun2", bugbase_import = "BugBase/phenotype results import", nitrogen_cycle = "Nitrogen cycle functional group",
      phosphorus_cycle = "Phosphorus cycle functional group", carbon_cycle = "Carbon cycle functional group", sulfur_cycle = "Sulfur cycle functional group",
      function_composition_differential = "Functional composition and differences", function_environment = "Function-Environment Association",
      fungaltraits = "FungalTraits", trophic_mode_composition = "Nutritional composition", fungal_ecological_groups = "AMF/ECM/pathogen/saprophytic functional group",
      guild_differential = "guild difference analysis", guild_environment = "guild and environment", guild_network = "guild network"
    ),
    assembly_source = c(
      nst = "NST", tnst = "tNST", pnst = "pNST", beta_mntd = "betaMNTD", beta_nti = "betaNTI",
      rcbray = "RCbray", icamp = "iCAMP", assembly_nri_nti = "NRI/NTI", niche_breadth_assembly = "Niche breadth",
      qpe_null = "QPE/null model extension", sourcetracker2_import = "SourceTracker2 results import", source_sink_comparison = "source-sink contribution comparison"
    ),
    longitudinal_stability = c(
      turnover_nestedness = "Turnover and nestedness decomposition", time_lag_decay = "Time lag distance attenuation",
      community_stability = "Community stability", resistance = "Resistance", resilience = "resilience",
      community_synchrony = "Community synchrony/asynchrony", alpha_longitudinal = "Alpha portrait model", beta_longitudinal = "Beta Longitudinal Model",
      gamm_time_trend = "GAMM Time Trend", repeated_permanova = "Paired/Repeated Measures PERMANOVA",
      longitudinal_trajectory = "Community trajectory analysis", change_point = "change-point/stage change", seasonality = "Seasonal Analysis"
    ),
    integration_ml = c(
      alpha_coupling = "Alpha diversity coupling", cross_domain_distance_correlation = "Distance matrix correlation",
      cross_domain_modules = "Cross-domain module association", function_guild_association = "16S function-ITS guild association",
      rf_regression = "Random Forest returns", xgboost = "XGBoost", svm = "SVM", plsda_splsda = "PLS-DA/sPLS-DA",
      boruta = "Boruta", permutation_importance = "permutation importance", shap = "SHAP",
      minimal_biomarker_panel = "Minimal biomarker panel"
    )
  )
  rows <- do.call(rbind, lapply(names(groups), function(category) {
    values <- groups[[category]]
    data.frame(id = names(values), label_cn = unname(values), secondary_category = category, stringsAsFactors = FALSE)
  }))
  rownames(rows) <- NULL
  rows
}

microbiome_method_registry <- function() {
  definitions <- list(
    c("data_integrity", "Data integrity and direction identification", "preprocess", "core", "both"),
    c("filter_prevalence", "Low abundance and low prevalence filtering", "preprocess", "core", "both"),
    c("clr_transform", "CLR/rCLR conversion", "preprocess", "standard", "both"),
    c("taxonomic_composition", "Classification composition stacked chart", "composition", "core", "both"),
    c("core_microbiome", "Core Microbiome", "composition", "standard", "both"),
    c("indicator_taxa", "Indicator species/indicator taxa", "composition", "standard", "both"),
    c("alpha_core", "Richness, diversity and evenness", "alpha", "core", "both"),
    c("phylogenetic_tree_build", "Phylogenetic tree construction", "alpha", "advanced", "both"),
    c("faith_pd", "Faith PD", "alpha", "advanced", "16S"),
    c("mpd_mntd_nri_nti", "Phylogenetic diversity (MPD/MNTD/NRI/NTI)", "alpha", "advanced", "16S"),
    c("phylogenetic_tree", "Phylogenetic tree diagram", "alpha", "advanced", "16S"),
    c("pcoa", "PCoA", "beta", "core", "both"),
    c("nmds", "NMDS", "beta", "core", "both"),
    c("permanova_permdisp", "PERMANOVA + PERMDISP", "beta", "core", "both"),
    c("rda", "RDA", "environment_spatial", "standard", "both"),
    c("cca", "Canonical Correspondence Analysis (CCA)", "environment_spatial", "standard", "both"),
    c("dbrda", "dbRDA/CAP", "environment_spatial", "standard", "both"),
    c("mantel", "Mantel Test", "environment_spatial", "standard", "both"),
    c("wilcoxon_kruskal", "Wilcoxon/Kruskal-Wallis", "differential", "core", "both"),
    c("ancombc2", "Differential taxa", "differential", "advanced", "both"),
    c("species_env_spearman", "Spearman related", "differential", "core", "both"),
    c("mantel_correlation", "Mantel-Correlation", "differential", "advanced", "both"),
    c("maaslin2", "MaAsLin2", "differential", "advanced", "both"),
    c("spearman_network", "Spearman Exploratory Correlation Network", "network", "core", "both"),
    c("spieceasi", "SPIEC-EASI", "network", "advanced", "both"),
    c("faprotax", "FAPROTAX", "function", "external_import", "16S"),
    c("funguild", "FUNGuild", "function", "external_import", "ITS"),
    c("picrust2_import", "PICRUSt2 results import", "function", "external_import", "16S"),
    c("ncm", "Sloan neutral community model", "assembly_source", "standard", "both"),
    c("bnti_rcbray", "βNTI + RCbray", "assembly_source", "advanced", "16S"),
    c("feast", "FEAST Source Tracking", "assembly_source", "advanced", "both"),
    c("temporal_beta", "Temporal beta diversity", "longitudinal_stability", "standard", "both"),
    c("longitudinal_lmm", "Linear Mixed Effects Trajectory", "longitudinal_stability", "standard", "both"),
    c("rf_classification", "Random Forest Classification", "integration_ml", "standard", "both"),
    c("elastic_net", "Elastic Net/LASSO", "integration_ml", "standard", "both"),
    c("procrustes_cross_domain", "16S–ITS Procrustes/Protest", "integration_ml", "standard", "both")
  )
  registry <- as.data.frame(do.call(rbind, definitions), stringsAsFactors = FALSE)
  names(registry) <- c("id", "label_cn", "secondary_category", "implementation_tier", "marker_type")
  extended <- microbiome_full_method_catalog()
  extended <- extended[!extended$id %in% registry$id, , drop = FALSE]
  extended$implementation_tier <- "mature_package"
  extended$marker_type <- "both"
  extended <- extended[, names(registry), drop = FALSE]
  registry <- rbind(registry, extended)
  registry$label_cn[registry$id == "clr_transform"] <- "CLR/rCLR/ALR/ILR conversion"
  registry$label_cn[registry$id == "alpha_core"] <- "Comprehensive display of multiple indicators"
  registry$label_cn[registry$id == "permanova_permdisp"] <- "PERMANOVA (also output PERMDISP)"
  registry$label_cn[registry$id == "envfit"] <- "PCoA + envfit"
  registry$label_cn[registry$id == "mantel"] <- "Mantel test"
  registry$label_en <- registry$id
  registry$marker_type[registry$id %in% c(
    "tax4fun2", "bugbase_import", "pnst", "beta_mntd", "beta_nti",
    "rcbray", "icamp", "assembly_nri_nti")] <- "16S"
  registry$marker_type[registry$id == "fungaltraits"] <- "ITS"
  registry$tertiary_panel <- vapply(seq_len(nrow(registry)), function(index) {
    microbiome_method_panel(registry$id[[index]], registry$secondary_category[[index]])
  }, character(1))
  registry$tertiary_group <- registry$tertiary_panel
  registry$description <- ""
  registry$scientific_scope <- ""
  registry$status <- "planned"
  registry$visibility <- FALSE
  registry$navigation_visibility <- FALSE
  registry$engine <- ""
  registry$unavailable_reason <- "The analysis engine, result collation and automated testing have not yet completed the closed loop."
  registry$required_packages <- ""
  registry$optional_packages <- ""
  registry$external_tools <- ""
  registry$local_database_requirements <- ""
  registry$minimum_r_version <- "4.4.0"
  registry$supported_operating_systems <- "windows,macos,linux"
  registry$count_table_required <- TRUE
  registry$taxonomy_required <- registry$secondary_category %in% c("composition", "function")
  registry$taxonomy_required[registry$id %in% c("lefse", "phylogenetic_tree")] <- TRUE
  registry$taxonomy_required[registry$id %in%
    c("species_env_spearman", "mantel_correlation", "maaslin2")] <- TRUE
  registry$taxonomy_required[registry$id %in% c(
    "netcomi_network", "cross_domain_network")] <- TRUE
  registry$metadata_required <- registry$secondary_category != "preprocess"
  registry$metadata_required[registry$id == "phylogenetic_tree_build"] <- FALSE
  registry$phylogeny_required <- registry$id %in% c(
    "faith_pd", "phylogenetic_tree", "mpd_mntd_nri_nti", "pnst", "beta_mntd", "beta_nti", "bnti_rcbray",
    "icamp", "assembly_nri_nti")
  registry$representative_sequences_required <- registry$id == "tax4fun2"
  registry$environment_table_required <- registry$secondary_category == "environment_spatial"
  registry$function_table_required <- registry$id %in% c(
    "picrust2_import", "bugbase_import")
  registry$function_mapping_required <- FALSE
  registry$source_sink_required <- registry$id == "feast"
  registry$longitudinal_required <- registry$secondary_category == "longitudinal_stability"
  registry$second_microbiome_dataset_required <- registry$id %in% c(
    "procrustes_cross_domain", "cross_domain_network")
  registry$raw_count_required <- registry$id %in% c("ancombc2", "linda")
  registry$allowed_transforms <- ifelse(registry$raw_count_required, "none", "none,relative,hellinger,clr,rclr,presence_absence")
  registry$minimum_samples <- 6L
  registry$minimum_features <- 2L
  registry$minimum_group_size <- 2L
  implemented <- registry$id %in% c("data_integrity", "filter_prevalence", "clr_transform", "taxonomic_composition",
                                    "core_microbiome", "alpha_core", "pcoa", "nmds", "permanova_permdisp")
  implemented <- implemented | registry$id %in% c("rda", "cca", "dbrda", "mantel")
  implemented <- implemented | registry$id == "wilcoxon_kruskal"
  implemented <- implemented | registry$id == "spearman_network"
  implemented <- implemented | registry$id == "netcomi_network"
  implemented <- implemented | registry$id == "cross_domain_network"
  implemented <- implemented | registry$id == "picrust2_import"
  implemented <- implemented | registry$id == "ncm"
  implemented <- implemented | registry$id %in% c("temporal_beta", "longitudinal_lmm")
  implemented <- implemented | registry$id == "procrustes_cross_domain"
  implemented <- implemented | registry$id %in% c("indicator_taxa", "faith_pd",
    "mpd_mntd_nri_nti", "phylogenetic_tree", "phylogenetic_tree_build")
  implemented <- implemented | registry$id %in%
    c("ancombc2", "species_env_spearman", "mantel_correlation", "maaslin2")
  implemented <- implemented | registry$id == "spieceasi"
  implemented <- implemented | registry$id %in% c("faprotax", "funguild")
  implemented <- implemented | registry$id %in% c("rf_classification", "elastic_net")
  implemented <- implemented | registry$id == "bnti_rcbray"
  implemented <- implemented | registry$id %in% c(
    "tax4fun2", "bugbase_import", "fungaltraits",
    "nst", "tnst", "pnst", "beta_mntd", "beta_nti", "rcbray",
    "icamp", "assembly_nri_nti", "niche_breadth_assembly")
  implemented <- implemented | registry$id %in% c(
    "richness_indices", "diversity_indices", "evenness_indices", "alpha_group_comparison",
    "alpha_multifactor_model", "alpha_repeated_mixed", "alpha_environment_regression", "alpha_rarefaction",
    "distance_matrix", "pca", "permanova_interaction", "permanova_restricted", "permdisp", "anosim", "mrpp",
    "between_group_distance", "beta_cluster_heatmap", "partial_rda", "partial_cca", "envfit",
    "constrained_term_tests", "varpart", "partial_mantel", "procrustes_environment",
    "anova_welch", "simper", "linda", "pearson_network", "sparcc", "spring_network")
  implemented <- implemented | registry$id %in% c("lefse", "venn_upset")
  registry$status[implemented] <- "implemented"
  registry$visibility[implemented] <- TRUE
  registry$unavailable_reason[implemented] <- ""
  registry$required_packages[registry$id %in% c("nmds", "permanova_permdisp")] <- "vegan"
  registry$required_packages[registry$id %in% c("rda", "cca", "dbrda")] <- "vegan,rdacca.hp"
  registry$required_packages[registry$id %in% c("envfit", "mantel")] <- "vegan"
  registry$required_packages[registry$id == "spearman_network"] <- "igraph"
  registry$required_packages[registry$id == "netcomi_network"] <-
    "NetCoMi,ggClusterNet,phyloseq,microeco,meconetcomp,igraph,ggraph,ggrepel"
  registry$required_packages[registry$id == "cross_domain_network"] <-
    "NetCoMi,ggClusterNet,phyloseq,microeco,meconetcomp,igraph,ggraph,ggrepel"
  registry$required_packages[registry$id == "temporal_beta"] <- "vegan"
  registry$required_packages[registry$id == "longitudinal_lmm"] <- "lme4"
  registry$required_packages[registry$id == "procrustes_cross_domain"] <- "vegan"
  registry$required_packages[registry$id == "indicator_taxa"] <- "indicspecies,permute"
  registry$required_packages[registry$id == "faith_pd"] <- "picante,ape"
  registry$required_packages[registry$id == "mpd_mntd_nri_nti"] <- "picante,ape,vegan"
  registry$required_packages[registry$id == "phylogenetic_tree"] <-
    "microeco,ggtree,ggtreeExtra,ape,RColorBrewer"
  registry$required_packages[registry$id == "phylogenetic_tree_build"] <-
    "ape,phangorn,DECIPHER,Biostrings"
  registry$optional_packages[registry$id == "phylogenetic_tree_build"] <-
    "ggtree"
  registry$required_packages[registry$id == "ancombc2"] <- "ANCOMBC"
  registry$required_packages[registry$id == "mantel_correlation"] <-
    "microeco,vegan,ggplot2"
  registry$required_packages[registry$id == "maaslin2"] <- "Maaslin2"
  registry$required_packages[registry$id == "spieceasi"] <- "SpiecEasi,igraph"
  registry$required_packages[registry$id == "rf_classification"] <- "ranger"
  registry$required_packages[registry$id == "elastic_net"] <- "glmnet"
  registry$required_packages[registry$id == "bnti_rcbray"] <- "iCAMP,ape"
  registry$required_packages[registry$id %in% c("nst", "tnst", "pnst")] <-
    "NST"
  registry$required_packages[registry$id %in% c(
    "beta_mntd", "beta_nti", "assembly_nri_nti")] <-
    "microeco,picante,ape"
  registry$required_packages[registry$id == "rcbray"] <- "iCAMP"
  registry$required_packages[registry$id == "icamp"] <- "iCAMP,ape"
  registry$required_packages[registry$id == "niche_breadth_assembly"] <-
    "microeco"
  registry$required_packages[registry$id == "tax4fun2"] <-
    "microeco,Tax4Fun2,seqinr"
  registry$required_packages[registry$id %in% c(
    "faprotax", "funguild", "fungaltraits")] <- "microeco"
  registry$required_packages[registry$id %in% c("richness_indices", "diversity_indices", "evenness_indices",
    "alpha_group_comparison", "alpha_multifactor_model", "alpha_environment_regression", "alpha_rarefaction",
    "distance_matrix", "pca", "permanova_interaction", "permanova_restricted", "permdisp", "anosim", "mrpp",
    "between_group_distance", "beta_cluster_heatmap", "partial_rda", "partial_cca", "envfit",
    "constrained_term_tests", "varpart", "partial_mantel", "procrustes_environment", "simper")] <- "vegan"
  registry$required_packages[registry$id == "alpha_repeated_mixed"] <- "vegan,lme4"
  registry$required_packages[registry$id == "linda"] <- "LinDA"
  registry$required_packages[registry$id == "lefse"] <- "microeco,ggtree,treeio,tidytree"
  registry$required_packages[registry$id == "venn_upset"] <- "ggVennDiagram,UpSetR"
  registry$required_packages[registry$id == "pearson_network"] <- "igraph"
  registry$required_packages[registry$id == "sparcc"] <- "SpiecEasi,igraph"
  registry$required_packages[registry$id == "spring_network"] <- "SPRING,igraph"
  registry$required_packages[registry$id == "feast"] <- "FEAST"
  registry$required_packages[registry$id == "alpha_core"] <- "vegan"
  registry$required_packages[registry$id == "taxonomic_composition"] <- "microeco,lme4,glmmTMB,emmeans"
  registry$engine[registry$status == "implemented"] <- "DAVA adapter"
  registry$engine[registry$id %in% c(
    "netcomi_network", "cross_domain_network")] <-
    "NetCoMi / ggClusterNet 2.0"
  registry$engine[registry$id == "alpha_core"] <- "vegan"
  registry$engine[registry$id == "taxonomic_composition"] <- "microeco::microtable$cal_abund"
  registry$engine[registry$id %in% c("nst", "tnst", "pnst")] <- "NST"
  registry$engine[registry$id %in% c(
    "beta_mntd", "beta_nti", "rcbray", "icamp", "assembly_nri_nti",
    "niche_breadth_assembly")] <-
    "microeco / picante / iCAMP"
  registry$engine[registry$id %in% c(
    "faprotax", "funguild", "fungaltraits")] <- "microeco::trans_func"
  registry$engine[registry$id == "tax4fun2"] <-
    "microeco::trans_func$cal_tax4fun2"
  registry$engine[registry$id == "phylogenetic_tree_build"] <-
    "DECIPHER::AlignSeqs / phangorn / ape"
  registry$engine[registry$id %in% c(
    "picrust2_import", "bugbase_import")] <-
    "validated external-result import"

  package_groups <- list(
    vegan = c("sequencing_quality", "rarefaction_resampling", "tss_relative", "hellinger_transform", "presence_absence",
      "richness_indices", "diversity_indices", "evenness_indices", "alpha_group_comparison", "alpha_multifactor_model",
      "alpha_environment_regression", "alpha_rarefaction", "alpha_multi_index", "distance_matrix", "pca", "beta_cluster_heatmap",
      "permanova", "permanova_interaction", "permanova_restricted", "permdisp", "anosim", "mrpp", "between_group_distance",
      "community_trajectory", "partial_rda", "partial_cca", "envfit", "constrained_term_tests", "varpart", "partial_mantel",
      "procrustes_environment", "distance_decay", "simper", "repeated_permanova", "longitudinal_trajectory"),
    phyloseq = c("sample_feature_matching", "taxonomic_aggregation", "top_taxa", "taxonomic_heatmap", "taxonomic_bubble",
      "dominant_rare_taxa", "abundance_occupancy", "shared_unique_features", "taxonomy_tree_abundance"),
    decontam = "contaminant_detection", iNEXT = c("rarefaction_curve_coverage", "alpha_rarefaction"),
    zCompositions = "logratio_transforms", UpSetR = "venn_upset",
    picante = c("mpd_mntd_nri_nti", "beta_mntd", "beta_nti", "assembly_nri_nti"),
    GUniFrac = "distance_matrix", lme4 = c("alpha_repeated_mixed", "feature_mixed_model", "alpha_longitudinal"),
    ade4 = "coinertia", spdep = "morans_i", adespatial = c("pcnm_dbmem", "environment_space_varpart"),
    ANCOMBC = "ancombc", ALDEx2 = "aldex2", LinDA = "linda",
    corncob = "corncob", lefser = "lefse", SpiecEasi = "sparcc", SPRING = "spring_network",
    NetCoMi = c("netcomi_network", "network_comparison"), igraph = c("cross_domain_network", "microbe_environment_network",
      "grouped_network", "network_topology", "network_modules", "zipi_roles", "keystone_taxa", "network_robustness",
      "node_removal", "differential_edges", "guild_network"),
    NST = c("nst", "tnst", "pnst"), iCAMP = c("icamp", "qpe_null"), FEAST = "feast",
    betapart = "turnover_nestedness", mgcv = c("gamm_time_trend", "seasonality"),
    ranger = c("rf_regression", "permutation_importance"), xgboost = "xgboost", e1071 = "svm",
    mixOmics = "plsda_splsda", Boruta = "boruta", fastshap = "shap", glmnet = "minimal_biomarker_panel"
  )
  for (package in names(package_groups)) {
    matched <- registry$id %in% package_groups[[package]] & registry$status != "implemented"
    registry$required_packages[matched] <- package
    registry$engine[matched] <- package
  }
  microeco_classes <- list(
    "microeco::microtable/trans_abund" = c("sample_feature_matching", "sequencing_quality", "rarefaction_resampling",
      "tss_relative", "taxonomic_aggregation", "top_taxa", "taxonomic_heatmap", "taxonomic_bubble",
      "dominant_rare_taxa", "abundance_occupancy", "shared_unique_features"),
    "microeco::trans_alpha" = c("richness_indices", "diversity_indices", "evenness_indices", "alpha_group_comparison",
      "alpha_multifactor_model", "alpha_environment_regression", "alpha_rarefaction"),
    "microeco::trans_beta" = c("distance_matrix", "pca", "beta_cluster_heatmap", "permanova_interaction",
      "permanova_restricted", "permdisp", "anosim", "mrpp", "between_group_distance", "community_trajectory"),
    "microeco::trans_env" = c("partial_rda", "partial_cca", "envfit", "constrained_term_tests", "varpart",
      "partial_mantel", "procrustes_environment", "distance_decay", "species_environment_response"),
    "microeco::trans_diff" = c("anova_welch", "lefse", "differential_indicator_species", "simper",
      "feature_glm", "interaction_association", "continuous_gradient_association"),
    "microeco::trans_network" = c("pearson_network", "partial_correlation_network", "cross_domain_network",
      "microbe_environment_network", "grouped_network", "network_comparison", "differential_edges"),
    "microeco::trans_func" = c("nitrogen_cycle", "phosphorus_cycle", "carbon_cycle", "sulfur_cycle",
      "function_composition_differential", "function_environment", "trophic_mode_composition",
      "fungal_ecological_groups", "guild_differential", "guild_environment", "guild_network"),
    "microeco::trans_nullmodel/trans_niche" = c("nst", "tnst", "pnst", "beta_mntd", "beta_nti", "rcbray",
      "niche_breadth_assembly", "qpe_null"),
    "microeco::trans_classifier" = c("rf_regression", "xgboost", "svm", "plsda_splsda", "boruta",
      "permutation_importance", "shap", "minimal_biomarker_panel")
  )
  for (engine_name in names(microeco_classes)) {
    matched <- registry$id %in% microeco_classes[[engine_name]] & registry$status != "implemented"
    registry$required_packages[matched] <- "microeco"
    registry$engine[matched] <- engine_name
  }
  ggcluster_methods <- c("network_topology", "network_modules", "zipi_roles", "keystone_taxa",
    "network_robustness", "node_removal", "cross_domain_modules")
  matched <- registry$id %in% ggcluster_methods & registry$status != "implemented"
  registry$required_packages[matched] <- "ggClusterNet,igraph"
  registry$engine[matched] <- "ggClusterNet 2.0"
  registry$engine[registry$status != "implemented" & !nzchar(registry$engine)] <- "mature package adapter pending"
  registry$unavailable_reason[registry$status != "implemented" & nzchar(registry$required_packages)] <- paste0(
    "needs to be completed ", registry$required_packages[registry$status != "implemented" & nzchar(registry$required_packages)],
    " Engine adaptation, results closed loop and automated testing.")
  registry
}

MICROBIOME_METHOD_REGISTRY <- microbiome_method_registry()
microbiome_package_registry <- function() {
  packages <- c("vegan", "ape", "permute", "compositions", "zCompositions", "phyloseq", "rbiom", "mia", "microbiome",
    "iNEXT", "picante", "GUniFrac", "decontam", "indicspecies", "UpSetR", "ComplexHeatmap",
    "ANCOMBC", "ALDEx2", "Maaslin2", "corncob", "LinDA", "lefser",
    "igraph", "SpiecEasi", "SPRING", "NetCoMi", "WGCNA", "NST", "iCAMP", "FEAST", "betapart",
    "adespatial", "ade4", "spdep", "lme4", "mgcv", "ranger", "glmnet", "xgboost", "e1071",
    "mixOmics", "Boruta", "fastshap", "microeco", "ggClusterNet")
  bioconductor <- c("zCompositions", "phyloseq", "mia", "microbiome", "decontam", "ComplexHeatmap",
    "ANCOMBC", "ALDEx2", "Maaslin2", "corncob", "lefser", "mixOmics")
  external <- c("LinDA", "SPRING", "NetCoMi", "FEAST", "fastshap", "SpiecEasi", "iCAMP", "ggClusterNet")
  source <- ifelse(packages %in% bioconductor, "Bioconductor",
    ifelse(packages %in% external, "external/GitHub", "CRAN"))
  source[packages == "rbiom"] <- "CRAN archive"
  repository <- stats::setNames(rep("", length(packages)), packages)
  repository[c("LinDA", "SPRING", "NetCoMi", "FEAST", "fastshap", "SpiecEasi", "iCAMP", "ggClusterNet")] <- c(
    "zhouhj1994/LinDA", "GraceYoon/SPRING", "stefpeschel/NetCoMi", "cozygene/FEAST", "bgreenwell/fastshap",
    "zdk123/SpiecEasi", "DaliangNing/iCAMP1", "taowenmicro/ggClusterNet")
  ref <- stats::setNames(rep("", length(packages)), packages)
  ref[c("SPRING", "NetCoMi")] <- c("2d73735b5f22431ebd62b0aaa51c5315bb3207b7", "d891a81")
  archive_url <- stats::setNames(rep("", length(packages)), packages)
  archive_url["rbiom"] <- "https://cran.r-project.org/src/contrib/Archive/rbiom/rbiom_2.2.1.tar.gz"
  archive_url["mia"] <- "https://bioconductor.org/packages/3.21/bioc/src/contrib/mia_1.16.1.tar.gz"
  data.frame(package = packages,
    tier = ifelse(packages %in% c("vegan", "ape", "permute"), "core",
      ifelse(packages %in% c("phyloseq", "iNEXT", "picante", "lme4", "mgcv", "ranger", "glmnet"), "standard", "advanced")),
    source = source, repository = unname(repository[packages]), ref = unname(ref[packages]),
    archive_url = unname(archive_url[packages]), startup_required = FALSE, stringsAsFactors = FALSE)
}

microbiome_ecosystem_registry <- function() {
  data.frame(
    id = c("microeco2", "easyamplicon", "microbiome_stat_plot", "inap2", "ggclusternet"),
    display_name = c("microeco 2", "EasyAmplicon", "MicrobiomeStatPlot", "iNAP 2.0", "ggClusterNet 2.0"),
    integration_mode = c("native_r_package", "external_workflow_import", "reviewed_script_templates",
      "external_platform_import", "optional_r_package"),
    package = c("microeco", "", "", "", "ggClusterNet"),
    source = c("CRAN/official GitHub", "YongxinLiu/EasyAmplicon", "YongxinLiu/MicrobiomeStatPlot",
      "iNAP external platform", "taowenmicro/ggClusterNet"),
    license = c("GPL-3", "GPL-3", "GPL-3", "external service terms", "upstream DESCRIPTION unresolved"),
    network_at_runtime = FALSE,
    shell_in_shiny = FALSE,
    redistribution_allowed = c(TRUE, TRUE, TRUE, FALSE, FALSE),
    stringsAsFactors = FALSE
  )
}

microbiome_package_status <- function(packages = microbiome_package_registry()$package,
    loadable = TRUE) {
  packages <- unique(as.character(packages))
  installed <- if (isTRUE(loadable)) {
    vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  } else {
    packages %in% rownames(utils::installed.packages())
  }
  data.frame(
    package = packages,
    installed = installed,
    version = vapply(packages, function(package) {
      if (installed[[match(package, packages)]]) {
        tryCatch(as.character(utils::packageVersion(package)),
          error = function(error) NA_character_)
      } else {
        NA_character_
      }
    }, character(1)),
    stringsAsFactors = FALSE)
}

microbiome_method_packages <- function(method, network_engine = "") {
  if (is.null(method) || !nrow(method)) return(character())
  value <- method$required_packages[[1]] %||% ""
  packages <- unique(trimws(unlist(strsplit(value, ",", fixed = TRUE))))
  packages <- packages[nzchar(packages)]
  if (method$id[[1]] %in% c("netcomi_network", "cross_domain_network")) {
    if (identical(network_engine, "ggclusternet2")) {
      packages <- setdiff(packages, "NetCoMi")
    } else {
      packages <- setdiff(packages, "ggClusterNet")
    }
  }
  packages
}

microbiome_install_packages <- function(packages,
    repos = "https://cloud.r-project.org") {
  packages <- unique(as.character(packages))
  packages <- packages[nzchar(packages)]
  missing <- packages[
    !vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (!length(missing)) return(microbiome_package_status(packages))

  catalog <- microbiome_package_registry()
  install_spec <- data.frame(
    package = missing, source = "CRAN", repository = "", ref = "",
    stringsAsFactors = FALSE)
  matched <- match(missing, catalog$package)
  known <- !is.na(matched)
  install_spec$source[known] <- catalog$source[matched[known]]
  install_spec$repository[known] <- catalog$repository[matched[known]]
  install_spec$ref[known] <- catalog$ref[matched[known]]
  bioconductor <- c(
    "ANCOMBC", "ALDEx2", "Maaslin2", "ComplexHeatmap", "decontam",
    "ggtree", "ggtreeExtra", "lefser", "mia", "microbiome",
    "mixOmics", "phyloseq", "tidytree", "treeio", "zCompositions")
  install_spec$source[install_spec$package %in% bioconductor] <-
    "Bioconductor"
  github_repositories <- c(
    LinDA = "zhouhj1994/LinDA", SPRING = "GraceYoon/SPRING",
    NetCoMi = "stefpeschel/NetCoMi", FEAST = "cozygene/FEAST",
    fastshap = "bgreenwell/fastshap", SpiecEasi = "zdk123/SpiecEasi",
    iCAMP = "DaliangNing/iCAMP1", ggClusterNet = "taowenmicro/ggClusterNet",
    Tax4Fun2 = "")
  github_packages <- intersect(install_spec$package,
    names(github_repositories)[nzchar(github_repositories)])
  install_spec$source[match(github_packages, install_spec$package)] <-
    "external/GitHub"
  install_spec$repository[match(github_packages, install_spec$package)] <-
    unname(github_repositories[github_packages])
  cran <- setdiff(install_spec$package[install_spec$source == "CRAN"],
    "Tax4Fun2")
  bioc <- install_spec$package[install_spec$source == "Bioconductor"]
  github <- install_spec[
    install_spec$source == "external/GitHub", , drop = FALSE]
  tax4fun2 <- "Tax4Fun2" %in% missing

  if (length(cran)) {
    if (exists("dava_install_cran_packages", mode = "function")) {
      dava_install_cran_packages(cran, repos = repos)
    } else {
      utils::install.packages(cran, repos = repos, dependencies = TRUE)
    }
  }
  if (length(bioc)) {
    if (!requireNamespace("BiocManager", quietly = TRUE)) {
      utils::install.packages("BiocManager", repos = repos)
    }
    BiocManager::install(bioc, ask = FALSE, update = FALSE)
  }
  if (nrow(github)) {
    if (!requireNamespace("remotes", quietly = TRUE)) {
      utils::install.packages("remotes", repos = repos)
    }
    for (index in seq_len(nrow(github))) {
      repository <- github$repository[[index]]
      if (!nzchar(repository)) {
        stop("Missing package installation repository information:", github$package[[index]], call. = FALSE)
      }
      remote <- if (nzchar(github$ref[[index]])) {
        paste0(repository, "@", github$ref[[index]])
      } else {
        repository
      }
      remotes::install_github(
        remote, dependencies = TRUE, upgrade = "never", force = FALSE)
    }
  }
  if (tax4fun2) {
    utils::install.packages(
      paste0("https://zenodo.org/api/records/10035668/files/",
        "Tax4Fun2_1.1.5.tar.gz/content"),
      repos = NULL, type = "source")
  }

  status <- microbiome_package_status(packages)
  unresolved <- status$package[!status$installed]
  if (length(unresolved)) {
    stop("The following analysis packages have still not been successfully installed:", paste(unresolved, collapse = ", "),
      call. = FALSE)
  }
  status
}
