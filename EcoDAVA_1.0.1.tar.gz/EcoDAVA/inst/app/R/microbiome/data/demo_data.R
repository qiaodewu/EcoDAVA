microbiome_demo_registry <- function() {
  data.frame(
    scenario_id = c("grassland_16s_cross_sectional", "grassland_its_cross_sectional", "grassland_16s_longitudinal",
                    "grassland_cross_domain", "grassland_source_sink"),
    marker_type = c("16S", "ITS", "16S", "both", "both"),
    label = c("Grassland soil 16S cross section", "Grassland Soil ITS Transect", "Long-term positioning of grassland 16S", "Grassland 16S-ITS cross-domain", "Grass source tracking"),
    status = "implemented", stringsAsFactors = FALSE
  )
}

microbiome_demo_bundle <- function(scenario_id) {
  switch(scenario_id,
    grassland_16s_cross_sectional = microbiome_demo_16s(),
    grassland_its_cross_sectional = microbiome_demo_its(),
    grassland_16s_longitudinal = microbiome_demo_16s(longitudinal = TRUE),
    grassland_cross_domain = microbiome_demo_cross_domain(),
    grassland_source_sink = microbiome_demo_source_sink(),
    stop("Unknown microorganism simulation scenario.", call. = FALSE)
  )
}

microbiome_method_demo_profile <- function(method_id) {
  method <- MICROBIOME_METHOD_REGISTRY[MICROBIOME_METHOD_REGISTRY$id == method_id, , drop = FALSE]
  panel <- if (nrow(method)) method$navigation_panel[[1]] %||% method$tertiary_panel[[1]] else ""
  scenario <- if (method_id == "feast") "grassland_source_sink" else if (
    method_id == "procrustes_cross_domain" || panel == "cross_domain_network") "grassland_cross_domain" else if (
    method_id %in% c("temporal_beta", "longitudinal_lmm", "alpha_repeated_mixed", "community_trajectory")) "grassland_16s_longitudinal" else if (
    panel == "fungal_function" || method_id %in% c("funguild", "fungaltraits")) "grassland_its_cross_sectional" else
      "grassland_16s_cross_sectional"
  method_label <- if (nrow(method)) method$label_cn[[1]] else method_id
  list(method_id = method_id, scenario_id = scenario,
    label = paste0(method_label, "Exclusive simulation data"), marker_type = if (grepl("its", scenario, fixed = TRUE)) "ITS" else "16S")
}

microbiome_demo_function_table <- function(bundle, method_id) {
  counts <- microbiome_numeric_matrix(bundle$counts)
  groups <- split(seq_len(ncol(counts)), rep(seq_len(min(8L, ncol(counts))), length.out = ncol(counts)))
  values <- vapply(groups, function(index) rowSums(counts[, index, drop = FALSE]), numeric(nrow(counts)))
  values <- as.data.frame(values, check.names = FALSE)
  rownames(values) <- rownames(counts)
  if (identical(method_id, "tax4fun2") &&
      requireNamespace("microeco", quietly = TRUE)) {
    data_environment <- new.env(parent = baseenv())
    utils::data(
      "Tax4Fun2_KEGG", package = "microeco",
      envir = data_environment)
    annotation <- data_environment$Tax4Fun2_KEGG$ptw_desc
    pathway_ids <- utils::head(rownames(annotation), ncol(values))
    names(values) <- make.unique(paste(
      pathway_ids, annotation[pathway_ids, "Level.3"], sep = " | "))
  } else {
    names(values) <- paste0(
      if (bundle$marker_type == "ITS") "Guild_" else "Pathway_",
      seq_len(ncol(values)))
  }
  values
}

microbiome_demo_venn_upset_bundle <- function(bundle, seed = 20260816L) {
  metadata <- bundle$metadata
  if (!"Treatment" %in% names(metadata)) return(bundle)
  features <- sprintf("ASV_VENN_%03d", seq_len(90L))
  group <- as.character(metadata$Treatment)
  membership <- list(
    all = seq_len(18L),
    Control = 19:23,
    ModerateGrazing = 24:33,
    HeavyGrazing = 34:49,
    Control_ModerateGrazing = 50:56,
    Control_HeavyGrazing = 57:68,
    ModerateGrazing_HeavyGrazing = 69:90
  )
  allowed_groups <- c(
    rep("Control|ModerateGrazing|HeavyGrazing", 18L),
    rep("Control", 5L), rep("ModerateGrazing", 10L),
    rep("HeavyGrazing", 16L),
    rep("Control|ModerateGrazing", 7L),
    rep("Control|HeavyGrazing", 12L),
    rep("ModerateGrazing|HeavyGrazing", 22L)
  )
  mean_abundance <- c(rep(240, 18L), rep(380, 5L), rep(440, 10L),
    rep(520, 16L), rep(320, 7L), rep(400, 12L), rep(480, 22L))
  set.seed(seed)
  counts <- matrix(0L, nrow = nrow(metadata), ncol = length(features),
    dimnames = list(metadata$SampleID, features))
  for (sample_index in seq_len(nrow(metadata))) {
    present <- grepl(group[[sample_index]], allowed_groups, fixed = TRUE)
    sample_mean <- mean_abundance * stats::rlnorm(length(features), 0, 0.18)
    counts[sample_index, present] <- pmax(1L, stats::rnbinom(
      sum(present), mu = sample_mean[present], size = 12))
  }
  taxonomy <- microbiome_demo_differential_taxonomy(features)
  taxonomy$Phylum <- rep(c("SharedCore", "GroupSpecific", "PairwiseShared"),
    times = c(18L, 31L, 41L))
  taxonomy$Class <- rep(names(membership), lengths(membership))
  taxonomy$Order <- paste0("SetOrder_", sprintf("%02d", seq_along(features)))
  taxonomy$Family <- paste0("SetFamily_", sprintf("%02d", seq_along(features)))
  taxonomy$Genus <- paste0("SetGenus_", sprintf("%02d", seq_along(features)))
  taxonomy$Species <- paste0(taxonomy$Genus, "_species")
  rownames(taxonomy) <- features
  bundle$counts <- as.data.frame(counts, check.names = FALSE)
  bundle$taxonomy <- taxonomy
  bundle$feature_ids <- features
  bundle$phylogeny <- NULL
  bundle$provenance$set_design <- list(
    shared_all = 18L,
    unique_by_group = c(Control = 5L, ModerateGrazing = 10L,
      HeavyGrazing = 16L),
    pairwise_shared = c(Control_ModerateGrazing = 7L,
      Control_HeavyGrazing = 12L, ModerateGrazing_HeavyGrazing = 22L))
  bundle
}

microbiome_demo_differential_taxonomy <- function(features) {
  lineages <- data.frame(
    Phylum = c(rep("Pseudomonadota", 3L), rep("Actinomycetota", 3L),
      rep("Acidobacteriota", 3L), rep("Bacillota", 3L),
      rep("Bacteroidota", 2L), "Nitrospirota"),
    Class = c(rep("Alphaproteobacteria", 2L), "Gammaproteobacteria",
      rep("Actinomycetia", 3L), rep("Acidobacteriae", 3L),
      rep("Bacilli", 2L), "Clostridia", rep("Bacteroidia", 2L),
      "Nitrospiria"),
    Order = c("Rhizobiales", "Sphingomonadales", "Pseudomonadales",
      "Streptomycetales", "Propionibacteriales", "Micrococcales",
      "Bryobacterales", "Acidobacteriales", "Granulicellales",
      "Bacillales", "Paenibacillales", "Eubacteriales",
      "Flavobacteriales", "Chitinophagales", "Nitrospirales"),
    Family = c("Rhizobiaceae", "Sphingomonadaceae", "Pseudomonadaceae",
      "Streptomycetaceae", "Nocardioidaceae", "Micrococcaceae",
      "Bryobacteraceae", "Acidobacteriaceae", "Granulicellaceae",
      "Bacillaceae", "Paenibacillaceae", "Clostridiaceae",
      "Flavobacteriaceae", "Chitinophagaceae", "Nitrospiraceae"),
    Genus = c("Rhizobium", "Sphingomonas", "Pseudomonas", "Streptomyces",
      "Nocardioides", "Arthrobacter", "Bryobacter", "Acidibacter",
      "Granulicella", "Bacillus", "Paenibacillus", "Clostridium",
      "Flavobacterium", "Chitinophaga", "Nitrospira"),
    stringsAsFactors = FALSE)
  lineage_index <- rep(seq_len(nrow(lineages)), each = 6L,
    length.out = length(features))
  taxonomy <- lineages[lineage_index, , drop = FALSE]
  taxonomy$Feature <- features
  taxonomy$Kingdom <- "Bacteria"
  taxonomy$Species <- paste0(taxonomy$Genus, "_demo_",
    ave(seq_along(features), taxonomy$Genus, FUN = seq_along))
  taxonomy <- taxonomy[, c("Feature", "Kingdom", "Phylum", "Class", "Order",
    "Family", "Genus", "Species")]
  rownames(taxonomy) <- features
  taxonomy
}

microbiome_demo_differential_taxa_bundle <- function(bundle, seed = 20260818L) {
  metadata <- bundle$metadata
  if (!"Treatment" %in% names(metadata)) return(bundle)
  groups <- c("Control", "ModerateGrazing", "HeavyGrazing")
  features <- sprintf("ASV_DIFF_%03d", seq_len(90L))
  signal_class <- c(rep(groups, each = 18L), rep("GrazingIncrease", 6L),
    rep("GrazingDecrease", 6L), rep("Background", 24L))
  set.seed(seed)
  baseline <- exp(stats::rnorm(length(features), log(105), 0.48))
  signal_tier <- rep(c(0.78, 1, 1.32), each = 6L, times = 3L)
  counts <- matrix(0L, nrow = nrow(metadata), ncol = length(features),
    dimnames = list(metadata$SampleID, features))
  for (sample_index in seq_len(nrow(metadata))) {
    current_group <- as.character(metadata$Treatment[[sample_index]])
    grazing_index <- match(current_group, groups) - 1L
    multiplier <- rep(1, length(features))
    group_markers <- signal_class %in% groups
    multiplier[group_markers] <- 0.58
    own_markers <- signal_class == current_group
    multiplier[own_markers] <- 7.5 * signal_tier[own_markers]
    multiplier[signal_class == "GrazingIncrease"] <- exp(0.95 * grazing_index)
    multiplier[signal_class == "GrazingDecrease"] <- exp(0.95 * (2L - grazing_index))
    library_factor <- stats::runif(1L, 0.82, 1.22)
    sample_noise <- stats::rlnorm(length(features), 0, 0.20)
    mean_count <- pmax(0.5, baseline * multiplier * library_factor * sample_noise)
    counts[sample_index, ] <- stats::rnbinom(
      length(features), mu = mean_count, size = 24)
  }
  taxonomy <- microbiome_demo_differential_taxonomy(features)
  bundle$counts <- as.data.frame(counts, check.names = FALSE)
  bundle$taxonomy <- taxonomy
  bundle$feature_ids <- features
  bundle$phylogeny <- NULL
  bundle$provenance$differential_marker_groups <- split(features, signal_class)
  bundle$provenance$differential_design <- list(
    group_markers_per_group = 18L, gradient_markers = 12L,
    background_taxa = 24L, within_group_log_sd = 0.20)
  bundle
}

microbiome_demo_lefse_bundle <- function(bundle, seed = 20260817L) {
  metadata <- bundle$metadata
  if (!"Treatment" %in% names(metadata)) return(bundle)
  features <- sprintf("ASV_LEFSE_%03d", seq_len(90L))
  marker_group <- c(rep(c("Control", "ModerateGrazing", "HeavyGrazing"),
    each = 18L), rep("Core", 36L))
  taxonomy <- microbiome_demo_differential_taxonomy(features)
  taxonomy$Species <- paste0(taxonomy$Genus, "_indicator_",
    ave(seq_along(features), taxonomy$Genus, FUN = seq_along))
  set.seed(seed)
  counts <- matrix(0L, nrow = nrow(metadata), ncol = length(features),
    dimnames = list(metadata$SampleID, features))
  for (sample_index in seq_len(nrow(metadata))) {
    current_group <- as.character(metadata$Treatment[[sample_index]])
    marker_tier <- rep(c(9, 14, 20), each = 6L, times = 3L)
    weight <- ifelse(marker_group == "Core", 1.8, 0.45)
    weight[marker_group == current_group] <-
      marker_tier[marker_group == current_group]
    weight <- weight * stats::rlnorm(length(features), 0, 0.16)
    depth <- sample(seq.int(18000L, 24000L), 1L)
    counts[sample_index, ] <- as.integer(stats::rmultinom(
      1L, size = depth, prob = weight / sum(weight)))
  }
  bundle$counts <- as.data.frame(counts, check.names = FALSE)
  bundle$taxonomy <- taxonomy
  bundle$feature_ids <- features
  bundle$phylogeny <- NULL
  bundle$provenance$lefse_marker_groups <- split(features, marker_group)
  bundle$provenance$lefse_design <- list(
    markers_per_group = 18L, background_taxa = 36L,
    marker_weight_tiers = c(9, 14, 20), within_group_log_sd = 0.16)
  bundle
}

microbiome_demo_for_method_generate <- function(method_id) {
  profile <- microbiome_method_demo_profile(method_id)
  value <- microbiome_demo_bundle(profile$scenario_id)
  bundle <- if (is.list(value) && !inherits(value, "microbiome_bundle") && all(c("bacteria", "fungi") %in% names(value))) value$bacteria else value
  if (identical(method_id, "ncm")) {
    bundle <- microbiome_demo_ncm()
  }
  if (identical(method_id, "venn_upset")) {
    bundle <- microbiome_demo_venn_upset_bundle(bundle)
  }
  if (identical(method_id, "ancombc2")) {
    bundle <- microbiome_demo_differential_taxa_bundle(bundle)
  }
  if (identical(method_id, "lefse")) {
    bundle <- microbiome_demo_lefse_bundle(bundle)
  }
  method <- MICROBIOME_METHOD_REGISTRY[MICROBIOME_METHOD_REGISTRY$id == method_id, , drop = FALSE]
  if (nrow(method) && (isTRUE(method$function_table_required[[1]]) || method$navigation_category[[1]] == "function_analysis")) {
    bundle$function_table <- microbiome_demo_function_table(bundle, method_id)
    bundle$function_metadata <- list(tool = method_id, version = "DAVA simulated", source_file = "method-specific demo")
  }
  if (method_id %in% c("tax4fun2", "phylogenetic_tree_build")) {
    sequences <- microbiome_demo_representative_sequences(
      bundle$feature_ids)
    bundle$representative_sequences <- sequences
    bundle$provenance$representative_sequence_source <-
      attr(sequences, "source") %||% "simulated_nonreference"
  }
  demo_version <- if (method_id %in% c("ancombc2", "lefse", "venn_upset")) {
    "v3"
  } else {
    "v1"
  }
  bundle$data_version <- paste0("demo_", method_id, "_", demo_version)
  bundle$provenance$method_id <- method_id
  bundle$provenance$scenario_id <- profile$scenario_id
  bundle$provenance$dedicated_demo <- TRUE
  bundle
}

microbiome_demo_for_method <- function(method_id) {
  dava_local_demo_read(dava_microbiome_demo_asset(method_id))
}

microbiome_demo_ncm <- function(
    feature_count = 2000L, seed = 20260725L) {
  feature_count <- max(2000L, as.integer(feature_count))
  metadata <- microbiome_demo_design(FALSE)
  sample_count <- nrow(metadata)
  features <- sprintf("ASV_NCM_%04d", seq_len(feature_count))
  set.seed(seed)
  rank_weight <- seq_len(feature_count)^-1.15
  global_abundance <- rank_weight * stats::rlnorm(
    feature_count, meanlog = 0, sdlog = 0.55)
  global_abundance <- global_abundance / sum(global_abundance)
  migration_by_group <- c(
    Control = 0.025,
    ModerateGrazing = 0.012,
    HeavyGrazing = 0.006)
  sample_depth <- sample(
    seq.int(8000L, 16000L), sample_count, replace = TRUE)
  counts <- matrix(
    0L, nrow = sample_count, ncol = feature_count,
    dimnames = list(metadata$SampleID, features))
  for (sample_index in seq_len(sample_count)) {
    group <- as.character(metadata$Treatment[[sample_index]])
    migration <- migration_by_group[[group]] %||% 0.01
    depth <- sample_depth[[sample_index]]
    occupancy <- stats::pbeta(
      1 / depth,
      depth * migration * global_abundance,
      depth * migration * (1 - global_abundance),
      lower.tail = FALSE)
    present <- stats::runif(feature_count) < occupancy
    present[seq_len(min(12L, feature_count))] <- TRUE
    probability <- global_abundance * present
    probability <- probability / sum(probability)
    counts[sample_index, ] <- as.integer(
      stats::rmultinom(1, size = depth, prob = probability))
  }
  taxonomy <- microbiome_demo_taxonomy(features, "16S")
  rownames(taxonomy) <- features
  bundle <- new_microbiome_bundle(
    as.data.frame(counts, check.names = FALSE),
    taxonomy = taxonomy,
    metadata = metadata,
    environment = metadata[, c(
      "SampleID", "SoilMoisture", "SoilPH", "SOC")],
    functional_mapping = microbiome_demo_function_mapping("16S"),
    marker_type = "16S",
    data_version = "demo_ncm_2000_asv_v1",
    provenance = list(
      simulated = TRUE,
      seed = seed,
      feature_count = feature_count,
      simulation_model = "Sloan occupancy with group-specific migration",
      migration_by_group = migration_by_group,
      dedicated_ncm_demo = TRUE))
  bundle
}

microbiome_demo_design <- function(longitudinal = FALSE) {
  if (longitudinal) {
    design <- expand.grid(PlotID = sprintf("P%02d", 1:18), Year = 2021:2024, Season = c("Spring", "Summer"), stringsAsFactors = FALSE)
    design$Treatment <- rep(rep(c("Control", "ModerateGrazing", "HeavyGrazing"), each = 6), each = 8)
  } else {
    design <- expand.grid(Block = paste0("B", 1:6), Treatment = c("Control", "ModerateGrazing", "HeavyGrazing"),
                          Degradation = c("Low", "High"), Season = c("Spring", "Summer"), stringsAsFactors = FALSE)
    design$PlotID <- sprintf("P%03d", seq_len(nrow(design)))
    design$Year <- 2026L
  }
  design$SampleID <- sprintf("S%03d", seq_len(nrow(design)))
  grazing <- match(design$Treatment, c("Control", "ModerateGrazing", "HeavyGrazing")) - 1
  degradation_values <- if ("Degradation" %in% names(design)) design$Degradation else rep("Low", nrow(design))
  degradation <- as.integer(degradation_values == "High")
  set.seed(20260717)
  design$SoilMoisture <- round(32 - 3.8 * grazing - 2.5 * degradation + stats::rnorm(nrow(design), 0, 2), 2)
  design$SoilPH <- round(6.5 + 0.17 * grazing + stats::rnorm(nrow(design), 0, 0.2), 2)
  design$SOC <- round(26 - 2 * grazing - 1.8 * degradation + 0.12 * design$SoilMoisture + stats::rnorm(nrow(design), 0, 1.5), 2)
  design
}

microbiome_demo_counts <- function(metadata, feature_prefix, feature_count, marker_type, seed) {
  set.seed(seed)
  n <- nrow(metadata)
  grazing <- match(metadata$Treatment, c("Control", "ModerateGrazing", "HeavyGrazing")) - 1
  degradation <- as.integer((metadata$Degradation %||% rep("Low", n)) == "High")
  base_mean <- exp(stats::rnorm(feature_count,
    log(if (marker_type == "16S") 120 else 70), 0.7))
  treatment_loading <- rep(c(0.95, 0.35, -0.45, -0.95),
    length.out = feature_count)
  degradation_loading <- rep(c(0.9, -0.9), each = ceiling(feature_count / 2),
    length.out = feature_count)
  vulnerable <- seq.int(max(9L, floor(feature_count * 0.38)), feature_count)
  counts <- matrix(0L, nrow = n, ncol = feature_count)
  for (sample_index in seq_len(n)) {
    abundance <- base_mean * exp(
      0.72 * grazing[[sample_index]] * treatment_loading +
        0.95 * degradation[[sample_index]] * degradation_loading)
    present <- rep(TRUE, feature_count)
    dropout <- min(0.78, 0.04 + 0.13 * grazing[[sample_index]] +
      0.24 * degradation[[sample_index]])
    present[vulnerable] <- stats::runif(length(vulnerable)) > dropout
    abundance[!present] <- 0
    depth <- sample(seq.int(9000L, 15000L), 1L)
    counts[sample_index, ] <- as.integer(stats::rmultinom(
      1L, size = depth, prob = abundance / sum(abundance)))
  }
  affected_positive <- seq_len(min(6, feature_count))
  affected_negative <- seq.int(min(7, feature_count), min(12, feature_count))
  rownames(counts) <- metadata$SampleID
  colnames(counts) <- sprintf("%s_%03d", feature_prefix, seq_len(feature_count))
  list(counts = as.data.frame(counts, check.names = FALSE), positive = colnames(counts)[affected_positive], negative = colnames(counts)[affected_negative])
}

microbiome_demo_taxonomy <- function(features, marker_type) {
  if (marker_type == "16S") {
    phylum <- c("Pseudomonadota", "Actinomycetota", "Bacillota", "Bacteroidota", "Acidobacteriota")
    class <- c("Gammaproteobacteria", "Actinomycetia", "Bacilli", "Bacteroidia", "Acidobacteriae")
    order <- c("Pseudomonadales", "Streptomycetales", "Bacillales", "Flavobacteriales", "Bryobacterales")
    family <- c("Pseudomonadaceae", "Streptomycetaceae", "Bacillaceae", "Flavobacteriaceae", "Bryobacteraceae")
    genus <- c("Pseudomonas", "Streptomyces", "Bacillus", "Flavobacterium", "Bryobacter")
    kingdom <- "Bacteria"
  } else {
    phylum <- c("Ascomycota", "Basidiomycota", "Mortierellomycota", "Glomeromycota")
    class <- c("Sordariomycetes", "Agaricomycetes", "Mortierellomycetes", "Glomeromycetes")
    order <- c("Hypocreales", "Sebacinales", "Mortierellales", "Glomerales")
    family <- c("Nectriaceae", "Sebacinaceae", "Mortierellaceae", "Glomeraceae")
    genus <- c("Fusarium", "Sebacina", "Mortierella", "Claroideoglomus")
    kingdom <- "Fungi"
  }
  index <- (seq_along(features) - 1L) %% length(phylum) + 1L
  data.frame(
    Feature = features, Kingdom = kingdom, Phylum = phylum[index], Class = class[index],
    Order = order[index], Family = family[index], Genus = genus[index],
    Species = paste0(genus[index], "_sp_", seq_along(features)),
    stringsAsFactors = FALSE
  )
}

microbiome_demo_phylogeny <- function(features) {
  if (!requireNamespace("ape", quietly = TRUE)) return(NULL)
  set.seed(20260718)
  tree <- ape::rtree(length(features), tip.label = features)
  attr(tree, "dava_demo_tree") <- TRUE
  tree
}

microbiome_demo_representative_sequences <- function(
    features, seed = 20260721L, sequence_length = 250L) {
  reference_root <- tryCatch({
    if (exists("microbiome_tax4fun2_reference_path", mode = "function")) {
      microbiome_tax4fun2_reference_path()
    } else {
      file.path(microbiome_project_root, "tools", "Tax4Fun2_ReferenceData_v2")
    }
  }, error = function(error) "")
  reference_fasta <- file.path(
    reference_root, "Ref99NR", "Ref99NR.fasta")
  if (file.exists(reference_fasta)) {
    fasta_lines <- readLines(reference_fasta, warn = FALSE)
    headers <- which(startsWith(fasta_lines, ">"))
    if (length(headers) >= length(features)) {
      sequences <- vapply(seq_along(features), function(index) {
        start <- headers[[index]] + 1L
        end <- if (index < length(headers)) {
          headers[[index + 1L]] - 1L
        } else {
          length(fasta_lines)
        }
        paste(fasta_lines[seq.int(start, end)], collapse = "")
      }, character(1))
      sequences <- as.list(stats::setNames(sequences, features))
      attr(sequences, "source") <- "Tax4Fun2 Ref99NR"
      return(sequences)
    }
  }
  set.seed(seed)
  sequences <- vapply(features, function(feature) {
    paste(sample(c("A", "C", "G", "T"), sequence_length, replace = TRUE),
      collapse = "")
  }, character(1))
  sequences <- as.list(stats::setNames(sequences, features))
  attr(sequences, "source") <- "simulated_nonreference"
  sequences
}

microbiome_demo_function_mapping <- function(marker_type) {
  if (marker_type == "16S") {
    data.frame(Taxon = c("Pseudomonas", "Streptomyces", "Bacillus", "Flavobacterium", "Bryobacter"),
      Function = c("nitrate_respiration", "chitinolysis", "fermentation", "aerobic_chemoheterotrophy", "soil_carbon_decomposition"),
      DatabaseVersion = "DAVA_SIMULATED_FAPROTAX_1", Evidence = "simulated_demo_mapping", stringsAsFactors = FALSE)
  } else {
    data.frame(Taxon = c("Fusarium", "Mortierella", "Sebacina", "Claroideoglomus"),
      Function = c("plant_pathogen", "saprotroph", "ectomycorrhizal", "arbuscular_mycorrhizal"),
      DatabaseVersion = "DAVA_SIMULATED_FUNGUILD_1", Evidence = "simulated_demo_mapping", stringsAsFactors = FALSE)
  }
}

microbiome_demo_16s <- function(longitudinal = FALSE) {
  metadata <- microbiome_demo_design(longitudinal)
  generated <- microbiome_demo_counts(metadata, "ASV16S", 48L, "16S", 20260719L)
  bundle <- new_microbiome_bundle(
    generated$counts, taxonomy = microbiome_demo_taxonomy(names(generated$counts), "16S"), metadata = metadata,
    environment = metadata[, c("SampleID", "SoilMoisture", "SoilPH", "SOC")],
    functional_mapping = microbiome_demo_function_mapping("16S"),
    phylogeny = microbiome_demo_phylogeny(names(generated$counts)), marker_type = "16S",
    data_version = if (longitudinal) "demo_16s_longitudinal_v1" else "demo_16s_cross_sectional_v1",
    provenance = list(simulated = TRUE, seed = 20260719L, known_positive_features = generated$positive,
                      known_negative_features = generated$negative,
                      group_signal = "Treatment and Degradation affect richness and composition",
                      phylogeny = "explicitly simulated")
  )
  bundle
}

microbiome_demo_its <- function() {
  metadata <- microbiome_demo_design(FALSE)
  generated <- microbiome_demo_counts(metadata, "ASVITS", 36L, "ITS", 20260720L)
  new_microbiome_bundle(
    generated$counts, taxonomy = microbiome_demo_taxonomy(names(generated$counts), "ITS"), metadata = metadata,
    environment = metadata[, c("SampleID", "SoilMoisture", "SoilPH", "SOC")], marker_type = "ITS",
    functional_mapping = microbiome_demo_function_mapping("ITS"),
    data_version = "demo_its_cross_sectional_v1",
    provenance = list(simulated = TRUE, seed = 20260720L, known_positive_features = generated$positive,
                      known_negative_features = generated$negative,
                      group_signal = "Treatment and Degradation affect richness and composition",
                      phylogeny = "not provided by design")
  )
}

microbiome_demo_cross_domain <- function() list(bacteria = microbiome_demo_16s(), fungi = microbiome_demo_its())

microbiome_demo_source_sink <- function() {
  bundle <- microbiome_demo_16s()
  bundle$metadata$SourceSink <- rep(c("Source", "Source", "Sink"), length.out = nrow(bundle$metadata))
  bundle$metadata$Habitat <- rep(c("BulkSoil", "Rhizosphere", "Root"), length.out = nrow(bundle$metadata))
  bundle$data_version <- "demo_source_sink_v1"
  bundle
}
