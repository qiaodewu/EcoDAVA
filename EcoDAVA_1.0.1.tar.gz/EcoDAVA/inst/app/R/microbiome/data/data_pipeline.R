microbiome_numeric_matrix <- function(x, object_name = "Abundance table") {
  x <- as.data.frame(x, check.names = FALSE)
  converted <- lapply(x, function(column) suppressWarnings(as.numeric(as.character(column))))
  matrix <- as.matrix(data.frame(converted, check.names = FALSE))
  dimnames(matrix) <- dimnames(x)
  if (anyNA(matrix) || any(!is.finite(matrix))) {
    stop(object_name, "must all be finite values.", call. = FALSE)
  }
  matrix
}

microbiome_unique_labels <- function(values, prefix = "Unclassified") {
  values <- trimws(as.character(values))
  missing <- is.na(values) | values == ""
  values[missing] <- sprintf("%s_%04d", prefix, seq_len(sum(missing)))
  make.unique(values, sep = "_")
}

microbiome_normalize_taxonomy_labels <- function(values, rank) {
  values <- trimws(as.character(values))
  missing <- is.na(values) | !nzchar(values)
  values[missing] <- paste0("Unclassified_", rank)
  values
}

microbiome_align_bundle <- function(bundle) {
  check <- validate_microbiome_bundle(bundle)
  if (!check$valid) stop(paste(check$errors, collapse = " "), call. = FALSE)
  counts <- microbiome_numeric_matrix(bundle$counts)
  metadata <- bundle$metadata
  orientation <- "samples_by_features"
  metadata_ids <- rownames(metadata)
  if (nrow(metadata) && "SampleID" %in% names(metadata)) metadata_ids <- as.character(metadata$SampleID)
  row_matches <- length(metadata_ids) && all(rownames(counts) %in% metadata_ids)
  column_matches <- length(metadata_ids) && all(colnames(counts) %in% metadata_ids)
  if (!row_matches && column_matches) {
    counts <- t(counts)
    orientation <- "features_by_samples_transposed"
  } else if (nrow(metadata) && !row_matches) {
    stop("Abundance table sample name cannot fully match the SampleID or row name of metadata.", call. = FALSE)
  }
  if (anyDuplicated(rownames(counts)) || any(!nzchar(rownames(counts)))) stop("Sample ID must be non-null and unique.", call. = FALSE)
  if (anyDuplicated(colnames(counts)) || any(!nzchar(colnames(counts)))) stop("Characteristic ID must be non-null and unique.", call. = FALSE)
  if (any(counts < 0)) stop("Abundance table cannot contain negative values.", call. = FALSE)
  if (nrow(metadata)) {
    match_index <- match(rownames(counts), metadata_ids)
    metadata <- metadata[match_index, , drop = FALSE]
    rownames(metadata) <- rownames(counts)
  }
  taxonomy <- bundle$taxonomy
  if (nrow(taxonomy)) {
    feature_ids <- rownames(taxonomy)
    if ("Feature" %in% names(taxonomy)) feature_ids <- as.character(taxonomy$Feature)
    if (!all(colnames(counts) %in% feature_ids)) stop("Taxonomic annotations cannot cover all abundance features.", call. = FALSE)
    taxonomy <- taxonomy[match(colnames(counts), feature_ids), , drop = FALSE]
    rownames(taxonomy) <- colnames(counts)
    for (name in names(taxonomy)) {
      if (is.character(taxonomy[[name]]) || is.factor(taxonomy[[name]])) {
        taxonomy[[name]] <- if (identical(name, "Feature")) {
          colnames(counts)
        } else {
          microbiome_normalize_taxonomy_labels(taxonomy[[name]], name)
        }
      }
    }
  }
  bundle$counts <- as.data.frame(counts, check.names = FALSE)
  bundle$metadata <- metadata
  bundle$taxonomy <- taxonomy
  bundle$sample_ids <- rownames(counts)
  bundle$feature_ids <- colnames(counts)
  bundle$is_raw_count <- all(counts == floor(counts)) && identical(bundle$transform, "none")
  list(bundle = bundle, orientation = orientation)
}

microbiome_data_summary <- function(bundle, orientation = "samples_by_features") {
  counts <- microbiome_numeric_matrix(bundle$counts)
  depth <- rowSums(counts)
  data.frame(
    metric = c("orientation", "samples", "features", "zero_fraction", "minimum_depth", "median_depth", "maximum_depth", "raw_integer_counts"),
    value = c(orientation, nrow(counts), ncol(counts), signif(mean(counts == 0), 5), min(depth), stats::median(depth), max(depth), bundle$is_raw_count),
    stringsAsFactors = FALSE
  )
}
microbiome_transform_bundle <- function(bundle, method = c("relative", "hellinger", "clr", "rclr", "presence_absence"), pseudocount = NULL) {
  method <- match.arg(method)
  aligned <- microbiome_align_bundle(bundle)$bundle
  counts <- microbiome_numeric_matrix(aligned$counts)
  if (any(rowSums(counts) <= 0)) stop("The total abundance of each sample must be greater than zero before conversion.", call. = FALSE)
  transformed <- switch(method,
    relative = counts / rowSums(counts),
    hellinger = sqrt(counts / rowSums(counts)),
    presence_absence = (counts > 0) * 1,
    clr = {
      if (is.null(pseudocount) || !is.finite(pseudocount) || pseudocount <= 0) stop("The CLR must provide a positive pseudo-count when a zero value is encountered.", call. = FALSE)
      logged <- log(counts + pseudocount)
      logged - rowMeans(logged)
    },
    rclr = {
      logged <- counts
      logged[counts > 0] <- log(counts[counts > 0])
      logged[counts == 0] <- NA_real_
      centered <- logged - rowMeans(logged, na.rm = TRUE)
      centered[is.na(centered)] <- 0
      centered
    }
  )
  output <- aligned
  output$counts <- as.data.frame(transformed, check.names = FALSE)
  output$transform <- method
  output$is_raw_count <- FALSE
  output$provenance$parent_data_version <- bundle$data_version
  output$provenance$transformation <- list(method = method, pseudocount = pseudocount)
  output$data_version <- paste0(bundle$data_version, "_", method)
  output
}
microbiome_dataset_names <- function(file_data) {
  dava_global_dataset_names(file_data)
}

microbiome_register_rooted_phylogeny <- function(file_data, tree_table,
    source = "Microbial data analysis/phylogenetic tree construction") {
  if (is.null(file_data)) stop("Global data status is unavailable.", call. = FALSE)
  tree_table <- as.data.frame(tree_table, stringsAsFactors = FALSE,
    check.names = FALSE)
  if (nrow(tree_table) != 1L || !"Newick" %in% names(tree_table) ||
      !nzchar(trimws(as.character(tree_table$Newick[[1]] %||% "")))) {
    stop("Rooted phylogenetic trees must provide a single valid Newick entry.", call. = FALSE)
  }
  if (exists("dava_register_global_datasets", mode = "function",
      inherits = TRUE)) {
    registered <- dava_register_global_datasets(
      file_data,
      list(rooted_phylogenetic_tree = tree_table),
      source = source, prefix = "micro", overwrite = TRUE)
    return(unname(registered[["rooted_phylogenetic_tree"]]))
  }

  dataset_name <- "micro_rooted_phylogenetic_tree"
  datasets <- shiny::isolate(file_data$global_datasets %||% list())
  sources <- shiny::isolate(file_data$dataset_sources %||% list())
  datasets[[dataset_name]] <- tree_table
  sources[[dataset_name]] <- source
  file_data$global_datasets <- datasets
  file_data$dataset_sources <- sources
  file_data$data_registry_version <-
    shiny::isolate(file_data$data_registry_version %||% 0L) + 1L
  dataset_name
}

microbiome_phylogeny_dataset_names <- function(file_data) {
  datasets <- dava_global_datasets(file_data, tabular_only = FALSE)
  if (!length(datasets)) return(character())
  names(datasets)[vapply(datasets, function(value) {
    if (inherits(value, "phylo")) return(TRUE)
    if (!(is.data.frame(value) || is.matrix(value) ||
        inherits(value, "data.table"))) return(FALSE)
    table <- as.data.frame(value, stringsAsFactors = FALSE,
      check.names = FALSE)
    tree_column <- intersect(
      c("Newick", "newick", "Tree", "tree"), names(table))
    length(tree_column) > 0L || (ncol(table) == 1L && nrow(table) == 1L)
  }, logical(1))]
}

microbiome_matching_dataset_name <- function(file_data, count_dataset, ids,
    type = c("taxonomy", "metadata")) {
  type <- match.arg(type)
  datasets <- dava_global_datasets(file_data)
  candidates <- setdiff(microbiome_dataset_names(file_data),
    count_dataset %||% "")
  ids <- unique(as.character(ids %||% character()))
  ids <- ids[!is.na(ids) & nzchar(ids)]
  if (!length(candidates) || !length(ids)) return("")
  taxonomy_ranks <- c("Kingdom", "Phylum", "Class", "Order", "Family",
    "Genus", "Species")
  preferred_ids <- if (type == "taxonomy") {
    c("Feature", "FeatureID", "ASV", "OTU", "Taxon", "ID")
  } else {
    c("SampleID", "Sample", "SampleName", "ID")
  }
  score <- vapply(candidates, function(name) tryCatch({
    value <- datasets[[name]]
    if (is.null(value)) return(-Inf)
    table <- as.data.frame(value, check.names = FALSE,
      stringsAsFactors = FALSE)
    if (!nrow(table)) return(-Inf)
    rank_count <- sum(taxonomy_ranks %in% names(table))
    if (type == "taxonomy" && rank_count == 0L) return(-Inf)
    if (type == "metadata" && rank_count >= 2L) return(-Inf)
    id_columns <- intersect(preferred_ids, names(table))
    candidate_ids <- unique(c(
      if (length(id_columns)) unlist(table[id_columns], use.names = FALSE) else NULL,
      if (!identical(rownames(table), as.character(seq_len(nrow(table))))) {
        rownames(table)
      } else NULL
    ))
    overlap <- sum(ids %in% as.character(candidate_ids))
    if (!overlap) return(-Inf)
    name_bonus <- if (type == "taxonomy") {
      20 * grepl("tax|taxonomy|annotation|class", name, ignore.case = TRUE)
    } else {
      20 * grepl("meta|sample|design|group", name, ignore.case = TRUE)
    }
    categorical_bonus <- if (type == "metadata") {
      sum(vapply(table, function(value) {
        count <- length(unique(value[!is.na(value)]))
        count >= 2L && count <= 20L
      }, logical(1)))
    } else rank_count
    1000 * overlap / length(ids) + name_bonus + categorical_bonus
  }, error = function(error) -Inf), numeric(1))
  if (!any(is.finite(score))) return("")
  candidates[[which.max(score)]]
}

microbiome_dataset_get <- function(file_data, name, optional = FALSE) {
  if (is.null(name) || !nzchar(name)) {
    if (optional) return(data.frame())
    stop("Please select a data set.", call. = FALSE)
  }
  value <- file_data$global_datasets[[name]]
  if (is.null(value)) stop("Data set does not exist:", name, call. = FALSE)
  as.data.frame(value, stringsAsFactors = FALSE, check.names = FALSE)
}

microbiome_phylogeny_dataset_get <- function(file_data, name, optional = FALSE) {
  if (is.null(name) || !nzchar(name)) {
    if (optional) return(NULL)
    stop("Please select a phylogenetic tree.", call. = FALSE)
  }
  value <- file_data$global_datasets[[name]]
  if (is.null(value)) stop("Phylogenetic tree dataset does not exist:", name, call. = FALSE)
  if (inherits(value, "phylo")) return(value)
  table <- as.data.frame(value, stringsAsFactors = FALSE, check.names = FALSE)
  tree_column <- intersect(c("Newick", "newick", "Tree", "tree"), names(table))
  text <- if (length(tree_column)) {
    as.character(table[[tree_column[[1L]]]][[1L]])
  } else if (length(table) == 1L && nrow(table) == 1L) {
    as.character(table[[1L]][[1L]])
  } else {
    ""
  }
  if (!nzchar(trimws(text))) {
    stop(paste0(
      "The phylogenetic tree dataset must be a phylo object, or a table containing a single Newick string.",
      "Multi-row Tip The preview table cannot be used for tree analysis; please reselect the registered full phylogenetic tree."),
      call. = FALSE)
  }
  text <- trimws(text)
  dava_parse_newick_tree(text)
}

microbiome_table_with_ids <- function(table, id_column = "", transpose = FALSE) {
  table <- as.data.frame(table, stringsAsFactors = FALSE, check.names = FALSE)
  if (identical(id_column, ".__rownames__")) id_column <- ""
  if (identical(id_column, ".__colnames__")) {
    id_column <- ""
    transpose <- !transpose
  }
  if (nzchar(id_column) && id_column %in% names(table)) {
    ids <- make.unique(as.character(table[[id_column]]))
    table[[id_column]] <- NULL
    rownames(table) <- ids
  }
  if (transpose) table <- as.data.frame(t(as.matrix(table)), check.names = FALSE)
  table
}

microbiome_count_table_with_roles <- function(table, feature_source, sample_source) {
  feature_source <- feature_source %||% ".__colnames__"
  sample_source <- sample_source %||% ".__rownames__"
  feature_is_column <- identical(feature_source, ".__colnames__")
  feature_is_row <- identical(feature_source, ".__rownames__")
  sample_is_column <- identical(sample_source, ".__colnames__")
  sample_is_row <- identical(sample_source, ".__rownames__")
  if ((feature_is_column && sample_is_column) || (feature_is_row && sample_is_row)) {
    stop("The OTU feature ID and sample ID cannot both be from the same set of row or column names.", call. = FALSE)
  }
  feature_field <- nzchar(feature_source) && !startsWith(feature_source, ".__")
  sample_field <- nzchar(sample_source) && !startsWith(sample_source, ".__")
  if (feature_field && sample_field) stop("OTU feature ID and sample ID cannot select data columns at the same time.", call. = FALSE)
  transpose <- feature_is_row || sample_is_column || feature_field
  id_column <- if (feature_field) feature_source else if (sample_field) sample_source else ""
  microbiome_table_with_ids(table, id_column, transpose)
}

microbiome_representative_sequence_list <- function(value) {
  if (is.null(value) || !length(value)) return(NULL)
  if (is.list(value) && !is.data.frame(value)) {
    sequences <- value
  } else {
    table <- as.data.frame(value, stringsAsFactors = FALSE,
      check.names = FALSE)
    if (!nrow(table)) return(NULL)
    feature_column <- intersect(
      c("Feature", "FeatureID", "ASV", "OTU", "ID"), names(table))
    sequence_column <- intersect(
      c("Sequence", "sequence", "DNA", "Nucleotide"), names(table))
    if (!length(sequence_column)) {
      stop(
        "Representative sequence tables must contain the Sequence column.",
        call. = FALSE)
    }
    ids <- if (length(feature_column)) {
      as.character(table[[feature_column[[1]]]])
    } else {
      rownames(table)
    }
    sequences <- as.list(as.character(table[[sequence_column[[1]]]]))
    names(sequences) <- ids
  }
  ids <- trimws(names(sequences) %||% character())
  if (length(ids) != length(sequences) || any(!nzchar(ids)) ||
      anyDuplicated(ids)) {
    stop("Representative sequence Feature ID must be non-empty and unique.", call. = FALSE)
  }
  sequences <- lapply(sequences, function(sequence) {
    sequence <- toupper(gsub("[[:space:]-]+", "", paste(sequence,
      collapse = "")))
    if (!nzchar(sequence) ||
        !grepl("^[ACGTURYSWKMBDHVN]+$", sequence)) {
      stop("Representative sequences contain empty sequences or non-IUPAC nucleic acid characters.", call. = FALSE)
    }
    strsplit(sequence, "", fixed = TRUE)[[1]]
  })
  names(sequences) <- ids
  sequences
}

microbiome_representative_sequence_table <- function(value) {
  sequences <- microbiome_representative_sequence_list(value)
  if (is.null(sequences)) return(data.frame())
  sequence_text <- vapply(
    sequences, paste, collapse = "", FUN.VALUE = character(1))
  data.frame(
    Feature = names(sequences),
    Sequence = unname(sequence_text),
    Length = nchar(sequence_text),
    stringsAsFactors = FALSE, check.names = FALSE)
}

microbiome_bundle_from_inputs <- function(file_data, values) {
  count_name <- values$count_dataset %||% ""
  if (identical(count_name, ".__method_demo__")) return(microbiome_demo_for_method(values$method_id %||% "alpha_core"))
  if (identical(count_name, ".__demo16s__")) return(dava_local_demo_read("microbiome/base_16s.rds"))
  if (identical(count_name, ".__demoits__")) return(dava_local_demo_read("microbiome/base_its.rds"))
  count_table <- microbiome_dataset_get(file_data, count_name)
  feature_id <- values$feature_id %||% ""
  sample_id <- values$sample_id %||% ""
  has_role_mapping <- !is.null(values$otu_feature_id) || !is.null(values$otu_sample_id)
  counts <- if (has_role_mapping) {
    microbiome_count_table_with_roles(count_table, values$otu_feature_id, values$otu_sample_id)
  } else {
    transpose <- nzchar(feature_id) && feature_id %in% names(count_table)
    microbiome_table_with_ids(count_table, if (transpose) feature_id else sample_id, transpose)
  }
  taxonomy_name <- values$taxonomy_dataset %||% ""
  metadata_name <- values$metadata_dataset %||% ""
  if (startsWith(taxonomy_name, ".__bundle_")) taxonomy_name <- ""
  if (startsWith(metadata_name, ".__bundle_")) metadata_name <- ""
  taxonomy_id <- values$taxonomy_feature_id %||% feature_id
  metadata_id <- values$metadata_sample_id %||% sample_id
  taxonomy <- microbiome_table_with_ids(microbiome_dataset_get(file_data, taxonomy_name, TRUE), taxonomy_id)
  metadata <- microbiome_table_with_ids(microbiome_dataset_get(file_data, metadata_name, TRUE), metadata_id)
  environment <- microbiome_table_with_ids(microbiome_dataset_get(file_data, values$environment_dataset %||% "", TRUE), metadata_id)
  function_table <- microbiome_table_with_ids(microbiome_dataset_get(file_data, values$function_dataset %||% "", TRUE), metadata_id)
  functional_mapping <- microbiome_dataset_get(file_data, values$function_mapping_dataset %||% "", TRUE)
  phylogeny <- microbiome_phylogeny_dataset_get(
    file_data, values$phylogeny_dataset %||% "", TRUE)
  representative_sequences <- microbiome_representative_sequence_list(
    microbiome_dataset_get(
      file_data, values$sequence_dataset %||% "", TRUE))
  new_microbiome_bundle(counts, taxonomy = taxonomy, metadata = metadata,
    phylogeny = phylogeny, environment = environment,
    representative_sequences = representative_sequences,
    function_table = function_table, function_metadata = list(tool = "PICRUSt2", version = "user supplied", source_file = values$function_dataset %||% ""),
    functional_mapping = functional_mapping,
    marker_type = values$marker_type %||% "16S", data_version = count_name,
    provenance = list(source = "DAVA global dataset", count_dataset = count_name))
}

microbiome_input_values <- function(input) {
  ids <- microbiome_field_catalog()$id
  stats::setNames(lapply(ids, function(id) input[[id]]), ids)
}

microbiome_bundle_to_microeco <- function(bundle) {
  if (!requireNamespace("microeco", quietly = TRUE)) stop("microeco package is required.", call. = FALSE)
  aligned <- microbiome_align_bundle(bundle)$bundle
  counts <- microbiome_numeric_matrix(aligned$counts)
  sample_table <- as.data.frame(aligned$metadata, stringsAsFactors = FALSE, check.names = FALSE)
  if (!nrow(sample_table)) sample_table <- data.frame(SampleID = aligned$sample_ids, stringsAsFactors = FALSE)
  rownames(sample_table) <- aligned$sample_ids
  tax_table <- as.data.frame(aligned$taxonomy, stringsAsFactors = FALSE, check.names = FALSE)
  if (!nrow(tax_table)) tax_table <- data.frame(Feature = aligned$feature_ids, stringsAsFactors = FALSE)
  rownames(tax_table) <- aligned$feature_ids
  microeco::microtable[["new"]](sample_table = sample_table,
    otu_table = as.data.frame(t(counts), check.names = FALSE), tax_table = tax_table,
    phylo_tree = aligned$phylogeny,
    rep_fasta = microbiome_representative_sequence_list(
      aligned$representative_sequences),
    auto_tidy = TRUE)
}
