microbiome_method_nav_value <- function(method_id) paste0("microbiome_method_", method_id)

microbiome_colour_palettes <- function() {
  list(
    "Okabe-Ito (color blind friendly)" = c(
      "#000000", "#E69F00", "#56B4E9", "#009E73",
      "#F0E442", "#0072B2", "#D55E00", "#CC79A7"),
    "Nature / NPG" = c(
      "#E64B35", "#4DBBD5", "#00A087", "#3C5488", "#F39B7F",
      "#8491B4", "#91D1C2", "#DC0000", "#7E6148", "#B09C85"),
    "Lancet / NEJM" = c(
      "#00468B", "#ED0000", "#42B540", "#0099B4", "#925E9F",
      "#FDAF91", "#AD002A", "#ADB6B6", "#1B1919"),
    "Classic diffuse color" = c(
      "#2166AC", "#67A9CF", "#D1E5F0", "#F7F7F7",
      "#FDDBC7", "#EF8A62", "#B2182B"),
    "Neutral colors" = c(
      "#000000", "#333333", "#666666", "#999999",
      "#BDBDBD", "#E0E0E0", "#FFFFFF")
  )
}

microbiome_normalize_colour <- function(value, fallback = "#000000") {
  value <- trimws(as.character(value %||% fallback)[[1]])
  if (grepl("^#[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?$", value)) {
    return(toupper(value))
  }
  rgba <- tryCatch(
    grDevices::col2rgb(value, alpha = TRUE)[, 1],
    error = function(error) NULL
  )
  if (is.null(rgba)) return(toupper(fallback))
  if (rgba[[4]] < 255L) {
    sprintf("#%02X%02X%02X%02X", rgba[[1]], rgba[[2]], rgba[[3]], rgba[[4]])
  } else {
    sprintf("#%02X%02X%02X", rgba[[1]], rgba[[2]], rgba[[3]])
  }
}

microbiome_colour_input <- function(ns, input_id, label, value = "#000000") {
  full_id <- ns(input_id)
  value <- microbiome_normalize_colour(value)
  palettes <- microbiome_colour_palettes()
  palette_sections <- lapply(names(palettes), function(name) {
    colours <- palettes[[name]]
    shiny::div(
      class = "dava-colour-palette-section",
      shiny::div(class = "dava-colour-palette-title", name),
      shiny::div(
        class = "dava-network-colour-grid",
        lapply(colours, function(colour) {
          shiny::tags$button(
            type = "button",
            class = "dava-network-colour-swatch",
            `data-target` = full_id,
            `data-colour` = colour,
            title = colour,
            `aria-label` = paste("Select color", colour),
            style = paste0("background:", colour)
          )
        })
      )
    )
  })
  hex_input <- htmltools::tagQuery(shiny::textInput(
    full_id, label = NULL, value = value
  ))$find("input")$addClass("dava-network-colour-hex")$allTags()
  trigger <- shiny::tags$button(
    type = "button",
    class = "dava-network-colour-trigger",
    `data-target` = full_id,
    `aria-label` = paste(label, value),
    title = "Open color picker",
    style = paste0("background:", value)
  )
  picker <- bslib::popover(
    trigger,
    shiny::div(
      class = "dava-network-colour-popover",
      `data-target` = full_id,
      bslib::navset_pill(
        bslib::nav_panel(
          "Scientific palette",
          shiny::div(class = "dava-colour-palette-list", palette_sections)
        ),
        bslib::nav_panel(
          "Universal Color Picker",
          shiny::tags$input(
            type = "color",
            value = substr(value, 1L, 7L),
            class = "dava-network-colour-mixer",
            `data-target` = full_id
          )
        ),
        bslib::nav_panel(
          "Gradient",
          shiny::div(
            class = "dava-network-gradient-panel",
            `data-target` = full_id,
            shiny::div(
              class = "dava-gradient-inputs",
              shiny::tags$label(
                "Starting color",
                shiny::tags$input(
                  type = "color", value = "#2166AC",
                  class = "dava-gradient-start"
                )
              ),
              shiny::tags$label(
                "End color",
                shiny::tags$input(
                  type = "color", value = "#B2182B",
                  class = "dava-gradient-end"
                )
              ),
              shiny::tags$label(
                "Step count",
                shiny::tags$input(
                  type = "number", value = 7, min = 3, max = 15,
                  class = "dava-gradient-steps"
                )
              )
            ),
            shiny::div(class = "dava-gradient-preview"),
            shiny::div(class = "dava-gradient-swatches")
          )
        )
      )
    ),
    title = label,
    placement = "left"
  )
  control <- shiny::div(
    class = "dava-network-colour-control dava-microbiome-colour-control",
    shiny::tags$label(class = "control-label", `for` = full_id, label),
    shiny::div(class = "dava-network-colour-row", picker, hex_input)
  )
  htmltools::attachDependencies(
    control,
    htmltools::htmlDependency(
      name = "dava-network-colour-picker",
      version = "1.1.0",
      src = c(file = file.path(microbiome_project_root, "www")),
      script = "dava_network_colour_picker.js",
      stylesheet = "dava_network_colour_picker.css"
    )
  )
}

microbiome_method_from_nav_value <- function(value) {
  prefix <- "microbiome_method_"
  if (!is.character(value) || length(value) != 1L || !startsWith(value, prefix)) return("")
  method_id <- substring(value, nchar(prefix) + 1L)
  if (method_id %in% MICROBIOME_METHOD_REGISTRY$id) method_id else ""
}

microbiome_navbar_menu <- function() {
  categories <- microbiome_category_registry()
  panels <- microbiome_panel_registry()
  category_menus <- lapply(seq_len(nrow(categories)), function(index) {
    category_id <- categories$id[[index]]
    category_panels <- panels[panels$secondary_category == category_id, , drop = FALSE]
    panel_items <- lapply(seq_len(nrow(category_panels)), function(panel_index) {
      panel_id <- category_panels$id[[panel_index]]
      bslib::nav_panel(category_panels$label_cn[[panel_index]],
        value = microbiome_panel_nav_value(panel_id),
        shiny::uiOutput(paste0("lazy_", microbiome_panel_nav_value(panel_id))))
    })
    if (identical(category_id, "composition_differential") && length(panel_items) == 1L) {
      return(bslib::nav_panel(
        categories$label_cn[[index]],
        value = microbiome_panel_nav_value(category_panels$id[[1]]),
        shiny::uiOutput(paste0("lazy_", microbiome_panel_nav_value(category_panels$id[[1]])))
      ))
    }
    do.call(shiny::navbarMenu, c(list(title = categories$label_cn[[index]]), panel_items))
  })
  do.call(shiny::navbarMenu, c(list(title = "Microbiome analysis"), category_menus))
}

mod_microbiome_framework_ui <- function(id, category_id, panel_id = "") {
  ns <- shiny::NS(id)
  panels <- microbiome_panel_registry()
  categories <- microbiome_category_registry()
  panel_label <- panels$label_cn[match(panel_id, panels$id)]
  title <- if (length(panel_label) && !is.na(panel_label)) panel_label else
    categories$label_cn[match(category_id, categories$id)] %||% category_id
  choices <- if (nzchar(panel_id)) microbiome_panel_method_choices(category_id, panel_id, TRUE) else
    microbiome_category_method_choices(category_id, TRUE)
  is_alpha <- identical(panel_id, "alpha_diversity")
  is_beta <- identical(panel_id, "beta_diversity")
  is_phylogenetic <- identical(panel_id, "phylogenetic_diversity")
  is_composition <- category_id == "composition_differential"
  is_species_environment <- identical(panel_id, "multivariable_association")
  is_community_assembly <- identical(panel_id, "community_assembly")
  is_bacterial_function <- identical(panel_id, "bacterial_function")
  is_network <- panel_id %in% c("microbial_network", "cross_domain_network")
  is_cross_domain <- identical(panel_id, "cross_domain_network")
  is_custom_diversity <- is_alpha || is_beta || is_phylogenetic
  method_selector <- if (is_alpha || is_beta) {
    shiny::div(style = "display:none;", shiny::selectInput(ns("method_id"), NULL, "alpha_core", selected = "alpha_core"))
  } else {
    shiny::selectInput(ns("method_id"), "Analysis method", choices)
  }
  if (is_beta) {
    method_selector <- shiny::div(style = "display:none;",
      shiny::selectInput(ns("method_id"), NULL, choices, selected = unname(choices)[[1]]))
  }
  if (is_composition) {
    method_selector <- shiny::div(style = "display:none;",
      shiny::selectInput(ns("method_id"), NULL, choices, selected = unname(choices)[[1]]))
  }
  if (is_network) {
    method_selector <- shiny::div(style = "display:none;",
      shiny::selectInput(ns("method_id"), NULL, choices,
        selected = if (is_cross_domain) {
          "cross_domain_network"
        } else {
          "netcomi_network"
        }))
  }
  sidebar_content <- if (is_alpha) {
    shiny::tagList(
      method_selector,
      shiny::tags$h4(class = "mb-3", "Alpha Diversity"),
      shiny::uiOutput(ns("alpha_sidebar")))
  } else if (is_beta) {
    shiny::tagList(
      shiny::tags$h4(class = "mb-3", "Beta Diversity"),
      shiny::uiOutput(ns("beta_data_sidebar")),
      shiny::tags$hr(class = "my-3"),
      shiny::tags$h6(class = "fw-semibold mb-2", "Analysis settings"),
      method_selector,
      shiny::uiOutput(ns("method_status")),
      shiny::uiOutput(ns("beta_analysis_sidebar")))
  } else if (is_phylogenetic) {
    shiny::tagList(
      shiny::tags$h4(class = "mb-3", "Phylogenetic diversity"),
      shiny::uiOutput(ns("phylogenetic_data_sidebar")),
      shiny::tags$hr(class = "my-3"),
      shiny::tags$h6(class = "fw-semibold mb-2", "Statistical analysis"),
      method_selector,
      shiny::uiOutput(ns("method_status")),
      shiny::uiOutput(ns("phylogenetic_analysis_sidebar")))
  } else {
    shiny::tagList(
      shiny::tags$h4(class = "mb-3", title),
      shiny::uiOutput(ns("general_data_sidebar")),
      shiny::tags$hr(class = "my-3"),
      shiny::tags$h6(class = "fw-semibold mb-2", "Analysis settings"),
      if (!is_species_environment && !is_network) method_selector,
      shiny::uiOutput(ns("method_status")),
      shiny::uiOutput(ns("general_analysis_sidebar")))
  }
  input_data_preview <- shiny::tagList(
    shiny::uiOutput(ns("input_data_controls")),
    DT::DTOutput(ns("input_data"))
  )
  input_second_data_preview <- shiny::tagList(
    shiny::uiOutput(ns("input_second_data_controls")),
    DT::DTOutput(ns("input_second_data"))
  )
  input_tabs <- if (is_cross_domain) {
    bslib::navset_card_tab(
      bslib::nav_panel(
        "16S bacterial abundance", input_data_preview),
      bslib::nav_panel(
        "16S Bacteria Annotation", DT::DTOutput(ns("input_taxonomy"))),
      bslib::nav_panel(
        "ITS fungal abundance", input_second_data_preview),
      bslib::nav_panel(
        "ITS Fungi Notes", DT::DTOutput(ns("input_second_taxonomy"))),
      bslib::nav_panel(
        "shared metadata", DT::DTOutput(ns("input_metadata"))),
      bslib::nav_panel(
        "Aggregated data for bacterial-fungal matches",
        DT::DTOutput(ns("preprocessed_data")))
    )
  } else {
    bslib::navset_card_tab(
      bslib::nav_panel("Abundance table", input_data_preview),
      bslib::nav_panel("Classification Notes", DT::DTOutput(ns("input_taxonomy"))),
      if (is_community_assembly) {
        bslib::nav_panel("Phylogenetic tree", DT::DTOutput(ns("input_phylogeny")))
      },
      if (is_bacterial_function) {
        bslib::nav_panel(
          "Representative sequence", DT::DTOutput(ns("input_sequences")))
      },
      bslib::nav_panel("sample metadata", DT::DTOutput(ns("input_metadata"))),
      bslib::nav_panel("Environment variables", DT::DTOutput(ns("input_environment"))),
      bslib::nav_panel("Function/auxiliary data", DT::DTOutput(ns("input_auxiliary"))),
      bslib::nav_panel(
        if (is_species_environment || is_network) {
          "Classified aggregated data"
        } else {
          "Preprocess data"
        },
        DT::DTOutput(ns("preprocessed_data")))
    )
  }
  bslib::page_sidebar(
    title = NULL,
    sidebar = bslib::sidebar(
      sidebar_content,
      shiny::div(class = "d-grid gap-2 mb-2",
        shiny::actionButton(ns("open_preprocessing"), "Data inspection and preprocessing", icon = shiny::icon("filter"), class = "btn-outline-secondary"),
        shiny::actionButton(ns("open_advanced"), "Advanced parameters", icon = shiny::icon("sliders"), class = "btn-outline-secondary"),
        dava_dependency_button_ui(ns, class = "btn-outline-secondary")
      ),
      shiny::uiOutput(ns("package_status")),
      shiny::uiOutput(ns("preprocessing_summary")),
      shiny::uiOutput(ns("analysis_action")),
      shiny::actionButton(ns("register_results"), "Add to data table repository", icon = shiny::icon("plus"),
        title = "Add to data table repository", class = "btn-success w-100 mt-2"),
      shiny::downloadButton(ns("download_results"), "Download analysis results table", icon = shiny::icon("download"), class = "btn-success w-100 mt-2"),
      width = 350
    ),
    bslib::navset_card_tab(
      bslib::nav_panel("Enter data", input_tabs),
      bslib::nav_panel("Main results", shiny::uiOutput(ns("result_type")), DT::DTOutput(ns("result_table"))),
      bslib::nav_panel("Plot", shiny::uiOutput(ns("plot_panel"))),
      bslib::nav_panel("Model text", shiny::verbatimTextOutput(ns("model_text"))),
      bslib::nav_panel("R Markdown code document", dava_module_code_panel_ui(ns)),
      bslib::nav_panel("Method Description", shiny::uiOutput(ns("method_description"))),
      bslib::nav_panel("Diagnostics and Errors", shiny::verbatimTextOutput(ns("messages")))
    )
  )
}
microbiome_core_field_catalog <- function() {
  data.frame(
    id = c("marker_type", "count_dataset", "taxonomy_dataset", "metadata_dataset", "environment_dataset", "function_dataset", "function_mapping_dataset",
           "phylogeny_dataset", "sequence_dataset", "second_microbiome_dataset", "sample_id", "feature_id",
           "group", "treatment", "block", "site", "degradation", "subject_or_plot_id", "time",
           "fixed_effects", "covariates", "random_effects", "interaction_terms", "source_sink_role",
           "taxonomic_rank", "transform", "minimum_total", "minimum_prevalence", "permutations", "seed"),
    section = c(rep("data", 10), rep("roles", 14), rep("parameters", 6)),
    label_cn = c("Amplicon type", "OTU/ASV abundance table", "Classification annotation table", "sample metadata", "Environment variable table", "Functional abundance results table", "Local classification-function mapping table", "Phylogenetic tree",
                 "represents the sequence", "Second microbial data set", "Sample ID", "Feature ID", "Grouping variables", "Process variables", "Block variable",
                 "location variable", "Degenerate gradient", "Subject/Plot ID", "time variable", "Fixed effects", "Covariates", "Random effects",
                 "interaction terms", "Source/Sink role", "Classification hierarchy", "Data conversion", "Minimum total abundance", "Minimum prevalence", "Number of replacements", "Random seed"),
    stringsAsFactors = FALSE
  )
}

microbiome_core_method_field_ids <- function(method) {
  ids <- c("marker_type", "count_dataset", "sample_id", "feature_id", "taxonomic_rank", "transform", "minimum_total", "minimum_prevalence", "seed")
  if (isTRUE(method$taxonomy_required)) ids <- c(ids, "taxonomy_dataset")
  if (isTRUE(method$metadata_required)) ids <- c(ids, "metadata_dataset", "group")
  if (isTRUE(method$environment_table_required)) ids <- c(ids, "environment_dataset", "fixed_effects", "covariates")
  if (isTRUE(method$function_table_required)) ids <- c(ids, "function_dataset")
  if (isTRUE(method$function_mapping_required)) ids <- c(ids, "function_mapping_dataset")
  if (method$secondary_category %in% c("beta", "environment_spatial") || method$id == "bnti_rcbray") ids <- c(ids, "permutations")
  if (isTRUE(method$phylogeny_required)) ids <- c(ids, "phylogeny_dataset")
  if (isTRUE(method$representative_sequences_required)) ids <- c(ids, "sequence_dataset")
  if (isTRUE(method$longitudinal_required)) ids <- c(ids, "subject_or_plot_id", "time", "treatment", "block")
  if (isTRUE(method$source_sink_required)) ids <- c(ids, "source_sink_role")
  if (isTRUE(method$second_microbiome_dataset_required)) ids <- c(ids, "second_microbiome_dataset")
  unique(ids)
}

microbiome_core_field_ui <- function(field_id, ns, context = list()) {
  language <- dava_i18n_language(context$language %||% "en")
  tr <- function(text) dava_translate_text(text, language)
  label <- tr(microbiome_field_catalog()$label_cn[
    match(field_id, microbiome_field_catalog()$id)] %||% field_id)
  datasets <- context$datasets %||% character()
  current <- context$current_values[[field_id]]
  switch(field_id,
    marker_type = shiny::selectInput(ns(field_id), label, c("16S" = "16S", "ITS" = "ITS"), selected = current %||% "16S"),
    count_dataset = shiny::selectInput(ns(field_id), label,
      c(stats::setNames(".__method_demo__", dava_translate_composed(
        context$demo_label %||% "Simulation data specific to the current method", language
      )), datasets),
      selected = current %||% ".__method_demo__"),
    taxonomy_dataset = shiny::selectInput(ns(field_id), label, c(stats::setNames("", tr("Not used")), datasets), selected = current %||% ""),
    metadata_dataset = shiny::selectInput(ns(field_id), label, c(stats::setNames("", tr("Not used")), datasets), selected = current %||% ""),
    environment_dataset = shiny::selectInput(ns(field_id), label, c(stats::setNames("", tr("Not used")), datasets), selected = current %||% ""),
    function_dataset = shiny::selectInput(ns(field_id), label, c(stats::setNames("", tr("Not provided")), datasets), selected = current %||% ""),
    function_mapping_dataset = shiny::selectInput(ns(field_id), label, c(stats::setNames("", tr("Using mock data in-mapping")), datasets), selected = current %||% ""),
    phylogeny_dataset = shiny::selectInput(ns(field_id), label, c(stats::setNames("", tr("Not provided")), datasets), selected = current %||% ""),
    sequence_dataset = {
      sequence_datasets <- context$sequence_datasets %||% datasets
      selected <- current %||% context$default_sequence_dataset %||% ""
      if (!selected %in% sequence_datasets) {
        selected <- context$default_sequence_dataset %||% ""
      }
      shiny::selectInput(
        ns(field_id), label, c(stats::setNames("", tr("Not provided")), sequence_datasets),
        selected = selected)
    },
    second_microbiome_dataset = shiny::selectInput(ns(field_id), label, c("Not provided" = "", datasets), selected = current %||% ""),
    taxonomic_rank = shiny::selectInput(ns(field_id), label, c("ASV/OTU" = "feature", "Phylum", "Class", "Order", "Family", "Genus", "Species"), selected = current %||% "feature"),
    transform = shiny::selectInput(ns(field_id), label, c("Not converted" = "none", "relative abundance" = "relative", "Hellinger" = "hellinger", "CLR" = "clr", "rCLR" = "rclr", "Presence/absence" = "presence_absence"), selected = current %||% "none"),
    minimum_total = shiny::numericInput(ns(field_id), label, current %||% 10, min = 0),
    minimum_prevalence = shiny::sliderInput(ns(field_id), label, 0, 1, current %||% 0.1, 0.01),
    permutations = shiny::numericInput(ns(field_id), label, current %||% 999, min = 99),
    seed = shiny::numericInput(ns(field_id), label, current %||% 2026, min = 1),
    source_sink_role = shiny::selectInput(ns(field_id), label, c("Source", "Sink"), selected = current %||% "Source"),
    {
      role_choices <- context$field_choices[[field_id]] %||% context$columns %||% character()
      selected <- intersect(current %||% character(), role_choices)
      if (!length(selected) && field_id %in% c("group", "treatment")) {
        preferred <- intersect(c("Treatment", "Group"), role_choices)
        selected <- if (length(preferred)) preferred[[1]] else utils::head(role_choices, 1L)
      }
      if (!length(selected) && identical(field_id, "fixed_effects")) selected <- utils::head(role_choices, 2L)
      shiny::selectizeInput(ns(field_id), label, choices = role_choices,
      selected = selected,
      multiple = field_id %in% c("fixed_effects", "covariates", "random_effects", "interaction_terms"))
    }
  )
}
microbiome_field_catalog <- function() {
  base <- microbiome_core_field_catalog()
  conditional <- data.frame(
    id = c("distance_method", "ordination_method", "test_method", "normalization_method",
      "model_engine", "functional_database", "network_method", "null_model_method", "ml_algorithm",
      "preprocess_strategy", "rarefaction_depth", "pseudocount", "p_adjust_method", "alpha_index",
      "posthoc_method", "formula_terms", "permutation_strata", "network_threshold", "network_fdr",
      "model_family", "random_structure", "spline_k", "n_iterations", "n_cores"),
    section = c(rep("method", 9), rep("preprocessing", 3), rep("advanced", 12)),
    label_cn = c("Distance or similarity algorithm", "Sorting method", "Statistical test methods", "Standardization or conversion method",
      "Model Engine", "Function database", "Network inference method", "Randomization or null model method", "Machine learning algorithm",
      "Preprocessing strategy", "Leveling depth", "CLR pseudo count", "P value correction", "Alpha indicator", "post-mortem",
      "model item", "Replace stratification variables", "Network related thresholds", "Network FDR Threshold", "Model distribution family",
      "Random effects structure", "Smoothing base dimension k", "Number of iterations/randomizations", "Number of CPU cores"),
    stringsAsFactors = FALSE
  )
  rbind(base, conditional)
}

microbiome_method_field_ids <- function(method) {
  ids <- microbiome_core_method_field_ids(method)
  panel <- method$navigation_panel[[1]] %||% method$tertiary_panel[[1]] %||% ""
  if (panel %in% c("beta_diversity", "community_environment", "community_assembly")) {
    ids <- c(ids, "distance_method")
  }
  if (panel %in% c("beta_diversity", "community_environment")) ids <- c(ids, "ordination_method")
  if (panel %in% c("alpha_diversity", "beta_diversity", "phylogenetic_diversity", "exploratory_composition")) ids <- c(ids, "test_method")
  if (panel %in% c("beta_diversity",
      "multivariable_association", "microbial_network", "cross_domain_network")) ids <- c(ids, "normalization_method")
  if (panel %in% c("alpha_diversity", "species_environment_response",
      "multivariable_association")) ids <- c(ids, "model_engine")
  if (panel %in% c("bacterial_function", "fungal_function")) {
    ids <- c(ids, "functional_database")
  }
  if (panel %in% c("microbial_network", "cross_domain_network")) ids <- c(ids, "network_method")
  if (panel %in% c("phylogenetic_diversity", "community_assembly", "niche_breadth")) {
    ids <- c(ids, "null_model_method")
  }
  unique(ids)
}

microbiome_field_ui <- function(field_id, ns, context = list()) {
  label <- microbiome_field_catalog()$label_cn[match(field_id, microbiome_field_catalog()$id)] %||% field_id
  current <- context$current_values[[field_id]]
  if (identical(field_id, "permutation_strata")) {
    metadata <- as.data.frame(context$metadata %||% data.frame(),
      check.names = FALSE)
    choices <- names(metadata)[vapply(metadata, function(value) {
      level_count <- length(unique(value[!is.na(value)]))
      level_count >= 2L && level_count <= 100L &&
        (is.factor(value) || is.character(value) || is.logical(value) ||
          level_count <= 20L)
    }, logical(1))]
    choices <- utils::head(choices, 100L)
    selected <- current %||% ""
    if (!selected %in% choices) selected <- ""
    return(shiny::selectInput(
      ns(field_id), label,
      choices = c("None" = "", stats::setNames(choices, choices)),
      selected = selected))
  }
  choices <- switch(field_id,
    distance_method = c("Bray-Curtis" = "bray", "Jaccard" = "jaccard", "Sorensen" = "sorensen",
      "Euclidean" = "euclidean", "Hellinger" = "hellinger", "Aitchison" = "aitchison",
      "Weighted UniFrac" = "weighted_unifrac", "Unweighted UniFrac" = "unweighted_unifrac", "Generalized UniFrac" = "generalized_unifrac"),
    ordination_method = c("Not sorted" = "none", "PCoA" = "pcoa", "NMDS" = "nmds", "PCA" = "pca", "robust Aitchison PCA" = "rpca", "RDA" = "rda", "CCA" = "cca", "dbRDA/CAP" = "dbrda"),
    test_method = c("PERMANOVA" = "permanova", "ANOSIM" = "anosim", "MRPP" = "mrpp", "t-test" = "t_test", "Welch" = "welch", "Wilcoxon" = "wilcoxon", "ANOVA" = "anova", "Kruskal-Wallis" = "kruskal"),
    normalization_method = c("Not converted" = "none", "Relative abundance/TSS" = "relative", "Hellinger" = "hellinger", "presence-absence" = "presence_absence", "log1p" = "log1p", "CLR" = "clr", "robust CLR" = "rclr", "ALR" = "alr", "ILR" = "ilr"),
    model_engine = c("Automatic (by capability)" = "auto", "lm" = "lm", "glm" = "glm", "lme4" = "lme4", "glmmTMB" = "glmmTMB", "mgcv" = "mgcv", "MaAsLin2" = "maaslin2"),
    functional_database = c("FAPROTAX" = "faprotax", "Tax4Fun2" = "tax4fun2", "PICRUSt2 results" = "picrust2", "FUNGuild" = "funguild", "FungalTraits" = "fungaltraits", "Custom versioned database" = "custom"),
    network_method = c("Spearman" = "spearman", "Pearson" = "pearson", "partial correlation" = "partial", "SparCC" = "sparcc", "SPIEC-EASI" = "spieceasi", "SPRING" = "spring", "NetCoMi" = "netcomi"),
    null_model_method = c("taxa labels" = "taxa.labels", "richness" = "richness", "frequency" = "frequency", "independent swap" = "independentswap", "trial swap" = "trialswap", "sample pool" = "sample.pool", "phylogeny pool" = "phylogeny.pool"),
    ml_algorithm = c("Random Forest" = "random_forest", "Elastic Net" = "elastic_net", "LASSO" = "lasso", "XGBoost" = "xgboost", "SVM" = "svm", "PLS-DA" = "plsda", "sPLS-DA" = "splsda"),
    preprocess_strategy = c("Not processed" = "none", "Draw a draw" = "rarefy", "Hellinger" = "hellinger", "CLR" = "clr", "relative abundance" = "relative", "Presence/absence" = "presence_absence"),
    p_adjust_method = c("FDR (BH)" = "BH", "Bonferroni" = "bonferroni", "Holm" = "holm", "No correction" = "none"),
    alpha_index = c("Observed" = "Observed", "Chao1" = "Chao1", "ACE" = "ACE", "Shannon" = "Shannon", "Simpson" = "Simpson", "Inverse Simpson" = "InverseSimpson", "Hill q0" = "Hill_q0", "Hill q1" = "Hill_q1", "Hill q2" = "Hill_q2", "Pielou" = "Pielou"),
    posthoc_method = c("Automatic" = "auto", "Tukey HSD" = "tukey", "Dunn" = "dunn", "None" = "none"),
    model_family = c("Gaussian" = "gaussian", "Binomial" = "binomial", "Poisson" = "poisson", "Negative binomial" = "nbinom2"),
    NULL
  )
  if (!is.null(choices)) {
    selected <- if (length(current) && current %in% unname(choices)) current else unname(choices)[1]
    return(shiny::selectInput(ns(field_id), label, choices, selected = selected))
  }
  if (field_id == "rarefaction_depth") return(shiny::numericInput(ns(field_id), label, current %||% 1000, min = 1, step = 1))
  if (field_id == "pseudocount") return(shiny::numericInput(ns(field_id), label, current %||% 0.5, min = 1e-08))
  if (field_id == "network_threshold") return(shiny::sliderInput(ns(field_id), label, 0, 1, current %||% 0.6, 0.01))
  if (field_id == "network_fdr") return(shiny::sliderInput(ns(field_id), label, 0.001, 0.2, current %||% 0.05, 0.001))
  if (field_id == "spline_k") return(shiny::numericInput(ns(field_id), label, current %||% 5, min = 3, step = 1))
  if (field_id == "n_iterations") return(shiny::numericInput(ns(field_id), label, current %||% 999, min = 99, step = 100))
  if (field_id == "n_cores") return(shiny::numericInput(ns(field_id), label, current %||% 1, min = 1, step = 1))
  if (field_id == "ncm_simplify") {
    return(shiny::checkboxInput(ns(field_id), "ncmR::fit_ncm simplify", isTRUE(current %||% TRUE)))
  }
  if (field_id == "ncm_return_model") {
    return(shiny::checkboxInput(ns(field_id), "ncmR::fit_ncm return_model", isTRUE(current %||% FALSE)))
  }
  if (field_id == "ncm_group_col") {
    return(shiny::textInput(ns(field_id), "ncmR::fit_ncm group_col", current %||% "group"))
  }
  if (field_id == "ncm_groups") {
    choices <- context$group_levels %||% character()
    return(shiny::selectizeInput(
      ns(field_id), "ncmR::fit_ncm groups", choices = choices,
      selected = intersect(current %||% character(), choices),
      multiple = TRUE, options = list(
      plugins = list("remove_button"), closeAfterSelect = FALSE)))
  }
  if (field_id == "ncm_data_type") {
    return(shiny::selectInput(ns(field_id), "Data type",
      c("Relative abundance (multinomial resampling)" = "relative",
        "Count" = "count"), current %||% "relative"))
  }
  if (field_id == "ncm_scale_factor") {
    return(shiny::numericInput(ns(field_id), "Scale factor",
      current %||% 10000L, min = 100L, step = 100L))
  }
  if (field_id == "ncm_seed") {
    return(shiny::numericInput(ns(field_id), "Random seed",
      current %||% 2026L, min = 1L, step = 1L))
  }
  if (field_id == "ncm_maxiter") {
    return(shiny::numericInput(ns(field_id), "nlsLM max iterations",
      current %||% 1000L, min = 100L, step = 100L))
  }
  if (field_id == "ncm_start_m") {
    return(shiny::numericInput(ns(field_id), "Initial migration rate (m)",
      current %||% 0.1, min = 0.000001, max = 0.999999, step = 0.01))
  }
  if (field_id == "ncm_lower_m") {
    return(shiny::numericInput(ns(field_id), "Lower bound for m",
      current %||% 0.000001, min = 0.00000001, max = 0.99, step = 0.000001))
  }
  if (field_id == "ncm_upper_m") {
    return(shiny::numericInput(ns(field_id), "Upper bound for m",
      current %||% 0.999999, min = 0.01, max = 0.9999999, step = 0.000001))
  }
  if (field_id == "ncm_conf_level") {
    return(shiny::sliderInput(ns(field_id), "Confidence level",
      min = 0.8, max = 0.99, value = current %||% 0.95, step = 0.01))
  }
  if (field_id %in% c("ncm_point_size", "ncm_point_alpha",
      "ncm_fit_line_width", "ncm_ci_line_width",
      "ncm_annotation_size", "ncm_axis_title_size",
      "ncm_axis_text_size")) {
    defaults <- c(ncm_point_size = 1.5, ncm_point_alpha = 0.8,
      ncm_fit_line_width = 0.8, ncm_ci_line_width = 0.8,
      ncm_annotation_size = 5, ncm_axis_title_size = 14,
      ncm_axis_text_size = 12)
    return(shiny::numericInput(ns(field_id), field_id,
      current %||% defaults[[field_id]], min = 0.1, step = 0.1))
  }
  if (field_id %in% c("ncm_fit_line_colour", "ncm_ci_line_colour")) {
    return(microbiome_colour_input(
      ns, field_id, field_id, current %||% "black"))
  }
  microbiome_core_field_ui(field_id, ns, context)
}

microbiome_sidebar_field_ids <- function(method) {
  all_ids <- microbiome_method_field_ids(method)
  advanced <- microbiome_advanced_field_ids(method)
  preprocessing <- c("transform", "minimum_total", "minimum_prevalence", "normalization_method",
    "preprocess_strategy", "rarefaction_depth", "pseudocount")
  setdiff(all_ids, c(advanced, preprocessing))
}

microbiome_method_sidebar_schema <- function(method) {
  panel <- method$navigation_panel[[1]] %||% ""
  method_id <- method$id[[1]] %||% ""
  available <- microbiome_method_field_ids(method)
  fields <- switch(panel,
    exploratory_composition = c("taxonomic_rank", "group"),
    multivariable_association = c("group", "fixed_effects", "covariates", "random_effects"),
    community_environment = "fixed_effects",
    species_environment_response = c("fixed_effects", "covariates", "random_effects"),
    microbial_network = c("taxonomic_rank",
      if (method_id %in% c("grouped_network", "network_comparison", "differential_edges")) "group"),
    cross_domain_network = c("taxonomic_rank", "group"),
    bacterial_function = c("taxonomic_rank", "functional_database", "group"),
    fungal_function = c("taxonomic_rank", "functional_database", "group"),
    community_assembly = c("group", "source_sink_role"),
    niche_breadth = c("group"),
    character()
  )
  fields <- intersect(fields, available)
  list(
    panel = panel,
    method_id = method_id,
    fields = fields,
    formula_label = if (panel %in% c("microbial_network", "cross_domain_network",
      "bacterial_function", "fungal_function", "community_assembly", "niche_breadth")) {
      "Analyze expressions"
    } else "Model formula / analytical expression"
  )
}

microbiome_composition_method_groups <- function(panel_id, include_planned = TRUE) {
  available <- unname(microbiome_panel_method_choices(
    "composition_differential", panel_id, include_planned = include_planned))
  groups <- switch(panel_id,
    exploratory_composition = list(
      composition_profile = c("taxonomic_composition", "core_microbiome"),
      univariate_test = c("wilcoxon_kruskal", "anova_welch"),
      indicator_discovery = c("indicator_taxa", "lefse", "differential_indicator_species"),
      set_comparison = c("shared_unique_features", "venn_upset"),
      bias_corrected = "ancombc2"),
    list()
  )
  lapply(groups, intersect, y = available)
}

microbiome_composition_task_choices <- function(panel_id, include_planned = TRUE) {
  labels <- c(
    composition_profile = "Composition and core group display",
    univariate_test = "Univariate abundance difference test",
    indicator_discovery = "Indicator groups and biomarkers",
    set_comparison = "Common and unique characteristics",
    bias_corrected = "Bias-corrected compositional model",
    log_ratio_model = "Log ratio and component regression"
  )
  groups <- microbiome_composition_method_groups(panel_id, include_planned)
  groups <- groups[lengths(groups) > 0L]
  stats::setNames(names(groups), unname(labels[names(groups)]))
}

microbiome_composition_significance_choices <- function(method_id, metadata = data.frame(), group = "") {
  levels <- if (nzchar(group) && group %in% names(metadata))
    nlevels(droplevels(factor(metadata[[group]]))) else 0L
  switch(method_id,
    taxonomic_composition = c("Descriptive composition display (not inspected)" = "none"),
    core_microbiome = c("Abundance-prevalence threshold determination (not tested)" = "none"),
    indicator_taxa = c("IndVal.g permutation test" = "indval_permutation"),
    wilcoxon_kruskal = if (levels == 2L) c("Wilcoxon rank-sum test" = "wilcoxon") else
      c("Kruskal-Wallis test" = "kruskal"),
    anova_welch = if (levels == 2L) c("Welch two-sample t-test" = "welch_t") else
      c("Welch one-way ANOVA" = "welch_anova"),
    ancombc2 = c("ANCOM-BC2 bias-corrected Wald test" = "wald_bias_corrected"),
    ancombc = c("ANCOM-BC bias-corrected Wald test" = "wald_bias_corrected"),
    linda = c("LinDA moderated linear-model test" = "linda_wald"),
    aldex2 = c("ALDEx2 Welch/Wilcoxon Monte Carlo test" = "aldex2_mc"),
    corncob = c("Corncob Wald or likelihood-ratio test" = "corncob_wald"),
    lefse = c("Kruskal-Wallis + Wilcoxon + LDA" = "lefse"),
    differential_indicator_species = c("Indicator-value permutation test" = "indval_permutation"),
    c("This method does not configure additional significance tests" = "none")
  )
}

microbiome_species_composition_method_choices <- function() c(
  "Abundance composition" = "taxonomic_composition",
  "Differential taxa" = "ancombc2",
  "LEfSe Analysis" = "lefse",
  "Indicator species" = "indicator_taxa",
  "Set analysis" = "venn_upset"
)

microbiome_ancombc2_mode_choices <- function() c(
  "Two-group comparison" = "two_group",
  "Multi-group global test" = "global",
  "All pairwise comparisons" = "pairwise",
  "Dunnett-type control comparisons" = "dunnett",
  "Ordered trend test" = "trend"
)

microbiome_ancombc2_plot_choices <- function(mode = "two_group") {
  common <- c(
    "Differential-taxa bubble plot" = "differential_bubble",
    "Relative-abundance boxplot / violin plot" = "abundance_distribution",
    "Differential-taxa sample heatmap" = "sample_heatmap",
    "ANCOM-BC2 taxonomy tree (not LEfSe)" = "taxonomy_tree"
  )
  switch(mode,
    two_group = c(
      "Two-group volcano plot" = "volcano",
      "Two-group forest plot" = "two_group_forest",
      common
    ),
    global = c(
      "Global-test summary" = "global_summary",
      common
    ),
    pairwise = c(
      "Pairwise LFC heatmap" = "pairwise_heatmap",
      common,
      "Significant-taxa UpSet plot" = "contrast_upset"
    ),
    dunnett = c(
      "Dunnett-type forest plot" = "dunnett_forest",
      common,
      "Significant-taxa UpSet plot" = "contrast_upset"
    ),
    trend = c(
      "Trend-mode heatmap" = "trend_heatmap",
      "Faceted taxon trajectories" = "trend_trajectory",
      common
    ),
    c("Two-group volcano plot" = "volcano", common)
  )
}

microbiome_ancombc2_resolve_plot_types <- function(mode, requested = character()) {
  allowed <- unname(microbiome_ancombc2_plot_choices(mode))
  requested <- as.character(requested %||% character())
  selected <- intersect(requested[!is.na(requested) & nzchar(requested)], allowed)
  if (length(selected)) selected else utils::head(allowed, 1L)
}

microbiome_species_composition_plot_choices <- function(method_id,
    analysis_mode = "two_group", differential_method = "ancombc2") {
  switch(method_id,
    taxonomic_composition = c(
      "Grouped stacked column chart" = "stacked_bar", "Grouped Bar Chart" = "grouped_bar",
      "Composition heat map" = "composition_heatmap", "Grouped box plot" = "abundance_boxplot",
      "Bubble chart" = "bubble",
      "Sankey diagram" = "sankey", "Rising Sun Chart" = "sunburst", "Ternary diagram" = "ternary"),
    ancombc2 = microbiome_differential_taxa_plot_choices(
      differential_method, analysis_mode),
    lefse = c("LDA score histogram" = "lda_bar", "Evolutionary branch cladogram diagram" = "cladogram"),
    indicator_taxa = c(
      "Indicator species bar chart" = "indicator_bar", "Indicator species abundance boxplot" = "indicator_boxplot",
      "Indicator species abundance heat map" = "indicator_heatmap", "Dot plot (bubble chart)" = "indicator_bubble",
      "Classification hierarchy tree diagram / circular evolution diagram" = "indicator_tree", "Bipartite network diagram" = "indicator_network",
      "UpSet / Venn linkage diagram" = "indicator_set"),
    venn_upset = c(
      "Venn diagram" = "venn", "UpSet graph" = "upset", "Intersection subset abundance boxplot" = "subset_boxplot",
      "Core species histogram" = "core_bar", "Venn/UpSet + classification annotation stacked chart" = "set_taxonomy",
      "Unique OTU scale histogram" = "unique_ratio"),
    character()
  )
}

microbiome_species_composition_uses_taxonomic_rank <- function(method_id) {
  !identical(method_id, "lefse")
}

microbiome_abundance_test_choices <- function() c(
  "t-test" = "pairwise_t",
  "Wilcoxon test" = "pairwise_wilcoxon",
  "Kruskal-Wallis rank sum test + Dunn test" = "kruskal_dunn",
  "Mixed Linear Model LMM/lmer" = "lmer",
  "Generalized linear mixed effects model glmmTMB" = "glmmTMB"
)

microbiome_set_test_choices <- function() c(
  "Jaccard similarity + permutation test" = "jaccard_permutation",
  "Hypergeometric test / Fisher's exact test" = "fisher_hypergeometric",
  "Core species replacement test" = "core_permutation"
)

microbiome_species_composition_advanced_field_ids <- function(
    method_id, differential_method = "ancombc2") {
  switch(method_id,
    taxonomic_composition = c(
      "abundance_merge_threshold_percent", "abundance_max_taxa",
      "abundance_others_label", "abundance_group_summary"),
    ancombc2 = microbiome_differential_taxa_advanced_field_ids(
      differential_method),
    lefse = c(
      "lefse_filter_threshold", "lefse_alpha", "lefse_p_adjust_method",
      "lefse_remove_unknown", "lefse_norm", "lefse_nresam", "lefse_boots",
      "lefse_subgroup_variable", "lefse_min_subsample", "lefse_subgroup_alpha",
      "lefse_subgroup_strict", "lefse_lda_threshold", "lefse_plot_max_taxa",
      "lefse_keep_full_name", "lefse_keep_prefix", "lefse_group_order",
      "lefse_group_aggregate", "lefse_two_group_separate",
      "lefse_bar_coord_flip", "lefse_bar_add_significance",
      "lefse_cladogram_background_taxa", "lefse_cladogram_features",
      "lefse_clade_label_level", "lefse_cladogram_only_selected",
      "lefse_cladogram_labels", "lefse_branch_size", "lefse_branch_alpha",
      "lefse_clade_label_size", "lefse_node_size_scale",
      "lefse_node_size_offset", "lefse_annotation_shape",
      "lefse_annotation_size", "lefse_color_palette"),
    indicator_taxa = c(
      "indicator_min_indval", "indicator_alpha", "indicator_max_taxa",
      "indicator_heatmap_transform"),
    venn_upset = c(
      "set_presence_threshold_percent", "set_core_prevalence",
      "set_permutations", "set_max_taxa"),
    character()
  )
}

microbiome_species_composition_advanced_controls_ui <- function(ns, method_id, context = list()) {
  current <- context$current_values %||% list()
  section <- function(title, ...) shiny::tagList(
    shiny::tags$h6(class = "fw-semibold mt-2 mb-2", title),
    ..., shiny::tags$hr()
  )
  common <- shiny::div(class = "alert alert-light border py-2",
    shiny::tags$strong("Method-specific settings"),
    shiny::tags$div(class = "small text-muted",
      "These parameters are saved independently for the selected species-composition method."))
  differential_method <- context$differential_method %||% "ancombc2"
  if (identical(method_id, "ancombc2") &&
      !identical(differential_method, "ancombc2")) {
    return(shiny::tagList(
      common,
      microbiome_differential_taxa_advanced_controls_ui(
        ns, differential_method, context)
    ))
  }
  controls <- switch(method_id,
    taxonomic_composition = shiny::tagList(
      section("Taxonomic aggregation",
        shiny::sliderInput(ns("abundance_merge_threshold_percent"),
          "Merge taxa below mean relative abundance (%)", min = 0, max = 10,
          value = current$abundance_merge_threshold_percent %||% 0.5, step = 0.1),
        shiny::numericInput(ns("abundance_max_taxa"), "Maximum displayed taxa",
          value = current$abundance_max_taxa %||% 20L, min = 1L, max = 100L, step = 1L),
        shiny::textInput(ns("abundance_others_label"), "Merged-taxa label",
          value = current$abundance_others_label %||% "Others")),
      section("Group summary",
        shiny::selectInput(ns("abundance_group_summary"), "Group summary statistic",
          c("Mean relative abundance" = "mean", "Median relative abundance" = "median"),
          selected = current$abundance_group_summary %||% "mean"))),
    ancombc2 = shiny::tagList(
      section("ANCOM-BC2 inference",
        shiny::sliderInput(ns("ancombc2_min_prevalence"), "Minimum feature prevalence",
          min = 0, max = 1, value = current$ancombc2_min_prevalence %||% 0.1, step = 0.01),
        shiny::selectInput(ns("ancombc2_p_adjust"), "Multiple-testing correction",
          c("FDR (BH)" = "BH", "Holm" = "holm", "Bonferroni" = "bonferroni",
            "Benjamini-Yekutieli" = "BY"),
          selected = current$ancombc2_p_adjust %||% "BH"),
        shiny::sliderInput(ns("ancombc2_alpha"), "Adjusted P-value threshold",
          min = 0.001, max = 0.1, value = current$ancombc2_alpha %||% 0.05, step = 0.001),
        shiny::numericInput(ns("ancombc2_mdfdr_bootstraps"),
          "mdFDR bootstrap repetitions", value = current$ancombc2_mdfdr_bootstraps %||% 100L,
          min = 10L, max = 10000L, step = 10L),
        if (identical(context$analysis_mode %||% "", "trend")) shiny::tagList(
          shiny::selectInput(ns("ancombc2_trend_pattern"), "Ordered trend pattern",
            c("Monotonically increasing" = "increasing",
              "Monotonically decreasing" = "decreasing",
              "Umbrella" = "umbrella",
              "Inverted umbrella" = "inverted_umbrella"),
            selected = current$ancombc2_trend_pattern %||% "increasing"),
          shiny::selectInput(ns("ancombc2_trend_turning_level"), "Trend turning level",
            c("Use middle ordered level" = "", context$group_levels %||% character()),
            selected = current$ancombc2_trend_turning_level %||% "")
        )),
      section("ANCOM-BC2 plots",
        shiny::numericInput(ns("ancombc2_max_taxa"), "Maximum displayed taxa",
          value = current$ancombc2_max_taxa %||% 30L, min = 5L, max = 100L, step = 1L),
        shiny::numericInput(ns("ancombc2_top_labels"), "Top taxa labels",
          value = current$ancombc2_top_labels %||% 10L, min = 0L, max = 50L, step = 1L),
        shiny::numericInput(ns("ancombc2_lfc_threshold"), "Optional absolute LFC threshold",
          value = current$ancombc2_lfc_threshold %||% 0, min = 0, step = 0.1),
        shiny::selectInput(ns("ancombc2_heatmap_transform"), "Sample heatmap transformation",
          c("Relative abundance" = "relative", "log10 relative abundance" = "log10_relative",
            "CLR" = "clr", "Row Z-score" = "row_z"),
          selected = current$ancombc2_heatmap_transform %||% "relative"),
        shiny::selectInput(ns("ancombc2_heatmap_nonsignificant"),
          "Non-significant pairwise cells",
          c("Grey" = "grey", "Reduced opacity" = "alpha"),
          selected = current$ancombc2_heatmap_nonsignificant %||% "grey"),
        shiny::selectizeInput(ns("ancombc2_heatmap_annotations"),
          "Sample heatmap column annotations",
          context$metadata_columns %||% character(),
          selected = intersect(
            current$ancombc2_heatmap_annotations %||% c("Treatment", "Site", "Year"),
            context$metadata_columns %||% character()),
          multiple = TRUE,
          options = list(closeAfterSelect = FALSE, plugins = list("remove_button"))),
        shiny::checkboxInput(ns("ancombc2_facet_phylum"),
          "Facet forest plots by Phylum",
          value = isTRUE(current$ancombc2_facet_phylum %||% FALSE)))),
    lefse = shiny::tagList(
      section("microeco::trans_diff$new() - LEfSe inference",
        shiny::numericInput(ns("lefse_filter_threshold"),
          "Minimum relative-abundance filter", current$lefse_filter_threshold %||% 0,
          min = 0, max = 1, step = 0.0001),
        shiny::sliderInput(ns("lefse_alpha"), "Kruskal-Wallis adjusted P threshold",
          0.001, 0.1, current$lefse_alpha %||% 0.05, 0.001),
        shiny::selectInput(ns("lefse_p_adjust_method"), "P-value adjustment",
          c("FDR (BH)" = "fdr", "Holm" = "holm", "Bonferroni" = "bonferroni",
            "Benjamini-Yekutieli" = "BY", "No adjustment" = "none"),
          selected = current$lefse_p_adjust_method %||% "fdr"),
        shiny::checkboxInput(ns("lefse_remove_unknown"),
          "Remove unknown / uncultured taxa",
          isTRUE(current$lefse_remove_unknown %||% TRUE)),
        shiny::numericInput(ns("lefse_norm"), "LEfSe normalization total",
          current$lefse_norm %||% 1e6, min = 0, step = 10000),
        shiny::sliderInput(ns("lefse_nresam"), "Resampled sample fraction",
          min = 0.1, max = 1, value = current$lefse_nresam %||% 0.6667,
          step = 0.0001),
        shiny::numericInput(ns("lefse_boots"), "Bootstrap repetitions",
          current$lefse_boots %||% 30L, min = 10L, step = 10L),
        shiny::selectInput(ns("lefse_subgroup_variable"), "Optional subclass variable",
          c("None" = "", context$metadata_columns %||% character()),
          selected = current$lefse_subgroup_variable %||% ""),
        shiny::numericInput(ns("lefse_min_subsample"),
          "Minimum samples per subclass", current$lefse_min_subsample %||% 10L,
          min = 2L, step = 1L),
        shiny::sliderInput(ns("lefse_subgroup_alpha"),
          "Subclass Wilcoxon P threshold", 0.001, 0.1,
          current$lefse_subgroup_alpha %||% 0.05, 0.001),
        shiny::checkboxInput(ns("lefse_subgroup_strict"), "Strict subclass consistency",
          isTRUE(current$lefse_subgroup_strict %||% FALSE))),
      section("microeco::trans_diff$plot_diff_bar() - LDA score plot",
        shiny::sliderInput(ns("lefse_lda_threshold"), "Minimum LDA score", 1, 5,
          current$lefse_lda_threshold %||% 2, 0.1),
        shiny::numericInput(ns("lefse_plot_max_taxa"), "Maximum taxa in LDA plot",
          current$lefse_plot_max_taxa %||% 30L, min = 1L, max = 500L, step = 1L),
        shiny::checkboxInput(ns("lefse_keep_full_name"), "Keep full taxonomic path",
          isTRUE(current$lefse_keep_full_name %||% FALSE)),
        shiny::checkboxInput(ns("lefse_keep_prefix"), "Keep rank prefixes (k__, p__, ...)",
          isTRUE(current$lefse_keep_prefix %||% TRUE)),
        shiny::selectizeInput(ns("lefse_group_order"), "Group display order",
          context$group_levels %||% character(),
          selected = intersect(current$lefse_group_order %||% character(),
            context$group_levels %||% character()),
          multiple = TRUE,
          options = list(closeAfterSelect = FALSE, plugins = list("remove_button"))),
        shiny::checkboxInput(ns("lefse_group_aggregate"), "Aggregate bars by enriched group",
          isTRUE(current$lefse_group_aggregate %||% TRUE)),
        shiny::checkboxInput(ns("lefse_two_group_separate"),
          "Separate directions for two groups",
          isTRUE(current$lefse_two_group_separate %||% TRUE)),
        shiny::checkboxInput(ns("lefse_bar_coord_flip"), "Horizontal taxon labels",
          isTRUE(current$lefse_bar_coord_flip %||% TRUE)),
        shiny::checkboxInput(ns("lefse_bar_add_significance"),
          "Add significance symbols",
          isTRUE(current$lefse_bar_add_significance %||% FALSE))),
      section("microeco::trans_diff$plot_diff_cladogram() - cladogram",
        shiny::numericInput(ns("lefse_cladogram_background_taxa"),
          "Most abundant background taxa", current$lefse_cladogram_background_taxa %||% 200L,
          min = 10L, max = 5000L, step = 10L),
        shiny::numericInput(ns("lefse_cladogram_features"),
          "Maximum differential features", current$lefse_cladogram_features %||% 120L,
          min = 1L, max = 500L, step = 1L),
        shiny::numericInput(ns("lefse_clade_label_level"),
          "Full-label level cutoff", current$lefse_clade_label_level %||% 5L,
          min = 1L, max = 8L, step = 1L),
        shiny::textAreaInput(ns("lefse_cladogram_labels"),
          "Taxa labels to show (comma or newline separated)",
          value = current$lefse_cladogram_labels %||% "", rows = 3),
        shiny::checkboxInput(ns("lefse_cladogram_only_selected"),
          "Only draw selected differential labels",
          isTRUE(current$lefse_cladogram_only_selected %||% FALSE)),
        shiny::sliderInput(ns("lefse_branch_size"), "Branch width",
          min = 0.05, max = 2, value = current$lefse_branch_size %||% 0.2, step = 0.05),
        shiny::sliderInput(ns("lefse_branch_alpha"), "Clade highlight opacity",
          min = 0, max = 1, value = current$lefse_branch_alpha %||% 0.2, step = 0.05),
        shiny::sliderInput(ns("lefse_clade_label_size"), "Clade label base size",
          min = 0.5, max = 8, value = current$lefse_clade_label_size %||% 2, step = 0.1),
        shiny::sliderInput(ns("lefse_node_size_scale"), "Node-size scale",
          min = 0, max = 5, value = current$lefse_node_size_scale %||% 1, step = 0.1),
        shiny::sliderInput(ns("lefse_node_size_offset"), "Node-size offset",
          min = 0, max = 5, value = current$lefse_node_size_offset %||% 1, step = 0.1),
        shiny::selectInput(ns("lefse_annotation_shape"), "Legend annotation shape",
          c("Circle" = 21L, "Square" = 22L, "Diamond" = 23L,
            "Triangle up" = 24L, "Triangle down" = 25L),
          selected = current$lefse_annotation_shape %||% 22L),
        shiny::sliderInput(ns("lefse_annotation_size"), "Legend annotation size",
          min = 1, max = 12, value = current$lefse_annotation_size %||% 5, step = 0.5),
        shiny::selectInput(ns("lefse_color_palette"), "Group color palette",
          c("Dark2" = "Dark2", "Set1" = "Set1", "Set2" = "Set2",
            "Paired" = "Paired", "Okabe-Ito" = "OkabeIto"),
          selected = current$lefse_color_palette %||% "Dark2"))),
    indicator_taxa = shiny::tagList(
      section("Indicator-taxon filtering",
        shiny::sliderInput(ns("indicator_min_indval"), "Minimum IndVal", 0, 1,
          current$indicator_min_indval %||% 0.7, 0.01),
        shiny::sliderInput(ns("indicator_alpha"), "Adjusted P-value threshold", 0.001, 0.1,
          current$indicator_alpha %||% 0.05, 0.001),
        shiny::numericInput(ns("indicator_max_taxa"), "Maximum displayed taxa",
          current$indicator_max_taxa %||% 30L, min = 5L, max = 100L, step = 1L)),
      section("Indicator heatmap",
        shiny::selectInput(ns("indicator_heatmap_transform"), "Heatmap abundance scale",
          c("CLR" = "clr", "Relative abundance" = "relative"),
          selected = current$indicator_heatmap_transform %||% "clr"))),
    venn_upset = shiny::tagList(
      section("Set membership",
        shiny::sliderInput(ns("set_presence_threshold_percent"),
          "Presence abundance threshold (%)", 0, 5,
          current$set_presence_threshold_percent %||% 0, 0.05),
        shiny::sliderInput(ns("set_core_prevalence"), "Core-taxon prevalence", 0.1, 1,
          current$set_core_prevalence %||% 0.5, 0.05),
        shiny::numericInput(ns("set_permutations"), "Permutation count",
          current$set_permutations %||% 999L, min = 99L, step = 100L)),
      section("Set plots",
        shiny::numericInput(ns("set_max_taxa"), "Maximum taxa in detailed plots",
          current$set_max_taxa %||% 50L, min = 5L, max = 500L, step = 5L))),
    NULL
  )
  shiny::tagList(common, controls)
}

microbiome_community_environment_plot_choices <- function(method_id) {
  switch(method_id,
    rda = c(
      "RDA biplot" = "ordination_biplot",
      "Environmental-term significance" = "term_significance",
      "Hierarchical partitioning" = "hierarchical_partition",
      "Unique and shared contribution" = "variation_partition"
    ),
    cca = c(
      "CCA triplot" = "ordination_biplot",
      "Environmental-term significance" = "term_significance",
      "Hierarchical partitioning" = "hierarchical_partition",
      "Unique and shared contribution" = "variation_partition"
    ),
    dbrda = c(
      "db-RDA biplot" = "ordination_biplot",
      "Environmental-term significance" = "term_significance",
      "Hierarchical partitioning" = "hierarchical_partition",
      "Unique and shared contribution" = "variation_partition"
    ),
    envfit = c(
      "PCoA with environmental vectors" = "pcoa_envfit",
      "envfit variable significance" = "envfit_significance"
    ),
    mantel = c(
      "Mantel test overview" = "mantel_overview",
      "Variable-wise Mantel statistics" = "mantel_variables"
    ),
    character()
  )
}

microbiome_phylogenetic_plot_choices <- function(method_id) {
  if (identical(method_id, "phylogenetic_tree_build")) {
    return(c("The constructed phylogenetic tree" = "phylo_build_tree"))
  }
  if (identical(method_id, "phylogenetic_tree")) {
    return(c(
      "microeco phylogenetic tree" = "phylo_tree",
      "taxonomy annotation rings" = "phylo_tree_rings",
      "publication tree with labels" = "phylo_tree_labels"
    ))
  }
  c(
    "Faith's PD group boxplot" = "faith_pd_boxplot",
    "phylogenetic alpha-metric heatmap" = "phylo_alpha_heatmap",
    "SES-MPD / SES-MNTD scatter" = "ses_mpd_mntd_scatter",
    "NRI / NTI group boxplot" = "nri_nti_boxplot",
    "betaMPD pairwise heatmap" = "beta_mpd_heatmap",
    "betaMNTD pairwise heatmap" = "beta_mntd_heatmap",
    "Beta PD pairwise heatmap" = "beta_pd_heatmap"
  )
}

microbiome_phylogenetic_advanced_field_ids <- function(method_id) {
  if (identical(method_id, "phylogenetic_tree_build")) {
    return(c(
      "phylo_build_alignment_preset", "phylo_build_large_dataset_threshold",
      "phylo_build_alignment_iterations", "phylo_build_alignment_refinements",
      "phylo_build_processors", "phylo_build_distance_engine",
      "phylo_build_gamma_categories",
      "phylo_build_optimize_nni", "phylo_build_optimize_gamma",
      "phylo_build_max_ml_tips", "phylo_build_ambiguous_warning_fraction",
      "phylo_build_seed", "phylo_build_show_tip_labels",
      "phylo_build_tip_label_limit"
    ))
  }
  if (identical(method_id, "phylogenetic_tree")) {
    return(c(
      "phylo_tree_group_col", "phylo_tree_group_prefix_remove"
    ))
  }
  c(
    "phylo_abundance_weighted", "phylo_include_root", "phylo_filter_prevalence",
    "phylo_null_model", "phylo_permutations", "phylo_seed", "phylo_workers",
    "phylo_ses_tail", "phylo_p_adjust", "phylo_plot_max_taxa",
    "phylo_heatmap_cluster", "phylo_heatmap_transform"
  )
}

microbiome_phylogenetic_advanced_controls_ui <- function(ns, method_id,
    context = list()) {
  current <- context$current_values %||% list()
  detected_cores <- dava_available_cores()
  section <- function(title, package_function, ...) shiny::tagList(
    shiny::tags$h6(class = "fw-semibold mt-2 mb-1", title),
    shiny::tags$div(class = "small text-muted mb-2", package_function),
    ..., shiny::tags$hr())
  taxonomy <- context$taxonomy_columns %||%
    c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species")
  if (identical(method_id, "phylogenetic_tree_build")) {
    return(shiny::tagList(
      shiny::conditionalPanel(
        sprintf("input['%s'] === 'representative_sequences'",
          ns("phylo_build_source")),
        section("Sequence alignment", "DECIPHER::AlignSeqs()",
          shiny::selectInput(ns("phylo_build_alignment_preset"),
            "Comparison mode",
            c("Automatic (big data uses fast parameters)" = "auto",
              "Fast (0 iterations/optimization)" = "fast",
              "Standard (use iteration parameters below)" = "standard"),
            selected = current$phylo_build_alignment_preset %||% "auto"),
          shiny::numericInput(ns("phylo_build_large_dataset_threshold"),
            "Automatic fast mode trigger tip number",
            current$phylo_build_large_dataset_threshold %||% 2000L,
            min = 3L, step = 100L),
          shiny::numericInput(ns("phylo_build_alignment_iterations"),
            "Number of iterations of progressive comparison",
            current$phylo_build_alignment_iterations %||% 2L,
            min = 0L, max = 10L, step = 1L),
          shiny::numericInput(ns("phylo_build_alignment_refinements"),
            "Number of comparison optimizations",
            current$phylo_build_alignment_refinements %||% 1L,
            min = 0L, max = 10L, step = 1L),
          shiny::numericInput(ns("phylo_build_processors"),
            "Number of parallel threads (default maximum available)",
            current$phylo_build_processors %||% detected_cores,
            min = 1L, max = detected_cores, step = 1L),
          shiny::selectInput(ns("phylo_build_distance_engine"),
            "Distance calculation engine",
            c("DECIPHER Jukes-Cantor (multi-threaded, recommended)" = "decipher_jc",
              "phangorn dist.ml (standard reproduction, single thread)" = "phangorn_ml"),
            selected = current$phylo_build_distance_engine %||%
              "decipher_jc"),
          shiny::sliderInput(ns("phylo_build_ambiguous_warning_fraction"),
            "N/ambiguous base ratio warning threshold", min = 0, max = 1,
            value = current$phylo_build_ambiguous_warning_fraction %||% 0.1,
            step = 0.01)),
        section("Maximum likelihood optimization", "phangorn::pml(), optim.pml()",
          shiny::numericInput(ns("phylo_build_gamma_categories"),
            "Gamma rate category number",
            current$phylo_build_gamma_categories %||% 4L,
            min = 1L, max = 16L, step = 1L),
          shiny::checkboxInput(ns("phylo_build_optimize_nni"),
            "Optimize NNI topology",
            isTRUE(current$phylo_build_optimize_nni %||% TRUE)),
          shiny::checkboxInput(ns("phylo_build_optimize_gamma"),
            "Optimize Gamma shape parameters",
            isTRUE(current$phylo_build_optimize_gamma %||% TRUE)),
          shiny::numericInput(ns("phylo_build_max_ml_tips"),
            "Maximum number of tips allowed to execute ML",
            current$phylo_build_max_ml_tips %||% 2000L,
            min = 3L, step = 100L))
      ),
      shiny::conditionalPanel(
        sprintf("input['%s'] === 'newick'", ns("phylo_build_source")),
        section("Newick/.tre/phylo input validation",
          "ape::read.tree(), phangorn::midpoint()",
          shiny::div(class = "alert alert-light border py-2 mb-0",
            paste0("The tree must contain internal nodes, full branch lengths, and be consistent with the OTU/ASV ID ",
              "Exact match; supports .nwk, .tree, .tre text trees, and phylo objects.")))
      ),
      section("Results and Reproduction", "ape::write.tree(), ggtree::ggtree()",
        shiny::numericInput(ns("phylo_build_seed"), "Random seed",
          current$phylo_build_seed %||% 2026L, min = 1L),
        shiny::checkboxInput(ns("phylo_build_show_tip_labels"),
          "Show tip tag in preview tree",
          isTRUE(current$phylo_build_show_tip_labels %||% TRUE)),
        shiny::numericInput(ns("phylo_build_tip_label_limit"),
          "Maximum number of tip tags to display",
          current$phylo_build_tip_label_limit %||% 100L,
          min = 3L, max = 2000L, step = 10L))
    ))
  }
  if (identical(method_id, "phylogenetic_tree")) {
    return(shiny::tagList(
      shiny::div(class = "alert alert-light border py-2",
        shiny::tags$strong("microeco::trans_phylo"),
        shiny::tags$div(class = "small text-muted",
          "Tree statistics and taxonomy annotations are kept in the microeco object.")),
      section("Tree construction and clade colouring", "microeco::trans_phylo$new()",
        shiny::selectInput(ns("phylo_tree_group_col"), "Taxonomy group column",
          taxonomy, selected = current$phylo_tree_group_col %||% "Phylum"),
        shiny::textInput(ns("phylo_tree_group_prefix_remove"), "Remove rank prefix",
          current$phylo_tree_group_prefix_remove %||% "p__"),
        shiny::div(class = "small text-muted",
          "Layout, branches, tips, labels, rings, legends and colours are configured in the plot panel right sidebar."))
    ))
  }
  shiny::tagList(
    shiny::div(class = "alert alert-light border py-2",
      shiny::tags$strong("Phylogenetic diversity parameters"),
      shiny::tags$div(class = "small text-muted",
        "Faith's PD/MPD/MNTD use picante; tree operations use ape; plots use ggplot2.")),
    section("picante::pd(), mpd(), mntd()", "picante::pd(), picante::mpd(), picante::mntd()",
      shiny::checkboxInput(ns("phylo_abundance_weighted"), "Use abundance-weighted MPD/MNTD",
        isTRUE(current$phylo_abundance_weighted %||% TRUE)),
      shiny::checkboxInput(ns("phylo_include_root"), "Include root branch in Faith's PD",
        isTRUE(current$phylo_include_root %||% FALSE)),
      shiny::sliderInput(ns("phylo_filter_prevalence"), "Minimum feature prevalence",
        0, 1, current$phylo_filter_prevalence %||% 0, 0.01)),
    section("picante::ses.pd(), ses.mpd(), ses.mntd()", "picante null-model SES",
      shiny::selectInput(ns("phylo_null_model"), "Null model",
        c("Taxa labels" = "taxa.labels", "Richness" = "richness",
          "Frequency" = "frequency", "Independent swap" = "independentswap"),
        selected = current$phylo_null_model %||% "taxa.labels"),
      shiny::numericInput(ns("phylo_permutations"), "Randomization runs",
        current$phylo_permutations %||% 999L, min = 9L, step = 100L),
      dava_i18n_preserve_choice_language(shiny::selectInput(
        ns("phylo_ses_tail"), "SES significance tail",
        c("Two-sided" = "both", "Lower / clustering" = "lower",
          "Upper / overdispersion" = "upper"),
        selected = current$phylo_ses_tail %||% "both")),
      shiny::numericInput(ns("phylo_seed"), "Random seed",
        current$phylo_seed %||% 2026L, min = 1L),
      shiny::numericInput(ns("phylo_workers"), "Parallel workers",
        current$phylo_workers %||% 1L, min = 1L,
        max = dava_available_cores())),
    section("ggplot2 / vegan phylogenetic plots", "ggplot2::geom_tile(), vegan::vegdist()",
      dava_i18n_preserve_choice_language(shiny::selectInput(
        ns("phylo_p_adjust"), "Group comparison adjustment",
        c("FDR (BH)" = "BH", "Holm" = "holm", "Bonferroni" = "bonferroni"),
        selected = current$phylo_p_adjust %||% "BH")),
      shiny::numericInput(ns("phylo_plot_max_taxa"), "Maximum plotted taxa",
        current$phylo_plot_max_taxa %||% 50L, min = 5L, max = 500L),
      shiny::checkboxInput(ns("phylo_heatmap_cluster"), "Cluster heatmap rows/columns",
        isTRUE(current$phylo_heatmap_cluster %||% TRUE)),
      shiny::selectInput(ns("phylo_heatmap_transform"), "Heatmap transform",
        c("Raw metric" = "raw", "Log10 + 1" = "log10"),
        selected = current$phylo_heatmap_transform %||% "raw"))
  )
}

microbiome_phylogenetic_tree_plot_settings_ui <- function(ns, prefix,
    result = NULL) {
  id <- function(value) ns(paste0(prefix, value))
  analysis <- result$analysis_spec %||% list()
  ring_data <- result$tables$ring_data %||% data.frame()
  ring_choices <- setdiff(names(ring_data), "label")
  default_rings <- intersect(
    result$actual_parameters$ring_columns %||% c("RelAbund", "Prevalence"),
    ring_choices)
  show_rings <- grepl("rings|labels", prefix)
  colour <- function(name, label, value) {
    microbiome_colour_input(ns, paste0(prefix, name), label, value)
  }
  section <- function(title, ...) {
    bslib::accordion_panel(title, shiny::div(class = "pt-1", ...))
  }
  shiny::tagList(
    shiny::tags$style(
      ".phylo-tree-properties .form-group{margin-bottom:.38rem}",
      ".phylo-tree-properties .shiny-input-container{margin-bottom:.38rem}",
      ".phylo-tree-properties .accordion-body{padding:.55rem .65rem}",
      ".phylo-tree-properties label{font-size:.82rem}"),
    shiny::div(class = "phylo-tree-properties",
      bslib::accordion(
        id = id("tree_property_sections"), open = "Layout and branches",
        section("Layout and branches",
          shiny::selectInput(id("tree_layout"), "Layout",
            c("sector" = "fan", "round" = "circular", "Radial" = "radial",
              "Rectangle" = "rectangular"),
            selected = analysis$phylo_tree_layout %||% "fan"),
          shiny::sliderInput(id("tree_open_angle"), "Sector opening angle",
            0, 180, analysis$phylo_tree_open_angle %||% 30, 5),
          shiny::sliderInput(id("tree_branch_size"), "Branch width",
            0.05, 2, analysis$phylo_tree_branch_size %||% 0.3, 0.05),
          shiny::checkboxInput(id("tree_clade_coloring"),
            "Color branches by taxon",
            isTRUE(analysis$phylo_tree_clade_coloring %||% TRUE)),
          shiny::selectInput(id("tree_palette"), "Taxa Palette",
            c("Dark 3" = "Dark 3", "Set 2" = "Set 2",
              "Dynamic" = "Dynamic", "Okabe-Ito" = "Okabe-Ito"),
            selected = "Dark 3"),
          colour("tree_branch_colour", "Unify branch colors", "#666666")),
        section("Tip nodes and labels",
          shiny::checkboxInput(id("tree_tip_point"), "Show Tip node", TRUE),
          shiny::sliderInput(id("tree_tip_point_size"), "Tip size",
            0.2, 8, analysis$phylo_tree_tip_point_size %||% 2, 0.1),
          shiny::selectInput(id("tree_tip_point_shape"), "Tip shape",
            c("round" = 21, "Square" = 22, "Diamond" = 23, "triangle" = 24),
            selected = analysis$phylo_tree_tip_point_shape %||% 21),
          shiny::sliderInput(id("tree_tip_point_stroke"), "Tip border width",
            0, 2, 0.3, 0.05),
          shiny::sliderInput(id("tree_tip_point_alpha"), "Tip Transparency",
            0.1, 1, analysis$phylo_tree_tip_point_alpha %||% 0.9, 0.05),
          shiny::checkboxInput(id("tree_show_tip_label"), "Show Tip label",
            isTRUE(analysis$phylo_tree_show_tip_label %||%
              grepl("labels", prefix))),
          shiny::sliderInput(id("tree_tip_label_size"), "Tip label font size",
            0.5, 8, analysis$phylo_tree_tip_label_size %||% 2, 0.1),
          shiny::numericInput(id("tree_tip_label_offset"), "Tip label offset",
            analysis$phylo_tree_tip_label_offset %||% 0.5,
            min = 0, max = 10, step = 0.1),
          shiny::checkboxInput(id("tree_show_node_label"),
            "Display internal node number", FALSE),
          colour("tree_tip_label_colour", "Tip label color", "#222222")),
        section("Classification and abundance rings",
          shiny::checkboxInput(id("tree_show_rings"), "Show outer ring comment",
            show_rings && length(default_rings) > 0L),
          shiny::selectizeInput(id("tree_ring_columns"), "Outer ring field",
            ring_choices, selected = default_rings, multiple = TRUE,
            options = list(closeAfterSelect = FALSE,
              plugins = list("remove_button"))),
          shiny::selectInput(id("tree_ring_geom"), "Numerical ring graph",
            c("Column" = "bar", "points" = "point", "Star point" = "star"),
            selected = analysis$phylo_tree_ring_geom %||% "bar"),
          shiny::sliderInput(id("tree_ring_width"), "Ring width",
            0.01, 0.25, analysis$phylo_tree_ring_width %||% 0.05, 0.01),
          shiny::sliderInput(id("tree_ring_offset"), "First loop offset",
            0, 0.3, analysis$phylo_tree_ring_offset %||% 0.03, 0.01),
          shiny::sliderInput(id("tree_ring_gap"), "Ring spacing",
            0, 0.2, analysis$phylo_tree_ring_gap %||% 0.03, 0.01),
          shiny::sliderInput(id("tree_ring_point_size"), "Dot ring size",
            0.2, 5, 1.5, 0.1),
          colour("tree_ring_low_colour", "Value ring low value color", "#0D0887"),
          colour("tree_ring_high_colour", "Value ring high value color", "#F0F921"),
          shiny::checkboxInput(id("tree_ring_legend"), "Show ring legend", TRUE),
          shiny::checkboxInput(id("tree_ring_labels"), "Display ring name", FALSE),
          shiny::sliderInput(id("tree_ring_label_size"), "Ring name font size",
            0.5, 6, 1.8, 0.1)),
        section("Legends and Notes",
          shiny::selectInput(id("tree_legend_position"), "Legend location",
            c("Right" = "right", "Bottom" = "bottom", "Top" = "top",
              "Left" = "left", "Hide" = "none"),
            selected = analysis$phylo_tree_legend_position %||% "right"),
          shiny::sliderInput(id("tree_legend_font_size"), "Legend font size",
            1, 12, analysis$phylo_tree_legend_font_size %||% 3.5, 0.5),
          shiny::textInput(id("tree_legend_title"), "Legend title", ""),
          shiny::checkboxInput(id("tree_scale_bar"), "Show scale", FALSE),
          shiny::textInput(id("tree_scale_bar_label"), "Scale label", "0.05"),
          shiny::sliderInput(id("tree_scale_bar_size"), "Scale font size",
            0.5, 6, 2, 0.1),
          shiny::textInput(id("tree_title"), "Main title", ""),
          shiny::textInput(id("tree_subtitle"), "subtitle", ""),
          shiny::sliderInput(id("tree_title_size"), "Title font size",
            6, 32, 14, 1)),
        section("Theme and Canvas",
          shiny::selectInput(id("tree_theme"), "Topic",
            c("Journal publishing" = "publication", "Simplicity" = "minimal",
              "Classic" = "classic", "Blank tree map" = "tree"),
            selected = "publication"),
          shiny::selectInput(id("tree_font_family"), "Font",
            c("Sans" = "sans", "Serif" = "serif", "Mono" = "mono"),
            selected = "sans"),
          shiny::sliderInput(id("tree_base_size"), "Basic font size",
            6, 28, analysis$phylo_tree_base_size %||% 12, 1),
          colour("tree_background_colour", "Canvas background", "#FFFFFF"),
          shiny::checkboxInput(id("tree_transparent"),
            "Transparent background", FALSE),
          shiny::sliderInput(id("tree_plot_margin"), "Canvas margins",
            0, 40, 8, 1))
      )
    )
  )
}

microbiome_apply_phylogenetic_tree_plot_settings <- function(plot, input, prefix) {
  if (!inherits(plot, "ggplot")) return(plot)
  theme_name <- input[[paste0(prefix, "tree_theme")]] %||% "publication"
  legend <- input[[paste0(prefix, "tree_legend_position")]] %||% "right"
  title_size <- as.numeric(input[[paste0(prefix, "tree_title_size")]] %||% 14)
  base_size <- as.numeric(input[[paste0(prefix, "tree_base_size")]] %||% 12)
  family <- input[[paste0(prefix, "tree_font_family")]] %||% "sans"
  transparent <- isTRUE(input[[paste0(prefix, "tree_transparent")]])
  background <- if (transparent) "transparent" else
    input[[paste0(prefix, "tree_background_colour")]] %||% "white"
  margin <- as.numeric(input[[paste0(prefix, "tree_plot_margin")]] %||% 8)
  base_theme <- switch(theme_name,
    minimal = ggplot2::theme_minimal(base_size = base_size,
      base_family = family),
    classic = ggplot2::theme_classic(base_size = base_size,
      base_family = family),
    tree = ggtree::theme_tree(),
    ggplot2::theme_classic(base_size = base_size, base_family = family))
  plot + base_theme + ggplot2::labs(
    title = input[[paste0(prefix, "tree_title")]] %||% NULL,
    subtitle = input[[paste0(prefix, "tree_subtitle")]] %||% NULL) +
    ggplot2::theme(
      legend.position = legend,
      text = ggplot2::element_text(family = family),
      plot.title = ggplot2::element_text(size = title_size, face = "bold"),
      plot.background = ggplot2::element_rect(fill = background, colour = NA),
      panel.background = ggplot2::element_rect(fill = background, colour = NA),
      plot.margin = ggplot2::margin(margin, margin, margin, margin))
}

microbiome_community_environment_advanced_field_ids <- function(method_id) {
  unique(c(
    "permutations", "seed",
    if (method_id %in% c("dbrda", "envfit", "mantel")) "distance_method",
    if (method_id == "mantel") c("environment_distance_method", "mantel_correlation"),
    if (method_id %in% c("rda", "cca", "dbrda")) {
      c("ordination_scaling", "ordination_top_species", "ordination_arrow_multiplier",
        "hierarchical_partition_type", "hierarchical_partition_permutations")
    },
    if (method_id == "envfit") c("ordination_arrow_multiplier", "envfit_alpha")
  ))
}

microbiome_community_environment_advanced_ui <- function(ns, method_id, current = list()) {
  section <- function(title, ...) shiny::tagList(
    shiny::tags$h6(class = "fw-semibold mt-2 mb-2", title),
    ..., shiny::tags$hr()
  )
  distance_choices <- c(
    "Bray-Curtis" = "bray", "Jaccard" = "jaccard",
    "Euclidean" = "euclidean", "Manhattan" = "manhattan"
  )
  shiny::tagList(
    shiny::div(class = "alert alert-light border py-2",
      shiny::tags$strong("Community-environment analysis"),
      shiny::tags$div(class = "small text-muted",
        "Only parameters supported by the selected method are shown.")),
    section("Permutation inference",
      shiny::numericInput(ns("permutations"), "Permutation count",
        value = current$permutations %||% 999L, min = 99L, step = 100L),
      shiny::numericInput(ns("seed"), "Random seed",
        value = current$seed %||% 2026L, min = 1L, step = 1L)),
    if (method_id %in% c("dbrda", "envfit", "mantel")) section(
      "Community dissimilarity",
      shiny::selectInput(ns("distance_method"), "Community distance",
        distance_choices, selected = current$distance_method %||% "bray")),
    if (method_id == "mantel") section(
      "Mantel test",
      shiny::selectInput(ns("environment_distance_method"), "Environmental distance",
        c("Euclidean" = "euclidean", "Manhattan" = "manhattan"),
        selected = current$environment_distance_method %||% "euclidean"),
      shiny::selectInput(ns("mantel_correlation"), "Correlation method",
        c("Pearson" = "pearson", "Spearman" = "spearman"),
        selected = current$mantel_correlation %||% "pearson")),
    if (method_id %in% c("rda", "cca", "dbrda")) shiny::tagList(
      section("Ordination display",
        shiny::selectInput(ns("ordination_scaling"), "Ordination scaling",
          c("Species-focused (scaling 2)" = "2", "Sites-focused (scaling 1)" = "1"),
          selected = as.character(current$ordination_scaling %||% "2")),
        shiny::numericInput(ns("ordination_top_species"), "Maximum labelled taxa",
          value = current$ordination_top_species %||% 12L, min = 0L, max = 50L),
        shiny::numericInput(ns("ordination_arrow_multiplier"), "Arrow-length multiplier",
          value = current$ordination_arrow_multiplier %||% 1, min = 0.1, max = 10, step = 0.1)),
      section("Hierarchical partitioning",
        shiny::selectInput(ns("hierarchical_partition_type"), "Explained-variation metric",
          c("Adjusted R-squared" = "adjR2", "R-squared" = "R2"),
          selected = current$hierarchical_partition_type %||% "adjR2"),
        shiny::numericInput(ns("hierarchical_partition_permutations"),
          "Variable-importance permutations",
          value = current$hierarchical_partition_permutations %||% 999L,
          min = 99L, step = 100L))
    ),
    if (method_id == "envfit") section(
      "Environmental vectors",
      shiny::numericInput(ns("ordination_arrow_multiplier"), "Arrow-length multiplier",
        value = current$ordination_arrow_multiplier %||% 1, min = 0.1, max = 10, step = 0.1),
      shiny::sliderInput(ns("envfit_alpha"), "Displayed-vector P-value threshold",
        min = 0.001, max = 1, value = current$envfit_alpha %||% 0.05, step = 0.001))
  )
}

microbiome_method_sidebar_formula <- function(method, values = list()) {
  schema <- microbiome_method_sidebar_schema(method)
  panel <- schema$panel
  method_id <- schema$method_id
  compact <- function(value) {
    value <- as.character(value %||% character())
    value[!is.na(value) & nzchar(value)]
  }
  group <- compact(values$group)
  fixed <- compact(values$fixed_effects)
  covariates <- compact(values$covariates)
  random <- compact(values$random_effects)
  rhs <- function(parts, fallback = "1") {
    parts <- unique(compact(parts))
    if (length(parts)) paste(parts, collapse = " + ") else fallback
  }
  group_rhs <- rhs(group)
  model_rhs <- rhs(c(fixed, covariates, if (length(random)) sprintf("(1 | %s)", random[[1]])))
  switch(panel,
    exploratory_composition = if (method_id %in% c("taxonomic_composition", "core_microbiome")) {
      sprintf("relative_abundance[%s] ~ %s", values$taxonomic_rank %||% "feature", group_rhs)
    } else sprintf("feature_abundance ~ %s", group_rhs),
    multivariable_association = sprintf("feature_abundance ~ %s", model_rhs),
    community_environment = {
      constrained <- rhs(fixed, "environment")
      group_term <- compact(values$group_variable %||% group)
      model_terms <- rhs(c(group_term, fixed), "environment")
      switch(method_id,
        rda = sprintf("RDA: community_hellinger ~ %s", model_terms),
        cca = sprintf("CCA: community_counts ~ %s", model_terms),
        dbrda = sprintf("db-RDA[%s]: community_distance ~ %s",
          values$distance_method %||% "bray", model_terms),
        envfit = sprintf("PCoA[%s](community) + envfit(~ %s)%s",
          values$distance_method %||% "bray", constrained,
          if (length(group_term)) paste0(" + factor(", group_term[[1]], ")") else ""),
        mantel = sprintf("Mantel[%s]: community_distance ~ distance(%s)%s",
          values$mantel_correlation %||% "pearson", constrained,
          if (length(group_term)) paste0(" | within ", group_term[[1]]) else ""),
        sprintf("community ~ %s", constrained)
      )
    },
    species_environment_response = sprintf("feature_abundance ~ %s", model_rhs),
    microbial_network = sprintf("%s(counts, transform = '%s')", method_id,
      values$preprocess_strategy %||% "clr"),
    cross_domain_network = sprintf("%s(first_domain, second_domain)", method_id),
    bacterial_function = sprintf("%s(taxonomy, database = '%s')", method_id,
      values$functional_database %||% method_id),
    fungal_function = sprintf("%s(taxonomy, database = '%s')", method_id,
      values$functional_database %||% method_id),
    community_assembly = sprintf("%s(community%s)", method_id,
      if (length(group)) paste0(", group = ", group[[1]]) else ""),
    niche_breadth = sprintf("%s(community) ~ %s", method_id, group_rhs),
    sprintf("%s(community_data)", method_id)
  )
}

microbiome_advanced_field_ids <- function(method) {
  capabilities <- microbiome_method_capabilities(method)
  panel <- method$navigation_panel[[1]] %||% ""
  ids <- c("seed")
  if (capabilities$supports_permutation) ids <- c(ids, "permutations", "permutation_strata")
  if (capabilities$supports_group) ids <- c(ids, "test_method", "p_adjust_method")
  if (panel == "alpha_diversity") ids <- c(ids, "alpha_index", "posthoc_method", "model_engine", "formula_terms")
  if (panel == "beta_diversity") ids <- c(ids, "distance_method", "ordination_method")
  if (panel == "phylogenetic_diversity") ids <- c(ids, "null_model_method", "n_iterations")
  if (panel == "multivariable_association") {
    ids <- c(ids, "model_engine", "model_family", "formula_terms", "p_adjust_method")
  }
  if (panel == "community_environment") {
    return(microbiome_community_environment_advanced_field_ids(method$id[[1]]))
  }
  if (panel == "species_environment_response") ids <- c(ids, "model_engine", "model_family", "spline_k", "formula_terms")
  if (panel %in% c("microbial_network", "cross_domain_network")) ids <- c(ids, "network_method", "network_threshold", "network_fdr")
  if (panel %in% c("community_assembly", "niche_breadth")) {
    ids <- c(ids, "null_model_method", "n_iterations", "n_cores")
    if (identical(method$id[[1]], "ncm")) {
      return(c("ncm_data_type", "ncm_scale_factor", "ncm_seed",
        "ncm_start_m", "ncm_lower_m", "ncm_upper_m", "ncm_maxiter",
        "ncm_conf_level"))
    }
  }
  if (capabilities$supports_random) ids <- c(ids, "random_effects", "random_structure")
  if (panel == "beta_diversity") {
    ids <- setdiff(ids, c("test_method", "p_adjust_method",
      "distance_method", "ordination_method"))
  }
  if (panel == "phylogenetic_diversity") {
    return(microbiome_phylogenetic_advanced_field_ids(method$id[[1]]))
  }
  unique(ids)
}

microbiome_preprocessing_ui <- function(ns, method, context = list()) {
  profile <- microbiome_preprocessing_profile(method)
  current <- context$current_values %||% list()
  current$preprocess_strategy <- current$preprocess_strategy %||% profile$strategy
  field_context <- utils::modifyList(context, list(current_values = current))
  panel <- method$navigation_panel[[1]] %||% ""
  is_diversity <- panel %in% c("alpha_diversity", "beta_diversity", "phylogenetic_diversity")
  otu_orientation_help <- shiny::div(
    class = "alert alert-secondary py-2 mb-2 small",
    shiny::tags$strong("OTU/ASV abundance table direction:"),
    "Recommended and internally unified as \"row=sample, column=OTU/ASV/species\".",
    shiny::tags$br(),
    "If the import table is \"row=sample, column=species\": select \"OTU feature ID=column name, OTU sample ID=row name\".",
    shiny::tags$br(),
    "If the imported table is \"row = species, column = sample\": select \"OTU feature ID = row name, OTU sample ID = column name\", the system will automatically transpose without manually modifying the original table."
  )
  if (is_diversity) {
    minimum_depth <- suppressWarnings(as.integer(context$minimum_depth %||% NA_integer_))
    if (is.finite(minimum_depth) && is.null(current$rarefaction_depth)) current$rarefaction_depth <- minimum_depth
    minimum_label <- if (is.finite(minimum_depth)) {
      sprintf("Sample minimum depth (auto: %s)", format(minimum_depth, big.mark = ","))
    } else "Sample minimum depth (auto)"
    id_choices <- function(columns) c("row name" = ".__rownames__", "Listing" = ".__colnames__", stats::setNames(columns, columns))
    select_id <- function(id, label, columns, default) {
      choices <- id_choices(columns)
      selected <- current[[id]] %||% default
      if (!length(selected) || !selected %in% unname(choices)) selected <- default
      shiny::selectizeInput(ns(id), label, choices = NULL, selected = NULL,
        options = list(placeholder = "Enter name to search", maxOptions = 100L))
    }
    taxonomy_default <- if ("Feature" %in% (context$taxonomy_columns %||% character())) "Feature" else ".__rownames__"
    metadata_default <- if ("SampleID" %in% (context$metadata_columns %||% character())) "SampleID" else ".__rownames__"
    return(shiny::tagList(
      shiny::tags$style(".microbiome-preprocess-compact .form-group{margin-bottom:.45rem}.microbiome-preprocess-compact hr{margin:.7rem 0}"),
      shiny::div(class = "microbiome-preprocess-compact",
        shiny::tags$h6(class = "fw-semibold mb-2", "Data ID Mapping"),
        otu_orientation_help,
        shiny::fluidRow(
          shiny::column(6, select_id("otu_feature_id", "OTU signature ID", context$count_columns %||% character(), ".__colnames__")),
          shiny::column(6, select_id("otu_sample_id", "OTU sample ID", context$count_columns %||% character(), ".__rownames__"))
        ),
        shiny::tags$hr(),
        shiny::fluidRow(
          shiny::column(6, select_id("taxonomy_feature_id", "Annotation Feature ID", context$taxonomy_columns %||% character(), taxonomy_default)),
          shiny::column(6, select_id("metadata_sample_id", "metadata sample ID", context$metadata_columns %||% character(), metadata_default))
        ),
        shiny::tags$hr(),
        shiny::tags$h6(class = "fw-semibold mb-2", "Preprocessing and standardization"),
        shiny::div(class = "alert alert-info py-2 mb-2", shiny::tags$strong("Recommended:"), profile$reason),
        microbiome_field_ui("preprocess_strategy", ns, field_context),
        shiny::conditionalPanel(sprintf("input['%s'] === 'rarefy'", ns("preprocess_strategy")),
          shiny::fluidRow(
            shiny::column(6, shiny::selectInput(ns("rarefaction_depth_mode"), "Leveling depth",
              stats::setNames(c("minimum", "custom"), c(minimum_label, "Custom numbers")),
              selected = current$rarefaction_depth_mode %||% "minimum")),
            shiny::column(6, shiny::conditionalPanel(
              sprintf("input['%s'] === 'custom'", ns("rarefaction_depth_mode")),
              microbiome_field_ui("rarefaction_depth", ns, field_context)))
          )),
        shiny::conditionalPanel(sprintf("input['%s'] === 'clr'", ns("preprocess_strategy")),
          microbiome_field_ui("pseudocount", ns, field_context)),
        shiny::tags$hr(),
        shiny::tags$h6(class = "fw-semibold mb-2", "Feature filtering"),
        shiny::fluidRow(
          shiny::column(6, microbiome_field_ui("minimum_total", ns, field_context)),
          shiny::column(6, microbiome_field_ui("minimum_prevalence", ns, field_context))
        ),
        shiny::tags$hr(),
        shiny::tags$p(class = "small text-muted mb-0",
          switch(panel,
            alpha_diversity = "Alpha diversity uses rarefied counts; ID mappings are applied before data checking and preprocessing.",
            beta_diversity = "Beta diversity uses the selected ecological transformation before distance calculation and ordination.",
            phylogenetic_diversity = "Phylogenetic diversity preserves abundance and tree-tip matching; ID mappings are applied before tree validation.",
            "ID mappings are applied before data checking and preprocessing."))
      )
    ))
  }
  id_choices <- function(columns) c("row name" = ".__rownames__", "Listing" = ".__colnames__",
    stats::setNames(columns, columns))
  select_id <- function(id, label, columns, default) {
    choices <- id_choices(columns)
    selected <- current[[id]] %||% default
    if (!length(selected) || !selected %in% unname(choices)) selected <- default
    shiny::selectizeInput(ns(id), label, choices = NULL, selected = NULL,
      options = list(placeholder = "Enter name to search", maxOptions = 100L))
  }
  taxonomy_default <- if ("Feature" %in% (context$taxonomy_columns %||% character())) "Feature" else ".__rownames__"
  metadata_default <- if ("SampleID" %in% (context$metadata_columns %||% character())) "SampleID" else ".__rownames__"
  shiny::tagList(
    shiny::tags$style(".microbiome-preprocess-compact .form-group{margin-bottom:.45rem}.microbiome-preprocess-compact hr{margin:.7rem 0}"),
    shiny::div(class = "microbiome-preprocess-compact",
      shiny::tags$h6(class = "fw-semibold mb-2", "Data ID Mapping"),
      otu_orientation_help,
      shiny::fluidRow(
        shiny::column(6, select_id("otu_feature_id", "OTU signature ID", context$count_columns %||% character(), ".__colnames__")),
        shiny::column(6, select_id("otu_sample_id", "OTU sample ID", context$count_columns %||% character(), ".__rownames__"))
      ),
      shiny::fluidRow(
        shiny::column(6, select_id("taxonomy_feature_id", "Annotation Feature ID", context$taxonomy_columns %||% character(), taxonomy_default)),
        shiny::column(6, select_id("metadata_sample_id", "metadata sample ID", context$metadata_columns %||% character(), metadata_default))
      ),
      shiny::tags$hr()
    ),
    shiny::div(class = "alert alert-info py-2", shiny::tags$strong("Recommended: "), profile$reason),
    microbiome_field_ui("preprocess_strategy", ns, field_context),
    shiny::conditionalPanel(sprintf("input['%s'] === 'rarefy'", ns("preprocess_strategy")),
      microbiome_field_ui("rarefaction_depth", ns, field_context)),
    shiny::conditionalPanel(sprintf("input['%s'] === 'clr'", ns("preprocess_strategy")),
      microbiome_field_ui("pseudocount", ns, field_context)),
    microbiome_field_ui("minimum_total", ns, field_context),
    microbiome_field_ui("minimum_prevalence", ns, field_context),
    shiny::tags$hr(),
    shiny::tags$p(class = "small text-muted",
      "Alpha: rarefaction; beta/ordination: Hellinger; association/network/modeling: CLR; relative abundance: composition plots only.")
  )
}

microbiome_advanced_controls_ui <- function(ns, method, context = list()) {
  ids <- setdiff(microbiome_advanced_field_ids(method), microbiome_method_sidebar_schema(method)$fields)
  inference_ids <- intersect(ids, c("test_method", "p_adjust_method", "permutations",
    "permutation_strata", "seed"))
  model_ids <- intersect(ids, c("model_engine", "model_family", "formula_terms",
    "random_effects", "random_structure", "spline_k"))
  algorithm_ids <- setdiff(ids, c(inference_ids, model_ids))
  section <- function(title, values) {
    if (!length(values)) return(NULL)
    shiny::tagList(shiny::tags$h6(class = "fw-semibold mt-2 mb-2", title),
      lapply(values, microbiome_field_ui, ns = ns, context = context), shiny::tags$hr())
  }
  shiny::tagList(
    shiny::div(class = "alert alert-light border py-2",
      shiny::tags$strong(method$label_cn[[1]]),
      shiny::tags$div(class = "small text-muted", "Only parameters supported by this analysis are shown.")),
    section("Model and variable structure", model_ids),
    section("Inference and reproducibility", inference_ids),
    section("Method-specific parameters", algorithm_ids)
  )
}

microbiome_ncm_advanced_ui <- function(ns, current = list()) {
  block <- function(title, package_function, ...) {
    shiny::div(
      class = "border rounded p-2 mb-2",
      shiny::div(
        class = "d-flex justify-content-between align-items-center mb-2",
        shiny::tags$strong(title),
        shiny::span(class = "badge text-bg-light", package_function)),
      ...)
  }
  shiny::tagList(
    shiny::tags$style(
      ".ncm-advanced .form-group{margin-bottom:.45rem}.ncm-advanced .row{--bs-gutter-x:.65rem}"),
    shiny::div(
      class = "ncm-advanced",
      block(
        "Data preparation and resampling", "base::rmultinom",
        shiny::selectInput(ns("ncm_data_type"), "Data type",
          c("Relative abundance (multinomial resampling)" = "relative",
            "Count matrix" = "count"),
          selected = current$ncm_data_type %||% "relative"),
        shiny::fluidRow(
          shiny::column(6, shiny::numericInput(
            ns("ncm_scale_factor"), "Scale factor",
            current$ncm_scale_factor %||% 10000L,
            min = 100L, step = 100L)),
          shiny::column(6, shiny::numericInput(
            ns("ncm_seed"), "Random seed",
            current$ncm_seed %||% 2026L,
            min = 1L, step = 1L)))),
      block(
        "Neutral-model fitting", "minpack.lm::nlsLM",
        shiny::fluidRow(
          shiny::column(6, shiny::numericInput(
            ns("ncm_start_m"), "Initial m",
            current$ncm_start_m %||% 0.1,
            min = 0.000001, max = 0.999999, step = 0.01)),
          shiny::column(6, shiny::numericInput(
            ns("ncm_maxiter"), "Maximum iterations",
            current$ncm_maxiter %||% 1000L,
            min = 100L, step = 100L))),
        shiny::fluidRow(
          shiny::column(6, shiny::numericInput(
            ns("ncm_lower_m"), "Lower m bound",
            current$ncm_lower_m %||% 0.000001,
            min = 0.00000001, max = 0.99, step = 0.000001)),
          shiny::column(6, shiny::numericInput(
            ns("ncm_upper_m"), "Upper m bound",
            current$ncm_upper_m %||% 0.999999,
            min = 0.01, max = 0.9999999, step = 0.000001)))),
      block(
        "Wilson confidence interval", "Hmisc::binconf",
        shiny::sliderInput(
          ns("ncm_conf_level"), "Confidence level",
          min = 0.8, max = 0.99,
          value = current$ncm_conf_level %||% 0.95, step = 0.01),
        shiny::div(
          class = "small text-muted",
          "The confidence envelope classifies taxa as med, low or high."))))
}

microbiome_alpha_metric_choices <- function() c(
  "Observed" = "Observed", "Chao1" = "Chao1", "ACE" = "ACE",
  "Shannon" = "Shannon", "Simpson" = "Simpson", "Inverse Simpson" = "InverseSimpson",
  "Hill numbers (q = 0, 1, 2)" = "Hill_numbers", "Pielou" = "Pielou"
)

microbiome_alpha_stat_method_choices <- function(metadata, groups = character()) {
  groups <- intersect(groups %||% character(), names(metadata %||% data.frame()))
  if (!length(groups)) return(c("Descriptive diversity only" = "descriptive"))
  if (length(groups) == 1L) {
    levels <- nlevels(droplevels(factor(metadata[[groups[[1]]]])))
    if (levels == 2L) return(c(
      "Independent-samples t-test" = "t_test", "Welch t-test" = "welch_t",
      "Wilcoxon rank-sum test" = "wilcoxon", "Linear mixed-effects model" = "lmm"))
    return(c(
      "One-way ANOVA" = "one_way_anova", "Welch ANOVA" = "welch_anova",
      "Kruskal-Wallis test" = "kruskal", "Linear mixed-effects model" = "lmm"))
  }
  c("Factorial ANOVA" = "factorial_anova", "Factorial ANOVA with interactions" = "interaction_anova",
    "Linear mixed-effects model" = "lmm")
}

microbiome_alpha_formula <- function(groups = character(), method = "descriptive", random_effect = "") {
  groups <- unique(groups[nzchar(groups)])
  if (!length(groups) || identical(method, "descriptive")) return("Diversity index ~ 1")
  operator <- if (identical(method, "interaction_anova") && length(groups) > 1L) " * " else " + "
  fixed <- paste(groups, collapse = operator)
  if (identical(method, "lmm") && nzchar(random_effect)) fixed <- paste(fixed, sprintf("(1 | %s)", random_effect), sep = " + ")
  paste("Diversity index ~", fixed)
}

microbiome_alpha_advanced_controls_ui <- function(ns, method, context = list()) {
  shiny::tagList(
    shiny::selectInput(ns("alpha_p_adjust"), "P-value adjustment",
      c("FDR (BH)" = "BH", "Bonferroni" = "bonferroni", "Holm" = "holm", "None" = "none"), selected = "BH"),
    shiny::sliderInput(ns("alpha_conf_level"), "Confidence level", 0.80, 0.99, 0.95, 0.01),
    if (identical(method, "lmm")) shiny::checkboxInput(ns("alpha_reml"), "Use REML", TRUE),
    shiny::checkboxInput(ns("alpha_diagnostics"), "Report assumption diagnostics", TRUE),
    shiny::numericInput(ns("alpha_seed"), "Random seed", 2026L, min = 1L, step = 1L)
  )
}

microbiome_plot_kind <- function(plot_name, plot = NULL) {
  name <- tolower(plot_name %||% "")
  if (identical(name, "venn")) return("venn")
  if (grepl("ncm_fit|neutral.*model|Neutral model", name)) return("ncm")
  if (grepl("mantel.*correlation|correlation.*mantel", name)) {
    return("mantel_correlation")
  }
  if (grepl("network|edge|zipi|keystone", name)) return("network")
  if (grepl("ordination|pcoa|nmds|pca|rda|cca|outlier", name)) return("ordination")
  if (grepl("forest|coefficient", name)) return("forest")
  if (grepl("volcano|prevalence|scatter|ma_plot|smear|dispersion|mean_variance", name)) return("scatter")
  if (grepl("group_distance|boxplot|distribution", name)) return("distribution")
  if (grepl("raref|curve|response|decay|trajectory", name)) return("curve")
  if (grepl("heat|matrix", name)) return("heatmap")
  if (grepl("abundance|composition|indicator|importance|differential|effect|bar|pvalue_histogram", name)) return("bar")
  "general"
}

microbiome_specific_plot_settings_ui <- function(ns, prefix, kind) {
  if (identical(kind, "venn")) {
    return(shiny::tagList(
      shiny::tags$hr(),
      shiny::tags$h6("Venn diagram exclusive settings"),
      shiny::tags$strong("Regional color matching"),
      shiny::fluidRow(
        shiny::column(6, microbiome_colour_input(
          ns, paste0(prefix, "_fill_low"), "Low count color", "#F1F5F4")),
        shiny::column(6, microbiome_colour_input(
          ns, paste0(prefix, "_fill_high"), "High count color", "#168574"))),
      shiny::sliderInput(ns(paste0(prefix, "_region_alpha")),
        "Area transparency", 0.05, 1, 0.72, 0.05),
      shiny::tags$strong("Contour line"),
      shiny::fluidRow(
        shiny::column(6, microbiome_colour_input(
          ns, paste0(prefix, "_edge_colour"), "Outline color", "#253238")),
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_edge_width")),
          "Contour line width", 0.8, min = 0, max = 5, step = 0.1))),
      shiny::selectInput(ns(paste0(prefix, "_edge_type")), "Contour line style",
        c("solid line" = "solid", "dashed line" = "dashed", "dotted line" = "dotted"),
        selected = "solid"),
      shiny::tags$strong("text"),
      shiny::selectInput(ns(paste0(prefix, "_font_family")), "Font",
        c("Sans serif" = "sans", "serif" = "serif", "Monowidth" = "mono"),
        selected = "sans"),
      shiny::fluidRow(
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_set_label_size")),
          "Collection name font size", 4.5, min = 1, max = 20, step = 0.25)),
        shiny::column(6, microbiome_colour_input(
          ns, paste0(prefix, "_set_label_colour"), "Collection name color", "#263238"))),
      shiny::fluidRow(
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_region_label_size")),
          "Intersection digital font size", 4, min = 1, max = 20, step = 0.25)),
        shiny::column(6, microbiome_colour_input(
          ns, paste0(prefix, "_region_label_colour"), "Intersection number color", "#111111"))),
      shiny::selectInput(ns(paste0(prefix, "_region_label_mode")), "Intersection tag content",
        c("Counts and percentages" = "both", "Count only" = "count", "Percent only" = "percent"),
        selected = "both"),
      shiny::tags$strong("Legend"),
      shiny::checkboxInput(ns(paste0(prefix, "_show_legend")), "Show legend", TRUE),
      shiny::textInput(ns(paste0(prefix, "_legend_title")), "Legend title", "Number of taxa"),
      shiny::selectInput(ns(paste0(prefix, "_legend_position")), "Legend location",
        c("Right" = "right", "Bottom" = "bottom", "Left" = "left", "Top" = "top"),
        selected = "right"),
      shiny::fluidRow(
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_legend_title_size")),
          "Legend title font size", 11, min = 6, max = 30, step = 1)),
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_legend_text_size")),
          "Legend text font size", 10, min = 6, max = 30, step = 1)))
    ))
  }
  if (identical(kind, "mantel_correlation")) {
    return(shiny::tagList(
      shiny::tags$hr(),
      shiny::tags$h6("Mantel-Correlation heatmap settings"),
      shiny::selectInput(ns(paste0(prefix, "_triangle")), "Matrix triangle",
        c("Upper" = "upper", "Lower" = "lower"), selected = "upper"),
      shiny::checkboxInput(ns(paste0(prefix, "_show_diagonal")),
        "Show diagonal", FALSE),
      shiny::sliderInput(ns(paste0(prefix, "_square_alpha")),
        "Correlation-square opacity", 0.2, 1, 1, 0.05),
      shiny::sliderInput(ns(paste0(prefix, "_grid_width")),
        "Matrix grid width", 0, 2, 0.25, 0.05),
      shiny::sliderInput(ns(paste0(prefix, "_cor_sig_threshold")),
        "Pearson significance threshold", 0.001, 0.2, 0.05, 0.001),
      shiny::sliderInput(ns(paste0(prefix, "_star_size")),
        "Significance-star size", 2, 12, 6, 0.5),
      shiny::tags$h6("Mantel links"),
      shiny::fluidRow(
        shiny::column(4, shiny::numericInput(ns(paste0(prefix, "_r_width_low")),
          "Low r", 0.5, min = 0.1, max = 8, step = 0.1)),
        shiny::column(4, shiny::numericInput(ns(paste0(prefix, "_r_width_mid")),
          "Mid r", 1.5, min = 0.1, max = 8, step = 0.1)),
        shiny::column(4, shiny::numericInput(ns(paste0(prefix, "_r_width_high")),
          "High r", 3, min = 0.1, max = 8, step = 0.1))),
      shiny::sliderInput(ns(paste0(prefix, "_link_curve")),
        "Link curvature", 0.05, 1, 0.3, 0.05),
      shiny::sliderInput(ns(paste0(prefix, "_taxon_label_size")),
        "Taxon label size", 2, 10, 3.88, 0.25),
      shiny::tags$h6("Colours"),
      shiny::fluidRow(
        shiny::column(4, microbiome_colour_input(
          ns, paste0(prefix, "_low_colour"), "Pearson -1", "#2166AC")),
        shiny::column(4, microbiome_colour_input(
          ns, paste0(prefix, "_mid_colour"), "Pearson 0", "#FFFFFF")),
        shiny::column(4, microbiome_colour_input(
          ns, paste0(prefix, "_high_colour"), "Pearson +1", "#B2182B"))),
      shiny::fluidRow(
        shiny::column(4, microbiome_colour_input(
          ns, paste0(prefix, "_p_colour_low"), "p < 0.01", "#D95F02")),
        shiny::column(4, microbiome_colour_input(
          ns, paste0(prefix, "_p_colour_mid"), "p 0.01-0.05", "#1B9E77")),
        shiny::column(4, microbiome_colour_input(
          ns, paste0(prefix, "_p_colour_high"), "p >= 0.05", "#A2A2A288"))),
      shiny::sliderInput(ns(paste0(prefix, "_x_angle")),
        "Environmental-label angle", 0, 90, 45, 5),
      shiny::selectInput(ns(paste0(prefix, "_legend_position")),
        "Legend position", c("Right" = "right", "Bottom" = "bottom",
          "Left" = "left", "Top" = "top", "None" = "none"),
        selected = "right")
    ))
  }
  if (identical(kind, "ncm")) {
    return(shiny::tagList(
      shiny::tags$hr(),
      shiny::tags$h6("Sloan NCM plot settings"),
      shiny::tags$div(class = "small text-muted mb-2",
        "Only redraws the current model results, not refitting."),
      shiny::tags$strong("Points"),
      shiny::fluidRow(
        shiny::column(6, shiny::sliderInput(ns(paste0(prefix, "_point_alpha")),
          "Point alpha", 0.1, 1, 0.8, 0.05)),
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_point_size")),
          "Point size", 3, min = 0.1, max = 20, step = 0.25))),
      shiny::fluidRow(
        shiny::column(4, microbiome_colour_input(
          ns, paste0(prefix, "_above_colour"), "Above", "#ED7D70")),
        shiny::column(4, microbiome_colour_input(
          ns, paste0(prefix, "_below_colour"), "Below", "#2B889B")),
        shiny::column(4, microbiome_colour_input(
          ns, paste0(prefix, "_neutral_colour"), "Neutral", "#B57FAF"))),
      shiny::tags$strong("Model and confidence interval"),
      shiny::fluidRow(
        shiny::column(4, microbiome_colour_input(
          ns, paste0(prefix, "_fit_line_colour"), "Fit colour", "#335399")),
        shiny::column(4, shiny::selectInput(ns(paste0(prefix, "_fit_line_type")),
          "Fit type", c("Solid" = "solid", "Dashed" = "dashed"), "solid")),
        shiny::column(4, shiny::numericInput(ns(paste0(prefix, "_fit_line_size")),
          "Fit width", 1, min = 0.1, max = 5, step = 0.1))),
      shiny::fluidRow(
        shiny::column(4, microbiome_colour_input(
          ns, paste0(prefix, "_ci_line_colour"), "CI colour", "#335399")),
        shiny::column(4, shiny::selectInput(ns(paste0(prefix, "_ci_line_type")),
          "CI type", c("Dashed" = "dashed", "Solid" = "solid"), "dashed")),
        shiny::column(4, shiny::numericInput(ns(paste0(prefix, "_ci_line_size")),
          "CI width", 1, min = 0.1, max = 5, step = 0.1))),
      shiny::tags$strong("Axes, legend and annotation"),
      shiny::textInput(ns(paste0(prefix, "_axis_title_x_text")),
        "X axis title", "Mean relative abundance (log10)"),
      shiny::textInput(ns(paste0(prefix, "_axis_title_y_text")),
        "Y axis title", "Occurrence frequency"),
      shiny::fluidRow(
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_axis_title_x_size")),
          "X title size", 25, min = 1, max = 60)),
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_axis_title_y_size")),
          "Y title size", 25, min = 1, max = 60))),
      shiny::fluidRow(
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_axis_text_x_size")),
          "X text size", 20, min = 1, max = 60)),
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_axis_text_y_size")),
          "Y text size", 20, min = 1, max = 60))),
      shiny::fluidRow(
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_legend_size")),
          "Legend size", 6, min = 1, max = 30)),
        shiny::column(6, shiny::selectInput(ns(paste0(prefix, "_font_family")),
          "Font", c("Sans" = "sans", "Serif" = "serif", "Mono" = "mono"), "sans"))),
      shiny::textInput(ns(paste0(prefix, "_legend_title_text")),
        "Legend title", ""),
      shiny::fluidRow(
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_fit_para_size")),
          "Fit annotation size", 6, min = 1, max = 30)),
        shiny::column(6, shiny::numericInput(ns(paste0(prefix, "_fit_para_x")),
          "Fit annotation X", 0.02, min = 0, max = 1, step = 0.01))),
      shiny::numericInput(ns(paste0(prefix, "_fit_para_y")),
        "Fit annotation Y", 0.98, min = 0, max = 1, step = 0.01)
    ))
  }
  controls <- switch(kind,
    ordination = shiny::tagList(
      shiny::sliderInput(ns(paste0(prefix, "_point_size")), "Point size", 1, 8, 3, 0.25),
      shiny::sliderInput(ns(paste0(prefix, "_point_alpha")), "Point opacity", 0.1, 1, 0.8, 0.05)),
    distribution = shiny::tagList(
      shiny::sliderInput(ns(paste0(prefix, "_box_width")), "Box width", 0.3, 0.95, 0.66, 0.05),
      shiny::sliderInput(ns(paste0(prefix, "_mean_size")), "Mean point size", 1, 7, 2.8, 0.2)),
    scatter = shiny::tagList(
      shiny::sliderInput(ns(paste0(prefix, "_point_size")), "Point size", 1, 8, 2.7, 0.25),
      shiny::sliderInput(ns(paste0(prefix, "_point_alpha")), "Point opacity", 0.1, 1, 0.82, 0.05)),
    forest = shiny::tagList(
      shiny::sliderInput(ns(paste0(prefix, "_point_size")), "Estimate point size", 1, 7, 2.8, 0.2),
      shiny::sliderInput(ns(paste0(prefix, "_interval_width")), "Confidence interval width", 0.2, 2.5, 0.7, 0.1)),
    curve = shiny::tagList(
      shiny::sliderInput(ns(paste0(prefix, "_line_width")), "Line width", 0.2, 3, 0.8, 0.1),
      shiny::sliderInput(ns(paste0(prefix, "_line_alpha")), "Line opacity", 0.1, 1, 0.7, 0.05)),
    bar = shiny::tagList(
      shiny::sliderInput(ns(paste0(prefix, "_bar_width")), "Bar width", 0.2, 1, 0.8, 0.05)),
    network = shiny::tagList(
      shiny::sliderInput(ns(paste0(prefix, "_node_size")), "Node size", 1, 12, 4, 0.5),
      shiny::sliderInput(ns(paste0(prefix, "_edge_alpha")), "Edge opacity", 0.1, 1, 0.6, 0.05)),
    heatmap = shiny::tagList(
      shiny::sliderInput(ns(paste0(prefix, "_label_size")), "Cell label size", 2, 10, 4, 0.25)),
    NULL
  )
  if (is.null(controls)) return(NULL)
  shiny::tagList(shiny::tags$hr(), shiny::tags$h6("Object-specific settings"), controls)
}

microbiome_mantel_plot_spec_from_input <- function(input, prefix, current = list()) {
  mapping <- c(
    triangle = "mantel_triangle",
    show_diagonal = "mantel_show_diagonal",
    square_alpha = "mantel_square_alpha",
    grid_width = "mantel_grid_width",
    cor_sig_threshold = "mantel_cor_sig_threshold",
    star_size = "mantel_star_size",
    r_width_low = "mantel_r_width_low",
    r_width_mid = "mantel_r_width_mid",
    r_width_high = "mantel_r_width_high",
    link_curve = "mantel_link_curve",
    taxon_label_size = "mantel_taxon_label_size",
    low_colour = "mantel_low_colour",
    mid_colour = "mantel_mid_colour",
    high_colour = "mantel_high_colour",
    p_colour_low = "mantel_p_colour_low",
    p_colour_mid = "mantel_p_colour_mid",
    p_colour_high = "mantel_p_colour_high",
    x_angle = "mantel_x_angle",
    legend_position = "mantel_legend_position"
  )
  for (suffix in names(mapping)) {
    value <- input[[paste0(prefix, "_", suffix)]]
    if (!is.null(value)) current[[mapping[[suffix]]]] <- value
  }
  current
}

microbiome_ncm_plot_args_from_input <- function(input, prefix) {
  get <- function(name, default) input[[paste0(prefix, "_", name)]] %||% default
  list(
    point_alpha = get("point_alpha", 0.8),
    point_size = get("point_size", 3),
    point_colors = c(
      Above = get("above_colour", "#ED7D70"),
      Below = get("below_colour", "#2B889B"),
      Neutral = get("neutral_colour", "#B57FAF")),
    fit_line_color = get("fit_line_colour", "#335399"),
    fit_line_type = get("fit_line_type", "solid"),
    fit_line_size = get("fit_line_size", 1),
    ci_line_color = get("ci_line_colour", "#335399"),
    ci_line_type = get("ci_line_type", "dashed"),
    ci_line_size = get("ci_line_size", 1),
    axis_title_x_text = get("axis_title_x_text", "Mean relative abundance (log10)"),
    axis_title_y_text = get("axis_title_y_text", "Frequency of occupancy"),
    axis_title_x_size = get("axis_title_x_size", 25),
    axis_title_y_size = get("axis_title_y_size", 25),
    axis_text_x_size = get("axis_text_x_size", 20),
    axis_text_y_size = get("axis_text_y_size", 20),
    legend_title_text = get("legend_title_text", NA_character_),
    legend_size = get("legend_size", 6),
    fit_para_size = get("fit_para_size", 6),
    fit_para_position = c(get("fit_para_x", 0.02), get("fit_para_y", 0.98)),
    font_family = get("font_family", "sans"))
}

microbiome_render_ncm_plot <- function(result, input, prefix) {
  feature_fit <- result$tables$feature_fit
  summary <- result$tables$ncm_summary
  if (!is.data.frame(feature_fit) || !nrow(feature_fit) ||
      !is.data.frame(summary) || !nrow(summary)) {
    return(result$plots$ncm_fit)
  }
  args <- microbiome_ncm_plot_args_from_input(input, prefix)
  groups <- if ("Group" %in% names(summary)) {
    as.character(summary$Group)
  } else {
    "All samples"
  }
  plots <- lapply(seq_along(groups), function(index) {
    group_name <- groups[[index]]
    table <- if ("Group" %in% names(summary) &&
        "Group" %in% names(feature_fit)) {
      feature_fit[as.character(feature_fit$Group) == group_name, ,
        drop = FALSE]
    } else {
      feature_fit
    }
    if (!nrow(table)) return(NULL)
    class_code <- if ("Classification" %in% names(table)) {
      as.character(table$Classification)
    } else {
      as.character(table$Group)
    }
    class_code <- factor(
      class_code,
      levels = c("neutral_envelope", "below_neutral", "above_neutral"),
      labels = c("med", "low", "high"))
    counts <- base::table(class_code, useNA = "no")
    percentages <- round(100 * counts / sum(counts), 1)
    labels <- paste0(names(counts), " ", percentages, "%")
    table$PlotClass <- factor(
      class_code, levels = c("med", "low", "high"), labels = labels)
    palette <- stats::setNames(c(
      args$point_colors[["Neutral"]],
      args$point_colors[["Below"]],
      args$point_colors[["Above"]]), labels)
    stats_row <- summary[index, , drop = FALSE]
    x_max <- max(log10(table$p), na.rm = TRUE)
    main <- ggplot2::ggplot(
      table, ggplot2::aes(log10(.data$p), .data$freq)) +
      ggplot2::geom_point(
        ggplot2::aes(colour = .data$PlotClass),
        size = args$point_size, alpha = args$point_alpha) +
      ggplot2::geom_line(
        ggplot2::aes(y = .data$freq.pred),
        colour = args$fit_line_color,
        linetype = args$fit_line_type,
        linewidth = args$fit_line_size) +
      ggplot2::geom_line(
        ggplot2::aes(y = .data$Lower),
        colour = args$ci_line_color,
        linetype = args$ci_line_type,
        linewidth = args$ci_line_size) +
      ggplot2::geom_line(
        ggplot2::aes(y = .data$Upper),
        colour = args$ci_line_color,
        linetype = args$ci_line_type,
        linewidth = args$ci_line_size) +
      ggplot2::scale_colour_manual(values = palette) +
      ggplot2::scale_y_continuous(
        limits = c(0, 1.05), breaks = seq(0, 1, 0.25)) +
      ggplot2::labs(
        x = args$axis_title_x_text,
        y = args$axis_title_y_text,
        title = if (length(groups) > 1L) group_name else NULL) +
      ggplot2::annotate(
        "text", x = x_max, y = 0.27,
        label = sprintf("R² = %.4f", stats_row$R_squared),
        hjust = 1, size = args$fit_para_size) +
      ggplot2::annotate(
        "text", x = x_max, y = 0.18,
        label = sprintf("Nm = %.3f", stats_row$Nm),
        hjust = 1, size = args$fit_para_size) +
      ggplot2::annotate(
        "text", x = x_max, y = 0.09,
        label = sprintf("m = %.4f", stats_row$MigrationRate),
        hjust = 1, size = args$fit_para_size) +
      ggplot2::theme_bw(base_family = args$font_family) +
      ggplot2::theme(
        panel.grid = ggplot2::element_blank(),
        axis.title.x = ggplot2::element_text(size = args$axis_title_x_size),
        axis.title.y = ggplot2::element_text(size = args$axis_title_y_size),
        axis.text.x = ggplot2::element_text(size = args$axis_text_x_size),
        axis.text.y = ggplot2::element_text(size = args$axis_text_y_size),
        plot.title = ggplot2::element_text(
          hjust = 0.5, face = "bold"),
        legend.position = "none")
    pie_data <- data.frame(
      Group = factor(labels, levels = labels),
      Value = as.numeric(counts))
    pie <- ggplot2::ggplot(
      pie_data, ggplot2::aes("", .data$Value, fill = .data$Group)) +
      ggplot2::geom_col(width = 1, colour = "white", linewidth = 0.2) +
      ggplot2::coord_polar("y") +
      ggplot2::scale_fill_manual(values = palette) +
      ggplot2::theme_void(base_family = args$font_family) +
      ggplot2::labs(fill = args$legend_title_text %||% "group") +
      ggplot2::theme(
        legend.position = "right",
        legend.text = ggplot2::element_text(size = args$legend_size))
    main + patchwork::inset_element(
      pie, left = 0.01, bottom = 0.55, right = 0.47, top = 1.02)
  })
  plots <- plots[!vapply(plots, is.null, logical(1))]
  if (!length(plots)) return(result$plots$ncm_fit)
  if (length(plots) == 1L) plots[[1]] else
    patchwork::wrap_plots(plots, ncol = min(2L, length(plots)))
}

microbiome_apply_specific_plot_settings <- function(plot, input, prefix, kind) {
  if (!inherits(plot, "ggplot")) return(plot)
  set_layers <- function(plot, geom_class, values) {
    for (index in seq_along(plot$layers)) {
      if (inherits(plot$layers[[index]]$geom, geom_class)) {
        for (name in names(values)) if (!is.null(values[[name]])) plot$layers[[index]]$aes_params[[name]] <- values[[name]]
      }
    }
    plot
  }
  if (identical(kind, "mantel_correlation")) {
    return(plot)
  }
  if (identical(kind, "venn")) {
    get <- function(name, default) input[[paste0(prefix, "_", name)]] %||% default
    fill_low <- microbiome_normalize_colour(get("fill_low", "#F1F5F4"), "#F1F5F4")
    fill_high <- microbiome_normalize_colour(get("fill_high", "#168574"), "#168574")
    edge_colour <- microbiome_normalize_colour(get("edge_colour", "#253238"), "#253238")
    set_label_colour <- microbiome_normalize_colour(
      get("set_label_colour", "#263238"), "#263238")
    region_label_colour <- microbiome_normalize_colour(
      get("region_label_colour", "#111111"), "#111111")
    font_family <- get("font_family", "sans")
    label_mode <- get("region_label_mode", "both")
    if (!label_mode %in% c("both", "count", "percent")) label_mode <- "both"
    for (index in seq_along(plot$layers)) {
      layer <- plot$layers[[index]]
      if (inherits(layer$geom, "GeomPolygon")) {
        layer$aes_params$alpha <- as.numeric(get("region_alpha", 0.72))
      } else if (inherits(layer$geom, "GeomPath")) {
        layer$mapping$colour <- NULL
        layer$mapping$linewidth <- NULL
        layer$mapping$linetype <- NULL
        layer$aes_params$colour <- edge_colour
        layer$aes_params$linewidth <- as.numeric(get("edge_width", 0.8))
        layer$aes_params$linetype <- get("edge_type", "solid")
      } else if (inherits(layer$geom, "GeomText")) {
        layer$mapping$size <- NULL
        layer$mapping$colour <- NULL
        layer$aes_params$size <- as.numeric(get("set_label_size", 4.5))
        layer$aes_params$colour <- set_label_colour
        layer$aes_params$family <- font_family
      } else if (inherits(layer$geom, "GeomLabel")) {
        if (label_mode %in% names(layer$data)) layer$data$both <- layer$data[[label_mode]]
        layer$aes_params$size <- as.numeric(get("region_label_size", 4))
        layer$aes_params$colour <- region_label_colour
        layer$aes_params$family <- font_family
      }
      plot$layers[[index]] <- layer
    }
    show_legend <- isTRUE(get("show_legend", TRUE))
    legend_title <- get("legend_title", "Number of taxa")
    plot <- plot + ggplot2::scale_fill_gradient(
      low = fill_low, high = fill_high, name = legend_title,
      guide = if (show_legend) ggplot2::guide_colourbar() else "none")
    return(plot + ggplot2::theme(
      text = ggplot2::element_text(family = font_family),
      legend.position = if (show_legend) get("legend_position", "right") else "none",
      legend.title = ggplot2::element_text(
        size = as.numeric(get("legend_title_size", 11))),
      legend.text = ggplot2::element_text(
        size = as.numeric(get("legend_text_size", 10)))))
  }
  if (kind == "ordination") return(set_layers(plot, "GeomPoint", list(
    size = input[[paste0(prefix, "_point_size")]] %||% 3,
    alpha = input[[paste0(prefix, "_point_alpha")]] %||% 0.8)))
  if (kind == "distribution") {
    width <- input[[paste0(prefix, "_box_width")]] %||% 0.66
    for (index in seq_along(plot$layers)) if (inherits(plot$layers[[index]]$geom, "GeomBoxplot")) {
      plot$layers[[index]]$geom_params$width <- width
    }
    return(set_layers(plot, "GeomPoint", list(
      size = input[[paste0(prefix, "_mean_size")]] %||% 2.8)))
  }
  if (kind == "scatter") return(set_layers(plot, "GeomPoint", list(
    size = input[[paste0(prefix, "_point_size")]] %||% 2.7,
    alpha = input[[paste0(prefix, "_point_alpha")]] %||% 0.82)))
  if (kind == "forest") {
    plot <- set_layers(plot, "GeomPoint", list(size = input[[paste0(prefix, "_point_size")]] %||% 2.8))
    return(set_layers(plot, "GeomSegment", list(linewidth = input[[paste0(prefix, "_interval_width")]] %||% 0.7)))
  }
  if (kind == "curve") return(set_layers(plot, "GeomLine", list(
    linewidth = input[[paste0(prefix, "_line_width")]] %||% 0.8,
    alpha = input[[paste0(prefix, "_line_alpha")]] %||% 0.7)))
  if (kind == "bar") {
    width <- input[[paste0(prefix, "_bar_width")]] %||% 0.8
    for (index in seq_along(plot$layers)) if (inherits(plot$layers[[index]]$geom, "GeomCol") || inherits(plot$layers[[index]]$geom, "GeomBar")) {
      plot$layers[[index]]$geom_params$width <- width
    }
    return(plot)
  }
  if (kind == "network") {
    plot <- set_layers(plot, "GeomPoint", list(size = input[[paste0(prefix, "_node_size")]] %||% 4))
    return(set_layers(plot, "GeomSegment", list(alpha = input[[paste0(prefix, "_edge_alpha")]] %||% 0.6)))
  }
  if (kind == "heatmap") return(set_layers(plot, "GeomText", list(size = input[[paste0(prefix, "_label_size")]] %||% 4)))
  plot
}
