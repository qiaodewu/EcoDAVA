microbiome_alpha_table <- function(bundle) {
  counts <- microbiome_numeric_matrix(bundle$counts)
  # estimateR warns when all non-zero observations exceed one, although this
  # is common for valid sequencing count tables and does not change estimates.
  estimates <- suppressWarnings(vegan::estimateR(counts))
  observed <- as.numeric(vegan::specnumber(counts))
  shannon <- as.numeric(vegan::diversity(counts, index = "shannon"))
  inverse_simpson <- as.numeric(vegan::diversity(counts, index = "invsimpson"))
  table <- data.frame(SampleID = rownames(counts), Observed = observed,
    Chao1 = as.numeric(estimates["S.chao1", ]), ACE = as.numeric(estimates["S.ACE", ]),
    FisherAlpha = as.numeric(vegan::fisher.alpha(counts)), Shannon = shannon,
    Simpson = as.numeric(vegan::diversity(counts, index = "simpson")), InverseSimpson = inverse_simpson,
    Hill_q0 = observed, Hill_q1 = exp(shannon), Hill_q2 = inverse_simpson,
    Pielou = ifelse(observed > 1, shannon / log(observed), NA_real_), stringsAsFactors = FALSE)
  if (nrow(bundle$metadata)) table <- cbind(table, bundle$metadata[, setdiff(names(bundle$metadata), "SampleID"), drop = FALSE])
  table
}

microbiome_alpha_index <- function(table, requested = "Shannon") {
  available <- c("Observed", "Chao1", "ACE", "FisherAlpha", "Shannon", "Simpson", "InverseSimpson", "Hill_q0", "Hill_q1", "Hill_q2", "Pielou")
  if (!requested %in% available) requested <- "Shannon"
  requested
}

microbiome_alpha_selected_indices <- function(spec = list()) {
  requested <- spec$diversity_indices %||% c("Observed", "Chao1", "ACE", "Shannon", "Simpson", "InverseSimpson", "Hill_numbers", "Pielou")
  requested <- unique(unlist(lapply(requested, function(value) {
    if (identical(value, "Hill_numbers")) c("Hill_q0", "Hill_q1", "Hill_q2") else value
  }), use.names = FALSE))
  intersect(requested, c("Observed", "Chao1", "ACE", "Shannon", "Simpson", "InverseSimpson", "Hill_q0", "Hill_q1", "Hill_q2", "Pielou"))
}

microbiome_alpha_statistical_analysis <- function(table, indices, spec = list()) {
  method <- spec$alpha_stat_method %||% "descriptive"
  groups <- intersect(spec$alpha_group_variables %||% character(), names(table))
  if (identical(method, "descriptive") || !length(groups)) return(list(tables = list(), models = list(), packages = character()))
  quote_name <- function(value) paste0("`", gsub("`", "", value, fixed = TRUE), "`")
  fixed_formula <- function(index, interaction = FALSE) {
    operator <- if (interaction && length(groups) > 1L) " * " else " + "
    stats::as.formula(paste(quote_name(index), "~", paste(vapply(groups, quote_name, character(1)), collapse = operator)))
  }
  omnibus_rows <- list()
  coefficient_rows <- list()
  posthoc_rows <- list()
  models <- list()
  packages <- character()
  add_omnibus <- function(index, test, term, statistic = NA_real_, df = NA_character_, p = NA_real_) {
    omnibus_rows[[length(omnibus_rows) + 1L]] <<- data.frame(
      DiversityIndex = index, Test = test, Term = term, Statistic = as.numeric(statistic),
      Df = as.character(df), PValue = as.numeric(p), stringsAsFactors = FALSE)
  }
  for (index in indices) {
    analysis_columns <- unique(c(index, groups, spec$alpha_random_effect %||% ""))
    analysis_columns <- analysis_columns[nzchar(analysis_columns)]
    analysis <- table[, analysis_columns, drop = FALSE]
    analysis <- analysis[stats::complete.cases(analysis), , drop = FALSE]
    if (!nrow(analysis)) next
    if (method %in% c("t_test", "welch_t", "wilcoxon")) {
      group <- droplevels(factor(analysis[[groups[[1]]]]))
      if (nlevels(group) != 2L) stop("The selected two-group test requires exactly two valid levels.", call. = FALSE)
      fit <- if (method == "wilcoxon") {
        stats::wilcox.test(analysis[[index]] ~ group, paired = FALSE, exact = FALSE, conf.int = TRUE,
          conf.level = spec$alpha_conf_level %||% 0.95)
      } else if (isTRUE(spec$alpha_paired)) {
        values <- split(analysis[[index]], group)
        if (length(values[[1]]) != length(values[[2]])) stop("Paired t-test requires equal sample counts in both groups.", call. = FALSE)
        stats::t.test(values[[1]], values[[2]], paired = TRUE, conf.level = spec$alpha_conf_level %||% 0.95)
      } else {
        stats::t.test(analysis[[index]] ~ group,
          var.equal = identical(method, "t_test"), conf.level = spec$alpha_conf_level %||% 0.95)
      }
      add_omnibus(index, fit$method, groups[[1]], unname(fit$statistic), fit$parameter %||% NA, fit$p.value)
      models[[index]] <- fit
    } else if (method == "welch_anova") {
      fit <- stats::oneway.test(fixed_formula(index), data = analysis, var.equal = FALSE)
      add_omnibus(index, fit$method, groups[[1]], unname(fit$statistic), paste(fit$parameter, collapse = ", "), fit$p.value)
      models[[index]] <- fit
    } else if (method == "kruskal") {
      fit <- stats::kruskal.test(fixed_formula(index), data = analysis)
      add_omnibus(index, fit$method, groups[[1]], unname(fit$statistic), fit$parameter, fit$p.value)
      models[[index]] <- fit
      if (!identical(spec$alpha_posthoc %||% "dunn", "none")) {
        pairwise <- stats::pairwise.wilcox.test(analysis[[index]], factor(analysis[[groups[[1]]]]),
          p.adjust.method = spec$alpha_p_adjust %||% "BH", exact = FALSE)
        values <- as.data.frame(as.table(pairwise$p.value), stringsAsFactors = FALSE)
        names(values) <- c("Group1", "Group2", "AdjustedP")
        values <- values[is.finite(values$AdjustedP), , drop = FALSE]
        if (nrow(values)) posthoc_rows[[index]] <- cbind(DiversityIndex = index, values)
      }
    } else if (method == "lmm") {
      if (!requireNamespace("lme4", quietly = TRUE)) stop("Linear mixed-effects analysis requires lme4.", call. = FALSE)
      random <- spec$alpha_random_effect %||% ""
      if (!nzchar(random) || !random %in% names(analysis)) stop("Select a valid random-effect variable.", call. = FALSE)
      formula <- stats::as.formula(paste(paste(deparse(fixed_formula(index)), collapse = " "), "+ (1 |", quote_name(random), ")"))
      fit <- lme4::lmer(formula, data = analysis, REML = isTRUE(spec$alpha_reml %||% TRUE))
      coefficients <- as.data.frame(coef(summary(fit)), check.names = FALSE)
      coefficients$Term <- rownames(coefficients)
      rownames(coefficients) <- NULL
      coefficient_rows[[index]] <- cbind(DiversityIndex = index, coefficients[, c("Term", setdiff(names(coefficients), "Term")), drop = FALSE])
      models[[index]] <- fit
      packages <- union(packages, "lme4")
    } else {
      fit <- stats::lm(fixed_formula(index, identical(method, "interaction_anova")), data = analysis)
      anova_table <- stats::anova(fit)
      for (term in rownames(anova_table)) add_omnibus(index, "ANOVA", term,
        anova_table[term, "F value"], anova_table[term, "Df"], anova_table[term, "Pr(>F)"])
      coefficients <- as.data.frame(coef(summary(fit)), check.names = FALSE)
      coefficients$Term <- rownames(coefficients)
      rownames(coefficients) <- NULL
      coefficient_rows[[index]] <- cbind(DiversityIndex = index, coefficients[, c("Term", setdiff(names(coefficients), "Term")), drop = FALSE])
      if (!identical(spec$alpha_posthoc %||% "tukey", "none") && length(groups) == 1L) {
        tukey <- as.data.frame(stats::TukeyHSD(stats::aov(fixed_formula(index), data = analysis))[[1]], check.names = FALSE)
        tukey$Contrast <- rownames(tukey)
        rownames(tukey) <- NULL
        posthoc_rows[[index]] <- cbind(DiversityIndex = index, tukey[, c("Contrast", setdiff(names(tukey), "Contrast")), drop = FALSE])
      }
      models[[index]] <- fit
    }
  }
  tables <- list()
  if (length(omnibus_rows)) tables$statistical_tests <- do.call(rbind, omnibus_rows)
  if (length(coefficient_rows)) tables$model_coefficients <- do.call(rbind, coefficient_rows)
  if (length(posthoc_rows)) tables$posthoc_comparisons <- do.call(rbind, posthoc_rows)
  list(tables = tables, models = models, packages = packages)
}

microbiome_phylogenetic_tip_diagnostics <- function(feature_ids, tree) {
  feature_ids <- unique(as.character(feature_ids %||% character()))
  tip_ids <- unique(as.character(tree$tip.label %||% character()))
  ids <- c(feature_ids, setdiff(tip_ids, feature_ids))
  in_abundance <- ids %in% feature_ids
  in_tree <- ids %in% tip_ids
  data.frame(
    Feature = ids,
    InAbundanceTable = in_abundance,
    InPhylogeneticTree = in_tree,
    Status = ifelse(in_abundance & in_tree, "matched",
      ifelse(in_abundance, "missing_from_tree", "missing_from_abundance")),
    stringsAsFactors = FALSE, check.names = FALSE
  )
}

microbiome_validate_phylogenetic_tree <- function(tree, feature_ids = character(),
    require_rooted = TRUE, exact_match = FALSE,
    require_branch_lengths = TRUE) {
  if (!requireNamespace("ape", quietly = TRUE)) {
    stop("Phylogenetic tree verification requires the ape package.", call. = FALSE)
  }
  if (is.null(tree) || !inherits(tree, "phylo")) {
    stop("requires a valid phylo phylogenetic tree.", call. = FALSE)
  }
  tips <- as.character(tree$tip.label %||% character())
  if (length(tips) < 3L || any(!nzchar(tips)) || anyDuplicated(tips)) {
    stop("The phylogenetic tree must contain at least 3 tips with non-empty and unique names.", call. = FALSE)
  }
  if (ape::Nnode(tree) <= 1L) {
    stop(paste0(
      "No internal nodes or star-shaped phylogenetic tree detected and reliable phylogenetic distance cannot be calculated.",
      "Please provide a Newick tree containing the internal nodes, or reconstruct it using a representative sequence."),
      call. = FALSE)
  }
  if (isTRUE(require_branch_lengths) &&
      (is.null(tree$edge.length) ||
        length(tree$edge.length) != nrow(tree$edge) ||
        any(!is.finite(tree$edge.length)) || any(tree$edge.length < 0) ||
        !any(tree$edge.length > 0))) {
    stop("The phylogenetic tree lacks complete and valid non-negative branch lengths.", call. = FALSE)
  }
  if (isTRUE(require_rooted) && !ape::is.rooted(tree)) {
    stop(paste0(
      "Unrooted phylogenetic tree detected. Please select \"Phylogenetic tree construction\" on the left,",
      "Use \"read Newick and root\" and midpoint to root before analyzing."),
      call. = FALSE)
  }
  diagnostics <- microbiome_phylogenetic_tip_diagnostics(feature_ids, tree)
  if (length(feature_ids)) {
    matched <- sum(diagnostics$Status == "matched")
    if (isTRUE(exact_match) && any(diagnostics$Status != "matched")) {
      missing_tree <- diagnostics$Feature[
        diagnostics$Status == "missing_from_tree"]
      missing_abundance <- diagnostics$Feature[
        diagnostics$Status == "missing_from_abundance"]
      detail <- c(
        if (length(missing_tree)) paste0("Missing from tree:",
          paste(utils::head(missing_tree, 8L), collapse = ", ")),
        if (length(missing_abundance)) paste0("Missing from abundance table:",
          paste(utils::head(missing_abundance, 8L), collapse = ", "))
      )
      stop(paste0(
        "Phylogenetic tree tip tag must exactly match the OTU/ASV feature ID (case and symbol sensitive).",
        paste0(" ", paste(detail, collapse = "；"))), call. = FALSE)
    }
    if (!isTRUE(exact_match) && matched < 3L) {
      stop("Abundance table matches phylogenetic tree for fewer than 3 characters, please check ASV/OTU names.",
        call. = FALSE)
    }
  }
  list(tree = tree, tip_diagnostics = diagnostics)
}

microbiome_phylo_prepare <- function(bundle, spec = list()) {
  if (is.null(bundle$phylogeny) || !inherits(bundle$phylogeny, "phylo")) {
    stop("Phylo phylogenetic trees with branch lengths are required for phylogenetic diversity.", call. = FALSE)
  }
  counts <- microbiome_numeric_matrix(bundle$counts)
  microbiome_validate_phylogenetic_tree(bundle$phylogeny, colnames(counts),
    require_rooted = TRUE, exact_match = TRUE,
    require_branch_lengths = TRUE)
  shared <- intersect(colnames(counts), bundle$phylogeny$tip.label)
  if (length(shared) < 3L) {
    stop("The abundance table matches the phylogenetic tree for fewer than 3 species. Please check the ASV/OTU name.", call. = FALSE)
  }
  counts <- counts[, shared, drop = FALSE]
  prevalence <- colMeans(counts > 0)
  keep <- prevalence >= as.numeric(spec$phylo_filter_prevalence %||% 0)
  counts <- counts[, keep, drop = FALSE]
  tree <- ape::keep.tip(bundle$phylogeny, colnames(counts))
  if (length(tree$tip.label) < 3L) {
    stop("There are less than 3 species in the filtered phylogenetic tree and phylogenetic distance cannot be calculated.", call. = FALSE)
  }
  counts <- counts[, tree$tip.label, drop = FALSE]
  list(counts = counts, tree = tree,
    distance = ape::cophenetic.phylo(tree))
}

microbiome_phylogenetic_build_plan <- function(feature_count, spec = list(),
    available_processors = NULL) {
  scalar_integer <- function(value, fallback, minimum = 0L) {
    value <- suppressWarnings(as.integer(value %||% fallback))
    if (!length(value) || !is.finite(value[[1]]) || value[[1]] < minimum) {
      return(as.integer(fallback))
    }
    value[[1]]
  }
  feature_count <- scalar_integer(feature_count, 0L, 0L)
  if (is.null(available_processors)) {
    available_processors <- dava_available_cores(logical = TRUE)
  }
  available_processors <- scalar_integer(
    available_processors, 1L, 1L)
  requested_processors <- scalar_integer(
    spec$phylo_build_processors, available_processors, 1L)
  processors <- max(1L, min(requested_processors, available_processors))
  algorithm <- as.character(
    spec$phylo_build_algorithm %||% "ml")[[1]]
  if (!algorithm %in% c("ml", "nj")) {
    stop("Unknown phylogenetic tree construction algorithm.", call. = FALSE)
  }
  max_ml_tips <- scalar_integer(
    spec$phylo_build_max_ml_tips, 2000L, 3L)
  if (identical(algorithm, "ml") && feature_count > max_ml_tips) {
    stop(sprintf(paste0(
      "There are currently %d ASV/OTUs, which exceeds the maximum number of tips set by ML by %d.",
      "The system has stopped before sequence alignment; please use NJ Quick Build instead.",
      "or explicitly increase the ML cap."),
      feature_count, max_ml_tips), call. = FALSE)
  }
  large_dataset_threshold <- scalar_integer(
    spec$phylo_build_large_dataset_threshold, 2000L, 3L)
  alignment_preset <- as.character(
    spec$phylo_build_alignment_preset %||% "auto")[[1]]
  if (!alignment_preset %in% c("auto", "fast", "standard")) {
    alignment_preset <- "auto"
  }
  fast_alignment <- identical(alignment_preset, "fast") ||
    (identical(alignment_preset, "auto") &&
      feature_count > large_dataset_threshold)
  alignment_iterations <- if (fast_alignment) 0L else scalar_integer(
    spec$phylo_build_alignment_iterations, 2L, 0L)
  alignment_refinements <- if (fast_alignment) 0L else scalar_integer(
    spec$phylo_build_alignment_refinements, 1L, 0L)
  distance_engine <- as.character(
    spec$phylo_build_distance_engine %||% "decipher_jc")[[1]]
  if (!distance_engine %in% c("decipher_jc", "phangorn_ml")) {
    distance_engine <- "decipher_jc"
  }
  list(
    feature_count = feature_count,
    algorithm = algorithm,
    max_ml_tips = max_ml_tips,
    processors = processors,
    available_processors = available_processors,
    large_dataset_threshold = large_dataset_threshold,
    alignment_preset = alignment_preset,
    fast_alignment = fast_alignment,
    alignment_iterations = alignment_iterations,
    alignment_refinements = alignment_refinements,
    distance_engine = distance_engine
  )
}

microbiome_build_phylogenetic_tree <- function(bundle, spec = list()) {
  started <- proc.time()[["elapsed"]]
  if (!requireNamespace("ape", quietly = TRUE) ||
      !requireNamespace("phangorn", quietly = TRUE)) {
    stop("Phylogenetic tree construction requires the ape and phangorn packages.", call. = FALSE)
  }
  aligned_bundle <- microbiome_align_bundle(bundle)$bundle
  counts <- microbiome_numeric_matrix(aligned_bundle$counts)
  feature_ids <- colnames(counts)
  source <- spec$phylo_build_source %||% "representative_sequences"
  algorithm <- spec$phylo_build_algorithm %||% "ml"
  rooting <- spec$phylo_build_rooting %||% "midpoint"
  warnings <- character()
  runtime_log <- character()
  sequence_quality <- data.frame()
  alignment <- NULL
  ml_fit <- NULL
  packages <- c("ape", "phangorn")

  if (identical(source, "representative_sequences")) {
    if (!requireNamespace("DECIPHER", quietly = TRUE) ||
        !requireNamespace("Biostrings", quietly = TRUE)) {
      stop("Construction of phylogenetic trees from representative sequences requires the DECIPHER and Biostrings packages.",
        call. = FALSE)
    }
    packages <- c(packages, "DECIPHER", "Biostrings")
    sequences <- microbiome_representative_sequence_list(
      aligned_bundle$representative_sequences)
    if (is.null(sequences) || !length(sequences)) {
      stop("Please select a FASTA file or data table that contains the ASV/OTU ID and representative sequence.",
        call. = FALSE)
    }
    sequence_ids <- names(sequences)
    missing_sequences <- setdiff(feature_ids, sequence_ids)
    extra_sequences <- setdiff(sequence_ids, feature_ids)
    if (length(missing_sequences) || length(extra_sequences)) {
      details <- c(
        if (length(missing_sequences)) paste0("represents the missing sequence:",
          paste(utils::head(missing_sequences, 8L), collapse = ", ")),
        if (length(extra_sequences)) paste0("Missing from abundance table:",
          paste(utils::head(extra_sequences, 8L), collapse = ", "))
      )
      stop(paste0(
        "means that the sequence name must be exactly the same as the OTU/ASV signature ID (case and symbol sensitive). ",
        paste(details, collapse = "；")), call. = FALSE)
    }
    sequences <- sequences[feature_ids]
    plan <- microbiome_phylogenetic_build_plan(
      length(feature_ids), spec)
    algorithm <- plan$algorithm
    sequence_text <- vapply(sequences, paste, collapse = "",
      FUN.VALUE = character(1))
    ambiguous_count <- nchar(gsub("[ACGT]", "", sequence_text))
    sequence_quality <- data.frame(
      Feature = feature_ids, Length = nchar(sequence_text),
      AmbiguousBases = ambiguous_count,
      AmbiguousFraction = ambiguous_count / pmax(nchar(sequence_text), 1L),
      stringsAsFactors = FALSE, check.names = FALSE)
    ambiguous_threshold <- as.numeric(
      spec$phylo_build_ambiguous_warning_fraction %||% 0.1)
    high_ambiguity <- sequence_quality$Feature[
      sequence_quality$AmbiguousFraction > ambiguous_threshold]
    if (length(high_ambiguity)) {
      warnings <- c(warnings, sprintf(
        "%d represents sequences with a N/ambiguous base ratio exceeding %.0f%%; DECIPHER has continued the alignment and it is recommended to review these sequences.",
        length(high_ambiguity), 100 * ambiguous_threshold))
    }
    dna <- Biostrings::DNAStringSet(sequence_text)
    names(dna) <- feature_ids
    processors <- plan$processors
    set.seed(as.integer(spec$phylo_build_seed %||% 2026L))
    alignment <- DECIPHER::AlignSeqs(
      dna,
      iterations = plan$alignment_iterations,
      refinements = plan$alignment_refinements,
      processors = processors, verbose = FALSE)
    phangorn_alignment <- phangorn::phyDat(
      as.matrix(alignment), type = "DNA")
    distance_engine_used <- plan$distance_engine
    distance <- if (identical(plan$distance_engine, "decipher_jc")) {
      DECIPHER::DistanceMatrix(
        alignment, type = "dist", correction = "Jukes-Cantor",
        processors = processors, verbose = FALSE)
    } else {
      phangorn::dist.ml(phangorn_alignment)
    }
    if (any(!is.finite(distance))) {
      runtime_log <- c(runtime_log, paste0(
        "DECIPHER Jukes-Cantor distance contained non-finite values; ",
        "phangorn::dist.ml was used as a deterministic fallback."))
      distance_engine_used <- "phangorn_ml_fallback"
      distance <- phangorn::dist.ml(phangorn_alignment)
    }
    tree_nj <- phangorn::NJ(distance)
    tree_nj <- phangorn::nnls.tree(distance, tree_nj, trace = 0)
    tree <- tree_nj
    if (identical(algorithm, "ml")) {
      gamma_categories <- max(1L, as.integer(
        spec$phylo_build_gamma_categories %||% 4L))
      ml_fit <- phangorn::pml(tree_nj, data = phangorn_alignment)
      ml_fit <- stats::update(ml_fit, k = gamma_categories, model = "GTR")
      ml_fit <- phangorn::optim.pml(
        ml_fit, model = "GTR",
        optNni = isTRUE(spec$phylo_build_optimize_nni %||% TRUE),
        optGamma = isTRUE(spec$phylo_build_optimize_gamma %||% TRUE),
        control = phangorn::pml.control(trace = 0))
      tree <- ml_fit$tree
    } else if (!identical(algorithm, "nj")) {
      stop("Unknown phylogenetic tree construction algorithm.", call. = FALSE)
    }
  } else if (identical(source, "newick")) {
    tree <- aligned_bundle$phylogeny
    if (is.null(tree) || !inherits(tree, "phylo")) {
      stop("Please select a valid Newick phylogenetic tree.", call. = FALSE)
    }
    if (isTRUE(attr(tree, "dava_newick_terminator_added"))) {
      warnings <- c(warnings,
        "The input Newick lacks the trailing semicolon (;), and the system has automatically completed and parsed it.")
    }
    microbiome_validate_phylogenetic_tree(tree, feature_ids,
      require_rooted = FALSE, exact_match = TRUE,
      require_branch_lengths = TRUE)
  } else {
    stop("Unknown phylogenetic tree construction method.", call. = FALSE)
  }

  if (identical(rooting, "midpoint")) {
    if (is.null(tree$edge.length) || any(!is.finite(tree$edge.length)) ||
        !any(tree$edge.length > 0)) {
      stop("midpoint Midpoint roots require full and valid branch lengths.", call. = FALSE)
    }
    tree <- phangorn::midpoint(tree)
  } else if (identical(rooting, "preserve")) {
    if (!ape::is.rooted(tree)) {
      stop("The current Newick is an unrooted tree; please select midpoint to root.", call. = FALSE)
    }
  } else {
    stop("Unknown way of rooting phylogenetic trees.", call. = FALSE)
  }

  validation <- microbiome_validate_phylogenetic_tree(
    tree, feature_ids, require_rooted = TRUE, exact_match = TRUE,
    require_branch_lengths = TRUE)
  tree <- validation$tree
  tree_summary <- data.frame(
    Metric = c("source", "algorithm", "rooting", "tips", "internal_nodes",
      "rooted", "has_branch_lengths", "matched_features"),
    Value = c(source,
      if (identical(source, "representative_sequences")) algorithm else "newick",
      rooting, ape::Ntip(tree), ape::Nnode(tree), ape::is.rooted(tree),
      !is.null(tree$edge.length),
      sum(validation$tip_diagnostics$Status == "matched")),
    stringsAsFactors = FALSE, check.names = FALSE)
  tables <- list(
    tree_newick = data.frame(Newick = ape::write.tree(tree),
      stringsAsFactors = FALSE, check.names = FALSE),
    tree_summary = tree_summary,
    tip_matching = validation$tip_diagnostics)
  if (nrow(sequence_quality)) tables$sequence_quality <- sequence_quality
  plots <- list()
  if (requireNamespace("ggtree", quietly = TRUE) &&
      "phylo_build_tree" %in% as.character(spec$plot_types %||%
        "phylo_build_tree")) {
    tree_plot <- ggtree::ggtree(tree)
    show_labels <- isTRUE(spec$phylo_build_show_tip_labels %||% TRUE) &&
      ape::Ntip(tree) <= as.integer(spec$phylo_build_tip_label_limit %||% 100L)
    if (show_labels) tree_plot <- tree_plot + ggtree::geom_tiplab(size = 2)
    plots$phylo_build_tree <- tree_plot
    packages <- c(packages, "ggtree")
  }
  packages <- unique(packages)
  new_microbiome_result(
    "phylogenetic_tree_build",
    status = if (length(warnings)) "warning" else "success",
    marker_type = aligned_bundle$marker_type,
    data_version = aligned_bundle$data_version,
    input_summary = microbiome_data_summary(aligned_bundle),
    analysis_spec = spec,
    actual_parameters = list(
      source = source, algorithm = algorithm, rooting = rooting,
      matched_features = length(feature_ids),
      processors = if (identical(source, "representative_sequences")) {
        plan$processors
      } else {
        NA_integer_
      },
      alignment_preset = if (identical(
          source, "representative_sequences")) {
        if (plan$fast_alignment) "fast" else "standard"
      } else {
        NA_character_
      },
      distance_engine = if (identical(
          source, "representative_sequences")) {
        distance_engine_used
      } else {
        NA_character_
      },
      gamma_categories = if (identical(algorithm, "ml")) {
        as.integer(spec$phylo_build_gamma_categories %||% 4L)
      } else {
        NA_integer_
      }),
    model_objects = list(tree = tree, ml_fit = ml_fit),
    tables = tables, plots = plots,
    warnings = warnings,
    available_outputs = names(tables), available_plots = names(plots),
    generated_code = microbiome_analysis_code(
      "phylogenetic_tree_build", spec),
    package_versions = microbiome_package_versions(packages),
    runtime_log = runtime_log,
    execution_time = proc.time()[["elapsed"]] - started,
    registration_manifest = microbiome_registration_manifest(
      aligned_bundle, "phylogenetic_tree_build", names(tables)))
}

microbiome_phylo_group_boxplot <- function(table, metric, group, title, ylab) {
  if (!nzchar(group) || !group %in% names(table) || !metric %in% names(table)) return(NULL)
  data <- data.frame(Group = factor(table[[group]]), Value = table[[metric]])
  data <- data[stats::complete.cases(data), , drop = FALSE]
  if (!nrow(data)) return(NULL)
  ggplot2::ggplot(data, ggplot2::aes(Group, Value, fill = Group)) +
    ggplot2::geom_boxplot(width = 0.68, outlier.shape = NA, alpha = 0.82) +
    ggplot2::geom_jitter(width = 0.12, size = 1.5, alpha = 0.7) +
    ggplot2::theme_classic() + ggplot2::theme(legend.position = "none") +
    ggplot2::labs(x = group, y = ylab, title = title)
}

microbiome_phylo_heatmap <- function(matrix, title, transform = "raw", cluster = TRUE) {
  matrix <- as.matrix(matrix)
  if (!nrow(matrix) || !ncol(matrix)) return(NULL)
  display <- if (identical(transform, "log10")) log10(abs(matrix) + 1) else matrix
  data <- as.data.frame(as.table(display), stringsAsFactors = FALSE)
  names(data) <- c("Sample1", "Sample2", "Value")
  ggplot2::ggplot(data, ggplot2::aes(Sample1, Sample2, fill = Value)) +
    ggplot2::geom_tile() +
    ggplot2::scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B",
      midpoint = 0) + ggplot2::coord_equal() +
    ggplot2::labs(title = title, x = NULL, y = NULL, fill = "Distance") +
    ggplot2::theme_classic() +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
}

microbiome_run_phylogenetic_metrics <- function(method_id, bundle, spec = list()) {
  started <- proc.time()[["elapsed"]]
  if (!requireNamespace("picante", quietly = TRUE) ||
      !requireNamespace("ape", quietly = TRUE)) {
    stop("Phylogenetic diversity requires the picante and ape packages.", call. = FALSE)
  }
  prepared <- microbiome_phylo_prepare(bundle, spec)
  counts <- prepared$counts
  tree <- prepared$tree
  distance <- prepared$distance
  weighted <- isTRUE(spec$phylo_abundance_weighted %||% TRUE)
  include_root <- isTRUE(spec$phylo_include_root %||% FALSE)
  runs <- max(9L, as.integer(spec$phylo_permutations %||%
    spec$n_iterations %||% 999L))
  set.seed(as.integer(spec$phylo_seed %||% 2026L))
  pd <- picante::pd(counts, tree, include.root = include_root)
  mpd_w <- picante::mpd(counts, distance, abundance.weighted = TRUE)
  mntd_w <- picante::mntd(counts, distance, abundance.weighted = TRUE)
  mpd_u <- picante::mpd(counts, distance, abundance.weighted = FALSE)
  mntd_u <- picante::mntd(counts, distance, abundance.weighted = FALSE)
  null_model <- microbiome_picante_null_model(
    spec$phylo_null_model %||% spec$null_model_method)
  ses_pd <- tryCatch(picante::ses.pd(counts, tree,
    null.model = null_model,
    runs = runs, include.root = include_root), error = function(e) NULL)
  ses_mpd <- tryCatch(picante::ses.mpd(counts, distance,
    null.model = null_model,
    runs = runs, abundance.weighted = weighted), error = function(e) NULL)
  ses_mntd <- tryCatch(picante::ses.mntd(counts, distance,
    null.model = null_model,
    runs = runs, abundance.weighted = weighted), error = function(e) NULL)
  pick_ses <- function(value, name) {
    if (is.null(value)) return(rep(NA_real_, nrow(counts)))
    value[[name]] %||% rep(NA_real_, nrow(counts))
  }
  table <- data.frame(
    SampleID = rownames(counts), FaithPD = pd$PD, Observed = pd$SR,
    MPD = if (weighted) mpd_w else mpd_u,
    MNTD = if (weighted) mntd_w else mntd_u,
    MPD_unweighted = mpd_u, MNTD_unweighted = mntd_u,
    SES_PD = pick_ses(ses_pd, "pd.obs.z"),
    SES_MPD = pick_ses(ses_mpd, "mpd.obs.z"),
    SES_MNTD = pick_ses(ses_mntd, "mntd.obs.z"),
    NRI = -pick_ses(ses_mpd, "mpd.obs.z"),
    NTI = -pick_ses(ses_mntd, "mntd.obs.z"),
    stringsAsFactors = FALSE)
  metadata <- microbiome_metadata_by_sample(bundle$metadata)
  if (nrow(metadata)) table <- cbind(table,
    metadata[match(table$SampleID, rownames(metadata)),
      setdiff(names(metadata), "SampleID"), drop = FALSE])
  group <- as.character(spec$group %||% "")
  tables <- list(phylogenetic_alpha = table)
  tests <- list()
  if (nzchar(group) && group %in% names(table)) {
    metrics <- c("FaithPD", "MPD", "MNTD", "SES_PD", "SES_MPD", "SES_MNTD")
    tests <- lapply(metrics, function(metric) {
      keep <- stats::complete.cases(table[[metric]], table[[group]])
      if (sum(keep) < 4L || length(unique(table[[group]][keep])) < 2L) return(NULL)
      fit <- stats::kruskal.test(table[[metric]][keep] ~ factor(table[[group]][keep]))
      data.frame(Metric = metric, Test = fit$method,
        Statistic = unname(fit$statistic), Df = unname(fit$parameter),
        PValue = fit$p.value, stringsAsFactors = FALSE)
    })
    tests <- Filter(Negate(is.null), tests)
    if (length(tests)) {
      tables$phylogenetic_group_tests <- do.call(rbind, tests)
      tables$group_test <- tables$phylogenetic_group_tests
    }
    if (identical(spec$phylogenetic_test_method %||% "kruskal", "kruskal") &&
        "FaithPD" %in% names(table)) {
      keep <- stats::complete.cases(table$FaithPD, table[[group]])
      if (sum(keep) >= 4L && length(unique(table[[group]][keep])) >= 2L) {
        pairwise <- stats::pairwise.wilcox.test(
          table$FaithPD[keep], factor(table[[group]][keep]),
          p.adjust.method = spec$phylogenetic_p_adjust %||%
            spec$p_adjust_method %||% "BH", exact = FALSE)
        posthoc <- as.data.frame(as.table(pairwise$p.value),
          stringsAsFactors = FALSE)
        names(posthoc) <- c("Group1", "Group2", "AdjustedP")
        posthoc <- posthoc[is.finite(posthoc$AdjustedP), , drop = FALSE]
        if (nrow(posthoc)) tables$posthoc_comparisons <- posthoc
      }
    }
  }
  tables$faith_pd <- table[, intersect(
    c("SampleID", "FaithPD", "Observed"), names(table)), drop = FALSE]
  beta_mpd <- tryCatch(picante::comdist(counts, distance,
    abundance.weighted = weighted), error = function(e) NULL)
  beta_mntd <- tryCatch(picante::comdistnt(counts, distance,
    abundance.weighted = weighted), error = function(e) NULL)
  edge_lengths <- as.numeric(tree$edge.length)
  if (length(edge_lengths) != nrow(tree$edge)) {
    edge_lengths <- rep(1, nrow(tree$edge))
  }
  descendant_tips <- function(node) {
    if (node <= ape::Ntip(tree)) return(node)
    children <- tree$edge[tree$edge[, 1] == node, 2]
    unlist(lapply(children, descendant_tips), use.names = FALSE)
  }
  branch_presence <- vapply(seq_len(nrow(counts)), function(index) {
    vapply(tree$edge[, 2], function(node) {
      tips <- descendant_tips(node)
      any(counts[index, tips] > 0)
    }, logical(1))
  }, logical(nrow(tree$edge)))
  branch_presence <- t(branch_presence)
  beta_pd <- matrix(0, nrow(counts), nrow(counts),
    dimnames = list(rownames(counts), rownames(counts)))
  for (i in seq_len(nrow(counts))) {
    for (j in seq_len(nrow(counts))) {
      union_branch <- branch_presence[i, ] | branch_presence[j, ]
      if (any(union_branch)) {
        shared_branch <- branch_presence[i, ] & branch_presence[j, ]
        beta_pd[i, j] <- 1 - sum(edge_lengths[shared_branch]) /
          sum(edge_lengths[union_branch])
      }
    }
  }
  tables$beta_phylogenetic_distance <- list(
    betaPD = beta_pd, betaPD_definition = "1 - shared/union branch length",
    betaMPD = beta_mpd, betaMNTD = beta_mntd)
  requested <- as.character(spec$plot_types %||%
    unname(microbiome_phylogenetic_plot_choices(method_id)))
  plots <- list()
  if ("faith_pd_boxplot" %in% requested) {
    plots$faith_pd_boxplot <- microbiome_phylo_group_boxplot(
      table, "FaithPD", group, "Faith's PD by group", "Faith's PD")
    plots$faith_pd_by_group <- plots$faith_pd_boxplot
  }
  if ("nri_nti_boxplot" %in% requested && nzchar(group)) {
    plots$nri_nti_boxplot <- microbiome_phylo_group_boxplot(
      transform(table, NRI = -SES_MPD), "NRI", group, "NRI by group", "NRI")
  }
  if ("ses_mpd_mntd_scatter" %in% requested) {
    plots$ses_mpd_mntd_scatter <- ggplot2::ggplot(table,
      ggplot2::aes(SES_MPD, SES_MNTD, colour = if (nzchar(group) &&
        group %in% names(table)) .data[[group]] else NULL)) +
      ggplot2::geom_hline(yintercept = 0, linetype = 2) +
      ggplot2::geom_vline(xintercept = 0, linetype = 2) +
      ggplot2::geom_point(size = 2.3, alpha = 0.8) +
      ggplot2::theme_classic() + ggplot2::labs(
        title = "SES-MPD and SES-MNTD", x = "SES.MPD", y = "SES.MNTD",
        colour = group)
  }
  if ("phylo_alpha_heatmap" %in% requested) {
    alpha_long <- do.call(rbind, lapply(
      c("FaithPD", "MPD", "MNTD", "SES_PD", "SES_MPD", "SES_MNTD"),
      function(metric) data.frame(SampleID = table$SampleID,
        Metric = metric, Value = table[[metric]])))
    plots$phylo_alpha_heatmap <- ggplot2::ggplot(alpha_long,
      ggplot2::aes(Metric, SampleID, fill = Value)) +
      ggplot2::geom_tile() + ggplot2::scale_fill_gradient2(
        low = "#2166AC", mid = "white", high = "#B2182B", midpoint = 0) +
      ggplot2::theme_classic() + ggplot2::labs(
        title = "Phylogenetic alpha diversity metrics", x = NULL, y = NULL)
  }
  if ("beta_mpd_heatmap" %in% requested && !is.null(beta_mpd))
    plots$beta_mpd_heatmap <- microbiome_phylo_heatmap(beta_mpd, "betaMPD")
  if ("beta_mntd_heatmap" %in% requested && !is.null(beta_mntd))
    plots$beta_mntd_heatmap <- microbiome_phylo_heatmap(beta_mntd, "betaMNTD")
  if ("beta_pd_heatmap" %in% requested)
    plots$beta_pd_heatmap <- microbiome_phylo_heatmap(beta_pd, "Beta PD")
  plots <- Filter(Negate(is.null), plots)
  new_microbiome_result(method_id, status = "success",
    marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle, "samples_by_features"),
    analysis_spec = spec,
    actual_parameters = list(
      abundance_weighted = weighted, include_root = include_root,
      null_model = spec$phylo_null_model %||% "taxa.labels",
      permutations = runs, workers = as.integer(spec$phylo_workers %||% 1L),
      matched_features = ncol(counts), plot_types = names(plots)),
    model_objects = list(tree = tree, distance = distance,
      ses_pd = ses_pd, ses_mpd = ses_mpd, ses_mntd = ses_mntd),
    tables = tables, plots = plots, available_outputs = names(tables),
    available_plots = names(plots),
    generated_code = microbiome_analysis_code(method_id, spec),
    package_versions = microbiome_package_versions(c("picante", "ape", "vegan")),
    execution_time = proc.time()[["elapsed"]] - started,
    registration_manifest = microbiome_registration_manifest(
      bundle, method_id, names(tables)))
}

microbiome_run_phylogenetic_tree <- function(bundle, spec = list()) {
  if (!requireNamespace("microeco", quietly = TRUE) ||
      !requireNamespace("ggtree", quietly = TRUE)) {
    stop("Phylogenetic dendrograms require the microeco, ggtree and ggtreeExtra packages.", call. = FALSE)
  }
  if (is.null(bundle$phylogeny) || !inherits(bundle$phylogeny, "phylo")) {
    stop("The phylogenetic tree requires a phylo phylogenetic tree with branch lengths.", call. = FALSE)
  }
  microbiome_validate_phylogenetic_tree(bundle$phylogeny,
    colnames(microbiome_numeric_matrix(bundle$counts)),
    require_rooted = TRUE, exact_match = TRUE,
    require_branch_lengths = TRUE)
  dataset <- microbiome_microeco_dataset(bundle, require_tree = TRUE)
  taxonomy <- as.data.frame(bundle$taxonomy, check.names = FALSE)
  tips <- rownames(dataset$otu_table)
  rel <- sweep(as.matrix(dataset$otu_table), 2,
    pmax(colSums(dataset$otu_table), 1), "/")
  ring <- data.frame(label = tips,
    RelAbund = rowMeans(rel) * 100, Prevalence = rowMeans(
      as.matrix(dataset$otu_table) > 0) * 100, stringsAsFactors = FALSE)
  if (nrow(taxonomy)) {
    tax <- taxonomy[match(tips, rownames(taxonomy)), , drop = FALSE]
    for (column in intersect(names(tax),
      c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species"))) {
      ring[[column]] <- as.character(tax[[column]])
    }
  }
  group_col <- spec$phylo_tree_group_col %||% "Phylum"
  if (!group_col %in% names(ring)) group_col <- "Phylum"
  group_prefix_remove <- spec$phylo_tree_group_prefix_remove %||% "p__"
  group_values <- as.character(ring[[group_col]])
  group_values <- gsub(group_prefix_remove, "", group_values)
  group_values[is.na(group_values) | !nzchar(group_values)] <- "Others"
  n_group <- length(unique(group_values))
  palette <- grDevices::hcl.colors(max(1L, n_group), "Dark 3")
  if (requireNamespace("RColorBrewer", quietly = TRUE) && n_group <= 8L) {
    palette <- RColorBrewer::brewer.pal(max(3L, n_group), "Dark2")[seq_len(n_group)]
  }
  viz <- microeco::trans_phylo$new(dataset = dataset, group_col = group_col,
    ring_data = ring, color_palette = palette,
    group_prefix_remove = group_prefix_remove,
    clade_coloring = isTRUE(spec$phylo_tree_clade_coloring %||% TRUE))
  viz$plot_tree(
    layout = spec$phylo_tree_layout %||% "fan",
    open_angle = as.numeric(spec$phylo_tree_open_angle %||% 30),
    branch_size = as.numeric(spec$phylo_tree_branch_size %||% 0.3),
    tip_point_size = as.numeric(spec$phylo_tree_tip_point_size %||% 2),
    tip_point_shape = as.integer(spec$phylo_tree_tip_point_shape %||% 21),
    tip_point_alpha = as.numeric(spec$phylo_tree_tip_point_alpha %||% 0.9),
    show_tip_label = isTRUE(spec$phylo_tree_show_tip_label %||% FALSE),
    tip_label_size = as.numeric(spec$phylo_tree_tip_label_size %||% 2),
    tip_label_offset = as.numeric(spec$phylo_tree_tip_label_offset %||% 0.5),
    legend_position = spec$phylo_tree_legend_position %||% "right",
    legend_font_size = as.numeric(spec$phylo_tree_legend_font_size %||% 3.5),
    legend_title = group_col)
  base_plot <- viz$get_plot()
  requested <- as.character(spec$plot_types %||%
    unname(microbiome_phylogenetic_plot_choices("phylogenetic_tree")))
  ring_columns <- intersect(as.character(spec$phylo_tree_ring_columns %||%
    c("RelAbund", "Prevalence")), names(ring))
  ring_warning <- character()
  if (length(ring_columns) && requireNamespace("ggtreeExtra", quietly = TRUE)) {
    viz$add_rings_batch(col_names = ring_columns,
      numeric_geom = spec$phylo_tree_ring_geom %||% "bar",
      ring_width = as.numeric(spec$phylo_tree_ring_width %||% 0.05),
      ring_offset = as.numeric(spec$phylo_tree_ring_offset %||% 0.03),
      show_legend = TRUE)
  } else if (length(ring_columns)) {
    ring_warning <- "ggtreeExtra is not installed; taxonomy and abundance rings were skipped."
  }
  ring_plot <- viz$get_plot()
  plots <- list()
  if ("phylo_tree" %in% requested) plots$phylo_tree <- base_plot
  if ("phylo_tree_rings" %in% requested) plots$phylo_tree_rings <- ring_plot
  if ("phylo_tree_labels" %in% requested) plots$phylo_tree_labels <- ring_plot
  new_microbiome_result("phylogenetic_tree", status = "success",
    marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle),
    analysis_spec = spec, actual_parameters = list(
      group_col = group_col, ring_columns = ring_columns,
      plot_types = names(plots)), model_objects = list(trans_phylo = viz),
    tables = list(ring_data = ring), plots = plots,
    available_outputs = "ring_data", available_plots = names(plots),
    generated_code = microbiome_analysis_code("phylogenetic_tree", spec),
    package_versions = microbiome_package_versions(
      c("microeco", "ggtree",
        if (requireNamespace("ggtreeExtra", quietly = TRUE)) "ggtreeExtra",
        "ape")),
    registration_manifest = microbiome_registration_manifest(
      bundle, "phylogenetic_tree", "ring_data"),
    warnings = ring_warning)
}

microbiome_render_phylogenetic_tree_result <- function(result, input, prefix,
    plot_name = "phylo_tree") {
  original <- result$plots[[plot_name]] %||% result$plots$phylo_tree
  source_object <- result$model_objects$trans_phylo
  if (is.null(source_object) || is.null(source_object$dataset) ||
      !requireNamespace("microeco", quietly = TRUE)) {
    return(microbiome_apply_phylogenetic_tree_plot_settings(
      original, input, prefix))
  }
  read_value <- function(name, default = NULL) {
    input[[paste0(prefix, name)]] %||% default
  }
  render <- suppressMessages(tryCatch({
    group_col <- result$actual_parameters$group_col %||%
      result$analysis_spec$phylo_tree_group_col %||% "Phylum"
    group_values <- source_object$tax_table[[group_col]] %||% "Others"
    group_values <- as.character(group_values)
    group_values[is.na(group_values) | !nzchar(group_values)] <- "Others"
    groups <- unique(group_values)
    palette_name <- read_value("tree_palette", "Dark 3")
    palette <- if (identical(palette_name, "Okabe-Ito")) {
      rep(c("#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7",
        "#56B4E9", "#F0E442", "#000000"), length.out = length(groups))
    } else {
      grDevices::hcl.colors(max(1L, length(groups)), palette_name)
    }
    names(palette) <- groups
    tree_object <- microeco::trans_phylo$new(
      dataset = source_object$dataset,
      group_col = group_col,
      ring_data = result$tables$ring_data,
      color_palette = palette,
      group_prefix_remove =
        result$analysis_spec$phylo_tree_group_prefix_remove %||% "p__",
      clade_coloring = isTRUE(read_value("tree_clade_coloring", TRUE)))
    tree_object$plot_tree(
      layout = read_value("tree_layout", "fan"),
      open_angle = as.numeric(read_value("tree_open_angle", 30)),
      branch_size = as.numeric(read_value("tree_branch_size", 0.3)),
      tip_point = isTRUE(read_value("tree_tip_point", TRUE)),
      tip_point_size = as.numeric(read_value("tree_tip_point_size", 2)),
      tip_point_shape = as.integer(read_value("tree_tip_point_shape", 21)),
      tip_point_stroke = as.numeric(read_value("tree_tip_point_stroke", 0.3)),
      tip_point_alpha = as.numeric(read_value("tree_tip_point_alpha", 0.9)),
      show_tip_label = isTRUE(read_value("tree_show_tip_label",
        grepl("labels", plot_name))),
      tip_label_size = as.numeric(read_value("tree_tip_label_size", 2)),
      tip_label_offset = as.numeric(read_value("tree_tip_label_offset", 0.5)),
      show_node_label = isTRUE(read_value("tree_show_node_label", FALSE)),
      branch_color_by_group =
        isTRUE(read_value("tree_clade_coloring", TRUE)),
      branch_color = read_value("tree_branch_colour", "#666666"),
      legend_title = {
        value <- trimws(as.character(read_value("tree_legend_title", "")))
        if (nzchar(value)) value else group_col
      },
      legend_position = read_value("tree_legend_position", "right"),
      legend_font_size =
        as.numeric(read_value("tree_legend_font_size", 3.5)))
    show_rings <- isTRUE(read_value("tree_show_rings",
      grepl("rings|labels", plot_name)))
    ring_columns <- intersect(as.character(read_value(
      "tree_ring_columns", result$actual_parameters$ring_columns %||%
        character())), names(result$tables$ring_data %||% data.frame()))
    if (show_rings && length(ring_columns) &&
        requireNamespace("ggtreeExtra", quietly = TRUE)) {
      tree_object$add_rings_batch(
        col_names = ring_columns,
        numeric_geom = read_value("tree_ring_geom", "bar"),
        ring_width = as.numeric(read_value("tree_ring_width", 0.05)),
        ring_offset = as.numeric(read_value("tree_ring_offset", 0.03)),
        color_low = read_value("tree_ring_low_colour", "#0D0887"),
        color_high = read_value("tree_ring_high_colour", "#F0F921"),
        show_legend = isTRUE(read_value("tree_ring_legend", TRUE)),
        ring_gap = as.numeric(read_value("tree_ring_gap", 0.03)),
        point_size = as.numeric(read_value("tree_ring_point_size", 1.5)))
      if (isTRUE(read_value("tree_ring_labels", FALSE))) {
        tree_object$add_ring_labels(
          size = as.numeric(read_value("tree_ring_label_size", 1.8)))
      }
    }
    if (isTRUE(read_value("tree_scale_bar", FALSE))) {
      tree_object$add_scale_bar(
        label = read_value("tree_scale_bar_label", "0.05"),
        fontsize = as.numeric(read_value("tree_scale_bar_size", 2)))
    }
    plot <- tree_object$get_plot()
    label_colour <- read_value("tree_tip_label_colour", "#222222")
    for (index in seq_along(plot$layers)) {
      geom_name <- class(plot$layers[[index]]$geom)[1]
      if (grepl("Text", geom_name, fixed = TRUE)) {
        plot$layers[[index]]$aes_params$colour <- label_colour
      }
    }
    microbiome_apply_phylogenetic_tree_plot_settings(plot, input, prefix)
  }, error = function(error) {
    microbiome_apply_phylogenetic_tree_plot_settings(
      original, input, prefix)
  }))
  render
}

microbiome_alpha_plot_type_choices <- function() {
  c(
    "Boxplot + Scatter" = "box_jitter",
    "Violin plot + box plot + scatter point" = "violin_box",
    "Violin diagram" = "violin",
    "Mean ± standard error + scatter" = "mean_se",
    "Grouped scatter plot" = "jitter"
  )
}

microbiome_alpha_diversity_plot <- function(table, spec = list(),
    plot_type = "box_jitter") {
  if (!requireNamespace("ggplot2", quietly = TRUE) || !nrow(table)) return(NULL)
  indices <- intersect(microbiome_alpha_selected_indices(spec), names(table))
  if (!length(indices)) return(NULL)
  long <- do.call(rbind, lapply(indices, function(index) data.frame(
    SampleID = table$SampleID, DiversityIndex = index,
    Value = table[[index]], stringsAsFactors = FALSE)))
  groups <- intersect(spec$alpha_group_variables %||% character(), names(table))
  if (length(groups)) {
    long$Group <- rep(interaction(table[, groups, drop = FALSE],
      drop = TRUE, sep = " × "), times = length(indices))
    mapping <- ggplot2::aes(Group, Value, fill = Group)
    x_label <- paste(groups, collapse = " × ")
    title <- "Alpha diversity by group"
  } else {
    long$Group <- long$DiversityIndex
    mapping <- ggplot2::aes(DiversityIndex, Value, fill = DiversityIndex)
    x_label <- NULL
    title <- "Alpha diversity indices"
  }
  plot <- ggplot2::ggplot(long, mapping)
  plot_type <- match.arg(plot_type, unname(microbiome_alpha_plot_type_choices()))
  plot <- switch(plot_type,
    box_jitter = plot +
      ggplot2::geom_boxplot(width = 0.68, outlier.shape = NA, alpha = 0.82) +
      ggplot2::geom_jitter(width = 0.12, size = 1.5, alpha = 0.65,
        colour = "#303030"),
    violin_box = plot +
      ggplot2::geom_violin(width = 0.9, trim = FALSE, alpha = 0.55) +
      ggplot2::geom_boxplot(width = 0.2, outlier.shape = NA, alpha = 0.78) +
      ggplot2::geom_jitter(width = 0.10, size = 1.25, alpha = 0.55,
        colour = "#303030"),
    violin = plot +
      ggplot2::geom_violin(width = 0.9, trim = FALSE, alpha = 0.72) +
      ggplot2::stat_summary(fun = stats::median, geom = "point", shape = 21,
        size = 2.2, fill = "white", colour = "#303030"),
    mean_se = plot +
      ggplot2::stat_summary(fun = mean, geom = "col", width = 0.62,
        alpha = 0.72) +
      ggplot2::stat_summary(fun.data = ggplot2::mean_se, geom = "errorbar",
        width = 0.18, linewidth = 0.65) +
      ggplot2::geom_jitter(width = 0.11, size = 1.35, alpha = 0.55,
        colour = "#303030"),
    jitter = plot +
      ggplot2::geom_jitter(width = 0.16, size = 2, alpha = 0.72,
        shape = 21, colour = "#303030")
  )
  plot + ggplot2::facet_wrap(~DiversityIndex, scales = "free_y") +
    ggplot2::theme_classic() +
    ggplot2::theme(legend.position = "none",
      axis.text.x = ggplot2::element_text(angle = 30, hjust = 1)) +
    ggplot2::labs(x = x_label, y = "Alpha diversity", title = title)
}

microbiome_run_alpha <- function(method_id, bundle, spec = list()) {
  started <- proc.time()[["elapsed"]]
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  counts <- microbiome_numeric_matrix(bundle$counts)
  if (identical(method_id, "phylogenetic_tree_build")) {
    return(microbiome_build_phylogenetic_tree(bundle, spec))
  }
  if (identical(method_id, "mpd_mntd_nri_nti")) {
    return(microbiome_run_phylogenetic_metrics(method_id, bundle, spec))
  }
  if (identical(method_id, "phylogenetic_tree")) {
    return(microbiome_run_phylogenetic_tree(bundle, spec))
  }
  if (method_id == "faith_pd") {
    if (!identical(bundle$marker_type, "16S")) stop("Faith PD is only open to 16S data with reliable phylogenetic trees.", call. = FALSE)
    if (!requireNamespace("picante", quietly = TRUE) || !requireNamespace("ape", quietly = TRUE)) stop("The picante or ape package is missing.", call. = FALSE)
    prepared <- microbiome_phylo_prepare(bundle, spec)
    counts <- prepared$counts
    tree <- prepared$tree
    pd <- picante::pd(counts, tree, include.root = TRUE)
    table <- data.frame(SampleID = rownames(counts), FaithPD = pd$PD, Observed = pd$SR, stringsAsFactors = FALSE)
    if (nrow(bundle$metadata)) table <- cbind(table, bundle$metadata[, setdiff(names(bundle$metadata), "SampleID"), drop = FALSE])
    tables <- list(faith_pd = table)
    plots <- list()
    models <- list()
    group_name <- spec$group %||% ""
    test_method <- spec$phylogenetic_test_method %||% "kruskal"
    if (!identical(test_method, "none") && nzchar(group_name) && group_name %in% names(table)) {
      analysis <- table[, c("FaithPD", group_name), drop = FALSE]
      analysis <- analysis[stats::complete.cases(analysis), , drop = FALSE]
      group <- droplevels(factor(analysis[[group_name]]))
      if (nlevels(group) >= 2L) {
        fit <- stats::kruskal.test(analysis$FaithPD ~ group)
        tables$group_test <- data.frame(
          Metric = "Faith PD", Test = fit$method, Statistic = unname(fit$statistic),
          Df = unname(fit$parameter), PValue = fit$p.value, stringsAsFactors = FALSE)
        pairwise <- stats::pairwise.wilcox.test(analysis$FaithPD, group,
          p.adjust.method = spec$p_adjust_method %||% "BH", exact = FALSE)
        comparisons <- as.data.frame(as.table(pairwise$p.value), stringsAsFactors = FALSE)
        names(comparisons) <- c("Group1", "Group2", "AdjustedP")
        comparisons <- comparisons[is.finite(comparisons$AdjustedP), , drop = FALSE]
        if (nrow(comparisons)) tables$posthoc_comparisons <- comparisons
        models$group_test <- fit
        if (requireNamespace("ggplot2", quietly = TRUE)) {
          plot_data <- data.frame(Group = group, FaithPD = analysis$FaithPD)
          plots$faith_pd_by_group <- ggplot2::ggplot(plot_data, ggplot2::aes(Group, FaithPD, fill = Group)) +
            ggplot2::geom_boxplot(width = 0.68, outlier.shape = NA, alpha = 0.82) +
            ggplot2::geom_jitter(width = 0.12, size = 1.6, alpha = 0.7) +
            ggplot2::theme_classic() + ggplot2::theme(legend.position = "none") +
            ggplot2::labs(x = group_name, y = "Faith's phylogenetic diversity", title = "Faith PD by group")
        }
      }
    }
    return(new_microbiome_result(method_id, marker_type = bundle$marker_type, data_version = bundle$data_version,
      input_summary = microbiome_data_summary(bundle, aligned$orientation), analysis_spec = spec,
      actual_parameters = utils::modifyList(spec, list(include_root = TRUE)),
      package_versions = microbiome_package_versions(c("picante", "ape")), model_objects = models,
      tables = tables, plots = plots, available_outputs = names(tables), available_plots = names(plots),
      generated_code = microbiome_analysis_code(method_id, spec),
      registration_manifest = microbiome_registration_manifest(bundle, method_id, names(tables))))
  }
  if (!requireNamespace("vegan", quietly = TRUE)) stop("Alpha diversity requires the vegan package.", call. = FALSE)
  table <- microbiome_alpha_table(bundle)
  tables <- list(alpha_diversity = table)
  plots <- list()
  model <- NULL
  packages <- "vegan"
  if (method_id %in% c("alpha_core", "richness_indices", "diversity_indices", "evenness_indices")) {
    columns <- switch(method_id,
      richness_indices = c("SampleID", "Observed", "Chao1", "ACE", "FisherAlpha"),
      diversity_indices = c("SampleID", "Shannon", "Simpson", "InverseSimpson", "Hill_q0", "Hill_q1", "Hill_q2"),
      evenness_indices = c("SampleID", "Pielou"), names(table))
    if (method_id == "alpha_core") columns <- c("SampleID", microbiome_alpha_selected_indices(spec))
    metadata_columns <- setdiff(names(table), c("SampleID", "Observed", "Chao1", "ACE", "FisherAlpha", "Shannon", "Simpson", "InverseSimpson", "Hill_q0", "Hill_q1", "Hill_q2", "Pielou"))
    tables$alpha_diversity <- table[, unique(c(columns, metadata_columns)), drop = FALSE]
    if (method_id == "alpha_core") {
      indices <- microbiome_alpha_selected_indices(spec)
      analysis <- microbiome_alpha_statistical_analysis(table, indices, spec)
      tables <- c(tables, analysis$tables)
      model <- analysis$models
      packages <- union(packages, analysis$packages)
      if (requireNamespace("ggplot2", quietly = TRUE) && length(indices)) {
        plots$alpha_diversity <- microbiome_alpha_diversity_plot(
          tables$alpha_diversity, spec, spec$alpha_plot_type %||% "box_jitter")
      }
    }
  } else if (method_id %in% c("alpha_group_comparison", "alpha_multifactor_model")) {
    group_name <- spec$group %||% "Treatment"
    if (!group_name %in% names(table)) stop("Alpha comparison requires a valid grouping variable.", call. = FALSE)
    index <- microbiome_alpha_index(table, spec$alpha_index %||% "Shannon")
    group <- droplevels(factor(table[[group_name]]))
    if (nlevels(group) < 2L) stop("Alpha comparison requires at least two valid groups.", call. = FALSE)
    if (method_id == "alpha_group_comparison") {
      omnibus <- if (nlevels(group) == 2L) stats::wilcox.test(table[[index]] ~ group, exact = FALSE) else stats::kruskal.test(table[[index]] ~ group)
      pairwise <- stats::pairwise.wilcox.test(table[[index]], group, p.adjust.method = spec$fdr_method %||% "BH", exact = FALSE)
      tables$omnibus_test <- data.frame(index = index, test = omnibus$method, statistic = unname(omnibus$statistic), p_value = omnibus$p.value)
      tables$pairwise_tests <- as.data.frame(as.table(pairwise$p.value), stringsAsFactors = FALSE)
      names(tables$pairwise_tests) <- c("group_1", "group_2", "adjusted_p")
      tables$pairwise_tests <- tables$pairwise_tests[is.finite(tables$pairwise_tests$adjusted_p), , drop = FALSE]
      model <- list(omnibus = omnibus, pairwise = pairwise)
    } else {
      effects <- intersect(spec$fixed_effects %||% group_name, names(table))
      if (!length(effects)) effects <- group_name
      formula <- stats::reformulate(effects, response = index)
      model <- stats::lm(formula, data = table)
      tables$model_coefficients <- data.frame(term = rownames(summary(model)$coefficients), summary(model)$coefficients, row.names = NULL, check.names = FALSE)
      tables$model_anova <- data.frame(term = rownames(stats::anova(model)), stats::anova(model), row.names = NULL, check.names = FALSE)
    }
  } else if (method_id == "alpha_environment_regression") {
    environment <- microbiome_aligned_environment(bundle, spec$fixed_effects %||% character())
    index <- microbiome_alpha_index(table, spec$alpha_index %||% "Shannon")
    analysis <- cbind(table[, c("SampleID", index), drop = FALSE], environment)
    model <- stats::lm(stats::reformulate(names(environment), response = index), data = analysis)
    tables$model_coefficients <- data.frame(term = rownames(summary(model)$coefficients), summary(model)$coefficients, row.names = NULL, check.names = FALSE)
    tables$model_anova <- data.frame(term = rownames(stats::anova(model)), stats::anova(model), row.names = NULL, check.names = FALSE)
  } else if (method_id == "alpha_repeated_mixed") {
    if (!requireNamespace("lme4", quietly = TRUE)) stop("Alpha mixed effects models require the lme4 package.", call. = FALSE)
    group_name <- spec$group %||% "Treatment"
    random_name <- spec$random_effect %||% spec$subject_id %||% "Subject"
    if (!all(c(group_name, random_name) %in% names(table))) stop("Please select valid fixed effect and random effect variables.", call. = FALSE)
    index <- microbiome_alpha_index(table, spec$alpha_index %||% "Shannon")
    formula <- stats::as.formula(sprintf("%s ~ %s + (1 | %s)", index, group_name, random_name))
    model <- lme4::lmer(formula, data = table, REML = isTRUE(spec$reml %||% TRUE))
    coefficients <- coef(summary(model))
    tables$model_coefficients <- data.frame(term = rownames(coefficients), coefficients, row.names = NULL, check.names = FALSE)
    tables$random_effects <- as.data.frame(lme4::VarCorr(model))
    packages <- c("vegan", "lme4")
  } else if (method_id == "alpha_rarefaction") {
    minimum_depth <- min(rowSums(counts))
    depths <- unique(pmax(1L, round(seq(1, minimum_depth, length.out = min(40L, minimum_depth)))))
    rarefaction <- do.call(rbind, lapply(seq_len(nrow(counts)), function(row) {
      valid <- depths[depths <= sum(counts[row, ])]
      data.frame(SampleID = rownames(counts)[row], Depth = valid,
        Richness = vapply(valid, function(depth) suppressWarnings(
          as.numeric(vegan::rarefy(counts[row, , drop = FALSE], sample = depth)[[1]])), numeric(1)))
    }))
    tables$rarefaction <- rarefaction
    if (requireNamespace("ggplot2", quietly = TRUE)) plots$rarefaction <- ggplot2::ggplot(rarefaction, ggplot2::aes(Depth, Richness, group = SampleID)) +
      ggplot2::geom_line(alpha = 0.65, linewidth = 0.6, colour = "#2878A8") + ggplot2::theme_classic() +
      ggplot2::labs(x = "Sequencing depth", y = "Expected richness", title = "Sample rarefaction curves")
  } else stop("Alpha adapter does not support method:", method_id, call. = FALSE)
  new_microbiome_result(method_id, marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle, aligned$orientation), analysis_spec = spec, actual_parameters = spec,
    execution_time = proc.time()[["elapsed"]] - started, package_versions = microbiome_package_versions(packages),
    model_objects = list(fit = model), tables = tables, plots = plots, available_outputs = names(tables), available_plots = names(plots),
    generated_code = microbiome_analysis_code(method_id, spec), registration_manifest = microbiome_registration_manifest(bundle, method_id, names(tables)))
}
