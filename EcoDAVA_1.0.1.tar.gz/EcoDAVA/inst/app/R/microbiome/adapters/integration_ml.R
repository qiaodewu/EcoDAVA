microbiome_run_integration_ml <- function(method_id, bundle, spec = list()) {
  if (method_id %in% c("rf_classification", "elastic_net")) return(microbiome_run_grouped_ml(method_id, bundle, spec))
  if (method_id != "procrustes_cross_domain") stop("The cross-domain and machine learning adapter does not support the method:", method_id, call. = FALSE)
  if (!requireNamespace("vegan", quietly = TRUE)) stop("The vegan package is missing.", call. = FALSE)
  second <- spec$second_bundle
  if (!inherits(second, "microbiome_bundle")) stop("16S–ITS Procrustes requires a second microbiome_bundle.", call. = FALSE)
  first_aligned <- microbiome_align_bundle(bundle)$bundle
  second_aligned <- microbiome_align_bundle(second)$bundle
  if (identical(first_aligned$marker_type, second_aligned$marker_type)) stop("Cross-domain analysis requires a 16S and an ITS dataset.", call. = FALSE)
  common <- intersect(first_aligned$sample_ids, second_aligned$sample_ids)
  if (length(common) < 6) stop("Both data domains require at least six fully matched common samples.", call. = FALSE)
  first <- microbiome_numeric_matrix(first_aligned$counts[common, , drop = FALSE])
  second_counts <- microbiome_numeric_matrix(second_aligned$counts[common, , drop = FALSE])
  first_ordination <- stats::cmdscale(vegan::vegdist(first, method = spec$distance %||% "bray"), k = 2, add = TRUE)
  second_ordination <- stats::cmdscale(vegan::vegdist(second_counts, method = spec$distance %||% "bray"), k = 2, add = TRUE)
  permutations <- as.integer(spec$permutations %||% 999L)
  seed <- as.integer(spec$seed %||% 2026L)
  set.seed(seed)
  test <- vegan::protest(first_ordination, second_ordination, permutations = permutations)
  fit <- vegan::procrustes(first_ordination, second_ordination, symmetric = TRUE)
  first_scores <- fit$X
  second_scores <- fit$Yrot
  scores <- data.frame(SampleID = common, FirstAxis1 = first_scores[, 1], FirstAxis2 = first_scores[, 2],
    SecondAxis1 = second_scores[, 1], SecondAxis2 = second_scores[, 2], stringsAsFactors = FALSE)
  summary <- data.frame(ProcrustesCorrelation = unname(test$t0), SumOfSquares = fit$ss,
    PValue = test$signif, Permutations = permutations, MatchedSamples = length(common),
    FirstMarker = first_aligned$marker_type, SecondMarker = second_aligned$marker_type)
  tables <- list(protest = summary, matched_scores = scores)
  spec$second_bundle <- NULL
  spec$permutations <- permutations
  new_microbiome_result(method_id, marker_type = paste(first_aligned$marker_type, second_aligned$marker_type, sep = "+"),
    data_version = paste(first_aligned$data_version, second_aligned$data_version, sep = "+"), analysis_spec = spec,
    actual_parameters = spec, package_versions = microbiome_package_versions("vegan"), random_seed = seed,
    model_objects = list(procrustes = fit, protest = test), tables = tables, statistics = summary,
    available_outputs = names(tables), generated_code = microbiome_procrustes_code(spec),
    registration_manifest = microbiome_registration_manifest(first_aligned, method_id, names(tables)))
}

microbiome_group_folds <- function(groups, folds, seed) {
  groups <- as.character(groups)
  unique_groups <- unique(groups)
  if (length(unique_groups) < 3) stop("Grouped cross-validation requires at least three independent blocks/plots.", call. = FALSE)
  folds <- min(as.integer(folds), length(unique_groups))
  set.seed(seed)
  shuffled <- sample(unique_groups)
  assignment <- stats::setNames(rep(seq_len(folds), length.out = length(shuffled)), shuffled)
  unname(assignment[groups])
}

microbiome_classification_metrics <- function(observed, predicted) {
  observed <- factor(observed)
  predicted <- factor(predicted, levels = levels(observed))
  confusion <- table(Observed = observed, Predicted = predicted)
  recall <- diag(confusion) / pmax(rowSums(confusion), 1)
  list(confusion = confusion, metrics = data.frame(Accuracy = mean(observed == predicted), BalancedAccuracy = mean(recall), Samples = length(observed)))
}

microbiome_run_grouped_ml <- function(method_id, bundle, spec = list()) {
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  counts <- microbiome_numeric_matrix(bundle$counts)
  metadata <- bundle$metadata
  outcome_name <- spec$group %||% "Treatment"
  split_name <- spec$block %||% if ("Block" %in% names(metadata)) "Block" else "PlotID"
  if (!all(c(outcome_name, split_name) %in% names(metadata))) stop("Machine learning requires categorical outcomes and block/plot splitting variables.", call. = FALSE)
  outcome <- droplevels(factor(metadata[[outcome_name]]))
  if (nlevels(outcome) < 2) stop("Categorical outcomes require at least two levels.", call. = FALSE)
  seed <- as.integer(spec$seed %||% 2026L)
  fold_id <- microbiome_group_folds(metadata[[split_name]], spec$cv_folds %||% 5L, seed)
  x <- log(counts + as.numeric(spec$pseudocount %||% 0.5))
  x <- x - rowMeans(x)
  predictions <- rep(NA_character_, nrow(x))
  fold_models <- vector("list", max(fold_id))
  if (method_id == "rf_classification") {
    if (!requireNamespace("ranger", quietly = TRUE)) stop("Missing ranger package.", call. = FALSE)
    for (fold in sort(unique(fold_id))) {
      train <- fold_id != fold
      model_data <- data.frame(.response = outcome[train], x[train, , drop = FALSE], check.names = FALSE)
      fit <- ranger::ranger(.response ~ ., data = model_data, probability = TRUE,
        num.trees = as.integer(spec$num_trees %||% 500L), importance = "permutation", seed = seed + fold)
      probability <- predict(fit, data = data.frame(x[!train, , drop = FALSE], check.names = FALSE))$predictions
      predictions[!train] <- colnames(probability)[max.col(probability, ties.method = "first")]
      fold_models[[fold]] <- fit
    }
    full_data <- data.frame(.response = outcome, x, check.names = FALSE)
    full_fit <- ranger::ranger(.response ~ ., data = full_data, probability = TRUE,
      num.trees = as.integer(spec$num_trees %||% 500L), importance = "permutation", seed = seed)
    importance <- data.frame(Feature = names(full_fit$variable.importance), Importance = unname(full_fit$variable.importance), stringsAsFactors = FALSE)
    packages <- "ranger"
    feature_table <- importance[order(importance$Importance, decreasing = TRUE), , drop = FALSE]
  } else {
    if (!requireNamespace("glmnet", quietly = TRUE)) stop("The glmnet package is missing.", call. = FALSE)
    family <- if (nlevels(outcome) == 2) "binomial" else "multinomial"
    alpha <- as.numeric(spec$alpha %||% 0.5)
    for (fold in sort(unique(fold_id))) {
      train <- fold_id != fold
      inner_groups <- metadata[[split_name]][train]
      inner_fold <- microbiome_group_folds(inner_groups, min(5L, length(unique(inner_groups))), seed + fold)
      fit <- glmnet::cv.glmnet(x[train, , drop = FALSE], outcome[train], family = family, alpha = alpha,
        foldid = inner_fold, type.measure = "class", standardize = TRUE)
      predicted <- predict(fit, newx = x[!train, , drop = FALSE], s = "lambda.min", type = "class")
      predictions[!train] <- as.character(predicted[, 1])
      fold_models[[fold]] <- fit
    }
    full_fit <- glmnet::cv.glmnet(x, outcome, family = family, alpha = alpha, foldid = fold_id,
      type.measure = "class", standardize = TRUE)
    coefficient <- stats::coef(full_fit, s = "lambda.min")
    if (!is.list(coefficient)) coefficient <- list(coefficient)
    feature_table <- do.call(rbind, lapply(seq_along(coefficient), function(index) {
      matrix <- as.matrix(coefficient[[index]])
      data.frame(Class = names(coefficient)[index] %||% levels(outcome)[min(index, nlevels(outcome))], Feature = rownames(matrix), Coefficient = matrix[, 1], stringsAsFactors = FALSE)
    }))
    feature_table <- feature_table[feature_table$Feature != "(Intercept)" & feature_table$Coefficient != 0, , drop = FALSE]
    packages <- "glmnet"
  }
  evaluated <- microbiome_classification_metrics(outcome, predictions)
  prediction_table <- data.frame(SampleID = rownames(counts), Observed = as.character(outcome), Predicted = predictions,
    Fold = fold_id, SplitGroup = as.character(metadata[[split_name]]), Correct = as.character(outcome) == predictions, stringsAsFactors = FALSE)
  fold_map <- unique(prediction_table[, c("SplitGroup", "Fold")])
  tables <- list(predictions = prediction_table, metrics = evaluated$metrics,
    confusion = data.frame(as.table(evaluated$confusion), stringsAsFactors = FALSE), feature_results = feature_table, fold_assignment = fold_map)
  spec$group <- outcome_name
  spec$block <- split_name
  spec$cv_folds <- max(fold_id)
  new_microbiome_result(method_id, marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle, aligned$orientation), analysis_spec = spec, actual_parameters = spec,
    package_versions = microbiome_package_versions(packages), random_seed = seed,
    model_objects = list(full_fit = full_fit, fold_models = fold_models), tables = tables, predictions = prediction_table,
    feature_results = feature_table, statistics = evaluated$metrics, available_outputs = names(tables),
    generated_code = microbiome_ml_code(method_id, spec), registration_manifest = microbiome_registration_manifest(bundle, method_id, names(tables)))
}
