microbiome_species_environment_aggregate <- function(bundle, rank = "Genus") {
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  counts <- microbiome_numeric_matrix(bundle$counts)
  taxonomy <- bundle$taxonomy
  if (!nrow(taxonomy) || !rank %in% names(taxonomy)) {
    stop("The selected taxonomy rank is not available in the taxonomy table: ", rank, call. = FALSE)
  }
  labels <- microbiome_normalize_taxonomy_labels(taxonomy[[rank]], rank)
  aggregated <- t(rowsum(t(counts), group = labels, reorder = FALSE))
  aggregated <- aggregated[, order(colMeans(aggregated), decreasing = TRUE), drop = FALSE]
  mapping <- data.frame(Feature = colnames(counts), Taxon = labels, Rank = rank,
    stringsAsFactors = FALSE)
  taxonomy_columns <- intersect(
    c("Domain", "Kingdom", "Phylum", "Class", "Order", "Family", "Genus",
      "Species"),
    names(taxonomy))
  for (column in taxonomy_columns) mapping[[column]] <- as.character(taxonomy[[column]])
  list(bundle = bundle, counts = aggregated, rank = rank, mapping = mapping)
}

microbiome_species_environment_metadata <- function(bundle) {
  sample_ids <- rownames(bundle$counts %||% data.frame()) %||% character()
  empty_aligned <- function() {
    data.frame(row.names = sample_ids, check.names = FALSE)
  }
  align_table <- function(value) {
    value <- as.data.frame(value %||% data.frame(), check.names = FALSE)
    if (!length(sample_ids) || !nrow(value)) return(empty_aligned())
    ids <- if ("SampleID" %in% names(value)) as.character(value$SampleID) else rownames(value)
    if (!all(sample_ids %in% ids)) return(empty_aligned())
    value <- value[match(sample_ids, ids), , drop = FALSE]
    rownames(value) <- sample_ids
    value$SampleID <- NULL
    value
  }
  metadata <- align_table(bundle$metadata)
  environment <- align_table(bundle$environment)
  duplicate_names <- intersect(names(environment), names(metadata))
  if (length(duplicate_names)) environment <- environment[, setdiff(names(environment), duplicate_names), drop = FALSE]
  cbind(metadata, environment, stringsAsFactors = FALSE)
}

microbiome_species_environment_context <- function(bundle, spec = list()) {
  rank <- spec$taxonomic_rank %||% "Genus"
  aggregation <- microbiome_species_environment_aggregate(bundle, rank)
  data <- microbiome_species_environment_metadata(aggregation$bundle)
  numeric_variables <- names(data)[vapply(data, is.numeric, logical(1))]
  taxa <- intersect(as.character(spec$taxa_variables %||% character()), colnames(aggregation$counts))
  if (!length(taxa)) {
    maximum <- max(1L, as.integer(spec$maximum_taxa %||% 20L))
    taxa <- utils::head(colnames(aggregation$counts), maximum)
  }
  environments <- intersect(as.character(spec$environment_factors %||% character()), numeric_variables)
  if (!length(environments)) environments <- utils::head(numeric_variables, 4L)
  if (!length(environments)) stop("Select at least one numeric environmental factor.", call. = FALSE)
  group_name <- if (isTRUE(spec$use_grouping)) as.character(spec$group %||% "") else ""
  if (nzchar(group_name) && !group_name %in% names(data)) {
    stop("The selected grouping variable is not available in sample metadata.", call. = FALSE)
  }
  list(
    bundle = aggregation$bundle,
    counts = aggregation$counts[, taxa, drop = FALSE],
    all_counts = aggregation$counts,
    metadata = data,
    taxa = taxa,
    environments = environments,
    group_name = group_name,
    group = if (nzchar(group_name)) droplevels(factor(data[[group_name]])) else NULL,
    rank = rank,
    mapping = aggregation$mapping
  )
}

microbiome_species_environment_diagnostics <- function(bundle, spec = list()) {
  context <- microbiome_species_environment_context(bundle, spec)
  environment <- context$metadata[, context$environments, drop = FALSE]
  correlation <- stats::cor(environment, use = "pairwise.complete.obs")
  threshold <- as.numeric(spec$environment_correlation_threshold %||% 0.8)
  index <- which(upper.tri(correlation) & abs(correlation) >= threshold, arr.ind = TRUE)
  high_correlation <- if (nrow(index)) {
    data.frame(
      Variable1 = rownames(correlation)[index[, 1]],
      Variable2 = colnames(correlation)[index[, 2]],
      Correlation = correlation[index],
      Threshold = threshold,
      stringsAsFactors = FALSE
    )
  } else {
    data.frame(Variable1 = character(), Variable2 = character(),
      Correlation = numeric(), Threshold = numeric())
  }
  vif <- stats::setNames(rep(NA_real_, ncol(environment)), names(environment))
  if (ncol(environment) >= 2L && nrow(environment) > ncol(environment) + 1L) {
    vif[] <- vapply(names(environment), function(variable) {
      others <- setdiff(names(environment), variable)
      fit <- tryCatch(stats::lm(stats::reformulate(others, response = variable),
        data = environment), error = function(error) NULL)
      r2 <- if (is.null(fit)) NA_real_ else summary(fit)$r.squared
      if (is.finite(r2) && r2 < 1) 1 / (1 - r2) else Inf
    }, numeric(1))
  }
  list(
    correlation_matrix = correlation,
    high_correlation = high_correlation,
    vif = data.frame(EnvironmentFactor = names(vif), VIF = as.numeric(vif),
      ExceedsThreshold = vif > as.numeric(spec$vif_threshold %||% 10),
      stringsAsFactors = FALSE)
  )
}

microbiome_species_environment_clr <- function(counts, pseudocount = 0.5) {
  logged <- log(counts + pseudocount)
  logged - rowMeans(logged)
}

microbiome_species_environment_spearman_table <- function(
    abundance, environment, taxa, environments, index, scope, fdr_method = "BH") {
  rows <- list()
  for (taxon in taxa) for (variable in environments) {
    complete <- index[stats::complete.cases(
      abundance[index, taxon], environment[index, variable])]
    test <- if (length(complete) >= 4L) {
      suppressWarnings(stats::cor.test(
        abundance[complete, taxon], environment[complete, variable],
        method = "spearman", exact = FALSE))
    } else NULL
    rho <- if (is.null(test)) NA_real_ else unname(test$estimate)
    n <- length(complete)
    clipped_rho <- if (is.finite(rho)) max(-0.999999, min(0.999999, rho)) else NA_real_
    z <- if (is.finite(clipped_rho) && n > 3L) atanh(clipped_rho) else NA_real_
    se <- if (n > 3L) 1 / sqrt(n - 3) else NA_real_
    rows[[length(rows) + 1L]] <- data.frame(
      Feature = taxon, EnvironmentFactor = variable, Scope = scope,
      effect = rho, standard_error = se,
      conf_low = if (is.finite(z)) tanh(z - stats::qnorm(0.975) * se) else NA_real_,
      conf_high = if (is.finite(z)) tanh(z + stats::qnorm(0.975) * se) else NA_real_,
      raw_p = if (is.null(test)) NA_real_ else test$p.value,
      SampleSize = n, stringsAsFactors = FALSE)
  }
  table <- do.call(rbind, rows)
  table$adjusted_p <- stats::p.adjust(table$raw_p, method = fdr_method)
  table$Term <- table$EnvironmentFactor
  table$contrast <- paste(table$Scope, table$Term, sep = ":")
  table
}

microbiome_species_environment_spearman_difference <- function(group_tables, fdr_method = "BH") {
  if (length(group_tables) < 2L) return(data.frame())
  contrasts <- utils::combn(names(group_tables), 2L, simplify = FALSE)
  rows <- lapply(contrasts, function(groups) {
    first <- group_tables[[groups[[1]]]]
    second <- group_tables[[groups[[2]]]]
    keys <- c("Feature", "EnvironmentFactor")
    value <- merge(first, second, by = keys, suffixes = c("_first", "_second"))
    valid <- is.finite(value$effect_first) & is.finite(value$effect_second) &
      value$SampleSize_first > 3L & value$SampleSize_second > 3L
    z_first <- atanh(pmax(-0.999999, pmin(0.999999, value$effect_first)))
    z_second <- atanh(pmax(-0.999999, pmin(0.999999, value$effect_second)))
    standard_error <- sqrt(
      1 / (value$SampleSize_first - 3) + 1 / (value$SampleSize_second - 3))
    z_statistic <- (z_second - z_first) / standard_error
    value$Contrast <- paste(groups[[2]], "-", groups[[1]])
    value$DeltaR <- value$effect_second - value$effect_first
    value$raw_p <- ifelse(valid, 2 * stats::pnorm(-abs(z_statistic)), NA_real_)
    value$adjusted_p <- stats::p.adjust(value$raw_p, method = fdr_method)
    value[, c(keys, "Contrast", "DeltaR", "raw_p", "adjusted_p",
      "SampleSize_first", "SampleSize_second"), drop = FALSE]
  })
  value <- do.call(rbind, rows)
  rownames(value) <- NULL
  value
}

microbiome_species_environment_spearman <- function(context, spec) {
  abundance <- microbiome_species_environment_clr(
    context$counts, as.numeric(spec$pseudocount %||% 0.5))
  environment <- context$metadata[, context$environments, drop = FALSE]
  fdr_method <- spec$fdr_method %||% "BH"
  overall <- microbiome_species_environment_spearman_table(
    abundance, environment, context$taxa, context$environments,
    seq_len(nrow(abundance)), "Overall", fdr_method)
  group_tables <- list()
  if (!is.null(context$group)) {
    group_tables <- stats::setNames(lapply(levels(context$group), function(level) {
      microbiome_species_environment_spearman_table(
        abundance, environment, context$taxa, context$environments,
        which(context$group == level), level, fdr_method)
    }), levels(context$group))
  }
  table <- if (length(group_tables)) do.call(rbind, group_tables) else overall
  rownames(table) <- NULL
  table$Significant <- is.finite(table$adjusted_p) &
    table$adjusted_p < as.numeric(spec$alpha %||% 0.05)
  overall$Significant <- is.finite(overall$adjusted_p) &
    overall$adjusted_p < as.numeric(spec$alpha %||% 0.05)
  differences <- microbiome_species_environment_spearman_difference(
    group_tables, spec$spearman_fisher_adjust %||% fdr_method)
  if (nrow(differences)) {
    differences$Significant <- is.finite(differences$adjusted_p) &
      differences$adjusted_p < as.numeric(spec$alpha %||% 0.05)
  }
  list(
    table = table,
    overall_table = overall,
    group_tables = group_tables,
    differences = differences,
    models = list(),
    warnings = paste(
      "Spearman correlation on CLR-transformed compositional abundance can still",
      "contain compositional dependence; interpret network edges as associations, not causality.")
  )
}

microbiome_capture_runtime_output <- function(code) {
  value <- NULL
  message_output <- character()
  warning_output <- character()
  standard_output <- utils::capture.output({
    value <- withCallingHandlers(
      code(),
      message = function(condition) {
        message_output <<- c(message_output, conditionMessage(condition))
        invokeRestart("muffleMessage")
      },
      warning = function(condition) {
        warning_output <<- c(warning_output, conditionMessage(condition))
        invokeRestart("muffleWarning")
      }
    )
  }, type = "output")
  clean <- function(lines) {
    lines <- trimws(as.character(lines %||% character()), which = "right")
    lines[nzchar(trimws(lines))]
  }
  list(
    value = value,
    log = c(clean(standard_output), clean(message_output)),
    warnings = unique(clean(warning_output))
  )
}

microbiome_species_environment_maaslin_fit <- function(counts, metadata, fixed_effects,
    spec, scope, reference = NULL) {
  output_dir <- tempfile("dava_species_environment_maaslin2_")
  dir.create(output_dir, recursive = TRUE)
  on.exit(unlink(output_dir, recursive = TRUE, force = TRUE), add = TRUE)
  captured <- microbiome_capture_runtime_output(function() {
    Maaslin2::Maaslin2(
      input_data = as.data.frame(counts, check.names = FALSE),
      input_metadata = metadata,
      output = output_dir,
      min_abundance = as.numeric(spec$minimum_abundance %||% 0),
      min_prevalence = as.numeric(spec$minimum_prevalence %||% 0.1),
      normalization = "CLR", transform = "NONE", analysis_method = "LM",
      fixed_effects = fixed_effects, correction = spec$fdr_method %||% "BH",
      standardize = isTRUE(spec$standardize_environment %||% TRUE),
      cores = max(1L, as.integer(spec$n_cores %||% 1L)),
      plot_heatmap = FALSE, plot_scatter = FALSE, save_scatter = FALSE,
      save_models = FALSE, reference = reference)
  })
  fit <- captured$value
  raw <- as.data.frame(fit$results, check.names = FALSE)
  if (!nrow(raw)) {
    return(list(table = data.frame(), fit = fit,
      runtime_log = captured$log, warnings = captured$warnings))
  }
  table <- data.frame(
    Feature = as.character(raw$feature),
    EnvironmentFactor = as.character(raw$metadata),
    Term = ifelse(is.na(raw$value) | !nzchar(as.character(raw$value)),
      as.character(raw$metadata), paste(raw$metadata, raw$value, sep = ":")),
    Scope = scope,
    effect = suppressWarnings(as.numeric(raw$coef)),
    standard_error = suppressWarnings(as.numeric(raw$stderr)),
    raw_p = suppressWarnings(as.numeric(raw$pval)),
    adjusted_p = suppressWarnings(as.numeric(raw$qval)),
    stringsAsFactors = FALSE)
  table$conf_low <- table$effect - stats::qnorm(0.975) * table$standard_error
  table$conf_high <- table$effect + stats::qnorm(0.975) * table$standard_error
  table$contrast <- paste(table$Scope, table$Term, sep = ":")
  table$Significant <- is.finite(table$adjusted_p) &
    table$adjusted_p < as.numeric(spec$alpha %||% 0.05)
  list(table = table, fit = fit,
    runtime_log = captured$log, warnings = captured$warnings)
}

microbiome_species_environment_maaslin <- function(context, spec) {
  if (!requireNamespace("Maaslin2", quietly = TRUE)) {
    stop("MaAsLin2 analysis requires the Maaslin2 package.", call. = FALSE)
  }
  metadata <- context$metadata
  counts <- context$counts
  environments <- context$environments
  group_mode <- spec$group_mode %||% "independent"
  fits <- list()
  tables <- list()
  runtime_log <- character()
  runtime_warnings <- character()
  if (is.null(context$group)) {
    value <- microbiome_species_environment_maaslin_fit(
      counts, metadata[, environments, drop = FALSE], environments, spec, "Global")
    fits$Global <- value$fit
    tables$Global <- value$table
    runtime_log <- c(runtime_log, value$runtime_log)
    runtime_warnings <- c(runtime_warnings, value$warnings)
  } else if (identical(group_mode, "independent")) {
    for (level in levels(context$group)) {
      index <- which(context$group == level)
      if (length(index) < max(6L, length(environments) + 3L)) next
      value <- microbiome_species_environment_maaslin_fit(
        counts[index, , drop = FALSE],
        metadata[index, environments, drop = FALSE],
        environments, spec, level)
      fits[[level]] <- value$fit
      tables[[level]] <- value$table
      runtime_log <- c(runtime_log, value$runtime_log)
      runtime_warnings <- c(runtime_warnings, value$warnings)
    }
  } else {
    group_name <- context$group_name
    model_metadata <- metadata[, c(group_name, environments), drop = FALSE]
    model_metadata[[group_name]] <- context$group
    reference_level <- spec$reference_group %||% levels(context$group)[1]
    if (!reference_level %in% levels(context$group)) reference_level <- levels(context$group)[1]
    reference <- paste(group_name, reference_level, sep = ",")
    interaction_terms <- character()
    non_reference <- setdiff(levels(context$group), reference_level)
    for (level in non_reference) for (variable in environments) {
      term <- paste0(".DAVA_", make.names(level), "_x_", make.names(variable))
      model_metadata[[term]] <- as.numeric(context$group == level) * as.numeric(model_metadata[[variable]])
      interaction_terms <- c(interaction_terms, term)
    }
    fixed <- c(group_name, environments, interaction_terms)
    value <- microbiome_species_environment_maaslin_fit(
      counts, model_metadata, fixed, spec, "Interaction", reference)
    value$table$EnvironmentFactor <- sub(
      "^\\.DAVA_[^_]+_x_", "", value$table$EnvironmentFactor)
    fits$Interaction <- value$fit
    tables$Interaction <- value$table
    runtime_log <- c(runtime_log, value$runtime_log)
    runtime_warnings <- c(runtime_warnings, value$warnings)
  }
  table <- do.call(rbind, Filter(NROW, tables))
  if (is.null(table) || !nrow(table)) {
    stop("MaAsLin2 did not return estimable associations for the selected variables and groups.",
      call. = FALSE)
  }
  rownames(table) <- NULL
  list(table = table, models = fits, runtime_log = runtime_log,
    warnings = unique(runtime_warnings))
}

microbiome_species_environment_significance <- function(p) {
  ifelse(is.finite(p) & p < 0.001, "***",
    ifelse(is.finite(p) & p < 0.01, "**",
      ifelse(is.finite(p) & p < 0.05, "*", "")))
}

microbiome_species_environment_matrix <- function(table, value = "effect") {
  features <- unique(as.character(table$Feature))
  environments <- unique(as.character(table$EnvironmentFactor))
  result <- matrix(NA_real_, nrow = length(features), ncol = length(environments),
    dimnames = list(features, environments))
  if (nrow(table)) {
    result[cbind(match(table$Feature, features),
      match(table$EnvironmentFactor, environments))] <- table[[value]]
  }
  result
}

microbiome_species_environment_classic_heatmap <- function(table, context, spec) {
  correlation <- microbiome_species_environment_matrix(table, "effect")
  adjusted_p <- microbiome_species_environment_matrix(table, "adjusted_p")
  significance <- microbiome_species_environment_significance(adjusted_p)
  numbers <- matrix(
    paste0(formatC(correlation, format = "f", digits = 2), significance),
    nrow = nrow(correlation), dimnames = dimnames(correlation))
  annotation_row <- NULL
  mapping <- context$mapping
  if ("Phylum" %in% names(mapping)) {
    mapping <- mapping[mapping$Taxon %in% rownames(correlation), , drop = FALSE]
    mapping <- mapping[!duplicated(mapping$Taxon), , drop = FALSE]
    annotation_row <- data.frame(Phylum = mapping$Phylum,
      row.names = mapping$Taxon, check.names = FALSE)
    annotation_row <- annotation_row[rownames(correlation), , drop = FALSE]
  }
  palette <- grDevices::colorRampPalette(
    c(spec$spearman_low_colour %||% "#2C7BB6", "white",
      spec$spearman_high_colour %||% "#D7191C"))(100)
  heatmap <- pheatmap::pheatmap(
    correlation, color = palette, breaks = seq(-1, 1, length.out = 101),
    cluster_rows = isTRUE(spec$spearman_cluster_rows %||% TRUE),
    cluster_cols = isTRUE(spec$spearman_cluster_columns %||% TRUE),
    display_numbers = if (isTRUE(spec$spearman_show_values %||% TRUE)) numbers else FALSE,
    number_color = "black", fontsize_number = 8,
    annotation_row = annotation_row,
    main = "Species-Environment Spearman Correlation",
    border_color = "grey80", silent = TRUE)
  ggplotify::as.ggplot(heatmap$gtable)
}

microbiome_species_environment_tile_plot <- function(table, title,
    value = "effect", facet = "Scope", nonsignificant_grey = FALSE,
    alpha = 0.05, show_values = TRUE, limits = c(-1, 1),
    legend_title = "Spearman r") {
  data <- table[is.finite(table[[value]]), , drop = FALSE]
  if (!nrow(data)) return(NULL)
  data$PlotValue <- data[[value]]
  data$Significance <- microbiome_species_environment_significance(data$adjusted_p)
  data$Label <- if (isTRUE(show_values)) {
    paste0(formatC(data$PlotValue, format = "f", digits = 2), data$Significance)
  } else data$Significance
  data$DisplayValue <- data$PlotValue
  if (isTRUE(nonsignificant_grey)) {
    data$DisplayValue[!is.finite(data$adjusted_p) | data$adjusted_p >= alpha] <- NA_real_
  }
  plot <- ggplot2::ggplot(data,
    ggplot2::aes(.data$EnvironmentFactor, .data$Feature, fill = .data$DisplayValue)) +
    ggplot2::geom_tile(colour = "grey85", linewidth = 0.35) +
    ggplot2::geom_text(ggplot2::aes(label = .data$Label),
      colour = if (isTRUE(nonsignificant_grey)) "#30343B" else "black", size = 3) +
    ggplot2::scale_fill_gradient2(low = "#2C7BB6", mid = "white", high = "#D7191C",
      midpoint = 0, limits = limits, na.value = "grey90", name = legend_title) +
    ggplot2::labs(x = "Environmental factor", y = "Taxon", title = title) +
    ggplot2::theme_classic(base_size = 11) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
  if (nzchar(facet) && facet %in% names(data)) {
    plot <- plot + ggplot2::facet_wrap(stats::as.formula(paste("~", facet)),
      nrow = 1, scales = "fixed")
  }
  plot
}

microbiome_species_environment_bubble_plot <- function(table, grouped = FALSE) {
  data <- table[is.finite(table$effect), , drop = FALSE]
  plot <- ggplot2::ggplot(data,
    ggplot2::aes(.data$EnvironmentFactor, .data$Feature)) +
    ggplot2::geom_point(ggplot2::aes(size = abs(.data$effect), colour = .data$effect),
      alpha = 0.82) +
    ggplot2::scale_colour_gradient2(low = "#2C7BB6", mid = "white",
      high = "#D7191C", midpoint = 0, limits = c(-1, 1), name = "Spearman r") +
    ggplot2::scale_size_continuous(range = c(1.5, 8), name = "|r|") +
    ggplot2::labs(x = "Environmental factor", y = "Taxon",
      title = if (grouped) "Species-Environment Correlation by Group" else
        "Species-Environment Correlation") +
    ggplot2::theme_minimal(base_size = 11) +
    ggplot2::theme(panel.grid = ggplot2::element_blank(),
      axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
  if (isTRUE(grouped)) plot <- plot + ggplot2::facet_wrap(~Scope, nrow = 1)
  plot
}

microbiome_species_environment_network_plot <- function(
    tables, r_threshold = 0.5, p_threshold = 0.05, title = "Correlation Network") {
  edge_frames <- list()
  node_frames <- list()
  for (scope in names(tables)) {
    table <- tables[[scope]]
    edges <- table[is.finite(table$effect) & abs(table$effect) >= r_threshold &
      is.finite(table$adjusted_p) & table$adjusted_p < p_threshold, , drop = FALSE]
    if (!nrow(edges)) next
    graph_edges <- data.frame(from = edges$Feature, to = edges$EnvironmentFactor,
      weight = edges$effect, stringsAsFactors = FALSE)
    graph <- igraph::graph_from_data_frame(graph_edges, directed = FALSE)
    coordinates <- igraph::layout_in_circle(graph)
    nodes <- data.frame(
      Name = igraph::V(graph)$name,
      x = coordinates[, 1], y = coordinates[, 2], Scope = scope,
      Type = ifelse(igraph::V(graph)$name %in% edges$EnvironmentFactor,
        "Environment", "Taxon"), stringsAsFactors = FALSE)
    edge_index <- igraph::ends(graph, igraph::E(graph), names = FALSE)
    edge_frames[[scope]] <- data.frame(
      x = coordinates[edge_index[, 1], 1], y = coordinates[edge_index[, 1], 2],
      xend = coordinates[edge_index[, 2], 1], yend = coordinates[edge_index[, 2], 2],
      Correlation = igraph::E(graph)$weight, Scope = scope)
    node_frames[[scope]] <- nodes
  }
  if (!length(edge_frames)) {
    return(ggplot2::ggplot() +
      ggplot2::annotate("text", x = 0, y = 0,
        label = "No associations passed the selected |r| and FDR thresholds.") +
      ggplot2::labs(title = title) + ggplot2::theme_void(base_size = 12))
  }
  edges <- do.call(rbind, edge_frames)
  nodes <- do.call(rbind, node_frames)
  ggplot2::ggplot() +
    ggplot2::geom_segment(data = edges,
      ggplot2::aes(.data$x, .data$y, xend = .data$xend, yend = .data$yend,
        colour = .data$Correlation, linewidth = abs(.data$Correlation)),
      alpha = 0.72) +
    ggplot2::geom_point(data = nodes,
      ggplot2::aes(.data$x, .data$y, fill = .data$Type, shape = .data$Type),
      size = 5, colour = "white", stroke = 0.8) +
    ggplot2::geom_text(data = nodes,
      ggplot2::aes(.data$x, .data$y, label = .data$Name),
      size = 3.1, vjust = -1.25) +
    ggplot2::scale_colour_gradient2(low = "#2C7BB6", mid = "grey85",
      high = "#D7191C", midpoint = 0, limits = c(-1, 1), name = "Spearman r") +
    ggplot2::scale_linewidth_continuous(range = c(0.5, 3), guide = "none") +
    ggplot2::scale_fill_manual(values = c(Taxon = "#8DA0CB", Environment = "#66C2A5")) +
    ggplot2::scale_shape_manual(values = c(Taxon = 21, Environment = 22)) +
    ggplot2::facet_wrap(~Scope) +
    ggplot2::coord_equal(clip = "off") +
    ggplot2::labs(title = title, fill = NULL, shape = NULL) +
    ggplot2::theme_void(base_size = 11) +
    ggplot2::theme(plot.margin = ggplot2::margin(15, 20, 15, 20))
}

microbiome_species_environment_heatmap <- function(table) {
  value <- table[is.finite(table$effect), , drop = FALSE]
  value$Column <- ifelse(value$Scope == "Global", value$EnvironmentFactor,
    paste(value$Scope, value$EnvironmentFactor, sep = "\n"))
  value$Significance <- ifelse(value$adjusted_p < 0.001, "***",
    ifelse(value$adjusted_p < 0.01, "**", ifelse(value$adjusted_p < 0.05, "*", "")))
  ggplot2::ggplot(value, ggplot2::aes(.data$Column, .data$Feature, fill = .data$effect)) +
    ggplot2::geom_tile(colour = "white", linewidth = 0.35) +
    ggplot2::geom_text(ggplot2::aes(label = .data$Significance), size = 3.5) +
    ggplot2::scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B",
      midpoint = 0, name = "Coefficient") +
    ggplot2::labs(x = "Environmental factor", y = "Taxon",
      title = "Taxon-environment association coefficients") +
    ggplot2::theme_classic(base_size = 12) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
}

microbiome_species_environment_forest <- function(table, maximum = 30L) {
  value <- table[is.finite(table$effect), , drop = FALSE]
  value <- value[order(value$adjusted_p, -abs(value$effect)), , drop = FALSE]
  value <- utils::head(value, maximum)
  value$Label <- paste(value$Feature, value$EnvironmentFactor, sep = " - ")
  value$Label <- factor(value$Label, levels = rev(unique(value$Label)))
  ggplot2::ggplot(value, ggplot2::aes(.data$effect, .data$Label, colour = .data$Scope)) +
    ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "#6B7280") +
    ggplot2::geom_errorbar(ggplot2::aes(xmin = .data$conf_low, xmax = .data$conf_high),
      width = 0.18, linewidth = 0.7, orientation = "y") +
    ggplot2::geom_point(ggplot2::aes(shape = .data$Significant), size = 2.8) +
    ggplot2::scale_shape_manual(values = c(`TRUE` = 16, `FALSE` = 1)) +
    ggplot2::labs(x = "Effect estimate (95% CI)", y = NULL, colour = "Group",
      shape = "FDR < 0.05", title = "Association effect-size comparison") +
    ggplot2::theme_classic(base_size = 12)
}

microbiome_species_environment_scatter <- function(context, table, spec) {
  top <- table[is.finite(table$adjusted_p), , drop = FALSE]
  top <- top[order(top$adjusted_p, -abs(top$effect)), , drop = FALSE]
  if (!nrow(top)) return(NULL)
  top <- top[1, , drop = FALSE]
  abundance <- microbiome_species_environment_clr(
    context$counts, as.numeric(spec$pseudocount %||% 0.5))
  data <- data.frame(
    Environment = context$metadata[[top$EnvironmentFactor]],
    CLRAbundance = abundance[, top$Feature],
    Group = if (is.null(context$group)) factor("All samples") else context$group)
  ggplot2::ggplot(data, ggplot2::aes(.data$Environment, .data$CLRAbundance,
      colour = .data$Group)) +
    ggplot2::geom_point(size = 2.2, alpha = 0.75) +
    ggplot2::geom_smooth(method = "lm", formula = y ~ x, se = TRUE, linewidth = 0.8) +
    ggplot2::labs(x = top$EnvironmentFactor, y = paste(top$Feature, "CLR abundance"),
      colour = "Group", title = "Key taxon-environment association") +
    ggplot2::theme_classic(base_size = 12)
}

microbiome_species_environment_set_plot <- function(table, alpha = 0.05) {
  significant <- table[is.finite(table$adjusted_p) & table$adjusted_p < alpha, , drop = FALSE]
  if (!nrow(significant)) {
    return(ggplot2::ggplot() +
      ggplot2::annotate("text", x = 0, y = 0,
        label = sprintf("No taxon-environment pairs passed FDR < %.3f.", alpha),
        size = 4.2, colour = "#4B5563") +
      ggplot2::xlim(-1, 1) + ggplot2::ylim(-1, 1) +
      ggplot2::labs(title = "Significant association-set comparison") +
      ggplot2::theme_void(base_size = 12))
  }
  significant$Association <- paste(significant$Feature, significant$EnvironmentFactor, sep = " | ")
  summary <- aggregate(Association ~ Scope, significant, function(value) length(unique(value)))
  names(summary)[2] <- "SignificantAssociations"
  ggplot2::ggplot(summary, ggplot2::aes(.data$Scope, .data$SignificantAssociations,
      fill = .data$Scope)) +
    ggplot2::geom_col(width = 0.68, show.legend = FALSE) +
    ggplot2::geom_text(ggplot2::aes(label = .data$SignificantAssociations), vjust = -0.35) +
    ggplot2::labs(x = "Association set", y = "Significant taxon-environment pairs",
      title = "Significant association-set comparison") +
    ggplot2::theme_classic(base_size = 12)
}

microbiome_species_environment_mantel_correlation <- function(context, spec = list()) {
  if (!requireNamespace("microeco", quietly = TRUE) ||
      !requireNamespace("vegan", quietly = TRUE)) {
    stop("Mantel-Correlation requires microeco and vegan.", call. = FALSE)
  }
  environment <- context$metadata[, context$environments, drop = FALSE]
  feature_counts <- as.matrix(context$bundle$counts)
  complete <- stats::complete.cases(environment) &
    stats::complete.cases(feature_counts)
  if (sum(complete) < 4L) {
    stop("Mantel-Correlation requires at least four complete samples.", call. = FALSE)
  }
  environment <- environment[complete, , drop = FALSE]
  feature_counts <- feature_counts[complete, , drop = FALSE]
  distance_method <- spec$mantel_distance %||% "bray"
  cor_method <- match.arg(spec$mantel_correlation_method %||% "pearson",
    c("pearson", "spearman", "kendall"))
  p_adjust <- spec$mantel_p_adjust %||% spec$fdr_method %||% "fdr"
  p_adjust <- if (identical(p_adjust, "BH")) "fdr" else p_adjust
  permutations <- max(99L, as.integer(spec$mantel_permutations %||% 999L))
  partial <- isTRUE(spec$mantel_partial %||% TRUE) && ncol(environment) > 1L
  fits <- lapply(context$taxa, function(taxon) {
    features <- context$mapping$Feature[context$mapping$Taxon == taxon]
    features <- intersect(features, colnames(feature_counts))
    if (!length(features)) return(NULL)
    distance_input <- feature_counts[, features, drop = FALSE]
    method <- distance_method
    if (identical(method, "aitchison")) {
      distance_input <- microbiome_species_environment_clr(
        distance_input, as.numeric(spec$pseudocount %||% 0.5))
      method <- "euclidean"
    }
    distance <- as.matrix(vegan::vegdist(distance_input, method = method))
    object <- microeco::trans_env$new(dataset = NULL, add_data = environment,
      standardize = isTRUE(spec$mantel_standardize %||% FALSE))
    object$cal_mantel(add_matrix = distance, partial_mantel = partial,
      method = cor_method, p_adjust_method = p_adjust,
      permutations = permutations)
    mantel <- object$res_mantel
    if (!nrow(mantel)) return(NULL)
    names(mantel)[names(mantel) == "Variables"] <- "env"
    names(mantel)[names(mantel) == "Correlation coefficient"] <- "r"
    if (!"env" %in% names(mantel)) mantel$env <- rownames(mantel)
    if (!"r" %in% names(mantel)) {
      candidate <- intersect(c("Mantel.r", "correlation", "statistic"), names(mantel))
      mantel$r <- if (length(candidate)) mantel[[candidate[[1]]]] else NA_real_
    }
    raw_column <- intersect(c("p.value", "Pvalue", "p"), names(mantel))
    adjusted_column <- intersect(c("p.adjusted", "AdjPvalue", "p.adj"), names(mantel))
    mantel$raw_p <- if (length(raw_column)) mantel[[raw_column[[1]]]] else NA_real_
    mantel$adjusted_p <- if (length(adjusted_column)) {
      mantel[[adjusted_column[[1]]]]
    } else {
      stats::p.adjust(mantel$raw_p, method = spec$mantel_p_adjust %||% "BH")
    }
    mantel$spec <- taxon
    mantel$FeatureCount <- length(features)
    list(object = object, mantel = mantel, distance = distance,
      features = features)
  })
  names(fits) <- context$taxa
  fits <- Filter(Negate(is.null), fits)
  if (!length(fits)) stop("No selected taxonomic group could be used for Mantel-Correlation.",
    call. = FALSE)
  mantel <- do.call(rbind, lapply(fits, `[[`, "mantel"))
  rownames(mantel) <- NULL
  mantel$Significant <- is.finite(mantel$adjusted_p) &
    mantel$adjusted_p < as.numeric(spec$alpha %||% 0.05)
  r_breaks <- sort(c(as.numeric(spec$mantel_r_break_1 %||% 0.3),
    as.numeric(spec$mantel_r_break_2 %||% 0.6)))
  p_breaks <- sort(c(as.numeric(spec$mantel_p_break_1 %||% 0.01),
    as.numeric(spec$mantel_p_break_2 %||% 0.05)))
  plot_table <- data.frame(
    spec = as.character(mantel$spec),
    env = as.character(mantel$env),
    r = as.numeric(mantel$r),
    p.value = as.numeric(mantel$adjusted_p),
    raw_p = as.numeric(mantel$raw_p),
    stringsAsFactors = FALSE
  )
  plot_table$rd <- cut(plot_table$r, breaks = c(-Inf, r_breaks, Inf),
    labels = c(sprintf("< %g", r_breaks[[1]]),
      sprintf("%g - %g", r_breaks[[1]], r_breaks[[2]]),
      sprintf(">= %g", r_breaks[[2]])), include.lowest = TRUE)
  plot_table$pd <- cut(plot_table$p.value, breaks = c(-Inf, p_breaks, Inf),
    labels = c(sprintf("< %g", p_breaks[[1]]),
      sprintf("%g - %g", p_breaks[[1]], p_breaks[[2]]),
      sprintf(">= %g", p_breaks[[2]])), include.lowest = TRUE)
  list(
    table = mantel,
    overall_table = mantel,
    mantel = mantel,
    plot_table = plot_table,
    environment_data = environment,
    group_tables = list(),
    models = stats::setNames(lapply(fits, `[[`, "object"), names(fits)),
    warnings = paste0(
      "Each selected taxonomic group uses the original ASV/OTU features mapped to it. ",
      "Mantel links compare that group's community distance with each environmental ",
      "distance; the triangle shows Pearson correlations among environmental factors.")
  )
}

microbiome_species_environment_mantel_plot <- function(environment_data, plot_table,
    spec = list()) {
  if (!requireNamespace("ggcor", quietly = TRUE)) {
    stop(paste0(
      "Mantel test + Correlation heatmap requires ggcor. Install it with ",
      "remotes::install_github('Github-Yilei/ggcor')."), call. = FALSE)
  }
  environment_data <- as.data.frame(environment_data, check.names = FALSE)
  plot_table <- as.data.frame(plot_table, stringsAsFactors = FALSE)
  if (ncol(environment_data) < 2L || !nrow(plot_table)) return(NULL)
  triangle <- match.arg(spec$mantel_triangle %||% "upper", c("upper", "lower"))
  line_widths <- c(as.numeric(spec$mantel_r_width_low %||% 0.5),
    as.numeric(spec$mantel_r_width_mid %||% 1.5),
    as.numeric(spec$mantel_r_width_high %||% 3))
  names(line_widths) <- levels(plot_table$rd)
  p_colours <- c(spec$mantel_p_colour_low %||% "#D95F02",
    spec$mantel_p_colour_mid %||% "#1B9E77",
    spec$mantel_p_colour_high %||% "#A2A2A288")
  names(p_colours) <- levels(plot_table$pd)
  correlation_plot <- ggcor::quickcor(
    environment_data, type = triangle, cor.test = TRUE, method = "pearson",
    show.diag = isTRUE(spec$mantel_show_diagonal %||% FALSE),
    grid.colour = spec$mantel_grid_colour %||% "grey80",
    grid.size = as.numeric(spec$mantel_grid_width %||% 0.25)
  )
  mark_data <- correlation_plot$data
  mark_data$mark <- microbiome_species_environment_significance(
    mark_data$p.value)
  mark_data <- mark_data[
    is.finite(mark_data$p.value) &
      mark_data$p.value < as.numeric(spec$mantel_cor_sig_threshold %||% 0.05),
    , drop = FALSE]
  correlation_plot +
    ggplot2::geom_tile(
      width = 0.95, height = 0.95,
      alpha = as.numeric(spec$mantel_square_alpha %||% 1)) +
    ggplot2::geom_text(
      data = mark_data,
      ggplot2::aes(x = .data$.col.id, y = .data$.row.id,
        label = .data$mark),
      inherit.aes = FALSE,
      colour = spec$mantel_star_colour %||% "black",
      size = as.numeric(spec$mantel_star_size %||% 6)) +
    ggcor::anno_link(
      ggplot2::aes(colour = .data$pd, size = .data$rd),
      data = plot_table, pos = spec$mantel_link_position %||% "right",
      label.size = as.numeric(spec$mantel_taxon_label_size %||% 3.88),
      width = as.numeric(spec$mantel_link_curve %||% 0.3)) +
    ggplot2::scale_size_manual(values = line_widths, drop = FALSE) +
    ggplot2::scale_colour_manual(values = p_colours, drop = FALSE) +
    ggplot2::scale_fill_gradient2(
      low = spec$mantel_low_colour %||% "#2166AC",
      mid = spec$mantel_mid_colour %||% "white",
      high = spec$mantel_high_colour %||% "#B2182B",
      midpoint = 0, limits = c(-1, 1), na.value = "grey90") +
    ggplot2::guides(
      size = ggplot2::guide_legend(title = "Mantel's r",
        override.aes = list(colour = "grey35"), order = 2),
      colour = ggplot2::guide_legend(title = "Mantel's p",
        override.aes = list(size = 3), order = 1),
      fill = ggplot2::guide_colorbar(title = "Pearson's r", order = 3)) +
    ggplot2::labs(title = spec$mantel_plot_title %||%
        "Mantel test + Correlation heatmap") +
    ggplot2::theme(
      text = ggplot2::element_text(size = as.numeric(spec$mantel_base_size %||% 11)),
      axis.text.x = ggplot2::element_text(
        angle = as.numeric(spec$mantel_x_angle %||% 45), hjust = 1),
      legend.position = spec$mantel_legend_position %||% "right",
      plot.title = ggplot2::element_text(face = "bold"))
}

microbiome_species_environment_formula <- function(method_id, taxa, environments,
    use_grouping = FALSE, group = "", group_mode = "independent") {
  taxa_label <- if (length(taxa)) paste(taxa, collapse = ", ") else "<select taxa>"
  environment_label <- if (length(environments)) paste(environments, collapse = " + ") else
    "<select environmental factors>"
  if (identical(method_id, "species_env_spearman")) {
    prefix <- if (isTRUE(use_grouping)) "Group-stratified Spearman" else
      "Overall Spearman"
    return(paste0(prefix, ": CLR[", taxa_label, "] ~ ", environment_label,
      if (isTRUE(use_grouping)) paste0(" | ", group) else ""))
  }
  if (identical(method_id, "mantel_correlation")) {
    return(paste0("Mantel-Correlation: beta-distance(each selected ",
      "taxonomic group: ", taxa_label, ") ~ environmental distances(",
      environment_label, ")"))
  }
  rhs <- environment_label
  if (isTRUE(use_grouping) && identical(group_mode, "interaction")) {
    rhs <- paste0(group, " + ", environment_label, " + ", group, ":(",
      environment_label, ")")
  }
  prefix <- if (isTRUE(use_grouping) && identical(group_mode, "independent"))
    paste0("MaAsLin2 by ", group, ": ") else "MaAsLin2: "
  paste0(prefix, "CLR[", taxa_label, "] ~ ", rhs)
}

microbiome_species_environment_plot_choices <- function(method_id, use_grouping = FALSE) {
  if (identical(method_id, "mantel_correlation")) {
    return(c("Mantel test + Correlation heatmap" = "mantel_correlation_heatmap"))
  }
  if (!identical(method_id, "species_env_spearman")) {
    return(c(
      "Coefficient heatmap" = "coefficient_heatmap",
      "Effect-size forest plot" = "effect_forest",
      "Scatter fit plot" = "scatter_fit",
      "UpSet/Venn association sets" = "association_sets"))
  }
  if (isTRUE(use_grouping)) {
    return(c(
      "Side-by-side heatmaps" = "grouped_heatmaps",
      "Delta-r heatmap" = "delta_heatmap",
      "Grouped bubble plot" = "grouped_bubble",
      "Differential-significance heatmap" = "differential_significance_heatmap",
      "Network comparison" = "network_comparison"))
  }
  c(
    "Classic correlation heatmap" = "classic_heatmap",
    "Correlation network" = "correlation_network",
    "Correlation bubble plot" = "correlation_bubble")
}

microbiome_species_environment_advanced_field_ids <- function(method_id = "") c(
  "association_min_prevalence", "association_min_abundance",
  "association_p_adjust", "association_alpha", "association_pseudocount",
  "association_standardize", "association_cores", "association_max_plot",
  "association_correlation_threshold", "association_vif_threshold",
  if (identical(method_id, "species_env_spearman")) c(
    "spearman_cluster_rows", "spearman_cluster_columns",
    "spearman_show_values", "spearman_network_r_threshold",
     "spearman_network_p_threshold", "spearman_fisher_adjust",
     "spearman_low_colour", "spearman_high_colour"),
   if (identical(method_id, "mantel_correlation")) c(
    "mantel_distance", "mantel_correlation_method", "mantel_p_adjust",
    "mantel_permutations", "mantel_partial", "mantel_standardize",
    "mantel_r_break_1", "mantel_r_break_2", "mantel_p_break_1",
    "mantel_p_break_2", "mantel_triangle", "mantel_show_diagonal",
    "mantel_cor_sig_threshold", "mantel_star_size", "mantel_grid_width",
    "mantel_square_alpha", "mantel_r_width_low", "mantel_r_width_mid",
    "mantel_r_width_high", "mantel_link_curve", "mantel_taxon_label_size",
    "mantel_x_angle", "mantel_low_colour", "mantel_mid_colour",
    "mantel_high_colour", "mantel_p_colour_low", "mantel_p_colour_mid",
    "mantel_p_colour_high", "mantel_base_size"))

microbiome_species_environment_advanced_ui <- function(ns, method_id, current = list()) {
  shiny::tagList(
    shiny::tags$h5("Association model"),
    shiny::sliderInput(ns("association_min_prevalence"), "Minimum taxon prevalence",
      0, 1, as.numeric(current$association_min_prevalence %||% 0.1), 0.01),
    shiny::numericInput(ns("association_min_abundance"), "Minimum abundance",
      as.numeric(current$association_min_abundance %||% 0), min = 0),
    shiny::selectInput(ns("association_p_adjust"), "Multiple-testing correction",
      c("FDR (BH)" = "BH", "Bonferroni" = "bonferroni", "Holm" = "holm",
        "Benjamini-Yekutieli" = "BY", "None" = "none"),
      selected = current$association_p_adjust %||% "BH"),
    shiny::sliderInput(ns("association_alpha"), "FDR significance threshold",
      0.001, 0.2, as.numeric(current$association_alpha %||% 0.05), 0.001),
    shiny::numericInput(ns("association_pseudocount"), "CLR pseudocount",
      as.numeric(current$association_pseudocount %||% 0.5), min = 1e-08),
    if (identical(method_id, "maaslin2")) shiny::tagList(
      shiny::checkboxInput(ns("association_standardize"),
        "Standardize environmental factors in MaAsLin2",
        isTRUE(current$association_standardize %||% TRUE)),
      shiny::numericInput(ns("association_cores"), "CPU cores",
        as.integer(current$association_cores %||% 1L), min = 1L, step = 1L)
    ),
    if (identical(method_id, "species_env_spearman")) shiny::tagList(
      shiny::div(class = "alert alert-warning py-2",
        "Spearman correlation is calculated on CLR-transformed abundance. ",
        "Edges describe associations and should not be interpreted as causal effects."),
      shiny::tags$hr(),
      shiny::tags$h5("Heatmaps"),
      shiny::checkboxInput(ns("spearman_cluster_rows"), "Cluster taxa in the overall heatmap",
        isTRUE(current$spearman_cluster_rows %||% TRUE)),
      shiny::checkboxInput(ns("spearman_cluster_columns"),
        "Cluster environmental factors in the overall heatmap",
        isTRUE(current$spearman_cluster_columns %||% TRUE)),
      shiny::checkboxInput(ns("spearman_show_values"),
        "Show correlation values and significance symbols",
        isTRUE(current$spearman_show_values %||% TRUE)),
      shiny::fluidRow(
        shiny::column(6, shiny::selectInput(ns("spearman_low_colour"),
          "Negative correlation colour",
          c("Scientific blue" = "#2C7BB6", "Navy" = "#08306B",
            "Purple" = "#6A51A3", "Teal" = "#178F8F"),
          selected = current$spearman_low_colour %||% "#2C7BB6")),
        shiny::column(6, shiny::selectInput(ns("spearman_high_colour"),
          "Positive correlation colour",
          c("Scientific red" = "#D7191C", "Firebrick" = "#B22222",
            "Orange" = "#E6550D", "Magenta" = "#C51B8A"),
          selected = current$spearman_high_colour %||% "#D7191C"))
      ),
      shiny::tags$hr(),
      shiny::tags$h5("Networks and group differences"),
      shiny::sliderInput(ns("spearman_network_r_threshold"),
        "Network threshold |r|", 0, 1,
        as.numeric(current$spearman_network_r_threshold %||% 0.5), 0.01),
      shiny::sliderInput(ns("spearman_network_p_threshold"),
        "Network FDR threshold", 0.001, 0.2,
        as.numeric(current$spearman_network_p_threshold %||% 0.05), 0.001),
      shiny::selectInput(ns("spearman_fisher_adjust"),
        "Fisher z group-difference correction",
        c("FDR (BH)" = "BH", "Bonferroni" = "bonferroni",
          "Holm" = "holm", "Benjamini-Yekutieli" = "BY", "None" = "none"),
        selected = current$spearman_fisher_adjust %||% "BH"),
      shiny::p(class = "small text-muted",
        "Grouped correlations are adjusted independently within each group. ",
        "Grouped heatmaps keep a common row and column order for direct comparison.")
    ),
    if (identical(method_id, "mantel_correlation")) shiny::tagList(
      shiny::div(class = "alert alert-info py-2",
        "microeco::trans_env$cal_mantel() is run separately for every selected ",
        "taxonomic group. ggcor draws the environmental Pearson-correlation ",
        "triangle and the Mantel links."),
      shiny::tags$h5("Mantel test parameters"),
      shiny::selectInput(ns("mantel_distance"), "Community distance",
        c("Bray-Curtis" = "bray", "Jaccard" = "jaccard",
          "Euclidean" = "euclidean", "Aitchison" = "aitchison"),
        selected = current$mantel_distance %||% "bray"),
      shiny::selectInput(ns("mantel_correlation_method"), "Correlation method",
        c("Pearson" = "pearson", "Spearman" = "spearman",
          "Kendall" = "kendall"),
        selected = current$mantel_correlation_method %||% "pearson"),
      shiny::selectInput(ns("mantel_p_adjust"), "Multiple-testing correction",
        c("FDR (BH)" = "BH", "Bonferroni" = "bonferroni",
          "Holm" = "holm", "Benjamini-Yekutieli" = "BY"),
        selected = current$mantel_p_adjust %||% "BH"),
      shiny::numericInput(ns("mantel_permutations"), "Mantel permutations",
        as.integer(current$mantel_permutations %||% 999L), min = 99L, step = 100L),
      shiny::checkboxInput(ns("mantel_partial"), "Partial Mantel test",
        isTRUE(current$mantel_partial %||% TRUE)),
      shiny::checkboxInput(ns("mantel_standardize"),
        "Standardize environmental variables before Mantel distance",
        isTRUE(current$mantel_standardize %||% FALSE)),
      shiny::tags$h5("Mantel r and adjusted-p categories"),
      shiny::fluidRow(
        shiny::column(6, shiny::numericInput(ns("mantel_r_break_1"),
          "Mantel r break 1", as.numeric(current$mantel_r_break_1 %||% 0.3),
          min = -1, max = 1, step = 0.05)),
        shiny::column(6, shiny::numericInput(ns("mantel_r_break_2"),
          "Mantel r break 2", as.numeric(current$mantel_r_break_2 %||% 0.6),
          min = -1, max = 1, step = 0.05))),
      shiny::fluidRow(
        shiny::column(6, shiny::numericInput(ns("mantel_p_break_1"),
          "Adjusted p break 1", as.numeric(current$mantel_p_break_1 %||% 0.01),
          min = 0, max = 1, step = 0.001)),
        shiny::column(6, shiny::numericInput(ns("mantel_p_break_2"),
          "Adjusted p break 2", as.numeric(current$mantel_p_break_2 %||% 0.05),
          min = 0, max = 1, step = 0.005))),
      shiny::tags$h5("Correlation triangle and links"),
      shiny::selectInput(ns("mantel_triangle"), "Correlation triangle",
        c("Upper" = "upper", "Lower" = "lower"),
        selected = current$mantel_triangle %||% "upper"),
      shiny::checkboxInput(ns("mantel_show_diagonal"), "Show diagonal",
        isTRUE(current$mantel_show_diagonal %||% FALSE)),
      shiny::sliderInput(ns("mantel_cor_sig_threshold"),
        "Pearson significance threshold", 0.001, 0.2,
        as.numeric(current$mantel_cor_sig_threshold %||% 0.05), 0.001),
      shiny::sliderInput(ns("mantel_star_size"), "Significance-star size",
        2, 12, as.numeric(current$mantel_star_size %||% 6), 0.5),
      shiny::sliderInput(ns("mantel_square_alpha"), "Square opacity",
        0.2, 1, as.numeric(current$mantel_square_alpha %||% 1), 0.05),
      shiny::sliderInput(ns("mantel_grid_width"), "Grid-line width",
        0, 2, as.numeric(current$mantel_grid_width %||% 0.25), 0.05),
      shiny::fluidRow(
        shiny::column(4, shiny::numericInput(ns("mantel_r_width_low"),
          "Low-r width", as.numeric(current$mantel_r_width_low %||% 0.5),
          min = 0.1, max = 8, step = 0.1)),
        shiny::column(4, shiny::numericInput(ns("mantel_r_width_mid"),
          "Mid-r width", as.numeric(current$mantel_r_width_mid %||% 1.5),
          min = 0.1, max = 8, step = 0.1)),
        shiny::column(4, shiny::numericInput(ns("mantel_r_width_high"),
          "High-r width", as.numeric(current$mantel_r_width_high %||% 3),
          min = 0.1, max = 8, step = 0.1))),
      shiny::sliderInput(ns("mantel_link_curve"), "Link curvature",
        0.05, 1, as.numeric(current$mantel_link_curve %||% 0.3), 0.05),
      shiny::sliderInput(ns("mantel_taxon_label_size"), "Taxon label size",
        2, 10, as.numeric(current$mantel_taxon_label_size %||% 3.88), 0.25),
      shiny::sliderInput(ns("mantel_x_angle"), "Environment label angle",
        0, 90, as.numeric(current$mantel_x_angle %||% 45), 5),
      shiny::numericInput(ns("mantel_base_size"), "Base font size",
        as.numeric(current$mantel_base_size %||% 11), min = 7, max = 24),
      shiny::fluidRow(
        shiny::column(4, microbiome_colour_input(
          ns, "mantel_low_colour", "Negative",
          current$mantel_low_colour %||% "#2166AC")),
        shiny::column(4, microbiome_colour_input(
          ns, "mantel_mid_colour", "Midpoint",
          current$mantel_mid_colour %||% "white")),
        shiny::column(4, microbiome_colour_input(
          ns, "mantel_high_colour", "Positive",
          current$mantel_high_colour %||% "#B2182B"))
      ),
      shiny::fluidRow(
        shiny::column(4, microbiome_colour_input(
          ns, "mantel_p_colour_low", "p < 0.01",
          current$mantel_p_colour_low %||% "#D95F02")),
        shiny::column(4, microbiome_colour_input(
          ns, "mantel_p_colour_mid", "p 0.01-0.05",
          current$mantel_p_colour_mid %||% "#1B9E77")),
        shiny::column(4, microbiome_colour_input(
          ns, "mantel_p_colour_high", "p >= 0.05",
          current$mantel_p_colour_high %||% "#A2A2A288"))
      )
    ),
    shiny::tags$hr(),
    shiny::tags$h5("Diagnostics and figures"),
    shiny::sliderInput(ns("association_correlation_threshold"),
      "High-correlation threshold |r|", 0.5, 0.99,
      as.numeric(current$association_correlation_threshold %||% 0.8), 0.01),
    shiny::numericInput(ns("association_vif_threshold"), "VIF warning threshold",
      as.numeric(current$association_vif_threshold %||% 10), min = 1),
    shiny::numericInput(ns("association_max_plot"),
      "Maximum associations in forest plot",
      as.integer(current$association_max_plot %||% 30L), min = 5L, step = 5L)
  )
}

microbiome_species_environment_precheck_ui <- function(ns, current = list()) {
  shiny::tagList(
    shiny::tags$p(class = "text-muted",
      "Checks sample alignment, selected taxonomic aggregation, missing values, ",
      "environmental-factor correlation and variance inflation."),
    shiny::sliderInput(ns("association_correlation_threshold"),
      "High-correlation threshold |r|", 0.5, 0.99,
      as.numeric(current$association_correlation_threshold %||% 0.8), 0.01),
    shiny::numericInput(ns("association_vif_threshold"), "VIF warning threshold",
      as.numeric(current$association_vif_threshold %||% 10), min = 1)
  )
}

microbiome_run_species_environment_association <- function(method_id, bundle, spec = list()) {
  started <- proc.time()[["elapsed"]]
  context <- microbiome_species_environment_context(bundle, spec)
  diagnostics <- microbiome_species_environment_diagnostics(bundle, spec)
  fit <- if (identical(method_id, "species_env_spearman")) {
    microbiome_species_environment_spearman(context, spec)
  } else if (identical(method_id, "mantel_correlation")) {
    captured <- microbiome_capture_runtime_output(function() {
      microbiome_species_environment_mantel_correlation(context, spec)
    })
    value <- captured$value
    value$runtime_log <- captured$log
    value$warnings <- unique(c(value$warnings, captured$warnings))
    value
  } else {
    microbiome_species_environment_maaslin(context, spec)
  }
  table <- fit$table
  default_plots <- unname(microbiome_species_environment_plot_choices(
    method_id, !is.null(context$group)))
  requested <- as.character(spec$plot_types %||% default_plots)
  if (identical(method_id, "species_env_spearman")) {
    requested <- intersect(requested, default_plots)
    if (!length(requested)) requested <- default_plots
  }
  plots <- list()
  if (identical(method_id, "species_env_spearman")) {
    alpha <- as.numeric(spec$alpha %||% 0.05)
    if ("classic_heatmap" %in% requested) {
      plots$classic_heatmap <- microbiome_species_environment_classic_heatmap(
        fit$overall_table, context, spec)
    }
    if ("correlation_network" %in% requested) {
      plots$correlation_network <- microbiome_species_environment_network_plot(
        list(Overall = fit$overall_table),
        as.numeric(spec$spearman_network_r_threshold %||% 0.5),
        as.numeric(spec$spearman_network_p_threshold %||% 0.05),
        "Species-Environment Correlation Network")
    }
    if ("correlation_bubble" %in% requested) {
      plots$correlation_bubble <- microbiome_species_environment_bubble_plot(
        fit$overall_table, FALSE)
    }
    if ("grouped_heatmaps" %in% requested) {
      plots$grouped_heatmaps <- microbiome_species_environment_tile_plot(
        table, "Group-specific Species-Environment Correlations",
        facet = "Scope", alpha = alpha,
        show_values = isTRUE(spec$spearman_show_values %||% TRUE))
    }
    if ("grouped_bubble" %in% requested) {
      plots$grouped_bubble <- microbiome_species_environment_bubble_plot(table, TRUE)
    }
    difference_plot_data <- fit$differences
    if (nrow(difference_plot_data)) {
      difference_plot_data$effect <- difference_plot_data$DeltaR
      difference_plot_data$Scope <- difference_plot_data$Contrast
      if ("delta_heatmap" %in% requested) {
        plots$delta_heatmap <- microbiome_species_environment_tile_plot(
          difference_plot_data, "Group Difference in Spearman Correlation (Fisher z-test)",
          facet = "Contrast", alpha = alpha,
          show_values = isTRUE(spec$spearman_show_values %||% TRUE),
          limits = c(-2, 2), legend_title = "Delta r")
      }
      if ("differential_significance_heatmap" %in% requested) {
        plots$differential_significance_heatmap <-
          microbiome_species_environment_tile_plot(
            difference_plot_data,
            "FDR-significant Group Differences in Spearman Correlation",
            facet = "Contrast", nonsignificant_grey = TRUE, alpha = alpha,
            show_values = isTRUE(spec$spearman_show_values %||% TRUE),
            limits = c(-2, 2), legend_title = "Delta r")
      }
    }
    if ("network_comparison" %in% requested) {
      plots$network_comparison <- microbiome_species_environment_network_plot(
        c(list(Overall = fit$overall_table), fit$group_tables),
        as.numeric(spec$spearman_network_r_threshold %||% 0.5),
        as.numeric(spec$spearman_network_p_threshold %||% 0.05),
        "Overall and Group-specific Correlation Networks")
    }
  } else if (identical(method_id, "mantel_correlation")) {
    if ("mantel_correlation_heatmap" %in% requested) {
      plots$mantel_correlation_heatmap <-
        microbiome_species_environment_mantel_plot(
          fit$environment_data, fit$plot_table, spec)
    }
  } else {
    if ("coefficient_heatmap" %in% requested) {
      plots$coefficient_heatmap <- microbiome_species_environment_heatmap(table)
    }
    if ("effect_forest" %in% requested) {
      plots$effect_forest <- microbiome_species_environment_forest(
        table, as.integer(spec$maximum_plot_associations %||% 30L))
    }
    if ("scatter_fit" %in% requested) {
      plots$scatter_fit <- microbiome_species_environment_scatter(context, table, spec)
    }
    if ("association_sets" %in% requested) {
      plots$association_sets <- microbiome_species_environment_set_plot(
        table, as.numeric(spec$alpha %||% 0.05))
    }
  }
  plots <- Filter(Negate(is.null), plots)
  spec$taxa_variables <- context$taxa
  spec$environment_factors <- context$environments
  spec$taxonomic_rank <- context$rank
  tables <- list(
    association_results = table,
    aggregated_taxa = data.frame(SampleID = rownames(context$all_counts),
      context$all_counts, check.names = FALSE),
    taxonomic_mapping = context$mapping,
    spearman_overall_results = fit$overall_table %||% data.frame(),
    spearman_group_differences = fit$differences %||% data.frame(),
    mantel_results = fit$mantel %||% data.frame(),
    mantel_plot_table = fit$plot_table %||% data.frame(),
    mantel_environment_data = if (is.null(fit$environment_data)) data.frame() else
      data.frame(SampleID = rownames(fit$environment_data),
        fit$environment_data, check.names = FALSE),
    environmental_correlation = as.data.frame(diagnostics$correlation_matrix),
    high_environmental_correlation = diagnostics$high_correlation,
    environmental_vif = diagnostics$vif
  )
  new_microbiome_result(
    method_id, marker_type = context$bundle$marker_type,
    data_version = context$bundle$data_version,
    input_summary = microbiome_data_summary(context$bundle),
    analysis_spec = spec, actual_parameters = spec,
    execution_time = proc.time()[["elapsed"]] - started,
    package_versions = microbiome_package_versions(
      if (identical(method_id, "maaslin2")) "Maaslin2" else
        if (identical(method_id, "mantel_correlation"))
          c("microeco", "vegan", "ggcor", "ggplot2") else
          c("pheatmap", "igraph", "ggplotify")),
    model_objects = fit$models, tables = tables, feature_results = table,
    runtime_log = fit$runtime_log %||% character(),
    warnings = fit$warnings %||% character(),
    plots = plots, available_outputs = names(tables), available_plots = names(plots),
    generated_code = microbiome_species_environment_code(method_id, spec),
    registration_manifest = microbiome_registration_manifest(
      context$bundle, method_id, names(tables)))
}
