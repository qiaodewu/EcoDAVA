microbiome_run_ncm_source <- function(
    method_id = "ncm", bundle, spec = list()) {
  if (!identical(method_id, "ncm")) {
    stop("Assembly adapter does not support method: ", method_id,
      call. = FALSE)
  }
  started <- proc.time()[["elapsed"]]
  microbiome_require_ncm_dependencies <- function() {
    packages <- c("Hmisc", "minpack.lm", "ggplot2", "patchwork")
    missing <- packages[!vapply(
      packages, requireNamespace, logical(1), quietly = TRUE)]
    if (length(missing)) {
      install.packages(missing, repos = "https://cloud.r-project.org")
    }
    missing <- packages[!vapply(
      packages, requireNamespace, logical(1), quietly = TRUE)]
    if (length(missing)) {
      stop(
        paste("Sloan NCM requires:", paste(missing, collapse = ", ")),
        call. = FALSE)
    }
  }
  microbiome_require_ncm_dependencies()
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  counts <- microbiome_numeric_matrix(bundle$counts)
  if (nrow(counts) < 3L) {
    stop("The Sloan neutral community model requires at least 3 samples.", call. = FALSE)
  }
  counts[is.na(counts) | !is.finite(counts)] <- 0
  valid_samples <- rowSums(counts) > 0
  counts <- counts[valid_samples, , drop = FALSE]
  if (!nrow(counts)) stop("There are no valid samples with a total abundance greater than 0.", call. = FALSE)
  group_name <- spec$group %||% ""
  if (nzchar(group_name) && group_name %in% names(bundle$metadata)) {
    group_values <- as.character(bundle$metadata[
      rownames(counts), group_name, drop = TRUE])
    group_levels <- unique(group_values[!is.na(group_values)])
    group_levels <- group_levels[nzchar(group_levels)]
    if (length(group_levels) > 1L) {
      group_results <- lapply(group_levels, function(level) {
        selected <- !is.na(group_values) & group_values == level
        group_bundle <- bundle
        group_bundle$counts <- counts[selected, , drop = FALSE]
        group_bundle$metadata <- bundle$metadata[
          rownames(counts)[selected], , drop = FALSE]
        group_bundle$sample_ids <- rownames(group_bundle$counts)
        group_spec <- spec
        group_spec$group <- ""
        group_spec$ncm_group_label <- level
        microbiome_run_ncm_source(
          method_id = "ncm", bundle = group_bundle, spec = group_spec)
      })
      group_plots <- lapply(seq_along(group_results), function(index) {
        plot <- group_results[[index]]$plots$ncm_fit
        plot + patchwork::plot_annotation(
          title = group_levels[[index]])
      })
      group_summary <- do.call(rbind, lapply(
        seq_along(group_results), function(index) {
          table <- group_results[[index]]$tables$ncm_summary
          table$Group <- group_levels[[index]]
          table
        }))
      group_feature_fit <- do.call(rbind, lapply(
        seq_along(group_results), function(index) {
          table <- group_results[[index]]$tables$feature_fit
          table$Group <- group_levels[[index]]
          table
        }))
      combined_plot <- patchwork::wrap_plots(
        group_plots, ncol = min(2L, length(group_plots)))
      tables <- list(
        ncm_summary = group_summary,
        feature_fit = group_feature_fit,
        ncm_predictions = group_feature_fit)
      return(new_microbiome_result(
        "ncm", status = "warning", marker_type = bundle$marker_type,
        data_version = bundle$data_version,
        input_summary = microbiome_data_summary(bundle, aligned$orientation),
        analysis_spec = spec,
        actual_parameters = list(
          implementation = "minpack.lm::nlsLM + Hmisc::binconf",
          group = group_name, groups = group_levels,
          plot_types = "ncm_fit"),
        model_objects = list(
          nls_model = lapply(group_results, function(x) x$model_objects$nls_model)),
        tables = tables, assembly_tables = tables,
        plots = list(ncm_fit = combined_plot),
        statistics = group_summary,
        warnings = paste(
          "Sloan NCM was fitted independently within each selected group;",
          "it does not by itself prove ecological neutrality."),
        available_outputs = c(names(tables), "ncm_fit"),
        generated_code = microbiome_ncm_code(spec),
        package_versions = microbiome_package_versions(
          c("Hmisc", "minpack.lm", "ggplot2", "patchwork")),
        execution_time = proc.time()[["elapsed"]] - started,
        registration_manifest = microbiome_registration_manifest(
          bundle, "ncm", c(names(tables), "ncm_fit"))))
    }
  }
  data_type <- match.arg(
    spec$ncm_data_type %||% "relative", c("relative", "count"))
  scale_factor <- max(
    1L, as.integer(spec$ncm_scale_factor %||% 10000L))
  if (identical(data_type, "relative")) {
    relative <- counts / rowSums(counts)
    set.seed(as.integer(spec$ncm_seed %||% 2026L))
    scaled <- t(apply(relative, 1, function(probability) {
      as.numeric(stats::rmultinom(
        1, size = scale_factor, prob = probability))
    }))
    rownames(scaled) <- rownames(counts)
    colnames(scaled) <- colnames(counts)
  } else {
    scaled <- counts
  }
  scaled <- scaled[, colSums(scaled) > 0, drop = FALSE]
  if (ncol(scaled) < 3L) {
    stop("Fewer than 3 species are available for Sloan neutral model fitting.", call. = FALSE)
  }
  sample_count <- nrow(scaled)
  N <- mean(rowSums(scaled))
  p_m <- colMeans(scaled)
  p <- p_m / N
  freq <- colMeans(scaled > 0)
  keep <- p > 0 & p < 1 & freq > 0
  p <- p[keep]
  freq <- freq[keep]
  if (length(p) < 3L) {
    stop("Removing zero values leaves fewer than 3 species available for the fit.", call. = FALSE)
  }
  d <- 1 / N
  lower_m <- as.numeric(spec$ncm_lower_m %||% 0.000001)
  upper_m <- as.numeric(spec$ncm_upper_m %||% 0.999999)
  if (!is.finite(lower_m) || !is.finite(upper_m) ||
      lower_m <= 0 || upper_m >= 1 || lower_m >= upper_m) {
    stop("NCM migration bounds must satisfy 0 < lower < upper < 1.",
      call. = FALSE)
  }
  requested_start <- as.numeric(spec$ncm_start_m %||% 0.1)
  start_values <- unique(pmin(
    pmax(c(requested_start, 0.01, 0.05, 0.1, 0.5), lower_m),
    upper_m))
  fit <- NULL
  for (start_value in start_values) {
    candidate <- tryCatch(minpack.lm::nlsLM(
      freq ~ stats::pbeta(
        d, N * m * p, N * m * (1 - p), lower.tail = FALSE),
      start = list(m = start_value),
      lower = c(m = lower_m),
      upper = c(m = upper_m),
      control = minpack.lm::nls.lm.control(
        maxiter = as.integer(spec$ncm_maxiter %||% 1000L))),
      error = function(error) NULL)
    if (!is.null(candidate)) {
      fit <- candidate
      break
    }
  }
  if (!is.null(fit)) {
    m_estimate <- unname(stats::coef(fit)[["m"]])
    confidence_level <- as.numeric(spec$ncm_conf_level %||% 0.95)
    ci <- tryCatch(stats::confint(fit, "m", level = confidence_level),
      error = function(error) c(NA_real_, NA_real_))
  } else {
    objective <- function(log_m) {
      predicted <- stats::pbeta(
        d, N * exp(log_m) * p, N * exp(log_m) * (1 - p),
        lower.tail = FALSE)
      sum((freq - predicted)^2)
    }
    fallback <- stats::optimize(objective, c(log(lower_m), log(upper_m)))
    m_estimate <- exp(fallback$minimum)
    ci <- c(NA_real_, NA_real_)
  }
  ci <- as.numeric(ci)
  freq_pred <- stats::pbeta(
    d, N * m_estimate * p, N * m_estimate * (1 - p),
    lower.tail = FALSE)
  confidence_level <- as.numeric(spec$ncm_conf_level %||% 0.95)
  confidence_level <- min(max(confidence_level, 0.8), 0.99)
  pred_ci <- Hmisc::binconf(
    freq_pred * sample_count, sample_count,
    alpha = 1 - confidence_level, method = "wilson", return.df = TRUE)
  denominator <- sum((freq - mean(freq))^2)
  r_squared <- if (denominator > 0) {
    1 - sum((freq - freq_pred)^2) / denominator
  } else {
    NA_real_
  }
  feature_fit <- data.frame(
    Taxa = names(p), p = as.numeric(p), freq = as.numeric(freq),
    freq.pred = as.numeric(freq_pred),
    Lower = pred_ci[, 2], Upper = pred_ci[, 3],
    stringsAsFactors = FALSE)
  feature_fit$Group <- "med"
  feature_fit$Group[feature_fit$freq < feature_fit$Lower] <- "low"
  feature_fit$Group[feature_fit$freq > feature_fit$Upper] <- "high"
  feature_fit$MeanRelativeAbundance <- feature_fit$p
  feature_fit$ObservedPrevalence <- feature_fit$freq
  feature_fit$PredictedPrevalence <- feature_fit$freq.pred
  feature_fit$Lower95 <- feature_fit$Lower
  feature_fit$Upper95 <- feature_fit$Upper
  feature_fit$Classification <- ifelse(
    feature_fit$Group == "low", "below_neutral",
    ifelse(feature_fit$Group == "high", "above_neutral",
      "neutral_envelope"))
  group_counts <- table(factor(
    feature_fit$Group, levels = c("med", "low", "high")))
  group_pct <- round(group_counts / sum(group_counts) * 100, 1)
  labels <- paste0(names(group_counts), " ", group_pct, "%")
  feature_fit$Group_label <- factor(
    feature_fit$Group, levels = c("med", "low", "high"),
    labels = labels)
  palette <- c("med" = "#435B74", "low" = "#569E74", "high" = "#D98E8D")
  names(palette) <- labels
  annotation_r2 <- paste0("R² = ", round(r_squared, 4))
  annotation_nm <- paste0("Nm = ", round(m_estimate * N, 3))
  annotation_m <- paste0("m = ", round(m_estimate, 4))
  x_max <- max(log10(feature_fit$p), na.rm = TRUE)
  main_plot <- ggplot2::ggplot(
    feature_fit, ggplot2::aes(x = log10(.data$p), y = .data$freq)) +
    ggplot2::geom_point(
      ggplot2::aes(colour = .data$Group_label),
      size = as.numeric(spec$ncm_point_size %||% 1.5),
      alpha = as.numeric(spec$ncm_point_alpha %||% 0.8)) +
    ggplot2::geom_line(
      ggplot2::aes(y = .data$freq.pred),
      colour = spec$ncm_fit_line_colour %||% "black",
      linewidth = as.numeric(spec$ncm_fit_line_width %||% 0.8)) +
    ggplot2::geom_line(
      ggplot2::aes(y = .data$Lower),
      colour = spec$ncm_ci_line_colour %||% "black",
      linetype = "dashed",
      linewidth = as.numeric(spec$ncm_ci_line_width %||% 0.8)) +
    ggplot2::geom_line(
      ggplot2::aes(y = .data$Upper),
      colour = spec$ncm_ci_line_colour %||% "black",
      linetype = "dashed",
      linewidth = as.numeric(spec$ncm_ci_line_width %||% 0.8)) +
    ggplot2::scale_color_manual(values = palette) +
    ggplot2::labs(
      x = "Mean relative abundance (log10)",
      y = "Occurrence frequency") +
    ggplot2::scale_y_continuous(
      limits = c(0, 1.05), breaks = seq(0, 1, 0.25)) +
    ggplot2::annotate(
      "text", x = x_max, y = 0.28, label = annotation_r2,
      hjust = 1, vjust = 0,
      size = as.numeric(spec$ncm_annotation_size %||% 5)) +
    ggplot2::annotate(
      "text", x = x_max, y = 0.19, label = annotation_nm,
      hjust = 1, vjust = 0,
      size = as.numeric(spec$ncm_annotation_size %||% 5)) +
    ggplot2::annotate(
      "text", x = x_max, y = 0.10, label = annotation_m,
      hjust = 1, vjust = 0,
      size = as.numeric(spec$ncm_annotation_size %||% 5)) +
    ggplot2::theme_bw() +
    ggplot2::theme(
      panel.grid = ggplot2::element_blank(),
      axis.title = ggplot2::element_text(
        size = as.numeric(spec$ncm_axis_title_size %||% 14)),
      axis.text = ggplot2::element_text(
        size = as.numeric(spec$ncm_axis_text_size %||% 12)),
      legend.position = "none")
  pie_data <- data.frame(
    Group = factor(labels, levels = labels),
    Value = as.numeric(group_counts))
  pie_plot <- ggplot2::ggplot(
    pie_data, ggplot2::aes(x = "", y = .data$Value, fill = .data$Group)) +
    ggplot2::geom_bar(
      width = 1, stat = "identity", colour = "white", linewidth = 0.2) +
    ggplot2::coord_polar("y", start = 0) +
    ggplot2::scale_fill_manual(values = palette) +
    ggplot2::theme_void() +
    ggplot2::labs(fill = "group") +
    ggplot2::theme(
      legend.position = "right",
      legend.title = ggplot2::element_text(size = 10),
      legend.text = ggplot2::element_text(size = 10),
      legend.key.size = grid::unit(0.5, "cm"),
      plot.margin = ggplot2::margin(0, 0, 0, 0, "cm"))
  final_plot <- main_plot + patchwork::inset_element(
    pie_plot, left = 0.01, bottom = 0.55, right = 0.45, top = 1.05)
  summary <- data.frame(
    MigrationRate = m_estimate, R_squared = r_squared,
    Nm = m_estimate * N, MeanSequencingDepth = N,
    Samples = sample_count, Features = nrow(feature_fit),
    CI_Lower = ci[[1]], CI_Upper = ci[[2]],
    DataType = data_type, ScaleFactor = scale_factor,
    stringsAsFactors = FALSE)
  tables <- list(ncm_summary = summary, feature_fit = feature_fit,
    ncm_predictions = feature_fit)
  new_microbiome_result(
    "ncm", status = "warning", marker_type = bundle$marker_type,
    data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle, aligned$orientation),
    analysis_spec = spec,
    actual_parameters = list(
      implementation = "minpack.lm::nlsLM + Hmisc::binconf",
      data_type = data_type, scale_factor = scale_factor,
      migration_rate = m_estimate, Nm = m_estimate * N,
      plot_types = "ncm_fit"),
    model_objects = list(nls_model = fit),
    tables = tables, assembly_tables = tables, plots = list(ncm_fit = final_plot),
    statistics = summary,
    warnings = paste(
      "Sloan NCM evaluates fit to a neutral occurrence-abundance expectation;",
      "it does not by itself prove ecological neutrality."),
    available_outputs = c(names(tables), "ncm_fit"),
    generated_code = microbiome_ncm_code(spec),
    package_versions = microbiome_package_versions(
      c("Hmisc", "minpack.lm", "ggplot2", "patchwork")),
    execution_time = proc.time()[["elapsed"]] - started,
    registration_manifest = microbiome_registration_manifest(
      bundle, "ncm", c(names(tables), "ncm_fit")))
}

microbiome_icamp_muffle_memory_limit <- function(expr) {
  withCallingHandlers(expr, warning = function(warning) {
    if (grepl("memory\\.limit\\(\\).*no longer supported",
        conditionMessage(warning))) {
      invokeRestart("muffleWarning")
    }
  })
}

microbiome_icamp_seeded_clusters <- function(seed, expr) {
  option_name <- "dava.icamp.parallel.seed"
  old_option <- getOption(option_name)
  options(structure(list(as.integer(seed)), names = option_name))
  suppressMessages(invisible(utils::capture.output(trace(
    "makeCluster", where = asNamespace("parallel"), print = FALSE,
    exit = quote(parallel::clusterSetRNGStream(
      returnValue(), iseed = getOption("dava.icamp.parallel.seed")))))))
  on.exit({
    suppressMessages(invisible(utils::capture.output(untrace(
      "makeCluster", where = asNamespace("parallel")))))
    options(structure(list(old_option), names = option_name))
  }, add = TRUE)
  force(expr)
}

microbiome_icamp_pair_vector <- function(matrix, pairs) {
  matrix[cbind(
    match(pairs$name1, rownames(matrix)),
    match(pairs$name2, colnames(matrix)))]
}

microbiome_icamp_batched_null_pairs <- function(
    counts, phylogenetic_distance, permutations, weighted, seed,
    memory_target_mb = 384) {
  sample_count <- nrow(counts)
  matrix_mb <- sample_count * sample_count * 8 / 1024^2
  # iCAMP retains both the list of random matrices and the final array.
  batch_size <- as.integer(max(1L, min(permutations,
    floor(memory_target_mb / max(matrix_mb * 3, .Machine$double.eps)))))
  batch_starts <- seq.int(1L, permutations, by = batch_size)
  bnti_sum <- bnti_sumsq <- numeric()
  bnti_observed <- numeric()
  rc_greater <- rc_equal <- numeric()
  rc_observed <- numeric()
  pair_ids <- NULL
  runtime_log <- character()

  run_batches <- function(engine) {
    for (batch_index in seq_along(batch_starts)) {
      run_count <- min(batch_size,
        permutations - batch_starts[[batch_index]] + 1L)
      batch_seed <- seed +
        (if (identical(engine, "rcbray")) 100000L else 0L) +
        batch_index - 1L
      set.seed(batch_seed)
      options(dava.icamp.parallel.seed = batch_seed)
      captured <- microbiome_capture_runtime_output(function() {
        microbiome_icamp_muffle_memory_limit(if (identical(engine, "bnti")) {
          iCAMP::bNTI.cm(
            counts, phylogenetic_distance, rand = run_count, nworker = 1L,
            weighted = weighted, sig.index = "SES", output.bMNTD = TRUE,
            detail.null = TRUE)
        } else {
          iCAMP::RC.cm(
            counts, rand = run_count, nworker = 1L, weighted = weighted,
            sig.index = "RC", silent = TRUE, output.bray = TRUE,
            detail.null = TRUE)
        })
      })
      runtime_log <<- c(runtime_log, captured$log, captured$warnings)
      fit <- captured$value
      random <- as.data.frame(fit$rand, check.names = FALSE)
      current_pairs <- random[, c("name1", "name2"), drop = FALSE]
      random_values <- as.matrix(random[, -(1:2), drop = FALSE])
      storage.mode(random_values) <- "double"
      if (is.null(pair_ids)) {
        pair_ids <<- current_pairs
      } else if (!identical(pair_ids, current_pairs)) {
        stop("iCAMP returned inconsistent sample-pair ordering between batches.",
          call. = FALSE)
      }
      if (identical(engine, "bnti")) {
        observed <- microbiome_icamp_pair_vector(fit$betaMNTD.obs, current_pairs)
        if (!length(bnti_observed)) bnti_observed <<- observed
        bnti_sum <<- if (!length(bnti_sum)) rowSums(random_values) else
          bnti_sum + rowSums(random_values)
        bnti_sumsq <<- if (!length(bnti_sumsq)) rowSums(random_values^2) else
          bnti_sumsq + rowSums(random_values^2)
      } else {
        observed <- microbiome_icamp_pair_vector(fit$BC.obs, current_pairs)
        if (!length(rc_observed)) rc_observed <<- observed
        greater <- rowSums(observed > random_values)
        equal <- rowSums(observed == random_values)
        rc_greater <<- if (!length(rc_greater)) greater else rc_greater + greater
        rc_equal <<- if (!length(rc_equal)) equal else rc_equal + equal
      }
      rm(fit, random, random_values)
      gc(FALSE)
    }
  }

  microbiome_icamp_seeded_clusters(seed, {
    run_batches("bnti")
    run_batches("rcbray")
  })
  null_mean <- bnti_sum / permutations
  null_variance <- pmax(
    (bnti_sumsq - bnti_sum^2 / permutations) / max(permutations - 1L, 1L), 0)
  null_sd <- sqrt(null_variance)
  beta_nti <- ifelse(null_sd > 0,
    (bnti_observed - null_mean) / null_sd, 0)
  rcbray <- 2 * ((rc_greater + 0.5 * rc_equal) / permutations) - 1
  data.frame(
    Sample1 = as.character(pair_ids$name1),
    Sample2 = as.character(pair_ids$name2),
    betaNTI = beta_nti, RCbray = rcbray,
    stringsAsFactors = FALSE,
    row.names = NULL) |>
    list(pairwise = _, batch_size = batch_size,
      matrix_mb = matrix_mb, runtime_log = runtime_log)
}

microbiome_run_bnti_rcbray <- function(bundle, spec = list()) {
  started <- proc.time()[["elapsed"]]
  if (!requireNamespace("iCAMP", quietly = TRUE) || !requireNamespace("ape", quietly = TRUE)) {
    stop("betaNTI + RCbray requires the iCAMP and ape packages.", call. = FALSE)
  }
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  if (!identical(bundle$marker_type, "16S")) stop("betaNTI + RCbray is available only for 16S data with a valid phylogeny.", call. = FALSE)
  tree <- bundle$phylogeny
  if (is.null(tree) || !inherits(tree, "phylo")) stop("betaNTI + RCbray requires a valid phylo tree.", call. = FALSE)
  counts <- microbiome_numeric_matrix(bundle$counts)
  shared <- intersect(colnames(counts), tree$tip.label)
  if (length(shared) < 3L) stop("The count table and phylogeny share fewer than three features.", call. = FALSE)
  counts <- counts[, shared, drop = FALSE]
  tree <- ape::keep.tip(tree, shared)
  phylogenetic_distance <- as.matrix(ape::cophenetic.phylo(tree))
  permutations <- max(9L, as.integer(
    spec$n_iterations %||% spec$permutations %||% 999L))
  seed <- as.integer(spec$seed %||% 2026L)
  workers <- max(1L, as.integer(spec$n_cores %||% spec$workers %||% 1L))
  weighted <- isTRUE(spec$abundance_weighted %||% TRUE)
  group_name <- trimws(as.character(spec$group %||% ""))
  estimated_cube_mb <- nrow(counts)^2 * 8 * permutations / 1024^2
  memory_target_mb <- max(0.0001,
    as.numeric(spec$null_batch_memory_mb %||% 384))
  use_batched <- estimated_cube_mb > memory_target_mb
  batch_details <- list()
  runtime_log <- character()
  if (use_batched) {
    sample_sets <- list(`All samples` = rownames(counts))
    if (nzchar(group_name)) {
      metadata <- microbiome_metadata_by_sample(bundle$metadata)
      if (!group_name %in% names(metadata)) {
        stop("The selected grouping variable is not present in sample metadata.", call. = FALSE)
      }
      group_values <- as.character(metadata[rownames(counts), group_name])
      if (anyNA(group_values) || any(!nzchar(group_values))) {
        stop("The selected grouping variable is missing for one or more samples.", call. = FALSE)
      }
      sample_sets <- split(rownames(counts), group_values, drop = TRUE)
      if (any(lengths(sample_sets) < 3L)) {
        stop("Every group requires at least three samples for memory-safe betaNTI + RCbray.",
          call. = FALSE)
      }
    }
    batch_details <- lapply(seq_along(sample_sets), function(index) {
      samples <- sample_sets[[index]]
      microbiome_icamp_batched_null_pairs(
        counts[samples, , drop = FALSE], phylogenetic_distance,
        permutations, weighted, seed + index - 1L, memory_target_mb)
    })
    names(batch_details) <- names(sample_sets)
    pairwise <- do.call(rbind, lapply(batch_details, `[[`, "pairwise"))
    rownames(pairwise) <- NULL
    runtime_log <- unlist(lapply(batch_details, `[[`, "runtime_log"),
      use.names = FALSE)
    bnti_fit <- rc_fit <- NULL
    workers_used <- 1L
  } else {
    fits <- microbiome_icamp_seeded_clusters(seed, {
      set.seed(seed)
      options(dava.icamp.parallel.seed = seed)
      bnti_value <- microbiome_icamp_muffle_memory_limit(iCAMP::bNTI.cm(
        counts, phylogenetic_distance, rand = permutations, nworker = workers,
        weighted = weighted, sig.index = "SES"))
      set.seed(seed + 100000L)
      options(dava.icamp.parallel.seed = seed + 100000L)
      rc_value <- microbiome_icamp_muffle_memory_limit(iCAMP::RC.cm(
        counts, rand = permutations, nworker = workers, weighted = weighted,
        sig.index = "RC", silent = TRUE))
      list(bnti = bnti_value, rcbray = rc_value)
    })
    bnti_fit <- fits$bnti
    rc_fit <- fits$rcbray
    bnti <- as.matrix(bnti_fit$index)
    rcbray <- as.matrix(rc_fit$index)
    pair_index <- which(upper.tri(bnti), arr.ind = TRUE)
    pairwise <- data.frame(
      Sample1 = rownames(bnti)[pair_index[, 1]],
      Sample2 = colnames(bnti)[pair_index[, 2]],
      betaNTI = bnti[pair_index], RCbray = rcbray[pair_index],
      stringsAsFactors = FALSE)
    workers_used <- workers
  }
  pairwise$Process <- ifelse(pairwise$betaNTI > 2, "variable_selection",
    ifelse(pairwise$betaNTI < -2, "homogeneous_selection",
      ifelse(pairwise$RCbray > 0.95, "dispersal_limitation",
        ifelse(pairwise$RCbray < -0.95, "homogeneous_dispersal", "drift"))))
  process_summary <- as.data.frame(table(pairwise$Process), stringsAsFactors = FALSE)
  names(process_summary) <- c("Process", "PairCount")
  process_summary$Proportion <- process_summary$PairCount / sum(process_summary$PairCount)
  process_group_summary <- data.frame()
  if (nzchar(group_name)) {
    metadata <- microbiome_metadata_by_sample(bundle$metadata)
    if (!group_name %in% names(metadata)) {
      stop("The selected grouping variable is not present in sample metadata.", call. = FALSE)
    }
    pairwise$Group1 <- as.character(metadata[pairwise$Sample1, group_name])
    pairwise$Group2 <- as.character(metadata[pairwise$Sample2, group_name])
    pairwise$WithinGroup <- !is.na(pairwise$Group1) & !is.na(pairwise$Group2) &
      pairwise$Group1 == pairwise$Group2
    pairwise$Group <- ifelse(pairwise$WithinGroup, pairwise$Group1, "Between groups")
    within <- pairwise[pairwise$WithinGroup, , drop = FALSE]
    if (nrow(within)) {
      process_group_summary <- as.data.frame(
        table(Group = within$Group, Process = within$Process), stringsAsFactors = FALSE)
      names(process_group_summary)[[3L]] <- "PairCount"
      process_group_summary <- process_group_summary[process_group_summary$PairCount > 0, , drop = FALSE]
      totals <- ave(process_group_summary$PairCount, process_group_summary$Group, FUN = sum)
      process_group_summary$Proportion <- process_group_summary$PairCount / totals
    }
  }
  plot_data <- if (nrow(process_group_summary)) process_group_summary else
    transform(process_summary, Group = "All sample pairs")
  tables <- list(pairwise_process = pairwise, process_summary = process_summary,
    process_group_summary = process_group_summary)
  plots <- list(process_proportions = microbiome_assembly_process_plot(
    plot_data, if (nrow(process_group_summary))
      "Ecological Process Partition by Group" else "Ecological Process Partition"))
  new_microbiome_result("bnti_rcbray", status = "success", marker_type = bundle$marker_type,
    data_version = bundle$data_version, input_summary = microbiome_data_summary(bundle, aligned$orientation),
    analysis_spec = spec, actual_parameters = list(permutations = permutations, seed = seed,
      betaNTI_threshold = 2, RCbray_threshold = 0.95, group = group_name,
      abundance_weighted = weighted,
      workers_requested = workers, workers = workers_used,
      memory_safe_batches = use_batched,
      estimated_unbatched_null_mb = estimated_cube_mb,
      null_batch_memory_mb = memory_target_mb,
      null_batch_sizes = if (use_batched) {
        vapply(batch_details, `[[`, integer(1), "batch_size")
      } else permutations,
      pair_scope = if (nrow(process_group_summary)) "within-group pairs" else "all pairs"),
      model_objects = list(bnti = bnti_fit, rcbray = rc_fit),
    tables = tables, plots = plots, assembly_tables = tables, statistics = process_summary,
    available_outputs = c(names(tables), names(plots)),
    generated_code = microbiome_bnti_rcbray_code(spec), package_versions = microbiome_package_versions(c("iCAMP", "ape")),
    runtime_log = runtime_log,
    execution_time = proc.time()[["elapsed"]] - started,
    registration_manifest = microbiome_registration_manifest(bundle, "bnti_rcbray", names(tables)))
}
