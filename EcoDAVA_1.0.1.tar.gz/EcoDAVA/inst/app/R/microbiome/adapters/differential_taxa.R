microbiome_differential_taxa_method_choices <- function() c(
  "DESeq2" = "deseq2",
  "edgeR" = "edger",
  "ANCOM-BC2" = "ancombc2"
)

microbiome_differential_taxa_applicability_ui <- function(method = "ancombc2") {
  message <- switch(method,
    deseq2 = paste(
      "Suitable for raw count data and explicit between-group comparisons; empirical Bayesian methods can be used to stabilize dispersion estimates in small to medium samples,",
      "is often used to find differential taxa with stable log2 fold change."
    ),
    edger = paste(
      "is suitable for raw count data, especially for small samples or designs with obvious differences in sequencing depth;",
      "Quasi-likelihood testing provides more robust control of dispersion and false positives."
    ),
    paste(
      "Ideal for designs that require correcting for microbial composition bias, identifying structural zeros, or performing multiple group, pairwise, Dunnett, and trend comparisons;",
      "Random effects can also be set explicitly when measurements are repeated within a group."
    )
  )
  shiny::div(
    class = "alert alert-info py-2 px-3 mb-2 small",
    shiny::tags$strong("Method applicability:"), message
  )
}

microbiome_differential_taxa_plot_choices <- function(
    method = "ancombc2", analysis_mode = "two_group") {
  switch(method,
    deseq2 = c(
      "Volcano plot" = "volcano",
      "MA plot" = "ma_plot",
      "Log2 fold-change forest plot" = "coefficient_forest",
      "Differential-taxa abundance plot" = "abundance_distribution",
      "Differential-taxa sample heatmap" = "sample_heatmap",
      "Mean-dispersion plot" = "dispersion_plot",
      "P-value histogram" = "pvalue_histogram"
    ),
    edger = c(
      "Volcano plot" = "volcano",
      "BCV / mean-variance plot" = "mean_variance",
      "Smear plot" = "smear_plot",
      "Log2 fold-change forest plot" = "coefficient_forest",
      "Differential-taxa abundance plot" = "abundance_distribution",
      "Differential-taxa sample heatmap" = "sample_heatmap",
      "P-value histogram" = "pvalue_histogram"
    ),
    microbiome_ancombc2_plot_choices(analysis_mode)
  )
}

microbiome_differential_taxa_advanced_field_ids <- function(method = "ancombc2") {
  switch(method,
    deseq2 = c(
      "deseq2_min_count", "deseq2_min_samples", "deseq2_fit_type",
      "deseq2_p_adjust", "deseq2_alpha", "deseq2_independent_filtering",
      "deseq2_cooks_cutoff", "deseq2_lfc_shrinkage", "deseq2_lfc_threshold",
      "deseq2_max_taxa", "deseq2_top_labels", "deseq2_heatmap_transform"
    ),
    edger = c(
      "edger_min_cpm", "edger_min_samples", "edger_robust",
      "edger_prior_df", "edger_p_adjust",
      "edger_alpha", "edger_lfc_threshold", "edger_max_taxa",
      "edger_top_labels", "edger_heatmap_transform"
    ),
    c(
      "ancombc2_min_prevalence", "ancombc2_p_adjust", "ancombc2_alpha",
      "ancombc2_max_taxa", "ancombc2_lfc_threshold", "ancombc2_top_labels",
      "ancombc2_heatmap_transform", "ancombc2_heatmap_nonsignificant",
      "ancombc2_heatmap_annotations", "ancombc2_facet_phylum",
      "ancombc2_trend_pattern", "ancombc2_trend_turning_level",
      "ancombc2_mdfdr_bootstraps"
    )
  )
}

microbiome_differential_taxa_sidebar_controls <- function(
    ns, method, group_levels = character(), current = list()) {
  reference <- current$composition_differential_reference %||%
    if (length(group_levels)) group_levels[[1L]] else ""
  comparison_choices <- setdiff(group_levels, reference)
  comparison <- current$composition_differential_comparison %||%
    if (length(comparison_choices)) comparison_choices[[1L]] else ""
  if (!comparison %in% comparison_choices) {
    comparison <- if (length(comparison_choices)) comparison_choices[[1L]] else ""
  }
  comparison_controls <- shiny::tagList(
    shiny::selectInput(ns("composition_differential_reference"), "Reference Group",
      group_levels, selected = reference),
    shiny::selectInput(ns("composition_differential_comparison"), "comparison group",
      comparison_choices, selected = comparison)
  )
  switch(method,
    deseq2 = shiny::tagList(
      comparison_controls,
      dava_i18n_preserve_choice_language(shiny::selectInput(
        ns("composition_deseq2_test"), "DESeq2 test",
        c("Wald test" = "Wald", "Likelihood-ratio test" = "LRT"),
        selected = current$composition_deseq2_test %||% "Wald")),
      shiny::selectInput(ns("composition_deseq2_design"), "Design method",
        c("Grouping variable (~ group)" = "group"), selected = "group"),
      shiny::div(class = "small text-muted mb-2",
        "uses DESeq2 median ratio normalization; the result is the log2 fold change of the selected comparison group relative to the reference group.")
    ),
    edger = shiny::tagList(
      comparison_controls,
      dava_i18n_preserve_choice_language(shiny::selectInput(
        ns("composition_edger_test"), "edgeR test",
        c("Quasi-likelihood F-test" = "QLF", "Likelihood-ratio test" = "LRT"),
        selected = current$composition_edger_test %||% "QLF")),
      shiny::selectInput(ns("composition_edger_normalization"), "Standardization method",
        c("TMM" = "TMM", "TMMwsp" = "TMMwsp", "RLE" = "RLE",
          "Upper quartile" = "upperquartile", "None" = "none"),
        selected = current$composition_edger_normalization %||% "TMM"),
      shiny::div(class = "small text-muted mb-2",
        "uses the edgeR negative binomial generalized linear model; the result is the log2 fold change of the selected comparison group relative to the reference group.")
    ),
    NULL
  )
}

microbiome_differential_taxa_advanced_controls_ui <- function(
    ns, method, context = list()) {
  current <- context$current_values %||% list()
  section <- function(title, ...) shiny::tagList(
    shiny::tags$h6(class = "fw-semibold mt-2 mb-2", title),
    ..., shiny::tags$hr()
  )
  switch(method,
    deseq2 = shiny::tagList(
      section("DESeq2 feature filtering",
        shiny::numericInput(ns("deseq2_min_count"), "Minimum total count",
          current$deseq2_min_count %||% 10L, min = 0L, step = 1L),
        shiny::numericInput(ns("deseq2_min_samples"), "Minimum samples with non-zero counts",
          current$deseq2_min_samples %||% 2L, min = 1L, step = 1L)),
      section("DESeq2 inference",
        shiny::selectInput(ns("deseq2_fit_type"), "Dispersion fit type",
          c("Parametric" = "parametric", "Local" = "local", "Mean" = "mean"),
          selected = current$deseq2_fit_type %||% "parametric"),
        shiny::selectInput(ns("deseq2_p_adjust"), "Multiple-testing correction",
          c("FDR (BH)" = "BH", "Holm" = "holm", "Bonferroni" = "bonferroni",
            "Benjamini-Yekutieli" = "BY"),
          selected = current$deseq2_p_adjust %||% "BH"),
        shiny::sliderInput(ns("deseq2_alpha"), "Adjusted P-value threshold",
          0.001, 0.1, current$deseq2_alpha %||% 0.05, 0.001),
        shiny::checkboxInput(ns("deseq2_independent_filtering"),
          "Independent filtering", isTRUE(current$deseq2_independent_filtering %||% TRUE)),
        shiny::checkboxInput(ns("deseq2_cooks_cutoff"),
          "Apply Cook's distance filtering", isTRUE(current$deseq2_cooks_cutoff %||% TRUE)),
        shiny::selectInput(ns("deseq2_lfc_shrinkage"), "LFC shrinkage",
          c("None" = "none", "Normal prior" = "normal"),
          selected = current$deseq2_lfc_shrinkage %||% "none")),
      section("DESeq2 plots",
        shiny::numericInput(ns("deseq2_lfc_threshold"), "Absolute log2FC threshold",
          current$deseq2_lfc_threshold %||% 1, min = 0, step = 0.1),
        shiny::numericInput(ns("deseq2_max_taxa"), "Maximum displayed taxa",
          current$deseq2_max_taxa %||% 30L, min = 5L, max = 100L),
        shiny::numericInput(ns("deseq2_top_labels"), "Top taxa labels",
          current$deseq2_top_labels %||% 10L, min = 0L, max = 50L),
        shiny::selectInput(ns("deseq2_heatmap_transform"), "Heatmap transformation",
          c("Variance-stabilizing transformation" = "vst",
            "Regularized log" = "rlog", "log2 normalized counts" = "log2"),
          selected = current$deseq2_heatmap_transform %||% "vst"))
    ),
    edger = shiny::tagList(
      section("edgeR feature filtering",
        shiny::numericInput(ns("edger_min_cpm"), "Minimum CPM",
          current$edger_min_cpm %||% 1, min = 0, step = 0.1),
        shiny::numericInput(ns("edger_min_samples"), "Minimum samples above CPM threshold",
          current$edger_min_samples %||% 2L, min = 1L, step = 1L)),
      section("edgeR inference",
        shiny::checkboxInput(ns("edger_robust"), "Robust dispersion estimation",
          isTRUE(current$edger_robust %||% TRUE)),
        shiny::numericInput(ns("edger_prior_df"), "Prior degrees of freedom",
          current$edger_prior_df %||% 10, min = 0, step = 1),
        shiny::selectInput(ns("edger_p_adjust"), "Multiple-testing correction",
          c("FDR (BH)" = "BH", "Holm" = "holm", "Bonferroni" = "bonferroni",
            "Benjamini-Yekutieli" = "BY"),
          selected = current$edger_p_adjust %||% "BH"),
        shiny::sliderInput(ns("edger_alpha"), "Adjusted P-value threshold",
          0.001, 0.1, current$edger_alpha %||% 0.05, 0.001)),
      section("edgeR plots",
        shiny::numericInput(ns("edger_lfc_threshold"), "Absolute log2FC threshold",
          current$edger_lfc_threshold %||% 1, min = 0, step = 0.1),
        shiny::numericInput(ns("edger_max_taxa"), "Maximum displayed taxa",
          current$edger_max_taxa %||% 30L, min = 5L, max = 100L),
        shiny::numericInput(ns("edger_top_labels"), "Top taxa labels",
          current$edger_top_labels %||% 10L, min = 0L, max = 50L),
        shiny::selectInput(ns("edger_heatmap_transform"), "Heatmap transformation",
          c("log2 CPM" = "logcpm", "CPM" = "cpm", "Row Z-score" = "row_z"),
          selected = current$edger_heatmap_transform %||% "logcpm"))
    ),
    NULL
  )
}

microbiome_differential_taxa_comparison <- function(group, spec) {
  available <- levels(droplevels(group))
  reference <- as.character(spec$reference_group %||% available[[1L]])
  if (!reference %in% available) reference <- available[[1L]]
  candidates <- setdiff(available, reference)
  comparison <- as.character(spec$comparison_group %||%
    if (length(candidates)) candidates[[1L]] else "")
  if (!comparison %in% candidates) {
    comparison <- if (length(candidates)) candidates[[1L]] else ""
  }
  if (!nzchar(comparison)) {
    stop("DESeq2 and edgeR require at least two valid group levels.", call. = FALSE)
  }
  keep <- as.character(group) %in% c(reference, comparison)
  list(
    keep = keep,
    group = stats::relevel(droplevels(group[keep]), ref = reference),
    reference = reference,
    comparison = comparison,
    contrast = paste0(comparison, " vs ", reference)
  )
}

microbiome_run_count_differential_engine <- function(
    method, counts, group, spec, prevalence, mean_abundance) {
  comparison <- microbiome_differential_taxa_comparison(group, spec)
  counts <- counts[comparison$keep, , drop = FALSE]
  group <- comparison$group
  if (!isTRUE(all(counts == floor(counts)))) {
    stop("DESeq2 and edgeR require an untransformed integer count table.", call. = FALSE)
  }
  alpha <- as.numeric(spec$alpha %||% 0.05)
  p_adjust <- spec$fdr_method %||% "BH"
  normalized <- NULL
  model_summary <- data.frame()

  if (identical(method, "deseq2")) {
    if (!requireNamespace("DESeq2", quietly = TRUE)) {
      stop("DESeq2 analysis requires the DESeq2 package.", call. = FALSE)
    }
    minimum_count <- as.numeric(spec$minimum_count %||% 10L)
    minimum_samples <- as.integer(spec$minimum_samples %||% 2L)
    keep_features <- colSums(counts) >= minimum_count &
      colSums(counts > 0) >= minimum_samples
    if (sum(keep_features) < 2L) stop("Too few taxa remain after DESeq2 filtering.", call. = FALSE)
    count_data <- t(round(counts[, keep_features, drop = FALSE]))
    col_data <- data.frame(group = group, row.names = rownames(counts))
    dds <- DESeq2::DESeqDataSetFromMatrix(count_data, col_data, ~ group)
    test <- spec$deseq2_test %||% "Wald"
    dds <- if (identical(test, "LRT")) {
      DESeq2::DESeq(dds, test = "LRT", reduced = ~ 1,
        fitType = spec$deseq2_fit_type %||% "parametric", quiet = TRUE)
    } else {
      DESeq2::DESeq(dds, test = "Wald",
        fitType = spec$deseq2_fit_type %||% "parametric", quiet = TRUE)
    }
    contrast <- c("group", comparison$comparison, comparison$reference)
    result <- DESeq2::results(dds, contrast = contrast, alpha = alpha,
      pAdjustMethod = p_adjust,
      independentFiltering = isTRUE(spec$deseq2_independent_filtering %||% TRUE),
      cooksCutoff = isTRUE(spec$deseq2_cooks_cutoff %||% TRUE))
    if (identical(spec$deseq2_lfc_shrinkage %||% "none", "normal") &&
        identical(test, "Wald")) {
      result <- DESeq2::lfcShrink(dds, contrast = contrast, res = result,
        type = "normal", quiet = TRUE)
    }
    raw <- as.data.frame(result)
    raw$Feature <- rownames(raw)
    table <- data.frame(
      Feature = raw$Feature, contrast = comparison$contrast,
      effect = raw$log2FoldChange, standard_error = raw$lfcSE,
      statistic = raw$stat, raw_p = raw$pvalue, adjusted_p = raw$padj,
      base_mean = raw$baseMean,
      prevalence = prevalence[raw$Feature], mean_abundance = mean_abundance[raw$Feature],
      convergence = is.finite(raw$log2FoldChange), stringsAsFactors = FALSE
    )
    table$differentially_abundant <- is.finite(table$adjusted_p) &
      table$adjusted_p <= alpha &
      abs(table$effect) >= as.numeric(spec$lfc_threshold %||% 0)
    heatmap_transform <- spec$heatmap_transform %||% "vst"
    normalized <- if (identical(heatmap_transform, "rlog")) {
      t(SummarizedExperiment::assay(DESeq2::rlog(dds, blind = FALSE)))
    } else if (identical(heatmap_transform, "vst")) {
      t(SummarizedExperiment::assay(DESeq2::varianceStabilizingTransformation(
        dds, blind = FALSE)))
    } else {
      log2(t(DESeq2::counts(dds, normalized = TRUE)) + 1)
    }
    model_summary <- data.frame(
      Metric = c("Retained taxa", "Samples", "Size-factor range", "Test"),
      Value = c(nrow(dds), ncol(dds),
        paste(signif(range(DESeq2::sizeFactors(dds)), 4), collapse = " - "), test),
      stringsAsFactors = FALSE
    )
    model <- dds
    packages <- "DESeq2"
  } else {
    if (!requireNamespace("edgeR", quietly = TRUE)) {
      stop("edgeR analysis requires the edgeR package.", call. = FALSE)
    }
    dge <- edgeR::DGEList(counts = t(round(counts)), group = group)
    min_cpm <- as.numeric(spec$minimum_cpm %||% 1)
    min_samples <- as.integer(spec$minimum_samples %||% 2L)
    keep_features <- rowSums(edgeR::cpm(dge) >= min_cpm) >= min_samples
    if (sum(keep_features) < 2L) stop("Too few taxa remain after edgeR filtering.", call. = FALSE)
    dge <- dge[keep_features, , keep.lib.sizes = FALSE]
    normalization <- spec$edger_normalization %||% "TMM"
    dge <- edgeR::calcNormFactors(dge, method = normalization)
    design <- stats::model.matrix(~ group)
    robust <- isTRUE(spec$edger_robust %||% TRUE)
    dge <- edgeR::estimateDisp(dge, design, robust = robust,
      prior.df = as.numeric(spec$edger_prior_df %||% 10))
    test <- spec$edger_test %||% "QLF"
    if (identical(test, "LRT")) {
      fit <- edgeR::glmFit(dge, design)
      tested <- edgeR::glmLRT(fit, coef = 2L)
    } else {
      fit <- edgeR::glmQLFit(dge, design, robust = robust)
      tested <- edgeR::glmQLFTest(fit, coef = 2L)
    }
    raw <- edgeR::topTags(tested, n = Inf, adjust.method = p_adjust,
      sort.by = "none")$table
    raw$Feature <- rownames(raw)
    statistic_name <- intersect(c("F", "LR"), names(raw))[[1L]]
    table <- data.frame(
      Feature = raw$Feature, contrast = comparison$contrast,
      effect = raw$logFC, standard_error = NA_real_,
      statistic = raw[[statistic_name]], raw_p = raw$PValue,
      adjusted_p = raw$FDR, log_cpm = raw$logCPM,
      prevalence = prevalence[raw$Feature], mean_abundance = mean_abundance[raw$Feature],
      convergence = is.finite(raw$logFC), stringsAsFactors = FALSE
    )
    table$differentially_abundant <- is.finite(table$adjusted_p) &
      table$adjusted_p <= alpha &
      abs(table$effect) >= as.numeric(spec$lfc_threshold %||% 0)
    normalized <- if (identical(spec$heatmap_transform %||% "logcpm", "cpm")) {
      t(edgeR::cpm(dge, log = FALSE))
    } else {
      t(edgeR::cpm(dge, log = TRUE, prior.count = 1))
    }
    model_summary <- data.frame(
      Metric = c("Retained taxa", "Samples", "Normalization", "Test", "Common dispersion"),
      Value = c(nrow(dge), ncol(dge), normalization, test,
        signif(dge$common.dispersion %||% NA_real_, 4)),
      stringsAsFactors = FALSE
    )
    model <- list(dge = dge, fit = fit, test = tested)
    packages <- "edgeR"
  }
  rownames(normalized) <- rownames(counts)
  list(
    table = table, model = model, packages = packages,
    normalized = as.data.frame(normalized, check.names = FALSE),
    model_summary = model_summary,
    comparison = comparison
  )
}

microbiome_count_differential_plots <- function(
    method, table, counts, group, normalized, spec) {
  requested <- as.character(spec$plot_types %||%
    unname(microbiome_differential_taxa_plot_choices(method)))
  maximum_features <- max(5L, as.integer(spec$maximum_features %||% 30L))
  ranked <- table[order(table$adjusted_p, -abs(table$effect), na.last = TRUE), , drop = FALSE]
  selected <- utils::head(ranked$Feature, maximum_features)
  selected <- intersect(selected, colnames(counts))
  plots <- list()
  if ("volcano" %in% requested) plots$volcano <- microbiome_volcano_plot(table)
  if ("coefficient_forest" %in% requested) {
    plots$coefficient_forest <- microbiome_differential_forest_plot(table, method)
  }
  mean_column <- if ("base_mean" %in% names(table)) "base_mean" else "log_cpm"
  mean_label <- if (identical(method, "deseq2")) "Mean normalized count" else "Average log CPM"
  if (any(c("ma_plot", "smear_plot") %in% requested)) {
    display <- table
    display$Significant <- as.logical(display$differentially_abundant %||% FALSE)
    name <- if (identical(method, "deseq2")) "ma_plot" else "smear_plot"
    plots[[name]] <- ggplot2::ggplot(display,
      ggplot2::aes(.data[[mean_column]], .data$effect, colour = .data$Significant)) +
      ggplot2::geom_hline(yintercept = 0, colour = "#7B8790", linetype = 2) +
      ggplot2::geom_point(alpha = 0.75, size = 2) +
      ggplot2::scale_colour_manual(values = c(`FALSE` = "#7B8790", `TRUE` = "#D94841")) +
      ggplot2::labs(title = if (identical(method, "deseq2")) "DESeq2 MA plot" else "edgeR smear plot",
        x = mean_label, y = "log2 fold change", colour = "Significant") +
      ggplot2::theme_classic(base_size = 12)
  }
  if ("pvalue_histogram" %in% requested) {
    plots$pvalue_histogram <- ggplot2::ggplot(table, ggplot2::aes(.data$raw_p)) +
      ggplot2::geom_histogram(bins = 30, fill = "#3B7EA1", colour = "white") +
      ggplot2::labs(title = paste(method, "P-value distribution"), x = "Raw P-value", y = "Taxa") +
      ggplot2::theme_classic(base_size = 12)
  }
  if ("abundance_distribution" %in% requested && length(selected)) {
    long <- data.frame(
      SampleID = rep(rownames(counts), times = length(selected)),
      Feature = rep(selected, each = nrow(counts)),
      Abundance = as.vector(counts[, selected, drop = FALSE]),
      Group = rep(as.character(group), times = length(selected)), stringsAsFactors = FALSE)
    plots$abundance_distribution <- ggplot2::ggplot(long,
      ggplot2::aes(.data$Group, log1p(.data$Abundance), fill = .data$Group)) +
      ggplot2::geom_violin(alpha = 0.45, trim = FALSE) +
      ggplot2::geom_boxplot(width = 0.22, outlier.shape = NA, alpha = 0.8) +
      ggplot2::facet_wrap(~ Feature, scales = "free_y") +
      ggplot2::labs(title = paste(method, "differential-taxa abundance"),
        x = NULL, y = "log(1 + count)") + ggplot2::theme_classic(base_size = 11)
  }
  normalized_matrix <- as.matrix(normalized)
  heat_features <- intersect(selected, colnames(normalized_matrix))
  if ("sample_heatmap" %in% requested && length(heat_features)) {
    heat <- normalized_matrix[, heat_features, drop = FALSE]
    if (identical(spec$heatmap_transform %||% "", "row_z")) {
      heat <- t(scale(t(heat)))
    }
    heat_long <- data.frame(
      Sample = rep(rownames(heat), times = ncol(heat)),
      Feature = rep(colnames(heat), each = nrow(heat)),
      Value = as.vector(heat), stringsAsFactors = FALSE)
    plots$sample_heatmap <- ggplot2::ggplot(heat_long,
      ggplot2::aes(.data$Sample, .data$Feature, fill = .data$Value)) +
      ggplot2::geom_tile() +
      ggplot2::scale_fill_gradient2(low = "#3B7EA1", mid = "white", high = "#D94841") +
      ggplot2::labs(title = paste(method, "differential-taxa heatmap"), x = NULL, y = NULL,
        fill = "Expression") +
      ggplot2::theme_classic(base_size = 10) +
      ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90, hjust = 1))
  }
  if (identical(method, "deseq2") && "dispersion_plot" %in% requested) {
    moments <- data.frame(Mean = colMeans(counts), Variance = apply(counts, 2, stats::var))
    plots$dispersion_plot <- ggplot2::ggplot(moments, ggplot2::aes(.data$Mean, .data$Variance)) +
      ggplot2::geom_point(colour = "#3B7EA1", alpha = 0.7) +
      ggplot2::scale_x_log10() + ggplot2::scale_y_log10() +
      ggplot2::labs(title = "DESeq2 mean-dispersion diagnostic", x = "Mean count", y = "Count variance") +
      ggplot2::theme_classic(base_size = 12)
  }
  if (identical(method, "edger") && "mean_variance" %in% requested) {
    moments <- data.frame(Mean = colMeans(counts), BCV = sqrt(pmax(0,
      (apply(counts, 2, stats::var) - colMeans(counts)) / pmax(colMeans(counts)^2, 1e-8))))
    plots$mean_variance <- ggplot2::ggplot(moments, ggplot2::aes(.data$Mean, .data$BCV)) +
      ggplot2::geom_point(colour = "#7A5195", alpha = 0.7) +
      ggplot2::scale_x_log10() +
      ggplot2::labs(title = "edgeR biological coefficient of variation", x = "Mean count", y = "BCV") +
      ggplot2::theme_classic(base_size = 12)
  }
  Filter(Negate(is.null), plots)
}

microbiome_count_differential_code <- function(method, spec) {
  reference <- deparse(as.character(spec$reference_group %||% "reference"))
  comparison <- deparse(as.character(spec$comparison_group %||% "comparison"))
  if (identical(method, "deseq2")) {
    return(paste(
      "library(DESeq2)",
      sprintf("group_variable <- %s", deparse(as.character(spec$group %||% "Treatment"))),
      sprintf("selected_groups <- c(%s, %s)", reference, comparison),
      "keep_samples <- bundle$metadata[[group_variable]] %in% selected_groups",
      "count_data <- t(round(as.matrix(bundle$counts[keep_samples, , drop = FALSE])))",
      "col_data <- data.frame(group = factor(bundle$metadata[[group_variable]][keep_samples]), row.names = rownames(bundle$counts)[keep_samples])",
      "dds <- DESeqDataSetFromMatrix(count_data, col_data, design = ~ group)",
      sprintf("dds$group <- relevel(dds$group, ref = %s)", reference),
      sprintf("dds <- DESeq(dds, test = %s, fitType = %s)",
        deparse(spec$deseq2_test %||% "Wald"), deparse(spec$deseq2_fit_type %||% "parametric")),
      sprintf("result <- results(dds, contrast = c('group', %s, %s), alpha = %s)",
        comparison, reference, format(spec$alpha %||% 0.05)), sep = "\n"))
  }
  paste(
    "library(edgeR)",
    sprintf("group_variable <- %s", deparse(as.character(spec$group %||% "Treatment"))),
    sprintf("selected_groups <- c(%s, %s)", reference, comparison),
    "keep_samples <- bundle$metadata[[group_variable]] %in% selected_groups",
    sprintf("group <- relevel(factor(bundle$metadata[[group_variable]][keep_samples]), ref = %s)", reference),
    "dge <- DGEList(counts = t(round(as.matrix(bundle$counts[keep_samples, , drop = FALSE]))), group = group)",
    sprintf("dge <- calcNormFactors(dge, method = %s)", deparse(spec$edger_normalization %||% "TMM")),
    "design <- model.matrix(~ group, data = dge$samples)",
    "dge <- estimateDisp(dge, design, robust = TRUE)",
    "fit <- glmQLFit(dge, design, robust = TRUE)",
    "result <- topTags(glmQLFTest(fit, coef = 2), n = Inf)$table",
    sep = "\n")
}
