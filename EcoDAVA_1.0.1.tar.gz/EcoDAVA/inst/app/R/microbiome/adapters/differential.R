microbiome_differential_metadata <- function(bundle, group_name) {
  if (!nrow(bundle$metadata) || !group_name %in% names(bundle$metadata)) stop("Differential analysis requires valid grouping variables.", call. = FALSE)
  group <- droplevels(factor(bundle$metadata[[group_name]]))
  if (nlevels(group) < 2 || any(table(group) < 2)) stop("A minimum of two samples per group is required.", call. = FALSE)
  group
}

microbiome_attach_taxonomy <- function(table, bundle) {
  if (!nrow(bundle$taxonomy)) return(table)
  taxonomy <- bundle$taxonomy
  taxonomy$Feature <- rownames(taxonomy)
  merge(table, taxonomy, by = "Feature", all.x = TRUE, sort = FALSE)
}

microbiome_differential_significance <- function(p) {
  p <- suppressWarnings(as.numeric(p))
  ifelse(is.na(p), "ns", ifelse(p < 0.001, "***", ifelse(p < 0.01, "**", ifelse(p < 0.05, "*", "ns"))))
}

microbiome_differential_effect_plot <- function(table, method_id, maximum_features = 20L) {
  if (!nrow(table)) return(NULL)
  effect <- suppressWarnings(as.numeric(table$effect %||% table$log2_fold_change))
  adjusted <- suppressWarnings(as.numeric(table$adjusted_p %||% table$raw_p))
  score <- ifelse(is.finite(effect), abs(effect), -log10(pmax(adjusted, .Machine$double.xmin)))
  keep <- order(score, decreasing = TRUE, na.last = NA)
  keep <- utils::head(keep, maximum_features)
  if (!length(keep)) return(NULL)
  display <- table[keep, , drop = FALSE]
  display$Effect <- effect[keep]
  if (!any(is.finite(display$Effect))) display$Effect <- -log10(pmax(adjusted[keep], .Machine$double.xmin))
  feature_label <- as.character(display$Feature)
  if (anyDuplicated(feature_label) && "contrast" %in% names(display)) {
    feature_label <- paste(feature_label, display$contrast, sep = " | ")
  }
  feature_label <- make.unique(feature_label)
  display$Feature <- factor(feature_label, levels = rev(feature_label))
  display$Significance <- microbiome_differential_significance(adjusted[keep])
  display$Direction <- ifelse(display$Effect >= 0, "Positive", "Negative")
  ggplot2::ggplot(display, ggplot2::aes(Feature, Effect, fill = Direction)) +
    ggplot2::geom_col(width = 0.72, colour = "#30363B", linewidth = 0.25) +
    ggplot2::geom_text(ggplot2::aes(label = Significance),
      hjust = ifelse(display$Effect >= 0, -0.25, 1.25), size = 3.5) +
    ggplot2::coord_flip(clip = "off") +
    ggplot2::scale_fill_manual(values = c(Positive = "#C64B40", Negative = "#3979A8")) +
    ggplot2::labs(title = paste(method_id, "differential abundance"), x = NULL,
      y = if (any(is.finite(effect))) "Effect estimate" else "-log10(adjusted P)", fill = "Direction") +
    ggplot2::theme_classic(base_size = 12) +
    ggplot2::theme(plot.margin = ggplot2::margin(8, 28, 8, 8))
}

microbiome_differential_forest_plot <- function(table, method_id, maximum_features = 20L) {
  if (!all(c("effect", "standard_error") %in% names(table))) return(NULL)
  effect <- suppressWarnings(as.numeric(table$effect))
  standard_error <- suppressWarnings(as.numeric(table$standard_error))
  adjusted <- suppressWarnings(as.numeric(table$adjusted_p %||% table$raw_p))
  keep <- which(is.finite(effect) & is.finite(standard_error) & standard_error >= 0)
  if (!length(keep)) return(NULL)
  keep <- utils::head(keep[order(abs(effect[keep]), decreasing = TRUE)], maximum_features)
  display <- table[keep, , drop = FALSE]
  display$Estimate <- effect[keep]
  display$Lower <- display$Estimate - 1.96 * standard_error[keep]
  display$Upper <- display$Estimate + 1.96 * standard_error[keep]
  feature_label <- as.character(display$Feature)
  if (anyDuplicated(feature_label) && "contrast" %in% names(display)) {
    feature_label <- paste(feature_label, display$contrast, sep = " | ")
  }
  feature_label <- make.unique(feature_label)
  display$Feature <- factor(feature_label, levels = rev(feature_label))
  display$Significance <- microbiome_differential_significance(adjusted[keep])
  display$Significant <- adjusted[keep] < 0.05
  ggplot2::ggplot(display, ggplot2::aes(Estimate, Feature, colour = Significant)) +
    ggplot2::geom_segment(ggplot2::aes(x = Lower, xend = Upper, yend = Feature), linewidth = 0.7) +
    ggplot2::geom_point(size = 2.8) +
    ggplot2::geom_text(ggplot2::aes(x = Upper, label = Significance), hjust = -0.35,
      colour = "#202428", size = 3.5) +
    ggplot2::geom_vline(xintercept = 0, linetype = "dashed", colour = "#606870") +
    ggplot2::scale_colour_manual(values = c(`FALSE` = "#879199", `TRUE` = "#C64B40"), guide = "none") +
    ggplot2::labs(title = paste(method_id, "model coefficients"), x = "Estimate (95% CI)", y = NULL) +
    ggplot2::theme_classic(base_size = 12) +
    ggplot2::theme(plot.margin = ggplot2::margin(8, 28, 8, 8))
}

microbiome_ancombc2_flags <- function(mode) {
  mode <- match.arg(mode, c("two_group", "global", "pairwise", "dunnett", "trend"))
  list(
    # ANCOMBC 2.12.x sensitivity analysis requires the global array when
    # pattern analysis is requested; both are produced by the same model fit.
    global = mode %in% c("global", "trend"),
    pairwise = identical(mode, "pairwise"),
    dunnet = identical(mode, "dunnett"),
    trend = identical(mode, "trend")
  )
}

microbiome_ancombc2_random_formula <- function(spec, metadata) {
  structure <- spec$random_structure %||% "none"
  require_column <- function(value, label) {
    value <- as.character(value %||% "")
    if (length(value) != 1L || is.na(value) || !nzchar(value) ||
        !value %in% names(metadata)) {
      stop(label, " must be explicitly selected from sample metadata.", call. = FALSE)
    }
    value
  }
  require_distinct <- function(first, second, label) {
    if (identical(first, second)) {
      stop(label, " must use two different metadata variables.", call. = FALSE)
    }
    c(first, second)
  }
  switch(structure,
    none = NULL,
    intercept = sprintf("(1 | %s)",
      require_column(spec$random_cluster %||% "", "Random-intercept variable")),
    slope = {
      values <- require_distinct(
        require_column(spec$random_cluster %||% "", "Random-intercept variable"),
        require_column(spec$random_slope_variable %||% "", "Random-slope variable"),
        "Random-intercept and random-slope terms")
      sprintf("(%s | %s)", values[[2]], values[[1]])
    },
    nested = {
      values <- require_distinct(
        require_column(spec$random_outer_variable %||% "", "Outer random variable"),
        require_column(spec$random_inner_variable %||% "", "Inner random variable"),
        "Outer and inner random-effect terms")
      sprintf("(1 | %s/%s)", values[[1]], values[[2]])
    },
    stop("Unsupported ANCOM-BC2 random-effect structure.", call. = FALSE)
  )
}

microbiome_ancombc2_model_metadata <- function(metadata, group, spec) {
  metadata <- as.data.frame(metadata, check.names = FALSE)
  if (length(group) != nrow(metadata)) {
    stop("ANCOM-BC2 group values must match the aligned metadata rows.",
      call. = FALSE)
  }
  structure <- spec$random_structure %||% "none"
  random_variables <- switch(structure,
    none = character(),
    intercept = as.character(spec$random_cluster %||% ""),
    slope = as.character(c(
      spec$random_cluster %||% "", spec$random_slope_variable %||% "")),
    nested = as.character(c(
      spec$random_outer_variable %||% "", spec$random_inner_variable %||% "")),
    stop("Unsupported ANCOM-BC2 random-effect structure.", call. = FALSE)
  )
  random_variables <- unique(random_variables[
    !is.na(random_variables) & nzchar(random_variables)])
  missing_variables <- setdiff(random_variables, names(metadata))
  if (length(missing_variables)) {
    stop("ANCOM-BC2 random-effect variables are missing from metadata: ",
      paste(missing_variables, collapse = ", "), call. = FALSE)
  }

  sample_ids <- rownames(metadata)
  model_metadata <- data.frame(SampleID = sample_ids, group = group,
    row.names = sample_ids, check.names = FALSE)
  for (variable in random_variables) {
    value <- metadata[[variable]]
    if (!is.atomic(value) || is.matrix(value) || length(value) != nrow(metadata)) {
      stop("ANCOM-BC2 model metadata column '", variable,
        "' must be a one-dimensional atomic vector.", call. = FALSE)
    }
    model_metadata[[variable]] <- value
  }
  model_metadata
}

microbiome_ancombc2_trend_control <- function(levels, spec) {
  coefficient_count <- length(levels) - 1L
  if (coefficient_count < 2L) {
    stop("Trend analysis requires at least three ordered group levels.", call. = FALSE)
  }
  pattern <- spec$trend_pattern %||% "increasing"
  increasing <- matrix(0, nrow = coefficient_count, ncol = coefficient_count)
  increasing[1, 1] <- 1
  if (coefficient_count > 1L) {
    for (index in 2:coefficient_count) {
      increasing[index, index - 1L] <- -1
      increasing[index, index] <- 1
    }
  }
  turn_level <- spec$trend_turning_level %||% ""
  turn <- match(turn_level, levels)
  if (is.na(turn) || turn <= 1L || turn >= length(levels)) {
    turn <- ceiling(length(levels) / 2)
  }
  turn_node <- max(1L, min(coefficient_count, turn - 1L))
  umbrella <- increasing
  if (turn <= coefficient_count) {
    umbrella[turn:coefficient_count, ] <- -umbrella[turn:coefficient_count, ]
  }
  contrasts <- list(
    increasing = increasing,
    decreasing = -increasing,
    umbrella = umbrella,
    inverted_umbrella = -umbrella
  )
  if (!pattern %in% names(contrasts)) {
    stop("Unsupported ANCOM-BC2 trend pattern.", call. = FALSE)
  }
  selected_contrast <- contrasts[[pattern]]
  selected_node <- if (pattern %in% c("increasing", "decreasing")) {
    coefficient_count
  } else {
    turn_node
  }
  # ANCOMBC 2.12.x drops the sensitivity array dimension for a one-item
  # contrast list. Duplicating the same cone preserves the requested test.
  list(contrast = list(selected_contrast, selected_contrast),
    node = list(selected_node, selected_node), solver = "OSQP",
    B = max(10L, as.integer(spec$mdfdr_bootstraps %||% 100L)))
}

microbiome_ancombc2_contrast_label <- function(suffix, group_levels, reference) {
  parts <- strsplit(sub("^group", "", suffix), "_group", fixed = FALSE)[[1]]
  match_level <- function(value) {
    candidates <- group_levels[make.names(group_levels) == make.names(value)]
    if (length(candidates)) candidates[[1]] else value
  }
  parts <- vapply(parts, match_level, character(1))
  if (length(parts) == 1L) paste(parts[[1]], "vs", reference) else
    paste(parts[[1]], "vs", parts[[2]])
}

microbiome_ancombc2_long_result <- function(raw, result_type, group_levels,
    reference, lfc_scale = "ln") {
  if (is.null(raw) || !NROW(raw)) return(data.frame())
  raw <- as.data.frame(raw, check.names = FALSE)
  if (identical(result_type, "global")) {
    robust <- as.logical(raw$diff_robust_abn %||% FALSE)
    different <- as.logical(raw$diff_abn %||% FALSE)
    robust[is.na(robust)] <- FALSE
    different[is.na(different)] <- FALSE
    status <- ifelse(robust, "Robust significant",
      ifelse(different, "Sensitivity candidate", "Not significant"))
    return(data.frame(
      Feature = as.character(raw$taxon),
      contrast = "Global test",
      statistic = suppressWarnings(as.numeric(raw$W)),
      raw_p = suppressWarnings(as.numeric(raw$p_val)),
      adjusted_p = suppressWarnings(as.numeric(raw$q_val)),
      differentially_abundant = different,
      sensitivity_passed = as.logical(raw$passed_ss),
      robust_difference = robust,
      result_status = status,
      result_type = result_type,
      stringsAsFactors = FALSE
    ))
  }
  coefficient_columns <- grep("^lfc_group", names(raw), value = TRUE)
  if (!length(coefficient_columns)) return(data.frame())
  scale_divisor <- if (identical(lfc_scale, "log2")) log(2) else 1
  do.call(rbind, lapply(coefficient_columns, function(column) {
    suffix <- sub("^lfc_", "", column)
    value <- function(prefix, fallback = NA) {
      name <- paste0(prefix, suffix)
      if (name %in% names(raw)) raw[[name]] else rep(fallback, nrow(raw))
    }
    effect <- suppressWarnings(as.numeric(raw[[column]])) / scale_divisor
    standard_error <- suppressWarnings(as.numeric(value("se_"))) / scale_divisor
    raw_p <- suppressWarnings(as.numeric(value("p_")))
    adjusted_p <- suppressWarnings(as.numeric(value("q_")))
    different <- as.logical(value("diff_", FALSE))
    sensitivity <- as.logical(value("passed_ss_", FALSE))
    robust <- as.logical(value("diff_robust_", FALSE))
    if ("p_val" %in% names(raw)) {
      raw_p <- suppressWarnings(as.numeric(raw$p_val))
      adjusted_p <- suppressWarnings(as.numeric(raw$q_val))
      different <- as.logical(raw$diff_abn)
      sensitivity <- as.logical(raw$passed_ss)
      robust <- as.logical(raw$diff_robust_abn)
    }
    different[is.na(different)] <- FALSE
    sensitivity[is.na(sensitivity)] <- FALSE
    robust[is.na(robust)] <- FALSE
    data.frame(
      Feature = as.character(raw$taxon),
      contrast = microbiome_ancombc2_contrast_label(
        suffix, group_levels, reference),
      effect = effect,
      effect_scale = if (identical(lfc_scale, "log2"))
        "log2 fold change" else "Natural-log fold change",
      standard_error = standard_error,
      conf_low = effect - stats::qnorm(0.975) * standard_error,
      conf_high = effect + stats::qnorm(0.975) * standard_error,
      statistic = if ("W" %in% names(raw)) suppressWarnings(as.numeric(raw$W)) else
        suppressWarnings(as.numeric(value("W_"))),
      raw_p = raw_p,
      adjusted_p = adjusted_p,
      differentially_abundant = different,
      sensitivity_passed = sensitivity,
      robust_difference = robust,
      result_status = ifelse(robust, "Robust significant",
        ifelse(different, "Sensitivity candidate", "Not significant")),
      result_type = result_type,
      stringsAsFactors = FALSE
    )
  }))
}

microbiome_ancombc2_structural_zeros <- function(zero_ind) {
  empty <- data.frame(
    Feature = character(), StructuralZeroGroup = character(),
    effect = numeric(), standard_error = numeric(),
    conf_low = numeric(), conf_high = numeric(),
    raw_p = numeric(), adjusted_p = numeric(),
    result_status = character(), effect_note = character(),
    stringsAsFactors = FALSE)
  if (is.null(zero_ind) || !NROW(zero_ind)) return(empty)
  zero_ind <- as.data.frame(zero_ind, check.names = FALSE)
  columns <- setdiff(names(zero_ind), "taxon")
  rows <- lapply(columns, function(column) {
    selected <- which(as.logical(zero_ind[[column]]))
    if (!length(selected)) return(NULL)
    data.frame(
      Feature = as.character(zero_ind$taxon[selected]),
      StructuralZeroGroup = sub("^structural_zero \\(group = (.*)\\)$", "\\1", column),
      effect = NA_real_, standard_error = NA_real_,
      conf_low = NA_real_, conf_high = NA_real_,
      raw_p = NA_real_, adjusted_p = NA_real_,
      result_status = "Structural zero",
      effect_note = "LFC and confidence interval are not estimated for structural zeros.",
      stringsAsFactors = FALSE
    )
  })
  result <- Filter(Negate(is.null), rows)
  if (length(result)) do.call(rbind, result) else empty
}

microbiome_ancombc2_selected_features <- function(table, maximum_features = 30L) {
  if (is.null(table) || !NROW(table)) return(character())
  value_or <- function(name, default) {
    if (name %in% names(table)) table[[name]] else rep(default, nrow(table))
  }
  q <- suppressWarnings(as.numeric(value_or("adjusted_p", NA_real_)))
  effect <- suppressWarnings(as.numeric(value_or("effect", 0)))
  robust <- as.logical(value_or("robust_difference", FALSE))
  candidate <- as.logical(value_or("differentially_abundant", FALSE))
  rank <- order(!robust, !candidate, q, -abs(effect), na.last = TRUE)
  unique(utils::head(as.character(table$Feature[rank]), as.integer(maximum_features)))
}

microbiome_ancombc2_status_scales <- function() {
  list(
    shape = c("Robust significant" = 16, "Sensitivity candidate" = 21,
      "Structural zero" = 17, "Not significant" = 1),
    colour = c("Robust significant" = "#1F6F8B", "Sensitivity candidate" = "#C55A11",
      "Structural zero" = "#7A3E9D", "Not significant" = "#7A8288")
  )
}

microbiome_ancombc2_forest <- function(table, structural, title, x_label,
    maximum_features, facet_phylum = FALSE) {
  if (!NROW(table)) return(NULL)
  selected <- microbiome_ancombc2_selected_features(table, maximum_features)
  shown <- table[table$Feature %in% selected & is.finite(table$effect), , drop = FALSE]
  if (!NROW(shown)) return(NULL)
  shown$Feature <- factor(shown$Feature, levels = rev(unique(selected)))
  scales <- microbiome_ancombc2_status_scales()
  plot <- ggplot2::ggplot(shown, ggplot2::aes(effect, Feature, colour = result_status)) +
    ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "#4D5358") +
    ggplot2::geom_errorbar(ggplot2::aes(xmin = conf_low, xmax = conf_high),
      width = 0, linewidth = 0.55, orientation = "y") +
    ggplot2::geom_point(ggplot2::aes(shape = result_status, fill = result_status),
      size = 2.8, stroke = 0.8) +
    ggplot2::scale_shape_manual(values = scales$shape) +
    ggplot2::scale_colour_manual(values = scales$colour) +
    ggplot2::scale_fill_manual(values = c(
      "Robust significant" = "#1F6F8B", "Sensitivity candidate" = "white",
      "Structural zero" = "#7A3E9D", "Not significant" = "white")) +
    ggplot2::labs(title = title, x = x_label, y = NULL,
      shape = "ANCOM-BC2 status", colour = "ANCOM-BC2 status",
      fill = "ANCOM-BC2 status",
      caption = "Triangles at the right margin denote structural zeros; no finite LFC or confidence interval is assigned.") +
    ggplot2::theme_classic(base_size = 11)
  structural_features <- unique(as.character(structural$Feature %||% character()))
  structural_features <- intersect(structural_features, selected)
  if (length(structural_features)) {
    boundary <- max(shown$conf_high, na.rm = TRUE)
    span <- diff(range(c(shown$conf_low, shown$conf_high), na.rm = TRUE))
    structural_plot <- data.frame(
      Feature = factor(structural_features, levels = levels(shown$Feature)),
      x = boundary + max(span * 0.08, 0.1),
      result_status = "Structural zero")
    plot <- plot +
      ggplot2::geom_point(data = structural_plot,
        ggplot2::aes(x = x, y = Feature, shape = result_status,
          colour = result_status, fill = result_status),
        inherit.aes = FALSE, size = 3)
  }
  if (isTRUE(facet_phylum) && "Phylum" %in% names(shown)) {
    plot <- plot + ggplot2::facet_grid(Phylum ~ ., scales = "free_y", space = "free_y")
  }
  plot
}

microbiome_ancombc2_plots <- function(table, tables, counts, group, group_name,
    taxonomy, metadata = data.frame(), spec = list()) {
  requested <- as.character(spec$plot_types %||% "volcano")
  alpha <- as.numeric(spec$alpha %||% 0.05)
  maximum_features <- as.integer(spec$maximum_features %||% 30L)
  lfc_label <- if (identical(spec$lfc_scale %||% "ln", "log2"))
    "log2 fold change" else "Natural-log fold change"
  structural <- tables$structural_zero_results %||% data.frame()
  effect_table <- table
  if (!"effect" %in% names(effect_table) &&
      NROW(tables$fixed_effect_results %||% data.frame())) {
    fixed <- tables$fixed_effect_results
    global_columns <- intersect(c("Feature", "adjusted_p", "raw_p",
      "differentially_abundant", "sensitivity_passed",
      "robust_difference", "result_status"), names(table))
    global_status <- table[, global_columns, drop = FALSE]
    effect_table <- merge(fixed, global_status, by = "Feature",
      all.x = FALSE, all.y = FALSE, suffixes = c(".coefficient", ""))
  }
  selected <- intersect(
    microbiome_ancombc2_selected_features(table, maximum_features),
    colnames(counts))
  relative <- counts / pmax(rowSums(counts), 1)
  sample_ids <- rownames(counts) %||% paste0("Sample_", seq_len(nrow(counts)))
  plots <- list()
  status_scales <- microbiome_ancombc2_status_scales()

  if ("volcano" %in% requested && NROW(table) && "effect" %in% names(table)) {
    shown <- table[is.finite(table$effect) & is.finite(table$adjusted_p), , drop = FALSE]
    shown$volcano_y <- -log10(pmax(shown$adjusted_p, .Machine$double.xmin))
    lfc_threshold <- as.numeric(spec$lfc_threshold %||% 0)
    top_n <- as.integer(spec$top_labels %||% 10L)
    label_rows <- utils::head(order(shown$adjusted_p, -abs(shown$effect)), top_n)
    shown$Label <- ""
    shown$Label[label_rows] <- shown$Feature[label_rows]
    plots$volcano <- ggplot2::ggplot(shown,
      ggplot2::aes(effect, volcano_y, colour = result_status,
        shape = result_status, fill = result_status)) +
      ggplot2::geom_hline(yintercept = -log10(alpha), linetype = 2, colour = "#555B60") +
      ggplot2::geom_vline(xintercept = c(-lfc_threshold, lfc_threshold),
        linetype = if (lfc_threshold > 0) 3 else 1,
        colour = if (lfc_threshold > 0) "#8A8F94" else "transparent") +
      ggplot2::geom_point(size = 2.5, alpha = 0.82, stroke = 0.75) +
      ggplot2::geom_text(ggplot2::aes(label = Label), check_overlap = TRUE,
        vjust = -0.7, size = 3, show.legend = FALSE) +
      ggplot2::scale_shape_manual(values = status_scales$shape) +
      ggplot2::scale_colour_manual(values = status_scales$colour) +
      ggplot2::scale_fill_manual(values = c(
        "Robust significant" = "#1F6F8B", "Sensitivity candidate" = "white",
        "Not significant" = "white")) +
      ggplot2::labs(title = "ANCOM-BC2 two-group differential abundance",
        x = lfc_label, y = expression(-log[10](q)),
        colour = "ANCOM-BC2 status", shape = "ANCOM-BC2 status",
        fill = "ANCOM-BC2 status") +
      ggplot2::theme_classic(base_size = 11)
  }
  if ("two_group_forest" %in% requested) {
    plots$two_group_forest <- microbiome_ancombc2_forest(
      table, structural, "ANCOM-BC2 two-group effects", lfc_label,
      maximum_features, spec$facet_phylum)
  }
  if ("dunnett_forest" %in% requested) {
    plots$dunnett_forest <- microbiome_ancombc2_forest(
      table, structural,
      paste0("ANCOM-BC2 Dunnett comparisons; reference: ",
        spec$reference_group %||% levels(group)[[1]]),
      lfc_label, maximum_features, spec$facet_phylum)
  }
  if ("global_summary" %in% requested && NROW(table)) {
    shown <- table[order(table$adjusted_p, na.last = NA), , drop = FALSE]
    shown <- utils::head(shown, maximum_features)
    shown$Feature <- factor(shown$Feature, levels = rev(shown$Feature))
    plots$global_summary <- ggplot2::ggplot(shown,
      ggplot2::aes(-log10(pmax(adjusted_p, .Machine$double.xmin)), Feature,
        fill = result_status)) +
      ggplot2::geom_col(width = 0.72) +
      ggplot2::geom_vline(xintercept = -log10(alpha), linetype = 2) +
      ggplot2::scale_fill_manual(values = c(
        "Robust significant" = "#1F6F8B", "Sensitivity candidate" = "#E09F3E",
        "Not significant" = "#C7CDD1")) +
      ggplot2::labs(title = "ANCOM-BC2 multi-group global test",
        x = expression(-log[10](q)), y = NULL, fill = "ANCOM-BC2 status") +
      ggplot2::theme_classic(base_size = 11)
  }
  if ("pairwise_heatmap" %in% requested && NROW(table)) {
    shown <- table[table$Feature %in% selected, , drop = FALSE]
    shown$display_effect <- shown$effect
    nonsig <- !as.logical(shown$differentially_abundant %||% FALSE)
    if (identical(spec$heatmap_nonsignificant %||% "grey", "grey")) {
      shown$display_effect[nonsig] <- NA_real_
    }
    shown$cell_alpha <- ifelse(nonsig, 0.28, 1)
    shown$cell_label <- ifelse(nonsig, "",
      ifelse(shown$adjusted_p < 0.001, "***",
        ifelse(shown$adjusted_p < 0.01, "**",
          ifelse(shown$adjusted_p < 0.05, "*", ""))))
    plots$pairwise_heatmap <- ggplot2::ggplot(shown,
      ggplot2::aes(contrast, Feature, fill = display_effect, alpha = cell_alpha)) +
      ggplot2::geom_tile(colour = "white", linewidth = 0.35) +
      ggplot2::geom_text(ggplot2::aes(label = cell_label), size = 3) +
      ggplot2::scale_fill_gradient2(low = "#2166AC", mid = "white",
        high = "#B2182B", midpoint = 0, na.value = "#D7DADD", name = lfc_label) +
      ggplot2::scale_alpha_identity() +
      ggplot2::labs(title = "ANCOM-BC2 pairwise LFC heatmap", x = NULL, y = NULL) +
      ggplot2::theme_classic(base_size = 11) +
      ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 35, hjust = 1))
  }
  if ("differential_bubble" %in% requested && NROW(effect_table) &&
      "effect" %in% names(effect_table)) {
    shown <- effect_table[
      effect_table$Feature %in% selected & is.finite(effect_table$effect), , drop = FALSE]
    shown$Direction <- ifelse(shown$effect >= 0, "Positive", "Negative")
    shown$Robustness <- ifelse(shown$robust_difference, "Robust",
      ifelse(shown$differentially_abundant, "Sensitivity candidate", "Not significant"))
    plots$differential_bubble <- ggplot2::ggplot(shown,
      ggplot2::aes(contrast, Feature, size = abs(effect), fill = Direction,
        alpha = Robustness)) +
      ggplot2::geom_point(shape = 21, colour = "#30363B", stroke = 0.5) +
      ggplot2::scale_fill_manual(values = c("Positive" = "#B2182B", "Negative" = "#2166AC")) +
      ggplot2::scale_alpha_manual(values = c("Robust" = 1,
        "Sensitivity candidate" = 0.65, "Not significant" = 0.22)) +
      ggplot2::labs(title = "ANCOM-BC2 differential-taxa effects",
        x = NULL, y = NULL, size = paste0("|", lfc_label, "|")) +
      ggplot2::theme_classic(base_size = 11) +
      ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 35, hjust = 1))
  }

  if (length(selected)) {
    abundance <- data.frame(
      Group = rep(as.character(group), times = length(selected)),
      Feature = rep(selected, each = nrow(counts)),
      RelativeAbundance = as.vector(relative[, selected, drop = FALSE]),
      stringsAsFactors = FALSE
    )
    abundance$Feature <- factor(abundance$Feature, levels = selected)
    if ("abundance_distribution" %in% requested) {
      plots$abundance_distribution <- ggplot2::ggplot(abundance,
        ggplot2::aes(Group, RelativeAbundance, fill = Group)) +
        ggplot2::geom_violin(trim = FALSE, alpha = 0.45, linewidth = 0.35) +
        ggplot2::geom_boxplot(width = 0.16, outlier.shape = NA,
          fill = "white", linewidth = 0.35) +
        ggplot2::facet_wrap(~Feature, scales = "free_y") +
        ggplot2::labs(title = "Relative abundance of ANCOM-BC2 taxa",
          x = group_name, y = "Sample relative abundance", fill = group_name,
          caption = paste(
            "Abundance plots show sample relative abundance;",
            "significance is derived from the ANCOM-BC2 bias-corrected model.")) +
        ggplot2::theme_classic(base_size = 11) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 30, hjust = 1))
    }
    if ("sample_heatmap" %in% requested) {
      transform <- spec$heatmap_transform %||% "relative"
      matrix <- relative[, selected, drop = FALSE]
      legend <- "Relative abundance"
      if (identical(transform, "log10_relative")) {
        matrix <- log10(matrix + 1e-06)
        legend <- "log10 relative abundance"
      } else if (identical(transform, "clr")) {
        logged <- log(relative[, selected, drop = FALSE] + 1e-06)
        matrix <- logged - rowMeans(logged)
        legend <- "CLR"
      } else if (identical(transform, "row_z")) {
        matrix <- t(scale(t(matrix)))
        matrix[!is.finite(matrix)] <- 0
        legend <- "Row Z-score"
      }
      sample_order <- order(group)
      annotation_columns <- intersect(
        as.character(spec$heatmap_annotations %||% character()), names(metadata))
      column_annotation <- if (length(annotation_columns)) {
        apply(metadata[sample_order, annotation_columns, drop = FALSE], 1,
          function(value) paste(paste(annotation_columns, value, sep = "="),
            collapse = " | "))
      } else {
        as.character(group)[sample_order]
      }
      row_results <- effect_table[
        order(effect_table$adjusted_p, -abs(effect_table$effect), na.last = TRUE),
        , drop = FALSE]
      row_results <- row_results[!duplicated(row_results$Feature), , drop = FALSE]
      row_results <- row_results[match(selected, row_results$Feature), , drop = FALSE]
      row_direction <- ifelse(row_results$effect >= 0, "Positive", "Negative")
      row_label <- sprintf("%s | %s | LFC=%.2f | q=%.3g",
        selected, row_direction, row_results$effect, row_results$adjusted_p)
      names(row_label) <- selected
      phylum <- if ("Phylum" %in% names(row_results)) {
        as.character(row_results$Phylum)
      } else {
        rep("Taxa", length(selected))
      }
      phylum[is.na(phylum) | !nzchar(phylum)] <- "Unclassified"
      names(phylum) <- selected
      heat <- data.frame(
        Sample = rep(sample_ids[sample_order], times = length(selected)),
        Feature = rep(row_label[selected], each = nrow(counts)),
        Phylum = rep(phylum[selected], each = nrow(counts)),
        Group = rep(as.character(group)[sample_order], times = length(selected)),
        ColumnAnnotation = rep(column_annotation, times = length(selected)),
        Value = as.vector(matrix[sample_order, , drop = FALSE]),
        stringsAsFactors = FALSE
      )
      heat$Sample <- factor(heat$Sample, levels = sample_ids[sample_order])
      heat$Feature <- factor(heat$Feature, levels = rev(row_label[selected]))
      plots$sample_heatmap <- ggplot2::ggplot(heat,
        ggplot2::aes(Sample, Feature, fill = Value)) +
        ggplot2::geom_tile() +
        ggplot2::facet_grid(Phylum ~ ColumnAnnotation,
          scales = "free", space = "free") +
        ggplot2::scale_fill_gradient2(low = "#2166AC", mid = "white",
          high = "#B2182B", midpoint = 0, name = legend) +
        ggplot2::labs(title = "ANCOM-BC2 differential-taxa sample heatmap",
          subtitle = "Rows: Phylum, direction, LFC and q-value; columns: selected sample metadata",
          x = NULL, y = NULL) +
        ggplot2::theme_classic(base_size = 11) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(
          angle = 90, hjust = 1, vjust = 0.5, size = 7))
    }
  }

  if ("contrast_upset" %in% requested && NROW(table)) {
    significant <- table[as.logical(table$differentially_abundant %||% FALSE), , drop = FALSE]
    contrasts <- unique(as.character(significant$contrast))
    if (NROW(significant) && length(contrasts) >= 2L) {
      incidence <- data.frame(Feature = unique(significant$Feature), stringsAsFactors = FALSE)
      for (contrast in contrasts) {
        incidence[[contrast]] <- incidence$Feature %in%
          significant$Feature[significant$contrast == contrast]
      }
      if (requireNamespace("ComplexUpset", quietly = TRUE)) {
        plots$contrast_upset <- ComplexUpset::upset(
          incidence, contrasts, name = "ANCOM-BC2 contrasts",
          base_annotations = list(
            "Significant taxa" = ComplexUpset::intersection_size()))
      } else {
        key <- apply(incidence[, contrasts, drop = FALSE], 1, function(value) {
          paste(contrasts[value], collapse = " & ")
        })
        intersections <- as.data.frame(table(key), stringsAsFactors = FALSE)
        names(intersections) <- c("Intersection", "Taxa")
        plots$contrast_upset <- ggplot2::ggplot(intersections,
          ggplot2::aes(Taxa, reorder(Intersection, Taxa))) +
          ggplot2::geom_col(fill = "#1F6F8B") +
          ggplot2::labs(title = "Significant-taxa intersections",
            subtitle = "Install ComplexUpset for the full matrix layout",
            x = "Number of taxa", y = NULL) +
          ggplot2::theme_classic(base_size = 11)
      }
    } else {
      plots$contrast_upset <- ggplot2::ggplot() +
        ggplot2::annotate("text", x = 0, y = 0,
          label = "No taxa were significant in two or more contrasts at the selected q-value threshold.") +
        ggplot2::labs(title = "ANCOM-BC2 significant-taxa intersections") +
        ggplot2::xlim(-1, 1) + ggplot2::ylim(-1, 1) +
        ggplot2::theme_void(base_size = 11)
    }
  }

  if ("taxonomy_tree" %in% requested && length(selected) && NROW(taxonomy)) {
    ranks <- intersect(c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species"),
      names(taxonomy))
    feature_column <- intersect(c("Feature", "Taxon", "ASV", "OTU"), names(taxonomy))[1]
    if (length(ranks) && length(feature_column) && !is.na(feature_column)) {
      tax <- taxonomy[match(selected, taxonomy[[feature_column]]), c(feature_column, ranks), drop = FALSE]
      edges <- list()
      for (index in seq_len(nrow(tax))) {
        path <- c("Microbiome", as.character(unlist(tax[index, ranks], use.names = FALSE)),
          as.character(tax[[feature_column]][index]))
        path <- path[nzchar(path) & !is.na(path)]
        if (length(path) > 1L) {
          edges[[length(edges) + 1L]] <- data.frame(
            from = head(path, -1), to = tail(path, -1), stringsAsFactors = FALSE)
        }
      }
      edge_table <- unique(do.call(rbind, edges))
      if (NROW(edge_table) && requireNamespace("igraph", quietly = TRUE) &&
          requireNamespace("ggraph", quietly = TRUE)) {
        graph <- igraph::graph_from_data_frame(edge_table)
        plots$taxonomy_tree <- ggraph::ggraph(graph, layout = "dendrogram", circular = TRUE) +
          ggraph::geom_edge_diagonal(colour = "#A8ADB2") +
          ggraph::geom_node_point(ggplot2::aes(
            colour = name %in% selected, size = name %in% selected)) +
          ggraph::geom_node_text(ggplot2::aes(
            label = ifelse(name %in% selected, name, "")), size = 2.7,
            repel = TRUE) +
          ggplot2::scale_colour_manual(values = c("FALSE" = "#B9BEC2", "TRUE" = "#B2182B")) +
          ggplot2::scale_size_manual(values = c("FALSE" = 1.2, "TRUE" = 3)) +
          ggplot2::labs(title = "ANCOM-BC2 significant-taxa taxonomy tree",
            subtitle = "Taxonomic mapping only; this is not LEfSe inference") +
          ggraph::theme_graph() +
          ggplot2::theme(legend.position = "none")
      }
    }
  }

  if (any(c("trend_heatmap", "trend_trajectory") %in% requested) && length(selected)) {
    group_levels <- levels(group)
    trend_summary <- stats::aggregate(RelativeAbundance ~ Group + Feature,
      data.frame(Group = factor(rep(as.character(group), times = length(selected)),
        levels = group_levels, ordered = TRUE),
        Feature = rep(selected, each = nrow(counts)),
        RelativeAbundance = as.vector(relative[, selected, drop = FALSE])),
      mean)
    if ("trend_heatmap" %in% requested) {
      trend_summary$Z <- ave(trend_summary$RelativeAbundance,
        trend_summary$Feature, FUN = function(value) {
          result <- as.numeric(scale(value))
          result[!is.finite(result)] <- 0
          result
        })
      plots$trend_heatmap <- ggplot2::ggplot(trend_summary,
        ggplot2::aes(Group, Feature, fill = Z)) +
        ggplot2::geom_tile(colour = "white") +
        ggplot2::scale_fill_gradient2(low = "#2166AC", mid = "white",
          high = "#B2182B", midpoint = 0, name = "Row Z-score") +
        ggplot2::labs(title = paste("ANCOM-BC2 trend:",
          gsub("_", " ", spec$trend_pattern %||% "increasing")),
          x = "Confirmed ordered group", y = NULL) +
        ggplot2::theme_classic(base_size = 11)
    }
    if ("trend_trajectory" %in% requested) {
      plots$trend_trajectory <- ggplot2::ggplot(trend_summary,
        ggplot2::aes(Group, RelativeAbundance, group = Feature, colour = Feature)) +
        ggplot2::geom_line(linewidth = 0.65) +
        ggplot2::geom_point(size = 2) +
        ggplot2::facet_wrap(~Feature, scales = "free_y") +
        ggplot2::labs(title = paste("ANCOM-BC2 taxon trajectories:",
          gsub("_", " ", spec$trend_pattern %||% "increasing")),
          x = "Confirmed ordered group", y = "Mean sample relative abundance") +
        ggplot2::theme_classic(base_size = 11) +
        ggplot2::theme(legend.position = "none")
    }
  }
  Filter(Negate(is.null), plots)
}

microbiome_lefse_palette <- function(name = "Dark2", n = 8L) {
  n <- max(1L, as.integer(n))
  if (identical(name, "OkabeIto")) {
    base <- c("#E69F00", "#56B4E9", "#009E73", "#F0E442",
      "#0072B2", "#D55E00", "#CC79A7", "#000000")
  } else {
    info <- RColorBrewer::brewer.pal.info
    palette_name <- if (name %in% rownames(info) && info[name, "category"] == "qual") {
      name
    } else {
      "Dark2"
    }
    base <- RColorBrewer::brewer.pal(
      min(max(3L, n), info[palette_name, "maxcolors"]), palette_name)
  }
  if (n <= length(base)) base[seq_len(n)] else grDevices::colorRampPalette(base)(n)
}

microbiome_lefse_selected_labels <- function(value) {
  labels <- trimws(unlist(strsplit(as.character(value %||% ""), "[,\r\n]+")))
  unique(labels[nzchar(labels)])
}

microbiome_lefse_group_order <- function(value, available) {
  selected <- intersect(as.character(value %||% character()), available)
  if (!length(selected)) return(NULL)
  unique(c(selected, setdiff(available, selected)))
}

microbiome_microeco_cladogram_compat <- function(plot) {
  if (!inherits(plot, "ggplot") || !requireNamespace("ggtree", quietly = TRUE)) return(plot)
  tree_data <- plot$data
  if (is.data.frame(tree_data) && !"label" %in% names(tree_data) &&
      "node" %in% names(tree_data)) {
    tree_data$label <- as.character(tree_data$node)
    plot$data <- tree_data
  }
  required <- c("x", "y", "node", "parent", "label")
  if (!is.data.frame(tree_data) || !all(required %in% names(tree_data))) return(plot)

  static_layer <- function(layer) {
    stat_class <- class(layer$stat)
    params <- layer$stat_params %||% list()
    aesthetics <- layer$aes_params %||% list()
    if (any(stat_class %in% c("StatCladBar", "StatCladeBar"))) {
      position <- ggtree:::get_cladelabel_position(
        data = tree_data,
        node = params$node,
        offset = params$offset %||% 0,
        align = isTRUE(params$align),
        adjustRatio = 1.02,
        angle = 0,
        extend = params$extend %||% 0
      )
      return(ggplot2::geom_segment(
        data = position,
        ggplot2::aes(x = .data$x, y = .data$y, xend = .data$xend, yend = .data$yend),
        inherit.aes = FALSE,
        linewidth = as.numeric(aesthetics$linewidth %||% aesthetics$size %||% 0.5),
        colour = aesthetics$colour %||% aesthetics$color %||% "black",
        na.rm = TRUE
      ))
    }
    if (any(stat_class %in% "StatCladeText")) {
      position <- ggtree:::get_cladelabel_position(
        data = tree_data,
        node = params$node,
        offset = params$offset %||% 0,
        align = isTRUE(params$align),
        adjustRatio = 1.03,
        angle = params$angle_ %||% 0,
        horizontal = isTRUE(params$horizontal)
      )
      position$y <- mean(c(position$y, position$yend))
      position$label <- params$label %||% ""
      return(ggplot2::geom_text(
        data = position,
        ggplot2::aes(x = .data$x, y = .data$y, label = .data$label, angle = .data$angle),
        inherit.aes = FALSE,
        size = as.numeric(aesthetics$size %||% 3.88),
        colour = aesthetics$colour %||% aesthetics$color %||% "black",
        family = aesthetics$family %||% "sans",
        hjust = as.numeric(aesthetics$hjust %||% 0),
        parse = isTRUE(aesthetics$parse),
        na.rm = TRUE
      ))
    }
    layer
  }

  plot$layers <- lapply(plot$layers, static_layer)
  plot
}

microbiome_run_differential <- function(method_id, bundle, spec = list()) {
  started <- proc.time()[["elapsed"]]
  analysis_warnings <- character()
  runtime_log <- character()
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  group_name <- spec$group %||% "Treatment"
  group <- microbiome_differential_metadata(bundle, group_name)
  counts <- microbiome_numeric_matrix(bundle$counts)
  prevalence <- colMeans(counts > 0)
  mean_abundance <- colMeans(counts)
  contrast <- paste(levels(group), collapse = " vs ")
  differential_method <- if (identical(method_id, "ancombc2")) {
    spec$differential_method %||% "ancombc2"
  } else {
    method_id
  }
  count_differential_counts <- counts
  count_differential_group <- group
  count_differential_normalized <- data.frame()
  count_differential_tables <- list()
  if (method_id == "lefse") {
    if (!requireNamespace("microeco", quietly = TRUE)) stop("LEfSe analysis requires the microeco package.", call. = FALSE)
    dataset <- microbiome_bundle_to_microeco(bundle)
    dataset$tax_table <- microeco::tidy_taxonomy(dataset$tax_table, add_prefix = TRUE)
    dataset$tidy_dataset()
    dataset[["cal_abund"]]()
    rank <- "all"
    available_groups <- levels(droplevels(factor(bundle$metadata[[group_name]])))
    subgroup <- as.character(spec$lefse_subgroup_variable %||% "")
    if (!nzchar(subgroup) && length(spec$group_variables %||% character()) > 1L) {
      subgroup <- as.character((spec$group_variables %||% character())[[2]])
    }
    if (!subgroup %in% setdiff(names(bundle$metadata), group_name)) subgroup <- NULL
    group_order <- microbiome_lefse_group_order(spec$lefse_group_order, available_groups)
    selected_labels <- microbiome_lefse_selected_labels(spec$lefse_cladogram_labels)
    group_colors <- microbiome_lefse_palette(
      spec$lefse_color_palette %||% "Dark2", length(available_groups))
    spec$taxonomic_rank <- rank
    spec$lefse_filter_threshold <- as.numeric(spec$lefse_filter_threshold %||% 0)
    spec$lefse_alpha <- as.numeric(spec$lefse_alpha %||% spec$alpha %||% 0.05)
    spec$lefse_p_adjust_method <- spec$lefse_p_adjust_method %||%
      spec$fdr_method %||% "fdr"
    spec$lefse_remove_unknown <- isTRUE(spec$lefse_remove_unknown %||% TRUE)
    spec$lefse_norm <- as.numeric(spec$lefse_norm %||% 1e6)
    spec$lefse_nresam <- as.numeric(spec$lefse_nresam %||% 0.6667)
    spec$lefse_boots <- as.integer(spec$lefse_boots %||% 30L)
    spec$lefse_subgroup_variable <- subgroup %||% ""
    spec$lefse_min_subsample <- as.integer(spec$lefse_min_subsample %||% 10L)
    spec$lefse_subgroup_alpha <- as.numeric(spec$lefse_subgroup_alpha %||% spec$lefse_alpha)
    spec$lefse_group_order <- group_order %||% character()
    spec$lefse_subgroup_strict <- isTRUE(spec$lefse_subgroup_strict %||% FALSE)
    spec$lefse_lda_threshold <- as.numeric(spec$lefse_lda_threshold %||% 2)
    spec$lefse_plot_max_taxa <- as.integer(spec$lefse_plot_max_taxa %||% 30L)
    spec$lefse_keep_full_name <- isTRUE(spec$lefse_keep_full_name %||% FALSE)
    spec$lefse_keep_prefix <- isTRUE(spec$lefse_keep_prefix %||% TRUE)
    spec$lefse_group_aggregate <- isTRUE(spec$lefse_group_aggregate %||% TRUE)
    spec$lefse_two_group_separate <- isTRUE(spec$lefse_two_group_separate %||% TRUE)
    spec$lefse_bar_coord_flip <- isTRUE(spec$lefse_bar_coord_flip %||% TRUE)
    spec$lefse_bar_add_significance <- isTRUE(
      spec$lefse_bar_add_significance %||% FALSE)
    spec$lefse_cladogram_background_taxa <- as.integer(
      spec$lefse_cladogram_background_taxa %||% 200L)
    spec$lefse_cladogram_features <- as.integer(
      spec$lefse_cladogram_features %||% 120L)
    spec$lefse_clade_label_level <- as.integer(spec$lefse_clade_label_level %||% 5L)
    spec$lefse_cladogram_only_selected <- isTRUE(
      spec$lefse_cladogram_only_selected %||% FALSE)
    spec$lefse_branch_size <- as.numeric(spec$lefse_branch_size %||% 0.2)
    spec$lefse_branch_alpha <- as.numeric(spec$lefse_branch_alpha %||% 0.2)
    spec$lefse_clade_label_size <- as.numeric(spec$lefse_clade_label_size %||% 2)
    spec$lefse_node_size_scale <- as.numeric(spec$lefse_node_size_scale %||% 1)
    spec$lefse_node_size_offset <- as.numeric(spec$lefse_node_size_offset %||% 1)
    spec$lefse_annotation_shape <- as.integer(spec$lefse_annotation_shape %||% 22L)
    spec$lefse_annotation_size <- as.numeric(spec$lefse_annotation_size %||% 5)
    spec$lefse_color_palette <- spec$lefse_color_palette %||% "Dark2"
    fit <- NULL
    fit_messages <- utils::capture.output({
      fit <- withCallingHandlers(
        microeco::trans_diff$new(dataset = dataset, method = "lefse",
          group = group_name, taxa_level = rank,
          filter_thres = spec$lefse_filter_threshold,
          alpha = spec$lefse_alpha,
          p_adjust_method = spec$lefse_p_adjust_method,
          remove_unknown = spec$lefse_remove_unknown,
          lefse_subgroup = subgroup,
          lefse_min_subsam = spec$lefse_min_subsample,
          lefse_sub_strict = isTRUE(spec$lefse_subgroup_strict %||% FALSE),
          lefse_sub_alpha = spec$lefse_subgroup_alpha,
          lefse_norm = spec$lefse_norm,
          nresam = spec$lefse_nresam,
          boots = spec$lefse_boots),
        warning = function(warning) {
          message <- conditionMessage(warning)
          analysis_warnings <<- unique(c(analysis_warnings,
            if (grepl("variables are collinear", message, fixed = TRUE)) {
              "LEfSe LDA detected collinear taxonomic features; scores were calculated after microeco/MASS internal handling."
            } else {
              message
            }))
          invokeRestart("muffleWarning")
        }
      )
    }, type = "message")
    runtime_log <- c(runtime_log, fit_messages)
    table <- as.data.frame(fit$res_diff, check.names = FALSE)
    feature_column <- intersect(c("Taxa", "Taxon", "Feature"), names(table))[1]
    effect_column <- intersect(c("LDA", "LDA score", "Score"), names(table))[1]
    p_column <- intersect(c("P.unadj", "P.value", "PValue", "p.value"), names(table))[1]
    adjusted_column <- intersect(c("P.adj", "AdjustedP", "padj"), names(table))[1]
    if (is.na(feature_column) || is.na(effect_column)) stop("microeco LEfSe did not return taxa and LDA-score columns.", call. = FALSE)
    table$Feature <- as.character(table[[feature_column]])
    table$effect <- suppressWarnings(as.numeric(table[[effect_column]]))
    table$raw_p <- if (!is.na(p_column)) suppressWarnings(as.numeric(table[[p_column]])) else NA_real_
    table$adjusted_p <- if (!is.na(adjusted_column)) {
      suppressWarnings(as.numeric(table[[adjusted_column]]))
    } else {
      stats::p.adjust(table$raw_p, method = spec$fdr_method %||% "BH")
    }
    table$contrast <- as.character(table$Group %||% contrast)
    table$prevalence <- prevalence[match(table$Feature, names(prevalence))]
    table$mean_abundance <- mean_abundance[match(table$Feature, names(mean_abundance))]
    table$convergence <- is.finite(table$effect)
    plot_types <- spec$plot_types %||% c("lda_bar", "cladogram")
    plots <- list()
    if ("lda_bar" %in% plot_types) {
      lda_values <- suppressWarnings(as.numeric(fit$res_diff$LDA))
      lda_rows <- which(is.finite(lda_values) & lda_values > spec$lefse_lda_threshold)
      lda_rows <- utils::head(lda_rows, spec$lefse_plot_max_taxa)
      plot_fit <- fit$clone(deep = TRUE)
      plots$lda_bar <- tryCatch({
        if (!length(lda_rows)) {
          stop("No LEfSe feature passed the selected LDA threshold.", call. = FALSE)
        }
        plot_fit$res_diff <- plot_fit$res_diff[lda_rows, , drop = FALSE]
        plot_fit$plot_diff_bar(
          color_values = group_colors,
          color_group_map = TRUE,
          use_number = seq_len(length(lda_rows)),
          threshold = NULL,
          keep_full_name = spec$lefse_keep_full_name,
          keep_prefix = spec$lefse_keep_prefix,
          group_order = group_order,
          group_aggre = spec$lefse_group_aggregate,
          group_two_sep = spec$lefse_two_group_separate,
          coord_flip = spec$lefse_bar_coord_flip,
          add_sig = spec$lefse_bar_add_significance)
      },
        error = function(error) microbiome_differential_effect_plot(table, method_id))
    }
    if ("cladogram" %in% plot_types) {
      plots$cladogram <- tryCatch(
        {
          plot <- NULL
          plot_messages <- utils::capture.output({
            plot <- withCallingHandlers(
              fit$plot_diff_cladogram(
                color = group_colors,
                group_order = group_order,
                use_taxa_num = as.integer(
                  spec$lefse_cladogram_background_taxa %||% 200L),
                use_feature_num = as.integer(spec$lefse_cladogram_features %||% 120L),
                clade_label_level = as.integer(spec$lefse_clade_label_level %||% 5L),
                select_show_labels = if (length(selected_labels)) selected_labels else NULL,
                only_select_show = isTRUE(
                  spec$lefse_cladogram_only_selected %||% FALSE),
                branch_size = as.numeric(spec$lefse_branch_size %||% 0.2),
                alpha = as.numeric(spec$lefse_branch_alpha %||% 0.2),
                clade_label_size = as.numeric(spec$lefse_clade_label_size %||% 2),
                node_size_scale = as.numeric(spec$lefse_node_size_scale %||% 1),
                node_size_offset = as.numeric(spec$lefse_node_size_offset %||% 1),
                annotation_shape = as.integer(spec$lefse_annotation_shape %||% 22L),
                annotation_shape_size = as.numeric(spec$lefse_annotation_size %||% 5)),
              warning = function(warning) {
                message <- conditionMessage(warning)
                if (!grepl("deprecated", message, ignore.case = TRUE)) {
                  analysis_warnings <<- unique(c(analysis_warnings, message))
                }
                invokeRestart("muffleWarning")
              }
            )
          }, type = "message")
          runtime_log <- c(runtime_log, plot_messages)
          microbiome_microeco_cladogram_compat(plot)
        },
        error = function(error) {
          stop(
            "microeco failed to draw the LEfSe cladogram. Check that ggtree, treeio, ",
            "tidytree, ggplot2 and dplyr are mutually compatible. Original error: ",
            conditionMessage(error),
            call. = FALSE
          )
        }
      )
    }
    packages <- "microeco"
    model <- fit
  } else if (method_id == "wilcoxon_kruskal") {
    relative <- counts / rowSums(counts)
    tests <- lapply(seq_len(ncol(relative)), function(index) {
      if (nlevels(group) == 2) stats::wilcox.test(relative[, index] ~ group, exact = FALSE) else stats::kruskal.test(relative[, index] ~ group)
    })
    raw_p <- vapply(tests, function(test) test$p.value, numeric(1))
    statistic <- vapply(tests, function(test) unname(test$statistic[[1]]), numeric(1))
    effect <- if (nlevels(group) == 2) vapply(seq_len(ncol(relative)), function(index) {
      medians <- tapply(relative[, index], group, stats::median)
      unname(medians[2] - medians[1])
    }, numeric(1)) else rep(NA_real_, ncol(relative))
    table <- data.frame(Feature = colnames(counts), contrast = contrast, test = if (nlevels(group) == 2) "Wilcoxon rank-sum" else "Kruskal-Wallis",
      statistic = statistic, effect = effect, raw_p = raw_p, adjusted_p = stats::p.adjust(raw_p, method = spec$fdr_method %||% "BH"),
      prevalence = prevalence, mean_abundance = mean_abundance, convergence = TRUE, stringsAsFactors = FALSE)
    packages <- character()
    model <- tests
  } else if (method_id == "anova_welch") {
    relative <- counts / rowSums(counts)
    tests <- lapply(seq_len(ncol(relative)), function(index) stats::oneway.test(relative[, index] ~ group, var.equal = FALSE))
    raw_p <- vapply(tests, function(test) test$p.value, numeric(1))
    statistic <- vapply(tests, function(test) unname(test$statistic), numeric(1))
    effect <- vapply(seq_len(ncol(relative)), function(index) diff(range(tapply(relative[, index], group, mean))), numeric(1))
    table <- data.frame(Feature = colnames(counts), contrast = contrast, test = "Welch one-way ANOVA",
      statistic = statistic, effect = effect, raw_p = raw_p,
      adjusted_p = stats::p.adjust(raw_p, method = spec$fdr_method %||% "BH"), prevalence = prevalence,
      mean_abundance = mean_abundance, convergence = TRUE, stringsAsFactors = FALSE)
    packages <- character()
    model <- tests
  } else if (method_id == "simper") {
    relative <- counts / rowSums(counts)
    fit <- vegan::simper(relative, group, permutations = as.integer(spec$permutations %||% 999L))
    table <- do.call(rbind, lapply(names(fit), function(comparison) {
      value <- fit[[comparison]]
      cumulative <- numeric(length(value$average))
      cumulative[value$ord] <- value$cusum
      data.frame(Feature = value$species, contrast = comparison, effect = unname(value$average),
        cumulative = cumulative, raw_p = unname(value$p), adjusted_p = stats::p.adjust(value$p, method = spec$fdr_method %||% "BH"),
        prevalence = prevalence[value$species], mean_abundance = mean_abundance[value$species], convergence = TRUE,
        stringsAsFactors = FALSE)
    }))
    packages <- "vegan"
    model <- fit
  } else if (method_id == "linda") {
    if (!requireNamespace("LinDA", quietly = TRUE)) stop("Missing LinDA package.", call. = FALSE)
    metadata <- bundle$metadata
    metadata$.dava_group <- group
    fit <- LinDA::linda(t(counts), metadata, "~ .dava_group", type = "count",
      adaptive = isTRUE(spec$adaptive %||% TRUE), imputation = isTRUE(spec$imputation %||% FALSE),
      pseudo.cnt = as.numeric(spec$pseudocount %||% 0.5), p.adj.method = spec$fdr_method %||% "BH",
      alpha = as.numeric(spec$alpha %||% 0.05), prev.cut = as.numeric(spec$minimum_prevalence %||% 0.1), n.cores = 1)
    table <- do.call(rbind, lapply(names(fit$output), function(coefficient) {
      value <- fit$output[[coefficient]]
      data.frame(Feature = rownames(value), contrast = coefficient, effect = value$log2FoldChange,
        standard_error = value$lfcSE, statistic = value$stat, raw_p = value$pvalue, adjusted_p = value$padj,
        differentially_abundant = value$reject, prevalence = prevalence[rownames(value)],
        mean_abundance = mean_abundance[rownames(value)], convergence = is.finite(value$log2FoldChange), stringsAsFactors = FALSE)
    }))
    packages <- "LinDA"
    model <- fit
  } else if (method_id == "ancombc2" &&
      differential_method %in% c("deseq2", "edger")) {
    if (!isTRUE(bundle$is_raw_count) || !all(counts == floor(counts))) {
      stop("DESeq2 and edgeR require the untransformed raw integer count table.",
        call. = FALSE)
    }
    allowed_plots <- unname(
      microbiome_differential_taxa_plot_choices(differential_method))
    requested_plots <- as.character(spec$plot_types %||% character())
    spec$plot_types <- intersect(requested_plots, allowed_plots)
    if (!length(spec$plot_types)) spec$plot_types <- utils::head(allowed_plots, 1L)
    engine_fit <- microbiome_run_count_differential_engine(
      differential_method, counts, group, spec, prevalence, mean_abundance)
    table <- engine_fit$table
    model <- engine_fit$model
    packages <- engine_fit$packages
    count_differential_counts <- counts[engine_fit$comparison$keep, , drop = FALSE]
    count_differential_group <- group[engine_fit$comparison$keep]
    count_differential_normalized <- engine_fit$normalized
    spec$reference_group <- engine_fit$comparison$reference
    spec$comparison_group <- engine_fit$comparison$comparison
    spec$contrast <- engine_fit$comparison$contrast
    spec$lfc_scale <- "log2"
    count_differential_tables <- list(
      model_summary = engine_fit$model_summary,
      normalized_abundance = engine_fit$normalized
    )
  } else if (method_id == "ancombc2") {
    if (!requireNamespace("ANCOMBC", quietly = TRUE)) {
      stop("ANCOM-BC2 requires the ANCOMBC package.", call. = FALSE)
    }
    if (!isTRUE(bundle$is_raw_count) || !all(counts == floor(counts))) {
      stop("ANCOM-BC2 requires the untransformed raw integer count table.", call. = FALSE)
    }
    mode <- spec$analysis_mode %||%
      if (nlevels(group) == 2L) "two_group" else "global"
    requested_plots <- as.character(spec$plot_types %||% character())
    spec$plot_types <- microbiome_ancombc2_resolve_plot_types(mode, requested_plots)
    ignored_plots <- setdiff(requested_plots, spec$plot_types)
    if (length(ignored_plots)) {
      analysis_warnings <- unique(c(analysis_warnings, paste0(
        "Ignored plot types that are incompatible with ANCOM-BC2 mode '",
        mode, "': ", paste(ignored_plots, collapse = ", "), ".")))
    }
    flags <- microbiome_ancombc2_flags(mode)
    group_levels <- levels(group)
    if (identical(mode, "two_group") && length(group_levels) != 2L) {
      stop("Two-group ANCOM-BC2 requires a grouping variable with exactly two valid levels.",
        call. = FALSE)
    }
    if (mode %in% c("global", "pairwise", "dunnett", "trend") &&
        length(group_levels) < 3L) {
      stop("The selected ANCOM-BC2 mode requires at least three valid group levels.",
        call. = FALSE)
    }
    if (identical(mode, "dunnett")) {
      reference <- spec$reference_group %||% ""
      if (!nzchar(reference) || !reference %in% group_levels) {
        stop("Dunnett-type ANCOM-BC2 requires an explicit valid reference group.",
          call. = FALSE)
      }
      group <- stats::relevel(group, ref = reference)
      group_levels <- levels(group)
    } else if (identical(mode, "trend")) {
      trend_order <- as.character(spec$trend_order %||% character())
      if (length(trend_order) != length(group_levels) ||
          length(unique(trend_order)) != length(group_levels) ||
          !setequal(trend_order, group_levels)) {
        stop("Trend ANCOM-BC2 requires every group level exactly once in the confirmed order.",
          call. = FALSE)
      }
      group <- factor(as.character(group), levels = trend_order)
      group_levels <- levels(group)
      reference <- group_levels[[1]]
    } else {
      reference <- group_levels[[1]]
    }
    metadata <- as.data.frame(bundle$metadata, check.names = FALSE)
    metadata <- metadata[rownames(counts), , drop = FALSE]
    random_formula <- microbiome_ancombc2_random_formula(spec, metadata)
    model_metadata <- microbiome_ancombc2_model_metadata(metadata, group, spec)
    trend_control <- if (flags$trend) {
      microbiome_ancombc2_trend_control(group_levels, spec)
    } else {
      list(contrast = NULL, node = NULL, solver = "OSQP",
        B = max(10L, as.integer(spec$mdfdr_bootstraps %||% 100L)))
    }
    fit <- ANCOMBC::ancombc2(data = t(round(counts)), taxa_are_rows = TRUE, meta_data = model_metadata,
      fix_formula = "group", rand_formula = random_formula, group = "group",
      p_adj_method = spec$fdr_method %||% "BH", pseudo_sens = TRUE,
      prv_cut = as.numeric(spec$minimum_prevalence %||% 0.1), lib_cut = 0, struc_zero = TRUE, neg_lb = TRUE,
      n_cl = 1, verbose = FALSE,
      global = flags$global, pairwise = flags$pairwise,
      dunnet = flags$dunnet, trend = flags$trend,
      trend_control = trend_control,
      mdfdr_control = list(fwer_ctrl_method = "holm",
        B = max(10L, as.integer(spec$mdfdr_bootstraps %||% 100L))))
    fixed_table <- microbiome_ancombc2_long_result(
      fit$res, "fixed_effect", group_levels, reference, spec$lfc_scale %||% "ln")
    global_table <- microbiome_ancombc2_long_result(
      fit$res_global, "global", group_levels, reference, spec$lfc_scale %||% "ln")
    pairwise_table <- microbiome_ancombc2_long_result(
      fit$res_pair, "pairwise", group_levels, reference, spec$lfc_scale %||% "ln")
    dunnett_table <- microbiome_ancombc2_long_result(
      fit$res_dunn, "dunnett", group_levels, reference, spec$lfc_scale %||% "ln")
    trend_table <- microbiome_ancombc2_long_result(
      fit$res_trend, "trend", group_levels, reference, spec$lfc_scale %||% "ln")
    if (NROW(trend_table)) trend_table$trend_pattern <- spec$trend_pattern %||% "increasing"
    structural_table <- microbiome_ancombc2_structural_zeros(fit$zero_ind)
    table <- switch(mode,
      two_group = fixed_table,
      global = global_table,
      pairwise = pairwise_table,
      dunnett = dunnett_table,
      trend = trend_table)
    if (!NROW(table)) {
      stop("ANCOM-BC2 did not return results for the selected analysis mode.",
        call. = FALSE)
    }
    add_abundance <- function(value) {
      if (!NROW(value)) return(value)
      value$prevalence <- prevalence[value$Feature]
      value$mean_abundance <- mean_abundance[value$Feature]
      value$convergence <- if ("effect" %in% names(value)) is.finite(value$effect) else TRUE
      value
    }
    ancom_tables <- list(
      fixed_effect_results = add_abundance(fixed_table),
      global_results = add_abundance(global_table),
      pairwise_results = add_abundance(pairwise_table),
      dunnett_results = add_abundance(dunnett_table),
      trend_results = add_abundance(trend_table),
      structural_zero_results = add_abundance(structural_table)
    )
    keep_tables <- vapply(ancom_tables, NROW, integer(1)) > 0L
    keep_tables[["structural_zero_results"]] <- TRUE
    ancom_tables <- ancom_tables[keep_tables]
    table <- add_abundance(table)
    spec$analysis_mode <- mode
    spec$reference_group <- reference
    spec$group_levels <- group_levels
    spec$random_formula <- random_formula
    spec$lfc_label <- if (identical(spec$lfc_scale %||% "ln", "log2"))
      "log2 fold change" else "Natural-log fold change"
    packages <- "ANCOMBC"
    model <- fit
  } else if (method_id == "maaslin2") {
    if (!requireNamespace("Maaslin2", quietly = TRUE)) stop("Missing Maaslin2 package.", call. = FALSE)
    fixed <- unique(c(group_name, intersect(spec$covariates %||% character(), names(bundle$metadata))))
    metadata <- bundle$metadata[, fixed, drop = FALSE]
    rownames(metadata) <- rownames(counts)
    output_dir <- tempfile("dava_maaslin2_")
    dir.create(output_dir, recursive = TRUE)
    on.exit(unlink(output_dir, recursive = TRUE, force = TRUE), add = TRUE)
    reference <- if (is.factor(metadata[[group_name]]) || is.character(metadata[[group_name]])) paste(group_name, levels(factor(metadata[[group_name]]))[1], sep = ",") else NULL
    fit <- Maaslin2::Maaslin2(input_data = as.data.frame(counts), input_metadata = metadata, output = output_dir,
      min_abundance = 0, min_prevalence = as.numeric(spec$minimum_prevalence %||% 0.1), normalization = "TSS",
      transform = "LOG", analysis_method = "LM", fixed_effects = fixed, correction = spec$fdr_method %||% "BH",
      standardize = isTRUE(spec$standardize %||% TRUE), cores = 1, plot_heatmap = FALSE, plot_scatter = FALSE,
      save_models = FALSE, save_scatter = FALSE, reference = reference)
    raw <- fit$results
    table <- raw[raw$metadata %in% fixed, , drop = FALSE]
    if (!nrow(table)) stop("MaAsLin2 did not return selected fixed effects results.", call. = FALSE)
    table <- data.frame(Feature = table$feature, contrast = paste(table$metadata, table$value, sep = ":"),
      effect = table$coef, standard_error = table$stderr, raw_p = table$pval, adjusted_p = table$qval,
      prevalence = prevalence[table$feature], mean_abundance = mean_abundance[table$feature],
      convergence = is.finite(table$coef), stringsAsFactors = FALSE)
    packages <- "Maaslin2"
    model <- list(results = raw)
  } else stop("The differential analysis adapter does not support method:", method_id, call. = FALSE)
  table <- microbiome_attach_taxonomy(table, bundle)
  if (method_id == "ancombc2" && identical(differential_method, "ancombc2")) {
    ancom_tables <- lapply(ancom_tables, microbiome_attach_taxonomy, bundle = bundle)
    ancom_tables$model_differential_taxa <- table[
      as.logical(table$differentially_abundant %||% FALSE), , drop = FALSE]
    ancom_tables$robust_differential_taxa <- table[
      as.logical(table$robust_difference %||% FALSE), , drop = FALSE]
    ancom_tables$sensitivity_candidates <- table[
      as.logical(table$differentially_abundant %||% FALSE) &
        !as.logical(table$robust_difference %||% FALSE), , drop = FALSE]
  }
  plots <- if (method_id == "lefse") {
    Filter(Negate(is.null), plots)
  } else if (method_id == "ancombc2" && identical(differential_method, "ancombc2")) {
    microbiome_ancombc2_plots(table, ancom_tables, counts, group, group_name,
      bundle$taxonomy, bundle$metadata, spec)
  } else if (method_id == "ancombc2") {
    microbiome_count_differential_plots(
      differential_method, table, count_differential_counts,
      count_differential_group, count_differential_normalized, spec)
  } else if (method_id %in% c("wilcoxon_kruskal", "anova_welch", "simper")) {
    Filter(Negate(is.null), list(differential_effect = microbiome_differential_effect_plot(table, method_id)))
  } else {
    Filter(Negate(is.null), list(
      volcano = microbiome_volcano_plot(table),
      coefficient_forest = microbiome_differential_forest_plot(table, method_id),
      differential_effect = microbiome_differential_effect_plot(table, method_id)
    ))
  }
  spec$group <- group_name
  spec$fdr_method <- spec$fdr_method %||% "BH"
  result_tables <- if (method_id == "ancombc2" &&
      identical(differential_method, "ancombc2")) {
    c(list(active_mode_results = table), ancom_tables)
  } else if (method_id == "ancombc2") {
    c(list(
      feature_results = table,
      significant_taxa = table[
        as.logical(table$differentially_abundant %||% FALSE), , drop = FALSE]
    ), count_differential_tables)
  } else {
    list(feature_results = table)
  }
  new_microbiome_result(method_id, marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle, aligned$orientation), analysis_spec = spec, actual_parameters = spec,
    package_versions = microbiome_package_versions(packages), execution_time = proc.time()[["elapsed"]] - started,
    model_objects = list(fit = model), tables = result_tables, feature_results = table, plots = plots,
    warnings = analysis_warnings, runtime_log = runtime_log,
    available_outputs = names(result_tables), available_plots = names(plots),
    generated_code = microbiome_differential_code(method_id, spec),
    registration_manifest = microbiome_registration_manifest(bundle, method_id, names(result_tables)))
}
