microbiome_aligned_environment <- function(bundle, variables = character()) {
  environment <- bundle$environment
  if (!nrow(environment)) stop("Environment variable tables are required for environment driven analysis.", call. = FALSE)
  ids <- rownames(environment)
  if ("SampleID" %in% names(environment)) ids <- as.character(environment$SampleID)
  index <- match(bundle$sample_ids, ids)
  if (anyNA(index)) stop("The environmental variable table cannot cover all microbial samples.", call. = FALSE)
  environment <- environment[index, , drop = FALSE]
  rownames(environment) <- bundle$sample_ids
  if (!length(variables)) variables <- names(environment)[vapply(environment, is.numeric, logical(1))]
  variables <- setdiff(variables, "SampleID")
  if (!length(variables) || !all(variables %in% names(environment))) stop("Please select a valid numeric environment variable.", call. = FALSE)
  invalid <- variables[!vapply(environment[variables], is.numeric, logical(1))]
  if (length(invalid)) stop("Environment constraint variables must be numeric:", paste(invalid, collapse = ", "), call. = FALSE)
  if (anyNA(environment[variables])) stop("Environment constraint variables cannot contain missing values.", call. = FALSE)
  environment[, variables, drop = FALSE]
}

microbiome_run_environment_spatial_legacy <- function(method_id, bundle, spec = list()) {
  if (!requireNamespace("vegan", quietly = TRUE)) stop("The vegan package is missing and the environment constraint method does not work.", call. = FALSE)
  started <- proc.time()[["elapsed"]]
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  variables <- spec$fixed_effects %||% character()
  covariates <- setdiff(spec$covariates %||% character(), variables)
  environment <- microbiome_aligned_environment(bundle, unique(c(variables, covariates)))
  if (!length(variables)) variables <- setdiff(names(environment), covariates)
  community <- microbiome_numeric_matrix(bundle$counts)
  permutations <- as.integer(spec$permutations %||% 999L)
  seed <- as.integer(spec$seed %||% 2026L)
  set.seed(seed)
  if (method_id == "mantel") {
    community_distance <- vegan::vegdist(community, method = spec$distance %||% "bray")
    environment_distance <- stats::dist(scale(environment))
    fit <- vegan::mantel(community_distance, environment_distance, permutations = permutations)
    tables <- list(mantel = data.frame(statistic = unname(fit$statistic), significance = fit$signif, permutations = fit$permutations))
    scores <- data.frame()
    plots <- list()
  } else if (method_id == "partial_mantel") {
    if (!length(covariates)) stop("Partial Mantel requires at least one control variable.", call. = FALSE)
    community_distance <- vegan::vegdist(community, method = spec$distance %||% "bray")
    predictor_distance <- stats::dist(scale(environment[, variables, drop = FALSE]))
    covariate_distance <- stats::dist(scale(environment[, covariates, drop = FALSE]))
    fit <- vegan::mantel.partial(community_distance, predictor_distance, covariate_distance, permutations = permutations)
    tables <- list(partial_mantel = data.frame(statistic = unname(fit$statistic), significance = fit$signif, permutations = fit$permutations))
    scores <- data.frame()
    plots <- list()
  } else if (method_id == "varpart") {
    groups <- spec$predictor_groups %||% list()
    if (length(groups) < 2L) {
      split <- split(variables, rep(seq_len(2L), length.out = length(variables)))
      groups <- split[lengths(split) > 0L]
    }
    if (length(groups) < 2L) stop("Variation partitioning requires at least two predictor groups.", call. = FALSE)
    predictors <- lapply(groups[seq_len(min(4L, length(groups)))], function(group) environment[, intersect(group, names(environment)), drop = FALSE])
    if (any(!lengths(predictors))) stop("There is an empty group in the predictor group.", call. = FALSE)
    response <- vegan::decostand(community, "hellinger")
    fit <- suppressWarnings(do.call(vegan::varpart, c(list(Y = response, X = predictors[[1]]), unname(predictors[-1]))))
    fractions <- as.data.frame(fit$part$indfract %||% fit$part$fract)
    tables <- list(variation_fractions = data.frame(fraction = rownames(fractions), fractions, row.names = NULL, check.names = FALSE))
    scores <- data.frame()
    plots <- list()
  } else if (method_id == "procrustes_environment") {
    community_fit <- stats::cmdscale(vegan::vegdist(community, method = spec$distance %||% "bray"), k = 2, add = TRUE)$points
    environment_fit <- stats::prcomp(scale(environment[, variables, drop = FALSE]))$x[, 1:2, drop = FALSE]
    fit <- vegan::protest(community_fit, environment_fit, permutations = permutations)
    scores <- data.frame(SampleID = rownames(community_fit), Community1 = community_fit[, 1], Community2 = community_fit[, 2],
      Environment1 = environment_fit[, 1], Environment2 = environment_fit[, 2], stringsAsFactors = FALSE)
    tables <- list(procrustes_test = data.frame(correlation = unname(fit$t0), p_value = fit$signif, permutations = permutations), scores = scores)
    plots <- list()
  } else if (method_id == "envfit") {
    ordination <- vegan::rda(vegan::decostand(community, "hellinger"))
    fit <- vegan::envfit(ordination, environment[, variables, drop = FALSE], permutations = permutations)
    vectors <- as.data.frame(vegan::scores(fit, display = "vectors"))
    vectors$Variable <- rownames(vectors)
    vectors$r_squared <- fit$vectors$r
    vectors$p_value <- fit$vectors$pvals
    tables <- list(environment_vectors = vectors)
    site <- vegan::scores(ordination, display = "sites", choices = 1:2)
    scores <- data.frame(SampleID = rownames(site), Axis1 = site[, 1], Axis2 = site[, 2])
    plots <- Filter(Negate(is.null), list(ordination = microbiome_ordination_plot(scores, "Environment fit")))
  } else {
    formula_text <- paste("community ~", paste(variables, collapse = " + "))
    if (method_id %in% c("partial_rda", "partial_cca") && length(covariates)) {
      formula_text <- paste(formula_text, "+ Condition(", paste(covariates, collapse = " + "), ")")
    }
    formula <- stats::as.formula(formula_text)
    fit <- switch(method_id,
      rda = vegan::rda(formula, data = environment),
      cca = vegan::cca(formula, data = environment),
      dbrda = vegan::capscale(formula, data = environment, distance = spec$distance %||% "bray"),
      partial_rda = vegan::rda(formula, data = environment),
      partial_cca = vegan::cca(formula, data = environment),
      constrained_term_tests = vegan::rda(formula, data = environment),
      stop("Environment space adapter does not support method:", method_id, call. = FALSE))
    overall <- vegan::anova.cca(fit, permutations = permutations)
    terms <- vegan::anova.cca(fit, by = "term", permutations = permutations)
    site <- vegan::scores(fit, display = "sites", choices = 1:2)
    scores <- data.frame(SampleID = rownames(site), Axis1 = site[, 1], Axis2 = site[, 2], stringsAsFactors = FALSE)
    constrained <- fit$CCA$tot.chi %||% 0
    total <- constrained + (fit$CA$tot.chi %||% 0)
    tables <- list(overall_test = data.frame(term = rownames(overall), overall, row.names = NULL, check.names = FALSE),
                   term_tests = data.frame(term = rownames(terms), terms, row.names = NULL, check.names = FALSE),
                   site_scores = scores,
                   model_summary = data.frame(constrained_inertia = constrained, total_inertia = total, explained_fraction = if (total > 0) constrained / total else NA_real_))
    plots <- Filter(Negate(is.null), list(ordination = microbiome_ordination_plot(scores, toupper(method_id))))
  }
  spec$fixed_effects <- variables
  spec$covariates <- covariates
  spec$permutations <- permutations
  new_microbiome_result(method_id, marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle, aligned$orientation), analysis_spec = spec, actual_parameters = spec,
    package_versions = microbiome_package_versions("vegan"), random_seed = seed, execution_time = proc.time()[["elapsed"]] - started,
    model_objects = list(fit = fit), tables = tables, ordination_scores = scores, plots = plots,
    available_outputs = names(tables), available_plots = names(plots), generated_code = microbiome_environment_code(method_id, spec),
    registration_manifest = microbiome_registration_manifest(bundle, method_id, names(tables)))
}

microbiome_environment_anova_table <- function(test) {
  table <- data.frame(Term = rownames(test), as.data.frame(test),
    row.names = NULL, check.names = FALSE, stringsAsFactors = FALSE)
  p_column <- grep("^Pr\\(", names(table), value = TRUE)
  table$PValue <- if (length(p_column)) as.numeric(table[[p_column[[1]]]]) else NA_real_
  table$Significance <- cut(table$PValue,
    breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
    labels = c("***", "**", "*", "ns"), right = FALSE)
  table
}

microbiome_environment_axis_matrix <- function(value) {
  value <- as.matrix(value)
  if (!nrow(value)) return(matrix(numeric(), 0, 2,
    dimnames = list(character(), c("Axis1", "Axis2"))))
  if (ncol(value) < 2L) value <- cbind(value, 0)
  value <- value[, 1:2, drop = FALSE]
  colnames(value) <- c("Axis1", "Axis2")
  value
}

microbiome_environment_group <- function(bundle, spec = list()) {
  group_name <- trimws(as.character(spec$group_variable %||% ""))
  if (!nzchar(group_name)) {
    return(list(name = "", values = NULL))
  }
  if (!group_name %in% names(bundle$metadata)) {
    stop("The selected grouping variable is not present in sample metadata: ",
      group_name, call. = FALSE)
  }
  values <- droplevels(factor(bundle$metadata[[group_name]]))
  if (anyNA(values) || nlevels(values) < 2L) {
    stop("The grouping variable must contain at least two non-missing levels.",
      call. = FALSE)
  }
  names(values) <- rownames(bundle$metadata)
  list(name = group_name, values = values)
}

microbiome_environment_attach_group <- function(scores, grouping) {
  if (!nzchar(grouping$name) || !nrow(scores)) return(scores)
  scores$Group <- grouping$values[match(scores$SampleID, names(grouping$values))]
  scores$Group <- droplevels(factor(scores$Group,
    levels = levels(grouping$values)))
  scores
}

microbiome_environment_ordination_plot <- function(site_scores, environment_vectors,
    species_scores = data.frame(), title = "Community-environment ordination",
    axis_labels = c("Axis 1", "Axis 2"), arrow_multiplier = 1) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) return(NULL)
  grouped <- "Group" %in% names(site_scores) &&
    length(unique(stats::na.omit(site_scores$Group))) > 1L
  point_layer <- if (grouped) {
    ggplot2::geom_point(ggplot2::aes(fill = Group, colour = Group),
      shape = 21, size = 2.9, stroke = 0.55, alpha = 0.88)
  } else {
    ggplot2::geom_point(shape = 21, size = 2.7, stroke = 0.45,
      fill = "#5AA6A6", colour = "#174A56", alpha = 0.82)
  }
  plot <- ggplot2::ggplot(site_scores, ggplot2::aes(Axis1, Axis2)) +
    ggplot2::geom_hline(yintercept = 0, colour = "#D7DDE2", linewidth = 0.35) +
    ggplot2::geom_vline(xintercept = 0, colour = "#D7DDE2", linewidth = 0.35) +
    point_layer
  if (grouped && all(table(site_scores$Group) >= 3L)) {
    plot <- plot + ggplot2::stat_ellipse(ggplot2::aes(colour = Group),
      linewidth = 0.65, linetype = 2, level = 0.95, show.legend = FALSE)
  }
  if (nrow(species_scores)) {
    plot <- plot +
      ggplot2::geom_segment(data = species_scores,
        ggplot2::aes(x = 0, y = 0, xend = Axis1, yend = Axis2),
        inherit.aes = FALSE, colour = "#8B9298", linewidth = 0.35,
        arrow = grid::arrow(length = grid::unit(0.09, "inches"))) +
      ggplot2::geom_text(data = species_scores,
        ggplot2::aes(Axis1, Axis2, label = Taxon), inherit.aes = FALSE,
        colour = "#5E646A", size = 3, check_overlap = TRUE)
  }
  if (nrow(environment_vectors)) {
    vectors <- environment_vectors
    vectors$Axis1 <- vectors$Axis1 * arrow_multiplier
    vectors$Axis2 <- vectors$Axis2 * arrow_multiplier
    plot <- plot +
      ggplot2::geom_segment(data = vectors,
        ggplot2::aes(x = 0, y = 0, xend = Axis1, yend = Axis2),
        inherit.aes = FALSE, colour = "#C33C54", linewidth = 0.75,
        arrow = grid::arrow(length = grid::unit(0.12, "inches"))) +
      ggplot2::geom_text(data = vectors,
        ggplot2::aes(Axis1, Axis2, label = Variable), inherit.aes = FALSE,
        colour = "#9A243A", fontface = "bold", size = 3.4,
        check_overlap = TRUE)
  }
  plot +
    ggplot2::labs(title = title, x = axis_labels[[1]], y = axis_labels[[2]],
      fill = if (grouped) "Group" else NULL,
      colour = if (grouped) "Group" else NULL) +
    ggplot2::coord_equal() +
    ggplot2::theme_bw(base_size = 12) +
    ggplot2::theme(panel.grid.minor = ggplot2::element_blank(),
      plot.title = ggplot2::element_text(face = "bold"))
}

microbiome_environment_significance_plot <- function(table,
    title = "Environmental-variable significance") {
  if (!requireNamespace("ggplot2", quietly = TRUE) || !nrow(table)) return(NULL)
  table <- table[is.finite(table$PValue), , drop = FALSE]
  if (!nrow(table)) return(NULL)
  table$Term <- factor(table$Term, levels = rev(table$Term))
  ggplot2::ggplot(table,
      ggplot2::aes(Term, -log10(pmax(PValue, .Machine$double.xmin)),
        fill = PValue < 0.05)) +
    ggplot2::geom_col(width = 0.68, colour = "#2D3439", linewidth = 0.25) +
    ggplot2::geom_hline(yintercept = -log10(0.05), linetype = 2,
      colour = "#B4384B") +
    ggplot2::coord_flip() +
    ggplot2::scale_fill_manual(values = c("FALSE" = "#B9C2C9", "TRUE" = "#2A9D8F"),
      guide = "none") +
    ggplot2::labs(title = title, x = NULL, y = expression(-log[10](italic(P)))) +
    ggplot2::theme_classic(base_size = 12)
}

microbiome_environment_hp_plots <- function(table) {
  if (!requireNamespace("ggplot2", quietly = TRUE) || !nrow(table)) {
    return(list(hierarchical_partition = NULL, variation_partition = NULL))
  }
  ordered <- table[order(table$Percentage), , drop = FALSE]
  ordered$Environment <- factor(ordered$Environment, levels = ordered$Environment)
  importance <- ggplot2::ggplot(ordered,
      ggplot2::aes(Environment, Percentage, fill = Percentage)) +
    ggplot2::geom_col(width = 0.7, colour = "#24333B", linewidth = 0.3) +
    ggplot2::geom_text(ggplot2::aes(label = sprintf("%.1f%%", Percentage)),
      hjust = -0.08, size = 3.2) +
    ggplot2::coord_flip(clip = "off") +
    ggplot2::scale_fill_gradient(low = "#A9D6C8", high = "#157A6E", guide = "none") +
    ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0, 0.16))) +
    ggplot2::labs(title = "Hierarchical partitioning",
      x = NULL, y = "Independent contribution (%)") +
    ggplot2::theme_classic(base_size = 12)
  components <- rbind(
    data.frame(Environment = table$Environment, Component = "Unique",
      Contribution = table$Unique),
    data.frame(Environment = table$Environment, Component = "Average shared",
      Contribution = table$AverageShared)
  )
  components$Environment <- factor(components$Environment,
    levels = table$Environment[order(table$Individual)])
  partition <- ggplot2::ggplot(components,
      ggplot2::aes(Environment, Contribution, fill = Component)) +
    ggplot2::geom_col(position = "dodge", width = 0.68,
      colour = "#26343B", linewidth = 0.25) +
    ggplot2::coord_flip() +
    ggplot2::scale_fill_manual(values = c("Unique" = "#3A86A8",
      "Average shared" = "#F2A65A")) +
    ggplot2::labs(title = "Unique and shared explained variation",
      x = NULL, y = "Explained variation", fill = NULL) +
    ggplot2::theme_classic(base_size = 12)
  list(hierarchical_partition = importance, variation_partition = partition)
}

microbiome_run_environment_spatial <- function(method_id, bundle, spec = list()) {
  supported <- c("rda", "cca", "dbrda", "envfit", "mantel")
  if (!method_id %in% supported) {
    return(microbiome_run_environment_spatial_legacy(method_id, bundle, spec))
  }
  if (!requireNamespace("vegan", quietly = TRUE)) {
    stop("The vegan package is required for community-environment analysis.", call. = FALSE)
  }
  started <- proc.time()[["elapsed"]]
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  grouping <- microbiome_environment_group(bundle, spec)
  group_variable <- grouping$name
  variables <- unique(as.character(spec$fixed_effects %||% character()))
  environment <- microbiome_aligned_environment(bundle, variables)
  if (!length(variables)) variables <- names(environment)
  community <- microbiome_numeric_matrix(bundle$counts)
  permutations <- as.integer(spec$permutations %||% 999L)
  seed <- as.integer(spec$seed %||% 2026L)
  distance_method <- spec$distance_method %||% spec$distance %||% "bray"
  requested_plots <- as.character(spec$plot_types %||%
    unname(microbiome_community_environment_plot_choices(method_id)))
  warnings <- character()
  scores <- data.frame()
  plots <- list()
  tables <- list()
  model_objects <- list()
  packages <- "vegan"
  set.seed(seed)

  if (method_id == "mantel") {
    environment_distance_method <- spec$environment_distance_method %||% "euclidean"
    correlation_method <- spec$mantel_correlation %||% "pearson"
    community_distance <- vegan::vegdist(community, method = distance_method)
    environment_distance <- stats::dist(scale(environment),
      method = environment_distance_method)
    fit <- vegan::mantel(community_distance, environment_distance,
      method = correlation_method, permutations = permutations)
    variable_tests <- do.call(rbind, lapply(variables, function(variable) {
      test <- vegan::mantel(community_distance,
        stats::dist(scale(environment[, variable, drop = FALSE]),
          method = environment_distance_method),
        method = correlation_method, permutations = permutations)
      data.frame(Environment = variable, MantelR = unname(test$statistic),
        PValue = test$signif, Permutations = test$permutations)
    }))
    variable_tests$Significance <- cut(variable_tests$PValue,
      breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
      labels = c("***", "**", "*", "ns"), right = FALSE)
    overall <- data.frame(Test = "Overall environmental matrix",
      MantelR = unname(fit$statistic), PValue = fit$signif,
      Permutations = fit$permutations,
      CommunityDistance = distance_method,
      EnvironmentalDistance = environment_distance_method,
      Correlation = correlation_method)
    overall$Group <- "All samples"
    variable_tests$Group <- "All samples"
    group_fits <- list()
    if (nzchar(group_variable)) {
      grouped_results <- lapply(levels(grouping$values), function(level) {
        keep <- grouping$values == level
        if (sum(keep) < 4L) {
          warnings <<- c(warnings, paste0("Mantel test skipped for group '", level,
            "': at least four samples are required."))
          return(NULL)
        }
        group_community_distance <- vegan::vegdist(community[keep, , drop = FALSE],
          method = distance_method)
        group_environment <- environment[keep, , drop = FALSE]
        group_environment_distance <- stats::dist(scale(group_environment),
          method = environment_distance_method)
        group_fit <- vegan::mantel(group_community_distance,
          group_environment_distance, method = correlation_method,
          permutations = permutations)
        group_fits[[level]] <<- group_fit
        group_variables <- do.call(rbind, lapply(variables, function(variable) {
          test <- vegan::mantel(group_community_distance,
            stats::dist(scale(group_environment[, variable, drop = FALSE]),
              method = environment_distance_method),
            method = correlation_method, permutations = permutations)
          data.frame(Environment = variable, MantelR = unname(test$statistic),
            PValue = test$signif, Permutations = test$permutations,
            Group = level, stringsAsFactors = FALSE)
        }))
        group_variables$Significance <- cut(group_variables$PValue,
          breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
          labels = c("***", "**", "*", "ns"), right = FALSE)
        list(
          overall = data.frame(Test = paste("Group", level),
            MantelR = unname(group_fit$statistic), PValue = group_fit$signif,
            Permutations = group_fit$permutations,
            CommunityDistance = distance_method,
            EnvironmentalDistance = environment_distance_method,
            Correlation = correlation_method, Group = level,
            stringsAsFactors = FALSE),
          variables = group_variables)
      })
      grouped_results <- Filter(Negate(is.null), grouped_results)
      if (length(grouped_results)) {
        overall <- rbind(overall,
          do.call(rbind, lapply(grouped_results, `[[`, "overall")))
        variable_tests <- rbind(variable_tests,
          do.call(rbind, lapply(grouped_results, `[[`, "variables")))
      }
    }
    overview_mapping <- if (nzchar(group_variable)) {
      ggplot2::aes(Test, MantelR, fill = Group)
    } else {
      ggplot2::aes(Test, MantelR, fill = PValue < 0.05)
    }
    overview_plot <- ggplot2::ggplot(overall, overview_mapping) +
      ggplot2::geom_col(width = 0.62, colour = "#26343B") +
      ggplot2::geom_text(ggplot2::aes(label = sprintf("r = %.3f; P = %.4f",
        MantelR, PValue)), vjust = ifelse(overall$MantelR >= 0, -0.45, 1.35),
        size = 3.2) +
      ggplot2::labs(title = "Mantel test", x = NULL, y = "Mantel correlation",
        fill = if (nzchar(group_variable)) group_variable else NULL) +
      ggplot2::theme_classic(base_size = 12)
    if (!nzchar(group_variable)) {
      overview_plot <- overview_plot + ggplot2::scale_fill_manual(
        values = c("FALSE" = "#B8C2C8", "TRUE" = "#2A9D8F"), guide = "none")
    }
    variable_mapping <- if (nzchar(group_variable)) {
      ggplot2::aes(stats::reorder(Environment, MantelR), MantelR, fill = Group)
    } else {
      ggplot2::aes(stats::reorder(Environment, MantelR), MantelR,
        fill = PValue < 0.05)
    }
    variable_position <- if (nzchar(group_variable)) {
      ggplot2::position_dodge(width = 0.76)
    } else "stack"
    variable_plot <- ggplot2::ggplot(variable_tests, variable_mapping) +
      ggplot2::geom_col(width = 0.68, colour = "#26343B",
        position = variable_position) +
      ggplot2::geom_text(ggplot2::aes(label = Significance),
        hjust = ifelse(variable_tests$MantelR >= 0, -0.25, 1.25), fontface = "bold",
        position = variable_position) +
      ggplot2::coord_flip(clip = "off") +
      ggplot2::labs(title = "Variable-wise Mantel tests",
        x = NULL, y = "Mantel correlation",
        fill = if (nzchar(group_variable)) group_variable else NULL) +
      ggplot2::theme_classic(base_size = 12)
    if (!nzchar(group_variable)) {
      variable_plot <- variable_plot + ggplot2::scale_fill_manual(
        values = c("FALSE" = "#B8C2C8", "TRUE" = "#3A86A8"), guide = "none")
    }
    tables <- list(overall_mantel_test = overall,
      environmental_variable_tests = variable_tests)
    plots <- list(mantel_overview = overview_plot, mantel_variables = variable_plot)
    model_objects <- list(fit = fit, group_fits = group_fits)
  } else if (method_id == "envfit") {
    community_distance <- vegan::vegdist(community, method = distance_method)
    ordination <- stats::cmdscale(community_distance, k = 2, eig = TRUE, add = TRUE)
    points <- microbiome_environment_axis_matrix(ordination$points)
    rownames(points) <- rownames(ordination$points)
    model_environment <- environment
    if (nzchar(group_variable)) {
      model_environment[[group_variable]] <- grouping$values
    }
    fit <- vegan::envfit(points, model_environment, permutations = permutations)
    vectors <- microbiome_environment_axis_matrix(
      vegan::scores(fit, display = "vectors"))
    vector_table <- data.frame(Variable = rownames(vectors),
      Axis1 = vectors[, 1], Axis2 = vectors[, 2],
      RSquared = as.numeric(fit$vectors$r),
      PValue = as.numeric(fit$vectors$pvals), row.names = NULL)
    vector_table$Significance <- cut(vector_table$PValue,
      breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
      labels = c("***", "**", "*", "ns"), right = FALSE)
    scores <- data.frame(SampleID = rownames(points),
      Axis1 = points[, 1], Axis2 = points[, 2], row.names = NULL)
    scores <- microbiome_environment_attach_group(scores, grouping)
    group_test <- data.frame()
    if (nzchar(group_variable) && !is.null(fit$factors)) {
      group_test <- data.frame(Variable = group_variable,
        RSquared = as.numeric(fit$factors$r),
        PValue = as.numeric(fit$factors$pvals), row.names = NULL)
      group_test$Significance <- cut(group_test$PValue,
        breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
        labels = c("***", "**", "*", "ns"), right = FALSE)
    }
    eigenvalues <- ordination$eig
    positive <- eigenvalues[eigenvalues > 0]
    axis_percent <- rep(NA_real_, 2L)
    axis_percent[seq_len(min(2L, length(positive)))] <-
      100 * utils::head(positive, 2L) / sum(positive)
    shown_vectors <- vector_table[
      vector_table$PValue <= as.numeric(spec$envfit_alpha %||% 0.05), ,
      drop = FALSE]
    ordination_plot <- microbiome_environment_ordination_plot(
      scores, shown_vectors, title = "PCoA with environmental vectors",
      axis_labels = sprintf("PCoA%d (%.1f%%)", 1:2, axis_percent),
      arrow_multiplier = as.numeric(spec$ordination_arrow_multiplier %||% 1))
    significance_table <- rbind(
      transform(vector_table, Term = Variable)[, c("Term", "PValue")],
      if (nrow(group_test)) transform(group_test, Term = Variable)[, c("Term", "PValue")]
      else data.frame(Term = character(), PValue = numeric()))
    significance_plot <- microbiome_environment_significance_plot(
      significance_table, "envfit variable and group significance")
    tables <- list(environment_vector_tests = vector_table, site_scores = scores,
      pcoa_eigenvalues = data.frame(Axis = seq_along(eigenvalues),
        Eigenvalue = eigenvalues))
    if (nrow(group_test)) tables$group_factor_test <- group_test
    plots <- list(pcoa_envfit = ordination_plot,
      envfit_significance = significance_plot)
    model_objects <- list(ordination = ordination, fit = fit)
  } else {
    if (!requireNamespace("rdacca.hp", quietly = TRUE)) {
      stop("The rdacca.hp package is required for hierarchical partitioning.",
        call. = FALSE)
    }
    packages <- c("vegan", "rdacca.hp")
    response <- if (method_id == "rda" &&
        !identical(bundle$transform %||% "", "hellinger")) {
      vegan::decostand(community, "hellinger")
    } else community
    model_environment <- environment
    model_terms <- variables
    if (nzchar(group_variable)) {
      model_environment[[group_variable]] <- grouping$values
      model_terms <- c(group_variable, model_terms)
    }
    formula <- stats::reformulate(model_terms, response = "response")
    fit <- switch(method_id,
      rda = vegan::rda(formula, data = model_environment),
      cca = vegan::cca(formula, data = model_environment),
      dbrda = vegan::dbrda(formula, data = model_environment, distance = distance_method))
    overall_test <- microbiome_environment_anova_table(
      vegan::anova.cca(fit, permutations = permutations))
    term_tests <- microbiome_environment_anova_table(
      vegan::anova.cca(fit, by = "term", permutations = permutations))
    scaling <- as.integer(spec$ordination_scaling %||% 2L)
    site_matrix <- microbiome_environment_axis_matrix(
      vegan::scores(fit, display = "sites", choices = 1:2, scaling = scaling))
    environment_matrix <- microbiome_environment_axis_matrix(
      vegan::scores(fit, display = "bp", choices = 1:2, scaling = scaling))
    species_matrix <- tryCatch(microbiome_environment_axis_matrix(
      vegan::scores(fit, display = "species", choices = 1:2, scaling = scaling)),
      error = function(error) matrix(numeric(), 0, 2))
    scores <- data.frame(SampleID = rownames(site_matrix),
      Axis1 = site_matrix[, 1], Axis2 = site_matrix[, 2], row.names = NULL)
    scores <- microbiome_environment_attach_group(scores, grouping)
    environment_vectors <- data.frame(Variable = rownames(environment_matrix),
      Axis1 = environment_matrix[, 1], Axis2 = environment_matrix[, 2],
      row.names = NULL)
    environment_vectors <- environment_vectors[
      environment_vectors$Variable %in% variables, , drop = FALSE]
    species_scores <- data.frame()
    if (nrow(species_matrix) && as.integer(spec$ordination_top_species %||% 12L) > 0L) {
      magnitude <- rowSums(species_matrix^2)
      keep <- utils::head(order(magnitude, decreasing = TRUE),
        as.integer(spec$ordination_top_species %||% 12L))
      species_scores <- data.frame(Taxon = rownames(species_matrix)[keep],
        Axis1 = species_matrix[keep, 1], Axis2 = species_matrix[keep, 2],
        row.names = NULL)
    }
    constrained <- fit$CCA$tot.chi %||% 0
    total <- constrained + (fit$CA$tot.chi %||% 0)
    adjusted <- tryCatch(vegan::RsquareAdj(fit),
      error = function(error) list(r.squared = if (total > 0) constrained / total else NA_real_,
        adj.r.squared = NA_real_))
    hp_warnings <- character()
    hp_response <- if (method_id == "dbrda") {
      vegan::vegdist(response, method = distance_method)
    } else response
    hp_fit <- withCallingHandlers(
      rdacca.hp::rdacca.hp(hp_response, environment,
        method = switch(method_id, rda = "RDA", cca = "CCA", dbrda = "dbRDA"),
        type = spec$hierarchical_partition_type %||% "adjR2",
        dbrdatype = "dbrda",
        n.perm = as.integer(spec$hierarchical_partition_permutations %||% permutations)),
      warning = function(condition) {
        hp_warnings <<- c(hp_warnings, conditionMessage(condition))
        invokeRestart("muffleWarning")
      })
    hp <- as.data.frame(hp_fit$Hier.part, check.names = FALSE)
    hp_table <- data.frame(Environment = rownames(hp),
      Unique = as.numeric(hp[, "Unique"]),
      AverageShared = as.numeric(hp[, "Average.share"]),
      Individual = as.numeric(hp[, "Individual"]),
      Percentage = as.numeric(hp[, "I.perc(%)"]), row.names = NULL)
    ordination_plot <- microbiome_environment_ordination_plot(
      scores, environment_vectors, species_scores,
      title = switch(method_id, rda = "RDA biplot", cca = "CCA triplot",
        dbrda = "db-RDA biplot"),
      arrow_multiplier = as.numeric(spec$ordination_arrow_multiplier %||% 1))
    significance_plot <- microbiome_environment_significance_plot(
      term_tests, "Environmental-term significance")
    hp_plots <- microbiome_environment_hp_plots(hp_table)
    tables <- list(overall_test = overall_test,
      environmental_variable_tests = term_tests,
      model_summary = data.frame(R2 = adjusted$r.squared %||% NA_real_,
        AdjustedR2 = adjusted$adj.r.squared %||% NA_real_,
        ConstrainedInertia = constrained, TotalInertia = total,
        ExplainedFraction = if (total > 0) constrained / total else NA_real_),
      site_scores = scores, environment_vectors = environment_vectors,
      hierarchical_partitioning = hp_table)
    plots <- c(list(ordination_biplot = ordination_plot,
      term_significance = significance_plot), hp_plots)
    warnings <- unique(hp_warnings)
    model_objects <- list(fit = fit, hierarchical_partition = hp_fit)
  }

  plots <- Filter(Negate(is.null), plots)
  requested <- intersect(requested_plots, names(plots))
  if (length(requested)) plots <- plots[requested]
  spec$fixed_effects <- variables
  spec$group_variable <- group_variable
  spec$covariates <- character()
  spec$permutations <- permutations
  spec$distance_method <- distance_method
  new_microbiome_result(method_id, marker_type = bundle$marker_type,
    data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle, aligned$orientation),
    analysis_spec = spec, actual_parameters = spec,
    package_versions = microbiome_package_versions(packages),
    random_seed = seed, execution_time = proc.time()[["elapsed"]] - started,
    model_objects = model_objects, tables = tables, ordination_scores = scores,
    plots = plots, warnings = warnings,
    available_outputs = names(tables), available_plots = names(plots),
    generated_code = microbiome_environment_code(method_id, spec),
    registration_manifest = microbiome_registration_manifest(
      bundle, method_id, names(tables)))
}
