microbiome_network_engine_choices <- function() c(
  "ggClusterNet2" = "ggclusternet2",
  "NetCoMi" = "netcomi")

microbiome_ggclusternet_measure_choices <- function() c(
  "Spearman correlation" = "spearman",
  "Pearson correlation" = "pearson",
  "Kendall correlation" = "kendall",
  "SparCC" = "sparcc")

microbiome_ggclusternet_plot_choices <- function(
    grouped = FALSE, cross_domain = FALSE) {
  network_name <- if (cross_domain) {
    "Bacteria-fungi cross-domain network"
  } else if (grouped) {
    "Grouped networks with a shared ggClusterNet2 layout"
  } else {
    "Overall ggClusterNet2 network"
  }
  choices <- c(
    network_name = if (cross_domain) "cross_domain_network" else
      if (grouped) "grouped_network" else "overall_network",
    "Curved-edge network" = "ggcluster_curved_network",
    "Module-coloured network" = "ggcluster_module_network",
    "Zi-Pi node roles" = "zipi_roles",
    "Degree distribution" = "centrality_distribution",
    "Module composition" = "module_composition",
    "Network properties" = "network_properties",
    "Cohesion by sample [meconetcomp]" = "cohesion",
    "Network robustness decay [meconetcomp; slow]" = "robustness",
    "Node vulnerability [meconetcomp; slow]" = "node_vulnerability",
    "Robustness and vulnerability summary [meconetcomp; slow]" =
      "stability_summary")
  names(choices)[[1]] <- network_name
  if (cross_domain) {
    choices <- c(
      choices,
      "Within-domain and cross-domain edge composition" =
        "domain_edge_composition",
      "Cross-domain association heatmap" = "cross_domain_heatmap",
      "Node centrality by microbial domain" = "domain_centrality")
  }
  choices
}

microbiome_ggclusternet_default_plot_types <- function(
    grouped = FALSE, cross_domain = FALSE) {
  if (cross_domain) {
    "cross_domain_network"
  } else if (isTRUE(grouped)) {
    "grouped_network"
  } else {
    "overall_network"
  }
}

microbiome_ggclusternet_analysis_requirements <- function(plot_types) {
  plot_types <- unique(as.character(plot_types %||% character()))
  list(
    cohesion = "cohesion" %in% plot_types,
    robustness = any(
      c("robustness", "stability_summary") %in% plot_types),
    vulnerability = any(
      c("node_vulnerability", "stability_summary") %in% plot_types))
}

microbiome_ggclusternet_default_cores <- function() {
  dava_available_cores(logical = TRUE, reserve = 1L)
}

microbiome_ggclusternet_advanced_field_ids <- function(
    cross_domain = FALSE) {
  ids <- c(
    "ggcluster_scale", "ggcluster_min_prevalence",
    "ggcluster_max_features", "ggcluster_sparcc_repetitions",
    "ggcluster_cluster_method", "ggcluster_layout",
    "ggcluster_top_modules", "ggcluster_hub_quantile",
    "ggcluster_robustness_strategy", "ggcluster_robustness_runs",
    "ggcluster_robustness_step", "ggcluster_robustness_max_ratio",
    "ggcluster_robustness_measure",
    "ggcluster_seed", "ggcluster_cores")
  if (cross_domain) {
    c("ggcluster_cross_scale", "ggcluster_max_features_per_domain", ids)
  } else {
    ids
  }
}

microbiome_ggclusternet_advanced_ui <- function(
    ns, current = list(), cross_domain = FALSE) {
  block <- function(title, package_function, ...) {
    shiny::div(
      class = "border rounded p-2 mb-2",
      shiny::div(
        class = "d-flex justify-content-between align-items-center mb-2",
        shiny::tags$strong(title),
        shiny::span(class = "badge text-bg-light", package_function)),
      ...)
  }
  shiny::tagList(
    shiny::tags$style(
      ".ggcluster-advanced .form-group{margin-bottom:.45rem}.ggcluster-advanced .row{--bs-gutter-x:.65rem}"),
    shiny::div(
      class = "ggcluster-advanced",
      if (cross_domain) {
        block(
          "Cross-domain merge", "ggClusterNet::merge16S_ITS",
          shiny::fluidRow(
            shiny::column(
              6,
              shiny::checkboxInput(
                ns("ggcluster_cross_scale"),
                "Domain relative abundance normalization",
                isTRUE(current$ggcluster_cross_scale %||% TRUE))),
            shiny::column(
              6,
              shiny::numericInput(
                ns("ggcluster_max_features_per_domain"),
                "Maximum number of taxa per domain",
                as.integer(
                  current$ggcluster_max_features_per_domain %||% 30L),
                min = 3L, step = 5L))))
      },
      block(
        "Taxon filtering and correlation inference", "ggClusterNet::corMicro",
        shiny::fluidRow(
          shiny::column(
            6,
            shiny::selectInput(
              ns("ggcluster_scale"), "method.scale",
              c("Relative abundance" = "rela", "None" = "none"),
              selected = current$ggcluster_scale %||% "rela")),
          shiny::column(
            6,
            shiny::sliderInput(
              ns("ggcluster_min_prevalence"), "Minimum detection rate",
              0, 1,
              as.numeric(current$ggcluster_min_prevalence %||% 0.1),
              0.01))),
        shiny::fluidRow(
          shiny::column(
            6,
            shiny::numericInput(
              ns("ggcluster_max_features"), "Maximum number of taxa",
              as.integer(current$ggcluster_max_features %||% 60L),
              min = 5L, step = 5L)),
          shiny::column(
            6,
            shiny::numericInput(
              ns("ggcluster_sparcc_repetitions"), "SparCC resampling times R",
              as.integer(
                current$ggcluster_sparcc_repetitions %||% 100L),
              min = 10L, step = 10L)))),
      block(
        "Modules, layouts and node roles",
        "ggClusterNet::model_Gephi.2 / model_igraph / ZiPiPlot",
        shiny::fluidRow(
          shiny::column(
            6,
            shiny::selectInput(
              ns("ggcluster_cluster_method"), "Module identification method",
              c(
                "Fast greedy" = "cluster_fast_greedy",
                "Walktrap" = "cluster_walktrap",
                "Edge betweenness" = "cluster_edge_betweenness",
                "Spinglass" = "cluster_spinglass"),
              selected = current$ggcluster_cluster_method %||%
                "cluster_fast_greedy")),
          shiny::column(
            6,
            shiny::selectInput(
              ns("ggcluster_layout"), "ggClusterNet2 layout",
              c(
                "Module FR layout" = "module_fr",
                "Gephi concentric layout" = "gephi_concentric"),
              selected = current$ggcluster_layout %||% "module_fr"))),
        shiny::fluidRow(
          shiny::column(
            6,
            shiny::numericInput(
              ns("ggcluster_top_modules"), "Shading module cap",
              as.integer(current$ggcluster_top_modules %||% 20L),
              min = 2L, max = 100L)),
          shiny::column(
            6,
            shiny::sliderInput(
              ns("ggcluster_hub_quantile"), "Hub Degree Quantile",
              0.5, 0.99,
              as.numeric(current$ggcluster_hub_quantile %||% 0.95),
              0.01)))),
      block(
        "Cohesion, network robustness and node vulnerability",
        "microeco::trans_network + meconetcomp",
        shiny::selectizeInput(
          ns("ggcluster_robustness_strategy"), "remove_strategy",
          c(
            "Random node removal" = "node_rand",
            "High-degree-first removal" = "node_degree_high",
            "Low-degree-first removal" = "node_degree_low",
            "Random edge removal" = "edge_rand",
            "Strong-edge-first removal" = "edge_strong",
            "Weak-edge-first removal" = "edge_weak"),
          selected = current$ggcluster_robustness_strategy %||%
            c("node_rand", "node_degree_high"),
          multiple = TRUE,
          options = list(plugins = list("remove_button"))),
        shiny::fluidRow(
          shiny::column(
            6,
            shiny::numericInput(
              ns("ggcluster_robustness_runs"), "Simulation runs",
              as.integer(current$ggcluster_robustness_runs %||% 20L),
              min = 5L, step = 5L)),
          shiny::column(
            6,
            shiny::selectInput(
              ns("ggcluster_robustness_measure"), "Stability measure",
              c(
                "Network efficiency" = "Eff",
                "Largest eigenvalue" = "Eigen",
                "Natural connectivity" = "Pcr"),
              selected = current$ggcluster_robustness_measure %||% "Eff"))),
        shiny::fluidRow(
          shiny::column(
            6,
            shiny::sliderInput(
              ns("ggcluster_robustness_step"), "Removal-ratio step",
              0.05, 0.25,
              as.numeric(current$ggcluster_robustness_step %||% 0.1),
              0.05)),
          shiny::column(
            6,
            shiny::sliderInput(
              ns("ggcluster_robustness_max_ratio"),
              "Maximum removal ratio",
              0.5, 0.95,
              as.numeric(
                current$ggcluster_robustness_max_ratio %||% 0.9),
              0.05))),
        shiny::div(
          class = "form-text",
          paste(
            "Cohesion uses signed association coefficients.",
            "Robustness and vulnerability use",
            "diss = sqrt(0.5 * (1 - r)) as edge distance."))),
      block(
        "Reproducibility and parallelism", "ggClusterNet::corMicro",
        shiny::fluidRow(
          shiny::column(
            6,
            shiny::numericInput(
              ns("ggcluster_seed"), "Random seed",
              as.integer(current$ggcluster_seed %||% 2026L), min = 1L)),
          shiny::column(
            6,
            shiny::numericInput(
              ns("ggcluster_cores"), "SparCC CPU thread",
              as.integer(current$ggcluster_cores %||%
                microbiome_ggclusternet_default_cores()),
              min = 1L, max = dava_available_cores(logical = TRUE)))))))
}

microbiome_ggclusternet_analysis_expression <- function(
    spec = list(), cross_domain = FALSE) {
  grouped <- isTRUE(spec$group_network %||% spec$grouped)
  measure <- spec$network_measure %||% "spearman"
  stability <- microbiome_ggclusternet_analysis_requirements(
    spec$plot_types %||% character())
  rank_text <- if (cross_domain) {
    paste0(
      "16S[", spec$bacteria_taxonomic_rank %||% "Genus", "] + ITS[",
      spec$fungi_taxonomic_rank %||% "Genus", "]")
  } else {
    paste0("community[", spec$taxonomic_rank %||% "Genus", "]")
  }
  paste0(
    if (cross_domain) {
      paste0(
        "ps_joint <- ggClusterNet::merge16S_ITS(ps16s, psITS, ",
        "scale = ", if (isTRUE(spec$ggcluster_cross_scale %||% TRUE)) {
          "TRUE"
        } else {
          "FALSE"
        }, ")\n")
    } else {
      ""
    },
    "fit <- ggClusterNet::corMicro(", rank_text,
    if (cross_domain) " -> ps_joint" else " -> phyloseq",
    ", method = '", measure,
    "', r.threshold = ",
    format(as.numeric(spec$network_threshold %||% 0.3)),
    ", p.threshold = ",
    format(as.numeric(spec$network_fdr %||% 0.05)),
    ", method.scale = '", spec$ggcluster_scale %||% "rela", "')",
    if (grouped) {
      paste0(
        "\nThe same ggClusterNet2 workflow is fitted independently by ",
        spec$group %||% "", ".")
    } else {
      ""
    },
    "\nlayout <- ggClusterNet::",
    if (identical(spec$ggcluster_layout %||% "module_fr",
        "gephi_concentric")) {
      "model_Gephi.2"
    } else {
      "model_igraph"
    },
    "(fit[[1]], method = '",
    spec$ggcluster_cluster_method %||% "cluster_fast_greedy", "')",
    "\nroles <- ggClusterNet::ZiPiPlot(graph, method = '",
    spec$ggcluster_cluster_method %||% "cluster_fast_greedy", "')",
    if (any(unlist(stability, use.names = FALSE))) {
      paste0(
        "\nassoMat <- signed ggClusterNet association matrix",
        "\ndiss <- sqrt(0.5 * (1 - assoMat))",
        "\ntn <- microeco::trans_network with signed edge table ",
        "and dissimilarity-weighted igraph",
        if (isTRUE(stability$cohesion)) {
          "\ncohesion <- meconetcomp::cohesionclass$new(tn_list)"
        } else {
          ""
        },
        if (isTRUE(stability$robustness)) {
          "\nrobustness <- meconetcomp::robustness$new(tn_list)"
        } else {
          ""
        },
        if (isTRUE(stability$vulnerability)) {
          "\nnode_vulnerability <- meconetcomp::vulnerability(tn_list)"
        } else {
          ""
        })
    } else {
      ""
    })
}

microbiome_ggclusternet_aggregate <- function(bundle, spec = list()) {
  rank <- spec$taxonomic_rank %||% "Genus"
  aggregated <- microbiome_species_environment_aggregate(bundle, rank)
  counts <- as.matrix(aggregated$counts)
  prevalence_threshold <- as.numeric(
    spec$minimum_prevalence %||%
      spec$ggcluster_min_prevalence %||% 0.1)
  maximum <- max(
    5L,
    as.integer(
      spec$maximum_features %||%
        spec$ggcluster_max_features %||% 60L))
  prevalence <- colMeans(counts > 0)
  candidates <- which(prevalence >= prevalence_threshold)
  if (length(candidates)) {
    relative <- counts / pmax(rowSums(counts), 1)
    candidates <- candidates[
      order(colMeans(relative[, candidates, drop = FALSE]),
        decreasing = TRUE)]
  }
  keep <- utils::head(candidates, maximum)
  if (length(keep) < 5L) {
    stop(
      "ggClusterNet2 requires at least five taxa after prevalence filtering.",
      call. = FALSE)
  }
  aggregated$counts <- counts[, keep, drop = FALSE]
  selected <- colnames(aggregated$counts)
  mapping <- as.data.frame(aggregated$mapping, check.names = FALSE)
  if ("Taxon" %in% names(mapping)) {
    mapping <- mapping[match(selected, mapping$Taxon), , drop = FALSE]
  } else {
    mapping$Taxon <- selected
  }
  rownames(mapping) <- NULL
  aggregated$mapping <- mapping
  aggregated
}

microbiome_ggclusternet_phyloseq <- function(
    counts, taxonomy, metadata) {
  if (!requireNamespace("phyloseq", quietly = TRUE)) {
    stop("ggClusterNet2 analysis requires phyloseq.", call. = FALSE)
  }
  counts <- as.matrix(counts)
  storage.mode(counts) <- "numeric"
  taxonomy <- as.data.frame(taxonomy, check.names = FALSE)
  taxon_id <- if ("Taxon" %in% names(taxonomy)) {
    as.character(taxonomy$Taxon)
  } else if ("Feature" %in% names(taxonomy)) {
    as.character(taxonomy$Feature)
  } else {
    rownames(taxonomy)
  }
  taxonomy <- taxonomy[match(colnames(counts), taxon_id), , drop = FALSE]
  rownames(taxonomy) <- colnames(counts)
  taxonomy <- taxonomy[, intersect(
    c(
      "Kingdom", "Phylum", "Class", "Order", "Family", "Genus",
      "Species", "Domain", "SelectedRank", "SelectedTaxon", "filed"),
    names(taxonomy)), drop = FALSE]
  if (!ncol(taxonomy)) {
    taxonomy <- data.frame(
      Taxon = colnames(counts), row.names = colnames(counts),
      stringsAsFactors = FALSE)
  }
  taxonomy[] <- lapply(taxonomy, function(value) {
    value <- as.character(value)
    value[is.na(value) | !nzchar(trimws(value))] <- "Unclassified"
    value
  })
  metadata <- as.data.frame(metadata, check.names = FALSE)
  metadata_id <- if ("SampleID" %in% names(metadata)) {
    as.character(metadata$SampleID)
  } else {
    rownames(metadata)
  }
  metadata <- metadata[match(rownames(counts), metadata_id), , drop = FALSE]
  rownames(metadata) <- rownames(counts)
  phyloseq::phyloseq(
    phyloseq::otu_table(t(counts), taxa_are_rows = TRUE),
    phyloseq::tax_table(as.matrix(taxonomy)),
    phyloseq::sample_data(metadata))
}

microbiome_ggclusternet_cross_phyloseq <- function(prepared, spec) {
  counts <- as.matrix(prepared$bundle$counts)
  taxonomy <- as.data.frame(prepared$bundle$taxonomy, check.names = FALSE)
  metadata <- prepared$bundle$metadata
  build_domain <- function(domain) {
    expected <- paste0(domain, "::")
    selected <- startsWith(colnames(counts), expected)
    domain_counts <- counts[, selected, drop = FALSE]
    original_names <- colnames(domain_counts)
    colnames(domain_counts) <- sub(expected, "", original_names, fixed = TRUE)
    domain_taxonomy <- taxonomy[
      match(original_names, rownames(taxonomy)), , drop = FALSE]
    domain_taxonomy$Taxon <- colnames(domain_counts)
    microbiome_ggclusternet_phyloseq(
      domain_counts, domain_taxonomy, metadata)
  }
  bacteria_ps <- build_domain("Bacteria")
  fungi_ps <- build_domain("Fungi")
  merged <- ggClusterNet::merge16S_ITS(
    bacteria_ps, fungi_ps,
    N16s = phyloseq::ntaxa(bacteria_ps),
    NITS = phyloseq::ntaxa(fungi_ps),
    scale = isTRUE(spec$ggcluster_cross_scale %||% TRUE),
    onlygroup = FALSE, dat1.lab = "Bacteria", dat2.lab = "Fungi")
  taxa <- phyloseq::taxa_names(merged)
  taxa <- sub("^Bacteria_", "Bacteria::", taxa)
  taxa <- sub("^Fungi_", "Fungi::", taxa)
  phyloseq::taxa_names(merged) <- taxa
  tax <- as.data.frame(phyloseq::tax_table(merged), check.names = FALSE)
  domain <- ifelse(startsWith(rownames(tax), "Bacteria::"),
    "Bacteria", "Fungi")
  tax$Domain <- domain
  tax$Kingdom <- domain
  phyloseq::tax_table(merged) <- phyloseq::tax_table(as.matrix(tax))
  merged
}

microbiome_ggclusternet_fit_cache <- local({
  values <- new.env(parent = emptyenv())
  access_order <- character()
  max_entries <- 30L
  function(action = c("get", "set", "clear"), key = "", value = NULL) {
    action <- match.arg(action)
    if (identical(action, "clear")) {
      rm(list = ls(values, all.names = TRUE), envir = values)
      access_order <<- character()
      return(invisible(TRUE))
    }
    if (!nzchar(key)) return(NULL)
    if (identical(action, "get")) {
      if (!exists(key, envir = values, inherits = FALSE)) return(NULL)
      access_order <<- c(setdiff(access_order, key), key)
      return(get(key, envir = values, inherits = FALSE))
    }
    assign(key, value, envir = values)
    access_order <<- c(setdiff(access_order, key), key)
    while (length(access_order) > max_entries) {
      rm(list = access_order[[1]], envir = values)
      access_order <<- access_order[-1]
    }
    invisible(value)
  }
})

microbiome_ggclusternet_fit_cache_key <- function(counts, spec) {
  if (!requireNamespace("digest", quietly = TRUE)) return("")
  parameters <- list(
    adapter = "ggclusternet2-v1",
    package = as.character(utils::packageVersion("ggClusterNet")),
    method = spec$network_measure %||% "spearman",
    r_threshold = as.numeric(spec$network_threshold %||% 0.3),
    p_threshold = as.numeric(spec$network_fdr %||% 0.05),
    scale = spec$ggcluster_scale %||% "rela",
    sparcc_repetitions = as.integer(
      spec$ggcluster_sparcc_repetitions %||% 100L),
    cluster_method = spec$ggcluster_cluster_method %||%
      "cluster_fast_greedy",
    layout = spec$ggcluster_layout %||% "module_fr",
    seed = as.integer(spec$ggcluster_seed %||% 2026L))
  paste0(
    "ggclusternet2-fit-",
    digest::digest(
      list(counts = counts, parameters = parameters),
      algo = "xxhash64", serialize = TRUE))
}

microbiome_ggclusternet_stability_cache_key <- function(
    counts, subsets, spec, requirements) {
  if (!requireNamespace("digest", quietly = TRUE)) return("")
  fit_keys <- vapply(subsets, function(index) {
    microbiome_ggclusternet_fit_cache_key(
      counts[index, , drop = FALSE], spec)
  }, character(1))
  parameters <- list(
    adapter = "ggclusternet2-meconetcomp-v1",
    fit_keys = fit_keys,
    cohesion = isTRUE(requirements$cohesion),
    robustness = isTRUE(requirements$robustness),
    vulnerability = isTRUE(requirements$vulnerability),
    strategies = sort(as.character(
      spec$ggcluster_robustness_strategy %||%
        c("node_rand", "node_degree_high"))),
    runs = max(5L, as.integer(
      spec$ggcluster_robustness_runs %||% 20L)),
    step = as.numeric(spec$ggcluster_robustness_step %||% 0.1),
    maximum_ratio = as.numeric(
      spec$ggcluster_robustness_max_ratio %||% 0.9),
    measure = as.character(
      spec$ggcluster_robustness_measure %||% "Eff"),
    seed = as.integer(spec$ggcluster_seed %||% 2026L))
  paste0(
    "ggclusternet2-stability-",
    digest::digest(
      parameters, algo = "xxhash64", serialize = TRUE))
}

microbiome_ggclusternet_empty_plot <- function(title, message) {
  ggplot2::ggplot() +
    ggplot2::annotate("text", x = 0, y = 0, label = message, size = 4) +
    ggplot2::labs(title = title) +
    ggplot2::theme_void()
}

microbiome_ggclusternet_edges <- function(correlation) {
  index <- which(lower.tri(correlation) & correlation != 0, arr.ind = TRUE)
  if (!nrow(index)) {
    return(data.frame(
      from = character(), to = character(), association = numeric(),
      stringsAsFactors = FALSE))
  }
  data.frame(
    from = rownames(correlation)[index[, 1]],
    to = colnames(correlation)[index[, 2]],
    association = correlation[index],
    stringsAsFactors = FALSE)
}

microbiome_ggclusternet_package_layout <- function(
    correlation, graph, spec) {
  taxa <- rownames(correlation)
  cluster_method <- spec$ggcluster_cluster_method %||%
    "cluster_fast_greedy"
  seed <- as.integer(spec$ggcluster_seed %||% 2026L)
  empty_layout <- function() {
    angle <- seq(0, 2 * pi, length.out = length(taxa) + 1L)[
      seq_along(taxa)]
    list(
      coordinates = data.frame(
        name = taxa, x = cos(angle), y = sin(angle),
        stringsAsFactors = FALSE),
      membership = stats::setNames(seq_along(taxa), taxa),
      model = NULL, warning = character())
  }
  if (!igraph::ecount(graph)) return(empty_layout())
  layout_name <- spec$ggcluster_layout %||% "module_fr"
  native_layout <- function() {
    cluster_function <- switch(
      cluster_method,
      cluster_fast_greedy = igraph::cluster_fast_greedy,
      cluster_walktrap = igraph::cluster_walktrap,
      cluster_edge_betweenness = igraph::cluster_edge_betweenness,
      cluster_spinglass = igraph::cluster_spinglass,
      igraph::cluster_fast_greedy)
    membership <- tryCatch({
      set.seed(seed)
      model <- cluster_function(
        graph, weights = abs(igraph::E(graph)$weight))
      stats::setNames(as.character(igraph::membership(model)),
        igraph::V(graph)$name)
    }, error = function(error) {
      stats::setNames(as.character(seq_len(igraph::vcount(graph))),
        igraph::V(graph)$name)
    })
    coordinates <- if (identical(layout_name, "gephi_concentric")) {
      groups <- split(names(membership), membership)
      centers <- seq(0, 2 * pi, length.out = length(groups) + 1L)[
        seq_along(groups)]
      result <- lapply(seq_along(groups), function(index) {
        members <- groups[[index]]
        angles <- seq(0, 2 * pi, length.out = length(members) + 1L)[
          seq_along(members)]
        radius <- 1 + 0.18 * sqrt(length(members))
        data.frame(
          name = members,
          x = cos(centers[[index]]) * 1.7 + radius * cos(angles),
          y = sin(centers[[index]]) * 1.7 + radius * sin(angles),
          stringsAsFactors = FALSE)
      })
      do.call(rbind, result)
    } else {
      set.seed(seed)
      coordinates <- igraph::layout_with_fr(
        graph, weights = abs(igraph::E(graph)$weight))
      data.frame(
        name = igraph::V(graph)$name,
        x = coordinates[, 1], y = coordinates[, 2],
        stringsAsFactors = FALSE)
    }
    list(
      coordinates = coordinates,
      membership = membership,
      model = NULL,
      warning = character())
  }
  legacy_adjacency_available <- exists(
    "graph.adjacency", envir = asNamespace("ggClusterNet"), inherits = TRUE)
  if (!legacy_adjacency_available) {
    return(native_layout())
  }
  fitted <- tryCatch({
    if (identical(layout_name, "gephi_concentric")) {
      object <- ggClusterNet::model_Gephi.2(
        correlation, method = cluster_method, seed = seed)
      coordinate_table <- as.data.frame(object[[1]])
      module_table <- as.data.frame(object[[3]])
      list(
        coordinates = data.frame(
          name = as.character(coordinate_table$elements),
          x = as.numeric(coordinate_table$X1),
          y = as.numeric(coordinate_table$X2),
          stringsAsFactors = FALSE),
        membership = stats::setNames(
          as.character(module_table$group),
          as.character(module_table$ID)),
        model = object, warning = character())
    } else {
      object <- ggClusterNet::model_igraph(
        correlation, method = cluster_method, seed = seed,
        Top_M = as.integer(spec$ggcluster_top_modules %||% 20L))
      coordinate_table <- as.data.frame(object[[1]])
      graph_model <- object[[3]]
      list(
        coordinates = data.frame(
          name = as.character(coordinate_table$elements),
          x = as.numeric(coordinate_table$X1),
          y = as.numeric(coordinate_table$X2),
          stringsAsFactors = FALSE),
        membership = stats::setNames(
          as.character(igraph::V(graph_model)$modularity),
          igraph::V(graph_model)$name),
        model = object, warning = character())
    }
  }, error = function(error) {
    fallback <- empty_layout()
    fallback$warning <- paste(
      "ggClusterNet2 package layout failed; a circular empty-safe layout",
      "was retained:", conditionMessage(error))
    fallback
  })
  missing <- setdiff(taxa, fitted$coordinates$name)
  if (length(missing)) {
    fallback <- empty_layout()$coordinates
    fitted$coordinates <- rbind(
      fitted$coordinates,
      fallback[fallback$name %in% missing, , drop = FALSE])
  }
  fitted$coordinates <- fitted$coordinates[
    match(taxa, fitted$coordinates$name), , drop = FALSE]
  fitted
}

microbiome_ggclusternet_construct <- function(ps, counts, spec) {
  measure <- spec$network_measure %||% "spearman"
  if (!measure %in% unname(microbiome_ggclusternet_measure_choices())) {
    stop("The selected method is not supported by ggClusterNet::corMicro().",
      call. = FALSE)
  }
  result <- ggClusterNet::corMicro(
    ps = ps, N = 0,
    r.threshold = as.numeric(spec$network_threshold %||% 0.3),
    method.scale = spec$ggcluster_scale %||% "rela",
    p.threshold = as.numeric(spec$network_fdr %||% 0.05),
    method = measure,
    R = as.integer(spec$ggcluster_sparcc_repetitions %||% 100L),
    ncpus = max(
      1L,
      as.integer(spec$ggcluster_cores %||%
        microbiome_ggclusternet_default_cores())))
  correlation <- as.matrix(result[[1]])
  p_value <- as.matrix(result[[4]])
  correlation[!is.finite(correlation)] <- 0
  diag(correlation) <- 0
  edge_table <- microbiome_ggclusternet_edges(correlation)
  graph <- igraph::graph_from_data_frame(
    transform(
      edge_table,
      weight = abs(association),
      sign = ifelse(association >= 0, "Positive", "Negative")),
    directed = FALSE,
    vertices = data.frame(name = colnames(counts), stringsAsFactors = FALSE))
  layout <- microbiome_ggclusternet_package_layout(
    correlation, graph, spec)
  node_properties <- tryCatch(
    as.data.frame(ggClusterNet::node_properties(graph, outdir = tempdir())),
    error = function(error) data.frame())
  network_properties <- tryCatch(
    as.data.frame(ggClusterNet::net_properties(graph)),
    error = function(error) data.frame())
  zipi <- if (igraph::ecount(graph)) {
    tryCatch(
      ggClusterNet::ZiPiPlot(
        graph,
        method = spec$ggcluster_cluster_method %||%
          "cluster_fast_greedy"),
      error = function(error) NULL)
  } else {
    NULL
  }
  list(
    cor_micro = result, correlation = correlation, p_value = p_value,
    graph = graph, layout = layout, node_properties = node_properties,
    network_properties = network_properties, zipi = zipi)
}

microbiome_ggclusternet_extract <- function(
    fit, counts, taxonomy, group_name, spec) {
  graph <- fit$graph
  edges <- microbiome_ggclusternet_edges(fit$correlation)
  edges$weight <- abs(edges$association)
  edges$sign <- ifelse(edges$association >= 0, "Positive", "Negative")
  edges$Group <- rep(group_name, nrow(edges))
  taxa <- colnames(counts)
  package_nodes <- fit$node_properties
  package_value <- function(column, fallback) {
    if (!nrow(package_nodes) || !column %in% names(package_nodes)) {
      return(fallback)
    }
    value <- package_nodes[[column]]
    names(value) <- rownames(package_nodes)
    as.numeric(value[taxa])
  }
  degree <- package_value(
    "igraph.degree", as.numeric(igraph::degree(graph)[taxa]))
  betweenness <- package_value(
    "igraph.betweenness",
    as.numeric(igraph::betweenness(graph, directed = FALSE)[taxa]))
  closeness <- package_value(
    "igraph.closeness",
    as.numeric(igraph::closeness(graph, normalized = TRUE)[taxa]))
  eigenvector <- if (igraph::ecount(graph)) {
    as.numeric(igraph::eigen_centrality(
      graph, directed = FALSE, weights = abs(igraph::E(graph)$weight))$
      vector[taxa])
  } else {
    rep(0, length(taxa))
  }
  strength <- as.numeric(igraph::strength(
    graph, vids = taxa, weights = abs(igraph::E(graph)$weight)))
  membership <- fit$layout$membership
  module <- as.character(membership[taxa])
  missing_module <- is.na(module) | !nzchar(module)
  module[missing_module] <- as.character(seq_len(sum(missing_module)) +
    length(unique(module[!missing_module])))
  hub_threshold <- if (length(degree)) {
    stats::quantile(
      degree,
      probs = as.numeric(spec$ggcluster_hub_quantile %||% 0.95),
      na.rm = TRUE, names = FALSE)
  } else {
    Inf
  }
  nodes <- data.frame(
    name = taxa, degree = degree, degree_raw = degree,
    betweenness = betweenness, closeness = closeness,
    eigenvector = eigenvector, strength = strength,
    mean_abundance = colMeans(counts / pmax(rowSums(counts), 1)),
    prevalence = colMeans(counts > 0), module = module,
    hub = degree > 0 & degree >= hub_threshold,
    Group = group_name, stringsAsFactors = FALSE)
  taxonomy <- as.data.frame(taxonomy, check.names = FALSE)
  if ("Taxon" %in% names(taxonomy)) {
    taxonomy <- taxonomy[!duplicated(taxonomy$Taxon), , drop = FALSE]
    nodes <- merge(
      nodes, taxonomy, by.x = "name", by.y = "Taxon",
      all.x = TRUE, sort = FALSE)
  }
  nodes <- nodes[match(taxa, nodes$name), , drop = FALSE]
  package_roles <- if (!is.null(fit$zipi) && length(fit$zipi) >= 2L) {
    as.data.frame(fit$zipi[[2]], check.names = FALSE)
  } else {
    data.frame()
  }
  if (nrow(package_roles)) {
    role_id <- rownames(package_roles)
    if ("label" %in% names(package_roles)) {
      labelled <- as.character(package_roles$label)
      role_id[nzchar(labelled)] <- labelled[nzchar(labelled)]
    }
    z_name <- intersect(c("z", "Zi", "zi"), names(package_roles))
    p_name <- intersect(c("p", "Pi", "pi"), names(package_roles))
    role_name <- intersect(c("roles", "role", "role_7"), names(package_roles))
    nodes$Zi <- if (length(z_name)) {
      as.numeric(package_roles[[z_name[[1]]]][match(nodes$name, role_id)])
    } else {
      NA_real_
    }
    nodes$Pi <- if (length(p_name)) {
      as.numeric(package_roles[[p_name[[1]]]][match(nodes$name, role_id)])
    } else {
      NA_real_
    }
    nodes$Role <- if (length(role_name)) {
      as.character(
        package_roles[[role_name[[1]]]][match(nodes$name, role_id)])
    } else {
      NA_character_
    }
  } else {
    fallback_roles <- microbiome_network_zipi(
      graph, stats::setNames(nodes$module, nodes$name)[igraph::V(graph)$name])
    nodes$Zi <- fallback_roles$Zi[match(nodes$name, fallback_roles$Feature)]
    nodes$Pi <- fallback_roles$Pi[match(nodes$name, fallback_roles$Feature)]
    nodes$Role <- ifelse(
      nodes$Zi >= 2.5 & nodes$Pi >= 0.62, "Network hubs",
      ifelse(
        nodes$Zi >= 2.5, "Module hubs",
        ifelse(nodes$Pi >= 0.62, "Connectors", "Peripherals")))
  }
  properties <- fit$network_properties
  property_values <- if (nrow(properties)) {
    stats::setNames(as.numeric(properties[[1]]), rownames(properties))
  } else {
    numeric()
  }
  property <- function(name, fallback = NA_real_) {
    value <- unname(property_values[name])
    if (length(value) && is.finite(value)) value else fallback
  }
  topology <- data.frame(
    Group = group_name,
    Nodes = property("num.vertices", igraph::vcount(graph)),
    Edges = property("num.edges", igraph::ecount(graph)),
    MeanDegree = property("average.degree", mean(degree)),
    Density = property("connectance", igraph::edge_density(graph)),
    Modularity = if (igraph::ecount(graph)) {
      suppressWarnings(igraph::modularity(
        graph, as.integer(factor(nodes$module)),
        weights = abs(igraph::E(graph)$weight)))
    } else {
      NA_real_
    },
    AveragePathLength = property("average.path.length"),
    ClusteringCoefficient = property("clustering.coefficient"),
    PositiveEdgeFraction = if (nrow(edges)) {
      mean(edges$association > 0)
    } else {
      NA_real_
    },
    stringsAsFactors = FALSE)
  list(
    graph = graph, nodes = nodes, edges = edges, topology = topology,
    correlation = fit$correlation, p_value = fit$p_value,
    coordinates = fit$layout$coordinates)
}

microbiome_ggclusternet_matrix_table <- function(extracted) {
  tables <- lapply(names(extracted), function(group) {
    correlation <- extracted[[group]]$correlation
    p_value <- extracted[[group]]$p_value
    index <- which(upper.tri(correlation), arr.ind = TRUE)
    if (!nrow(index)) {
      return(data.frame(
        Group = character(), From = character(), To = character(),
        Correlation = numeric(), PValue = numeric(), Retained = logical(),
        stringsAsFactors = FALSE))
    }
    data.frame(
      Group = group,
      From = rownames(correlation)[index[, 1]],
      To = colnames(correlation)[index[, 2]],
      Correlation = correlation[index],
      PValue = p_value[index],
      Retained = correlation[index] != 0,
      stringsAsFactors = FALSE)
  })
  do.call(rbind, tables)
}

microbiome_ggclusternet_network_plot_specs <- function(plot_spec) {
  base <- microbiome_network_plot_spec_merge(plot_spec)
  curved <- base
  curved$plot_variant <- "curved_edge"
  curved$edge$curve <- max(
    0.25, abs(as.numeric(curved$edge$curve %||% 0.25)))
  curved$edge$curve_all <- TRUE
  curved$annotation$title <- paste0(
    base$annotation$title %||% "ggClusterNet2 Network",
    " - Curved-edge")
  module <- base
  module$plot_variant <- "module_coloured"
  module$node$colour_by <- "module"
  module$annotation$title <- paste0(
    base$annotation$title %||% "ggClusterNet2 Network",
    " - Module-coloured")
  list(
    ggcluster_curved_network = curved,
    ggcluster_module_network = module)
}

microbiome_ggclusternet_plot_set <- function(
    requested, graphs, nodes, edges, topology, coordinates, plot_spec,
    extracted, cross_domain = FALSE, stability = list()) {
  grouped <- length(graphs) > 1L
  main_name <- if (cross_domain) {
    "cross_domain_network"
  } else if (grouped) {
    "grouped_network"
  } else {
    "overall_network"
  }
  network_plot <- microbiome_render_network_publication(
    graphs, nodes, edges, coordinates, plot_spec)
  variant_specs <- microbiome_ggclusternet_network_plot_specs(plot_spec)
  curved_spec <- variant_specs$ggcluster_curved_network
  module_spec <- variant_specs$ggcluster_module_network
  role_data <- nodes[
    is.finite(nodes$Zi) & is.finite(nodes$Pi), , drop = FALSE]
  role_plot <- if (nrow(role_data)) {
    ggplot2::ggplot(
      role_data,
      ggplot2::aes(.data$Pi, .data$Zi, colour = .data$module,
        shape = .data$Role)) +
      ggplot2::geom_hline(yintercept = 2.5, linetype = 2) +
      ggplot2::geom_vline(xintercept = 0.62, linetype = 2) +
      ggplot2::geom_point(size = 2.8) +
      ggplot2::facet_wrap(~Group) +
      ggplot2::labs(
        x = "Participation coefficient (Pi)",
        y = "Within-module connectivity (Zi)",
        title = "ggClusterNet2 Zi-Pi Node Roles") +
      ggplot2::theme_classic()
  } else {
    microbiome_ggclusternet_empty_plot(
      "ggClusterNet2 Zi-Pi Node Roles",
      "Zi-Pi roles are unavailable because the inferred network has no edges.")
  }
  taxonomy_field <- if ("Phylum" %in% names(nodes)) {
    "Phylum"
  } else if ("Kingdom" %in% names(nodes)) {
    "Kingdom"
  } else {
    nodes$TaxonomicGroup <- "Unclassified"
    "TaxonomicGroup"
  }
  nodes$TaxonomicGroup <- as.factor(nodes[[taxonomy_field]])
  topology_long <- tidyr::pivot_longer(
    topology,
    cols = setdiff(names(topology), "Group"),
    names_to = "Property", values_to = "Value")
  topology_long$Value <- suppressWarnings(as.numeric(topology_long$Value))
  topology_long <- topology_long[
    is.finite(topology_long$Value), , drop = FALSE]
  candidates <- list(
    ggcluster_curved_network = microbiome_render_network_publication(
      graphs, nodes, edges, coordinates, curved_spec),
    ggcluster_module_network = microbiome_render_network_publication(
      graphs, nodes, edges, coordinates, module_spec),
    zipi_roles = role_plot,
    centrality_distribution = ggplot2::ggplot(
      nodes, ggplot2::aes(.data$degree, fill = .data$Group)) +
      ggplot2::geom_histogram(
        bins = 15, alpha = 0.72, position = "identity") +
      ggplot2::facet_wrap(~Group, scales = "free_y") +
      ggplot2::labs(
        x = "Degree", y = "Node count",
        title = "ggClusterNet2 Degree Distribution") +
      ggplot2::theme_classic(),
    module_composition = ggplot2::ggplot(
      nodes,
      ggplot2::aes(.data$module, fill = .data$TaxonomicGroup)) +
      ggplot2::geom_bar(position = "fill") +
      ggplot2::facet_wrap(~Group) +
      ggplot2::labs(
        x = "Module", y = "Taxonomic composition",
        fill = taxonomy_field,
        title = "ggClusterNet2 Module Composition") +
      ggplot2::theme_classic(),
    network_properties = ggplot2::ggplot(
      topology_long,
      ggplot2::aes(.data$Group, .data$Value, fill = .data$Group)) +
      ggplot2::geom_col(show.legend = FALSE) +
      ggplot2::facet_wrap(~Property, scales = "free_y") +
      ggplot2::labs(
        x = NULL, y = "Value",
        title = "ggClusterNet2 Network Properties") +
      ggplot2::theme_classic())
  stability_plots <- microbiome_netcomi_support_plots(
    nodes, edges, topology, stability)
  for (name in c(
      "cohesion", "robustness", "node_vulnerability",
      "stability_summary")) {
    if (!is.null(stability_plots[[name]])) {
      candidates[[name]] <- stability_plots[[name]]
    }
  }
  plots <- list()
  if (main_name %in% requested) plots[[main_name]] <- network_plot
  for (name in intersect(names(candidates), requested)) {
    plots[[name]] <- candidates[[name]]
  }
  if (cross_domain) {
    edges <- microbiome_cross_domain_annotate_edges(edges, nodes)
    if ("domain_edge_composition" %in% requested) {
      plots$domain_edge_composition <- if (nrow(edges)) {
        summary <- as.data.frame(table(
          Group = edges$Group, EdgeDomain = edges$EdgeDomain),
          stringsAsFactors = FALSE)
        summary <- summary[summary$Freq > 0, , drop = FALSE]
        ggplot2::ggplot(
          summary,
          ggplot2::aes(.data$Group, .data$Freq, fill = .data$EdgeDomain)) +
          ggplot2::geom_col(position = "fill") +
          ggplot2::scale_y_continuous(labels = scales::percent) +
          ggplot2::labs(
            x = NULL, y = "Edge proportion", fill = "Edge domain",
            title = "ggClusterNet2 Cross-domain Edge Composition") +
          ggplot2::theme_classic()
      } else {
        microbiome_ggclusternet_empty_plot(
          "ggClusterNet2 Cross-domain Edge Composition",
          "No associations passed the selected thresholds.")
      }
    }
    cross_edges <- edges[
      edges$EdgeDomain == "Bacteria-Fungi", , drop = FALSE]
    if ("cross_domain_heatmap" %in% requested) {
      plots$cross_domain_heatmap <- if (nrow(cross_edges)) {
        cross_edges$Bacteria <- ifelse(
          cross_edges$FromDomain == "Bacteria",
          sub("^Bacteria::", "", cross_edges$from),
          sub("^Bacteria::", "", cross_edges$to))
        cross_edges$Fungi <- ifelse(
          cross_edges$FromDomain == "Fungi",
          sub("^Fungi::", "", cross_edges$from),
          sub("^Fungi::", "", cross_edges$to))
        ggplot2::ggplot(
          cross_edges,
          ggplot2::aes(.data$Bacteria, .data$Fungi,
            fill = .data$association)) +
          ggplot2::geom_tile(colour = "white", linewidth = 0.25) +
          ggplot2::scale_fill_gradient2(
            low = "#2B6CB0", mid = "white", high = "#C43C39",
            midpoint = 0, name = "Correlation") +
          ggplot2::facet_wrap(~Group) +
          ggplot2::labs(
            x = "Bacterial taxon", y = "Fungal taxon",
            title = "ggClusterNet2 Bacteria-Fungi Associations") +
          ggplot2::theme_classic() +
          ggplot2::theme(
            axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
      } else {
        microbiome_ggclusternet_empty_plot(
          "ggClusterNet2 Bacteria-Fungi Associations",
          "No bacteria-fungi associations passed the selected thresholds.")
      }
    }
    if ("domain_centrality" %in% requested) {
      plots$domain_centrality <- ggplot2::ggplot(
        nodes,
        ggplot2::aes(.data$Kingdom, .data$degree,
          fill = .data$Kingdom)) +
        ggplot2::geom_boxplot(outlier.shape = NA, alpha = 0.72) +
        ggplot2::geom_jitter(width = 0.12, alpha = 0.5, size = 1.4) +
        ggplot2::facet_wrap(~Group) +
        ggplot2::labs(
          x = NULL, y = "Degree",
          title = "ggClusterNet2 Centrality by Domain") +
        ggplot2::theme_classic() +
        ggplot2::theme(legend.position = "none")
    }
  }
  missing <- setdiff(requested, names(plots))
  for (name in missing) {
    plots[[name]] <- microbiome_ggclusternet_empty_plot(
      name,
      "The selected ggClusterNet2 output is unavailable for this result.")
  }
  plots[requested]
}

microbiome_ggclusternet_code <- function(
    spec, cross_domain = FALSE) {
  grouped <- isTRUE(spec$group_network)
  stability <- microbiome_ggclusternet_analysis_requirements(
    spec$plot_types %||% character())
  stability_requested <- any(unlist(stability, use.names = FALSE))
  lines <- c(
    "library(phyloseq)",
    "library(ggClusterNet)",
    "library(igraph)",
    if (stability_requested) {
      c("library(microeco)", "library(meconetcomp)")
    },
    if (cross_domain) {
      c(
        "# ps16s and psITS are rank-aggregated phyloseq objects.",
        sprintf(
          paste0(
            "ps_network <- ggClusterNet::merge16S_ITS(ps16s, psITS, ",
            "N16s = ntaxa(ps16s), NITS = ntaxa(psITS), scale = %s, ",
            "dat1.lab = 'Bacteria', dat2.lab = 'Fungi')"),
          if (isTRUE(spec$ggcluster_cross_scale %||% TRUE)) "TRUE" else
            "FALSE"))
    } else {
      c(
        "counts <- as.matrix(bundle$counts)",
        "storage.mode(counts) <- 'numeric'",
        sprintf(
          "taxonomic_rank <- %s",
          dQuote(spec$taxonomic_rank %||% "Genus", q = FALSE)),
        "taxonomy <- as.data.frame(bundle$taxonomy, check.names = FALSE)",
        "taxonomy_ids <- if ('Feature' %in% names(taxonomy)) as.character(taxonomy$Feature) else rownames(taxonomy)",
        "taxonomy <- taxonomy[match(colnames(counts), taxonomy_ids), , drop = FALSE]",
        "stopifnot(taxonomic_rank %in% names(taxonomy))",
        "taxon <- trimws(as.character(taxonomy[[taxonomic_rank]]))",
        "taxon[is.na(taxon) | !nzchar(taxon)] <- paste0('Unclassified_', taxonomic_rank)",
        "network_counts <- t(rowsum(t(counts), group = taxon, reorder = FALSE))",
        sprintf("minimum_prevalence <- %s",
          format(as.numeric(spec$minimum_prevalence %||%
            spec$ggcluster_min_prevalence %||% 0.1))),
        sprintf("maximum_features <- %dL",
          max(5L, as.integer(spec$maximum_features %||%
            spec$ggcluster_max_features %||% 60L))),
        "prevalence <- colMeans(network_counts > 0)",
        "candidates <- which(prevalence >= minimum_prevalence)",
        "relative_abundance <- network_counts / pmax(rowSums(network_counts), 1)",
        "candidates <- candidates[order(colMeans(relative_abundance[, candidates, drop = FALSE]), decreasing = TRUE)]",
        "keep <- head(candidates, maximum_features)",
        "stopifnot(length(keep) >= 5L)",
        "network_counts <- network_counts[, keep, drop = FALSE]",
        "metadata <- as.data.frame(bundle$metadata, check.names = FALSE)",
        "metadata_ids <- if ('SampleID' %in% names(metadata)) as.character(metadata$SampleID) else rownames(metadata)",
        "metadata <- metadata[match(rownames(network_counts), metadata_ids), , drop = FALSE]",
        "rownames(metadata) <- rownames(network_counts)",
        "network_taxonomy <- data.frame(Taxon = colnames(network_counts), row.names = colnames(network_counts), check.names = FALSE)",
        "network_taxonomy[[taxonomic_rank]] <- colnames(network_counts)",
        "ps_network <- phyloseq::phyloseq(",
        "  phyloseq::otu_table(t(network_counts), taxa_are_rows = TRUE),",
        "  phyloseq::tax_table(as.matrix(network_taxonomy)),",
        "  phyloseq::sample_data(metadata))")
    },
    if (grouped) {
      sprintf(
        "network_sets <- split(sample_names(ps_network), sample_data(ps_network)[[%s]])",
        dQuote(spec$group %||% "", q = FALSE))
    } else {
      "network_sets <- list(Overall = sample_names(ps_network))"
    },
    "cor_micro <- lapply(network_sets, function(sample_ids) {",
    "  ps_group <- prune_samples(sample_ids, ps_network)",
    "  ggClusterNet::corMicro(",
    "    ps_group, N = 0,",
    sprintf("    r.threshold = %s, p.threshold = %s,",
      format(as.numeric(spec$network_threshold %||% 0.3)),
      format(as.numeric(spec$network_fdr %||% 0.05))),
    sprintf("    method.scale = %s, method = %s,",
      dQuote(spec$ggcluster_scale %||% "rela", q = FALSE),
      dQuote(spec$network_measure %||% "spearman", q = FALSE)),
    sprintf("    R = %dL, ncpus = %dL)",
      as.integer(spec$ggcluster_sparcc_repetitions %||% 100L),
      max(
        1L,
        as.integer(spec$ggcluster_cores %||%
          microbiome_ggclusternet_default_cores()))),
    "})",
    "graphs <- lapply(cor_micro, function(x) {",
    "  edge_node <- ggClusterNet::nodeEdge(x[[1]], zero = TRUE)",
    "  igraph::graph_from_data_frame(edge_node[[1]], directed = FALSE,",
    "    vertices = edge_node[[2]])",
    "})",
    sprintf(
      "layouts <- lapply(cor_micro, function(x) ggClusterNet::%s(x[[1]], method = %s, seed = %dL))",
      if (identical(spec$ggcluster_layout %||% "module_fr",
          "gephi_concentric")) {
        "model_Gephi.2"
      } else {
        "model_igraph"
      },
      dQuote(spec$ggcluster_cluster_method %||%
        "cluster_fast_greedy", q = FALSE),
      as.integer(spec$ggcluster_seed %||% 2026L)),
    sprintf(
      "zi_pi <- lapply(graphs, ggClusterNet::ZiPiPlot, method = %s)",
      dQuote(spec$ggcluster_cluster_method %||%
        "cluster_fast_greedy", q = FALSE)),
    "node_properties <- lapply(graphs, ggClusterNet::node_properties, outdir = tempdir())",
    "network_properties <- lapply(graphs, ggClusterNet::net_properties)")
  if (stability_requested) {
    strategies <- unique(as.character(
      spec$ggcluster_robustness_strategy %||%
        c("node_rand", "node_degree_high")))
    lines <- c(
      lines,
      "",
      "# meconetcomp adapter: signed r for Cohesion; signed dissimilarity for paths.",
      "to_trans_network <- function(cor_result, sample_ids) {",
      "  assoMat <- as.matrix(cor_result[[1]])",
      "  edge_info <- as.data.frame(ggClusterNet::nodeEdge(assoMat, zero = TRUE)[[1]])",
      "  names(edge_info)[names(edge_info) == 'weight'] <- 'association'",
      "  taxa <- unique(c(edge_info$from, edge_info$to))",
      "  ps_group <- prune_samples(sample_ids, ps_network)",
      "  otu <- as(otu_table(ps_group), 'matrix')",
      "  if (!taxa_are_rows(ps_group)) otu <- t(otu)",
      "  otu <- otu[taxa, , drop = FALSE]",
      "  microtable <- microeco::microtable$new(",
      "    otu_table = as.data.frame(otu),",
      "    sample_table = as.data.frame(sample_data(ps_group)),",
      "    tax_table = as.data.frame(tax_table(ps_group))[taxa, , drop = FALSE],",
      "    auto_tidy = FALSE)",
      "  tn <- microeco::trans_network$new(dataset = microtable)",
      "  edge_info$dissimilarity <- sqrt(0.5 * (1 - edge_info$association))",
      "  edge_info$label <- ifelse(edge_info$association >= 0, '+', '-')",
      "  tn$data_abund <- as.data.frame(t(otu))",
      "  tn$res_network <- igraph::graph_from_data_frame(",
      "    transform(edge_info, weight = dissimilarity), directed = FALSE,",
      "    vertices = data.frame(name = taxa))",
      "  tn$res_edge_table <- data.frame(",
      "    node1 = edge_info$from, node2 = edge_info$to,",
      "    weight = abs(edge_info$association), label = edge_info$label,",
      "    association = edge_info$association,",
      "    dissimilarity = edge_info$dissimilarity)",
      "  tn",
      "}",
      "trans_network_list <- Map(to_trans_network, cor_micro, network_sets)",
      "names(trans_network_list) <- names(network_sets)")
    if (isTRUE(stability$cohesion)) {
      lines <- c(
        lines,
        "cohesion_result <- meconetcomp::cohesionclass$new(trans_network_list)",
        "cohesion_sample <- cohesion_result$res_list$sample")
    }
    if (isTRUE(stability$robustness)) {
      lines <- c(
        lines,
        "robustness_result <- meconetcomp::robustness$new(",
        "  trans_network_list,",
        sprintf(
          "  remove_strategy = c(%s),",
          paste(dQuote(strategies, q = FALSE), collapse = ", ")),
        sprintf(
          "  remove_ratio = seq(0, %s, by = %s),",
          format(as.numeric(
            spec$ggcluster_robustness_max_ratio %||% 0.9)),
          format(as.numeric(
            spec$ggcluster_robustness_step %||% 0.1))),
        sprintf(
          "  measure = %s, run = %dL)",
          dQuote(
            spec$ggcluster_robustness_measure %||% "Eff",
            q = FALSE),
          max(5L, as.integer(
            spec$ggcluster_robustness_runs %||% 20L))),
        "robustness_curve <- robustness_result$res_summary",
        "trapz <- function(x, y) sum(diff(x) *",
        "  (head(y, -1L) + tail(y, -1L)) / 2)",
        "robustness_auc <- do.call(rbind, lapply(split(",
        "  robustness_curve, interaction(",
        "    robustness_curve$Network, robustness_curve$remove_strategy,",
        "    robustness_curve$measure, drop = TRUE)), function(d) {",
        "  d <- d[order(d$remove_ratio), ]",
        "  data.frame(",
        "    Network = d$Network[1],",
        "    remove_strategy = d$remove_strategy[1],",
        "    measure = d$measure[1],",
        "    Robustness_AUC = trapz(d$remove_ratio, d$Mean))",
        "}))")
    }
    if (isTRUE(stability$vulnerability)) {
      lines <- c(
        lines,
        "node_vulnerability <- meconetcomp::vulnerability(trans_network_list)")
    }
  }
  microbiome_parseable_code(lines)
}

microbiome_run_ggclusternet_network <- function(
    bundle, spec = list(), method_id = "netcomi_network",
    cross_domain = FALSE) {
  grouped <- isTRUE(spec$group_network)
  requested_input <- unique(as.character(
    spec$plot_types %||%
      microbiome_ggclusternet_default_plot_types(
        grouped, cross_domain)))
  requirements <- microbiome_ggclusternet_analysis_requirements(
    requested_input)
  stability_required <- any(unlist(requirements, use.names = FALSE))
  required <- c(
    "ggClusterNet", "phyloseq", "igraph", "ggplot2", "tidyr",
    if (stability_required) c("microeco", "meconetcomp"))
  missing <- required[!vapply(
    required, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    stop(
      "ggClusterNet2 network analysis requires: ",
      paste(missing, collapse = ", "), call. = FALSE)
  }
  started <- proc.time()[["elapsed"]]
  prepared <- NULL
  if (cross_domain) {
    second_bundle <- spec$second_bundle
    if (is.null(second_bundle)) {
      stop(
        "Select the paired ITS dataset for cross-domain analysis.",
        call. = FALSE)
    }
    cross_spec <- spec
    cross_spec$minimum_prevalence <-
      spec$ggcluster_min_prevalence %||% 0.1
    cross_spec$maximum_features <-
      spec$ggcluster_max_features %||% 60L
    cross_spec$cross_max_features_per_domain <-
      spec$ggcluster_max_features_per_domain %||% 30L
    prepared <- microbiome_cross_domain_prepare(
      bundle, second_bundle, cross_spec)
    analysis_bundle <- prepared$bundle
    counts <- as.matrix(analysis_bundle$counts)
    taxonomy <- as.data.frame(
      analysis_bundle$taxonomy, check.names = FALSE)
    taxonomy$Taxon <- rownames(taxonomy)
    ps <- microbiome_ggclusternet_cross_phyloseq(prepared, spec)
    rank <- "CrossDomainTaxon"
  } else {
    aggregation <- microbiome_ggclusternet_aggregate(bundle, spec)
    analysis_bundle <- aggregation$bundle
    counts <- as.matrix(aggregation$counts)
    taxonomy <- aggregation$mapping
    ps <- microbiome_ggclusternet_phyloseq(
      counts, taxonomy, analysis_bundle$metadata)
    rank <- aggregation$rank
  }
  metadata <- analysis_bundle$metadata
  group_name <- if (grouped) as.character(spec$group %||% "") else ""
  if (grouped && (!nzchar(group_name) || !group_name %in% names(metadata))) {
    stop(
      "Select a valid categorical grouping variable for grouped networks.",
      call. = FALSE)
  }
  subsets <- if (grouped) {
    grouping <- droplevels(factor(metadata[[group_name]]))
    stats::setNames(
      lapply(levels(grouping), function(level) which(grouping == level)),
      levels(grouping))
  } else {
    list(Overall = seq_len(nrow(counts)))
  }
  if (any(lengths(subsets) < 6L)) {
    stop("Each ggClusterNet2 network requires at least six samples.",
      call. = FALSE)
  }
  fits <- extracted <- trans_networks <- list()
  warnings <- runtime_log <- character()
  cache_hits <- 0L
  for (scope in names(subsets)) {
    index <- subsets[[scope]]
    scope_counts <- counts[index, , drop = FALSE]
    cache_key <- microbiome_ggclusternet_fit_cache_key(scope_counts, spec)
    captured <- microbiome_ggclusternet_fit_cache("get", cache_key)
    if (is.null(captured)) {
      sample_ids <- rownames(scope_counts)
      scope_ps <- phyloseq::prune_samples(sample_ids, ps)
      captured <- microbiome_capture_runtime_output(function() {
        microbiome_ggclusternet_construct(scope_ps, scope_counts, spec)
      })
      if (nzchar(cache_key)) {
        microbiome_ggclusternet_fit_cache(
          "set", cache_key, captured)
      }
    } else {
      cache_hits <- cache_hits + 1L
      captured$log <- c(
        captured$log,
        sprintf(
          "[cache] Reused fitted ggClusterNet2 network for %s.", scope))
    }
    fits[[scope]] <- captured$value
    warnings <- c(
      warnings, captured$warnings,
      fits[[scope]]$layout$warning %||% character())
    runtime_log <- c(runtime_log, captured$log)
    extracted[[scope]] <- microbiome_ggclusternet_extract(
      fits[[scope]], scope_counts, taxonomy, scope, spec)
    if (stability_required) {
      captured_trans_network <- microbiome_capture_runtime_output(function() {
        microbiome_network_as_trans_network(
          extracted[[scope]], scope_counts,
          metadata[index, , drop = FALSE], taxonomy)
      })
      trans_networks[[scope]] <- captured_trans_network$value
      warnings <- c(warnings, captured_trans_network$warnings)
      runtime_log <- c(runtime_log, captured_trans_network$log)
    }
  }
  stability_cache_key <- if (stability_required) {
    microbiome_ggclusternet_stability_cache_key(
      counts, subsets, spec, requirements)
  } else {
    ""
  }
  cached_stability <- if (nzchar(stability_cache_key)) {
    microbiome_ggclusternet_fit_cache(
      "get", stability_cache_key)
  } else {
    NULL
  }
  stability_cache_hit <- !is.null(cached_stability)
  stability <- if (stability_cache_hit) {
    runtime_log <- c(
      runtime_log,
      "[cache] Reused ggClusterNet2 meconetcomp stability results.")
    cached_stability
  } else if (stability_required) {
    captured_stability <- microbiome_capture_runtime_output(function() {
      microbiome_network_stability(
        trans_networks, spec, requirements)
    })
    warnings <- c(warnings, captured_stability$warnings)
    runtime_log <- c(runtime_log, captured_stability$log)
    value <- captured_stability$value
    if (nzchar(stability_cache_key)) {
      microbiome_ggclusternet_fit_cache(
        "set", stability_cache_key, value)
    }
    value
  } else {
    microbiome_network_stability(
      list(), spec, requirements)
  }
  if (stability_required) {
    runtime_log <- c(
      runtime_log,
      paste(
        "[stability] Cohesion used signed ggClusterNet associations;",
        "robustness and node vulnerability used",
        "diss = sqrt(0.5 * (1 - r))."))
  }
  graphs <- lapply(extracted, `[[`, "graph")
  nodes <- do.call(rbind, lapply(extracted, `[[`, "nodes"))
  edges <- do.call(rbind, lapply(extracted, `[[`, "edges"))
  topology <- do.call(rbind, lapply(extracted, `[[`, "topology"))
  rownames(nodes) <- rownames(edges) <- rownames(topology) <- NULL
  if (cross_domain) {
    edges <- microbiome_cross_domain_annotate_edges(edges, nodes)
  }
  stability <- microbiome_network_annotate_stability(
    stability, nodes)
  warnings <- unique(c(warnings, stability$warnings))
  first_coordinates <- extracted[[1]]$coordinates
  coordinates <- first_coordinates[
    match(colnames(counts), first_coordinates$name), , drop = FALSE]
  plot_spec <- microbiome_network_plot_spec_merge(
    spec$network_plot_spec %||% list())
  plot_spec$engine <- "ggclusternet2"
  plot_spec$layout$algorithm <- paste0(
    "ggcluster_", spec$ggcluster_layout %||% "module_fr")
  plot_spec$layout$seed <- as.integer(spec$ggcluster_seed %||% 2026L)
  plot_spec$layout$common_layout <- TRUE
  plot_spec$node$colour_by <- if (cross_domain) "Kingdom" else "Phylum"
  plot_spec$annotation$title <- if (cross_domain) {
    if (grouped) {
      "Grouped ggClusterNet2 Bacteria-Fungi Networks"
    } else {
      "ggClusterNet2 Bacteria-Fungi Cross-domain Network"
    }
  } else if (grouped) {
    "Grouped ggClusterNet2 Co-occurrence Networks"
  } else {
    "ggClusterNet2 Co-occurrence Network"
  }
  plot_spec$annotation$subtitle <- if (cross_domain) {
    paste0(
      "16S ", prepared$bacteria_rank, " + ITS ", prepared$fungi_rank,
      "; ggClusterNet::merge16S_ITS")
  } else {
    paste("Network taxonomic level:", rank)
  }
  plot_specs <- microbiome_ggclusternet_network_plot_specs(plot_spec)
  requested <- requested_input
  valid_plots <- unname(
    microbiome_ggclusternet_plot_choices(grouped, cross_domain))
  requested <- intersect(requested, valid_plots)
  if (!length(requested)) {
    requested <- microbiome_ggclusternet_default_plot_types(
      grouped, cross_domain)
  }
  plots <- microbiome_ggclusternet_plot_set(
    requested, graphs, nodes, edges, topology, coordinates, plot_spec,
    extracted, cross_domain, stability)
  correlation_table <- microbiome_ggclusternet_matrix_table(extracted)
  tables <- list(
    aggregation_summary = data.frame(
      Engine = "ggClusterNet2",
      TaxonomicLevel = rank,
      Samples = nrow(counts), AggregatedTaxa = ncol(counts),
      stringsAsFactors = FALSE),
    fit_cache_summary = data.frame(
      Engine = "ggClusterNet2",
      CacheHits = cache_hits,
      CacheMisses = length(subsets) - cache_hits,
      StabilityCacheHit = stability_cache_hit,
      stringsAsFactors = FALSE),
    nodes = nodes, edges = edges, topology = topology,
    correlations = correlation_table,
    cohesion = stability$cohesion,
    cohesion_tests = stability$cohesion_tests,
    robustness = stability$robustness,
    robustness_auc = stability$robustness_auc,
    robustness_auc_runs = stability$robustness_runs,
    robustness_tests = stability$robustness_tests,
    vulnerability = stability$vulnerability,
    vulnerability_tests = stability$vulnerability_tests,
    stability_summary = stability$summary,
    stability_edges = microbiome_network_stability_edges(
      trans_networks),
    layout_coordinates = coordinates,
    aggregated_counts = data.frame(
      SampleID = rownames(counts), counts, check.names = FALSE))
  if (cross_domain) {
    tables$cross_domain_summary <- data.frame(
      MatchedSamples = length(prepared$common_samples),
      BacterialTaxa = length(prepared$bacteria_taxa),
      FungalTaxa = length(prepared$fungi_taxa),
      BacteriaRank = prepared$bacteria_rank,
      FungiRank = prepared$fungi_rank,
      Engine = "ggClusterNet2",
      stringsAsFactors = FALSE)
  }
  public_spec <- spec
  public_spec$second_bundle <- NULL
  public_spec$network_engine <- "ggclusternet2"
  public_spec$network_plot_spec <- plot_spec
  public_spec$taxonomic_rank <- rank
  runtime_log <- c(
    runtime_log,
    sprintf(
      "[performance] ggClusterNet2 fit cache: %d hit(s), %d miss(es).",
      cache_hits, length(subsets) - cache_hits))
  new_microbiome_result(
    method_id,
    status = if (length(unique(warnings))) "warning" else "success",
    marker_type = if (cross_domain) {
      "16S+ITS"
    } else {
      analysis_bundle$marker_type
    },
    data_version = analysis_bundle$data_version,
    input_summary = microbiome_data_summary(analysis_bundle),
    analysis_spec = public_spec, actual_parameters = public_spec,
    execution_time = proc.time()[["elapsed"]] - started,
    random_seed = plot_spec$layout$seed,
    package_versions = microbiome_package_versions(
      c(
        "ggClusterNet", "phyloseq", "igraph", "ggplot2",
        if (stability_required) c("microeco", "meconetcomp"))),
    model_objects = list(
      engine = "ggclusternet2",
      corMicro = lapply(fits, `[[`, "cor_micro"),
      package_layout = lapply(fits, function(value) value$layout$model),
      ZiPiPlot = lapply(fits, `[[`, "zipi"),
      node_properties = lapply(fits, `[[`, "node_properties"),
      net_properties = lapply(fits, `[[`, "network_properties"),
      trans_network = trans_networks,
      meconetcomp = stability$objects),
    network_objects = list(
      engine = "ggclusternet2", graphs = graphs,
      layout_coordinates = coordinates, plot_spec = plot_spec,
      plot_specs = plot_specs),
    network_tables = tables, tables = tables, plots = plots,
    warnings = unique(warnings), runtime_log = runtime_log,
    available_outputs = names(tables), available_plots = names(plots),
    generated_code = microbiome_ggclusternet_code(
      public_spec, cross_domain),
    registration_manifest = microbiome_registration_manifest(
      analysis_bundle, method_id, names(tables)))
}

microbiome_render_network_result <- function(result, spec) {
  if (!identical(
      result$network_objects$engine %||%
        result$actual_parameters$network_engine,
      "ggclusternet2")) {
    return(microbiome_render_netcomi_result_network(result, spec))
  }
  base_spec <- result$network_objects$plot_spec %||% list()
  use_package_layout <- startsWith(
    spec$layout$algorithm %||% "", "ggcluster_") &&
    identical(spec$layout$algorithm, base_spec$layout$algorithm)
  coordinates <- if (use_package_layout) {
    result$network_objects$layout_coordinates
  } else {
    microbiome_network_layout_coordinates(
      result$network_objects$graphs,
      algorithm = sub("^ggcluster_", "", spec$layout$algorithm),
      seed = spec$layout$seed,
      common_layout = length(result$network_objects$graphs) > 1L &&
        isTRUE(spec$layout$common_layout),
      iterations = spec$layout$iterations)
  }
  microbiome_render_network_publication(
    result$network_objects$graphs,
    result$tables$nodes, result$tables$edges, coordinates, spec)
}
