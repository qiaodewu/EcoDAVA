microbiome_rarefaction_diagnostics <- function(counts, steps = 8L) {
  depth <- rowSums(counts)
  positive <- depth[depth > 0]
  if (!length(positive)) return(data.frame())
  target_depths <- unique(pmax(1L, floor(seq(max(1, min(positive) * 0.1), min(positive), length.out = steps))))
  rows <- lapply(seq_len(nrow(counts)), function(index) {
    valid_depths <- target_depths[target_depths <= depth[[index]]]
    richness <- if (requireNamespace("vegan", quietly = TRUE)) {
      suppressWarnings(as.numeric(vegan::rarefy(counts[index, , drop = FALSE], sample = valid_depths)))
    } else {
      observed <- sum(counts[index, ] > 0)
      observed * (1 - exp(-valid_depths / max(depth[[index]], 1)))
    }
    data.frame(SampleID = rownames(counts)[[index]], Depth = valid_depths, Richness = richness)
  })
  do.call(rbind, rows)
}

microbiome_environment_diagnostics <- function(environment) {
  environment <- as.data.frame(environment, check.names = FALSE)
  if (!ncol(environment)) return(data.frame(variable = character(), missing = integer(), outliers = integer(), vif = numeric()))
  numeric_names <- names(environment)[vapply(environment, is.numeric, logical(1))]
  if (!length(numeric_names)) return(data.frame(variable = names(environment), missing = colSums(is.na(environment)), outliers = NA_integer_, vif = NA_real_))
  outliers <- vapply(environment[numeric_names], function(x) {
    bounds <- stats::quantile(x, c(0.25, 0.75), na.rm = TRUE)
    span <- diff(bounds)
    sum(x < bounds[[1]] - 1.5 * span | x > bounds[[2]] + 1.5 * span, na.rm = TRUE)
  }, integer(1))
  vif <- stats::setNames(rep(NA_real_, length(numeric_names)), numeric_names)
  complete <- stats::complete.cases(environment[numeric_names])
  if (sum(complete) > length(numeric_names) + 2L && length(numeric_names) > 1L) {
    vif[] <- vapply(numeric_names, function(name) {
      others <- setdiff(numeric_names, name)
      fit <- stats::lm(stats::reformulate(others, name), data = environment[complete, numeric_names, drop = FALSE])
      r2 <- summary(fit)$r.squared
      if (is.finite(r2) && r2 < 1) 1 / (1 - r2) else Inf
    }, numeric(1))
  }
  data.frame(variable = numeric_names, missing = colSums(is.na(environment[numeric_names])),
    outliers = unname(outliers), vif = unname(vif), stringsAsFactors = FALSE)
}

microbiome_preprocessing_diagnostics <- function(bundle, spec = list()) {
  aligned <- microbiome_align_bundle(bundle)$bundle
  counts <- microbiome_numeric_matrix(aligned$counts)
  totals <- colSums(counts)
  prevalence <- colMeans(counts > 0)
  minimum_total <- as.numeric(spec$minimum_total %||% 10)
  minimum_prevalence <- as.numeric(spec$minimum_prevalence %||% 0.1)
  abundance <- data.frame(Feature = colnames(counts), Total = totals, Prevalence = prevalence,
    Rare = totals < minimum_total | prevalence < minimum_prevalence, stringsAsFactors = FALSE)
  rare_fraction <- mean(abundance$Rare)
  rarefaction <- microbiome_rarefaction_diagnostics(counts)
  pcoa <- data.frame()
  if (nrow(counts) >= 3L && requireNamespace("vegan", quietly = TRUE)) {
    distance <- vegan::vegdist(counts, method = "bray")
    points <- stats::cmdscale(distance, k = 2, add = TRUE)$points
    radius <- sqrt(rowSums(scale(points, center = TRUE, scale = FALSE)^2))
    cutoff <- stats::median(radius) + 3 * stats::mad(radius)
    pcoa <- data.frame(SampleID = rownames(points), Axis1 = points[, 1], Axis2 = points[, 2],
      Outlier = radius > cutoff, stringsAsFactors = FALSE)
  }
  depth <- data.frame(SampleID = rownames(counts), SequencingDepth = rowSums(counts),
    ObservedFeatures = rowSums(counts > 0), stringsAsFactors = FALSE)
  environment <- if (ncol(aligned$environment)) aligned$environment else aligned$metadata
  environment_quality <- microbiome_environment_diagnostics(environment)
  plots <- list()
  if (requireNamespace("ggplot2", quietly = TRUE)) {
    if (nrow(rarefaction)) plots$rarefaction_curve <- ggplot2::ggplot(rarefaction, ggplot2::aes(Depth, Richness, group = SampleID)) +
      ggplot2::geom_line(alpha = 0.35, colour = "#2878B5", linewidth = 0.6) + ggplot2::theme_classic() +
      ggplot2::labs(title = "Sample rarefaction curves", x = "Sequencing depth", y = "Expected richness")
    plots$feature_abundance <- ggplot2::ggplot(abundance, ggplot2::aes(Total, fill = Rare)) +
      ggplot2::geom_histogram(bins = 30, colour = "white") + ggplot2::scale_x_log10() + ggplot2::theme_classic() +
      ggplot2::labs(title = "ASV abundance distribution", x = "Total abundance (log10)", y = "Feature count", fill = "Rare")
    if (nrow(pcoa)) plots$bray_pcoa_outliers <- ggplot2::ggplot(pcoa, ggplot2::aes(Axis1, Axis2, colour = Outlier)) +
      ggplot2::geom_point(size = 2.8) + ggplot2::scale_colour_manual(values = c(`FALSE` = "#2878B5", `TRUE` = "#D73027")) +
      ggplot2::theme_classic() + ggplot2::labs(title = "Bray-Curtis PCoA outlier screening", colour = "Outlier")
  }
  list(tables = list(sequencing_depth = depth, feature_abundance = abundance,
      rare_feature_summary = data.frame(metric = c("rare_feature_fraction", "rare_feature_count"),
        value = c(rare_fraction, sum(abundance$Rare))), environment_quality = environment_quality,
      bray_pcoa_scores = pcoa), plots = plots)
}

microbiome_validate_rarefaction_counts <- function(counts) {
  counts <- microbiome_numeric_matrix(counts)
  if (!nrow(counts) || !ncol(counts)) {
    stop("The abundance table has no samples and features available for smoothing.", call. = FALSE)
  }
  if (any(!is.finite(counts))) {
    stop("Abundance table contains NA, Inf, or non-numeric values and cannot be flattened.", call. = FALSE)
  }
  if (any(counts < 0)) {
    stop("The abundance table contains negative values ​​and cannot be flattened.", call. = FALSE)
  }
  integer_tolerance <- sqrt(.Machine$double.eps)
  if (any(abs(counts - round(counts)) > integer_tolerance)) {
    stop("Flattening only works on unconverted non-negative integer counts.", call. = FALSE)
  }
  counts
}

microbiome_rarefy_counts <- function(counts, depth) {
  counts <- microbiome_validate_rarefaction_counts(counts)
  withCallingHandlers(
    vegan::rrarefy(counts, sample = depth),
    warning = function(warning) {
      if (grepl("function should be used for observed counts",
          conditionMessage(warning), fixed = TRUE)) {
        invokeRestart("muffleWarning")
      }
    }
  )
}

microbiome_resolve_rarefaction_depth <- function(bundle, spec = list()) {
  counts <- microbiome_validate_rarefaction_counts(
    microbiome_align_bundle(bundle)$bundle$counts)
  depths <- rowSums(counts)
  if (!length(depths) || any(!is.finite(depths)) || any(depths < 1)) {
    stop("The abundance table contains empty samples, non-finite values, or no valid counts, and the drawdown depth cannot be calculated.",
      call. = FALSE)
  }
  minimum_depth <- suppressWarnings(as.integer(min(depths)))
  if (!length(minimum_depth) || is.na(minimum_depth) || minimum_depth < 1L) {
    stop("The effective drawdown depth cannot be calculated from the abundance table.", call. = FALSE)
  }
  mode <- spec$rarefaction_depth_mode %||% "minimum"
  if (identical(mode, "minimum")) return(minimum_depth)
  depth <- suppressWarnings(as.integer(spec$rarefaction_depth %||% minimum_depth))
  if (!is.finite(depth) || depth < 1L) stop("Custom flushing depth must be a positive integer.", call. = FALSE)
  depth
}

microbiome_apply_preprocessing <- function(bundle, spec = list()) {
  strategy <- spec$preprocess_strategy %||% "none"
  if (strategy == "none") return(bundle)
  if (strategy == "rarefy") {
    if (!requireNamespace("vegan", quietly = TRUE)) stop("Rarefaction requires the vegan package.", call. = FALSE)
    aligned <- microbiome_align_bundle(bundle)$bundle
    counts <- microbiome_numeric_matrix(aligned$counts)
    depth <- microbiome_resolve_rarefaction_depth(aligned, spec)
    if (!is.finite(depth) || depth < 1L || any(rowSums(counts) < depth)) stop("Rarefaction depth exceeds one or more sample depths.", call. = FALSE)
    set.seed(as.integer(spec$seed %||% 2026L))
    aligned$counts <- as.data.frame(
      microbiome_rarefy_counts(counts, depth), check.names = FALSE)
    aligned$transform <- "rarefy"
    aligned$is_raw_count <- TRUE
    aligned$data_version <- paste0(aligned$data_version, "_rarefied")
    return(aligned)
  }
  pseudocount <- if (strategy == "clr") as.numeric(spec$pseudocount %||% 0.5) else NULL
  microbiome_transform_bundle(bundle, strategy, pseudocount)
}

microbiome_attach_preprocessing_diagnostics <- function(result, diagnostics, spec = result$actual_parameters %||% list()) {
  if (!inherits(result, "microbiome_result")) return(result)
  diagnostic_tables <- diagnostics$tables %||% list()
  diagnostic_plots <- diagnostics$plots %||% list()
  if (!identical(result$status %||% "success", "success")) diagnostic_plots <- list()
  prefix_names <- function(values) {
    if (!length(values)) return(values)
    value_names <- names(values)
    if (is.null(value_names)) value_names <- rep("", length(values))
    missing_names <- !nzchar(value_names)
    value_names[missing_names] <- paste0("diagnostic_", which(missing_names))
    names(values) <- paste0("preprocess_", value_names)
    values
  }
  diagnostic_tables <- prefix_names(diagnostic_tables)
  diagnostic_plots <- prefix_names(diagnostic_plots)
  result$tables <- c(result$tables, diagnostic_tables)
  result$plots <- c(result$plots, diagnostic_plots)
  result$available_outputs <- names(result$tables)
  result$available_plots <- names(result$plots)
  result$actual_parameters <- utils::modifyList(result$actual_parameters %||% list(), spec)
  strategy <- spec$preprocess_strategy %||% "none"
  preprocessing_code <- switch(strategy,
    rarefy = sprintf("set.seed(%d)\nanalysis_bundle$counts <- as.data.frame(vegan::rrarefy(as.matrix(bundle$counts), sample = %d))",
      as.integer(spec$seed %||% 2026L), as.integer(spec$rarefaction_depth %||% 1000L)),
    hellinger = "analysis_bundle <- microbiome_transform_bundle(bundle, 'hellinger')",
    clr = sprintf("analysis_bundle <- microbiome_transform_bundle(bundle, 'clr', pseudocount = %s)",
      format(as.numeric(spec$pseudocount %||% 0.5), scientific = FALSE)),
    relative = "analysis_bundle <- microbiome_transform_bundle(bundle, 'relative')",
    presence_absence = "analysis_bundle <- microbiome_transform_bundle(bundle, 'presence_absence')",
    "analysis_bundle <- bundle"
  )
  result$generated_code <- paste(
    "# Data checking and method-aware preprocessing",
    "preprocessing_diagnostics <- microbiome_preprocessing_diagnostics(bundle)",
    preprocessing_code,
    "",
    "# Method analysis",
    result$generated_code,
    sep = "\n"
  )
  result
}

microbiome_model_text <- function(result) {
  if (is.null(result)) return("")
  sections <- c(
    "============================================================",
    sprintf("Microbiome analysis: %s", result$method_label %||% result$method_id),
    "============================================================",
    sprintf("Status: %s", result$status %||% ""),
    sprintf("Data version: %s", result$data_version %||% ""),
    sprintf("Execution time: %s seconds", signif(result$execution_time %||% NA_real_, 4))
  )
  if (identical(result$method_id %||% "", "ancombc2")) {
    engine <- result$actual_parameters$differential_method %||% "ancombc2"
    engine_label <- c(
      deseq2 = "DESeq2", edger = "edgeR", ancombc2 = "ANCOM-BC2"
    )[[engine]] %||% engine
    sections <- c(sections, sprintf("Differential taxa engine: %s", engine_label))
  }
  render_object <- function(name, value) {
    text <- paste(utils::capture.output(print(value)), collapse = "\n")
    paste0("\n--- ", name, " ---\n", text)
  }
  for (name in names(result$statistics %||% list())) {
    if (is.data.frame(result$statistics)) break
    sections <- c(sections, render_object(name, result$statistics[[name]]))
  }
  if (is.data.frame(result$statistics) && nrow(result$statistics)) {
    sections <- c(sections, render_object("Statistics", result$statistics))
  }
  for (name in names(result$tables %||% list())) sections <- c(sections, render_object(name, result$tables[[name]]))
  if (length(result$warnings)) sections <- c(sections, "\n--- Warnings ---", result$warnings)
  if (length(result$errors)) sections <- c(sections, "\n--- Errors ---", result$errors)
  paste(sections, collapse = "\n")
}
