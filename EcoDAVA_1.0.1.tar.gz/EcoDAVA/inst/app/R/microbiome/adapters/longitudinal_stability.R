microbiome_longitudinal_roles <- function(bundle, spec) {
  metadata <- bundle$metadata
  subject_name <- spec$subject_or_plot_id %||% "PlotID"
  time_name <- spec$time %||% "Year"
  if (!all(c(subject_name, time_name) %in% names(metadata))) stop("Longitudinal analysis requires a valid Subject/Plot ID and time variable.", call. = FALSE)
  subject <- factor(metadata[[subject_name]])
  time <- metadata[[time_name]]
  if (anyNA(subject) || anyNA(time) || any(table(subject) < 2)) stop("At least two complete time points are required for each longitudinal subject.", call. = FALSE)
  list(metadata = metadata, subject_name = subject_name, time_name = time_name, subject = subject, time = time)
}

microbiome_run_longitudinal <- function(method_id, bundle, spec = list()) {
  started <- proc.time()[["elapsed"]]
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  roles <- microbiome_longitudinal_roles(bundle, spec)
  counts <- microbiome_numeric_matrix(bundle$counts)
  seed <- as.integer(spec$seed %||% 2026L)
  if (method_id == "temporal_beta") {
    if (!requireNamespace("vegan", quietly = TRUE)) stop("The vegan package is missing.", call. = FALSE)
    rows <- lapply(levels(roles$subject), function(subject) {
      index <- which(roles$subject == subject)
      index <- index[order(roles$time[index], seq_along(index))]
      if (length(index) < 2) return(NULL)
      data.frame(Subject = subject, FromSample = rownames(counts)[head(index, -1)], ToSample = rownames(counts)[tail(index, -1)],
        FromTime = head(roles$time[index], -1), ToTime = tail(roles$time[index], -1),
        BrayCurtis = vapply(seq_len(length(index) - 1), function(position) as.numeric(vegan::vegdist(counts[index[c(position, position + 1)], , drop = FALSE], method = "bray")), numeric(1)), stringsAsFactors = FALSE)
    })
    transitions <- do.call(rbind, rows)
    summary <- aggregate(BrayCurtis ~ FromTime + ToTime, transitions, function(value) c(mean = mean(value), sd = stats::sd(value), n = length(value)))
    tables <- list(transitions = transitions, time_summary = summary)
    packages <- "vegan"
    model <- list()
    warnings <- character()
  } else if (method_id == "longitudinal_lmm") {
    if (!requireNamespace("lme4", quietly = TRUE)) stop("Missing lme4 package.", call. = FALSE)
    relative <- counts / rowSums(counts)
    shannon <- -rowSums(ifelse(relative > 0, relative * log(relative), 0))
    model_data <- roles$metadata
    model_data$Shannon <- shannon
    model_data$Subject <- roles$subject
    fixed <- spec$fixed_effects %||% intersect(c("Treatment", roles$time_name), names(model_data))
    if (!length(fixed)) stop("Longitudinal LMM requires at least one fixed effect.", call. = FALSE)
    formula <- stats::as.formula(paste("Shannon ~", paste(fixed, collapse = " + "), "+ (1 | Subject)"))
    fit <- lme4::lmer(formula, data = model_data, REML = TRUE)
    coefficient <- as.data.frame(summary(fit)$coefficients)
    coefficient$term <- rownames(coefficient)
    rownames(coefficient) <- NULL
    variance <- as.data.frame(lme4::VarCorr(fit))
    diagnostics <- data.frame(converged = is.null(fit@optinfo$conv$lme4$messages), singular = lme4::isSingular(fit))
    tables <- list(fixed_effects = coefficient, random_effects = variance, diagnostics = diagnostics,
                   fitted = data.frame(SampleID = rownames(counts), Observed = shannon, Fitted = stats::fitted(fit), Residual = stats::residuals(fit)))
    packages <- "lme4"
    model <- fit
    warnings <- if (diagnostics$singular) "The mixed model is a singular fit, please check the random effects informativeness." else character()
    spec$fixed_effects <- fixed
  } else stop("Portrait adapter does not support method:", method_id, call. = FALSE)
  spec$subject_or_plot_id <- roles$subject_name
  spec$time <- roles$time_name
  new_microbiome_result(method_id, status = if (length(warnings)) "warning" else "success", marker_type = bundle$marker_type,
    data_version = bundle$data_version, input_summary = microbiome_data_summary(bundle, aligned$orientation), analysis_spec = spec,
    actual_parameters = spec, package_versions = microbiome_package_versions(packages), random_seed = seed,
    execution_time = proc.time()[["elapsed"]] - started, model_objects = list(fit = model), tables = tables,
    diagnostics = tables$diagnostics %||% data.frame(), warnings = warnings, available_outputs = names(tables),
    generated_code = microbiome_longitudinal_code(method_id, spec), registration_manifest = microbiome_registration_manifest(bundle, method_id, names(tables)))
}
