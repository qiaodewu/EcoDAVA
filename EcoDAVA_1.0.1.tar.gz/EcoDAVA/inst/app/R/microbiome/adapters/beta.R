microbiome_distance <- function(bundle, method = "bray") {
  if (!requireNamespace("vegan", quietly = TRUE)) stop("Unable to calculate ecological distance due to missing vegan package.", call. = FALSE)
  allowed <- c("bray", "jaccard", "sorensen", "euclidean", "hellinger", "aitchison", "unifrac", "weighted_unifrac")
  if (!method %in% allowed) stop("Distance is not currently implemented:", method, call. = FALSE)
  counts <- microbiome_numeric_matrix(bundle$counts)
  if (method == "hellinger") return(stats::dist(vegan::decostand(counts, method = "hellinger")))
  if (method == "aitchison") {
    clr <- log(counts + 0.5)
    clr <- clr - rowMeans(clr)
    return(stats::dist(clr))
  }
  if (method %in% c("unifrac", "weighted_unifrac")) {
    if (!requireNamespace("GUniFrac", quietly = TRUE) || is.null(bundle$phylogeny)) stop("UniFrac distance requires the GUniFrac package and phylogenetic trees.", call. = FALSE)
    distances <- GUniFrac::GUniFrac(counts, bundle$phylogeny, alpha = c(0, 1))$unifracs
    return(stats::as.dist(distances[, , if (method == "unifrac") "d_UW" else "d_1"]))
  }
  vegan::vegdist(counts, method = if (method == "sorensen") "bray" else method,
    binary = method %in% c("jaccard", "sorensen"))
}

microbiome_beta_significance <- function(distance, metadata, group_names,
                                          method = "permanova_permdisp", permutations = 999L) {
  if (identical(method, "none")) return(list(tables = list(), models = list()))
  group_names <- intersect(unique(as.character(group_names %||% character())), names(metadata))
  if (!length(group_names)) stop("Community difference significance testing requires at least one valid metadata categorical variable.", call. = FALSE)

  complete <- stats::complete.cases(metadata[, group_names, drop = FALSE])
  if (sum(complete) < 3L) stop("The number of complete samples for the grouping variable is insufficient to conduct a significance test for community differences.", call. = FALSE)
  test_metadata <- droplevels(metadata[complete, group_names, drop = FALSE])
  group_names <- group_names[vapply(test_metadata, function(value) {
    nlevels(factor(value)) >= 2L
  }, logical(1))]
  if (!length(group_names)) stop("None of the selected grouping variables has less than two valid levels.", call. = FALSE)
  test_metadata <- test_metadata[, group_names, drop = FALSE]
  matrix <- as.matrix(distance)
  test_distance <- stats::as.dist(matrix[complete, complete, drop = FALSE])
  permutations <- as.integer(permutations %||% 999L)
  tables <- list()
  models <- list()
  summaries <- list()

  if (method %in% c("permanova", "permanova_permdisp")) {
    formula <- stats::reformulate(group_names, response = "test_distance")
    fit <- vegan::adonis2(formula, data = test_metadata, permutations = permutations)
    table <- data.frame(term = rownames(fit), fit, row.names = NULL, check.names = FALSE)
    tables$permanova <- table
    models$permanova <- fit
    term_rows <- !table$term %in% c("Residual", "Total")
    summaries[[length(summaries) + 1L]] <- data.frame(
      test = "PERMANOVA", grouping = table$term[term_rows],
      statistic = table$F[term_rows], p_value = table[["Pr(>F)"]][term_rows],
      permutations = permutations, stringsAsFactors = FALSE)
  }

  if (method %in% c("permdisp", "permanova_permdisp")) {
    dispersion_tables <- list()
    for (group_name in group_names) {
      group <- factor(test_metadata[[group_name]])
      dispersion <- vegan::betadisper(test_distance, group)
      fit <- vegan::permutest(dispersion, permutations = permutations)
      table <- data.frame(grouping = group_name, term = rownames(fit$tab), fit$tab,
        row.names = NULL, check.names = FALSE)
      dispersion_tables[[group_name]] <- table
      models[[paste0("permdisp_", group_name)]] <- list(dispersion = dispersion, test = fit)
      summaries[[length(summaries) + 1L]] <- data.frame(
        test = "PERMDISP", grouping = group_name, statistic = table$F[[1]],
        p_value = table[["Pr(>F)"]][[1]], permutations = permutations,
        stringsAsFactors = FALSE)
    }
    tables$permdisp <- do.call(rbind, dispersion_tables)
    rownames(tables$permdisp) <- NULL
  }

  if (method %in% c("anosim", "mrpp")) {
    test_tables <- list()
    for (group_name in group_names) {
      group <- factor(test_metadata[[group_name]])
      fit <- if (method == "anosim") {
        vegan::anosim(test_distance, group, permutations = permutations)
      } else vegan::mrpp(test_distance, group, permutations = permutations)
      row <- if (method == "anosim") {
        data.frame(test = "ANOSIM", grouping = group_name,
          statistic = unname(fit$statistic), p_value = fit$signif,
          permutations = permutations, stringsAsFactors = FALSE)
      } else {
        data.frame(test = "MRPP", grouping = group_name, statistic = fit$A,
          p_value = fit$Pvalue, permutations = permutations, stringsAsFactors = FALSE)
      }
      test_tables[[group_name]] <- row
      models[[paste0(method, "_", group_name)]] <- fit
      summaries[[length(summaries) + 1L]] <- row
    }
    tables[[method]] <- do.call(rbind, test_tables)
    rownames(tables[[method]]) <- NULL
  }

  if (length(summaries)) {
    tables$community_significance_summary <- do.call(rbind, summaries)
    rownames(tables$community_significance_summary) <- NULL
  }
  list(tables = tables, models = models)
}

microbiome_beta_palette <- function(levels) {
  base <- c("#1B9E77", "#D95F02", "#7570B3", "#E7298A", "#66A61E", "#E6AB02", "#A6761D", "#1F78B4")
  stats::setNames(rep(base, length.out = length(levels)), levels)
}

microbiome_beta_ellipse_data <- function(scores, level = 0.95, points = 120L) {
  groups <- split(scores, scores$Group, drop = TRUE)
  polygons <- lapply(names(groups), function(group_name) {
    values <- groups[[group_name]][, c("Axis1", "Axis2"), drop = FALSE]
    if (nrow(values) < 3L || any(!is.finite(as.matrix(values)))) return(NULL)
    covariance <- stats::cov(values)
    decomposition <- eigen(covariance, symmetric = TRUE)
    largest <- max(decomposition$values, na.rm = TRUE)
    if (!is.finite(largest) || largest <= 0) return(NULL)
    regularized <- pmax(decomposition$values, largest * 1e-6)
    transform <- decomposition$vectors %*% diag(sqrt(regularized), nrow = 2L)
    angle <- seq(0, 2 * pi, length.out = points)
    circle <- rbind(cos(angle), sin(angle))
    polygon <- sweep(t(sqrt(stats::qchisq(level, df = 2L)) * transform %*% circle),
      2L, colMeans(values), "+")
    data.frame(Axis1 = polygon[, 1], Axis2 = polygon[, 2], Group = group_name,
      stringsAsFactors = FALSE)
  })
  polygons <- Filter(Negate(is.null), polygons)
  if (length(polygons)) do.call(rbind, polygons) else data.frame()
}

microbiome_beta_ordination_plot <- function(scores, x_label, y_label) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) return(NULL)
  if (!"Group" %in% names(scores)) {
    return(ggplot2::ggplot(scores, ggplot2::aes(Axis1, Axis2)) +
      ggplot2::geom_point(size = 3, alpha = 0.85, colour = "#1B9E77") +
      ggplot2::labs(x = x_label, y = y_label) + ggplot2::theme_bw(base_size = 13))
  }
  scores$Group <- droplevels(factor(scores$Group))
  levels <- levels(scores$Group)
  colours <- microbiome_beta_palette(levels)
  shapes <- stats::setNames(rep(c(16, 17, 7, 18, 15, 8, 3, 4), length.out = length(levels)), levels)
  ellipse_data <- microbiome_beta_ellipse_data(scores)
  plot <- ggplot2::ggplot(scores, ggplot2::aes(Axis1, Axis2, colour = Group, shape = Group))
  if (nrow(ellipse_data)) plot <- plot +
    ggplot2::geom_polygon(data = ellipse_data,
      ggplot2::aes(Axis1, Axis2, colour = Group, fill = Group, group = Group),
      inherit.aes = FALSE, alpha = 0.10, linewidth = 0.9, show.legend = FALSE) +
    ggplot2::scale_fill_manual(values = colours)
  plot +
    ggplot2::geom_point(size = 3.2, alpha = 0.86) +
    ggplot2::scale_colour_manual(values = colours) +
    ggplot2::scale_shape_manual(values = shapes) +
    ggplot2::labs(x = x_label, y = y_label, colour = "Group", shape = "Group") +
    ggplot2::theme_bw(base_size = 13) +
    ggplot2::theme(panel.grid.minor = ggplot2::element_blank(),
      legend.position = "right", legend.title = ggplot2::element_text(face = "plain"))
}

microbiome_beta_group_distance_plot <- function(distance, metadata, group_name, distance_label) {
  if (!requireNamespace("ggplot2", quietly = TRUE) || !group_name %in% names(metadata)) return(NULL)
  group <- droplevels(factor(metadata[[group_name]]))
  if (nlevels(group) < 2L || anyNA(group)) return(NULL)
  dispersion <- vegan::betadisper(distance, group)
  table <- data.frame(Group = group, Distance = as.numeric(dispersion$distances), stringsAsFactors = FALSE)
  levels <- levels(group)
  colours <- microbiome_beta_palette(levels)
  plot <- ggplot2::ggplot(table, ggplot2::aes(Group, Distance, colour = Group)) +
    ggplot2::geom_boxplot(width = 0.66, fill = "white", linewidth = 0.8, outlier.shape = NA) +
    ggplot2::stat_summary(fun = mean, geom = "point", size = 2.8, show.legend = FALSE) +
    ggplot2::scale_colour_manual(values = colours) +
    ggplot2::labs(x = NULL, y = paste(distance_label, "distance")) +
    ggplot2::theme_classic(base_size = 14) +
    ggplot2::theme(legend.position = "none", plot.margin = ggplot2::margin(8, 24, 8, 8))

  comparisons <- if (length(levels) >= 2L) utils::combn(levels, 2L, simplify = FALSE) else list()
  comparison_table <- if (length(comparisons)) do.call(rbind, lapply(comparisons, function(pair) {
    fit <- stats::wilcox.test(table$Distance[table$Group == pair[[1]]],
      table$Distance[table$Group == pair[[2]]], exact = FALSE)
    data.frame(group1 = pair[[1]], group2 = pair[[2]], p_value = fit$p.value,
      stringsAsFactors = FALSE)
  })) else data.frame()
  if (nrow(comparison_table)) {
    comparison_table$p_adjusted <- stats::p.adjust(comparison_table$p_value, method = "BH")
    comparison_table$significance <- cut(comparison_table$p_adjusted,
      breaks = c(-Inf, 0.001, 0.01, 0.05, Inf), labels = c("***", "**", "*", "ns"))
    annotations <- comparison_table[comparison_table$p_adjusted < 0.05, , drop = FALSE]
    if (nrow(annotations) && requireNamespace("ggpubr", quietly = TRUE)) {
      spread <- diff(range(table$Distance, na.rm = TRUE))
      if (!is.finite(spread) || spread == 0) spread <- max(abs(table$Distance), 1) * 0.1
      annotations$y.position <- max(table$Distance, na.rm = TRUE) +
        seq_len(nrow(annotations)) * spread * 0.13
      plot <- plot + ggpubr::stat_pvalue_manual(annotations, label = "significance",
        xmin = "group1", xmax = "group2", y.position = "y.position",
        tip.length = 0.012, bracket.size = 0.45, size = 4, inherit.aes = FALSE) +
        ggplot2::coord_cartesian(clip = "off")
    }
  }
  list(plot = plot, distances = table, comparisons = comparison_table, model = dispersion)
}

microbiome_run_beta <- function(method_id, bundle, spec = list()) {
  started <- proc.time()[["elapsed"]]
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  distance_method <- spec$distance %||% "bray"
  distance <- microbiome_distance(bundle, distance_method)
  group_name <- spec$group %||% "Treatment"
  group <- if (nrow(bundle$metadata) && group_name %in% names(bundle$metadata)) factor(bundle$metadata[[group_name]]) else NULL
  seed <- as.integer(spec$seed %||% 2026L)
  set.seed(seed)
  if (method_id == "distance_matrix") {
    matrix <- as.matrix(distance)
    tables <- list(distance_matrix = data.frame(SampleID = rownames(matrix), matrix, check.names = FALSE))
    statistics <- data.frame(metric = c("samples", "minimum", "median", "maximum"),
      value = c(nrow(matrix), min(distance), stats::median(distance), max(distance)))
    model <- distance
    plots <- list()
  } else if (method_id == "pcoa") {
    fit <- stats::cmdscale(distance, eig = TRUE, add = TRUE, k = 2)
    scores <- data.frame(SampleID = rownames(fit$points), Axis1 = fit$points[, 1], Axis2 = fit$points[, 2], stringsAsFactors = FALSE)
    if (!is.null(group)) scores$Group <- group
    positive <- fit$eig[fit$eig > 0]
    statistics <- data.frame(metric = c("Axis1_explained", "Axis2_explained", "negative_eigenvalues"), value = c(positive[1] / sum(positive), positive[2] / sum(positive), sum(fit$eig < 0)))
    model <- fit
    tables <- list(scores = scores, eigenvalues = data.frame(Axis = seq_along(fit$eig), Eigenvalue = fit$eig))
    axis_labels <- c(sprintf("PCo1 [%.1f%%]", 100 * positive[1] / sum(positive)),
      sprintf("PCo2 [%.1f%%]", 100 * positive[2] / sum(positive)))
    plots <- list()
  } else if (method_id == "nmds") {
    fit <- vegan::metaMDS(distance, k = 2, trymax = as.integer(spec$trymax %||% 50L), trace = FALSE)
    points <- vegan::scores(fit, display = "sites")
    scores <- data.frame(SampleID = rownames(points), Axis1 = points[, 1], Axis2 = points[, 2], stringsAsFactors = FALSE)
    if (!is.null(group)) scores$Group <- group
    statistics <- data.frame(metric = "stress", value = fit$stress)
    model <- fit
    tables <- list(scores = scores, diagnostics = statistics)
    axis_labels <- c("NMDS1", "NMDS2")
    plots <- list()
  } else if (method_id == "pca") {
    transformed <- vegan::decostand(microbiome_numeric_matrix(bundle$counts), method = "hellinger")
    fit <- stats::prcomp(transformed, center = TRUE, scale. = FALSE)
    scores <- data.frame(SampleID = rownames(fit$x), Axis1 = fit$x[, 1], Axis2 = fit$x[, 2], stringsAsFactors = FALSE)
    if (!is.null(group)) scores$Group <- group
    explained <- summary(fit)$importance[2, ]
    statistics <- data.frame(metric = c("PC1_explained", "PC2_explained"), value = explained[1:2])
    model <- fit
    tables <- list(scores = scores, loadings = data.frame(Feature = rownames(fit$rotation), fit$rotation[, 1:2, drop = FALSE]))
    axis_labels <- c(sprintf("PC1 [%.1f%%]", 100 * explained[[1]]),
      sprintf("PC2 [%.1f%%]", 100 * explained[[2]]))
    plots <- list()
  } else if (method_id %in% c("permanova_permdisp", "permanova_interaction", "permanova_restricted")) {
    if (is.null(group) || nlevels(group) < 2) stop("PERMANOVA + PERMDISP requires at least two non-null groupings.", call. = FALSE)
    permutations <- as.integer(spec$permutations %||% 999L)
    metadata <- bundle$metadata
    metadata$.dava_group <- group
    fixed <- intersect(spec$fixed_effects %||% group_name, names(metadata))
    if (!length(fixed)) fixed <- ".dava_group"
    formula <- if (method_id == "permanova_interaction" && length(fixed) > 1L) {
      stats::as.formula(paste("distance ~", paste(fixed, collapse = " * ")))
    } else stats::reformulate(fixed, response = "distance")
    permutation_design <- permutations
    strata_name <- spec$strata %||% spec$random_effect %||% ""
    if (method_id == "permanova_restricted" && nzchar(strata_name) && strata_name %in% names(metadata)) {
      permutation_design <- permute::how(nperm = permutations)
      permute::setBlocks(permutation_design) <- factor(metadata[[strata_name]])
    }
    permanova <- vegan::adonis2(formula, data = metadata, permutations = permutation_design)
    dispersion <- vegan::betadisper(distance, group)
    permdisp <- vegan::permutest(dispersion, permutations = permutations)
    tables <- list(permanova = data.frame(term = rownames(permanova), permanova, row.names = NULL, check.names = FALSE),
                   permdisp = data.frame(term = rownames(permdisp$tab), permdisp$tab, row.names = NULL, check.names = FALSE))
    statistics <- data.frame(test = c("PERMANOVA", "PERMDISP"), permutations = permutations)
    model <- list(permanova = permanova, dispersion = dispersion, permdisp = permdisp)
    plots <- list()
    spec$permutations <- permutations
  } else if (method_id == "permdisp") {
    if (is.null(group) || nlevels(group) < 2) stop("PERMDISP requires at least two valid packets.", call. = FALSE)
    permutations <- as.integer(spec$permutations %||% 999L)
    dispersion <- vegan::betadisper(distance, group)
    fit <- vegan::permutest(dispersion, permutations = permutations)
    tables <- list(permdisp = data.frame(term = rownames(fit$tab), fit$tab, row.names = NULL, check.names = FALSE),
      distances_to_centroid = data.frame(SampleID = names(dispersion$distances), Group = group, Distance = dispersion$distances))
    statistics <- tables$permdisp
    model <- list(dispersion = dispersion, test = fit)
    plots <- list()
  } else if (method_id %in% c("anosim", "mrpp")) {
    if (is.null(group) || nlevels(group) < 2) stop("The community difference test requires at least two valid groupings.", call. = FALSE)
    permutations <- as.integer(spec$permutations %||% 999L)
    fit <- if (method_id == "anosim") vegan::anosim(distance, group, permutations = permutations) else vegan::mrpp(distance, group, permutations = permutations)
    statistics <- if (method_id == "anosim") data.frame(test = "ANOSIM", statistic = unname(fit$statistic), p_value = fit$signif) else
      data.frame(test = "MRPP", statistic = fit$A, p_value = fit$Pvalue, observed_delta = fit$delta)
    tables <- list(test_result = statistics)
    model <- fit
    plots <- list()
  } else if (method_id == "between_group_distance") {
    if (is.null(group) || nlevels(group) < 2) stop("Inter-group distance comparison requires at least two valid groups.", call. = FALSE)
    matrix <- as.matrix(distance)
    pairs <- which(upper.tri(matrix), arr.ind = TRUE)
    pairwise <- data.frame(Sample1 = rownames(matrix)[pairs[, 1]], Sample2 = colnames(matrix)[pairs[, 2]],
      Group1 = group[pairs[, 1]], Group2 = group[pairs[, 2]], Distance = matrix[pairs], stringsAsFactors = FALSE)
    pairwise$Comparison <- ifelse(pairwise$Group1 == pairwise$Group2, "Within group", "Between groups")
    fit <- stats::wilcox.test(Distance ~ Comparison, data = pairwise, exact = FALSE)
    statistics <- data.frame(test = fit$method, statistic = unname(fit$statistic), p_value = fit$p.value)
    tables <- list(pairwise_distances = pairwise, comparison_test = statistics)
    model <- fit
    plots <- list()
  } else if (method_id == "beta_cluster_heatmap") {
    matrix <- as.matrix(distance)
    fit <- stats::hclust(distance, method = spec$cluster_method %||% "average")
    tables <- list(distance_matrix = data.frame(SampleID = rownames(matrix), matrix, check.names = FALSE),
      cluster_order = data.frame(Order = seq_along(fit$order), SampleID = fit$labels[fit$order]))
    statistics <- data.frame(samples = nrow(matrix), linkage = fit$method)
    model <- fit
    plots <- list()
  } else stop("Beta adapter does not support method:", method_id, call. = FALSE)
  if (method_id %in% c("pcoa", "nmds", "pca")) {
    significance_groups <- spec$group_variables %||% group_name
    if (!length(significance_groups)) significance_groups <- group_name
    significance <- microbiome_beta_significance(
      distance, bundle$metadata, significance_groups,
      method = spec$beta_significance_test %||% "none",
      permutations = spec$permutations %||% 999L)
    if (length(significance$tables)) {
      tables <- c(tables, significance$tables)
      model <- list(ordination = model, significance = significance$models)
    }
    plots$ordination <- microbiome_beta_ordination_plot(scores, axis_labels[[1]], axis_labels[[2]])
    distance_plot <- microbiome_beta_group_distance_plot(
      distance, bundle$metadata, group_name,
      switch(distance_method, bray = "Bray-Curtis", jaccard = "Jaccard",
        euclidean = "Euclidean", hellinger = "Hellinger", aitchison = "Aitchison",
        distance_method))
    if (!is.null(distance_plot)) {
      plots$group_distance <- distance_plot$plot
      tables$group_distances <- distance_plot$distances
      tables$group_distance_comparisons <- distance_plot$comparisons
      if (is.list(model) && "ordination" %in% names(model)) {
        model$group_dispersion <- distance_plot$model
      }
    }
  }
  spec$distance <- distance_method
  spec$group <- group_name
  spec$group_variables <- unique(as.character(spec$group_variables %||% group_name))
  new_microbiome_result(method_id, marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle, aligned$orientation), analysis_spec = spec, actual_parameters = spec,
    package_versions = microbiome_package_versions("vegan"), random_seed = seed, execution_time = proc.time()[["elapsed"]] - started,
    model_objects = list(fit = model), tables = tables, statistics = statistics, ordination_scores = if (exists("scores")) scores else data.frame(),
    distance_matrix = distance, plots = plots, available_outputs = names(tables), available_plots = names(plots),
    generated_code = microbiome_analysis_code(method_id, spec), registration_manifest = microbiome_registration_manifest(bundle, method_id, names(tables)))
}
