microbiome_function_plot_choices <- function(method_id = "") {
  if (identical(method_id, "faprotax")) {
    return(c(
      "Function composition stacked diagram" = "function_composition",
      "Functional abundance heatmap" = "function_heatmap",
      "Top function bar chart" = "function_top_bar",
      "Grouped function box plot" = "function_group_boxplot",
      "Feature-Environment Spearman Correlation Heat Map" = "function_environment_correlation"))
  }
  if (method_id %in% c("funguild", "fungaltraits")) {
    return(c(
      "Functional trait abundance heatmap" = "function_heatmap",
      "Top Functional Histogram" = "function_top_bar",
      "Grouped functional trait box plot" = "function_group_boxplot"))
  }
  c(
    "Function composition stacked diagram" = "function_composition",
    "Functional abundance heatmap" = "function_heatmap",
    "Top function bar chart" = "function_top_bar",
    "Grouped function box plot" = "function_group_boxplot")
}

microbiome_metadata_by_sample <- function(metadata) {
  metadata <- as.data.frame(metadata, check.names = FALSE)
  if ("SampleID" %in% names(metadata) &&
      !all(as.character(metadata$SampleID) %in% rownames(metadata))) {
    rownames(metadata) <- as.character(metadata$SampleID)
  }
  metadata
}

microbiome_readonly_expression <- function(ns, value, rows = 5L) {
  htmltools::tagQuery(shiny::textAreaInput(
    ns("general_model_formula"), "Model formula / analytical expression",
    value = value, rows = rows, resize = "vertical"))$
    find("textarea")$addAttrs(readonly = "readonly")$allTags()
}

microbiome_function_analysis_expression <- function(
    method_id, group = "", current = list()) {
  group_text <- if (nzchar(group)) {
    paste0("\nfunction_abundance ~ ", group,
      "  # Wilcoxon/Kruskal-Wallis + BH")
  } else {
    ""
  }
  function_environment <- if (identical(method_id, "faprotax") &&
      isTRUE(current$function_environment_enabled) &&
      length(current$function_environment_variables %||% character())) {
    selected_environment <- paste(
      sprintf("'%s'", current$function_environment_variables), collapse = ", ")
    paste0(
      "Function-Environment Spearman correlation: env[c(", selected_environment,
      ")] -> microeco::trans_env$cal_cor(function_abundance) -> ",
      "plot_cor(cluster_ggplot = 'both')")
  } else ""
  paste0(switch(method_id,
    faprotax = "microeco::trans_func$cal_func(prok_database = 'FAPROTAX')",
    funguild = paste0(
      "microeco::trans_func$new(ITS_microtable)$cal_func(",
      "fungi_database = 'FUNGuild', FUNGuild_confidence = c(",
      paste(
        sprintf("'%s'", current$funguild_confidence %||%
          c("Highly Probable", "Probable", "Possible")),
        collapse = ", "),
      "))\ncal_func_FR(abundance_weighted = TRUE, perc = TRUE)"),
    fungaltraits = paste(
      "microeco::trans_func$new(ITS_microtable)$cal_func(",
      "fungi_database = 'FungalTraits')",
      "\ncal_func_FR(abundance_weighted = TRUE, perc = TRUE)"),
    tax4fun2 = paste(
      "microeco::trans_func$new(dataset)$cal_tax4fun2(",
      "path_to_reference_data = local_Ref99NR, database_mode = 'Ref99NR')"),
    picrust2_import = "PICRUSt2 completed result -> validated abundance-table import",
    bugbase_import = "BugBase completed result -> validated phenotype-table import",
        paste0(method_id, "(functional_data)")),
    if (nzchar(function_environment)) paste0("\n", function_environment) else "",
    group_text)
}

microbiome_tax4fun2_reference_path <- function(value = NULL) {
  candidate <- value %||% file.path(
    microbiome_project_root, "tools", "Tax4Fun2_ReferenceData_v2")
  normalizePath(candidate, winslash = "/", mustWork = FALSE)
}

microbiome_tax4fun2_blast_path <- function(value = NULL) {
  if (nzchar(value %||% "")) {
    return(normalizePath(value, winslash = "/", mustWork = FALSE))
  }
  if (nzchar(Sys.which("blastn"))) return(NULL)
  candidates <- unique(c(
    Sys.getenv("NCBI_BLAST_BIN", unset = ""),
    file.path(
      Sys.getenv("ProgramFiles", unset = "C:/Program Files"),
      "NCBI", "blast-2.5.0+", "bin"),
    file.path(
      Sys.getenv("ProgramFiles", unset = "C:/Program Files"),
      "NCBI", "blast-2.9.0+", "bin"),
    file.path(
      microbiome_project_root, "tools", "ncbi-blast-2.5.0+", "bin")))
  candidates <- candidates[nzchar(candidates)]
  matched <- candidates[file.exists(file.path(candidates, "blastn.exe"))]
  if (length(matched)) {
    normalizePath(matched[[1]], winslash = "/", mustWork = TRUE)
  } else {
    ""
  }
}

microbiome_tax4fun2_reference_urls <- function() {
  c(
    "GitHub" = paste0(
      "https://github.com/ChiLiubio/microeco_extra_data/releases/",
      "download/v1.0.0/Tax4Fun2_ReferenceData_v2.zip"),
    "Gitee" = paste0(
      "https://gitee.com/chiliubio/microeco_extra_data/releases/",
      "download/v1.0.0/Tax4Fun2_ReferenceData_v2.zip"))
}

microbiome_choose_directory <- function(default = getwd(), caption = "Select directory") {
  if (exists("dava_choose_directory", mode = "function")) {
    return(dava_choose_directory(default = default, caption = caption))
  }
  NA_character_
}

microbiome_download_tax4fun2_reference <- function(
    destination_parent, preferred_source = "GitHub") {
  destination_parent <- normalizePath(
    destination_parent, winslash = "/", mustWork = FALSE)
  if (!dir.exists(destination_parent) &&
      !dir.create(destination_parent, recursive = TRUE)) {
    stop("Unable to create the selected download directory:", destination_parent, call. = FALSE)
  }
  destination <- file.path(
    destination_parent, "Tax4Fun2_ReferenceData_v2")
  if (dir.exists(destination) && length(list.files(
      destination, all.files = TRUE, no.. = TRUE))) {
    stop(
      "A non-empty Tax4Fun2_ReferenceData_v2 folder already exists in the selected directory;",
      "Please use this path directly, or choose another download directory.", call. = FALSE)
  }

  urls <- microbiome_tax4fun2_reference_urls()
  preferred_source <- as.character(preferred_source %||% "GitHub")[[1]]
  source_order <- unique(c(preferred_source, names(urls)))
  source_order <- source_order[source_order %in% names(urls)]
  archive <- tempfile("dava-tax4fun2-reference-", fileext = ".zip")
  on.exit(unlink(archive, force = TRUE), add = TRUE)
  old_timeout <- getOption("timeout")
  options(timeout = max(600, old_timeout %||% 60))
  on.exit(options(timeout = old_timeout), add = TRUE)
  errors <- character()
  downloaded_source <- ""
  for (source in source_order) {
    result <- tryCatch({
      utils::download.file(
        urls[[source]], archive, mode = "wb", quiet = TRUE)
      if (!file.exists(archive) || file.info(archive)$size <= 0) {
        stop("Download file is empty")
      }
      TRUE
    }, error = function(error) {
      errors[[source]] <<- conditionMessage(error)
      FALSE
    })
    if (isTRUE(result)) {
      downloaded_source <- source
      break
    }
  }
  if (!nzchar(downloaded_source)) {
    stop(
      "Tax4Fun2 reference database download failed.",
      paste(sprintf("%s：%s", names(errors), errors), collapse = "；"),
      call. = FALSE)
  }

  entries <- utils::unzip(archive, list = TRUE)$Name
  normalized_entries <- gsub("\\\\", "/", entries)
  unsafe <- grepl("^(/|[A-Za-z]:)", normalized_entries) |
    grepl("(^|/)\\.\\.(/|$)", normalized_entries)
  if (!length(entries) || any(unsafe)) {
    stop("The downloaded Tax4Fun2 zip package structure is invalid.", call. = FALSE)
  }
  staging <- tempfile(".dava-tax4fun2-extract-", tmpdir = destination_parent)
  dir.create(staging)
  on.exit(unlink(staging, recursive = TRUE, force = TRUE), add = TRUE)
  utils::unzip(archive, exdir = staging)
  candidates <- list.dirs(staging, recursive = TRUE, full.names = TRUE)
  reference_root <- candidates[
    basename(candidates) == "Tax4Fun2_ReferenceData_v2"]
  if (length(reference_root)) {
    reference_root <- reference_root[[1]]
  } else if (all(c("Ref99NR", "Ref100NR") %in% basename(list.dirs(
      staging, recursive = FALSE, full.names = TRUE)))) {
    reference_root <- staging
  } else {
    stop(
      "The Tax4Fun2_ReferenceData_v2 reference database was not found in the downloaded archive.",
      call. = FALSE)
  }
  if (dir.exists(destination)) unlink(destination, recursive = TRUE, force = TRUE)
  if (!file.rename(reference_root, destination)) {
    stop("Unable to move the unpacked reference database to the selected directory.", call. = FALSE)
  }
  list(
    path = normalizePath(destination, winslash = "/", mustWork = TRUE),
    source = downloaded_source)
}

microbiome_tax4fun2_advanced_field_ids <- function() {
  c(
    "tax4fun2_reference_path", "tax4fun2_blast_path",
    "tax4fun2_database_mode", "tax4fun2_min_identity",
    "tax4fun2_threads", "tax4fun2_copy_number",
    "tax4fun2_use_uproc", "tax4fun2_cal_fri")
}

microbiome_tax4fun2_advanced_ui <- function(ns, current = list()) {
  reference_path <- microbiome_tax4fun2_reference_path(
    current$tax4fun2_reference_path)
  blast_path <- microbiome_tax4fun2_blast_path(
    current$tax4fun2_blast_path)
  block <- function(title, package_function, ...) {
    shiny::div(
      class = "border rounded p-2 mb-2",
      shiny::div(
        class = "d-flex justify-content-between align-items-center mb-2",
        shiny::tags$strong(title),
        shiny::span(class = "badge text-bg-light", package_function)),
      ...)
  }
  shiny::tagList(
    shiny::tags$style(
      ".tax4fun2-advanced .form-group{margin-bottom:.45rem}.tax4fun2-advanced .row{--bs-gutter-x:.65rem}"),
    shiny::div(
      class = "tax4fun2-advanced",
      block(
        "Local database and BLAST", "microeco::trans_func$cal_tax4fun2",
        shiny::textInput(
          ns("tax4fun2_reference_path"), "Tax4Fun2_ReferenceData_v2 path",
          reference_path),
        shiny::fluidRow(
          shiny::column(
            5,
            shiny::selectInput(
              ns("tax4fun2_reference_source"), "Reference library download source",
              stats::setNames(
                names(microbiome_tax4fun2_reference_urls()),
                names(microbiome_tax4fun2_reference_urls())),
              selected = "GitHub")),
          shiny::column(
            7,
            shiny::tags$label(class = "form-label d-block", "Download and unzip"),
            shiny::actionButton(
              ns("tax4fun2_download_reference"),
              "Select path and download Tax4Fun2_ReferenceData_v2",
              icon = shiny::icon("download"),
              class = "btn-outline-primary w-100"))),
        shiny::div(
          class = "small text-muted mb-2",
          "When downloading, first choose to save the parent directory; after completion, it will automatically decompress and backfill the reference library path.",
          "Automatically tries another download source when the preferred download source is unavailable."),
        shiny::textInput(
          ns("tax4fun2_blast_path"),
          "NCBI BLAST bin path (can be left empty if PATH is available)",
          blast_path %||% ""),
        shiny::tags$a(
          href = "https://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/2.5.0/",
          target = "_blank", rel = "noopener noreferrer",
          class = "btn btn-outline-secondary btn-sm mb-2",
          shiny::icon("external-link-alt"),
          " Download NCBI BLAST+ 2.5.0 according to the current operating system"),
        shiny::uiOutput(ns("tax4fun2_blast_status")),
        shiny::selectInput(
          ns("tax4fun2_database_mode"), "Reference database",
          c("Ref99NR" = "Ref99NR", "Ref100NR" = "Ref100NR"),
          selected = current$tax4fun2_database_mode %||% "Ref99NR")),
      block(
        "Sequence matching and prediction", "microeco::trans_func$cal_tax4fun2",
        shiny::fluidRow(
          shiny::column(
            6,
            shiny::numericInput(
              ns("tax4fun2_min_identity"), "Minimum sequence identity (%)",
              as.numeric(current$tax4fun2_min_identity %||% 97),
              min = 90, max = 100, step = 0.5)),
          shiny::column(
            6,
            shiny::numericInput(
              ns("tax4fun2_threads"), "BLAST thread count",
              as.integer(current$tax4fun2_threads %||%
                dava_available_cores(logical = TRUE, reserve = 1L)),
              min = 1L, step = 1L))),
        shiny::checkboxInput(
          ns("tax4fun2_copy_number"), "Normalized by 16S copy number",
          isTRUE(current$tax4fun2_copy_number %||% TRUE)),
        shiny::checkboxInput(
          ns("tax4fun2_use_uproc"), "Using UProC Reference Feature Column",
          isTRUE(current$tax4fun2_use_uproc %||% TRUE))),
      block(
        "Functional redundancy index", "microeco::trans_func$cal_tax4fun2_FRI",
        shiny::checkboxInput(
          ns("tax4fun2_cal_fri"),
          "Calculate absolute/relative functional redundancy index (time consuming)",
          isTRUE(current$tax4fun2_cal_fri %||% FALSE)),
        shiny::div(
          class = "small text-muted",
          "FRI will traverse the phylogenetic distance between KO and reference sequences. It is recommended to enable it as needed after completing the basic prediction."))))
}

microbiome_function_analysis_ui <- function(
    ns, method_id, metadata, current = list(), environment = data.frame()) {
  categorical <- names(metadata)[vapply(metadata, function(value) {
    count <- length(unique(value[!is.na(value)]))
    count >= 2L && count <= 12L &&
      (is.factor(value) || is.character(value) || is.logical(value) ||
        count <= 8L)
  }, logical(1))]
  group <- current$group %||% ""
  if (!group %in% categorical) {
    group <- if ("Treatment" %in% categorical) "Treatment" else
      if (length(categorical)) categorical[[1]] else ""
  }
  plot_choices <- microbiome_function_plot_choices(method_id)
  environment <- microbiome_metadata_by_sample(environment)
  environment_choices <- names(environment)[vapply(
    environment, function(value) is.numeric(value) &&
      length(unique(value[is.finite(value)])) > 1L, logical(1))]
  environment_enabled <- identical(method_id, "faprotax") &&
    isTRUE(current$function_environment_enabled)
  if (identical(method_id, "faprotax") && !environment_enabled) {
    plot_choices <- plot_choices[
      unname(plot_choices) != "function_environment_correlation"]
  }
  selected <- intersect(
    current$plot_types %||% unname(plot_choices), unname(plot_choices))
  if (!length(selected)) selected <- unname(plot_choices)
  selected_environment <- intersect(
    as.character(current$function_environment_variables %||% character()),
    environment_choices)
  shiny::tagList(
    if (identical(method_id, "funguild")) {
      shiny::selectizeInput(
        ns("funguild_confidence"), "FUNGuild Confidence Level",
        c("Highly Probable", "Probable", "Possible"),
        selected = current$funguild_confidence %||%
          c("Highly Probable", "Probable", "Possible"),
        multiple = TRUE,
        options = list(
          plugins = list("remove_button"), closeAfterSelect = FALSE))
    },
    if (method_id %in% c("funguild", "fungaltraits")) {
      shiny::checkboxInput(
        ns("fungal_fr_abundance_weighted"), "Abundance weighted functional redundancy",
        isTRUE(current$fungal_fr_abundance_weighted %||% TRUE))
    },
    if (method_id %in% c("funguild", "fungaltraits")) {
      shiny::checkboxInput(
        ns("fungal_fr_percent"), "Output as relative abundance percentage",
        isTRUE(current$fungal_fr_percent %||% TRUE))
    },
    shiny::selectInput(
      ns("group"), "Grouping variables",
      c("Do not perform group testing" = "", stats::setNames(categorical, categorical)),
      selected = group),
    if (identical(method_id, "faprotax")) shiny::checkboxInput(
      ns("function_environment_enabled"), "Function-Environment Variable Association",
      value = environment_enabled),
    if (identical(method_id, "faprotax")) {
      shiny::conditionalPanel(
        condition = sprintf("input['%s'] === true", ns("function_environment_enabled")),
        shiny::selectizeInput(
          ns("function_environment_variables"), "Environment variables",
          choices = environment_choices, selected = selected_environment,
          multiple = TRUE,
          options = list(
            plugins = list("remove_button"),
            closeAfterSelect = FALSE)))
    },
    dava_i18n_preserve_choice_language(shiny::selectInput(
      ns("p_adjust_method"), "Multiple comparison correction",
      c("FDR (BH)" = "BH", "Holm" = "holm",
        "Bonferroni" = "bonferroni", "No correction" = "none"),
      selected = current$p_adjust_method %||% "BH")),
    shiny::tags$hr(class = "my-3"),
    shiny::uiOutput(ns("function_analysis_expression")),
    shiny::selectizeInput(
      ns("function_plot_types"), "Drawing type",
      plot_choices, selected = selected, multiple = TRUE,
      options = list(
        plugins = list("remove_button"), closeAfterSelect = FALSE)))
}

microbiome_assembly_analysis_expression <- function(method_id, current = list()) {
  iterations <- as.integer(current$n_iterations %||% 999L)
  workers <- as.integer(current$n_cores %||% 1L)
  switch(method_id,
    ncm = paste(
      "minpack.lm::nlsLM(freq ~ pbeta(d, N*m*p, N*m*(1 - p),",
      "lower.tail = FALSE), start = list(m = 0.1),",
      "lower = c(m = 0.000001), upper = c(m = 0.999999))",
      if (nzchar(current$group %||% "")) {
        sprintf("Fit each group independently by %s", current$group)
      } else "Overall fitting",
      "[Hmisc::binconf + ggplot2 + patchwork]"),
    nst = , tnst = sprintf(
      "NST::tNST(comm, group, dist.method = '%s', rand = %d, nworker = %d)",
      current$distance_method %||% "jaccard", iterations, workers),
    pnst = sprintf(
      "NST::pNST(comm, tree = phylogeny, group = group, rand = %d, nworker = %d)",
      iterations, workers),
    beta_mntd =
      "microeco::trans_nullmodel$cal_betamntd(abundance.weighted = TRUE)",
    beta_nti = sprintf(
      "microeco::trans_nullmodel$cal_ses_betamntd(runs = %d, null.model = '%s', nworker = %d)",
      iterations, current$null_model_method %||% "taxa.labels", workers),
    rcbray = sprintf(
      "iCAMP::RC.cm(comm, rand = %d, nworker = %d, sig.index = 'RC')",
      iterations, workers),
    bnti_rcbray = sprintf(
      "iCAMP::bNTI.cm(...) + iCAMP::RC.cm(..., rand = %d, nworker = %d)",
      iterations, workers),
    icamp = sprintf(
      "iCAMP::icamp.big(comm, tree, rand = %d, nworker = %d, bin.size.limit = %d)",
      iterations, workers, as.integer(current$icamp_bin_size %||% 24L)),
    assembly_nri_nti = sprintf(
      "picante::ses.mpd/mntd(comm, phylogenetic_distance, runs = %d)",
      iterations),
    niche_breadth_assembly =
      "microeco::trans_niche / Levins: B_j = 1 / sum_i(p_ij^2)",
    paste0(method_id, "(community)"))
}

microbiome_assembly_analysis_ui <- function(
    ns, method_id, metadata, current = list(), session = NULL) {
  categorical <- names(metadata)[vapply(metadata, function(value) {
    count <- length(unique(value[!is.na(value)]))
    count >= 2L && count <= 12L &&
      (is.factor(value) || is.character(value) || is.logical(value) ||
        count <= 8L)
  }, logical(1))]
  group_required <- method_id %in% c("nst", "tnst", "pnst")
  group <- current$group %||% ""
  if (!group %in% categorical) {
    group <- if ("Treatment" %in% categorical) "Treatment" else
      if (length(categorical)) categorical[[1]] else ""
  }
  group_choices <- c(
    if (!group_required) "Not grouped" = "",
    stats::setNames(categorical, categorical))
  server_side_group <- !is.null(session) && length(group_choices) > 100L
  if (server_side_group) {
    session$onFlushed(function() {
      shiny::updateSelectizeInput(
        session, "group", choices = group_choices,
        selected = group, server = TRUE)
    }, once = TRUE)
  }
  plot_choices <- microbiome_assembly_plot_choices(method_id)
  selected <- intersect(
    current$plot_types %||% unname(plot_choices), unname(plot_choices))
  if (!length(selected)) selected <- unname(plot_choices)
  distance_methods <- c(
    "Jaccard" = "jaccard", "Bray-Curtis" = "bray",
    "Euclidean" = "euclidean")
  shiny::tagList(
    if (length(categorical)) shiny::selectizeInput(
      ns("group"), if (group_required) "Grouping variables" else "Grouping variables (plotting)",
      choices = if (server_side_group) NULL else group_choices,
      selected = if (server_side_group) NULL else group,
      options = list(maxOptions = 100L)),
    if (method_id %in% c("nst", "tnst")) shiny::selectInput(
      ns("distance_method"), "Distance algorithm", distance_methods,
      selected = current$distance_method %||% "jaccard"),
    if (method_id %in% c(
        "nst", "tnst", "pnst", "beta_mntd", "beta_nti", "rcbray",
        "bnti_rcbray")) shiny::checkboxInput(
      ns("assembly_abundance_weighted"), "Abundance weighting",
      isTRUE(current$abundance_weighted %||% TRUE)),
    if (identical(method_id, "icamp")) shiny::numericInput(
      ns("icamp_bin_size"), "Minimum number of binned taxa",
      value = as.integer(current$icamp_bin_size %||% 24L),
      min = 12L, max = 96L, step = 1L),
    if (method_id %in% c("nst", "tnst", "pnst", "assembly_nri_nti")) {
      shiny::selectInput(
        ns("p_adjust_method"), "Comparison between groups for multiple corrections",
        c("FDR (BH)" = "BH", "Holm" = "holm",
          "Bonferroni" = "bonferroni", "No correction" = "none"),
        selected = current$p_adjust_method %||% "BH")
    },
    shiny::tags$hr(class = "my-3"),
    microbiome_readonly_expression(
      ns, microbiome_assembly_analysis_expression(method_id, current), 6L),
    shiny::selectizeInput(
      ns("assembly_plot_types"), "Drawing type",
      plot_choices, selected = selected, multiple = TRUE,
      options = list(
        plugins = list("remove_button"), closeAfterSelect = FALSE)))
}

microbiome_function_group_results <- function(table, metadata, group, adjust = "BH") {
  metadata <- microbiome_metadata_by_sample(metadata)
  if (!nzchar(group %||% "") || !group %in% names(metadata)) {
    return(data.frame())
  }
  grouping <- droplevels(factor(metadata[rownames(table), group]))
  if (nlevels(grouping) < 2L) return(data.frame())
  rows <- lapply(colnames(table), function(feature) {
    value <- table[, feature]
    fit <- if (nlevels(grouping) == 2L) {
      stats::wilcox.test(value ~ grouping, exact = FALSE)
    } else {
      stats::kruskal.test(value ~ grouping)
    }
    data.frame(
      Function = feature, Statistic = unname(fit$statistic),
      PValue = fit$p.value,
      Method = if (nlevels(grouping) == 2L) "Wilcoxon" else "Kruskal-Wallis",
      stringsAsFactors = FALSE)
  })
  result <- do.call(rbind, rows)
  result$AdjustedP <- stats::p.adjust(result$PValue, method = adjust)
  result
}

microbiome_function_environment_correlation <- function(
    function_table, environment, bundle = NULL,
    variables = character(), enabled = FALSE) {
  if (!isTRUE(enabled) || !length(variables)) {
    return(list(plot = NULL, table = data.frame(), engine = "disabled"))
  }
  environment <- microbiome_metadata_by_sample(environment %||% data.frame())
  if (!nrow(environment) || !nrow(function_table)) {
    return(list(plot = NULL, table = data.frame(), engine = "none"))
  }
  environment <- environment[match(rownames(function_table), rownames(environment)), , drop = FALSE]
  numeric_names <- intersect(
    variables, names(environment)[vapply(environment, is.numeric, logical(1))])
  numeric_names <- numeric_names[vapply(environment[numeric_names], function(x) {
    x <- x[is.finite(x)]
    length(x) >= 3L && length(unique(x)) > 1L
  }, logical(1))]
  if (!length(numeric_names)) {
    return(list(plot = NULL, table = data.frame(), engine = "none"))
  }
  relative <- function_table / pmax(rowSums(function_table), 1)
  relative <- as.matrix(relative)
  env_values <- as.matrix(environment[, numeric_names, drop = FALSE])
  keep <- complete.cases(env_values) & apply(relative, 1, function(x) all(is.finite(x)))
  relative <- relative[keep, , drop = FALSE]
  env_values <- env_values[keep, , drop = FALSE]
  if (nrow(relative) < 3L) {
    return(list(plot = NULL, table = data.frame(), engine = "none"))
  }
  r_mat <- matrix(NA_real_, nrow = ncol(relative), ncol = ncol(env_values),
    dimnames = list(colnames(relative), colnames(env_values)))
  p_mat <- r_mat
  for (i in seq_len(nrow(r_mat))) for (j in seq_len(ncol(r_mat))) {
    test <- suppressWarnings(stats::cor.test(
      relative[, i], env_values[, j], method = "spearman", exact = FALSE))
    r_mat[i, j] <- unname(test$estimate)
    p_mat[i, j] <- test$p.value
  }
  stars <- matrix("", nrow = nrow(p_mat), ncol = ncol(p_mat),
    dimnames = dimnames(p_mat))
  stars[p_mat < 0.05] <- "*"
  stars[p_mat < 0.01] <- "**"
  stars[p_mat < 0.001] <- "***"
  correlation_table <- as.data.frame(as.table(r_mat), stringsAsFactors = FALSE)
  names(correlation_table) <- c("Function", "Environment", "SpearmanR")
  p_table <- as.data.frame(as.table(p_mat), stringsAsFactors = FALSE)
  names(p_table) <- c("Function", "Environment", "PValue")
  star_table <- as.data.frame(as.table(stars), stringsAsFactors = FALSE)
  names(star_table) <- c("Function", "Environment", "Significance")
  correlation_table <- merge(correlation_table, p_table,
    by = c("Function", "Environment"), sort = FALSE)
  correlation_table <- merge(correlation_table, star_table,
    by = c("Function", "Environment"), sort = FALSE)
  correlation_table$FDR <- stats::p.adjust(correlation_table$PValue, method = "BH")

  row_order <- seq_len(nrow(r_mat))
  col_order <- seq_len(ncol(r_mat))
  if (length(row_order) > 1L) row_order <- stats::hclust(stats::dist(r_mat))$order
  if (length(col_order) > 1L) col_order <- stats::hclust(stats::dist(t(r_mat)))$order
  plot_data <- correlation_table
  plot_data$Function <- factor(plot_data$Function,
    levels = rownames(r_mat)[rev(row_order)])
  plot_data$Environment <- factor(plot_data$Environment,
    levels = colnames(r_mat)[col_order])
  fallback_plot <- ggplot2::ggplot(
    plot_data, ggplot2::aes(.data$Environment, .data$Function,
      fill = .data$SpearmanR)) +
    ggplot2::geom_tile(color = "white", linewidth = 0.15) +
    ggplot2::geom_text(ggplot2::aes(label = .data$Significance), size = 3) +
    ggplot2::scale_fill_gradient2(low = "#3B4CC0", mid = "white",
      high = "#B40426", midpoint = 0, limits = c(-1, 1),
      name = "Spearman") +
    ggplot2::labs(x = NULL, y = NULL,
      title = "FAPROTAX Function-Environment Correlation") +
    ggplot2::theme_classic() + ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 45, hjust = 1),
      axis.text.y = ggplot2::element_text(size = 7))

  microeco_plot <- NULL
  if (!is.null(bundle) && requireNamespace("microeco", quietly = TRUE)) {
    microeco_plot <- tryCatch({
      dataset <- microbiome_microeco_dataset(bundle)
      env_table <- environment[rownames(relative), numeric_names, drop = FALSE]
      function_abundance <- as.data.frame(
        function_table[rownames(relative), , drop = FALSE],
        check.names = FALSE)
      t3 <- microeco::trans_env$new(dataset = dataset, add_data = env_table)
      t3$cal_cor(
        add_abund_table = function_abundance, method = "spearman")
      t3$plot_cor(cluster_ggplot = "both")
    }, error = function(error) NULL)
    if (inherits(microeco_plot, "aplot") &&
        requireNamespace("ggplotify", quietly = TRUE)) {
      microeco_plot <- tryCatch(
        ggplotify::as.ggplot(microeco_plot), error = function(error) NULL)
    }
    if (!inherits(microeco_plot, "ggplot") &&
        !inherits(microeco_plot, "patchwork") &&
        !inherits(microeco_plot, "aplot")) microeco_plot <- NULL
  }
  list(plot = microeco_plot %||% fallback_plot,
    table = correlation_table,
    engine = if (is.null(microeco_plot)) "ggplot2_fallback" else
      "microeco::trans_env$cal_cor + plot_cor")
}

microbiome_function_plots <- function(
    table, metadata, group, requested,
    values_are_relative = FALSE, values_are_percent = FALSE,
    environment = data.frame(), method_id = "", bundle = NULL,
    environment_variables = character(), environment_enabled = FALSE) {
  metadata <- microbiome_metadata_by_sample(metadata)
  relative <- if (values_are_relative) {
    table / if (values_are_percent) 100 else 1
  } else {
    table / pmax(rowSums(table), 1)
  }
  top <- names(sort(colMeans(relative), decreasing = TRUE))[
    seq_len(min(20L, ncol(relative)))]
  sample_group <- if (nzchar(group %||% "") && group %in% names(metadata)) {
    as.character(metadata[rownames(relative), group])
  } else {
    rep("All samples", nrow(relative))
  }
  long <- data.frame(
    SampleID = rep(rownames(relative), each = length(top)),
    Group = rep(sample_group, each = length(top)),
    Function = rep(top, times = nrow(relative)),
    RelativeAbundance = as.vector(t(relative[, top, drop = FALSE])),
    stringsAsFactors = FALSE)
  group_mean <- stats::aggregate(
    RelativeAbundance ~ Group + Function, long, mean)
  heat <- long
  heat$LogAbundance <- log10(heat$RelativeAbundance + 1e-6)
  top_summary <- data.frame(
    Function = top,
    MeanRelativeAbundance = colMeans(relative[, top, drop = FALSE]),
    stringsAsFactors = FALSE)
  plots <- list(
    function_composition = ggplot2::ggplot(
      group_mean,
      ggplot2::aes(.data$Group, .data$RelativeAbundance,
        fill = .data$Function)) +
      ggplot2::geom_col(position = "fill") +
      ggplot2::scale_y_continuous(labels = scales::percent) +
      ggplot2::labs(
        x = NULL, y = "Mean relative abundance", fill = "Function",
        title = "Functional Composition") +
      ggplot2::theme_classic(),
    function_heatmap = ggplot2::ggplot(
      heat,
      ggplot2::aes(.data$SampleID, .data$Function,
        fill = .data$LogAbundance)) +
      ggplot2::geom_tile() +
      ggplot2::facet_grid(~Group, scales = "free_x", space = "free_x") +
      ggplot2::scale_fill_gradient2(
        low = "#2166AC", mid = "#F7F7F7", high = "#B2182B",
        midpoint = stats::median(heat$LogAbundance, na.rm = TRUE)) +
      ggplot2::labs(
        x = "Sample", y = "Function",
        fill = "log10(relative + 1e-6)",
        title = "Functional Abundance Heatmap") +
      ggplot2::theme_classic() +
      ggplot2::theme(
        axis.text.x = ggplot2::element_blank(),
        axis.ticks.x = ggplot2::element_blank()),
    function_top_bar = ggplot2::ggplot(
      top_summary,
      ggplot2::aes(
        .data$MeanRelativeAbundance,
        stats::reorder(.data$Function, .data$MeanRelativeAbundance),
        fill = .data$Function)) +
      ggplot2::geom_col(show.legend = FALSE) +
      ggplot2::labs(
        x = "Mean relative abundance", y = NULL,
        title = "Top Predicted Functions") +
      ggplot2::theme_classic(),
    function_group_boxplot = ggplot2::ggplot(
      long,
      ggplot2::aes(.data$Group, .data$RelativeAbundance,
        fill = .data$Group)) +
      ggplot2::geom_boxplot(outlier.shape = NA) +
      ggplot2::geom_jitter(width = 0.12, alpha = 0.35, size = 0.8) +
      ggplot2::facet_wrap(~Function, scales = "free_y") +
      ggplot2::labs(
        x = NULL, y = "Relative abundance",
        title = "Functional Abundance by Group") +
      ggplot2::theme_classic() +
      ggplot2::theme(legend.position = "none"))
  plots <- plots[intersect(names(plots), requested)]
  if (identical(method_id, "faprotax") &&
      "function_environment_correlation" %in% requested) {
    correlation <- microbiome_function_environment_correlation(
      table, environment, bundle, environment_variables,
      environment_enabled)
    if (!is.null(correlation$plot)) {
      plots$function_environment_correlation <- correlation$plot
      attr(plots, "function_environment_correlation") <- correlation
    }
  }
  plots
}

microbiome_enhance_function_result <- function(result, bundle, spec) {
  abundance <- result$tables$function_abundance %||% data.frame()
  if (!nrow(abundance)) return(result)
  if ("SampleID" %in% names(abundance)) {
    rownames(abundance) <- abundance$SampleID
    abundance$SampleID <- NULL
  }
  abundance <- microbiome_numeric_matrix(abundance, "function abundance")
  group <- spec$group %||% ""
  adjust <- spec$p_adjust_method %||% "BH"
  tests <- microbiome_function_group_results(
    abundance, bundle$metadata, group, adjust)
  if (nrow(tests)) result$tables$group_tests <- tests
  requested <- as.character(spec$plot_types %||%
    unname(microbiome_function_plot_choices(result$method_id)))
  result$plots <- microbiome_function_plots(
    abundance, bundle$metadata, group, requested,
    values_are_relative = result$method_id %in%
      c("funguild", "fungaltraits"),
    values_are_percent = isTRUE(
      result$actual_parameters$functional_redundancy_percent),
    environment = bundle$environment, method_id = result$method_id,
    bundle = bundle,
    environment_variables = spec$function_environment_variables %||%
      character(),
    environment_enabled = isTRUE(spec$function_environment_enabled))
  correlation <- attr(result$plots, "function_environment_correlation")
  if (!is.null(correlation)) {
    result$tables$function_environment_correlation <- correlation$table
    result$actual_parameters$function_environment_engine <- correlation$engine
  }
  result$actual_parameters <- utils::modifyList(
    result$actual_parameters,
    list(group = group, p_adjust_method = adjust,
      plot_types = names(result$plots)))
  result$available_outputs <- unique(c(
    names(result$tables), names(result$plots)))
  result
}

microbiome_fungal_required_ranks <- function() {
  c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species")
}

microbiome_prepare_fungal_function_bundle <- function(bundle) {
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  if (!identical(bundle$marker_type, "ITS")) {
    stop("Fungal function prediction only supports ITS amplicon data.", call. = FALSE)
  }
  required_ranks <- microbiome_fungal_required_ranks()
  missing_ranks <- setdiff(required_ranks, names(bundle$taxonomy))
  if (length(missing_ranks)) {
    stop(
      "Fungal function prediction requires a complete taxonomic annotation table, which is missing:",
      paste(missing_ranks, collapse = ", "),
      ". The classification table must contain Kingdom, Phylum, Class, Order, Family, Genus, and Species.",
      call. = FALSE)
  }
  if (nrow(bundle$taxonomy) != length(bundle$feature_ids) ||
      !identical(rownames(bundle$taxonomy), bundle$feature_ids)) {
    stop(
      "The classification annotation table must completely cover and match all OTUs/ASVs by Feature ID.",
      call. = FALSE)
  }
  kingdom <- trimws(as.character(bundle$taxonomy$Kingdom))
  fungal <- grepl("Fungi", kingdom, ignore.case = TRUE)
  if (!any(fungal)) {
    stop(
      "Fungi is not recognized in the Kingdom column of the taxonomy annotation table and fungal function prediction cannot be made.",
      call. = FALSE)
  }
  excluded <- data.frame(
    Feature = bundle$feature_ids[!fungal],
    Kingdom = kingdom[!fungal],
    Reason = rep(
      "Kingdom is not assigned to Fungi", sum(!fungal)),
    stringsAsFactors = FALSE)
  bundle$counts <- bundle$counts[, fungal, drop = FALSE]
  bundle$taxonomy <- bundle$taxonomy[fungal, , drop = FALSE]
  bundle$feature_ids <- colnames(bundle$counts)
  zero_samples <- rownames(bundle$counts)[rowSums(
    microbiome_numeric_matrix(bundle$counts)) <= 0]
  if (length(zero_samples)) {
    stop(
      "The following samples had no fungal abundance after removing non-fungal features:",
      paste(utils::head(zero_samples, 8L), collapse = ", "),
      if (length(zero_samples) > 8L) " ..." else "",
      call. = FALSE)
  }
  list(
    bundle = bundle, orientation = aligned$orientation,
    excluded = excluded)
}

microbiome_run_fungal_function <- function(
    method_id, bundle, spec = list()) {
  if (!method_id %in% c("funguild", "fungaltraits")) {
    stop("Unknown fungal function prediction method:", method_id, call. = FALSE)
  }
  if (!requireNamespace("microeco", quietly = TRUE)) {
    stop("Fungal function prediction requires the microeco package.", call. = FALSE)
  }
  suppressPackageStartupMessages(
    require("microeco", character.only = TRUE))
  prepared <- microbiome_prepare_fungal_function_bundle(bundle)
  fungal_bundle <- prepared$bundle
  database <- if (identical(method_id, "funguild")) {
    "FUNGuild"
  } else {
    "FungalTraits"
  }
  confidence <- intersect(
    as.character(spec$funguild_confidence %||%
      c("Highly Probable", "Probable", "Possible")),
    c("Highly Probable", "Probable", "Possible"))
  if (identical(method_id, "funguild") && !length(confidence)) {
    stop("FUNGuild requires at least one confidence level to be selected.", call. = FALSE)
  }
  abundance_weighted <- isTRUE(
    spec$fungal_fr_abundance_weighted %||% TRUE)
  percent <- isTRUE(spec$fungal_fr_percent %||% TRUE)
  dataset <- microbiome_microeco_dataset(fungal_bundle)
  fit <- microeco::trans_func$new(dataset = dataset)
  fit$for_what <- "fungi"
  captured <- microbiome_capture_runtime_output(function() {
    if (identical(method_id, "funguild")) {
      fit$cal_func(
        fungi_database = database,
        FUNGuild_confidence = confidence)
    } else {
      fit$cal_func(fungi_database = database)
    }
    fit$cal_func_FR(
      abundance_weighted = abundance_weighted,
      perc = percent, remove_zero = TRUE)
    fit
  })
  fit <- captured$value
  functional_redundancy <- as.data.frame(
    fit$res_func_FR, stringsAsFactors = FALSE, check.names = FALSE)
  if (!nrow(functional_redundancy) ||
      !ncol(functional_redundancy)) {
    stop(
      database,
      " No available fungal functional traits were returned; please check the taxonomy name and confidence level.",
      call. = FALSE)
  }
  functional_redundancy <- functional_redundancy[
    fungal_bundle$sample_ids, , drop = FALSE]
  binary <- as.data.frame(
    fit$res_func, stringsAsFactors = FALSE, check.names = FALSE)
  binary <- binary[fungal_bundle$feature_ids, , drop = FALSE]
  matched <- rowSums(as.matrix(binary), na.rm = TRUE) > 0
  raw_mapping <- if (identical(method_id, "funguild")) {
    fit$res_spe_func_raw_funguild
  } else {
    fit$res_spe_func_raw_FungalTraits
  }
  raw_mapping <- as.data.frame(
    raw_mapping, stringsAsFactors = FALSE, check.names = FALSE)
  raw_mapping <- raw_mapping[fungal_bundle$feature_ids, , drop = FALSE]
  raw_mapping <- data.frame(
    Feature = rownames(raw_mapping), raw_mapping,
    row.names = NULL, check.names = FALSE)
  binary_table <- data.frame(
    Feature = rownames(binary), binary,
    row.names = NULL, check.names = FALSE)
  taxonomy_used <- fungal_bundle$taxonomy
  taxonomy_used$Feature <- fungal_bundle$feature_ids
  taxonomy_used <- taxonomy_used[, c(
    "Feature", setdiff(names(taxonomy_used), "Feature")),
    drop = FALSE]
  mean_fr <- colMeans(functional_redundancy)
  summary <- data.frame(
    Function = names(mean_fr),
    MeanAbundance = unname(mean_fr),
    MeanRelativeAbundance = if (percent) {
      unname(mean_fr) / 100
    } else {
      unname(mean_fr)
    },
    Prevalence = colMeans(functional_redundancy > 0),
    Database = database,
    stringsAsFactors = FALSE)
  mapping_summary <- data.frame(
    Metric = c(
      "Input ITS features", "Fungal features retained",
      "Features with predicted traits", "Unmatched fungal features",
      "Predicted feature fraction"),
    Value = c(
      length(bundle$feature_ids), length(fungal_bundle$feature_ids),
      sum(matched), sum(!matched),
      sum(matched) / length(matched)),
    stringsAsFactors = FALSE)
  database_version <- paste0(
    database, " bundled with microeco ",
    as.character(utils::packageVersion("microeco")))
  tables <- list(
    function_summary = summary,
    function_abundance = data.frame(
      SampleID = rownames(functional_redundancy),
      functional_redundancy,
      check.names = FALSE),
    feature_function_binary = binary_table,
    raw_trait_mapping = raw_mapping,
    mapping_summary = mapping_summary,
    unmatched_features = data.frame(
      Feature = fungal_bundle$feature_ids[!matched],
      stringsAsFactors = FALSE),
    excluded_non_fungi = prepared$excluded,
    taxonomy_used = taxonomy_used,
    mapping_evidence = data.frame(
      DatabaseVersion = database_version,
      Evidence = if (identical(method_id, "funguild")) {
        "microeco built-in FUNGuild taxonomy-to-guild database"
      } else {
        "microeco built-in FungalTraits genus-to-trait database"
      },
      stringsAsFactors = FALSE))
  if (identical(method_id, "funguild") &&
      "confidenceRanking" %in% names(raw_mapping)) {
    confidence_values <- as.character(raw_mapping$confidenceRanking)
    confidence_values[!nzchar(confidence_values)] <- "Unmatched"
    tables$confidence_summary <- as.data.frame(
      table(confidence_values), stringsAsFactors = FALSE)
    names(tables$confidence_summary) <- c("Confidence", "Features")
  }
  result <- new_microbiome_result(
    method_id, status = "warning", marker_type = fungal_bundle$marker_type,
    data_version = bundle$data_version,
    input_summary = microbiome_data_summary(
      fungal_bundle, prepared$orientation),
    analysis_spec = spec,
    actual_parameters = list(
      engine = "microeco::trans_func$cal_func + cal_func_FR",
      database = database,
      database_version = database_version,
      required_taxonomy_ranks = microbiome_fungal_required_ranks(),
      funguild_confidence = if (identical(
        method_id, "funguild")) confidence else NULL,
      abundance_weighted = abundance_weighted,
      functional_redundancy_percent = percent,
      retained_fungal_features = length(fungal_bundle$feature_ids),
      excluded_non_fungal_features = nrow(prepared$excluded)),
    model_objects = list(
      microtable = dataset, trans_func = fit),
    functional_tables = tables, tables = tables,
    warnings = unique(c(
      paste0(
        database,
        " The output is based on the ITS taxonomic annotation inferred function, not the metagenomic measured function."),
      captured$warnings)),
    runtime_log = captured$log,
    available_outputs = names(tables),
    package_versions = microbiome_package_versions("microeco"),
    generated_code = microbiome_extended_function_code(method_id),
    registration_manifest = microbiome_registration_manifest(
      fungal_bundle, method_id, names(tables)))
  microbiome_enhance_function_result(result, fungal_bundle, spec)
}

microbiome_run_fungaltraits_mapping <- function(bundle, spec = list()) {
  microbiome_run_fungal_function("fungaltraits", bundle, spec)
}

microbiome_tax4fun2_kegg_data <- function() {
  data_environment <- new.env(parent = baseenv())
  utils::data(
    "Tax4Fun2_KEGG", package = "microeco",
    envir = data_environment)
  data_environment$Tax4Fun2_KEGG
}

microbiome_tax4fun2_pathway_tables <- function(fit, bundle) {
  pathway <- as.matrix(fit$res_tax4fun2_pathway)
  storage.mode(pathway) <- "numeric"
  if (!nrow(pathway) || !ncol(pathway)) {
    stop("Tax4Fun2 did not return valid pathway abundances.", call. = FALSE)
  }
  if (!all(bundle$sample_ids %in% colnames(pathway))) {
    stop("Tax4Fun2 pathway result sample cannot match the input abundance table.",
      call. = FALSE)
  }
  pathway <- pathway[, bundle$sample_ids, drop = FALSE]
  pathway_ids <- rownames(pathway)
  kegg <- microbiome_tax4fun2_kegg_data()
  annotation <- as.data.frame(
    kegg$ptw_desc[pathway_ids, , drop = FALSE],
    stringsAsFactors = FALSE, check.names = FALSE)
  annotation$PathwayID <- pathway_ids
  annotation$Level.1[is.na(annotation$Level.1)] <- "Unclassified"
  annotation$Level.2[is.na(annotation$Level.2)] <- "Unclassified"
  annotation$Level.3[is.na(annotation$Level.3)] <- pathway_ids[
    is.na(annotation$Level.3)]
  function_names <- make.unique(paste(
    pathway_ids, annotation$Level.3, sep = " | "))
  function_abundance <- t(pathway)
  colnames(function_abundance) <- function_names
  relative <- function_abundance /
    pmax(rowSums(function_abundance), .Machine$double.eps)
  summary <- data.frame(
    FunctionID = pathway_ids,
    Function = function_names,
    Level1 = annotation$Level.1,
    Level2 = annotation$Level.2,
    Level3 = annotation$Level.3,
    MeanAbundance = colMeans(function_abundance),
    MeanRelativeAbundance = colMeans(relative),
    Prevalence = colMeans(function_abundance > 0),
    stringsAsFactors = FALSE, check.names = FALSE)
  rownames(summary) <- NULL
  list(
    function_summary = summary,
    function_abundance = data.frame(
      SampleID = rownames(function_abundance),
      function_abundance, check.names = FALSE),
    pathway_abundance = data.frame(
      PathwayID = pathway_ids, pathway,
      check.names = FALSE),
    pathway_annotation = annotation[, c(
      "PathwayID", "Level.1", "Level.2", "Level.3"),
      drop = FALSE],
    ko_abundance = as.data.frame(
      fit$res_tax4fun2_KO, check.names = FALSE))
}

microbiome_tax4fun2_reference_workspace <- function(
    source_root, database_mode, work_dir) {
  source_directory <- file.path(source_root, database_mode)
  runtime_root <- file.path(work_dir, "reference_data")
  runtime_directory <- file.path(runtime_root, database_mode)
  dir.create(runtime_directory, recursive = TRUE)
  source_files <- list.files(
    source_directory, full.names = TRUE, all.files = TRUE,
    no.. = TRUE)
  source_files <- source_files[file.info(source_files)$isdir %in% FALSE]
  destination_files <- file.path(
    runtime_directory, basename(source_files))
  mutable_index <- grepl(
    paste0("^", database_mode, "\\.fasta\\.n"),
    basename(source_files))
  linked <- rep(FALSE, length(source_files))
  linked[!mutable_index] <- file.link(
    source_files[!mutable_index], destination_files[!mutable_index])
  if (any(!linked)) {
    copied <- file.copy(
      source_files[!linked], destination_files[!linked],
      overwrite = TRUE, copy.mode = FALSE, copy.date = FALSE)
    if (any(!copied)) {
      stop(
        "Unable to prepare the Tax4Fun2 reference database in the system temporary directory.",
        call. = FALSE)
    }
  }
  normalizePath(runtime_root, winslash = "/", mustWork = TRUE)
}

microbiome_run_tax4fun2 <- function(bundle, spec = list()) {
  dava_install_packages(c("microeco", "Tax4Fun2", "seqinr"),
    purpose = "Tax4Fun2 bacterial functional analysis")
  suppressPackageStartupMessages(
    require("microeco", character.only = TRUE))
  if (!identical(bundle$marker_type, "16S")) {
    stop("Tax4Fun2 only works with 16S amplicon data.", call. = FALSE)
  }
  representative_sequences <- microbiome_representative_sequence_list(
    bundle$representative_sequences)
  demo_fallback <- isTRUE(bundle$provenance$dedicated_demo) &&
    NROW(bundle$function_table %||% data.frame()) &&
    (is.null(representative_sequences) ||
      identical(bundle$provenance$representative_sequence_source %||% "",
        "simulated_nonreference"))
  if (demo_fallback) {
      result <- microbiome_run_function_core(
        "picrust2_import", bundle, spec)
      result$method_id <- "tax4fun2"
      result$actual_parameters$execution_mode <-
        "DAVA method demonstration table"
      result$warnings <- paste(
        "is currently exclusive simulation data for the Tax4Fun2 method and is only used for interface demonstration;",
        "Real analysis must select the complete representative sequence and run Ref99NR.")
      result$generated_code <- microbiome_extended_function_code(
        "tax4fun2")
      return(microbiome_enhance_function_result(
        result, bundle, spec))
  }
  if (is.null(representative_sequences)) {
    stop(
      "Tax4Fun2 must select representative sequences that completely match the OTU/ASV abundance table.",
      call. = FALSE)
  }
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  missing_sequences <- setdiff(
    bundle$feature_ids, names(representative_sequences))
  if (length(missing_sequences)) {
    stop(sprintf(
      "The representative sequence is missing %d abundance features, for example: %s.",
      length(missing_sequences),
      paste(utils::head(missing_sequences, 5L), collapse = ", ")),
      call. = FALSE)
  }
  bundle$representative_sequences <- representative_sequences[
    bundle$feature_ids]

  reference_path <- microbiome_tax4fun2_reference_path(
    spec$tax4fun2_reference_path)
  database_mode <- spec$tax4fun2_database_mode %||% "Ref99NR"
  reference_fasta <- file.path(
    reference_path, database_mode, paste0(database_mode, ".fasta"))
  if (!file.exists(reference_fasta)) {
    stop(
      "Tax4Fun2 reference database does not exist:", reference_fasta,
      call. = FALSE)
  }
  blast_path <- microbiome_tax4fun2_blast_path(
    spec$tax4fun2_blast_path)
  previous_path <- Sys.getenv("PATH")
  if (nzchar(blast_path %||% "")) {
    Sys.setenv(PATH = paste(
      blast_path, previous_path, sep = .Platform$path.sep))
  }
  on.exit(Sys.setenv(PATH = previous_path), add = TRUE)
  blast_binary <- Sys.which("blastn")
  if (!nzchar(blast_binary)) {
    stop(
      "blastn not found. Please set the NCBI BLAST bin path in advanced parameters.",
      call. = FALSE)
  }
  blast_check <- suppressWarnings(system2(
    blast_binary, "-version", stdout = TRUE, stderr = TRUE))
  if (!length(blast_check)) {
    stop("blastn failed to execute:", blast_binary, call. = FALSE)
  }

  work_dir <- tempfile("dava-tax4fun2-")
  dir.create(work_dir, recursive = TRUE)
  on.exit(unlink(work_dir, recursive = TRUE, force = TRUE), add = TRUE)
  runtime_reference_path <- microbiome_tax4fun2_reference_workspace(
    reference_path, database_mode, work_dir)
  dataset <- microbiome_microeco_dataset(bundle)
  fit <- microeco::trans_func$new(dataset = dataset)
  threads <- max(1L, as.integer(
    spec$tax4fun2_threads %||% 1L))
  captured <- microbiome_capture_runtime_output(function() {
    fit$cal_tax4fun2(
      blast_tool_path = NULL,
      path_to_reference_data = runtime_reference_path,
      path_to_temp_folder = work_dir,
      database_mode = database_mode,
      normalize_by_copy_number = isTRUE(
        spec$tax4fun2_copy_number %||% TRUE),
      min_identity_to_reference = as.numeric(
        spec$tax4fun2_min_identity %||% 97),
      use_uproc = isTRUE(spec$tax4fun2_use_uproc %||% TRUE),
      num_threads = threads,
      normalize_pathways = FALSE)
    if (isTRUE(spec$tax4fun2_cal_fri %||% FALSE)) {
      fit$cal_tax4fun2_FRI()
    }
    mapping_path <- file.path(
      work_dir, "res_tax4fun2_reference_profile.tsv")
    mapping <- if (file.exists(mapping_path)) {
      utils::read.delim(
        mapping_path, stringsAsFactors = FALSE, check.names = FALSE)
    } else {
      data.frame()
    }
    list(fit = fit, mapping = mapping)
  })
  fit <- captured$value$fit
  tables <- microbiome_tax4fun2_pathway_tables(fit, bundle)
  mapping <- captured$value$mapping
  mapping <- mapping[, intersect(
    c("Taxa", "id"), names(mapping)), drop = FALSE]
  tables$sequence_reference_matches <- mapping
  matched_features <- unique(as.character(mapping$Taxa %||% character()))
  unmatched_features <- setdiff(bundle$feature_ids, matched_features)
  tables$sequence_match_summary <- data.frame(
    Metric = c(
      "Input features", "Matched features", "Unmatched features",
      "Matched feature fraction"),
    Value = c(
      length(bundle$feature_ids), length(intersect(
        bundle$feature_ids, matched_features)),
      length(unmatched_features),
      length(intersect(bundle$feature_ids, matched_features)) /
        length(bundle$feature_ids)),
    stringsAsFactors = FALSE)
  tables$unmatched_features <- data.frame(
    Feature = unmatched_features, stringsAsFactors = FALSE)
  if (!is.null(fit$res_tax4fun2_aFRI)) {
    tables$absolute_functional_redundancy <- as.data.frame(
      fit$res_tax4fun2_aFRI, check.names = FALSE)
  }
  if (!is.null(fit$res_tax4fun2_rFRI)) {
    tables$relative_functional_redundancy <- as.data.frame(
      fit$res_tax4fun2_rFRI, check.names = FALSE)
  }
  warning_text <- c(
    "Tax4Fun2 is a function prediction based on the 16S nearest neighbor reference genome, not a metagenomic measured function.",
    captured$warnings)
  result <- new_microbiome_result(
    "tax4fun2", status = "warning",
    marker_type = bundle$marker_type,
    data_version = bundle$data_version,
    input_summary = microbiome_data_summary(
      bundle, aligned$orientation),
    analysis_spec = spec,
    actual_parameters = list(
      engine = "microeco::trans_func$cal_tax4fun2",
      database_mode = database_mode,
      reference_path = reference_path,
      blast_binary = normalizePath(
        blast_binary, winslash = "/", mustWork = TRUE),
      min_identity = as.numeric(
        spec$tax4fun2_min_identity %||% 97),
      normalize_by_copy_number = isTRUE(
        spec$tax4fun2_copy_number %||% TRUE),
      use_uproc = isTRUE(spec$tax4fun2_use_uproc %||% TRUE),
      threads = threads,
      functional_redundancy = isTRUE(
        spec$tax4fun2_cal_fri %||% FALSE)),
    model_objects = list(trans_func = fit),
    functional_tables = tables, tables = tables,
    warnings = unique(warning_text),
    runtime_log = c(
      paste0("[Tax4Fun2] ReferenceData: ", reference_path),
      paste0("[Tax4Fun2] BLAST: ", blast_binary),
      captured$log),
    available_outputs = names(tables),
    generated_code = microbiome_extended_function_code("tax4fun2"),
    package_versions = microbiome_package_versions(
      c("microeco", "Tax4Fun2", "seqinr")),
    registration_manifest = microbiome_registration_manifest(
      bundle, "tax4fun2", names(tables)))
  microbiome_enhance_function_result(result, bundle, spec)
}

microbiome_extended_function_code <- function(method_id) {
  if (identical(method_id, "tax4fun2")) {
    return(microbiome_parseable_code(c(
      "library(microeco)",
      microbiome_microeco_input_code("dataset"),
      "tax4fun <- trans_func$new(dataset = dataset)",
      "tax4fun$cal_tax4fun2(",
      "  blast_tool_path = NULL,",
      "  path_to_reference_data = 'tools/Tax4Fun2_ReferenceData_v2',",
      "  database_mode = 'Ref99NR',",
      "  path_to_temp_folder = tempdir(),",
      "  normalize_by_copy_number = TRUE,",
      "  min_identity_to_reference = 97,",
      "  use_uproc = TRUE, num_threads = 1)",
      "pathway_abundance <- tax4fun$res_tax4fun2_pathway",
      "data('Tax4Fun2_KEGG', package = 'microeco')",
      "pathway_annotation <- Tax4Fun2_KEGG$ptw_desc[rownames(pathway_abundance), ]")))
  }
  if (method_id %in% c("picrust2_import", "bugbase_import")) {
    tool <- switch(method_id,
      bugbase_import = "BugBase", "PICRUSt2")
    return(microbiome_parseable_code(c(
      sprintf("# Import a completed %s abundance table.", tool),
      microbiome_function_table_input_code(),
      "relative_function <- function_table / rowSums(function_table)",
      "group_tests <- apply(function_table, 2, function(value) kruskal.test(value ~ group))",
      "adjusted_p <- p.adjust(vapply(group_tests, function(x) x$p.value, numeric(1)), method = 'BH')")))
  }
  if (method_id %in% c("funguild", "fungaltraits")) {
    database <- if (identical(method_id, "funguild")) {
      "FUNGuild"
    } else {
      "FungalTraits"
    }
    prediction_call <- if (identical(method_id, "funguild")) {
      paste0(
        "fungal_function$cal_func(fungi_database = 'FUNGuild', ",
        "FUNGuild_confidence = c('Highly Probable', 'Probable', 'Possible'))")
    } else {
      "fungal_function$cal_func(fungi_database = 'FungalTraits')"
    }
    return(microbiome_parseable_code(c(
      "library(microeco)",
      "required_ranks <- c('Kingdom', 'Phylum', 'Class', 'Order', 'Family', 'Genus', 'Species')",
      "stopifnot(all(required_ranks %in% names(bundle$taxonomy)))",
      microbiome_microeco_input_code("dataset"),
      "dataset$tax_table <- subset(dataset$tax_table, grepl('Fungi', Kingdom, ignore.case = TRUE))",
      "dataset$tidy_dataset()",
      "fungal_function <- trans_func$new(dataset)",
      "fungal_function$for_what <- 'fungi'",
      sprintf("# microeco built-in fungal database: %s", database),
      prediction_call,
      "fungal_function$cal_func_FR(abundance_weighted = TRUE, perc = TRUE)",
      "trait_by_feature <- fungal_function$res_func",
      "trait_by_sample <- fungal_function$res_func_FR")))
  }
  if (identical(method_id, "faprotax")) {
    return(microbiome_parseable_code(c(
      "library(microeco)",
      microbiome_microeco_input_code("dataset"),
      "func <- trans_func$new(dataset = dataset)",
      "func$cal_func(prok_database = 'FAPROTAX')",
      "func$cal_func_FR(abundance_weighted = TRUE, perc = FALSE, remove_zero = TRUE)",
      "func_abundance <- func$res_func_FR",
      "env <- bundle$environment",
      "t3 <- trans_env$new(dataset = dataset, add_data = env)",
      "t3$cal_cor(add_abund_table = func_abundance, method = 'spearman')",
      "t3$plot_cor(cluster_ggplot = 'both')")))
  }
  database <- switch(method_id,
    faprotax = "FAPROTAX")
  microbiome_parseable_code(c(
    "library(microeco)",
    "mapping <- bundle$functional_mapping",
    sprintf("# Versioned taxonomy-to-function database: %s", database),
    "function_counts <- sapply(unique(mapping$Function), function(fun) rowSums(counts[, taxonomy$Genus %in% mapping$Taxon[mapping$Function == fun], drop = FALSE]))"))
}

microbiome_run_faprotax <- function(bundle, spec = list()) {
  if (!requireNamespace("microeco", quietly = TRUE)) {
    stop("FAPROTAX analysis requires the microeco package.", call. = FALSE)
  }
  suppressPackageStartupMessages(
    require("microeco", character.only = TRUE))

  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  if (!identical(bundle$marker_type, "16S")) {
    stop("FAPROTAX is only available for 16S amplicon data.", call. = FALSE)
  }
  if (!nrow(bundle$taxonomy) || !ncol(bundle$taxonomy)) {
    stop("FAPROTAX requires a taxonomy annotation table matched to the OTU/ASV table.",
      call. = FALSE)
  }
  if (nrow(bundle$taxonomy) != length(bundle$feature_ids) ||
      !identical(rownames(bundle$taxonomy), bundle$feature_ids)) {
    stop("The taxonomy table must cover every OTU/ASV and use matching feature IDs.",
      call. = FALSE)
  }

  dataset <- microbiome_microeco_dataset(bundle)
  fit <- microeco::trans_func$new(dataset = dataset)
  captured <- microbiome_capture_runtime_output(function() {
    fit$cal_func(prok_database = "FAPROTAX")
    fit$cal_func_FR(
      abundance_weighted = TRUE, perc = FALSE, remove_zero = TRUE)
    fit
  })
  fit <- captured$value

  abundance <- as.data.frame(
    fit$res_func_FR, stringsAsFactors = FALSE, check.names = FALSE)
  if (!nrow(abundance) || !ncol(abundance)) {
    stop(paste(
      "The microeco built-in FAPROTAX database returned no predicted functions.",
      "Check that the taxonomy names and feature IDs are valid."),
      call. = FALSE)
  }
  if (!all(bundle$sample_ids %in% rownames(abundance))) {
    stop("The FAPROTAX result does not contain all input samples.", call. = FALSE)
  }
  abundance <- abundance[bundle$sample_ids, , drop = FALSE]

  feature_function <- as.data.frame(
    fit$res_func, stringsAsFactors = FALSE, check.names = FALSE)
  if (!all(bundle$feature_ids %in% rownames(feature_function))) {
    stop("The FAPROTAX feature mapping does not match the input OTU/ASV IDs.",
      call. = FALSE)
  }
  feature_function <- feature_function[bundle$feature_ids, , drop = FALSE]
  matched <- rowSums(as.matrix(feature_function), na.rm = TRUE) > 0
  database_version <- paste0(
    "FAPROTAX bundled with microeco ",
    as.character(utils::packageVersion("microeco")))

  summary <- data.frame(
    Function = names(abundance),
    MeanAbundance = unname(colMeans(abundance)),
    MeanRelativeAbundance = unname(colMeans(abundance)),
    Prevalence = unname(colMeans(abundance > 0)),
    Database = "FAPROTAX",
    stringsAsFactors = FALSE)
  taxonomy_used <- data.frame(
    Feature = bundle$feature_ids, bundle$taxonomy,
    row.names = NULL, check.names = FALSE)
  tables <- list(
    function_summary = summary,
    function_abundance = data.frame(
      SampleID = rownames(abundance), abundance,
      row.names = NULL, check.names = FALSE),
    feature_function_binary = data.frame(
      Feature = rownames(feature_function), feature_function,
      row.names = NULL, check.names = FALSE),
    mapping_summary = data.frame(
      Metric = c(
        "Input features", "Features matched by FAPROTAX",
        "Unmatched features", "Matched feature fraction"),
      Value = c(
        length(matched), sum(matched), sum(!matched), mean(matched)),
      stringsAsFactors = FALSE),
    unmatched_features = data.frame(
      Feature = bundle$feature_ids[!matched], stringsAsFactors = FALSE),
    taxonomy_used = taxonomy_used,
    mapping_evidence = data.frame(
      DatabaseVersion = database_version,
      Evidence = "microeco built-in FAPROTAX taxonomy-to-function database",
      stringsAsFactors = FALSE))

  result <- new_microbiome_result(
    "faprotax", status = "warning", marker_type = bundle$marker_type,
    data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle, aligned$orientation),
    analysis_spec = spec,
    actual_parameters = list(
      engine = "microeco::trans_func$cal_func + cal_func_FR",
      database = "FAPROTAX",
      database_source = "microeco built-in database",
      database_version = database_version,
      abundance_weighted = TRUE,
      matched_features = sum(matched),
      unmatched_features = sum(!matched)),
    model_objects = list(microtable = dataset, trans_func = fit),
    functional_tables = tables, tables = tables,
    warnings = unique(c(
      paste0(
        "FAPROTAX \u8f93\u51fa\u662f\u57fa\u4e8e 16S \u5206\u7c7b\u6ce8\u91ca\u548c microeco \u5185\u7f6e\u6570\u636e\u5e93\u7684",
        "\u63a8\u65ad\u529f\u80fd\uff0c\u4e0d\u662f\u5b8f\u57fa\u56e0\u7ec4\u5b9e\u6d4b\u529f\u80fd\u3002"),
      captured$warnings)),
    runtime_log = captured$log,
    available_outputs = names(tables),
    package_versions = microbiome_package_versions("microeco"),
    generated_code = microbiome_extended_function_code("faprotax"),
    registration_manifest = microbiome_registration_manifest(
      bundle, "faprotax", names(tables)))
  microbiome_enhance_function_result(result, bundle, spec)
}

microbiome_run_function <- function(method_id, bundle, spec = list()) {
  if (method_id %in% c("funguild", "fungaltraits")) {
    return(microbiome_run_fungal_function(
      method_id, bundle, spec))
  }
  if (identical(method_id, "tax4fun2")) {
    return(microbiome_run_tax4fun2(bundle, spec))
  }
  if (identical(method_id, "faprotax")) {
    return(microbiome_run_faprotax(bundle, spec))
  }
  import_methods <- c(
    picrust2_import = "PICRUSt2", bugbase_import = "BugBase")
  base_method <- if (method_id %in% names(import_methods)) {
    "picrust2_import"
  } else {
    method_id
  }
  result <- microbiome_run_function_core(base_method, bundle, spec)
  if (!identical(base_method, method_id)) {
    result$method_id <- method_id
    result$actual_parameters$tool <- unname(import_methods[[method_id]])
    result$warnings <- paste0(
      unname(import_methods[[method_id]]),
      " results are imported from its completed external workflow; ",
      "DAVA does not fabricate predictions from taxonomic abundance.")
  }
  result$generated_code <- microbiome_extended_function_code(method_id)
  microbiome_enhance_function_result(result, bundle, spec)
}

microbiome_microeco_dataset <- function(bundle, require_tree = FALSE) {
  sample_table <- as.data.frame(bundle$metadata, check.names = FALSE)
  if (!nrow(sample_table)) {
    sample_table <- data.frame(
      SampleID = bundle$sample_ids, stringsAsFactors = FALSE)
  }
  rownames(sample_table) <- bundle$sample_ids
  taxonomy <- as.data.frame(bundle$taxonomy, check.names = FALSE)
  if (!nrow(taxonomy)) {
    taxonomy <- data.frame(
      Feature = bundle$feature_ids, stringsAsFactors = FALSE)
  }
  rownames(taxonomy) <- bundle$feature_ids
  arguments <- list(
    sample_table = sample_table,
    otu_table = as.data.frame(t(bundle$counts), check.names = FALSE),
    tax_table = taxonomy,
    rep_fasta = microbiome_representative_sequence_list(
      bundle$representative_sequences))
  if (require_tree) arguments$phylo_tree <- bundle$phylogeny
  do.call(microeco::microtable$new, arguments)
}

microbiome_assembly_plot_choices <- function(method_id) {
  if (method_id %in% c("nst", "tnst", "pnst")) {
    return(c(
      "Group randomness index graph" = "stochasticity_group",
      "Sample pair randomness distribution" = "stochasticity_pair"))
  }
  if (method_id %in% c("beta_mntd", "beta_nti", "rcbray")) {
    return(c(
      "Sample pair matrix heatmap" = "pairwise_heatmap",
      "Box plot of distribution between groups" = "pairwise_group_boxplot"))
  }
  if (identical(method_id, "assembly_nri_nti")) {
    return(c("NRI/NTI grouped box plot" = "nri_nti_boxplot"))
  }
  if (identical(method_id, "niche_breadth_assembly")) {
    return(c(
      "Species level niche breadth ranking chart" = "niche_breadth_bar",
      "Sample level niche width group plot" = "niche_breadth_sample_boxplot",
      "Species niche width distribution map" = "niche_breadth_distribution",
      "Sample niche width distribution map" = "niche_breadth_sample_distribution"))
    return(c(
      "Niche breadth ranking chart" = "niche_breadth_bar",
      "Niche width distribution map" = "niche_breadth_distribution"))
  }
  if (identical(method_id, "bnti_rcbray")) {
    return(c(
      "Ecological process scale diagram" = "process_proportions",
      "βNTI-RCbray process scatter plot" = "process_scatter"))
  }
  if (identical(method_id, "icamp")) {
    return(c(
      "Ecological process contribution stacked diagram" = "icamp_process_composition",
      "Dominant process proportion diagram" = "icamp_dominant_process"))
  }
  c("Neutral model fitting diagram" = "ncm_fit")
}

microbiome_assembly_group <- function(bundle, spec) {
  group <- spec$group %||% ""
  if (!nzchar(group) || !group %in% names(bundle$metadata)) {
    stop("Select a categorical grouping variable for this assembly method.",
      call. = FALSE)
  }
  metadata <- microbiome_metadata_by_sample(bundle$metadata)
  if (!all(bundle$sample_ids %in% rownames(metadata))) {
    stop("The selected metadata table does not match all OTU/ASV samples.",
      call. = FALSE)
  }
  values <- droplevels(factor(metadata[bundle$sample_ids, group]))
  if (anyNA(values)) {
    stop("The grouping variable contains missing values for OTU/ASV samples.",
      call. = FALSE)
  }
  if (nlevels(values) < 2L) {
    stop("The grouping variable must contain at least two levels.",
      call. = FALSE)
  }
  data.frame(Group = values, row.names = bundle$sample_ids)
}

microbiome_pairwise_long <- function(matrix, value_name) {
  matrix <- as.matrix(matrix)
  index <- which(upper.tri(matrix), arr.ind = TRUE)
  result <- data.frame(
    Sample1 = rownames(matrix)[index[, 1]],
    Sample2 = colnames(matrix)[index[, 2]],
    Value = matrix[index], stringsAsFactors = FALSE)
  names(result)[3] <- value_name
  result[is.finite(result[[value_name]]), , drop = FALSE]
}

microbiome_assembly_significance <- function(p) {
  ifelse(is.na(p), NA_character_,
    ifelse(p < 0.001, "***", ifelse(p < 0.01, "**",
      ifelse(p < 0.05, "*", "ns"))))
}

microbiome_assembly_group_tests <- function(
    data, value_col = "Value", group_col = "Group",
    facet_col = NULL, p_adjust = "BH") {
  data <- as.data.frame(data, check.names = FALSE)
  facets <- if (!is.null(facet_col) && facet_col %in% names(data)) {
    split(data, as.character(data[[facet_col]]), drop = TRUE)
  } else {
    list(`All data` = data)
  }
  results <- lapply(names(facets), function(facet_name) {
    part <- facets[[facet_name]]
    part <- part[is.finite(part[[value_col]]) & !is.na(part[[group_col]]), , drop = FALSE]
    groups <- unique(as.character(part[[group_col]]))
    if (length(groups) < 2L) return(NULL)
    pairs <- utils::combn(groups, 2L, simplify = FALSE)
    rows <- lapply(pairs, function(pair) {
      first <- part[as.character(part[[group_col]]) == pair[[1]], value_col]
      second <- part[as.character(part[[group_col]]) == pair[[2]], value_col]
      if (length(first) < 2L || length(second) < 2L) return(NULL)
      test <- suppressWarnings(stats::wilcox.test(first, second, exact = FALSE))
      data.frame(Group1 = pair[[1]], Group2 = pair[[2]],
        PValue = test$p.value, stringsAsFactors = FALSE)
    })
    rows <- Filter(Negate(is.null), rows)
    if (!length(rows)) return(NULL)
    result <- do.call(rbind, rows)
    result$AdjustedP <- stats::p.adjust(result$PValue, method = p_adjust)
    result$Significance <- microbiome_assembly_significance(result$AdjustedP)
    if (!is.null(facet_col)) result[[facet_col]] <- facet_name
    result
  })
  results <- Filter(Negate(is.null), results)
  if (!length(results)) return(data.frame())
  do.call(rbind, results)
}

microbiome_assembly_add_brackets <- function(
    plot, tests, data, value_col = "Value", group_col = "Group",
    facet_col = NULL) {
  if (!nrow(tests)) return(plot)
  levels <- unique(as.character(data[[group_col]]))
  tests$X1 <- match(tests$Group1, levels)
  tests$X2 <- match(tests$Group2, levels)
  facets <- if (!is.null(facet_col)) unique(as.character(tests[[facet_col]])) else "All data"
  positioned <- lapply(facets, function(facet_name) {
    rows <- if (!is.null(facet_col)) tests[as.character(tests[[facet_col]]) == facet_name, , drop = FALSE] else tests
    values <- if (!is.null(facet_col)) {
      data[[value_col]][as.character(data[[facet_col]]) == facet_name]
    } else data[[value_col]]
    values <- values[is.finite(values)]
    span <- max(diff(range(values)), abs(max(values)), 1)
    rows$Y <- max(values) + seq_len(nrow(rows)) * span * 0.12
    rows$Tip <- span * 0.035
    rows
  })
  positioned <- do.call(rbind, positioned)
  segment <- rbind(
    transform(positioned, XA = X1, XB = X2, YA = Y, YB = Y),
    transform(positioned, XA = X1, XB = X1, YA = Y, YB = Y - Tip),
    transform(positioned, XA = X2, XB = X2, YA = Y, YB = Y - Tip))
  plot +
    ggplot2::geom_segment(data = segment, inherit.aes = FALSE,
      ggplot2::aes(x = .data$XA, xend = .data$XB, y = .data$YA, yend = .data$YB)) +
    ggplot2::geom_text(data = positioned, inherit.aes = FALSE,
      ggplot2::aes(x = (.data$X1 + .data$X2) / 2, y = .data$Y, label = .data$Significance),
      vjust = -0.25, size = 3.5) +
    ggplot2::coord_cartesian(clip = "off") +
    ggplot2::theme(plot.margin = ggplot2::margin(12, 8, 8, 8))
}

microbiome_assembly_group_boxplot <- function(
    data, value_col = "Value", group_col = "Group", tests = data.frame(),
    facet_col = NULL, thresholds = numeric(), title = NULL, y_label = value_col) {
  data[[group_col]] <- factor(data[[group_col]], levels = unique(as.character(data[[group_col]])))
  plot <- ggplot2::ggplot(data, ggplot2::aes(
      .data[[group_col]], .data[[value_col]], color = .data[[group_col]])) +
    ggplot2::geom_boxplot(fill = "white", outlier.shape = NA, linewidth = 0.7) +
    ggplot2::geom_jitter(width = 0.12, alpha = 0.42, size = 1) +
    ggplot2::stat_summary(fun = mean, geom = "point", shape = 21,
      fill = "white", color = "black", size = 2.6) +
    ggplot2::labs(x = NULL, y = y_label, title = title) +
    ggplot2::theme_classic() +
    ggplot2::theme(legend.position = "none",
      axis.text.x = ggplot2::element_text(angle = 25, hjust = 1))
  if (length(thresholds)) {
    plot <- plot + ggplot2::geom_hline(
      yintercept = thresholds, linetype = 2, color = "#666666")
  }
  if (!is.null(facet_col)) {
    plot <- plot + ggplot2::facet_wrap(stats::as.formula(paste("~", facet_col)), scales = "free_y")
  }
  microbiome_assembly_add_brackets(
    plot, tests, data, value_col, group_col, facet_col)
}

microbiome_assembly_process_name <- function(value) {
  key <- gsub("[^a-z]+", "_", tolower(as.character(value)))
  key <- gsub("^_|_$", "", key)
  aliases <- c(
    heterogeneous_selection = "variable_selection", variable_selection = "variable_selection",
    homogeneous_selection = "homogeneous_selection",
    dispersal_limitation = "dispersal_limitation",
    homogenizing_dispersal = "homogeneous_dispersal", homogeneous_dispersal = "homogeneous_dispersal",
    undominated = "drift", drift = "drift", drift_others = "drift",
    drift_and_others = "drift")
  mapped <- unname(aliases[key])
  mapped[is.na(mapped)] <- key[is.na(mapped)]
  mapped
}

microbiome_assembly_process_plot <- function(data, title) {
  order <- c("dispersal_limitation", "drift", "homogeneous_dispersal",
    "homogeneous_selection", "variable_selection")
  colors <- c(dispersal_limitation = "#2C7FB8", drift = "#F57C00",
    homogeneous_dispersal = "#2CA02C", homogeneous_selection = "#D62728",
    variable_selection = "#9467BD")
  data$Process <- factor(data$Process, levels = order)
  ggplot2::ggplot(data, ggplot2::aes(.data$Group, .data$Proportion, fill = .data$Process)) +
    ggplot2::geom_col(width = 0.72) +
    ggplot2::scale_fill_manual(values = colors, drop = FALSE) +
    ggplot2::scale_y_continuous(labels = scales::percent, limits = c(0, 1), expand = c(0, 0)) +
    ggplot2::labs(x = "Group", y = "Ecological processes (%)", fill = "Process", title = title) +
    ggplot2::theme_classic()
}

microbiome_pairwise_plots <- function(matrix, metadata, group, value_name) {
  metadata <- microbiome_metadata_by_sample(metadata)
  long <- microbiome_pairwise_long(matrix, value_name)
  long$Comparison <- if (nzchar(group) && group %in% names(metadata)) {
    first <- as.character(metadata[long$Sample1, group])
    second <- as.character(metadata[long$Sample2, group])
    ifelse(first == second, first, "Between groups")
  } else {
    "All pairs"
  }
  heat <- as.data.frame(as.table(matrix), stringsAsFactors = FALSE)
  names(heat) <- c("Sample1", "Sample2", "Value")
  heat <- heat[is.finite(heat$Value), , drop = FALSE]
  list(
    pairwise_heatmap = ggplot2::ggplot(
      heat, ggplot2::aes(.data$Sample1, .data$Sample2,
        fill = .data$Value)) +
      ggplot2::geom_tile() +
      ggplot2::scale_fill_gradient2(
        low = "#2166AC", mid = "#F7F7F7", high = "#B2182B",
        midpoint = 0) +
      ggplot2::labs(
        x = NULL, y = NULL, fill = value_name,
        title = paste(value_name, "Pairwise Matrix")) +
      ggplot2::theme_classic() +
      ggplot2::theme(
        axis.text = ggplot2::element_blank(),
        axis.ticks = ggplot2::element_blank()),
    pairwise_group_boxplot = ggplot2::ggplot(
      long, ggplot2::aes(
        .data$Comparison, .data[[value_name]],
        fill = .data$Comparison)) +
      ggplot2::geom_boxplot(outlier.shape = NA) +
      ggplot2::geom_jitter(width = 0.12, alpha = 0.25, size = 0.7) +
      ggplot2::labs(
        x = NULL, y = value_name,
        title = paste(value_name, "by Group")) +
      ggplot2::theme_classic() +
      ggplot2::theme(
        legend.position = "none",
        axis.text.x = ggplot2::element_text(angle = 30, hjust = 1)))
}

microbiome_run_nst_family <- function(method_id, bundle, spec) {
  if (!requireNamespace("NST", quietly = TRUE)) {
    stop("NST package is required.", call. = FALSE)
  }
  group <- microbiome_assembly_group(bundle, spec)
  permutations <- max(9L, as.integer(
    spec$n_iterations %||% spec$permutations %||% 999L))
  workers <- max(1L, as.integer(spec$n_cores %||% 1L))
  weighted <- isTRUE(spec$abundance_weighted %||% TRUE)
  seed <- as.integer(spec$seed %||% 2026L)
  set.seed(seed)
  captured <- microbiome_capture_runtime_output(function() {
    if (identical(method_id, "pnst")) {
      if (is.null(bundle$phylogeny) ||
          !inherits(bundle$phylogeny, "phylo")) {
        stop("pNST requires a matched phylogenetic tree.", call. = FALSE)
      }
      pd_dir <- tempfile("dava-pnst-")
      dir.create(pd_dir)
      on.exit(unlink(pd_dir, recursive = TRUE, force = TRUE), add = TRUE)
      NST::pNST(
        comm = bundle$counts, tree = bundle$phylogeny, group = group,
        abundance.weighted = weighted, rand = permutations,
        nworker = workers, pd.wd = pd_dir, output.rand = TRUE)
    } else {
      NST::tNST(
        comm = bundle$counts, group = group,
        dist.method = spec$distance_method %||% "jaccard",
        abundance.weighted = weighted, rand = permutations,
        nworker = workers,
        null.model = spec$null_model_method %||% "PF",
        output.rand = TRUE)
    }
  })
  fit <- captured$value
  group_table <- as.data.frame(fit$index.grp, check.names = FALSE)
  pair_table <- as.data.frame(fit$index.pair, check.names = FALSE)
  nst_column <- grep("^NST", names(group_table), value = TRUE)[1]
  bootstrap <- NST::nst.boot(fit, group = group, rand = permutations,
    trace = FALSE, two.tail = TRUE, out.detail = TRUE, nworker = workers)
  bootstrap_long <- do.call(rbind, lapply(names(bootstrap$detail$NST.boot), function(level) {
    data.frame(Group = level, NST = as.numeric(bootstrap$detail$NST.boot[[level]]),
      stringsAsFactors = FALSE)
  }))
  bootstrap_long <- bootstrap_long[is.finite(bootstrap_long$NST), , drop = FALSE]
  group_levels <- levels(group$Group)
  group_tests <- as.data.frame(bootstrap$compare, check.names = FALSE)
  group_tests <- group_tests[group_tests$Index == "NST", , drop = FALSE]
  if (nrow(group_tests)) {
    decode_group <- function(value) {
      value <- as.character(value)
      numeric_value <- suppressWarnings(as.integer(value))
      ifelse(!is.na(numeric_value) & numeric_value >= 1L & numeric_value <= length(group_levels),
        group_levels[numeric_value], value)
    }
    group_tests$Group1 <- decode_group(group_tests$group1)
    group_tests$Group2 <- decode_group(group_tests$group2)
    group_tests$PValue <- as.numeric(group_tests$p.wtest)
    group_tests$AdjustedP <- stats::p.adjust(
      group_tests$PValue, method = spec$p_adjust_method %||% "BH")
    group_tests$Significance <- microbiome_assembly_significance(group_tests$AdjustedP)
  }
  group_plot <- microbiome_assembly_group_boxplot(
    bootstrap_long, value_col = "NST", tests = group_tests, thresholds = 0.5,
    title = if (method_id == "pnst") "Phylogenetic NST by Group" else "Taxonomic NST by Group",
    y_label = "Normalized stochasticity ratio (bootstrap)")
  pair_nst <- grep("^NST", names(pair_table), value = TRUE)[1]
  pair_plot <- if (length(pair_nst) && !is.na(pair_nst)) {
    ggplot2::ggplot(
      pair_table,
      ggplot2::aes(.data[[pair_nst]])) +
      ggplot2::geom_histogram(bins = 30, fill = "#3B7EA1") +
      ggplot2::geom_vline(xintercept = 0.5, linetype = 2) +
      ggplot2::labs(
        x = "Pairwise NST", y = "Pair count",
        title = "Pairwise Stochasticity Distribution") +
      ggplot2::theme_classic()
  } else {
    group_plot
  }
  requested <- as.character(spec$plot_types %||%
    unname(microbiome_assembly_plot_choices(method_id)))
  plots <- list(
    stochasticity_group = group_plot,
    stochasticity_pair = pair_plot)
  plots <- plots[intersect(names(plots), requested)]
  tables <- list(
    stochasticity_by_group = group_table,
    stochasticity_by_pair = pair_table,
    stochasticity_bootstrap = bootstrap_long,
    stochasticity_group_tests = group_tests)
  new_microbiome_result(
    method_id, status = if (length(captured$warnings)) "warning" else "success",
    marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle),
    analysis_spec = spec,
    actual_parameters = list(
      group = spec$group, permutations = permutations, workers = workers,
      abundance_weighted = weighted, plot_types = names(plots)),
    model_objects = list(nst = fit, nst_bootstrap = bootstrap),
    tables = tables, assembly_tables = tables, plots = plots,
    runtime_log = captured$log, warnings = captured$warnings,
    available_outputs = c(names(tables), names(plots)),
    generated_code = microbiome_assembly_code(method_id, spec),
    package_versions = microbiome_package_versions("NST"),
    registration_manifest = microbiome_registration_manifest(
      bundle, method_id, names(tables)))
}

microbiome_run_phylogenetic_assembly <- function(method_id, bundle, spec) {
  if (!requireNamespace("microeco", quietly = TRUE)) {
    stop("microeco is required.", call. = FALSE)
  }
  if (is.null(bundle$phylogeny) || !inherits(bundle$phylogeny, "phylo")) {
    stop(method_id, " requires a matched phylogenetic tree.",
      call. = FALSE)
  }
  dataset <- microbiome_microeco_dataset(bundle, require_tree = TRUE)
  fit <- microeco::trans_nullmodel$new(dataset = dataset)
  weighted <- isTRUE(spec$abundance_weighted %||% TRUE)
  permutations <- max(9L, as.integer(
    spec$n_iterations %||% spec$permutations %||% 999L))
  workers <- max(1L, as.integer(spec$n_cores %||% 1L))
  if (identical(method_id, "beta_mntd")) {
    fit$cal_betamntd(abundance.weighted = weighted)
    matrix <- as.matrix(fit$res_betamntd)
    value_name <- "betaMNTD"
  } else {
    fit$cal_ses_betamntd(
      runs = permutations,
      null.model = spec$null_model_method %||% "taxa.labels",
      abundance.weighted = weighted, nworker = workers,
      iterations = max(100L, permutations))
    matrix <- as.matrix(fit$res_ses_betamntd)
    value_name <- "betaNTI"
  }
  tables <- list(pairwise = microbiome_pairwise_long(matrix, value_name))
  plots <- microbiome_pairwise_plots(
    matrix, bundle$metadata, spec$group %||% "", value_name)
  requested <- as.character(spec$plot_types %||%
    unname(microbiome_assembly_plot_choices(method_id)))
  plots <- plots[intersect(names(plots), requested)]
  new_microbiome_result(
    method_id, status = "success", marker_type = bundle$marker_type,
    data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle),
    analysis_spec = spec,
    actual_parameters = list(
      permutations = if (method_id == "beta_nti") permutations else 0L,
      workers = workers, abundance_weighted = weighted,
      plot_types = names(plots)),
    model_objects = list(trans_nullmodel = fit),
    tables = tables, assembly_tables = tables, plots = plots,
    available_outputs = c(names(tables), names(plots)),
    generated_code = microbiome_assembly_code(method_id, spec),
    package_versions = microbiome_package_versions(c("microeco", "picante", "ape")),
    registration_manifest = microbiome_registration_manifest(
      bundle, method_id, names(tables)))
}

microbiome_run_rcbray <- function(bundle, spec) {
  if (!requireNamespace("iCAMP", quietly = TRUE)) {
    stop("iCAMP is required for RCbray.", call. = FALSE)
  }
  permutations <- max(9L, as.integer(
    spec$n_iterations %||% spec$permutations %||% 999L))
  workers <- max(1L, as.integer(spec$n_cores %||% 1L))
  set.seed(as.integer(spec$seed %||% 2026L))
  fit <- iCAMP::RC.cm(
    bundle$counts, rand = permutations, nworker = workers,
    weighted = isTRUE(spec$abundance_weighted %||% TRUE),
    sig.index = "RC", silent = TRUE)
  matrix <- as.matrix(fit$index)
  tables <- list(pairwise = microbiome_pairwise_long(matrix, "RCbray"))
  plots <- microbiome_pairwise_plots(
    matrix, bundle$metadata, spec$group %||% "", "RCbray")
  requested <- as.character(spec$plot_types %||%
    unname(microbiome_assembly_plot_choices("rcbray")))
  plots <- plots[intersect(names(plots), requested)]
  new_microbiome_result(
    "rcbray", status = "success", marker_type = bundle$marker_type,
    data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle),
    analysis_spec = spec,
    actual_parameters = list(
      permutations = permutations, workers = workers,
      plot_types = names(plots)),
    model_objects = list(rcbray = fit),
    tables = tables, assembly_tables = tables, plots = plots,
    available_outputs = c(names(tables), names(plots)),
    generated_code = microbiome_assembly_code("rcbray", spec),
    package_versions = microbiome_package_versions("iCAMP"),
    registration_manifest = microbiome_registration_manifest(
      bundle, "rcbray", names(tables)))
}

microbiome_run_icamp <- function(bundle, spec) {
  if (!requireNamespace("iCAMP", quietly = TRUE) ||
      !requireNamespace("ape", quietly = TRUE)) {
    stop("iCAMP and ape are required for iCAMP analysis.",
      call. = FALSE)
  }
  tree <- bundle$phylogeny
  if (is.null(tree) || !inherits(tree, "phylo")) {
    stop("iCAMP requires a matched rooted phylogenetic tree.", call. = FALSE)
  }
  if (!ape::is.rooted(tree)) {
    stop("iCAMP requires a rooted phylogenetic tree. Please select a rooted Newick tree.",
      call. = FALSE)
  }
  shared <- intersect(colnames(bundle$counts), tree$tip.label)
  if (length(shared) < 24L) {
    stop("iCAMP requires at least 24 taxa shared by counts and tree.",
      call. = FALSE)
  }
  community <- bundle$counts[, shared, drop = FALSE]
  tree <- ape::keep.tip(tree, shared)
  permutations <- max(9L, as.integer(
    spec$n_iterations %||% spec$permutations %||% 999L))
  workers <- max(1L, as.integer(spec$n_cores %||% 1L))
  requested_bin_size <- suppressWarnings(as.integer(
    spec$icamp_bin_size %||% 24L))
  if (!is.finite(requested_bin_size) || requested_bin_size < 12L) {
    requested_bin_size <- 24L
  }
  # iCAMP 1.5.x can fail in its bMPD correction step when all shared taxa
  # fall into one bin. Keep small datasets split into at least two bins.
  bin_size <- min(requested_bin_size,
    max(12L, floor(length(shared) / 3L)))
  bin_size_warning <- if (bin_size < requested_bin_size) {
    sprintf("iCAMP bin.size.limit was reduced from %d to %d for %d shared taxa to avoid a single-bin calculation.",
      requested_bin_size, bin_size, length(shared))
  } else {
    character()
  }
  work_dir <- tempfile("dava-icamp-")
  dir.create(work_dir)
  on.exit(unlink(work_dir, recursive = TRUE, force = TRUE), add = TRUE)
  set.seed(as.integer(spec$seed %||% 2026L))
  captured <- microbiome_capture_runtime_output(function() {
    suppressWarnings(iCAMP::icamp.big(
      comm = community, tree = tree,
      pd.wd = work_dir, output.wd = work_dir,
      rand = permutations, prefix = "dava_icamp",
      nworker = workers, memory.G = 4,
      detail.save = FALSE, qp.save = FALSE,
      bin.size.limit = bin_size))
  })
  runtime_warnings <- c(captured$warnings, bin_size_warning)
  # iCAMP 1.5.x calls the removed Windows memory.limit() API internally.
  # It is harmless under current R versions and does not indicate a failed run.
  runtime_warnings <- runtime_warnings[
    !grepl("^'memory\\.limit\\(\\)' is no longer supported$",
      runtime_warnings)]
  fit <- captured$value
  pairwise <- as.data.frame(fit[[1]], check.names = FALSE)
  process_columns <- setdiff(names(pairwise), c("sample1", "sample2"))
  process_summary <- data.frame(
    Process = microbiome_assembly_process_name(process_columns),
    MeanContribution = colMeans(pairwise[, process_columns, drop = FALSE],
      na.rm = TRUE),
    stringsAsFactors = FALSE)
  group_name <- trimws(as.character(spec$group %||% ""))
  process_group_summary <- data.frame()
  if (nzchar(group_name) && !group_name %in% names(bundle$metadata)) {
    stop("The selected iCAMP grouping variable is not present in sample metadata.",
      call. = FALSE)
  }
  if (nzchar(group_name)) {
    metadata <- microbiome_metadata_by_sample(bundle$metadata)
    group1 <- as.character(metadata[as.character(pairwise$sample1), group_name])
    group2 <- as.character(metadata[as.character(pairwise$sample2), group_name])
    if (anyNA(group1) || anyNA(group2)) {
      stop("The selected grouping variable is missing for one or more iCAMP samples.",
        call. = FALSE)
    }
    group_sizes <- table(as.character(metadata[rownames(community), group_name]))
    if (any(group_sizes < 2L)) {
      stop("Every iCAMP group must contain at least two matched samples.", call. = FALSE)
    }
    within_group <- !is.na(group1) & !is.na(group2) & group1 == group2
    if (any(within_group)) {
      grouped <- pairwise[within_group, process_columns, drop = FALSE]
      group_values <- group1[within_group]
      process_group_summary <- do.call(rbind, lapply(
        split(seq_len(nrow(grouped)), group_values), function(index) {
          data.frame(
            Group = group_values[index[[1L]]],
            Process = microbiome_assembly_process_name(process_columns),
            SamplePairCount = length(index),
            MeanContribution = colMeans(grouped[index, , drop = FALSE],
              na.rm = TRUE),
            stringsAsFactors = FALSE)
        }))
    }
  }
  composition_data <- if (nrow(process_group_summary)) {
    process_group_summary
  } else {
    transform(process_summary, Group = "All samples")
  }
  composition_data <- stats::aggregate(MeanContribution ~ Group + Process,
    composition_data, sum, na.rm = TRUE)
  totals <- ave(composition_data$MeanContribution, composition_data$Group, FUN = sum)
  composition_data$Proportion <- ifelse(totals > 0, composition_data$MeanContribution / totals, 0)
  if (nrow(process_group_summary)) {
    pair_counts <- unique(process_group_summary[
      c("Group", "Process", "SamplePairCount")])
    process_group_summary <- merge(
      composition_data, pair_counts, by = c("Group", "Process"), sort = FALSE)
    composition_data <- process_group_summary
  }
  dominant_index <- max.col(
    as.matrix(pairwise[, process_columns, drop = FALSE]),
    ties.method = "first")
  pairwise$DominantProcess <- microbiome_assembly_process_name(process_columns[dominant_index])
  dominant_summary <- as.data.frame(
    prop.table(table(pairwise$DominantProcess)),
    stringsAsFactors = FALSE)
  names(dominant_summary) <- c("Process", "Proportion")
  plots <- list(
    icamp_process_composition = microbiome_assembly_process_plot(
      composition_data, if (nrow(process_group_summary)) {
        "iCAMP Ecological Process Partition by Group"
      } else "iCAMP Ecological Process Partition"),
    icamp_dominant_process = ggplot2::ggplot(
      dominant_summary,
      ggplot2::aes(
        .data$Proportion,
        stats::reorder(.data$Process, .data$Proportion),
        fill = .data$Process)) +
      ggplot2::geom_col(show.legend = FALSE) +
      ggplot2::scale_x_continuous(labels = scales::percent) +
      ggplot2::labs(
        x = "Proportion of sample pairs", y = NULL,
        title = "Dominant iCAMP Process") +
      ggplot2::theme_classic())
  requested <- as.character(spec$plot_types %||%
    unname(microbiome_assembly_plot_choices("icamp")))
  plots <- plots[intersect(names(plots), requested)]
  tables <- list(
    pairwise_process_contribution = pairwise,
    process_summary = process_summary,
    process_group_summary = process_group_summary,
    dominant_process_summary = dominant_summary)
  new_microbiome_result(
    "icamp",
    status = if (length(runtime_warnings)) "warning" else "success",
    marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle),
    analysis_spec = spec,
    actual_parameters = list(
      permutations = permutations, workers = workers,
      bin_size_limit = bin_size,
      requested_bin_size_limit = requested_bin_size,
      group = group_name,
      plot_types = names(plots)),
    model_objects = list(icamp = fit),
    tables = tables, assembly_tables = tables, plots = plots,
    runtime_log = captured$log, warnings = runtime_warnings,
    available_outputs = c(names(tables), names(plots)),
    generated_code = microbiome_assembly_code("icamp", spec),
    package_versions = microbiome_package_versions(c("iCAMP", "ape")),
    registration_manifest = microbiome_registration_manifest(
      bundle, "icamp", names(tables)))
}

microbiome_picante_null_model <- function(value, default = "taxa.labels") {
  value <- as.character(value %||% default)[[1L]]
  if (is.na(value) || !nzchar(value)) value <- default
  aliases <- c(
    taxa_labels = "taxa.labels", `taxa labels` = "taxa.labels",
    independent_swap = "independentswap", `independent swap` = "independentswap",
    trial_swap = "trialswap", `trial swap` = "trialswap"
  )
  if (value %in% names(aliases)) value <- unname(aliases[[value]])
  allowed <- c("taxa.labels", "richness", "frequency", "sample.pool",
    "phylogeny.pool", "independentswap", "trialswap")
  if (!value %in% allowed) default else value
}

microbiome_run_nri_nti <- function(bundle, spec) {
  if (!requireNamespace("picante", quietly = TRUE) ||
      !requireNamespace("ape", quietly = TRUE)) {
    stop("picante and ape are required for NRI/NTI.", call. = FALSE)
  }
  tree <- bundle$phylogeny
  if (is.null(tree) || !inherits(tree, "phylo")) {
    stop("NRI/NTI requires a matched phylogenetic tree.", call. = FALSE)
  }
  shared <- intersect(colnames(bundle$counts), tree$tip.label)
  community <- bundle$counts[, shared, drop = FALSE]
  distance <- as.matrix(ape::cophenetic.phylo(
    ape::keep.tip(tree, shared)))
  runs <- max(9L, as.integer(
    spec$n_iterations %||% spec$permutations %||% 999L))
  null_model <- microbiome_picante_null_model(spec$null_model_method)
  nri_fit <- picante::ses.mpd(
    community, distance, null.model = null_model,
    abundance.weighted = isTRUE(spec$abundance_weighted %||% TRUE),
    runs = runs)
  nti_fit <- picante::ses.mntd(
    community, distance, null.model = null_model,
    abundance.weighted = isTRUE(spec$abundance_weighted %||% TRUE),
    runs = runs)
  table <- data.frame(
    SampleID = rownames(community),
    NRI = -as.numeric(nri_fit$mpd.obs.z),
    NTI = -as.numeric(nti_fit$mntd.obs.z),
    stringsAsFactors = FALSE)
  group <- spec$group %||% ""
  metadata <- microbiome_metadata_by_sample(bundle$metadata)
  table$Group <- if (nzchar(group)) {
    validated_group <- microbiome_assembly_group(bundle, spec)
    as.character(validated_group[table$SampleID, "Group"])
  } else {
    "All samples"
  }
  long <- tidyr::pivot_longer(
    table, c("NRI", "NTI"), names_to = "Index", values_to = "Value")
  group_tests <- microbiome_assembly_group_tests(
    long, facet_col = "Index", p_adjust = spec$p_adjust_method %||% "BH")
  plot <- microbiome_assembly_group_boxplot(
    long, tests = group_tests, facet_col = "Index",
    thresholds = c(-1.96, 1.96),
    title = "Net Relatedness and Nearest Taxon Indices",
    y_label = "Standardized effect size")
  tables <- list(nri_nti = table, nri_nti_group_tests = group_tests)
  new_microbiome_result(
    "assembly_nri_nti", status = "success",
    marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle),
    analysis_spec = spec,
    actual_parameters = list(
      permutations = runs, null_model = null_model,
      p_adjust_method = spec$p_adjust_method %||% "BH",
      plot_types = "nri_nti_boxplot"),
    model_objects = list(nri = nri_fit, nti = nti_fit),
    tables = tables, assembly_tables = tables,
    plots = list(nri_nti_boxplot = plot),
    available_outputs = c(names(tables), "nri_nti_boxplot"),
    generated_code = microbiome_assembly_code("assembly_nri_nti", spec),
    package_versions = microbiome_package_versions(c("picante", "ape")),
    registration_manifest = microbiome_registration_manifest(
      bundle, "assembly_nri_nti", names(tables)))
}

microbiome_run_niche_breadth <- function(bundle, spec) {
  counts <- as.matrix(bundle$counts)
  counts[!is.finite(counts) | counts < 0] <- 0
  metadata <- as.data.frame(bundle$metadata, check.names = FALSE)
  metadata <- metadata[match(rownames(counts), rownames(metadata)), , drop = FALSE]
  group <- spec$group %||% ""
  if (nzchar(group) && group %in% names(metadata)) {
    group_values <- as.character(metadata[[group]])
    group_values[is.na(group_values) | !nzchar(group_values)] <- "Unknown"
  } else {
    group <- ""
    group_values <- rep("Overall", nrow(counts))
  }
  group_values <- factor(group_values, levels = unique(group_values))

  species_rows <- lapply(levels(group_values), function(level) {
    sub_counts <- counts[group_values == level, , drop = FALSE]
    relative <- sweep(sub_counts, 1, pmax(rowSums(sub_counts), 1), "/")
    taxon_profile <- sweep(sub_counts, 2, pmax(colSums(sub_counts), 1), "/")
    breadth <- 1 / pmax(colSums(taxon_profile^2), .Machine$double.eps)
    data.frame(
      Taxon = colnames(counts), Group = level,
      LevinsBreadth = as.numeric(breadth),
      MeanRelativeAbundance = colMeans(relative),
      Prevalence = colMeans(sub_counts > 0), stringsAsFactors = FALSE)
  })
  species_table <- do.call(rbind, species_rows)
  rownames(species_table) <- NULL
  species_table <- species_table[order(
    species_table$Group, -species_table$LevinsBreadth), , drop = FALSE]

  sample_relative <- sweep(counts, 1, pmax(rowSums(counts), 1), "/")
  sample_table <- data.frame(
    SampleID = rownames(counts), Group = as.character(group_values),
    LevinsBreadth = 1 / pmax(rowSums(sample_relative^2), .Machine$double.eps),
    Richness = rowSums(counts > 0), TotalAbundance = rowSums(counts),
    stringsAsFactors = FALSE)
  top <- do.call(rbind, lapply(split(species_table, species_table$Group),
    function(x) utils::head(x[order(-x$LevinsBreadth), , drop = FALSE], 30L)))
  top$Taxon <- factor(top$Taxon, levels = rev(unique(top$Taxon)))
  grouped_theme <- ggplot2::theme_classic() + ggplot2::theme(
    axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
  plots <- list(
    niche_breadth_bar = ggplot2::ggplot(
      top, ggplot2::aes(
        .data$LevinsBreadth,
        .data$Taxon,
        fill = .data$MeanRelativeAbundance)) +
      ggplot2::geom_col() +
      ggplot2::scale_fill_gradient(low = "#C7E9E4", high = "#126E63") +
      ggplot2::labs(
        x = "Levins niche breadth", y = "Taxon",
        fill = "Mean relative abundance",
        title = "Species-level Niche Breadth") +
      ggplot2::facet_wrap(~Group, scales = "free_y") + grouped_theme,
    niche_breadth_sample_boxplot = ggplot2::ggplot(
      sample_table, ggplot2::aes(.data$Group, .data$LevinsBreadth,
        fill = .data$Group)) +
      ggplot2::geom_boxplot(outlier.shape = NA, alpha = 0.8) +
      ggplot2::geom_jitter(width = 0.12, alpha = 0.7, size = 1.4) +
      ggplot2::labs(x = "Group", y = "Levins niche breadth",
        title = "Sample-level Niche Breadth") +
      ggplot2::guides(fill = "none") + grouped_theme,
    niche_breadth_distribution = ggplot2::ggplot(
      species_table, ggplot2::aes(.data$LevinsBreadth, fill = .data$Group)) +
      ggplot2::geom_histogram(bins = 30, alpha = 0.7, position = "identity") +
      ggplot2::labs(
        x = "Levins niche breadth", y = "Taxon count", fill = "Group",
        title = "Species Niche Breadth Distribution") + grouped_theme,
    niche_breadth_sample_distribution = ggplot2::ggplot(
      sample_table, ggplot2::aes(.data$LevinsBreadth, fill = .data$Group)) +
      ggplot2::geom_density(alpha = 0.45, na.rm = TRUE) +
      ggplot2::labs(x = "Levins niche breadth", y = "Density", fill = "Group",
        title = "Sample Niche Breadth Distribution") + grouped_theme)
  requested <- as.character(spec$plot_types %||%
    unname(microbiome_assembly_plot_choices("niche_breadth_assembly")))
  plots <- plots[intersect(names(plots), requested)]
  tables <- list(
    niche_breadth = species_table,
    niche_breadth_species = species_table,
    niche_breadth_sample = sample_table)
  new_microbiome_result(
    "niche_breadth_assembly", status = "success",
    marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle),
    analysis_spec = spec,
    actual_parameters = list(
      index = "Levins", grouping_variable = group %||% "Overall",
      plot_types = names(plots)),
    tables = tables, assembly_tables = tables, plots = plots,
    available_outputs = c(names(tables), names(plots)),
    generated_code = microbiome_assembly_code(
      "niche_breadth_assembly", spec),
    package_versions = microbiome_package_versions("microeco"),
    registration_manifest = microbiome_registration_manifest(
      bundle, "niche_breadth_assembly", names(tables)))
}

microbiome_run_assembly_source <- function(method_id, bundle, spec = list()) {
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  if (identical(method_id, "ncm")) {
    result <- microbiome_run_ncm_source(method_id, bundle, spec)
    if (!is.null(result$plots$ncm_fit)) {
      result$actual_parameters$plot_engine <-
        "minpack.lm::nlsLM + ggplot2 + patchwork"
      return(result)
    }
    stop("Sloan NCM did not return the final combined plot.",
      call. = FALSE)
  }
  if (identical(method_id, "bnti_rcbray")) {
    result <- microbiome_run_bnti_rcbray(bundle, spec)
    pairwise <- result$tables$pairwise_process
    result$plots$process_scatter <- ggplot2::ggplot(
      pairwise,
      ggplot2::aes(.data$RCbray, .data$betaNTI,
        colour = .data$Process)) +
      ggplot2::geom_hline(yintercept = c(-2, 2), linetype = 2) +
      ggplot2::geom_vline(xintercept = c(-0.95, 0.95), linetype = 2) +
      ggplot2::geom_point(alpha = 0.7, size = 1.8) +
      ggplot2::labs(
        x = "RCbray", y = expression(beta * "NTI"),
        colour = "Ecological process",
        title = expression(beta * "NTI + RCbray Process Partition")) +
      ggplot2::theme_classic()
    requested <- as.character(spec$plot_types %||%
      unname(microbiome_assembly_plot_choices(method_id)))
    result$plots <- result$plots[
      intersect(names(result$plots), requested)]
    result$actual_parameters$plot_types <- names(result$plots)
    result$available_outputs <- unique(c(
      names(result$tables), names(result$plots)))
    return(result)
  }
  if (method_id %in% c("nst", "tnst", "pnst")) {
    return(microbiome_run_nst_family(method_id, bundle, spec))
  }
  if (method_id %in% c("beta_mntd", "beta_nti")) {
    return(microbiome_run_phylogenetic_assembly(method_id, bundle, spec))
  }
  if (identical(method_id, "rcbray")) {
    return(microbiome_run_rcbray(bundle, spec))
  }
  if (identical(method_id, "icamp")) {
    return(microbiome_run_icamp(bundle, spec))
  }
  if (identical(method_id, "assembly_nri_nti")) {
    return(microbiome_run_nri_nti(bundle, spec))
  }
  if (identical(method_id, "niche_breadth_assembly")) {
    return(microbiome_run_niche_breadth(bundle, spec))
  }
  stop("Assembly adapter does not support method: ", method_id,
    call. = FALSE)
}

microbiome_assembly_code <- function(method_id, spec = list()) {
  iterations <- max(9L, as.integer(
    spec$n_iterations %||% spec$permutations %||% 999L))
  workers <- max(1L, as.integer(spec$n_cores %||% 1L))
  lines <- switch(method_id,
    nst = , tnst = c(
      "library(NST)",
      sprintf(
        "fit <- NST::tNST(comm, group, dist.method = '%s', rand = %dL, nworker = %dL)",
        spec$distance_method %||% "jaccard", iterations, workers)),
    pnst = c(
      "library(NST)",
      sprintf(
        "fit <- NST::pNST(comm, tree = phylogeny, group = group, rand = %dL, nworker = %dL)",
        iterations, workers)),
    beta_mntd = c(
      "nm <- microeco::trans_nullmodel$new(dataset = microtable)",
      "nm$cal_betamntd(abundance.weighted = TRUE)"),
    beta_nti = c(
      "nm <- microeco::trans_nullmodel$new(dataset = microtable)",
      sprintf(
        "nm$cal_ses_betamntd(runs = %dL, null.model = '%s', nworker = %dL)",
        iterations, spec$null_model_method %||% "taxa.labels", workers)),
    rcbray = c(
      "library(iCAMP)",
      sprintf(
        "fit <- iCAMP::RC.cm(comm, rand = %dL, nworker = %dL, sig.index = 'RC')",
        iterations, workers)),
    icamp = c(
      "library(iCAMP)",
      sprintf(
        "fit <- iCAMP::icamp.big(comm, tree, rand = %dL, nworker = %dL, pd.wd = tempdir(), output.wd = tempdir())",
        iterations, workers)),
    assembly_nri_nti = c(
      "nri <- -picante::ses.mpd(comm, phylogenetic_distance, runs = 999)$mpd.obs.z",
      "nti <- -picante::ses.mntd(comm, phylogenetic_distance, runs = 999)$mntd.obs.z"),
    niche_breadth_assembly = c(
      "relative <- comm / rowSums(comm)",
      "levins_breadth <- 1 / colSums(sweep(relative^2, 1, rowSums(relative^2), '/'))"),
    "fit <- NULL")
  microbiome_parseable_code(lines)
}
