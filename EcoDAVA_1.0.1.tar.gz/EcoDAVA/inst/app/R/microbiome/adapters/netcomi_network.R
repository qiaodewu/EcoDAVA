microbiome_netcomi_measure_choices <- function() c(
  "Pearson correlation [fast]" = "pearson",
  "Spearman correlation [fast]" = "spearman",
  "Biweight midcorrelation [fast]" = "bicor",
  "SparCC [compositional; fast]" = "sparcc",
  "CCLasso" = "cclasso",
  "CCREPE" = "ccrepe",
  "SPIEC-EASI [moderate]" = "spieceasi",
  "SPRING [StARS; compute intensive]" = "spring",
  "gCoda" = "gcoda",
  "propr" = "propr")

microbiome_cross_domain_measure_choices <- function() c(
  "Spearman correlation [domain-wise CLR; recommended]" = "spearman",
  "Pearson correlation [domain-wise CLR]" = "pearson",
  "Biweight midcorrelation [domain-wise CLR]" = "bicor")

microbiome_cross_domain_plot_choices <- function(grouped = FALSE) {
  choices <- c(
    "Bacteria-fungi cross-domain network" = "cross_domain_network",
    "Within-domain and cross-domain edge composition" =
      "domain_edge_composition",
    "Cross-domain association heatmap" = "cross_domain_heatmap",
    "Node centrality by microbial domain" = "domain_centrality")
  if (isTRUE(grouped)) {
    choices <- c(
      choices,
      "Network-metric comparison [permutation; slow]" =
        "network_metric_forest",
      "Node-centrality differences [permutation; slow]" =
        "centrality_difference")
  }
  c(
    choices,
    "Cohesion by sample [additional calculation]" = "cohesion",
    "Robustness decay curve [slow]" = "robustness",
    "Node vulnerability [slow]" = "node_vulnerability",
    "Vulnerability and robustness summary [slow]" = "stability_summary")
}

microbiome_cross_domain_analysis_ui <- function(
    ns, bacteria, fungi, current = list()) {
  metadata <- bacteria$metadata %||% data.frame()
  categorical <- names(metadata)[vapply(metadata, function(value) {
    levels <- unique(value[!is.na(value)])
    length(levels) >= 2L && length(levels) <= 12L &&
      (is.factor(value) || is.character(value) ||
        is.logical(value) || length(levels) <= 8L)
  }, logical(1))]
  grouped <- isTRUE(current$grouped)
  group <- current$group %||%
    if (length(categorical)) categorical[[1]] else ""
  if (!group %in% categorical) {
    group <- if (length(categorical)) categorical[[1]] else ""
  }
  engine <- current$engine %||% "netcomi"
  if (!engine %in% unname(microbiome_network_engine_choices())) {
    engine <- "netcomi"
  }
  measure_choices <- if (identical(engine, "ggclusternet2")) {
    microbiome_ggclusternet_measure_choices()
  } else {
    microbiome_cross_domain_measure_choices()
  }
  measure <- current$measure %||% "spearman"
  if (!measure %in% unname(measure_choices)) {
    measure <- unname(measure_choices)[[1]]
  }
  threshold <- current$threshold %||% 0.3
  fdr <- current$fdr %||% 0.05
  plot_choices <- if (identical(engine, "ggclusternet2")) {
    microbiome_ggclusternet_plot_choices(
      grouped, cross_domain = TRUE)
  } else {
    microbiome_cross_domain_plot_choices(grouped)
  }
  default_plot <- if (identical(engine, "ggclusternet2")) {
    microbiome_ggclusternet_default_plot_types(
      grouped, cross_domain = TRUE)
  } else {
    "cross_domain_network"
  }
  selected_plots <- intersect(
    current$plot_types %||% default_plot,
    unname(plot_choices))
  if (!length(selected_plots)) selected_plots <- default_plot
  common_samples <- if (!is.null(bacteria) && !is.null(fungi)) {
    length(intersect(rownames(bacteria$counts), rownames(fungi$counts)))
  } else {
    0L
  }
  expression_spec <- list(
    group_network = grouped, group = group,
    network_measure = measure, network_threshold = threshold,
    network_fdr = fdr,
    bacteria_taxonomic_rank = current$bacteria_rank %||% "Genus",
    fungi_taxonomic_rank = current$fungi_rank %||% "Genus",
    ggcluster_scale = current$ggcluster_scale %||% "rela",
    ggcluster_cross_scale = current$ggcluster_cross_scale %||% TRUE,
    ggcluster_layout = current$ggcluster_layout %||% "module_fr",
    ggcluster_cluster_method = current$ggcluster_cluster_method %||%
      "cluster_fast_greedy",
    ggcluster_robustness_strategy =
      current$ggcluster_robustness_strategy %||%
        c("node_rand", "node_degree_high"),
    ggcluster_robustness_runs =
      current$ggcluster_robustness_runs %||% 20L,
    ggcluster_robustness_step =
      current$ggcluster_robustness_step %||% 0.1,
    ggcluster_robustness_max_ratio =
      current$ggcluster_robustness_max_ratio %||% 0.9,
    ggcluster_robustness_measure =
      current$ggcluster_robustness_measure %||% "Eff",
    plot_types = selected_plots)
  formula <- if (identical(engine, "ggclusternet2")) {
    paste0(
      microbiome_ggclusternet_analysis_expression(
        expression_spec, cross_domain = TRUE),
      "\nMatched 16S-ITS samples: ", common_samples)
  } else {
    paste0(
      "Bacteria[", current$bacteria_rank %||% "Genus",
      "] + Fungi[", current$fungi_rank %||% "Genus",
      "] -> domain-wise CLR -> NetCoMi::netConstruct(",
      "measure = '", measure, "', alpha = ", format(fdr), ")",
      if (grouped) {
        paste0("\nNetworks fitted independently by ", group, ".")
      } else {
        ""
      },
      "\nMatched 16S-ITS samples: ", common_samples)
  }
  formula_control <- htmltools::tagQuery(shiny::textAreaInput(
    ns("general_model_formula"), "Model formula / analysis expression",
    value = formula, rows = 5, resize = "vertical"))$
    find("textarea")$addAttrs(readonly = "readonly")$allTags()
  expensive <- intersect(
    selected_plots,
    c(
      if (identical(engine, "netcomi")) {
        c("network_metric_forest", "centrality_difference")
      },
      "robustness", "node_vulnerability", "stability_summary"))
  shiny::tagList(
    shiny::checkboxInput(
      ns("network_grouped"), "Grouped networks", value = grouped),
    if (grouped) {
      shiny::selectInput(
        ns("network_group"), "Grouping variable",
        categorical, selected = group)
    },
    shiny::selectInput(
      ns("network_engine"), "Analysis mode",
      microbiome_network_engine_choices(), selected = engine),
    shiny::selectInput(
      ns("network_measure"), "Network inference method",
      measure_choices, selected = measure),
    shiny::sliderInput(
      ns("network_threshold"), "Association threshold |association|",
      0, 1, as.numeric(threshold), 0.01),
    shiny::sliderInput(
      ns("network_fdr"), "Network FDR threshold",
      0.001, 0.2, as.numeric(fdr), 0.001),
    shiny::tags$hr(class = "my-3"),
    formula_control,
    shiny::selectizeInput(
      ns("network_plot_types"), "Plot types",
      plot_choices, selected = selected_plots, multiple = TRUE,
      options = list(
        closeAfterSelect = FALSE, plugins = list("remove_button"))),
    if (length(expensive)) {
      shiny::div(
        class = "alert alert-warning py-2 small mt-2",
        paste(
          "The selected permutation or stability outputs add",
          "substantial runtime."))
    }
  )
}

microbiome_netcomi_plot_choices <- function(grouped = FALSE) {
  common <- c(
    "Cohesion by sample [additional calculation]" = "cohesion",
    "Robustness decay curve [slow]" = "robustness",
    "Node vulnerability [slow]" = "node_vulnerability",
    "Vulnerability and robustness summary [slow]" = "stability_summary")
  if (isTRUE(grouped)) {
    return(c(
      "Networks with a shared layout [fast default]" = "grouped_network",
      "Common-node network" = "common_nodes_network",
      "Group-specific edges" = "group_specific_edges",
      "Network-metric comparison [permutation; slow]" = "network_metric_forest",
      "Node-centrality differences [permutation; slow]" = "centrality_difference",
      "Edge-change Sankey" = "edge_change_sankey",
      common))
  }
  c(
    "Overall network [fast default]" = "overall_network",
    "Degree and centrality distributions" = "centrality_distribution",
    "Zi-Pi node roles" = "zipi_roles",
    "Module composition" = "module_composition",
    common)
}

microbiome_netcomi_default_plot_types <- function(grouped = FALSE) {
  if (isTRUE(grouped)) "grouped_network" else "overall_network"
}

microbiome_netcomi_analysis_requirements <- function(
    plot_types, grouped = FALSE) {
  plot_types <- unique(as.character(plot_types %||% character()))
  list(
    cohesion = "cohesion" %in% plot_types,
    robustness = any(c("robustness", "stability_summary") %in% plot_types),
    vulnerability = any(
      c("node_vulnerability", "stability_summary") %in% plot_types),
    comparison = isTRUE(grouped) && any(
      c("network_metric_forest", "centrality_difference") %in% plot_types))
}

microbiome_netcomi_advanced_field_ids <- function() c(
  "netcomi_zero_method", "netcomi_norm_method", "netcomi_min_prevalence",
  "netcomi_max_features", "netcomi_cluster_method", "netcomi_hub_method",
  "netcomi_hub_quantile", "netcomi_compare_permutations",
  "netcomi_spring_nlambda", "netcomi_spring_repetitions",
  "netcomi_robustness_strategy", "netcomi_robustness_runs",
  "netcomi_robustness_step", "netcomi_seed", "netcomi_cores")

microbiome_cross_domain_advanced_field_ids <- function() c(
  "cross_domain_pseudocount", "cross_max_features_per_domain",
  microbiome_netcomi_advanced_field_ids())

microbiome_netcomi_default_cores <- function() {
  available <- suppressWarnings(as.integer(
    if (requireNamespace("future", quietly = TRUE)) {
      future::availableCores()
    } else {
      parallel::detectCores(logical = TRUE)
    }))
  available <- available[is.finite(available) & available > 0L]
  max(1L, if (length(available)) available[[1]] - 1L else 1L)
}

microbiome_netcomi_advanced_ui <- function(ns, current = list()) {
  block <- function(title, package_function, ...) {
    shiny::div(class = "border rounded p-2 mb-2",
      shiny::div(class = "d-flex justify-content-between align-items-center mb-2",
        shiny::tags$strong(title),
        shiny::span(class = "badge text-bg-light", package_function)),
      ...)
  }
  shiny::tagList(
    shiny::tags$style(
      ".netcomi-advanced .form-group{margin-bottom:.45rem}.netcomi-advanced .row{--bs-gutter-x:.65rem}"),
    shiny::div(class = "netcomi-advanced",
      block("Zero replacement and normalization", "NetCoMi::netConstruct",
        shiny::fluidRow(
          shiny::column(6, shiny::selectInput(ns("netcomi_zero_method"),
            "zeroMethod", c("Pseudo-count" = "pseudo", "Multiplicative replacement" = "multRepl",
              "No replacement" = "none"),
            selected = current$netcomi_zero_method %||% "pseudo")),
          shiny::column(6, shiny::selectInput(ns("netcomi_norm_method"),
            "normMethod", c("CLR" = "clr", "TSS" = "tss", "CSS" = "css",
              "No normalization" = "none"),
            selected = current$netcomi_norm_method %||% "clr"))),
        shiny::fluidRow(
          shiny::column(6, shiny::sliderInput(ns("netcomi_min_prevalence"),
            "Minimum prevalence", 0, 1,
            as.numeric(current$netcomi_min_prevalence %||% 0.1), 0.01)),
          shiny::column(6, shiny::numericInput(ns("netcomi_max_features"),
            "Maximum taxa", as.integer(current$netcomi_max_features %||% 60L),
            min = 5L, step = 5L)))),
      block("Topology, modules and hubs", "NetCoMi::netAnalyze",
        shiny::fluidRow(
          shiny::column(6, shiny::selectInput(ns("netcomi_cluster_method"),
            "clustMethod",
            c("Louvain" = "cluster_louvain", "Fast greedy" = "cluster_fast_greedy",
              "Walktrap" = "cluster_walktrap", "Infomap" = "cluster_infomap"),
            selected = current$netcomi_cluster_method %||% "cluster_louvain")),
          shiny::column(6, shiny::selectInput(ns("netcomi_hub_method"),
            "Hub centrality", c("Degree" = "degree", "Eigenvector" = "eigenvector",
              "Betweenness" = "between", "Closeness" = "close"),
            selected = current$netcomi_hub_method %||% "degree"))),
        shiny::fluidRow(
          shiny::column(6, shiny::sliderInput(ns("netcomi_hub_quantile"),
            "Hub quantile", 0.8, 0.999,
            as.numeric(current$netcomi_hub_quantile %||% 0.95), 0.001)))),
      block("SPRING stability selection", "NetCoMi::netConstruct / SPRING::SPRING",
        shiny::p(class = "small text-muted mb-2",
          "10 x 10 is suitable for exploratory previews; 20 x 20 is the default scientific setting. Increasing either value improves stability resolution but increases runtime."),
        shiny::fluidRow(
          shiny::column(6, shiny::numericInput(ns("netcomi_spring_nlambda"),
            "Lambda grid size", as.integer(
              current$netcomi_spring_nlambda %||% 20L),
            min = 5L, max = 100L, step = 5L)),
          shiny::column(6, shiny::numericInput(ns("netcomi_spring_repetitions"),
            "StARS resamples", as.integer(
              current$netcomi_spring_repetitions %||% 20L),
            min = 5L, max = 200L, step = 5L)))),
      block("Network comparison", "NetCoMi::netCompare",
        shiny::fluidRow(
          shiny::column(6, shiny::numericInput(ns("netcomi_compare_permutations"),
            "Permutation count", as.integer(current$netcomi_compare_permutations %||% 999L),
            min = 99L, step = 100L)),
          shiny::column(6, shiny::numericInput(ns("netcomi_cores"),
            "CPU cores", as.integer(current$netcomi_cores %||%
              microbiome_netcomi_default_cores()),
            min = 1L, step = 1L)))),
      block("Cohesion, robustness and vulnerability", "meconetcomp",
        shiny::fluidRow(
          shiny::column(6, shiny::selectInput(ns("netcomi_robustness_strategy"),
            "Removal strategy",
            c("Random nodes" = "node_rand", "High-degree nodes" = "node_degree_high",
              "Random edges" = "edge_rand", "Strong edges" = "edge_strong"),
            selected = current$netcomi_robustness_strategy %||% "node_rand")),
          shiny::column(6, shiny::numericInput(ns("netcomi_robustness_runs"),
            "Repeated removals", as.integer(current$netcomi_robustness_runs %||% 20L),
            min = 5L, step = 5L))),
        shiny::sliderInput(ns("netcomi_robustness_step"),
          "Node/edge removal step", 0.05, 0.25,
          as.numeric(current$netcomi_robustness_step %||% 0.1), 0.05)),
      shiny::numericInput(ns("netcomi_seed"), "Random seed",
        as.integer(current$netcomi_seed %||% 2026L), min = 1L))
  )
}

microbiome_cross_domain_advanced_ui <- function(ns, current = list()) {
  shiny::tagList(
    shiny::div(
      class = "border rounded p-2 mb-2",
      shiny::div(
        class = "d-flex justify-content-between align-items-center mb-2",
        shiny::tags$strong("Bacteria-fungi domain preprocessing"),
        shiny::span(
          class = "badge text-bg-light", "domain-wise CLR")),
      shiny::p(
        class = "small text-muted mb-2",
        paste(
          "16S and ITS are zero-replaced and CLR-transformed separately",
          "before concatenation. The generic zeroMethod and normMethod",
          "settings below are therefore overridden for this workflow.")),
      shiny::fluidRow(
        shiny::column(
          6,
          shiny::numericInput(
            ns("cross_domain_pseudocount"), "CLR pseudocount",
            as.numeric(current$cross_domain_pseudocount %||% 0.5),
            min = 1e-06, step = 0.1)),
        shiny::column(
          6,
          shiny::numericInput(
            ns("cross_max_features_per_domain"),
            "Maximum taxa per domain",
            as.integer(current$cross_max_features_per_domain %||% 30L),
            min = 5L, step = 5L)))),
    microbiome_netcomi_advanced_ui(ns, current)
  )
}

microbiome_network_main_plot <- function(name) {
  name %in% c(
    "overall_network", "grouped_network", "common_nodes_network",
    "cross_domain_network", "ggcluster_curved_network",
    "ggcluster_module_network")
}

microbiome_network_plot_spec_for <- function(result, plot_name) {
  base <- result$network_objects$plot_spec %||% list()
  variants <- result$network_objects$plot_specs %||% list()
  microbiome_network_plot_spec_merge(
    variants[[plot_name]] %||% base)
}

microbiome_network_colour_input <- function(ns, input_id, label, value) {
  microbiome_colour_input(ns, input_id, label, value)
}

microbiome_network_plot_settings_ui <- function(
    ns, prefix = "", defaults = list()) {
  defaults <- microbiome_network_plot_spec_merge(defaults)
  id <- function(value) paste0(prefix, value)
  layout_choices <- c(
    "Fruchterman-Reingold" = "fr", "Kamada-Kawai" = "kk",
    "Circle" = "circle", "MDS" = "mds", "Graphopt" = "graphopt")
  if (identical(defaults$engine %||% "", "ggclusternet2")) {
    layout_choices <- c(
      "ggClusterNet2 module FR" = "ggcluster_module_fr",
      "ggClusterNet2 Gephi concentric" =
        "ggcluster_gephi_concentric",
      layout_choices)
  }
  section <- function(title, ...) {
    bslib::accordion_panel(title, shiny::div(class = "pt-1", ...))
  }
  variant_note <- switch(
    defaults$plot_variant %||% "",
    curved_edge = shiny::div(
      class = "alert alert-info py-2 px-2 small mb-2",
      shiny::tags$strong("ggClusterNet2 Curved-edge Network"),
      shiny::tags$div(
        "Edge bending changes only the display layer; network correlation, topology metrics, and stability results remain unchanged.")),
    module_coloured = shiny::div(
      class = "alert alert-info py-2 px-2 small mb-2",
      shiny::tags$strong("ggClusterNet2 Module-coloured Network"),
      shiny::tags$div(
        "Default coloring by ggClusterNet2 module, mapping can be switched in node properties.")),
    NULL)
  shiny::tagList(
    variant_note,
    bslib::accordion(
      id = ns(id("network_plot_sections")), open = "Global network settings",
    section("Global network settings",
      shiny::selectInput(ns(id("network_plot_layout")), "Layout",
        layout_choices,
        selected = defaults$layout$algorithm %||% "fr"),
      shiny::numericInput(ns(id("network_plot_iterations")), "Number of layout iterations",
        1000L, min = 100L, max = 20000L, step = 100L),
      shiny::checkboxInput(ns(id("network_plot_rm_singles")),
        "Remove orphaned nodes", TRUE),
      shiny::checkboxInput(ns(id("network_plot_legend")), "Show legend", TRUE),
      shiny::selectInput(ns(id("network_plot_legend_position")), "Legend location",
        c("Right" = "right", "Bottom" = "bottom", "Left" = "left",
          "Top" = "top"), selected = "right"),
      shiny::sliderInput(ns(id("network_plot_legend_size")), "Legend text size",
        6, 18, 10, 1),
      shiny::textInput(ns(id("network_plot_title")), "Figure title",
        defaults$annotation$title %||% "Microbial Co-occurrence Network"),
      shiny::sliderInput(ns(id("network_plot_title_size")), "Title font size",
        8, 24, 14, 1),
      microbiome_network_colour_input(
        ns, id("network_plot_canvas_background"), "Canvas background color", "#FFFFFF"),
      shiny::sliderInput(ns(id("network_plot_alpha")), "Global transparency",
        0.1, 1, 0.85, 0.05),
      shiny::checkboxInput(ns(id("network_plot_show_hubs")), "Tag Hub", TRUE),
      microbiome_network_colour_input(
        ns, id("network_plot_hub_border_colour"), "Hub outer ring color", "#111111"),
      shiny::sliderInput(ns(id("network_plot_hub_border_width")),
        "Hub outer ring thickness", 0, 4, 1.2, 0.1)),
    section("Node attributes",
      shiny::selectInput(ns(id("network_plot_node_colour_by")), "Node color",
        c("Domain / Kingdom" = "Kingdom", "Phylum" = "Phylum",
          "Class" = "Class", "Order" = "Order",
          "Family" = "Family", "Genus" = "Genus", "Module" = "module",
          "Degree" = "degree", "Betweenness" = "betweenness",
          "Fixed color" = "fixed"),
        selected = defaults$node$colour_by %||% "Phylum"),
      microbiome_network_colour_input(
        ns, id("network_plot_node_fixed_colour"), "Node fixed color", "#3498DB"),
      microbiome_network_colour_input(
        ns, id("network_plot_node_gradient_low"), "Continuous color low value", "#F7F7F7"),
      microbiome_network_colour_input(
        ns, id("network_plot_node_gradient_high"), "Continuous color high value", "#E41A1C"),
      microbiome_network_colour_input(
        ns, id("network_plot_node_unclassified_colour"),
        "Uncategorized node color", "#B8B8B8"),
      shiny::selectInput(ns(id("network_plot_node_size_by")), "Node size",
        c("Degree" = "degree", "Strength" = "strength",
          "Betweenness" = "betweenness", "Mean abundance" = "mean_abundance",
          "Fixed size" = "fixed"), selected = "degree"),
      shiny::sliderInput(ns(id("network_plot_node_fixed_size")), "Fixed node size",
        1, 12, 4, 0.5),
      shiny::sliderInput(ns(id("network_plot_node_size_range")), "Node size range",
        0.5, 15, c(2, 7), 0.5),
      shiny::selectInput(ns(id("network_plot_node_shape")), "Node shape",
        c("Circle" = 21, "Square" = 22, "Triangle" = 24), selected = 21),
      microbiome_network_colour_input(
        ns, id("network_plot_node_border_colour"), "Node border color", "#222222"),
      shiny::sliderInput(ns(id("network_plot_node_border_width")),
        "Node border thickness", 0, 3, 0.6, 0.1),
      shiny::selectInput(ns(id("network_plot_label_mode")), "node label",
        c("Not displayed" = "none", "All nodes" = "all", "Hub only" = "hubs",
          "Centrality Top N" = "top_n"), selected = "none"),
      shiny::selectInput(ns(id("network_plot_label_field")), "tag content",
        c("Feature ID" = "name", "Genus" = "Genus",
          "Species" = "Species"), selected = "name"),
      shiny::numericInput(ns(id("network_plot_label_top_n")), "Top N",
        15L, min = 1L, max = 100L),
      shiny::sliderInput(ns(id("network_plot_label_size")), "Label font size",
        2, 10, 3.2, 0.2),
      microbiome_network_colour_input(
        ns, id("network_plot_label_colour"), "Label color", "#111111")),
    section("Edge properties",
      shiny::selectInput(ns(id("network_plot_edge_colouring")), "Edge coloring rules",
        c("Positive and negative correlation" = "sign", "Association strength" = "weight",
          "Fixed color" = "fixed"), selected = "sign"),
      microbiome_network_colour_input(
        ns, id("network_plot_edge_positive_colour"), "Positively associated colors", "#377EB8"),
      microbiome_network_colour_input(
        ns, id("network_plot_edge_negative_colour"), "Negatively associated colors", "#E41A1C"),
      microbiome_network_colour_input(
        ns, id("network_plot_edge_fixed_colour"), "Edge fixed color", "#777777"),
      shiny::selectInput(ns(id("network_plot_edge_width_by")), "Edge thickness",
        c("Association strength" = "abs_weight", "Fixed thickness" = "fixed"),
        selected = "abs_weight"),
      shiny::sliderInput(ns(id("network_plot_edge_fixed_width")), "Fixed edge width",
        0.1, 5, 0.8, 0.1),
      shiny::sliderInput(ns(id("network_plot_edge_width_range")), "Edge width interval",
        0.1, 5, c(0.3, 1.8), 0.1),
      shiny::sliderInput(ns(id("network_plot_edge_alpha")), "Edge transparency",
        0.05, 1, 0.7, 0.05),
      shiny::selectInput(ns(id("network_plot_edge_linetype")), "Edge type",
        c("solid line" = 1, "dashed line" = 2, "dotted line" = 3), selected = 1),
      shiny::sliderInput(ns(id("network_plot_edge_curve")),
        "Edge curvature (curve)", 0, 0.5,
        as.numeric(defaults$edge$curve %||% 0.25), 0.05),
      shiny::checkboxInput(ns(id("network_plot_edge_curve_all")),
        "Curve all edges (curveAll)",
        isTRUE(defaults$edge$curve_all %||% TRUE)),
      shiny::sliderInput(ns(id("network_plot_edge_filter")),
        "Plot only hide weak edges (absolute association)", 0, 1, 0, 0.01),
      shiny::div(class = "small text-muted",
        "This filtering only changes the plot display, not the network topology, Cohesion, or stability calculations."))
    )
  )
}

microbiome_network_plot_spec_default <- function() {
  list(
    canvas = list(preset = "journal_double", width = 180, height = 120,
      unit = "mm", background = "white", transparent = FALSE, dpi = 600,
      base_family = "sans", theme = "nature"),
    layout = list(algorithm = "fr", seed = 2026L, iterations = 1000L,
      use_weights = TRUE, scale = 1, rotation = 0, flip_x = FALSE,
      flip_y = FALSE, locked = TRUE, common_layout = TRUE,
      node_strategy = "union", remove_singles = TRUE),
    node = list(colour_by = "Phylum", size_by = "degree", shape_by = "Kingdom",
      size_min = 3, size_max = 10, transform = "sqrt",
      fixed_colour = "#3498DB", gradient_low = "#F7F7F7",
      gradient_high = "#E41A1C", fixed_size = 4, shape = 21,
      border_colour = "#222222", border_width = 0.6,
      unclassified_colour = "#B8B8B8", hub_style = "outer_ring",
      show_hubs = TRUE, hub_border_colour = "#111111",
      hub_border_width = 1.2),
    edge = list(colour_by = "sign", positive_colour = "#C43C39",
      negative_colour = "#2B6CB0", width_by = "abs_weight",
      fixed_colour = "#777777", fixed_width = 0.8,
      width_min = 0.3, width_max = 2.8, alpha = 0.7, linetype = 1,
      curve = 0.25, curve_all = TRUE,
      display_rule = "all", threshold = 0, top_n = 200L),
    label = list(mode = "hubs", field = "name", top_n = 15L,
      max_characters = 28L, size = 3.2, colour = "#111111", repel = TRUE),
    module = list(show = TRUE, outline = FALSE, weaken_between = FALSE),
    legend = list(show = TRUE, position = "right", text_size = 10,
      direction = "vertical", shared = TRUE),
    annotation = list(title = "", subtitle = "", auto_statistics = TRUE,
      caption = TRUE, title_size = 14, alpha = 0.85),
    group_compare = list(shared_layout = TRUE, shared_scales = TRUE,
      shared_legend = TRUE, panel_order = character()),
    export = list(svg = TRUE, pdf = TRUE, png_dpi = 600L, tiff_dpi = 600L,
      tiff_compression = "lzw", embed_fonts = TRUE),
    overrides = list(nodes = list(), edges = list())
  )
}

microbiome_network_plot_spec_merge <- function(value = list()) {
  utils::modifyList(microbiome_network_plot_spec_default(), value %||% list())
}

microbiome_network_plot_spec_from_input <- function(
    input, base = list(), prefix = "") {
  value <- function(id, default) input[[paste0(prefix, id)]] %||% default
  range_value <- function(id, default) {
    result <- suppressWarnings(as.numeric(value(id, default)))
    if (length(result) == 2L && all(is.finite(result))) result else default
  }
  spec <- microbiome_network_plot_spec_merge(base)
  spec$layout$algorithm <- value("network_plot_layout", spec$layout$algorithm)
  spec$layout$iterations <- as.integer(value(
    "network_plot_iterations", spec$layout$iterations))
  spec$layout$remove_singles <- isTRUE(value(
    "network_plot_rm_singles", spec$layout$remove_singles))
  spec$legend$show <- isTRUE(value("network_plot_legend", spec$legend$show))
  spec$legend$position <- value(
    "network_plot_legend_position", spec$legend$position)
  spec$legend$text_size <- as.numeric(value(
    "network_plot_legend_size", spec$legend$text_size))
  spec$annotation$title <- value(
    "network_plot_title", spec$annotation$title)
  spec$annotation$title_size <- as.numeric(value(
    "network_plot_title_size", spec$annotation$title_size))
  spec$canvas$background <- value(
    "network_plot_canvas_background", spec$canvas$background)
  spec$annotation$alpha <- as.numeric(value(
    "network_plot_alpha", spec$annotation$alpha))
  spec$node$show_hubs <- isTRUE(value(
    "network_plot_show_hubs", spec$node$show_hubs))
  spec$node$hub_border_colour <- value(
    "network_plot_hub_border_colour", spec$node$hub_border_colour)
  spec$node$hub_border_width <- as.numeric(value(
    "network_plot_hub_border_width", spec$node$hub_border_width))
  spec$node$colour_by <- value(
    "network_plot_node_colour_by", spec$node$colour_by)
  spec$node$fixed_colour <- value(
    "network_plot_node_fixed_colour", spec$node$fixed_colour)
  spec$node$gradient_low <- value(
    "network_plot_node_gradient_low", spec$node$gradient_low)
  spec$node$gradient_high <- value(
    "network_plot_node_gradient_high", spec$node$gradient_high)
  spec$node$unclassified_colour <- value(
    "network_plot_node_unclassified_colour",
    spec$node$unclassified_colour)
  spec$node$size_by <- value("network_plot_node_size_by", spec$node$size_by)
  spec$node$fixed_size <- as.numeric(value(
    "network_plot_node_fixed_size", spec$node$fixed_size))
  node_range <- range_value(
    "network_plot_node_size_range", c(spec$node$size_min, spec$node$size_max))
  spec$node$size_min <- node_range[[1]]
  spec$node$size_max <- node_range[[2]]
  spec$node$shape <- as.integer(value("network_plot_node_shape", spec$node$shape))
  spec$node$border_colour <- value(
    "network_plot_node_border_colour", spec$node$border_colour)
  spec$node$border_width <- as.numeric(value(
    "network_plot_node_border_width", spec$node$border_width))
  spec$label$mode <- value("network_plot_label_mode", spec$label$mode)
  spec$label$field <- value("network_plot_label_field", spec$label$field)
  spec$label$top_n <- as.integer(value("network_plot_label_top_n", spec$label$top_n))
  spec$label$size <- as.numeric(value("network_plot_label_size", spec$label$size))
  spec$label$colour <- value("network_plot_label_colour", spec$label$colour)
  spec$edge$colour_by <- value(
    "network_plot_edge_colouring", spec$edge$colour_by)
  spec$edge$positive_colour <- value(
    "network_plot_edge_positive_colour", spec$edge$positive_colour)
  spec$edge$negative_colour <- value(
    "network_plot_edge_negative_colour", spec$edge$negative_colour)
  spec$edge$fixed_colour <- value(
    "network_plot_edge_fixed_colour", spec$edge$fixed_colour)
  spec$edge$width_by <- value(
    "network_plot_edge_width_by", spec$edge$width_by)
  spec$edge$fixed_width <- as.numeric(value(
    "network_plot_edge_fixed_width", spec$edge$fixed_width))
  edge_range <- range_value(
    "network_plot_edge_width_range", c(spec$edge$width_min, spec$edge$width_max))
  spec$edge$width_min <- edge_range[[1]]
  spec$edge$width_max <- edge_range[[2]]
  spec$edge$alpha <- as.numeric(value(
    "network_plot_edge_alpha", spec$edge$alpha))
  spec$edge$linetype <- as.integer(value(
    "network_plot_edge_linetype", spec$edge$linetype))
  spec$edge$curve <- as.numeric(value(
    "network_plot_edge_curve", spec$edge$curve))
  spec$edge$curve_all <- isTRUE(value(
    "network_plot_edge_curve_all", spec$edge$curve_all))
  threshold <- as.numeric(value("network_plot_edge_filter", 0))
  spec$edge$display_rule <- if (is.finite(threshold) && threshold > 0) {
    "threshold"
  } else {
    "all"
  }
  spec$edge$threshold <- if (is.finite(threshold)) threshold else 0
  spec
}

microbiome_netcomi_aggregate <- function(bundle, spec) {
  rank <- spec$taxonomic_rank %||% "Genus"
  aggregated <- microbiome_species_environment_aggregate(bundle, rank)
  counts <- aggregated$counts
  prevalence <- colMeans(counts > 0)
  keep <- which(prevalence >= as.numeric(spec$minimum_prevalence %||%
    spec$netcomi_min_prevalence %||% 0.1))
  maximum <- max(5L, as.integer(spec$maximum_features %||%
    spec$netcomi_max_features %||% 60L))
  keep <- utils::head(keep[order(colMeans(counts[, keep, drop = FALSE]),
    decreasing = TRUE)], maximum)
  if (length(keep) < 5L) {
    stop("NetCoMi requires at least five taxa after prevalence filtering.",
      call. = FALSE)
  }
  aggregated$counts <- counts[, keep, drop = FALSE]
  selected_taxa <- colnames(aggregated$counts)
  mapping <- as.data.frame(aggregated$mapping, check.names = FALSE)
  taxonomy_columns <- intersect(
    c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species"),
    names(mapping))
  first_label <- function(value) {
    value <- as.character(value)
    value <- value[!is.na(value) & nzchar(trimws(value))]
    if (length(value)) value[[1]] else NA_character_
  }
  mapping <- do.call(rbind, lapply(selected_taxa, function(taxon) {
    rows <- mapping[mapping$Taxon == taxon, , drop = FALSE]
    values <- lapply(taxonomy_columns, function(column) first_label(rows[[column]]))
    names(values) <- taxonomy_columns
    data.frame(Taxon = taxon, Rank = rank, values,
      check.names = FALSE, stringsAsFactors = FALSE)
  }))
  rownames(mapping) <- NULL
  aggregated$mapping <- mapping
  aggregated
}

microbiome_with_spieceasi_compat <- function(callback) {
  had_sparse <- exists("sparseiCov", envir = .GlobalEnv, inherits = FALSE)
  previous_sparse <- if (had_sparse) {
    get("sparseiCov", envir = .GlobalEnv, inherits = FALSE)
  } else {
    NULL
  }
  assign(
    "sparseiCov", getFromNamespace("sparseiCov", "SpiecEasi"),
    envir = .GlobalEnv)
  on.exit({
    if (had_sparse) {
      assign("sparseiCov", previous_sparse, envir = .GlobalEnv)
    } else if (exists("sparseiCov", envir = .GlobalEnv, inherits = FALSE)) {
      rm("sparseiCov", envir = .GlobalEnv)
    }
  }, add = TRUE)

  update_list <- utils::getS3method("update", "list", optional = TRUE)
  if (!is.null(update_list) && "new" %in% names(formals(update_list))) {
    base::registerS3method(
      "update", "list",
      function(object, ...) stats:::update.default(object, ...),
      envir = .GlobalEnv)
    on.exit(base::registerS3method(
      "update", "list", update_list, envir = .GlobalEnv), add = TRUE)
  }

  callback()
}

microbiome_with_windows_pulsar_parallel <- function(callback, cores) {
  cores <- max(1L, as.integer(cores))
  if (.Platform$OS.type != "windows" || cores < 2L ||
      !requireNamespace("pulsar", quietly = TRUE)) {
    return(callback())
  }
  namespace <- asNamespace("pulsar")
  binding <- ".try_mclapply"
  original <- get(binding, envir = namespace, inherits = FALSE)
  output_log <- tempfile("dava-pulsar-psock-", fileext = ".log")
  cluster <- parallel::makePSOCKcluster(cores, outfile = output_log)
  on.exit({
    microbiome_stop_psock_cluster(cluster)
    if (file.exists(output_log)) unlink(output_log, force = TRUE)
  }, add = TRUE)
  replacement <- function(
      X, FUN, mc.cores = getOption("mc.cores", 2L),
      pass.errors = TRUE, mc.preschedule = FALSE, ...) {
    dots <- list(...)
    output <- parallel::parLapplyLB(
      cluster, X,
      function(item, worker_callback, worker_arguments) {
        try(do.call(
          worker_callback, c(list(item), worker_arguments)), silent = TRUE)
      },
      worker_callback = FUN, worker_arguments = dots)
    errors <- vapply(output, inherits, logical(1), what = "try-error")
    if (any(errors)) {
      messages <- table(trimws(vapply(
        output[errors], function(value) as.character(value[[1]]),
        character(1))))
      message <- paste(sprintf(
        "\n%s job%s failed with: \"%s\"",
        messages, ifelse(messages > 1, "s", ""), names(messages)),
        collapse = "")
      if (!pass.errors || all(errors)) {
        stop(message, call. = FALSE)
      }
      warning(message, call. = FALSE)
      output <- output[!errors]
    }
    attr(output, "errors") <- errors
    output
  }
  unlockBinding(binding, namespace)
  assign(binding, replacement, envir = namespace)
  lockBinding(binding, namespace)
  on.exit({
    unlockBinding(binding, namespace)
    assign(binding, original, envir = namespace)
    lockBinding(binding, namespace)
  }, add = TRUE)
  callback()
}

microbiome_stop_psock_cluster <- function(cluster) {
  if (is.null(cluster)) return(invisible(TRUE))
  suppressWarnings(try(parallel::stopCluster(cluster), silent = TRUE))
  for (node in cluster) {
    connection <- node$con %||% NULL
    if (inherits(connection, "connection")) {
      suppressWarnings(try({
        if (isOpen(connection)) close(connection)
      }, silent = TRUE))
    }
  }
  invisible(TRUE)
}

microbiome_netcomi_parallel_group_fits <- function(
    scopes, counts, subsets, spec, per_group_cores, workers) {
  workers <- min(max(1L, as.integer(workers)), length(scopes))
  if (workers < 2L) {
    return(lapply(scopes, function(scope) {
      index <- subsets[[scope]]
      fit_spec <- spec
      fit_spec$n_cores <- per_group_cores
      captured <- microbiome_capture_runtime_output(function() {
        microbiome_netcomi_construct(
          counts[index, , drop = FALSE], fit_spec)
      })
      list(
        scope = scope, index = index, captured = captured,
        cache_key = microbiome_netcomi_fit_cache_key(
          counts[index, , drop = FALSE], spec),
        cache_hit = FALSE)
    }))
  }
  output_log <- tempfile("dava-netcomi-groups-", fileext = ".log")
  cluster <- parallel::makePSOCKcluster(workers, outfile = output_log)
  on.exit({
    microbiome_stop_psock_cluster(cluster)
    if (file.exists(output_log)) unlink(output_log, force = TRUE)
  }, add = TRUE)
  project_root <- get0(
    "microbiome_project_root", envir = .GlobalEnv,
    ifnotfound = normalizePath(".", winslash = "/", mustWork = TRUE))
  parallel::clusterCall(cluster, function(root) {
    assign("%||%", function(x, y) if (is.null(x)) y else x,
      envir = .GlobalEnv)
    source(
      file.path(root, "R", "microbiome", "00_bootstrap.R"),
      local = .GlobalEnv, encoding = "UTF-8")
    NULL
  }, project_root)
  parallel::parLapplyLB(
    cluster, scopes,
    function(scope, worker_counts, worker_subsets, worker_spec, group_cores) {
      index <- worker_subsets[[scope]]
      fit_spec <- worker_spec
      fit_spec$n_cores <- group_cores
      captured <- microbiome_capture_runtime_output(function() {
        microbiome_netcomi_construct(
          worker_counts[index, , drop = FALSE], fit_spec)
      })
      list(
        scope = scope, index = index, captured = captured,
        cache_key = microbiome_netcomi_fit_cache_key(
          worker_counts[index, , drop = FALSE], worker_spec),
        cache_hit = FALSE)
    },
    worker_counts = counts, worker_subsets = subsets,
    worker_spec = spec, group_cores = per_group_cores)
}

microbiome_netcomi_call_construct <- function(arguments) {
  measure <- arguments$measure %||% "spieceasi"
  construct_with_compatibility <- function() {
    construct_code <- paste(
      deparse(NetCoMi::netConstruct, width.cutoff = 500L),
      collapse = "\n")
    construct_code <- gsub(
      "1:nrow(edgelist1)", "seq_len(nrow(edgelist1))",
      construct_code, fixed = TRUE)
    construct_code <- gsub(
      "1:nrow(edgelist2)", "seq_len(nrow(edgelist2))",
      construct_code, fixed = TRUE)
    for (network_index in c("1", "2")) {
      edge_list <- paste0("edgelist", network_index)
      for (matrix_name in c("assoMat", "dissMat", "simMat", "adjaMat")) {
        matrix_object <- paste0(matrix_name, network_index)
        original <- sprintf(
          "%s[%s[i, 1], %s[i, 2]]",
          matrix_object, edge_list, edge_list)
        replacement <- sprintf(
          paste0(
            "%s[match(%s[i, 1], igraph::V(g)$name), ",
            "match(%s[i, 2], igraph::V(g)$name)]"),
          matrix_object, edge_list, edge_list)
        construct_code <- gsub(
          original, replacement, construct_code, fixed = TRUE)
      }
    }
    compatible_construct <- eval(
      parse(text = construct_code), envir = asNamespace("NetCoMi"))
    do.call(compatible_construct, arguments)
  }
  if (identical(measure, "spieceasi")) {
    return(microbiome_with_spieceasi_compat(construct_with_compatibility))
  }
  if (identical(measure, "spring")) {
    spring_cores <- arguments$measurePar$ncores %||% 1L
    return(microbiome_with_windows_pulsar_parallel(
      construct_with_compatibility, spring_cores))
  }
  construct_with_compatibility()
}

microbiome_netcomi_empty_properties <- function(taxa) {
  zero <- stats::setNames(rep(0, length(taxa)), taxa)
  modules <- stats::setNames(seq_along(taxa), taxa)
  list(
    centralities = list(
      degree1 = zero, between1 = zero, close1 = zero, eigenv1 = zero),
    clustering = list(clust1 = modules),
    hubs = list(hubs1 = character()),
    globalProps = list(
      modularity1 = NA_real_, avPath1 = NA_real_, clustCoef1 = NA_real_),
    empty_network = TRUE)
}

microbiome_netcomi_uses_association_threshold <- function(measure) {
  measure %in% c("pearson", "spearman", "bicor")
}

microbiome_netcomi_parallel_group_measure <- function(measure) {
  measure %in% c(
    "spieceasi", "spring", "sparcc", "cclasso", "ccrepe", "gcoda", "propr")
}

microbiome_netcomi_warm_workers <- local({
  warmed_workers <- 0L
  function(max_workers = 2L) {
    if (!requireNamespace("future", quietly = TRUE) ||
        future::nbrOfWorkers() < 2L) {
      return(logical())
    }
    worker_count <- min(
      max(1L, as.integer(max_workers)),
      as.integer(future::nbrOfWorkers()))
    if (warmed_workers >= worker_count) {
      return(rep(TRUE, worker_count))
    }
    futures <- lapply(seq_len(worker_count), function(worker) {
      future::future({
        suppressPackageStartupMessages(
          suppressWarnings(requireNamespace("NetCoMi", quietly = TRUE)))
        suppressPackageStartupMessages(
          suppressWarnings(requireNamespace("igraph", quietly = TRUE)))
        TRUE
      }, seed = TRUE)
    })
    results <- vapply(
      futures,
      function(job) isTRUE(tryCatch(
        future::value(job),
        error = function(error) FALSE)),
      logical(1))
    if (all(results)) warmed_workers <<- worker_count
    results
  }
})

microbiome_netcomi_fit_cache <- local({
  values <- new.env(parent = emptyenv())
  access_order <- character()
  max_entries <- 20L
  function(action = c("get", "set", "clear"), key = "", value = NULL) {
    action <- match.arg(action)
    if (identical(action, "clear")) {
      rm(list = ls(values, all.names = TRUE), envir = values)
      access_order <<- character()
      return(invisible(TRUE))
    }
    if (!nzchar(key)) return(NULL)
    if (identical(action, "get")) {
      if (!exists(key, envir = values, inherits = FALSE)) return(NULL)
      access_order <<- c(setdiff(access_order, key), key)
      return(get(key, envir = values, inherits = FALSE))
    }
    assign(key, value, envir = values)
    access_order <<- c(setdiff(access_order, key), key)
    while (length(access_order) > max_entries) {
      remove_key <- access_order[[1]]
      rm(list = remove_key, envir = values)
      access_order <<- access_order[-1]
    }
    invisible(value)
  }
})

microbiome_netcomi_fit_cache_key <- function(counts, spec) {
  if (!requireNamespace("digest", quietly = TRUE)) return("")
  parameters <- list(
    adapter_version = 3L,
    netcomi_version = as.character(utils::packageVersion("NetCoMi")),
    measure = spec$network_measure %||% spec$network_method %||% "spieceasi",
    zero_method = spec$zero_method %||% spec$netcomi_zero_method %||% "pseudo",
    norm_method = spec$norm_method %||% spec$netcomi_norm_method %||% "clr",
    threshold = as.numeric(
      spec$network_threshold %||% spec$correlation_threshold %||% 0),
    fdr = as.numeric(spec$network_fdr %||% spec$alpha %||% 0.05),
    seed = as.integer(spec$seed %||% spec$netcomi_seed %||% 2026L),
    cluster_method = spec$cluster_method %||%
      spec$netcomi_cluster_method %||% "cluster_louvain",
    hub_method = spec$hub_method %||% spec$netcomi_hub_method %||% "degree",
    hub_quantile = as.numeric(
      spec$hub_quantile %||% spec$netcomi_hub_quantile %||% 0.95),
    spring_nlambda = as.integer(spec$spring_nlambda %||% 20L),
    spring_repetitions = as.integer(spec$spring_repetitions %||% 20L),
    cross_domain_clr = isTRUE(spec$cross_domain_clr),
    cross_domain_pseudocount = as.numeric(
      spec$cross_domain_pseudocount %||% 0.5),
    measure_parameters = spec$measure_parameters %||% list())
  paste0("fit-", digest::digest(
    list(counts = counts, parameters = parameters),
    algo = "xxhash64", serialize = TRUE))
}

microbiome_netcomi_comparison_cache_key <- function(counts, subsets, spec) {
  if (!requireNamespace("digest", quietly = TRUE)) return("")
  parameters <- list(
    adapter_version = 3L,
    netcomi_version = as.character(utils::packageVersion("NetCoMi")),
    groups = names(subsets),
    group_rows = subsets,
    measure = spec$network_measure %||% "spieceasi",
    zero_method = spec$zero_method %||% "pseudo",
    norm_method = spec$norm_method %||% "clr",
    threshold = as.numeric(spec$network_threshold %||% 0.3),
    fdr = as.numeric(spec$network_fdr %||% 0.05),
    cluster_method = spec$cluster_method %||% "cluster_louvain",
    hub_method = spec$hub_method %||% "degree",
    hub_quantile = as.numeric(spec$hub_quantile %||% 0.95),
    spring_nlambda = as.integer(spec$spring_nlambda %||% 20L),
    spring_repetitions = as.integer(spec$spring_repetitions %||% 20L),
    cross_domain_clr = isTRUE(spec$cross_domain_clr),
    cross_domain_pseudocount = as.numeric(
      spec$cross_domain_pseudocount %||% 0.5),
    measure_parameters = spec$measure_parameters %||% list(),
    permutations = max(9L, as.integer(spec$compare_permutations %||% 999L)),
    seed = as.integer(spec$seed %||% 2026L))
  paste0("comparison-", digest::digest(
    list(counts = counts, parameters = parameters),
    algo = "xxhash64", serialize = TRUE))
}

microbiome_netcomi_stability_cache_key <- function(
    counts, subsets, spec, requirements) {
  if (!requireNamespace("digest", quietly = TRUE)) return("")
  fit_keys <- vapply(subsets, function(index) {
    microbiome_netcomi_fit_cache_key(counts[index, , drop = FALSE], spec)
  }, character(1))
  parameters <- list(
    adapter_version = 1L,
    fit_keys = fit_keys,
    cohesion = isTRUE(requirements$cohesion),
    robustness = isTRUE(requirements$robustness),
    vulnerability = isTRUE(requirements$vulnerability),
    robustness_strategy = sort(as.character(
      spec$robustness_strategy %||%
        spec$netcomi_robustness_strategy %||% "node_rand")),
    robustness_step = as.numeric(
      spec$robustness_step %||% spec$netcomi_robustness_step %||% 0.1),
    robustness_max_ratio = as.numeric(
      spec$robustness_max_ratio %||% 0.9),
    robustness_measure = as.character(
      spec$robustness_measure %||% "Eff"),
    robustness_runs = max(5L, as.integer(
      spec$robustness_runs %||% spec$netcomi_robustness_runs %||% 20L)))
  paste0("stability-", digest::digest(
    parameters, algo = "xxhash64", serialize = TRUE))
}

microbiome_cross_domain_clr_matrix <- function(counts, pseudocount = 0.5) {
  domains <- sub("::.*$", "", colnames(counts))
  transformed <- do.call(cbind, lapply(unique(domains), function(domain) {
    block <- counts[, domains == domain, drop = FALSE]
    logged <- log(block + as.numeric(pseudocount))
    logged - rowMeans(logged)
  }))
  transformed <- transformed[, colnames(counts), drop = FALSE]
  sweep(
    transformed, 2L, apply(transformed, 2L, min), FUN = "-") + 1e-08
}

microbiome_netcomi_construct <- function(counts, spec) {
  measure <- spec$network_measure %||% spec$network_method %||% "spieceasi"
  correlation_measures <- c("pearson", "spearman", "bicor")
  spars_method <- if (measure %in% correlation_measures) "t-test" else "none"
  threshold <- as.numeric(spec$network_threshold %||% spec$correlation_threshold %||% 0)
  requested_cores <- max(1L, as.integer(spec$n_cores %||%
    spec$netcomi_cores %||% microbiome_netcomi_default_cores()))
  measure_parameters <- spec$measure_parameters %||% list()
  if (identical(measure, "spring")) {
    spring_defaults <- list(
      ncores = requested_cores,
      nlambda = as.integer(spec$spring_nlambda %||% 20L),
      rep.num = as.integer(spec$spring_repetitions %||% 20L),
      verbose = FALSE)
    measure_parameters <- utils::modifyList(
      spring_defaults, measure_parameters)
  }
  analysis_counts <- counts
  data_type <- "counts"
  zero_method <- spec$zero_method %||% spec$netcomi_zero_method %||% "pseudo"
  norm_method <- spec$norm_method %||% spec$netcomi_norm_method %||% "clr"
  if (isTRUE(spec$cross_domain_clr)) {
    analysis_counts <- microbiome_cross_domain_clr_matrix(
      counts, spec$cross_domain_pseudocount %||% 0.5)
    zero_method <- "none"
    norm_method <- "none"
  }
  arguments <- list(
    data = analysis_counts, dataType = data_type, measure = measure,
    measurePar = if (length(measure_parameters)) measure_parameters else NULL,
    zeroMethod = zero_method,
    normMethod = norm_method,
    sparsMethod = spars_method,
    alpha = as.numeric(spec$network_fdr %||% spec$alpha %||% 0.05),
    adjust = "BH", cores = requested_cores,
    verbose = 0, seed = as.integer(spec$seed %||% spec$netcomi_seed %||% 2026L))
  construct <- tryCatch(
    microbiome_netcomi_call_construct(arguments),
    error = function(error) {
      if (!measure %in% correlation_measures) stop(error)
      warning(
        "No network survived the requested FDR filter; NetCoMi threshold ",
        "sparsification was used for this network. Original error: ",
        conditionMessage(error), call. = FALSE)
      arguments$sparsMethod <- "threshold"
      arguments$thresh <- threshold
      microbiome_netcomi_call_construct(arguments)
    })
  if (microbiome_netcomi_uses_association_threshold(measure) &&
      is.matrix(construct$assoMat1) && threshold > 0) {
    keep <- abs(construct$assoMat1) >= threshold
    diag(keep) <- FALSE
    construct$adjaMat1 <- construct$adjaMat1 * keep
    if (is.data.frame(construct$edgelist1) && nrow(construct$edgelist1) &&
        "asso" %in% names(construct$edgelist1) &&
        is.numeric(construct$edgelist1$asso)) {
      construct$edgelist1 <- construct$edgelist1[
        abs(construct$edgelist1$asso) >= threshold, , drop = FALSE]
    }
  }
  empty_network <- !is.data.frame(construct$edgelist1) ||
    !nrow(construct$edgelist1)
  properties <- if (empty_network) {
    warning(
      "NetCoMi inferred no edges for this sample subset. An empty network ",
      "was retained without fabricating associations.", call. = FALSE)
    microbiome_netcomi_empty_properties(colnames(counts))
  } else {
    NetCoMi::netAnalyze(
      construct,
      clustMethod = spec$cluster_method %||% spec$netcomi_cluster_method %||%
        "cluster_louvain",
      hubPar = spec$hub_method %||% spec$netcomi_hub_method %||% "degree",
      hubQuant = as.numeric(spec$hub_quantile %||% spec$netcomi_hub_quantile %||% 0.95),
      graphlet = FALSE, gcmHeat = FALSE, gcmHeatLCC = FALSE, verbose = 0)
  }
  list(construct = construct, properties = properties)
}

microbiome_netcomi_extract <- function(fit, counts, taxonomy, group_name) {
  association <- as.matrix(fit$construct$assoMat1)
  adjacency <- as.matrix(fit$construct$adjaMat1)
  if (is.null(rownames(adjacency))) dimnames(adjacency) <- dimnames(association)
  index <- which(upper.tri(adjacency) & adjacency != 0, arr.ind = TRUE)
  edges <- if (nrow(index)) {
    data.frame(
      from = rownames(adjacency)[index[, 1]],
      to = colnames(adjacency)[index[, 2]],
      association = association[index],
      weight = abs(association[index]),
      sign = ifelse(association[index] >= 0, "Positive", "Negative"),
      Group = group_name, stringsAsFactors = FALSE)
  } else {
    data.frame(from = character(), to = character(), association = numeric(),
      weight = numeric(), sign = character(), Group = character())
  }
  graph <- igraph::graph_from_data_frame(
    edges[, c("from", "to", "association", "weight", "sign"), drop = FALSE],
    directed = FALSE, vertices = data.frame(name = colnames(counts)))
  centralities <- fit$properties$centralities
  nodes <- data.frame(
    name = colnames(counts),
    degree = as.numeric(centralities$degree1[colnames(counts)]),
    betweenness = as.numeric(centralities$between1[colnames(counts)]),
    closeness = as.numeric(centralities$close1[colnames(counts)]),
    eigenvector = as.numeric(centralities$eigenv1[colnames(counts)]),
    mean_abundance = colMeans(counts / pmax(rowSums(counts), 1)),
    prevalence = colMeans(counts > 0),
    module = as.character(fit$properties$clustering$clust1[colnames(counts)]),
    hub = colnames(counts) %in% (fit$properties$hubs$hubs1 %||% character()),
    Group = group_name, stringsAsFactors = FALSE)
  degree_raw <- igraph::degree(graph)
  nodes$strength <- as.numeric(igraph::strength(graph, weights = igraph::E(graph)$weight))
  nodes$degree_raw <- as.numeric(degree_raw[nodes$name])
  taxonomy <- as.data.frame(taxonomy, check.names = FALSE)
  if ("Taxon" %in% names(taxonomy)) {
    taxonomy <- taxonomy[!duplicated(taxonomy$Taxon), , drop = FALSE]
    nodes <- merge(nodes, taxonomy, by.x = "name", by.y = "Taxon",
      all.x = TRUE, sort = FALSE)
  }
  membership <- stats::setNames(nodes$module, nodes$name)
  zipi <- microbiome_network_zipi(graph, membership[igraph::V(graph)$name])
  nodes <- merge(nodes, zipi, by.x = "name", by.y = "Feature",
    all.x = TRUE, sort = FALSE)
  global <- unlist(fit$properties$globalProps, recursive = TRUE, use.names = TRUE)
  topology <- data.frame(
    Group = group_name,
    Nodes = igraph::vcount(graph), Edges = igraph::ecount(graph),
    MeanDegree = mean(degree_raw), Density = igraph::edge_density(graph),
    Modularity = as.numeric(global[["modularity1"]] %||% NA_real_),
    AveragePathLength = as.numeric(global[["avPath1"]] %||% NA_real_),
    ClusteringCoefficient = as.numeric(global[["clustCoef1"]] %||% NA_real_),
    PositiveEdgeFraction = if (nrow(edges)) mean(edges$association > 0) else NA_real_,
    stringsAsFactors = FALSE)
  list(graph = graph, nodes = nodes, edges = edges, topology = topology,
    association = association, adjacency = adjacency)
}

microbiome_network_signed_dissimilarity <- function(association) {
  association <- pmax(-1, pmin(1, as.numeric(association)))
  sqrt(0.5 * (1 - association))
}

microbiome_network_as_trans_network <- function(
    extracted, counts, metadata, taxonomy) {
  counts <- as.matrix(counts)
  edge_table <- as.data.frame(
    extracted$edges %||% data.frame(), stringsAsFactors = FALSE)
  if (nrow(edge_table)) {
    from_name <- intersect(c("from", "node1", "source"), names(edge_table))
    to_name <- intersect(c("to", "node2", "target"), names(edge_table))
    if (!length(from_name) || !length(to_name)) {
      stop("The network edge table does not contain named endpoints.",
        call. = FALSE)
    }
    names(edge_table)[names(edge_table) == from_name[[1]]] <- "from"
    names(edge_table)[names(edge_table) == to_name[[1]]] <- "to"
    if (!"association" %in% names(edge_table)) {
      if ("asso" %in% names(edge_table)) {
        edge_table$association <- as.numeric(edge_table$asso)
      } else if ("weight" %in% names(edge_table)) {
        sign_value <- if ("label" %in% names(edge_table)) {
          ifelse(edge_table$label == "-", -1, 1)
        } else {
          1
        }
        edge_table$association <- sign_value *
          abs(as.numeric(edge_table$weight))
      }
    }
    edge_table$association <- pmax(
      -1, pmin(1, as.numeric(edge_table$association)))
    edge_table <- edge_table[
      is.finite(edge_table$association) &
        edge_table$from %in% colnames(counts) &
        edge_table$to %in% colnames(counts),
      , drop = FALSE]
  }
  taxa <- if (nrow(edge_table)) {
    unique(c(as.character(edge_table$from), as.character(edge_table$to)))
  } else {
    colnames(counts)
  }
  taxa <- intersect(colnames(counts), taxa)
  network_counts <- counts[, taxa, drop = FALSE]

  association_matrix <- matrix(
    0, length(taxa), length(taxa), dimnames = list(taxa, taxa))
  stability_edges <- data.frame(
    from = character(), to = character(), association = numeric(),
    weight = numeric(), label = character(), stringsAsFactors = FALSE)
  if (nrow(edge_table)) {
    association_matrix[cbind(
      match(edge_table$from, taxa),
      match(edge_table$to, taxa))] <- edge_table$association
    association_matrix[cbind(
      match(edge_table$to, taxa),
      match(edge_table$from, taxa))] <- edge_table$association
    stability_edges <- data.frame(
      from = as.character(edge_table$from),
      to = as.character(edge_table$to),
      association = edge_table$association,
      weight = microbiome_network_signed_dissimilarity(
        edge_table$association),
      label = ifelse(edge_table$association >= 0, "+", "-"),
      stringsAsFactors = FALSE)
  }
  stability_graph <- igraph::graph_from_data_frame(
    stability_edges, directed = FALSE,
    vertices = data.frame(name = taxa, stringsAsFactors = FALSE))

  tax_table <- as.data.frame(taxonomy, check.names = FALSE)
  if (!nrow(tax_table)) {
    tax_table <- data.frame(
      Taxon = taxa, row.names = taxa, stringsAsFactors = FALSE)
  } else {
    if (!"Taxon" %in% names(tax_table)) {
      tax_table$Taxon <- rownames(tax_table)
    }
    tax_table <- tax_table[!duplicated(tax_table$Taxon), , drop = FALSE]
    rownames(tax_table) <- tax_table$Taxon
    tax_table$Taxon <- NULL
    missing_taxa <- setdiff(taxa, rownames(tax_table))
    if (length(missing_taxa)) {
      missing_table <- as.data.frame(matrix(
        NA_character_, nrow = length(missing_taxa),
        ncol = ncol(tax_table),
        dimnames = list(missing_taxa, names(tax_table))))
      tax_table <- rbind(tax_table, missing_table)
    }
    tax_table <- tax_table[taxa, , drop = FALSE]
  }
  sample_table <- as.data.frame(metadata, check.names = FALSE)
  sample_table <- sample_table[
    match(rownames(network_counts), rownames(sample_table)), , drop = FALSE]
  rownames(sample_table) <- rownames(network_counts)
  microtable <- microeco::microtable$new(
    otu_table = as.data.frame(t(network_counts), check.names = FALSE),
    sample_table = sample_table, tax_table = tax_table,
    auto_tidy = FALSE)
  network <- microeco::trans_network$new(dataset = microtable)
  network$data_abund <- network_counts
  network$res_cor_p <- list(cor = association_matrix)
  network$res_network <- stability_graph

  node_table <- as.data.frame(
    extracted$nodes %||% data.frame(name = taxa),
    stringsAsFactors = FALSE)
  if (!"name" %in% names(node_table)) node_table$name <- rownames(node_table)
  node_table <- node_table[
    match(taxa, node_table$name), , drop = FALSE]
  rownames(node_table) <- taxa
  network$res_node_table <- node_table

  network$res_edge_table <- data.frame(
    node1 = stability_edges$from,
    node2 = stability_edges$to,
    weight = abs(stability_edges$association),
    label = stability_edges$label,
    association = stability_edges$association,
    dissimilarity = stability_edges$weight,
    stringsAsFactors = FALSE)
  network
}

microbiome_netcomi_as_trans_network <- function(
    extracted, counts, metadata, taxonomy) {
  microbiome_network_as_trans_network(
    extracted, counts, metadata, taxonomy)
}

microbiome_network_stability_edges <- function(network_list) {
  if (!length(network_list)) return(data.frame())
  tables <- lapply(names(network_list), function(network_name) {
    edge_table <- as.data.frame(
      network_list[[network_name]]$res_edge_table %||% data.frame(),
      stringsAsFactors = FALSE)
    if (!nrow(edge_table)) return(NULL)
    edge_table$Network <- network_name
    edge_table
  })
  output <- dplyr::bind_rows(tables)
  if (nrow(output)) {
    output <- output[, c(
      "Network", setdiff(names(output), "Network")), drop = FALSE]
  }
  output
}

microbiome_network_trapezoid_auc <- function(x, y) {
  keep <- is.finite(x) & is.finite(y)
  x <- as.numeric(x[keep])
  y <- as.numeric(y[keep])
  if (length(x) < 2L) return(NA_real_)
  summarized <- stats::aggregate(y, list(x = x), mean)
  names(summarized) <- c("ratio", "value")
  summarized <- summarized[order(summarized$ratio), , drop = FALSE]
  if (nrow(summarized) < 2L) return(NA_real_)
  sum(diff(summarized$ratio) *
    (utils::head(summarized$value, -1L) +
      utils::tail(summarized$value, -1L)) / 2)
}

microbiome_network_metric_tests <- function(
    data, group_column, metrics, strata = character()) {
  data <- as.data.frame(data, stringsAsFactors = FALSE)
  if (!nrow(data) || !group_column %in% names(data)) return(data.frame())
  strata <- intersect(strata, names(data))
  split_data <- if (length(strata)) {
    split(data, interaction(data[strata], drop = TRUE, lex.order = TRUE))
  } else {
    list(All = data)
  }
  results <- list()
  append_result <- function(frame, metric, test, contrast, statistic, p) {
    row <- data.frame(
      Metric = metric, Test = test, Contrast = contrast,
      Statistic = as.numeric(statistic), PValue = as.numeric(p),
      stringsAsFactors = FALSE)
    for (field in strata) row[[field]] <- as.character(frame[[field]][[1]])
    results[[length(results) + 1L]] <<- row
  }
  for (frame in split_data) {
    for (metric in intersect(metrics, names(frame))) {
      values <- suppressWarnings(as.numeric(frame[[metric]]))
      groups <- as.character(frame[[group_column]])
      keep <- is.finite(values) & !is.na(groups) & nzchar(groups)
      values <- values[keep]
      groups <- droplevels(factor(groups[keep]))
      if (length(levels(groups)) < 2L) next
      if (length(levels(groups)) == 2L) {
        test <- suppressWarnings(stats::wilcox.test(values ~ groups))
        append_result(
          frame, metric, "Wilcoxon rank-sum",
          paste(levels(groups), collapse = " vs "),
          test$statistic, test$p.value)
      } else {
        test <- stats::kruskal.test(values ~ groups)
        append_result(
          frame, metric, "Kruskal-Wallis", "Overall",
          test$statistic, test$p.value)
        pairs <- utils::combn(levels(groups), 2L, simplify = FALSE)
        for (pair in pairs) {
          index <- groups %in% pair
          pair_test <- suppressWarnings(
            stats::wilcox.test(values[index] ~ droplevels(groups[index])))
          append_result(
            frame, metric, "Pairwise Wilcoxon",
            paste(pair, collapse = " vs "),
            pair_test$statistic, pair_test$p.value)
        }
      }
    }
  }
  if (!length(results)) return(data.frame())
  output <- do.call(rbind, results)
  output$AdjustedP <- stats::p.adjust(output$PValue, method = "BH")
  rownames(output) <- NULL
  output
}

microbiome_network_efficiency <- function(graph) {
  if (igraph::vcount(graph) < 2L || igraph::ecount(graph) < 2L) return(0)
  distance <- stats::as.dist(igraph::distances(graph))
  inverse <- 1 / distance
  inverse[!is.finite(inverse)] <- 0
  sum(inverse) /
    (igraph::vcount(graph) * (igraph::vcount(graph) - 1))
}

microbiome_network_stability <- function(network_list, spec,
    requirements = list(cohesion = TRUE, robustness = TRUE,
      vulnerability = TRUE)) {
  empty <- list(
    cohesion = data.frame(), cohesion_tests = data.frame(),
    robustness = data.frame(), robustness_runs = data.frame(),
    robustness_auc = data.frame(), robustness_tests = data.frame(),
    vulnerability = data.frame(), vulnerability_tests = data.frame(),
    summary = data.frame(), objects = list(), warnings = character())
  if (!length(network_list) || !any(unlist(requirements, use.names = FALSE))) {
    return(empty)
  }
  if (!requireNamespace("meconetcomp", quietly = TRUE)) {
    empty$warnings <- paste(
      "Package meconetcomp is unavailable; cohesion, robustness and",
      "vulnerability were not computed.")
    return(empty)
  }
  warnings <- character()
  safe <- function(code) {
    withCallingHandlers(
      tryCatch(code, error = function(error) {
        warnings <<- c(warnings, conditionMessage(error))
        NULL
      }),
      warning = function(warning) {
        warnings <<- c(warnings, conditionMessage(warning))
        invokeRestart("muffleWarning")
      })
  }
  cohesion_object <- if (isTRUE(requirements$cohesion)) {
    safe(meconetcomp::cohesionclass$new(network_list))
  } else {
    NULL
  }
  strategies <- unique(as.character(
    spec$robustness_strategy %||%
      spec$ggcluster_robustness_strategy %||%
      spec$netcomi_robustness_strategy %||% "node_rand"))
  allowed_strategies <- c(
    "edge_rand", "edge_strong", "edge_weak", "node_rand", "node_hub",
    "node_degree_high", "node_degree_low")
  strategies <- intersect(strategies, allowed_strategies)
  if (!length(strategies)) strategies <- "node_rand"
  step <- as.numeric(
    spec$robustness_step %||%
      spec$ggcluster_robustness_step %||%
      spec$netcomi_robustness_step %||% 0.1)
  step <- max(0.01, min(0.5, step))
  max_ratio <- as.numeric(
    spec$robustness_max_ratio %||%
      spec$ggcluster_robustness_max_ratio %||% 0.9)
  max_ratio <- max(step, min(0.95, max_ratio))
  remove_ratio <- unique(c(
    seq(0, max_ratio, by = step), max_ratio))
  measure <- as.character(
    spec$robustness_measure %||%
      spec$ggcluster_robustness_measure %||% "Eff")
  measure <- intersect(measure, c("Eff", "Eigen", "Pcr"))
  if (!length(measure)) measure <- "Eff"
  runs <- max(5L, as.integer(
    spec$robustness_runs %||%
      spec$ggcluster_robustness_runs %||%
      spec$netcomi_robustness_runs %||% 20L))
  set.seed(as.integer(
    spec$seed %||% spec$ggcluster_seed %||%
      spec$netcomi_seed %||% 2026L))
  robustness_object <- if (isTRUE(requirements$robustness)) {
    safe(meconetcomp::robustness$new(
      network_list, remove_strategy = strategies,
      remove_ratio = remove_ratio, measure = measure, run = runs))
  } else {
    NULL
  }
  vulnerability <- if (isTRUE(requirements$vulnerability)) {
    safe(meconetcomp::vulnerability(network_list))
  } else {
    data.frame()
  }

  cohesion <- as.data.frame(
    cohesion_object$res_list$sample %||% data.frame(),
    stringsAsFactors = FALSE)
  if (nrow(cohesion)) {
    cohesion$network <- as.character(cohesion$network)
    cohesion$Group <- cohesion$network
    cohesion$SampleID <- as.character(cohesion$sample)
  }
  cohesion_tests <- microbiome_network_metric_tests(
    cohesion, "network", c("c_pos", "c_neg"))

  robustness <- as.data.frame(
    robustness_object$res_summary %||% data.frame(),
    stringsAsFactors = FALSE)
  robustness_runs <- as.data.frame(
    robustness_object$res_table %||% data.frame(),
    stringsAsFactors = FALSE)
  for (network_name in names(network_list)) {
    baseline <- microbiome_network_efficiency(
      network_list[[network_name]]$res_network)
    if (nrow(robustness) && "Eff" %in% measure) {
      index <- as.character(robustness$Network) == network_name &
        robustness$measure == "Eff" & robustness$remove_ratio == 0
      robustness$Mean[index] <- baseline
      robustness$SD[index] <- 0
    }
    if (nrow(robustness_runs) && "Eff" %in% measure) {
      index <- as.character(robustness_runs$Network) == network_name &
        robustness_runs$measure == "Eff" &
        robustness_runs$remove_ratio == 0
      robustness_runs$value[index] <- baseline
    }
  }
  robustness_auc_runs <- if (nrow(robustness_runs)) {
    split_runs <- split(
      robustness_runs,
      interaction(
        robustness_runs$Network, robustness_runs$remove_strategy,
        robustness_runs$measure, robustness_runs$Run,
        drop = TRUE, lex.order = TRUE))
    do.call(rbind, lapply(split_runs, function(frame) {
      data.frame(
        Network = as.character(frame$Network[[1]]),
        remove_strategy = as.character(frame$remove_strategy[[1]]),
        measure = as.character(frame$measure[[1]]),
        Run = as.character(frame$Run[[1]]),
        MaximumRemovalRatio = max(
          frame$remove_ratio, na.rm = TRUE),
        AUC = microbiome_network_trapezoid_auc(
          frame$remove_ratio, frame$value),
        stringsAsFactors = FALSE)
    }))
  } else {
    data.frame()
  }
  if (nrow(robustness_auc_runs)) {
    rownames(robustness_auc_runs) <- NULL
  }
  robustness_auc <- if (nrow(robustness_auc_runs)) {
    split_auc <- split(
      robustness_auc_runs,
      interaction(
        robustness_auc_runs$Network,
        robustness_auc_runs$remove_strategy,
        robustness_auc_runs$measure,
        drop = TRUE, lex.order = TRUE))
    do.call(rbind, lapply(split_auc, function(frame) {
      data.frame(
        Network = frame$Network[[1]],
        remove_strategy = frame$remove_strategy[[1]],
        measure = frame$measure[[1]],
        MaximumRemovalRatio = frame$MaximumRemovalRatio[[1]],
        Robustness_AUC = mean(frame$AUC, na.rm = TRUE),
        Robustness_AUC_SD = stats::sd(frame$AUC, na.rm = TRUE),
        SimulationRuns = sum(is.finite(frame$AUC)),
        stringsAsFactors = FALSE)
    }))
  } else {
    data.frame()
  }
  robustness_tests <- microbiome_network_metric_tests(
    robustness_auc_runs, "Network", "AUC",
    c("remove_strategy", "measure"))

  vulnerability <- as.data.frame(
    vulnerability %||% data.frame(), stringsAsFactors = FALSE)
  if (nrow(vulnerability)) {
    vulnerability$Network <- as.character(vulnerability$Network)
    vulnerability$MetricDefinition <-
      "Network efficiency after removing the target node"
  }
  vulnerability_summary <- if (nrow(vulnerability)) {
    do.call(rbind, lapply(
      split(vulnerability, vulnerability$Network), function(frame) {
        data.frame(
          Network = frame$Network[[1]],
          GlobalVulnerability = max(
            frame$vulnerability, na.rm = TRUE),
          MeanNodeVulnerability = mean(
            frame$vulnerability, na.rm = TRUE),
          stringsAsFactors = FALSE)
      }))
  } else {
    data.frame()
  }
  summary <- if (nrow(robustness_auc) && nrow(vulnerability_summary)) {
    merge(
      robustness_auc, vulnerability_summary,
      by = "Network", all = TRUE, sort = FALSE)
  } else if (nrow(robustness_auc)) {
    robustness_auc
  } else {
    vulnerability_summary
  }
  if (nrow(summary)) {
    summary$Group <- summary$Network
    summary$Robustness <- summary$Robustness_AUC %||% NA_real_
    summary$Vulnerability <- summary$GlobalVulnerability %||% NA_real_
    rownames(summary) <- NULL
  }
  list(
    cohesion = cohesion, cohesion_tests = cohesion_tests,
    robustness = robustness, robustness_runs = robustness_auc_runs,
    robustness_auc = robustness_auc,
    robustness_tests = robustness_tests,
    vulnerability = vulnerability,
    vulnerability_tests = data.frame(), summary = summary,
    objects = list(
      cohesion = cohesion_object, robustness = robustness_object),
    warnings = unique(warnings))
}

microbiome_netcomi_stability <- function(
    network_list, spec,
    requirements = list(cohesion = TRUE, robustness = TRUE,
      vulnerability = TRUE)) {
  microbiome_network_stability(network_list, spec, requirements)
}

microbiome_network_annotate_stability <- function(stability, nodes) {
  vulnerability <- as.data.frame(
    stability$vulnerability %||% data.frame(),
    stringsAsFactors = FALSE)
  nodes <- as.data.frame(nodes, stringsAsFactors = FALSE)
  if (!nrow(vulnerability) || !nrow(nodes) ||
      !all(c("Network", "Node") %in% names(vulnerability)) ||
      !all(c("Group", "name") %in% names(nodes))) {
    return(stability)
  }
  annotations <- nodes
  names(annotations)[names(annotations) == "Group"] <- "Network"
  names(annotations)[names(annotations) == "name"] <- "Node"
  annotations <- annotations[
    !duplicated(paste(annotations$Network, annotations$Node)), ,
    drop = FALSE]
  annotation_fields <- setdiff(
    names(annotations),
    intersect(names(annotations), names(vulnerability)))
  annotation_fields <- unique(c("Network", "Node", annotation_fields))
  stability$vulnerability <- merge(
    vulnerability, annotations[, annotation_fields, drop = FALSE],
    by = c("Network", "Node"), all.x = TRUE, sort = FALSE)

  between_networks <- microbiome_network_metric_tests(
    stability$vulnerability, "Network", "vulnerability")
  if (nrow(between_networks)) {
    between_networks$Scope <- "Between networks"
  }
  by_domain <- if ("Kingdom" %in% names(stability$vulnerability)) {
    microbiome_network_metric_tests(
      stability$vulnerability, "Kingdom", "vulnerability", "Network")
  } else {
    data.frame()
  }
  if (nrow(by_domain)) by_domain$Scope <- "Within network by domain"
  stability$vulnerability_tests <- dplyr::bind_rows(
    between_networks, by_domain)
  stability
}

microbiome_netcomi_compare_groups <- function(counts, subsets, spec) {
  if (length(subsets) < 2L) {
    return(list(objects = list(), global = data.frame(),
      centrality = data.frame(), warnings = character(),
      log = character(), cache_hit = FALSE))
  }
  cache_key <- microbiome_netcomi_comparison_cache_key(counts, subsets, spec)
  cached <- microbiome_netcomi_fit_cache("get", cache_key)
  if (!is.null(cached)) {
    cached$cache_hit <- TRUE
    cached$log <- c(
      cached$log,
      "[cache] Reused NetCoMi permutation comparison.")
    return(cached)
  }
  pairs <- utils::combn(names(subsets), 2L, simplify = FALSE)
  objects <- list()
  global_tables <- centrality_tables <- list()
  warnings <- runtime_log <- character()
  for (pair in pairs) {
    captured <- microbiome_capture_runtime_output(function() {
      measure <- spec$network_measure %||% "spieceasi"
      correlation_measure <- measure %in% c("pearson", "spearman", "bicor")
      requested_cores <- max(1L, as.integer(spec$n_cores %||%
        microbiome_netcomi_default_cores()))
      measure_parameters <- spec$measure_parameters %||% list()
      if (identical(measure, "spring")) {
        measure_parameters <- utils::modifyList(
          list(
            ncores = requested_cores,
            nlambda = as.integer(spec$spring_nlambda %||% 20L),
            rep.num = as.integer(spec$spring_repetitions %||% 20L),
            verbose = FALSE),
          measure_parameters)
      }
      data1 <- counts[subsets[[pair[[1]]]], , drop = FALSE]
      data2 <- counts[subsets[[pair[[2]]]], , drop = FALSE]
      zero_method <- spec$zero_method %||% "pseudo"
      norm_method <- spec$norm_method %||% "clr"
      if (isTRUE(spec$cross_domain_clr)) {
        data1 <- microbiome_cross_domain_clr_matrix(
          data1, spec$cross_domain_pseudocount %||% 0.5)
        data2 <- microbiome_cross_domain_clr_matrix(
          data2, spec$cross_domain_pseudocount %||% 0.5)
        zero_method <- "none"
        norm_method <- "none"
      }
      arguments <- list(
        data = data1,
        data2 = data2,
        dataType = "counts", measure = measure,
        measurePar = if (length(measure_parameters)) {
          measure_parameters
        } else NULL,
        zeroMethod = zero_method,
        normMethod = norm_method,
        sparsMethod = if (correlation_measure) "t-test" else "none",
        alpha = as.numeric(spec$network_fdr %||% 0.05), adjust = "BH",
        jointPrepro = TRUE, cores = requested_cores,
        seed = as.integer(spec$seed %||% 2026L), verbose = 0)
      construct <- tryCatch(
        microbiome_netcomi_call_construct(arguments),
        error = function(error) {
          if (!correlation_measure) stop(error)
          warning(
            "The grouped FDR network was empty; the NetCoMi comparison ",
            "used threshold sparsification. Original error: ",
            conditionMessage(error), call. = FALSE)
          arguments$sparsMethod <- "threshold"
          arguments$thresh <- as.numeric(spec$network_threshold %||% 0.3)
          microbiome_netcomi_call_construct(arguments)
        })
      if ((!is.data.frame(construct$edgelist1) || !nrow(construct$edgelist1)) ||
          (!is.data.frame(construct$edgelist2) || !nrow(construct$edgelist2))) {
        warning(
          "NetCoMi comparison skipped because at least one grouped ",
          "SPIEC-EASI network contained no edges.", call. = FALSE)
        return(NULL)
      }
      properties <- NetCoMi::netAnalyze(
        construct, clustMethod = spec$cluster_method %||% "cluster_louvain",
        hubPar = spec$hub_method %||% "degree",
        hubQuant = as.numeric(spec$hub_quantile %||% 0.95),
        graphlet = FALSE, gcmHeat = FALSE, gcmHeatLCC = FALSE, verbose = 0)
      NetCoMi::netCompare(
        properties, permTest = TRUE,
        testRand = FALSE, gcd = FALSE,
        nPerm = max(9L, as.integer(spec$compare_permutations %||% 999L)),
        cores = max(1L, as.integer(spec$n_cores %||%
          microbiome_netcomi_default_cores())),
        verbose = FALSE, seed = as.integer(spec$seed %||% 2026L))
    })
    contrast <- paste(pair[[2]], "vs", pair[[1]])
    comparison <- captured$value
    runtime_log <- c(runtime_log, captured$log)
    if (is.null(comparison)) {
      warnings <- c(warnings, captured$warnings)
      next
    }
    objects[[contrast]] <- comparison
    warnings <- c(warnings, captured$warnings)
    difference <- unlist(comparison$diffGlobal, use.names = TRUE)
    p_value <- unlist(comparison$pvalDiffGlobal, use.names = TRUE)
    metric <- sub("^diff", "", names(difference))
    global_tables[[contrast]] <- data.frame(
      Contrast = contrast, Metric = metric,
      Difference = as.numeric(difference),
      PValue = as.numeric(p_value[paste0("pval", metric)]),
      stringsAsFactors = FALSE)
    centrality_tables[[contrast]] <- do.call(rbind, lapply(
      names(comparison$diffCentr), function(metric_name) {
        difference <- comparison$diffCentr[[metric_name]]
        p_name <- sub("^diff", "pAdjustDiff", metric_name)
        adjusted <- comparison$pvalDiffCentrAdjust[[p_name]]
        data.frame(
          Contrast = contrast,
          Metric = sub("^diff", "", metric_name),
          Taxon = names(difference), Difference = as.numeric(difference),
          AdjustedP = as.numeric(adjusted[names(difference)]),
          stringsAsFactors = FALSE)
      }))
  }
  bind_rows <- function(value) {
    if (length(value)) do.call(rbind, value) else data.frame()
  }
  result <- list(
    objects = objects,
    global = bind_rows(global_tables),
    centrality = bind_rows(centrality_tables),
    warnings = unique(warnings),
    log = runtime_log,
    cache_hit = FALSE)
  if (nzchar(cache_key)) {
    microbiome_netcomi_fit_cache("set", cache_key, result)
  }
  result
}

microbiome_network_layout_weights <- function(graph) {
  edge_count <- igraph::ecount(graph)
  if (!edge_count) return(NULL)
  attribute_names <- igraph::edge_attr_names(graph)
  weight_names <- grep("^(weight|association)(_[0-9]+)?$",
    attribute_names, value = TRUE)
  if (!length(weight_names)) return(rep(1, edge_count))
  candidates <- do.call(cbind, lapply(weight_names, function(name) {
    value <- suppressWarnings(as.numeric(igraph::edge_attr(graph, name)))
    if (length(value) != edge_count) rep(NA_real_, edge_count) else value
  }))
  weights <- apply(abs(candidates), 1, function(value) {
    value <- value[is.finite(value) & value > 0]
    if (length(value)) mean(value) else NA_real_
  })
  valid <- weights[is.finite(weights) & weights > 0]
  replacement <- if (length(valid)) stats::median(valid) else 1
  weights[!is.finite(weights) | weights <= 0] <- replacement
  as.numeric(weights)
}

microbiome_network_layout_coordinates <- function(graphs, algorithm = "fr",
    seed = 2026L, common_layout = TRUE, iterations = 1000L) {
  if (!length(graphs)) {
    return(data.frame(name = character(), x = numeric(), y = numeric()))
  }
  set.seed(as.integer(seed))
  union_graph <- if (length(graphs) > 1L && isTRUE(common_layout)) {
    Reduce(igraph::union, graphs)
  } else graphs[[1]]
  if (!igraph::vcount(union_graph)) {
    return(data.frame(name = character(), x = numeric(), y = numeric()))
  }
  if (igraph::vcount(union_graph) == 1L) {
    return(data.frame(name = igraph::V(union_graph)$name, x = 0, y = 0,
      stringsAsFactors = FALSE))
  }
  weights <- microbiome_network_layout_weights(union_graph)
  if (length(weights)) igraph::E(union_graph)$weight <- weights
  layout <- switch(algorithm,
    kk = igraph::layout_with_kk(union_graph, maxiter = as.integer(iterations),
      weights = weights),
    kamadakawai = igraph::layout_with_kk(
      union_graph, maxiter = as.integer(iterations), weights = weights),
    circle = igraph::layout_in_circle(union_graph),
    mds = igraph::layout_with_mds(union_graph),
    graphopt = igraph::layout_with_graphopt(
      union_graph, niter = as.integer(iterations)),
    grid = igraph::layout_on_grid(union_graph),
    igraph::layout_with_fr(
      union_graph, niter = as.integer(iterations), weights = weights))
  if (any(!is.finite(layout))) {
    layout <- igraph::layout_in_circle(union_graph)
  }
  data.frame(
    name = igraph::V(union_graph)$name,
    x = layout[, 1], y = layout[, 2], stringsAsFactors = FALSE)
}

microbiome_render_network_publication <- function(graphs, nodes, edges, coordinates,
    spec = microbiome_network_plot_spec_default(),
    title = "Microbial Co-occurrence Network") {
  spec <- microbiome_network_plot_spec_merge(spec)
  full_edges <- edges
  if (identical(spec$edge$display_rule, "threshold")) {
    edges <- edges[edges$weight >= spec$edge$threshold, , drop = FALSE]
  } else if (identical(spec$edge$display_rule, "top_n") && nrow(edges)) {
    edges <- utils::head(
      edges[order(edges$weight, decreasing = TRUE), , drop = FALSE],
      spec$edge$top_n)
  } else if (identical(spec$edge$display_rule, "positive")) {
    edges <- edges[edges$association > 0, , drop = FALSE]
  } else if (identical(spec$edge$display_rule, "negative")) {
    edges <- edges[edges$association < 0, , drop = FALSE]
  }

  if (isTRUE(spec$layout$remove_singles) && nrow(full_edges)) {
    connected <- unique(c(full_edges$from, full_edges$to))
    nodes <- nodes[nodes$name %in% connected, , drop = FALSE]
    edges <- edges[edges$from %in% connected & edges$to %in% connected, ,
      drop = FALSE]
  } else if (isTRUE(spec$layout$remove_singles) && !nrow(full_edges)) {
    nodes <- nodes[0, , drop = FALSE]
  }

  if (!nrow(nodes)) {
    return(ggplot2::ggplot() +
      ggplot2::annotate(
        "text", x = 0, y = 0,
        label = "No edges were inferred with the selected network method.",
        size = 4.2) +
      ggplot2::labs(title = spec$annotation$title %||% title) +
      ggplot2::theme_void() +
      ggplot2::theme(
        plot.title = ggplot2::element_text(
          size = spec$annotation$title_size, face = "bold")))
  }

  nodes <- merge(nodes, coordinates, by = "name", all.x = TRUE, sort = FALSE)
  from_coordinates <- coordinates
  names(from_coordinates)[2:3] <- c("x", "y")
  to_coordinates <- coordinates
  names(to_coordinates)[2:3] <- c("xend", "yend")
  edges <- merge(
    edges, from_coordinates, by.x = "from", by.y = "name", all.x = TRUE)
  edges <- merge(
    edges, to_coordinates, by.x = "to", by.y = "name", all.x = TRUE)

  # ggplot2::geom_curve() cannot construct a curve when both endpoints are
  # identical (this is commonly produced by a self-loop or a collapsed
  # layout).  Keep finite edges for plotting, but route degenerate edges to
  # geom_segment() below so the network renderer never raises
  # `calcCurveGrob: endpoints must not be equal` into the Shiny/R console.
  edge_coordinate_columns <- c("x", "y", "xend", "yend")
  if (nrow(edges)) {
    finite_edges <- stats::complete.cases(edges[, edge_coordinate_columns,
      drop = FALSE])
    finite_edges <- finite_edges & apply(
      edges[, edge_coordinate_columns, drop = FALSE], 1L,
      function(row) all(is.finite(as.numeric(row))))
    edges <- edges[finite_edges, , drop = FALSE]
  }

  colour_field <- spec$node$colour_by
  continuous_colour <- colour_field %in% c(
    "degree", "strength", "betweenness", "closeness", "eigenvector",
    "mean_abundance", "prevalence")
  if (!colour_field %in% names(nodes) && !identical(colour_field, "fixed")) {
    colour_field <- "module"
    continuous_colour <- FALSE
  }
  size_field <- spec$node$size_by
  if (!size_field %in% names(nodes) && !identical(size_field, "fixed")) {
    size_field <- "degree"
  }
  nodes$NodeColour <- if (identical(colour_field, "fixed")) {
    spec$node$fixed_colour
  } else if (continuous_colour) {
    suppressWarnings(as.numeric(nodes[[colour_field]]))
  } else {
    as.factor(nodes[[colour_field]])
  }
  nodes$NodeSize <- if (identical(size_field, "fixed")) {
    rep(spec$node$fixed_size, nrow(nodes))
  } else {
    suppressWarnings(as.numeric(nodes[[size_field]]))
  }
  nodes$NodeSize[!is.finite(nodes$NodeSize)] <- 0
  node_range <- range(nodes$NodeSize, finite = TRUE)
  if (!identical(size_field, "fixed") && diff(node_range) > 0) {
    nodes$ScaledSize <- spec$node$size_min +
      (nodes$NodeSize - node_range[1]) / diff(node_range) *
      (spec$node$size_max - spec$node$size_min)
  } else {
    nodes$ScaledSize <- if (identical(size_field, "fixed")) {
      spec$node$fixed_size
    } else {
      mean(c(spec$node$size_min, spec$node$size_max))
    }
  }
  label_field <- if (spec$label$field %in% names(nodes)) {
    spec$label$field
  } else {
    "name"
  }
  label_value <- as.character(nodes[[label_field]])
  label_value[is.na(label_value)] <- nodes$name[is.na(label_value)]
  nodes$Label <- switch(spec$label$mode,
    none = "",
    all = label_value,
    hubs = ifelse(nodes$hub, label_value, ""),
    top_n = ifelse(
      rank(-nodes$NodeSize, ties.method = "first") <= spec$label$top_n,
      label_value, ""),
    "")

  global_alpha <- max(0, min(1, as.numeric(spec$annotation$alpha)))
  edge_mapping <- ggplot2::aes(
    .data$x, .data$y, xend = .data$xend, yend = .data$yend)
  if (identical(spec$edge$colour_by, "sign") &&
      identical(spec$edge$width_by, "abs_weight")) {
    edge_mapping <- ggplot2::aes(
      .data$x, .data$y, xend = .data$xend, yend = .data$yend,
      colour = .data$sign, linewidth = .data$weight)
  } else if (identical(spec$edge$colour_by, "weight") &&
      identical(spec$edge$width_by, "abs_weight")) {
    edge_mapping <- ggplot2::aes(
      .data$x, .data$y, xend = .data$xend, yend = .data$yend,
      colour = .data$association, linewidth = .data$weight)
  } else if (identical(spec$edge$colour_by, "sign")) {
    edge_mapping <- ggplot2::aes(
      .data$x, .data$y, xend = .data$xend, yend = .data$yend,
      colour = .data$sign)
  } else if (identical(spec$edge$colour_by, "weight")) {
    edge_mapping <- ggplot2::aes(
      .data$x, .data$y, xend = .data$xend, yend = .data$yend,
      colour = .data$association)
  } else if (identical(spec$edge$width_by, "abs_weight")) {
    edge_mapping <- ggplot2::aes(
      .data$x, .data$y, xend = .data$xend, yend = .data$yend,
      linewidth = .data$weight)
  }
  edge_parameters <- list(
    data = edges, mapping = edge_mapping,
    alpha = spec$edge$alpha * global_alpha,
    linetype = spec$edge$linetype, lineend = "round")
  if (identical(spec$edge$colour_by, "fixed")) {
    edge_parameters$colour <- spec$edge$fixed_colour
  }
  if (identical(spec$edge$width_by, "fixed")) {
    edge_parameters$linewidth <- spec$edge$fixed_width
  }
  curve <- suppressWarnings(as.numeric(spec$edge$curve %||% 0))
  if (!is.finite(curve)) curve <- 0
  curve <- max(-1, min(1, curve))
  curve_all <- isTRUE(spec$edge$curve_all)
  degenerate_edge <- if (nrow(edges)) {
    abs(edges$x - edges$xend) <= sqrt(.Machine$double.eps) &
      abs(edges$y - edges$yend) <= sqrt(.Machine$double.eps)
  } else logical()
  edge_layers <- if (abs(curve) <= .Machine$double.eps || !nrow(edges)) {
    list(do.call(ggplot2::geom_segment, edge_parameters))
  } else if (curve_all) {
    layers <- list()
    if (any(degenerate_edge)) {
      segment_parameters <- edge_parameters
      segment_parameters$data <- edges[degenerate_edge, , drop = FALSE]
      layers[[length(layers) + 1L]] <- do.call(
        ggplot2::geom_segment, segment_parameters)
    }
    if (any(!degenerate_edge)) {
      curved_parameters <- edge_parameters
      curved_parameters$data <- edges[!degenerate_edge, , drop = FALSE]
      curved_parameters$curvature <- curve
      layers[[length(layers) + 1L]] <- do.call(
        ggplot2::geom_curve, curved_parameters)
    }
    layers
  } else {
    forward <- paste(edges$Group, edges$from, edges$to, sep = "\r")
    reverse <- paste(edges$Group, edges$to, edges$from, sep = "\r")
    curved_index <- reverse %in% forward & !degenerate_edge
    layers <- list()
    if (any(!curved_index)) {
      straight_parameters <- edge_parameters
      straight_parameters$data <- edges[!curved_index, , drop = FALSE]
      layers[[length(layers) + 1L]] <- do.call(
        ggplot2::geom_segment, straight_parameters)
    }
    if (any(curved_index)) {
      curved_parameters <- edge_parameters
      curved_parameters$data <- edges[curved_index, , drop = FALSE]
      curved_parameters$curvature <- curve
      layers[[length(layers) + 1L]] <- do.call(
        ggplot2::geom_curve, curved_parameters)
    }
    layers
  }

  node_mapping <- ggplot2::aes(
    .data$x, .data$y, size = .data$ScaledSize)
  if (!identical(colour_field, "fixed")) {
    node_mapping <- ggplot2::aes(
      .data$x, .data$y, size = .data$ScaledSize, fill = .data$NodeColour)
  }
  node_parameters <- list(
    data = nodes, mapping = node_mapping, shape = spec$node$shape,
    colour = spec$node$border_colour, stroke = spec$node$border_width,
    alpha = global_alpha)
  if (identical(colour_field, "fixed")) {
    node_parameters$fill <- spec$node$fixed_colour
  }
  plot <- ggplot2::ggplot() + edge_layers +
    do.call(ggplot2::geom_point, node_parameters) +
    ggplot2::scale_size_identity()

  hubs <- nodes[isTRUE(spec$node$show_hubs) & nodes$hub, , drop = FALSE]
  if (nrow(hubs)) {
    plot <- plot + ggplot2::geom_point(
      data = hubs,
      ggplot2::aes(.data$x, .data$y, size = .data$ScaledSize),
      shape = spec$node$shape, fill = NA,
      colour = spec$node$hub_border_colour,
      stroke = spec$node$hub_border_width)
  }
  if (!identical(colour_field, "fixed")) {
    plot <- if (continuous_colour) {
      plot + ggplot2::scale_fill_gradient(
        low = spec$node$gradient_low, high = spec$node$gradient_high,
        name = colour_field)
    } else {
      levels <- levels(nodes$NodeColour)
      colours <- grDevices::hcl.colors(
        max(3L, length(levels)), palette = "Dark 3")[seq_along(levels)]
      names(colours) <- levels
      colours[grepl("^Unclassified", levels)] <-
        spec$node$unclassified_colour
      plot + ggplot2::scale_fill_manual(
        values = colours, name = colour_field,
        na.value = spec$node$unclassified_colour)
    }
  }
  if (nrow(edges) && identical(spec$edge$colour_by, "sign")) {
    plot <- plot + ggplot2::scale_colour_manual(
      values = c(Positive = spec$edge$positive_colour,
        Negative = spec$edge$negative_colour), name = "Association")
  } else if (nrow(edges) && identical(spec$edge$colour_by, "weight")) {
    plot <- plot + ggplot2::scale_colour_gradient2(
      low = spec$edge$negative_colour, mid = "#F7F7F7",
      high = spec$edge$positive_colour, midpoint = 0,
      name = "Association")
  }
  if (nrow(edges) && identical(spec$edge$width_by, "abs_weight")) {
    plot <- plot + ggplot2::scale_linewidth_continuous(
      range = c(spec$edge$width_min, spec$edge$width_max), guide = "none")
  }

  plot <- plot +
    ggplot2::facet_wrap(~Group) +
    ggplot2::coord_equal(clip = "off") +
    ggplot2::labs(
      title = spec$annotation$title %||% title,
      subtitle = spec$annotation$subtitle %||% "",
      caption = if (isTRUE(spec$annotation$caption)) {
        sprintf(
          "Node colour: %s; node size: %s; edge width: %s; edge curve: %.2f (%s); layout: %s. Visual edge filter: |association| >= %.2f.",
          colour_field, size_field, spec$edge$width_by,
          curve, if (curve_all) "all edges" else "reciprocal edges",
          spec$layout$algorithm, spec$edge$threshold)
      } else {
        NULL
      }) +
    ggplot2::theme_void(
      base_size = 11, base_family = spec$canvas$base_family) +
    ggplot2::theme(
      legend.position = if (isTRUE(spec$legend$show)) {
        spec$legend$position
      } else {
        "none"
      },
      legend.text = ggplot2::element_text(size = spec$legend$text_size),
      legend.title = ggplot2::element_text(
        size = spec$legend$text_size, face = "bold"),
      plot.title = ggplot2::element_text(
        size = spec$annotation$title_size, face = "bold"),
      plot.background = ggplot2::element_rect(
        fill = spec$canvas$background, colour = NA),
      strip.text = ggplot2::element_text(face = "bold"))

  labelled <- nodes[nzchar(nodes$Label), , drop = FALSE]
  if (nrow(labelled)) {
    plot <- plot + ggrepel::geom_text_repel(
      data = labelled,
      ggplot2::aes(.data$x, .data$y, label = .data$Label),
      size = spec$label$size, colour = spec$label$colour,
      max.overlaps = Inf, box.padding = 0.35, min.segment.length = 0)
  }
  plot
}

microbiome_render_netcomi_result_network <- function(result, spec) {
  graphs <- result$network_objects$graphs
  coordinates <- microbiome_network_layout_coordinates(
    graphs, spec$layout$algorithm, spec$layout$seed,
    length(graphs) > 1L && isTRUE(spec$layout$common_layout),
    spec$layout$iterations)
  microbiome_render_network_publication(
    graphs, result$tables$nodes, result$tables$edges, coordinates, spec)
}

microbiome_netcomi_support_plots <- function(nodes, edges, topology, stability) {
  taxonomy_field <- if ("Phylum" %in% names(nodes)) {
    "Phylum"
  } else if ("Rank" %in% names(nodes)) {
    "Rank"
  } else {
    nodes$Taxonomy <- "Unclassified"
    "Taxonomy"
  }
  nodes$TaxonomicGroup <- as.factor(nodes[[taxonomy_field]])
  cohesion_data <- as.data.frame(
    stability$cohesion %||% data.frame(),
    stringsAsFactors = FALSE)
  cohesion_tests <- as.data.frame(
    stability$cohesion_tests %||% data.frame(),
    stringsAsFactors = FALSE)
  cohesion_subtitle <- if (nrow(cohesion_tests)) {
    overall <- cohesion_tests[
      cohesion_tests$Test != "Pairwise Wilcoxon", , drop = FALSE]
    overall <- utils::head(overall, 2L)
    paste(sprintf(
      "%s: BH-adjusted P = %.3g",
      overall$Metric, overall$AdjustedP), collapse = "; ")
  } else {
    NULL
  }
  robustness_data <- as.data.frame(
    stability$robustness %||% data.frame(),
    stringsAsFactors = FALSE)
  stability_summary <- as.data.frame(
    stability$summary %||% data.frame(),
    stringsAsFactors = FALSE)
  if (nrow(stability_summary) &&
      !"remove_strategy" %in% names(stability_summary)) {
    stability_summary$remove_strategy <- "Not applicable"
  }
  stability_summary_long <- if (nrow(stability_summary)) {
    long <- tidyr::pivot_longer(
      stability_summary,
      cols = intersect(
        c("Robustness", "Vulnerability"),
        names(stability_summary)),
      names_to = "Metric", values_to = "Value")
    vulnerability_rows <- long$Metric == "Vulnerability"
    if (any(vulnerability_rows)) {
      vulnerability_data_summary <- long[
        vulnerability_rows, , drop = FALSE]
      vulnerability_data_summary <- vulnerability_data_summary[
        !duplicated(vulnerability_data_summary$Group), , drop = FALSE]
      vulnerability_data_summary$remove_strategy <- "All nodes"
      long <- dplyr::bind_rows(
        long[!vulnerability_rows, , drop = FALSE],
        vulnerability_data_summary)
    }
    long[is.finite(suppressWarnings(as.numeric(long$Value))), , drop = FALSE]
  } else {
    data.frame()
  }
  vulnerability_data <- as.data.frame(
    stability$vulnerability %||% data.frame(),
    stringsAsFactors = FALSE)
  if (nrow(vulnerability_data)) {
    vulnerability_data <- vulnerability_data[
      is.finite(suppressWarnings(as.numeric(
        vulnerability_data$vulnerability))), , drop = FALSE]
  }
  if (nrow(vulnerability_data)) {
    vulnerability_data <- do.call(rbind, lapply(
      split(vulnerability_data, vulnerability_data$Network),
      function(frame) {
        frame <- frame[
          order(frame$vulnerability, decreasing = TRUE), , drop = FALSE]
        utils::head(frame, 30L)
      }))
    label_field <- intersect(
      c("Genus", "Species", "SelectedTaxon", "Node"),
      names(vulnerability_data))
    label_field <- if (length(label_field)) label_field[[1]] else "Node"
    vulnerability_data$TaxonLabel <- as.character(
      vulnerability_data[[label_field]])
    vulnerability_data$TaxonLabel[
      is.na(vulnerability_data$TaxonLabel) |
        !nzchar(vulnerability_data$TaxonLabel)] <-
      vulnerability_data$Node[
        is.na(vulnerability_data$TaxonLabel) |
          !nzchar(vulnerability_data$TaxonLabel)]
    vulnerability_fill <- if ("Kingdom" %in% names(vulnerability_data)) {
      "Kingdom"
    } else {
      "Network"
    }
  }
  list(
    centrality_distribution = ggplot2::ggplot(nodes,
      ggplot2::aes(.data$degree_raw, fill = .data$Group)) +
      ggplot2::geom_histogram(alpha = 0.7, bins = 15, position = "identity") +
      ggplot2::labs(x = "Degree", y = "Node count",
        title = "Degree Distribution") + ggplot2::theme_classic(),
    zipi_roles = ggplot2::ggplot(nodes, ggplot2::aes(.data$Pi, .data$Zi,
      colour = .data$module, shape = .data$hub)) +
      ggplot2::geom_hline(yintercept = 2.5, linetype = 2) +
      ggplot2::geom_vline(xintercept = 0.62, linetype = 2) +
      ggplot2::geom_point(size = 3) +
      ggplot2::labs(x = "Participation coefficient (Pi)",
        y = "Within-module connectivity (Zi)", title = "Zi-Pi Node Roles") +
      ggplot2::theme_classic(),
    module_composition = ggplot2::ggplot(nodes,
      ggplot2::aes(.data$module, fill = .data$TaxonomicGroup)) +
      ggplot2::geom_bar(position = "fill") +
      ggplot2::labs(x = "Module", y = "Taxonomic composition",
        fill = taxonomy_field, title = "Module Composition") +
      ggplot2::theme_classic(),
    cohesion = if (nrow(cohesion_data)) {
      tidyr::pivot_longer(cohesion_data,
        cols = intersect(c("c_pos", "c_neg"), names(cohesion_data)),
        names_to = "Cohesion", values_to = "Value") |>
        ggplot2::ggplot(ggplot2::aes(.data$network, .data$Value,
          fill = .data$Cohesion)) +
        ggplot2::geom_boxplot(outlier.shape = NA) +
        ggplot2::geom_jitter(width = 0.12, alpha = 0.45, size = 1.5) +
        ggplot2::labs(x = "Network", y = "Cohesion",
          title = "Positive and Negative Cohesion",
          subtitle = cohesion_subtitle) +
        ggplot2::theme_classic()
    } else NULL,
    robustness = if (nrow(robustness_data)) {
      ggplot2::ggplot(robustness_data,
        ggplot2::aes(.data$remove_ratio, .data$Mean, colour = .data$Network,
          linetype = .data$remove_strategy,
          group = interaction(.data$Network, .data$remove_strategy))) +
        ggplot2::geom_ribbon(ggplot2::aes(ymin = pmax(0, .data$Mean - .data$SD),
          ymax = .data$Mean + .data$SD, fill = .data$Network),
          alpha = 0.14, colour = NA) +
        ggplot2::geom_line(linewidth = 0.9) +
        ggplot2::labs(x = "Proportion removed",
          y = "Remaining stability metric",
          colour = "Network", linetype = "Removal strategy",
          title = "Network Robustness") +
        ggplot2::theme_classic()
    } else NULL,
    node_vulnerability = if (nrow(vulnerability_data)) {
      ggplot2::ggplot(
        vulnerability_data,
        ggplot2::aes(
          .data$vulnerability,
          stats::reorder(.data$TaxonLabel, .data$vulnerability),
          fill = .data[[vulnerability_fill]])) +
        ggplot2::geom_col(width = 0.72) +
        ggplot2::facet_wrap(~Network, scales = "free_y") +
        ggplot2::labs(
          x = "Node vulnerability (efficiency after removal)", y = "Taxon",
          fill = vulnerability_fill,
          title = "Node Vulnerability") +
        ggplot2::theme_classic()
    } else NULL,
    stability_summary = if (nrow(stability_summary_long)) {
      ggplot2::ggplot(
        stability_summary_long,
        ggplot2::aes(
          .data$Group, .data$Value,
          fill = .data$remove_strategy)) +
        ggplot2::geom_col(position = "dodge") +
        ggplot2::facet_wrap(~Metric, scales = "free_y") +
        ggplot2::labs(
          x = "Network", y = "Metric value",
          fill = "Removal strategy",
          title = "Network Stability Summary") +
        ggplot2::theme_classic()
    } else NULL)
}

microbiome_run_netcomi_network <- function(bundle, spec = list()) {
  grouped <- isTRUE(spec$group_network)
  requested <- unique(as.character(spec$plot_types %||%
    microbiome_netcomi_default_plot_types(grouped)))
  requirements <- microbiome_netcomi_analysis_requirements(
    requested, grouped)
  stability_required <- any(unlist(
    requirements[c("cohesion", "robustness", "vulnerability")],
    use.names = FALSE))
  required <- c(
    "NetCoMi", "igraph",
    if (stability_required) c("microeco", "meconetcomp"))
  installed <- vapply(
    required,
    function(package) nzchar(system.file(package = package)),
    logical(1))
  missing <- required[!installed]
  if (length(missing)) {
    stop("NetCoMi network analysis requires: ", paste(missing, collapse = ", "),
      call. = FALSE)
  }
  started <- proc.time()[["elapsed"]]
  execution_profile <- data.frame(
    Stage = character(), Seconds = numeric(), Computed = logical(),
    stringsAsFactors = FALSE)
  add_timing <- function(stage, stage_started, computed = TRUE) {
    execution_profile <<- rbind(
      execution_profile,
      data.frame(
        Stage = stage,
        Seconds = round(proc.time()[["elapsed"]] - stage_started, 3),
        Computed = computed,
        stringsAsFactors = FALSE))
  }
  stage_started <- proc.time()[["elapsed"]]
  aggregation <- microbiome_netcomi_aggregate(bundle, spec)
  add_timing("Taxonomic aggregation and filtering", stage_started)
  counts <- aggregation$counts
  metadata <- aggregation$bundle$metadata
  group_name <- if (grouped) as.character(spec$group %||% "") else ""
  if (grouped && (!nzchar(group_name) || !group_name %in% names(metadata))) {
    stop("Select a valid categorical grouping variable for grouped networks.",
      call. = FALSE)
  }
  subsets <- if (grouped) {
    group <- droplevels(factor(metadata[[group_name]]))
    stats::setNames(lapply(levels(group), function(level) which(group == level)),
      levels(group))
  } else list(Overall = seq_len(nrow(counts)))
  if (any(lengths(subsets) < 6L)) {
    stop("Each network requires at least six samples.", call. = FALSE)
  }
  fits <- extracted <- trans_networks <- list()
  runtime_log <- warnings <- character()
  total_cores <- max(1L, as.integer(spec$n_cores %||%
    spec$netcomi_cores %||% microbiome_netcomi_default_cores()))
  per_group_cores <- total_cores
  stage_started <- proc.time()[["elapsed"]]
  fit_scope <- function(scope) {
    index <- subsets[[scope]]
    fit_spec <- spec
    fit_spec$n_cores <- per_group_cores
    captured <- microbiome_capture_runtime_output(function() {
      microbiome_netcomi_construct(counts[index, , drop = FALSE], fit_spec)
    })
    list(
      scope = scope, index = index, captured = captured,
      cache_key = microbiome_netcomi_fit_cache_key(
        counts[index, , drop = FALSE], spec),
      cache_hit = FALSE)
  }
  cached_scopes <- lapply(names(subsets), function(scope) {
    index <- subsets[[scope]]
    key <- microbiome_netcomi_fit_cache_key(
      counts[index, , drop = FALSE], spec)
    cached <- microbiome_netcomi_fit_cache("get", key)
    if (is.null(cached)) return(NULL)
    cached$log <- c(
      cached$log,
      sprintf("[cache] Reused fitted NetCoMi network for %s.", scope))
    list(
      scope = scope, index = index, captured = cached,
      cache_key = key, cache_hit = TRUE)
  })
  names(cached_scopes) <- names(subsets)
  missing_scopes <- names(subsets)[vapply(
    cached_scopes, is.null, logical(1))]
  parallel_groups <- grouped && length(missing_scopes) > 1L &&
    total_cores > 1L &&
    microbiome_netcomi_parallel_group_measure(
      spec$network_measure %||% spec$network_method %||% "spieceasi")
  concurrent_groups <- if (parallel_groups) {
    min(length(missing_scopes), total_cores)
  } else 1L
  per_group_cores <- if (parallel_groups) {
    max(1L, floor(total_cores / concurrent_groups))
  } else total_cores
  newly_fitted <- if (parallel_groups) {
    batches <- split(
      missing_scopes,
      ceiling(seq_along(missing_scopes) / concurrent_groups))
    unlist(lapply(batches, function(batch) {
      microbiome_netcomi_parallel_group_fits(
        batch, counts, subsets, spec, per_group_cores,
        workers = length(batch))
    }), recursive = FALSE)
  } else {
    lapply(missing_scopes, fit_scope)
  }
  for (fitted_scope in newly_fitted) {
    if (nzchar(fitted_scope$cache_key)) {
      microbiome_netcomi_fit_cache(
        "set", fitted_scope$cache_key, fitted_scope$captured)
    }
  }
  newly_fitted <- stats::setNames(
    newly_fitted, vapply(newly_fitted, `[[`, character(1), "scope"))
  fitted_scopes <- lapply(names(subsets), function(scope) {
    cached_scopes[[scope]] %||% newly_fitted[[scope]]
  })
  if (parallel_groups) {
    runtime_log <- c(
      runtime_log,
      sprintf(
        paste0(
          "[performance] Group network construction parallelized across ",
          "%d uncached groups with %d SPRING/core worker(s) per group ",
          "(%d total thread budget)."),
        length(missing_scopes), per_group_cores, total_cores))
  }
  cache_hits <- sum(vapply(fitted_scopes, `[[`, logical(1), "cache_hit"))
  cache_misses <- length(fitted_scopes) - cache_hits
  runtime_log <- c(
    runtime_log,
    sprintf(
      "[performance] NetCoMi fit cache: %d hit(s), %d miss(es).",
      cache_hits, cache_misses))
  for (fitted_scope in fitted_scopes) {
    scope <- fitted_scope$scope
    index <- fitted_scope$index
    captured <- fitted_scope$captured
    fits[[scope]] <- captured$value
    runtime_log <- c(runtime_log, captured$log)
    warnings <- c(warnings, captured$warnings)
    extracted[[scope]] <- microbiome_netcomi_extract(
      fits[[scope]], counts[index, , drop = FALSE], aggregation$mapping, scope)
    if (stability_required) {
      captured_trans_network <- microbiome_capture_runtime_output(function() {
        microbiome_netcomi_as_trans_network(
          extracted[[scope]], counts[index, , drop = FALSE],
          metadata[index, , drop = FALSE], aggregation$mapping)
      })
      trans_networks[[scope]] <- captured_trans_network$value
      runtime_log <- c(runtime_log, captured_trans_network$log)
      warnings <- c(warnings, captured_trans_network$warnings)
    }
  }
  add_timing("Group network construction", stage_started)
  stage_started <- proc.time()[["elapsed"]]
  stability_cache_key <- if (stability_required) {
    microbiome_netcomi_stability_cache_key(
      counts, subsets, spec, requirements)
  } else ""
  cached_stability <- if (nzchar(stability_cache_key)) {
    microbiome_netcomi_fit_cache("get", stability_cache_key)
  } else NULL
  stability_cache_hit <- !is.null(cached_stability)
  stability <- if (stability_cache_hit) {
    runtime_log <- c(
      runtime_log,
      "[cache] Reused Cohesion and network-stability results.")
    cached_stability
  } else if (stability_required) {
    value <- microbiome_netcomi_stability(
      trans_networks, spec, requirements)
    if (nzchar(stability_cache_key)) {
      microbiome_netcomi_fit_cache("set", stability_cache_key, value)
    }
    value
  } else {
    list(
      cohesion = data.frame(), cohesion_tests = data.frame(),
      robustness = data.frame(), robustness_runs = data.frame(),
      robustness_auc = data.frame(), robustness_tests = data.frame(),
      vulnerability = data.frame(), vulnerability_tests = data.frame(),
      summary = data.frame(), objects = list(), warnings = character())
  }
  add_timing("Cohesion and stability analysis", stage_started,
    stability_required)
  if (stability_required) {
    runtime_log <- c(
      runtime_log,
      paste(
        "[stability] Cohesion used signed associations;",
        "robustness and node vulnerability used",
        "diss = sqrt(0.5 * (1 - r))."))
  }
  stage_started <- proc.time()[["elapsed"]]
  comparison <- if (isTRUE(requirements$comparison)) {
    microbiome_netcomi_compare_groups(counts, subsets, spec)
  } else {
    list(objects = list(), global = data.frame(), centrality = data.frame(),
      warnings = character(), log = character(), cache_hit = FALSE)
  }
  add_timing("Permutation network comparison", stage_started,
    isTRUE(requirements$comparison))
  warnings <- unique(c(warnings, stability$warnings, comparison$warnings))
  runtime_log <- c(runtime_log, comparison$log)
  graphs <- lapply(extracted, `[[`, "graph")
  nodes <- do.call(rbind, lapply(extracted, `[[`, "nodes"))
  edges <- do.call(rbind, lapply(extracted, `[[`, "edges"))
  topology <- do.call(rbind, lapply(extracted, `[[`, "topology"))
  rownames(nodes) <- rownames(edges) <- rownames(topology) <- NULL
  stability <- microbiome_network_annotate_stability(stability, nodes)
  plot_spec <- microbiome_network_plot_spec_merge(spec$network_plot_spec %||% list(
    layout = list(algorithm = spec$default_layout %||%
      spec$netcomi_default_layout %||% "fr",
      seed = as.integer(spec$seed %||% spec$netcomi_seed %||% 2026L),
      common_layout = TRUE),
    node = list(colour_by = spec$node_colour %||%
      spec$netcomi_node_colour %||% "Phylum",
      size_by = spec$node_size %||% spec$netcomi_node_size %||% "degree"),
    annotation = list(title = if (grouped)
      "Group-specific Microbial Co-occurrence Networks" else
        "Microbial Co-occurrence Network",
      subtitle = paste("Network taxonomic level:", aggregation$rank))))
  plot_spec$annotation$subtitle <- paste(
    "Network taxonomic level:", aggregation$rank)
  stage_started <- proc.time()[["elapsed"]]
  coordinates <- microbiome_network_layout_coordinates(
    graphs, plot_spec$layout$algorithm, plot_spec$layout$seed,
    grouped && isTRUE(plot_spec$layout$common_layout))
  network_plot <- microbiome_render_network_publication(
    graphs, nodes, edges, coordinates, plot_spec)
  support <- microbiome_netcomi_support_plots(nodes, edges, topology, stability)
  plots <- list()
  main_name <- if (grouped) "grouped_network" else "overall_network"
  if (main_name %in% requested) plots[[main_name]] <- network_plot
  for (name in intersect(names(support), requested)) plots[[name]] <- support[[name]]
  if (grouped) {
    if ("common_nodes_network" %in% requested) plots$common_nodes_network <- network_plot
    if ("group_specific_edges" %in% requested) {
      edge_summary <- aggregate(weight ~ Group + sign, edges, length)
      plots$group_specific_edges <- ggplot2::ggplot(edge_summary,
        ggplot2::aes(.data$Group, .data$weight, fill = .data$sign)) +
        ggplot2::geom_col(position = "dodge") +
        ggplot2::labs(x = "Network", y = "Number of edges",
          title = "Group-specific Edge Composition") + ggplot2::theme_classic()
    }
    if ("network_metric_forest" %in% requested) {
      if (nrow(comparison$global)) {
        plots$network_metric_forest <- ggplot2::ggplot(comparison$global,
          ggplot2::aes(.data$Difference, .data$Metric, colour = .data$Contrast)) +
          ggplot2::geom_vline(xintercept = 0, linetype = 2) +
          ggplot2::geom_point(size = 3,
            position = ggplot2::position_dodge(width = 0.45)) +
          ggplot2::geom_text(ggplot2::aes(label = sprintf("P = %.3f", .data$PValue)),
            nudge_x = 0.03, hjust = 0, size = 3) +
          ggplot2::labs(x = "Difference between networks", y = NULL,
            title = "Permutation Tests of Network Properties") +
          ggplot2::theme_classic()
      }
    }
    if ("centrality_difference" %in% requested) {
      if (nrow(comparison$centrality)) {
        centrality <- comparison$centrality
        centrality <- centrality[order(centrality$AdjustedP,
          -abs(centrality$Difference)), , drop = FALSE]
        centrality <- utils::head(centrality, 40L)
        plots$centrality_difference <- ggplot2::ggplot(centrality,
          ggplot2::aes(.data$Difference,
            stats::reorder(.data$Taxon, .data$Difference),
            colour = .data$Contrast, shape = .data$AdjustedP < 0.05)) +
          ggplot2::geom_vline(xintercept = 0, linetype = 2) +
          ggplot2::geom_point(size = 2.8) +
          ggplot2::facet_wrap(~Metric, scales = "free_y") +
          ggplot2::labs(x = "Centrality difference", y = "Taxon",
            shape = "Adjusted P < 0.05",
            title = "Permutation-tested Node Centrality Differences") +
          ggplot2::theme_classic()
      }
    }
    if ("edge_change_sankey" %in% requested) {
      edge_key <- paste(pmin(edges$from, edges$to), pmax(edges$from, edges$to), sep = " -- ")
      transition <- table(edges$Group, edge_key)
      transition <- data.frame(Group = rownames(transition),
        Edges = rowSums(transition > 0))
      plots$edge_change_sankey <- ggplot2::ggplot(transition,
        ggplot2::aes(.data$Group, .data$Edges, fill = .data$Group)) +
        ggplot2::geom_col(show.legend = FALSE) +
        ggplot2::labs(x = "Network", y = "Observed edges",
          title = "Edge-set Change Overview") + ggplot2::theme_classic()
    }
  }
  plots <- Filter(Negate(is.null), plots)
  add_timing("Layout and plot rendering", stage_started)
  runtime_log <- c(
    runtime_log,
    sprintf(
      "[performance] %s: %.3f s%s",
      execution_profile$Stage, execution_profile$Seconds,
      ifelse(execution_profile$Computed, "", " (skipped)")))
  tables <- list(
    aggregation_summary = data.frame(
      TaxonomicLevel = aggregation$rank,
      Samples = nrow(counts),
      AggregatedTaxa = ncol(counts),
      stringsAsFactors = FALSE),
    fit_cache_summary = data.frame(
      CacheHits = cache_hits,
      CacheMisses = cache_misses,
      ParallelizedMisses = if (parallel_groups) length(missing_scopes) else 0L,
      StabilityCacheHit = stability_cache_hit,
      ComparisonCacheHit = isTRUE(comparison$cache_hit),
      stringsAsFactors = FALSE),
    execution_profile = execution_profile,
    nodes = nodes, edges = edges, topology = topology,
    cohesion = stability$cohesion,
    cohesion_tests = stability$cohesion_tests,
    robustness = stability$robustness,
    robustness_auc = stability$robustness_auc,
    robustness_auc_runs = stability$robustness_runs,
    robustness_tests = stability$robustness_tests,
    vulnerability = stability$vulnerability,
    vulnerability_tests = stability$vulnerability_tests,
    stability_summary = stability$summary,
    stability_edges = microbiome_network_stability_edges(
      trans_networks),
    network_comparison = comparison$global,
    centrality_comparison = comparison$centrality,
    layout_coordinates = coordinates,
    aggregated_counts = data.frame(SampleID = rownames(counts), counts,
      check.names = FALSE))
  spec$network_measure <- spec$network_measure %||% "spieceasi"
  spec$group_network <- grouped
  spec$network_plot_spec <- plot_spec
  new_microbiome_result(
    "netcomi_network", status = if (length(warnings)) "warning" else "success",
    marker_type = aggregation$bundle$marker_type,
    data_version = aggregation$bundle$data_version,
    input_summary = microbiome_data_summary(aggregation$bundle),
    analysis_spec = spec, actual_parameters = spec,
    execution_time = proc.time()[["elapsed"]] - started,
    random_seed = plot_spec$layout$seed,
    package_versions = microbiome_package_versions(
      c("NetCoMi", "microeco", "meconetcomp", "igraph", "ggraph", "ggrepel")),
    model_objects = list(net_construct = fits,
      net_analyze = lapply(fits, `[[`, "properties"),
      net_compare = comparison$objects,
      trans_network = trans_networks,
      meconetcomp = stability$objects),
    network_objects = list(graphs = graphs, layout_coordinates = coordinates,
      plot_spec = plot_spec),
    network_tables = tables, tables = tables, plots = plots,
    warnings = warnings, runtime_log = runtime_log,
    available_outputs = names(tables), available_plots = names(plots),
    generated_code = microbiome_netcomi_code(spec),
    registration_manifest = microbiome_registration_manifest(
      aggregation$bundle, "netcomi_network", names(tables)))
}

microbiome_cross_domain_prepare <- function(
    first_bundle, second_bundle, spec = list()) {
  if (!inherits(first_bundle, "microbiome_bundle") ||
      !inherits(second_bundle, "microbiome_bundle")) {
    stop("Cross-domain analysis requires both 16S and ITS microbiome data.",
      call. = FALSE)
  }
  first_bundle <- microbiome_align_bundle(first_bundle)$bundle
  second_bundle <- microbiome_align_bundle(second_bundle)$bundle
  if (identical(first_bundle$marker_type, second_bundle$marker_type)) {
    stop("Bacteria-fungi analysis requires one 16S and one ITS dataset.",
      call. = FALSE)
  }
  bacteria <- if (identical(first_bundle$marker_type, "16S")) {
    first_bundle
  } else {
    second_bundle
  }
  fungi <- if (identical(first_bundle$marker_type, "ITS")) {
    first_bundle
  } else {
    second_bundle
  }
  common_samples <- intersect(rownames(bacteria$counts), rownames(fungi$counts))
  if (length(common_samples) < 6L) {
    stop("At least six matched 16S-ITS samples are required.", call. = FALSE)
  }
  bacteria_rank <- spec$bacteria_taxonomic_rank %||%
    spec$taxonomic_rank %||% "Genus"
  fungi_rank <- spec$fungi_taxonomic_rank %||%
    spec$taxonomic_rank %||% "Genus"
  bacteria_aggregation <- microbiome_species_environment_aggregate(
    bacteria, bacteria_rank)
  fungi_aggregation <- microbiome_species_environment_aggregate(
    fungi, fungi_rank)
  prevalence_threshold <- as.numeric(spec$minimum_prevalence %||%
    spec$netcomi_min_prevalence %||% 0.1)
  maximum_total <- max(10L, as.integer(spec$maximum_features %||%
    spec$netcomi_max_features %||% 60L))
  maximum_per_domain <- max(5L, as.integer(
    spec$cross_max_features_per_domain %||% floor(maximum_total / 2L)))
  select_taxa <- function(counts) {
    prevalence <- colMeans(counts > 0)
    relative <- counts / pmax(rowSums(counts), 1)
    candidates <- which(prevalence >= prevalence_threshold)
    if (!length(candidates)) return(character())
    score <- colMeans(relative[, candidates, drop = FALSE])
    colnames(counts)[candidates[order(score, decreasing = TRUE)]][
      seq_len(min(maximum_per_domain, length(candidates)))]
  }
  bacteria_taxa <- select_taxa(bacteria_aggregation$counts)
  fungi_taxa <- select_taxa(fungi_aggregation$counts)
  if (length(bacteria_taxa) < 2L || length(fungi_taxa) < 2L) {
    stop(
      "Each microbial domain requires at least two taxa after filtering.",
      call. = FALSE)
  }
  prefix_counts <- function(aggregation, taxa, domain) {
    value <- aggregation$counts[
      common_samples, taxa, drop = FALSE]
    colnames(value) <- paste0(domain, "::", taxa)
    value
  }
  bacteria_counts <- prefix_counts(
    bacteria_aggregation, bacteria_taxa, "Bacteria")
  fungi_counts <- prefix_counts(fungi_aggregation, fungi_taxa, "Fungi")
  counts <- cbind(bacteria_counts, fungi_counts)
  taxonomy_for <- function(aggregation, taxa, domain) {
    mapping <- aggregation$mapping[
      match(taxa, aggregation$mapping$Taxon), , drop = FALSE]
    names_out <- paste0(domain, "::", taxa)
    mapping$Domain <- domain
    mapping$Kingdom <- domain
    mapping$Feature <- names_out
    mapping$CrossDomainTaxon <- names_out
    mapping$SelectedRank <- aggregation$rank
    mapping$SelectedTaxon <- taxa
    rownames(mapping) <- names_out
    mapping
  }
  taxonomy <- rbind(
    taxonomy_for(bacteria_aggregation, bacteria_taxa, "Bacteria"),
    taxonomy_for(fungi_aggregation, fungi_taxa, "Fungi"))
  metadata <- as.data.frame(bacteria$metadata, check.names = FALSE)
  metadata_ids <- if ("SampleID" %in% names(metadata)) {
    as.character(metadata$SampleID)
  } else {
    rownames(metadata)
  }
  metadata <- metadata[match(common_samples, metadata_ids), , drop = FALSE]
  rownames(metadata) <- common_samples
  combined <- new_microbiome_bundle(
    counts, taxonomy = taxonomy, metadata = metadata,
    marker_type = "16S",
    data_version = paste(
      bacteria$data_version %||% "16S",
      fungi$data_version %||% "ITS", sep = " + "),
    provenance = list(
      source = "Matched bacteria-fungi cross-domain data",
      bacteria_rank = bacteria_rank, fungi_rank = fungi_rank))
  list(
    bundle = combined,
    bacteria = bacteria, fungi = fungi,
    common_samples = common_samples,
    bacteria_taxa = bacteria_taxa, fungi_taxa = fungi_taxa,
    bacteria_rank = bacteria_rank, fungi_rank = fungi_rank)
}

microbiome_cross_domain_annotate_edges <- function(edges, nodes) {
  if (!nrow(edges)) {
    edges$FromDomain <- character()
    edges$ToDomain <- character()
    edges$EdgeDomain <- character()
    return(edges)
  }
  domain <- stats::setNames(
    as.character(nodes$Kingdom %||% sub("::.*$", "", nodes$name)),
    nodes$name)
  edges$FromDomain <- unname(domain[edges$from])
  edges$ToDomain <- unname(domain[edges$to])
  edges$EdgeDomain <- ifelse(
    edges$FromDomain != edges$ToDomain,
    "Bacteria-Fungi",
    ifelse(edges$FromDomain == "Bacteria",
      "Bacteria-Bacteria", "Fungi-Fungi"))
  edges
}

microbiome_run_cross_domain_network <- function(bundle, spec = list()) {
  second_bundle <- spec$second_bundle
  if (is.null(second_bundle)) {
    stop("Select the paired ITS dataset for cross-domain analysis.",
      call. = FALSE)
  }
  measure <- spec$network_measure %||% "spearman"
  if (!measure %in% unname(microbiome_cross_domain_measure_choices())) {
    stop(
      "Cross-domain CLR analysis supports Pearson, Spearman or bicor.",
      call. = FALSE)
  }
  prepared <- microbiome_cross_domain_prepare(bundle, second_bundle, spec)
  requested <- unique(as.character(spec$plot_types %||%
    "cross_domain_network"))
  grouped <- isTRUE(spec$group_network)
  base_main <- if (grouped) "grouped_network" else "overall_network"
  base_spec <- spec
  base_spec$taxonomic_rank <- "CrossDomainTaxon"
  base_spec$minimum_prevalence <- 0
  base_spec$maximum_features <- ncol(prepared$bundle$counts)
  base_spec$cross_domain_clr <- TRUE
  base_spec$network_measure <- measure
  base_spec$plot_types <- unique(c(
    base_main,
    intersect(requested, c(
      "network_metric_forest", "centrality_difference",
      "cohesion", "robustness", "node_vulnerability",
      "stability_summary"))))
  result <- microbiome_run_netcomi_network(prepared$bundle, base_spec)
  nodes <- result$tables$nodes
  edges <- microbiome_cross_domain_annotate_edges(
    result$tables$edges, nodes)
  result$tables$edges <- edges
  result$network_tables$edges <- edges
  plot_spec <- result$network_objects$plot_spec
  plot_spec$node$colour_by <- "Kingdom"
  plot_spec$node$shape_by <- "Kingdom"
  plot_spec$annotation$title <- if (grouped) {
    "Grouped Bacteria-Fungi Cross-domain Networks"
  } else {
    "Bacteria-Fungi Cross-domain Network"
  }
  plot_spec$annotation$subtitle <- paste0(
    "16S ", prepared$bacteria_rank, " + ITS ", prepared$fungi_rank,
    "; domain-wise CLR")
  result$network_objects$plot_spec <- plot_spec
  empty_plot <- function(title, message) {
    ggplot2::ggplot() +
      ggplot2::annotate("text", x = 0, y = 0, label = message, size = 4) +
      ggplot2::labs(title = title) +
      ggplot2::theme_void()
  }
  cross_plots <- list(
    cross_domain_network = microbiome_render_netcomi_result_network(
      result, plot_spec),
    domain_edge_composition = empty_plot(
      "Within-domain and Cross-domain Associations",
      "No network edges were inferred."),
    cross_domain_heatmap = empty_plot(
      "Bacteria-Fungi Cross-domain Associations",
      "No bacteria-fungi edges were inferred."),
    domain_centrality = ggplot2::ggplot(
      nodes,
      ggplot2::aes(.data$Kingdom, .data$degree, fill = .data$Kingdom)) +
      ggplot2::geom_boxplot(outlier.shape = NA, alpha = 0.7) +
      ggplot2::geom_jitter(width = 0.12, alpha = 0.55, size = 1.5) +
      ggplot2::facet_wrap(~Group) +
      ggplot2::labs(
        x = NULL, y = "Degree",
        title = "Node Centrality by Microbial Domain") +
      ggplot2::theme_classic() +
      ggplot2::theme(legend.position = "none"))
  if (nrow(edges)) {
    edge_summary <- as.data.frame(table(
      Group = edges$Group, EdgeDomain = edges$EdgeDomain),
      stringsAsFactors = FALSE)
    edge_summary <- edge_summary[edge_summary$Freq > 0, , drop = FALSE]
    cross_plots$domain_edge_composition <- ggplot2::ggplot(
      edge_summary,
      ggplot2::aes(.data$Group, .data$Freq, fill = .data$EdgeDomain)) +
      ggplot2::geom_col(position = "fill") +
      ggplot2::scale_y_continuous(labels = scales::percent) +
      ggplot2::labs(
        x = NULL, y = "Edge proportion", fill = "Edge domain",
        title = "Within-domain and Cross-domain Associations") +
      ggplot2::theme_classic()
    cross_edges <- edges[edges$EdgeDomain == "Bacteria-Fungi", , drop = FALSE]
    if (nrow(cross_edges)) {
      cross_edges$Bacteria <- ifelse(
        cross_edges$FromDomain == "Bacteria",
        sub("^Bacteria::", "", cross_edges$from),
        sub("^Bacteria::", "", cross_edges$to))
      cross_edges$Fungi <- ifelse(
        cross_edges$FromDomain == "Fungi",
        sub("^Fungi::", "", cross_edges$from),
        sub("^Fungi::", "", cross_edges$to))
      cross_plots$cross_domain_heatmap <- ggplot2::ggplot(
        cross_edges,
        ggplot2::aes(.data$Bacteria, .data$Fungi, fill = .data$association)) +
        ggplot2::geom_tile(colour = "white", linewidth = 0.25) +
        ggplot2::scale_fill_gradient2(
          low = "#2B6CB0", mid = "white", high = "#C43C39",
          midpoint = 0, name = "Association") +
        ggplot2::facet_wrap(~Group) +
        ggplot2::labs(
          x = "Bacterial taxon", y = "Fungal taxon",
          title = "Bacteria-Fungi Cross-domain Associations") +
        ggplot2::theme_classic() +
        ggplot2::theme(
          axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
    }
  }
  retained_support <- result$plots[
    intersect(names(result$plots), requested)]
  result$plots <- Filter(
    Negate(is.null),
    c(cross_plots[intersect(names(cross_plots), requested)],
      retained_support))
  result$method_id <- "cross_domain_network"
  result$marker_type <- "16S+ITS"
  public_spec <- spec
  public_spec$second_bundle <- NULL
  result$actual_parameters <- utils::modifyList(
    public_spec,
    list(
      bacteria_taxonomic_rank = prepared$bacteria_rank,
      fungi_taxonomic_rank = prepared$fungi_rank,
      matched_samples = length(prepared$common_samples),
      cross_domain_transform = "domain-wise CLR",
      network_plot_spec = plot_spec))
  result$analysis_spec <- result$actual_parameters
  result$tables$cross_domain_summary <- data.frame(
    MatchedSamples = length(prepared$common_samples),
    BacterialTaxa = length(prepared$bacteria_taxa),
    FungalTaxa = length(prepared$fungi_taxa),
    BacteriaRank = prepared$bacteria_rank,
    FungiRank = prepared$fungi_rank,
    stringsAsFactors = FALSE)
  result$tables$matched_counts <- data.frame(
    SampleID = rownames(prepared$bundle$counts),
    prepared$bundle$counts, check.names = FALSE)
  result$network_tables <- result$tables
  result$available_outputs <- names(result$tables)
  result$available_plots <- names(result$plots)
  result$generated_code <- microbiome_cross_domain_network_code(
    result$actual_parameters)
  result
}
