microbiome_network_zipi <- function(graph, membership) {
  adjacency <- as.matrix(igraph::as_adjacency_matrix(graph, attr = "weight", sparse = FALSE))
  adjacency <- abs(adjacency)
  degree <- rowSums(adjacency > 0)
  within <- vapply(seq_len(nrow(adjacency)), function(index) sum(adjacency[index, membership == membership[index]] > 0), numeric(1))
  z <- numeric(length(within))
  for (module in unique(membership)) {
    member <- which(membership == module)
    deviation <- stats::sd(within[member])
    z[member] <- if (length(member) > 1 && is.finite(deviation) && deviation > 0) (within[member] - mean(within[member])) / deviation else 0
  }
  participation <- vapply(seq_len(nrow(adjacency)), function(index) {
    if (!degree[index]) return(0)
    fractions <- vapply(unique(membership), function(module) sum(adjacency[index, membership == module] > 0) / degree[index], numeric(1))
    1 - sum(fractions^2)
  }, numeric(1))
  data.frame(Feature = igraph::V(graph)$name, Zi = z, Pi = participation, stringsAsFactors = FALSE)
}

microbiome_run_network <- function(method_id, bundle, spec = list()) {
  engine <- spec$network_engine %||% "netcomi"
  if (!engine %in% unname(microbiome_network_engine_choices())) {
    stop("Unknown network analysis engine: ", engine, call. = FALSE)
  }
  legacy_measures <- c(
    spearman_network = "spearman",
    pearson_network = "pearson",
    sparcc = "sparcc",
    spieceasi = "spieceasi",
    spring_network = "spring"
  )
  supported <- c(
    "netcomi_network", "cross_domain_network", names(legacy_measures))
  if (!method_id %in% supported) {
    stop("Network adapter supports only the unified NetCoMi workflow.",
      call. = FALSE)
  }
  if (method_id %in% names(legacy_measures)) {
    spec$network_measure <- legacy_measures[[method_id]]
  }
  if (identical(engine, "ggclusternet2")) {
    return(microbiome_run_ggclusternet_network(
      bundle, spec, method_id = if (identical(
        method_id, "cross_domain_network")) {
        "cross_domain_network"
      } else {
        "netcomi_network"
      },
      cross_domain = identical(method_id, "cross_domain_network")))
  }
  if (identical(method_id, "cross_domain_network")) {
    return(microbiome_run_cross_domain_network(bundle, spec))
  }
  microbiome_run_netcomi_network(bundle, spec)
}
