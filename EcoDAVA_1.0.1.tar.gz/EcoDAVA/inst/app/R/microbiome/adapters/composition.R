microbiome_core_abundance_plot <- function(table) {
  ggplot2::ggplot(table, ggplot2::aes(MeanRelativeAbundance, Prevalence, colour = Core)) +
    ggplot2::geom_point(size = 2.7, alpha = 0.82) +
    ggplot2::scale_colour_manual(values = c(`FALSE` = "#8A949C", `TRUE` = "#1B9E77")) +
    ggplot2::labs(title = "Core microbiome", x = "Mean relative abundance",
      y = "Prevalence", colour = "Core taxon") +
    ggplot2::theme_classic(base_size = 12)
}

microbiome_indicator_taxa_plot <- function(table, maximum_features = 20L) {
  statistic_name <- intersect(c("stat", "s", "index", "A"), names(table))
  if (!length(statistic_name) || !nrow(table)) return(NULL)
  statistic <- suppressWarnings(as.numeric(table[[statistic_name[[1]]]]))
  adjusted <- suppressWarnings(as.numeric(table$adjusted_p %||% table$p.value))
  keep <- which(is.finite(statistic))
  if (!length(keep)) return(NULL)
  keep <- utils::head(keep[order(statistic[keep], decreasing = TRUE)], maximum_features)
  display <- table[keep, , drop = FALSE]
  display$IndicatorValue <- statistic[keep]
  display$Feature <- factor(display$Feature, levels = rev(display$Feature))
  display$Significance <- microbiome_differential_significance(adjusted[keep])
  ggplot2::ggplot(display, ggplot2::aes(Feature, IndicatorValue, fill = IndicatorValue)) +
    ggplot2::geom_col(width = 0.72, colour = "#30363B", linewidth = 0.25) +
    ggplot2::geom_text(ggplot2::aes(label = Significance), hjust = -0.3, size = 3.5) +
    ggplot2::coord_flip(clip = "off") +
    ggplot2::scale_fill_gradient(low = "#B9D9D2", high = "#167A6A", guide = "none") +
    ggplot2::labs(title = "Indicator taxa", x = NULL, y = "Indicator value") +
    ggplot2::theme_classic(base_size = 12) +
    ggplot2::theme(plot.margin = ggplot2::margin(8, 26, 8, 8))
}

microbiome_composition_group_data <- function(bundle, spec) {
  groups <- utils::head(intersect(as.character(spec$group_variables %||% spec$group %||% character()),
    names(bundle$metadata)), 3L)
  metadata <- bundle$metadata
  if (!length(groups)) {
    metadata$.DAVA_Group <- factor("All samples")
    groups <- ".DAVA_Group"
  }
  metadata$.DAVA_Group <- interaction(metadata[, groups, drop = FALSE], sep = " / ", drop = TRUE)
  metadata$SampleID <- NULL
  list(metadata = metadata, groups = groups, group = droplevels(metadata$.DAVA_Group))
}

microbiome_composition_attach_metadata <- function(table, bundle, spec) {
  grouping <- microbiome_composition_group_data(bundle, spec)
  metadata <- data.frame(SampleID = rownames(grouping$metadata), grouping$metadata,
    check.names = FALSE, stringsAsFactors = FALSE)
  list(
    table = merge(table, metadata, by = "SampleID", all.x = TRUE, sort = FALSE),
    grouping = grouping
  )
}

microbiome_aggregate_taxonomic_abundance <- function(counts, taxonomy, rank, spec = list()) {
  feature_ids <- colnames(counts)
  if (identical(rank, "feature")) {
    taxon <- feature_ids
  } else {
    taxonomy_ids <- if ("Feature" %in% names(taxonomy)) {
      as.character(taxonomy$Feature)
    } else {
      rownames(taxonomy)
    }
    taxon <- as.character(taxonomy[[rank]][match(feature_ids, taxonomy_ids)])
    missing <- is.na(taxon) | !nzchar(trimws(taxon))
    taxon[missing] <- paste0("Unclassified_", rank)
  }
  aggregated_counts <- rowsum(t(counts), group = taxon, reorder = FALSE)
  sample_depth <- colSums(aggregated_counts)
  sample_depth[sample_depth <= 0] <- 1
  relative <- sweep(aggregated_counts, 2, sample_depth, "/")

  threshold <- if (!is.null(spec$abundance_merge_threshold_percent)) {
    as.numeric(spec$abundance_merge_threshold_percent) / 100
  } else {
    as.numeric(spec$abundance_merge_threshold %||% 0.005)
  }
  threshold <- max(0, threshold)
  maximum_taxa <- max(1L, as.integer(spec$abundance_max_taxa %||% 20L))
  others_label <- trimws(as.character(spec$abundance_others_label %||% "Others"))
  if (!nzchar(others_label)) others_label <- "Others"
  mean_abundance <- rowMeans(relative, na.rm = TRUE)
  ordered_taxa <- names(sort(mean_abundance, decreasing = TRUE))
  retained <- ordered_taxa[mean_abundance[ordered_taxa] >= threshold]
  retained <- utils::head(retained, maximum_taxa)
  merged_labels <- ifelse(rownames(relative) %in% retained, rownames(relative), others_label)
  aggregation_summary <- data.frame(
    Taxon = rownames(relative),
    MeanRelativeAbundance = as.numeric(mean_abundance[rownames(relative)]),
    Threshold = threshold,
    Retained = rownames(relative) %in% retained,
    DisplayTaxon = merged_labels,
    stringsAsFactors = FALSE
  )
  aggregation_summary <- aggregation_summary[
    order(aggregation_summary$MeanRelativeAbundance, decreasing = TRUE), , drop = FALSE]
  relative <- rowsum(relative, group = merged_labels, reorder = FALSE)
  if (others_label %in% rownames(relative)) {
    row_order <- c(setdiff(retained, others_label), others_label)
    relative <- relative[intersect(row_order, rownames(relative)), , drop = FALSE]
  }
  table <- data.frame(
    SampleID = rep(colnames(relative), each = nrow(relative)),
    Taxon = rep(rownames(relative), times = ncol(relative)),
    RelativeAbundance = as.vector(relative),
    stringsAsFactors = FALSE
  )
  list(
    table = table,
    mapping = data.frame(Feature = feature_ids, Taxon = taxon, stringsAsFactors = FALSE),
    summary = aggregation_summary,
    retained_taxa = retained,
    threshold = threshold,
    maximum_taxa = maximum_taxa,
    others_label = others_label
  )
}

microbiome_mixed_abundance_tests <- function(table, spec) {
  method <- spec$composition_abundance_test %||% "lmer"
  required_package <- if (identical(method, "lmer")) "lme4" else "glmmTMB"
  if (!requireNamespace(required_package, quietly = TRUE)) {
    stop("The selected mixed-effects analysis requires package '", required_package, "'.", call. = FALSE)
  }
  if (!requireNamespace("emmeans", quietly = TRUE)) {
    stop("Mixed-effects multiple comparisons require package 'emmeans'.", call. = FALSE)
  }

  quote_name <- function(value) paste0("`", gsub("`", "", value, fixed = TRUE), "`")
  adjustment <- spec$p_adjust_method %||% spec$fdr_method %||% "BH"
  if (!adjustment %in% c(stats::p.adjust.methods, "none")) adjustment <- "BH"
  adjust_p <- function(value) {
    if (identical(adjustment, "none")) value else stats::p.adjust(value, method = adjustment)
  }
  require_variable <- function(value, label) {
    if (!length(value) || !nzchar(value) || !value %in% names(table)) {
      stop("Select a valid ", label, " from sample metadata.", call. = FALSE)
    }
    value
  }

  structure <- spec$effect_structure %||% "random_intercept"
  random_variables <- character()
  random_term <- switch(structure,
    repeated = {
      subject <- require_variable(spec$random_effect %||% "", "repeated-measures Subject/Plot variable")
      random_variables <- subject
      paste0("(1 | ", quote_name(subject), ")")
    },
    nested = {
      outer <- require_variable(spec$random_outer %||% "", "outer random variable")
      inner <- require_variable(spec$random_inner %||% "", "nested random variable")
      if (identical(outer, inner)) stop("Outer and nested random variables must be different.", call. = FALSE)
      random_variables <- c(outer, inner)
      paste0("(1 | ", quote_name(outer), "/", quote_name(inner), ")")
    },
    random_slope = {
      cluster <- require_variable(spec$random_effect %||% "", "random-effect grouping variable")
      slope <- require_variable(spec$random_slope %||% "", "random-slope variable")
      random_variables <- c(cluster, slope)
      paste0("(1 + ", quote_name(slope), " | ", quote_name(cluster), ")")
    },
    {
      cluster <- require_variable(spec$random_effect %||% "", "random-intercept variable")
      random_variables <- cluster
      paste0("(1 | ", quote_name(cluster), ")")
    }
  )

  others_label <- as.character(spec$abundance_others_label %||% "Others")
  taxa <- setdiff(unique(as.character(table$Taxon)), others_label)
  omnibus_rows <- list()
  pairwise_rows <- list()
  marginal_rows <- list()
  diagnostic_rows <- list()
  models <- list()

  for (taxon in taxa) {
    value <- table[
      table$Taxon == taxon & is.finite(table$RelativeAbundance) & !is.na(table$.DAVA_Group),
      , drop = FALSE
    ]
    value$.DAVA_Group <- droplevels(factor(value$.DAVA_Group))
    if (nlevels(value$.DAVA_Group) < 2L || any(table(value$.DAVA_Group) < 2L)) {
      diagnostic_rows[[taxon]] <- data.frame(
        Taxon = taxon, Status = "skipped", Message = "At least two observations per group are required.",
        stringsAsFactors = FALSE
      )
      next
    }
    for (variable in random_variables) value[[variable]] <- droplevels(factor(value[[variable]]))
    if (any(vapply(random_variables, function(variable) nlevels(value[[variable]]) < 2L, logical(1)))) {
      diagnostic_rows[[taxon]] <- data.frame(
        Taxon = taxon, Status = "skipped", Message = "The random effect must contain at least two levels.",
        stringsAsFactors = FALSE
      )
      next
    }

    value$.DAVA_Response <- value$RelativeAbundance
    family_label <- "Gaussian (identity)"
    if (identical(method, "glmmTMB")) {
      family_id <- spec$glmm_family %||% "beta"
      if (identical(family_id, "beta")) {
        sample_count <- nrow(value)
        value$.DAVA_Response <- (value$.DAVA_Response * (sample_count - 1) + 0.5) / sample_count
        family_object <- glmmTMB::beta_family(link = "logit")
        family_label <- "Beta (logit)"
      } else if (identical(family_id, "Gamma")) {
        positive <- value$.DAVA_Response[value$.DAVA_Response > 0]
        if (!length(positive)) {
          diagnostic_rows[[taxon]] <- data.frame(
            Taxon = taxon, Status = "skipped", Message = "Gamma models require positive abundance values.",
            stringsAsFactors = FALSE
          )
          next
        }
        value$.DAVA_Response[value$.DAVA_Response <= 0] <- min(positive) / 2
        family_object <- stats::Gamma(link = "log")
        family_label <- "Gamma (log)"
      } else {
        family_object <- stats::gaussian(link = "identity")
      }
    }

    full_formula <- stats::as.formula(paste(".DAVA_Response ~ .DAVA_Group +", random_term))
    null_formula <- stats::as.formula(paste(".DAVA_Response ~ 1 +", random_term))
    fitted <- tryCatch({
      full <- if (identical(method, "lmer")) {
        lme4::lmer(full_formula, data = value, REML = FALSE)
      } else {
        glmmTMB::glmmTMB(full_formula, data = value, family = family_object)
      }
      null <- if (identical(method, "lmer")) {
        lme4::lmer(null_formula, data = value, REML = FALSE)
      } else {
        glmmTMB::glmmTMB(null_formula, data = value, family = family_object)
      }
      list(full = full, null = null)
    }, error = function(error) error)
    if (inherits(fitted, "error")) {
      diagnostic_rows[[taxon]] <- data.frame(
        Taxon = taxon, Status = "failed", Message = conditionMessage(fitted),
        stringsAsFactors = FALSE
      )
      next
    }

    comparison <- tryCatch(stats::anova(fitted$null, fitted$full), error = function(error) NULL)
    comparison_row <- if (is.null(comparison)) NULL else comparison[nrow(comparison), , drop = FALSE]
    p_column <- if (is.null(comparison_row)) character() else grep("^Pr\\(", names(comparison_row), value = TRUE)
    statistic_column <- if (is.null(comparison_row)) character() else
      intersect(c("Chisq", "L.Ratio", "F value"), names(comparison_row))
    df_column <- if (is.null(comparison_row)) character() else
      intersect(c("Df", "Chi Df", "NumDF"), names(comparison_row))
    omnibus_rows[[taxon]] <- data.frame(
      Taxon = taxon,
      Model = if (identical(method, "lmer")) "LMM/lmer" else "GLMM/glmmTMB",
      Family = family_label,
      RandomStructure = structure,
      Statistic = if (length(statistic_column)) as.numeric(comparison_row[[statistic_column[[1]]]]) else NA_real_,
      Df = if (length(df_column)) as.numeric(comparison_row[[df_column[[1]]]]) else NA_real_,
      PValue = if (length(p_column)) as.numeric(comparison_row[[p_column[[1]]]]) else NA_real_,
      stringsAsFactors = FALSE
    )

    marginal <- tryCatch(
      emmeans::emmeans(fitted$full, specs = ".DAVA_Group", type = "response"),
      error = function(error) error
    )
    if (!inherits(marginal, "error")) {
      marginal_table <- as.data.frame(summary(marginal, infer = c(TRUE, TRUE)))
      marginal_table$Taxon <- taxon
      names(marginal_table)[names(marginal_table) == ".DAVA_Group"] <- "Group"
      marginal_rows[[taxon]] <- marginal_table[, c("Taxon", setdiff(names(marginal_table), "Taxon")), drop = FALSE]

      contrasts <- tryCatch(
        as.data.frame(summary(emmeans::contrast(marginal, method = "pairwise", adjust = "none"),
          infer = c(TRUE, TRUE))),
        error = function(error) data.frame()
      )
      if (nrow(contrasts)) {
        names(contrasts)[names(contrasts) == "p.value"] <- "PValue"
        contrasts$Taxon <- taxon
        contrasts$AdjustedP <- adjust_p(contrasts$PValue)
        contrasts$Significance <- microbiome_differential_significance(contrasts$AdjustedP)
        pairwise_rows[[taxon]] <- contrasts[, c("Taxon", setdiff(names(contrasts), "Taxon")), drop = FALSE]
      }
    }

    singular <- if (identical(method, "lmer")) lme4::isSingular(fitted$full, tol = 1e-4) else NA
    converged <- if (identical(method, "lmer")) {
      length(fitted$full@optinfo$conv$lme4$messages %||% character()) == 0L
    } else {
      identical(fitted$full$fit$convergence, 0L)
    }
    diagnostic_rows[[taxon]] <- data.frame(
      Taxon = taxon, Status = if (isTRUE(converged)) "success" else "warning",
      Converged = converged, Singular = singular,
      Message = if (isTRUE(singular)) "Singular mixed-model fit." else "",
      stringsAsFactors = FALSE
    )
    models[[taxon]] <- fitted$full
  }

  omnibus <- dplyr::bind_rows(omnibus_rows)
  pairwise <- dplyr::bind_rows(pairwise_rows)
  marginal_means <- dplyr::bind_rows(marginal_rows)
  diagnostics <- dplyr::bind_rows(diagnostic_rows)
  if (nrow(omnibus)) {
    omnibus$AdjustedP <- adjust_p(omnibus$PValue)
    omnibus$Significance <- microbiome_differential_significance(omnibus$AdjustedP)
  }
  if (nrow(pairwise)) {
    pairwise$AcrossTaxaAdjustedP <- adjust_p(pairwise$PValue)
  }
  list(
    omnibus = omnibus,
    pairwise = pairwise,
    marginal_means = marginal_means,
    diagnostics = diagnostics,
    models = models
  )
}

microbiome_abundance_group_tests <- function(table, spec) {
  test_method <- spec$composition_abundance_test %||% "kruskal_dunn"
  if (test_method %in% c("lmer", "glmmTMB")) {
    return(microbiome_mixed_abundance_tests(table, spec))
  }
  p_adjust <- spec$p_adjust_method %||% spec$fdr_method %||% "BH"
  taxa <- unique(as.character(table$Taxon))
  test_one <- function(taxon) {
    value <- table[table$Taxon == taxon & is.finite(table$RelativeAbundance) &
      !is.na(table$.DAVA_Group), , drop = FALSE]
    group <- droplevels(factor(value$.DAVA_Group))
    if (nlevels(group) < 2L || any(table(group) < 2L)) return(NULL)
    if (test_method == "pairwise_t") {
      fit <- stats::pairwise.t.test(value$RelativeAbundance, group, p.adjust.method = p_adjust)
      p <- fit$p.value
      return(data.frame(Taxon = taxon, Contrast = microbiome_pairwise_matrix_names(p),
        Statistic = NA_real_, PValue = as.numeric(p[!is.na(p)]), stringsAsFactors = FALSE))
    }
    if (test_method == "pairwise_wilcoxon") {
      fit <- stats::pairwise.wilcox.test(value$RelativeAbundance, group,
        p.adjust.method = p_adjust, exact = FALSE)
      p <- fit$p.value
      return(data.frame(Taxon = taxon, Contrast = microbiome_pairwise_matrix_names(p),
        Statistic = NA_real_, PValue = as.numeric(p[!is.na(p)]), stringsAsFactors = FALSE))
    }
    if (test_method == "kruskal_dunn") {
      omnibus <- stats::kruskal.test(RelativeAbundance ~ group, data = value)
      if (requireNamespace("FSA", quietly = TRUE)) {
        dunn_adjust <- tolower(p_adjust)
        if (dunn_adjust == "fdr") dunn_adjust <- "bh"
        posthoc <- FSA::dunnTest(value$RelativeAbundance, group, method = dunn_adjust)$res
        return(data.frame(Taxon = taxon, Contrast = posthoc$Comparison,
          Statistic = posthoc$Z, PValue = posthoc$P.adj,
          OmnibusP = omnibus$p.value, stringsAsFactors = FALSE))
      }
      return(data.frame(Taxon = taxon, Contrast = "Kruskal-Wallis",
        Statistic = unname(omnibus$statistic), PValue = omnibus$p.value,
        OmnibusP = omnibus$p.value, stringsAsFactors = FALSE))
    }
    stop("Unsupported abundance test: ", test_method, call. = FALSE)
  }
  result <- Filter(Negate(is.null), lapply(taxa, test_one))
  if (!length(result)) return(data.frame())
  result <- do.call(rbind, result)
  result$AdjustedP <- stats::p.adjust(result$PValue, method = p_adjust)
  result$Significance <- microbiome_differential_significance(result$AdjustedP)
  rownames(result) <- NULL
  result
}

microbiome_pairwise_matrix_names <- function(value) {
  if (is.null(value) || !length(value)) return(character())
  index <- which(!is.na(value), arr.ind = TRUE)
  if (!nrow(index)) return(character())
  paste(rownames(value)[index[, 1]], colnames(value)[index[, 2]], sep = " vs ")
}

microbiome_composition_plots <- function(table, plot_types, rank, spec = list()) {
  if (!length(plot_types)) plot_types <- "stacked_bar"
  top_taxa <- names(sort(tapply(table$RelativeAbundance, table$Taxon, mean,
    na.rm = TRUE), decreasing = TRUE))
  others_label <- spec$abundance_others_label %||% "Others"
  if (others_label %in% top_taxa) top_taxa <- c(setdiff(top_taxa, others_label), others_label)
  display <- table[table$Taxon %in% top_taxa, , drop = FALSE]
  display$Taxon <- factor(display$Taxon, levels = top_taxa)
  summary_function <- if (identical(spec$abundance_group_summary %||% "mean", "median")) {
    stats::median
  } else {
    mean
  }
  group_summary <- stats::aggregate(RelativeAbundance ~ .DAVA_Group + Taxon,
    display, summary_function)
  grouped_values <- split(display,
    list(display$.DAVA_Group, display$Taxon), drop = TRUE)
  grouped_intervals <- lapply(grouped_values, function(grouped_table) {
    value <- grouped_table$RelativeAbundance
    value <- value[is.finite(value)]
    keys <- data.frame(
      .DAVA_Group = as.character(grouped_table$.DAVA_Group[[1]]),
      Taxon = as.character(grouped_table$Taxon[[1]]), stringsAsFactors = FALSE)
    if (!length(value)) {
      return(cbind(keys, Centre = NA_real_, Lower = NA_real_, Upper = NA_real_))
    }
    if (identical(spec$abundance_group_summary %||% "mean", "median")) {
      interval <- stats::quantile(value, c(0.25, 0.75), na.rm = TRUE, names = FALSE)
      return(cbind(keys, Centre = stats::median(value),
        Lower = interval[[1]], Upper = interval[[2]]))
    }
    centre <- mean(value)
    standard_error <- if (length(value) > 1L) stats::sd(value) / sqrt(length(value)) else 0
    cbind(keys, Centre = centre, Lower = max(0, centre - standard_error),
      Upper = centre + standard_error)
  })
  grouped_intervals <- do.call(rbind, grouped_intervals)
  rownames(grouped_intervals) <- NULL
  grouped_intervals$Taxon <- factor(grouped_intervals$Taxon, levels = top_taxa)
  grouped_intervals$.DAVA_Group <- factor(grouped_intervals$.DAVA_Group,
    levels = levels(factor(display$.DAVA_Group)))
  plots <- list()
  if ("stacked_bar" %in% plot_types) {
    plots$stacked_bar <- ggplot2::ggplot(group_summary,
      ggplot2::aes(.DAVA_Group, RelativeAbundance, fill = Taxon)) +
      ggplot2::geom_col(position = "fill", width = 0.78) +
      ggplot2::scale_y_continuous(labels = scales::percent) +
      ggplot2::labs(title = paste(rank, "composition"), x = "Group",
        y = paste(if (identical(spec$abundance_group_summary %||% "mean", "median"))
          "Median" else "Mean", "relative abundance"), fill = rank) +
      ggplot2::theme_classic(base_size = 12)
  }
  if ("grouped_bar" %in% plot_types) {
    dodge <- ggplot2::position_dodge(width = 0.78)
    plots$grouped_bar <- ggplot2::ggplot(grouped_intervals,
      ggplot2::aes(Taxon, Centre * 100, fill = .DAVA_Group)) +
      ggplot2::geom_col(position = dodge, width = 0.72) +
      ggplot2::geom_errorbar(ggplot2::aes(ymin = Lower * 100, ymax = Upper * 100),
        position = dodge, width = 0.22, linewidth = 0.45) +
      ggplot2::labs(title = paste(rank, "abundance by group"), x = NULL,
        y = paste(if (identical(spec$abundance_group_summary %||% "mean", "median"))
          "Median (IQR)" else "Mean +/- SE", "relative abundance (%)"), fill = "Group") +
      ggplot2::theme_classic(base_size = 12) +
      ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
  }
  if ("composition_heatmap" %in% plot_types) {
    heatmap_data <- display
    heatmap_data <- heatmap_data[order(heatmap_data$.DAVA_Group,
      match(heatmap_data$SampleID, unique(display$SampleID))), , drop = FALSE]
    heatmap_data$SampleID <- factor(heatmap_data$SampleID,
      levels = unique(heatmap_data$SampleID))
    heatmap_data$Taxon <- factor(heatmap_data$Taxon, levels = rev(top_taxa))
    heatmap_floor <- 0.01
    heatmap_data$AbundancePercent <- pmax(heatmap_data$RelativeAbundance * 100,
      heatmap_floor)
    heatmap_limits <- range(heatmap_data$AbundancePercent, finite = TRUE)
    heatmap_limits[[1]] <- max(0.01, heatmap_limits[[1]])
    if (heatmap_limits[[2]] <= heatmap_limits[[1]]) heatmap_limits[[2]] <- heatmap_limits[[1]] * 10
    heatmap_breaks <- 10 ^ seq(floor(log10(heatmap_limits[[1]])),
      ceiling(log10(heatmap_limits[[2]])))
    plots$composition_heatmap <- ggplot2::ggplot(heatmap_data,
      ggplot2::aes(SampleID, Taxon, fill = AbundancePercent)) +
      ggplot2::geom_tile() +
      ggplot2::facet_grid(cols = ggplot2::vars(.DAVA_Group), scales = "free_x",
        space = "free_x") +
      ggplot2::scale_fill_gradientn(
        colours = c("#313695", "#74ADD1", "#FFFFBF", "#FDAE61", "#A50026"),
        trans = "log10", limits = heatmap_limits, breaks = heatmap_breaks,
        oob = scales::squish) +
      ggplot2::labs(title = paste(rank, "composition heatmap"), x = "Sample",
        y = NULL, fill = "% Relative\nabundance") +
      ggplot2::theme_minimal(base_size = 11) +
      ggplot2::theme(panel.grid = ggplot2::element_blank(),
        axis.text.x = ggplot2::element_blank(), axis.ticks.x = ggplot2::element_blank(),
        strip.text = ggplot2::element_text(size = 11),
        strip.background = ggplot2::element_rect(fill = "#E8E8E8", colour = NA),
        panel.spacing.x = grid::unit(2, "mm"))
  }
  if ("abundance_boxplot" %in% plot_types) {
    box_dodge <- ggplot2::position_dodge2(width = 0.8, preserve = "single")
    plots$abundance_boxplot <- ggplot2::ggplot(display,
      ggplot2::aes(Taxon, RelativeAbundance * 100, fill = .DAVA_Group,
        colour = .DAVA_Group)) +
      ggplot2::geom_boxplot(position = box_dodge, width = 0.68,
        outlier.shape = NA, alpha = 0.92, linewidth = 0.45) +
      ggplot2::geom_point(position = ggplot2::position_jitterdodge(
        jitter.width = 0.12, dodge.width = 0.8), size = 1.5, alpha = 0.78) +
      ggplot2::labs(title = paste(rank, "relative abundance distribution"),
        x = NULL, y = "Relative abundance (%)", fill = "Group", colour = "Group") +
      ggplot2::theme_minimal(base_size = 12) +
      ggplot2::theme(panel.grid.minor = ggplot2::element_blank(),
        axis.text.x = ggplot2::element_text(angle = 45, hjust = 1),
        legend.position = "right")
  }
  if ("bubble" %in% plot_types) {
    plots$bubble <- ggplot2::ggplot(group_summary,
      ggplot2::aes(.DAVA_Group, Taxon, size = RelativeAbundance,
        colour = RelativeAbundance)) +
      ggplot2::geom_point(alpha = 0.82) +
      ggplot2::scale_colour_gradient(low = "#9CD7D3", high = "#B33A3A") +
      ggplot2::labs(title = paste(rank, "composition bubble plot"), x = NULL,
        y = NULL, size = "Relative\nabundance", colour = "Relative\nabundance") +
      ggplot2::theme_classic(base_size = 12)
  }
  if ("sankey" %in% plot_types && requireNamespace("ggalluvial", quietly = TRUE)) {
    plots$sankey <- ggplot2::ggplot(group_summary,
      ggplot2::aes(axis1 = .DAVA_Group, axis2 = Taxon, y = RelativeAbundance)) +
      ggalluvial::geom_alluvium(ggplot2::aes(fill = Taxon), width = 0.16,
        alpha = 0.75) +
      ggalluvial::geom_stratum(width = 0.16, fill = "#F4F5F5", colour = "#5F676C") +
      ggalluvial::stat_stratum(geom = "text",
        ggplot2::aes(label = ggplot2::after_stat(stratum)), size = 3) +
      ggplot2::scale_x_discrete(limits = c("Group", rank), expand = c(0.08, 0.08)) +
      ggplot2::labs(title = paste("Group-to-", rank, "composition", sep = ""),
        y = "Mean relative abundance", x = NULL) +
      ggplot2::theme_classic(base_size = 12) +
      ggplot2::theme(legend.position = "none")
  }
  if ("sunburst" %in% plot_types) {
    plots$sunburst <- ggplot2::ggplot(group_summary,
      ggplot2::aes(x = .DAVA_Group, y = RelativeAbundance, fill = Taxon)) +
      ggplot2::geom_col(width = 1, colour = "white", linewidth = 0.15) +
      ggplot2::coord_polar(theta = "y") +
      ggplot2::labs(title = paste(rank, "sunburst composition"), x = NULL,
        y = NULL, fill = rank) +
      ggplot2::theme_void(base_size = 12)
  }
  if ("ternary" %in% plot_types && length(unique(group_summary$.DAVA_Group)) == 3L) {
    wide <- reshape(group_summary, idvar = "Taxon", timevar = ".DAVA_Group",
      direction = "wide")
    values <- as.matrix(wide[, -1, drop = FALSE])
    values <- values / rowSums(values)
    ternary <- data.frame(Taxon = wide$Taxon,
      X = values[, 2] + 0.5 * values[, 3],
      Y = sqrt(3) / 2 * values[, 3], stringsAsFactors = FALSE)
    plots$ternary <- ggplot2::ggplot(ternary, ggplot2::aes(X, Y, label = Taxon,
      colour = Taxon)) +
      ggplot2::geom_polygon(data = data.frame(X = c(0, 1, 0.5), Y = c(0, 0, sqrt(3) / 2)),
        ggplot2::aes(X, Y), inherit.aes = FALSE, fill = NA, colour = "#31373B") +
      ggplot2::geom_point(size = 3) +
      ggplot2::geom_text(nudge_y = 0.025, size = 3, check_overlap = TRUE) +
      ggplot2::coord_equal() +
      ggplot2::labs(title = paste(rank, "ternary composition"), x = NULL, y = NULL) +
      ggplot2::theme_void(base_size = 12) +
      ggplot2::theme(legend.position = "none")
  }
  Filter(Negate(is.null), plots)
}

microbiome_indicator_plots <- function(table, relative, bundle, spec) {
  plot_types <- spec$plot_types %||% "indicator_bar"
  statistic_name <- intersect(c("stat", "s", "index", "A"), names(table))[1]
  if (is.na(statistic_name) || !nrow(table)) return(list())
  table$IndVal <- suppressWarnings(as.numeric(table[[statistic_name]]))
  table$AdjustedP <- suppressWarnings(as.numeric(table$adjusted_p %||% table$p.value))
  table$IndicatorGroup <- apply(table[, grep("^s\\.", names(table)), drop = FALSE], 1,
    function(value) paste(names(value)[as.numeric(value) > 0], collapse = " + "))
  minimum_indval <- as.numeric(spec$indicator_min_indval %||% 0.7)
  alpha <- as.numeric(spec$indicator_alpha %||% 0.05)
  maximum_taxa <- as.integer(spec$indicator_max_taxa %||% 30L)
  selected <- table[is.finite(table$IndVal) & table$IndVal >= minimum_indval &
    is.finite(table$AdjustedP) & table$AdjustedP < alpha, , drop = FALSE]
  if (!nrow(selected)) selected <- utils::head(table[order(table$IndVal, decreasing = TRUE), , drop = FALSE], 20L)
  selected <- utils::head(selected, maximum_taxa)
  selected$Feature <- factor(selected$Feature, levels = rev(unique(selected$Feature)))
  plots <- list()
  if ("indicator_bar" %in% plot_types) {
    plots$indicator_bar <- ggplot2::ggplot(selected,
      ggplot2::aes(Feature, IndVal, fill = IndicatorGroup)) +
      ggplot2::geom_col(width = 0.72) + ggplot2::coord_flip() +
      ggplot2::labs(title = "Indicator taxa", x = NULL, y = "Indicator value (IndVal)",
        fill = "Indicator group") + ggplot2::theme_classic(base_size = 12)
  }
  if ("indicator_bubble" %in% plot_types) {
    plots$indicator_bubble <- ggplot2::ggplot(selected,
      ggplot2::aes(IndVal, Feature, size = -log10(pmax(AdjustedP, .Machine$double.xmin)),
        colour = IndicatorGroup)) +
      ggplot2::geom_point(alpha = 0.82) +
      ggplot2::labs(title = "Indicator strength and significance", x = "Indicator value (IndVal)",
        y = NULL, size = "-log10(FDR)", colour = "Indicator group") +
      ggplot2::theme_classic(base_size = 12)
  }
  feature_names <- as.character(selected$Feature)
  feature_index <- match(feature_names, colnames(relative))
  keep <- is.finite(feature_index)
  if (any(keep)) {
    abundance <- data.frame(SampleID = rep(rownames(relative), sum(keep)),
      Feature = rep(feature_names[keep], each = nrow(relative)),
      Abundance = as.vector(relative[, feature_index[keep], drop = FALSE]),
      stringsAsFactors = FALSE)
    grouping <- microbiome_composition_group_data(bundle, spec)
    abundance$Group <- rep(as.character(grouping$group), sum(keep))
    abundance$Feature <- factor(abundance$Feature, levels = rev(feature_names[keep]))
    if ("indicator_boxplot" %in% plot_types) {
      plots$indicator_boxplot <- ggplot2::ggplot(abundance,
        ggplot2::aes(Group, Abundance, colour = Group)) +
        ggplot2::geom_boxplot(outlier.shape = NA) +
        ggplot2::geom_jitter(width = 0.15, alpha = 0.55, size = 1.2) +
        ggplot2::facet_wrap(~Feature, scales = "free_y") +
        ggplot2::labs(title = "Indicator-taxon abundance", x = NULL,
          y = "Relative abundance") + ggplot2::theme_classic(base_size = 11) +
        ggplot2::theme(legend.position = "none")
    }
    if ("indicator_heatmap" %in% plot_types) {
      transform <- spec$indicator_heatmap_transform %||% "clr"
      abundance$CLR <- if (identical(transform, "clr")) {
        log(abundance$Abundance + 0.5 / ncol(relative))
      } else {
        abundance$Abundance
      }
      plots$indicator_heatmap <- ggplot2::ggplot(abundance,
        ggplot2::aes(SampleID, Feature, fill = CLR)) +
        ggplot2::geom_tile() +
        ggplot2::scale_fill_gradient2(low = "#2C6E9B", mid = "#F5F5F2", high = "#B33A3A") +
        ggplot2::labs(title = "Indicator-taxon abundance heatmap", x = "Sample", y = NULL,
          fill = if (identical(transform, "clr")) "CLR" else "Relative\nabundance") +
        ggplot2::theme_classic(base_size = 10) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90, hjust = 1))
    }
  }
  if ("indicator_network" %in% plot_types) {
    network <- selected[, c("IndicatorGroup", "Feature", "IndVal"), drop = FALSE]
    plots$indicator_network <- ggplot2::ggplot(network,
      ggplot2::aes(x = 1, xend = 2, y = IndicatorGroup, yend = Feature,
        linewidth = IndVal, colour = IndicatorGroup)) +
      ggplot2::geom_segment(alpha = 0.65) +
      ggplot2::geom_point(ggplot2::aes(x = 1, y = IndicatorGroup), size = 4) +
      ggplot2::geom_point(ggplot2::aes(x = 2, y = Feature), size = 3) +
      ggplot2::geom_text(ggplot2::aes(x = 0.95, y = IndicatorGroup,
        label = IndicatorGroup), hjust = 1) +
      ggplot2::geom_text(ggplot2::aes(x = 2.05, y = Feature,
        label = Feature), hjust = 0) +
      ggplot2::coord_cartesian(xlim = c(0.5, 2.5), clip = "off") +
      ggplot2::labs(title = "Indicator taxa-group network") +
      ggplot2::theme_void(base_size = 11) +
      ggplot2::theme(legend.position = "none")
  }
  if ("indicator_tree" %in% plot_types) {
    selected$Angle <- seq(0, 2 * pi, length.out = nrow(selected) + 1L)[-1L]
    plots$indicator_tree <- ggplot2::ggplot(selected,
      ggplot2::aes(Angle, IndVal, colour = IndicatorGroup, label = Feature)) +
      ggplot2::geom_segment(ggplot2::aes(xend = Angle, y = 0, yend = IndVal),
        linewidth = 0.6) +
      ggplot2::geom_point(size = 2.8) +
      ggplot2::geom_text(nudge_y = 0.08, size = 3, check_overlap = TRUE) +
      ggplot2::coord_polar() +
      ggplot2::labs(title = "Circular indicator-taxa tree", x = NULL, y = NULL,
        colour = "Indicator group") + ggplot2::theme_void(base_size = 11)
  }
  if ("indicator_set" %in% plot_types) {
    counts <- as.data.frame(table(selected$IndicatorGroup), stringsAsFactors = FALSE)
    names(counts) <- c("IndicatorGroup", "Taxa")
    plots$indicator_set <- ggplot2::ggplot(counts,
      ggplot2::aes(reorder(IndicatorGroup, Taxa), Taxa, fill = IndicatorGroup)) +
      ggplot2::geom_col(width = 0.72) + ggplot2::coord_flip() +
      ggplot2::labs(title = "Indicator-taxa sets", x = NULL, y = "Number of indicator taxa") +
      ggplot2::theme_classic(base_size = 12) + ggplot2::theme(legend.position = "none")
  }
  Filter(Negate(is.null), plots)
}

microbiome_set_pairwise_fisher <- function(sets, universe_features) {
  universe_features <- unique(as.character(universe_features))
  sets <- lapply(sets, function(set) intersect(unique(as.character(set)), universe_features))
  if (length(universe_features) == 0L || length(sets) < 2L) {
    return(data.frame(
      Test = character(), Group1 = character(), Group2 = character(),
      Overlap = integer(), Group1Only = integer(), Group2Only = integer(),
      Neither = integer(), Statistic = numeric(), PValue = numeric(),
      stringsAsFactors = FALSE
    ))
  }
  group_pairs <- utils::combn(names(sets), 2L, simplify = FALSE)

  do.call(rbind, lapply(group_pairs, function(pair) {
    set1 <- sets[[pair[[1L]]]]
    set2 <- sets[[pair[[2L]]]]
    counts <- c(
      overlap = length(intersect(set1, set2)),
      group1_only = length(setdiff(set1, set2)),
      group2_only = length(setdiff(set2, set1)),
      neither = length(setdiff(universe_features, union(set1, set2)))
    )
    if (any(!is.finite(counts)) || any(counts < 0)) {
      stop("Invalid set-overlap contingency table.", call. = FALSE)
    }
    fisher <- stats::fisher.test(
      matrix(as.integer(counts), nrow = 2L, byrow = TRUE),
      alternative = "greater"
    )
    odds_ratio <- unname(fisher$estimate)
    if (!length(odds_ratio) || !is.finite(odds_ratio)) odds_ratio <- NA_real_
    data.frame(
      Test = paste(pair, collapse = " vs "),
      Group1 = pair[[1L]], Group2 = pair[[2L]],
      Overlap = as.integer(counts[["overlap"]]),
      Group1Only = as.integer(counts[["group1_only"]]),
      Group2Only = as.integer(counts[["group2_only"]]),
      Neither = as.integer(counts[["neither"]]),
      Statistic = odds_ratio, PValue = fisher$p.value,
      stringsAsFactors = FALSE
    )
  }))
}

microbiome_set_analysis <- function(relative, taxa, bundle, spec) {
  grouping <- microbiome_composition_group_data(bundle, spec)
  group <- grouping$group
  presence_threshold <- as.numeric(spec$set_presence_threshold_percent %||% 0) / 100
  core_prevalence <- as.numeric(spec$set_core_prevalence %||% 0.5)
  presence <- relative > presence_threshold
  group_levels <- levels(group)
  sets <- stats::setNames(lapply(group_levels, function(level) {
    colnames(presence)[colSums(presence[group == level, , drop = FALSE]) > 0]
  }), group_levels)
  membership <- do.call(rbind, lapply(names(sets), function(name) {
    data.frame(Group = name, Feature = sets[[name]], stringsAsFactors = FALSE)
  }))
  membership$Taxon <- taxa[match(membership$Feature, colnames(relative))]
  patterns <- apply(vapply(sets, function(set) colnames(relative) %in% set, logical(ncol(relative))),
    1, function(value) paste(group_levels[value], collapse = " & "))
  intersections <- as.data.frame(table(patterns), stringsAsFactors = FALSE)
  names(intersections) <- c("Intersection", "FeatureCount")
  intersections <- intersections[nzchar(intersections$Intersection), , drop = FALSE]
  test_method <- spec$set_test %||% "jaccard_permutation"
  if (test_method == "jaccard_permutation") {
    permutations <- as.integer(spec$set_permutations %||% spec$permutations %||% 999L)
    distance <- vegan::vegdist(presence * 1, method = "jaccard", binary = TRUE)
    permanova <- vegan::adonis2(distance ~ group, permutations = permutations)
    tests <- data.frame(Test = "Jaccard PERMANOVA", Statistic = permanova$F[1],
      PValue = permanova$`Pr(>F)`[1], stringsAsFactors = FALSE)
  } else if (test_method == "fisher_hypergeometric") {
    tests <- microbiome_set_pairwise_fisher(sets, colnames(presence))
  } else {
    observed <- vapply(group_levels, function(level) {
      mean(colMeans(presence[group == level, , drop = FALSE]) >= core_prevalence)
    }, numeric(1))
    permutations <- as.integer(spec$set_permutations %||% spec$permutations %||% 999L)
    null <- replicate(permutations, {
      shuffled <- sample(group)
      vapply(group_levels, function(level) {
        mean(colMeans(presence[shuffled == level, , drop = FALSE]) >= core_prevalence)
      }, numeric(1))
    })
    p <- vapply(seq_along(observed), function(index) {
      (1 + sum(null[index, ] >= observed[index])) / (permutations + 1)
    }, numeric(1))
    tests <- data.frame(Test = paste(group_levels, "core-microbiome permutation"),
      Statistic = observed, PValue = p, stringsAsFactors = FALSE)
  }
  tests$AdjustedP <- stats::p.adjust(tests$PValue, method = spec$fdr_method %||% "BH")
  list(sets = sets, membership = membership, intersections = intersections,
    tests = tests, presence = presence, group = group)
}

microbiome_set_plots <- function(set_result, relative, bundle, spec) {
  plot_types <- spec$plot_types %||% "upset"
  membership <- set_result$membership
  plots <- list()
  if ("venn" %in% plot_types && length(set_result$sets) <= 3L &&
      requireNamespace("ggVennDiagram", quietly = TRUE)) {
    plots$venn <- ggVennDiagram::ggVennDiagram(set_result$sets,
      label_alpha = 0, edge_size = 0.8) +
      ggplot2::scale_fill_gradient(low = "#F4F5F5", high = "#167A6A") +
      ggplot2::labs(title = "Shared and unique taxa")
  }
  if ("upset" %in% plot_types) {
    plots$upset <- ggplot2::ggplot(set_result$intersections,
      ggplot2::aes(reorder(Intersection, FeatureCount), FeatureCount,
        fill = FeatureCount)) +
      ggplot2::geom_col(width = 0.72, colour = "#30363B", linewidth = 0.2) +
      ggplot2::geom_text(ggplot2::aes(label = FeatureCount), hjust = -0.2) +
      ggplot2::coord_flip(clip = "off") +
      ggplot2::scale_fill_gradient(low = "#9CD7D3", high = "#B33A3A", guide = "none") +
      ggplot2::labs(title = "Taxon-set intersections", x = "Set intersection",
        y = "Number of taxa") + ggplot2::theme_classic(base_size = 12) +
      ggplot2::theme(plot.margin = ggplot2::margin(8, 24, 8, 8))
  }
  group <- set_result$group
  abundance <- data.frame(Group = rep(as.character(group), ncol(relative)),
    Feature = rep(colnames(relative), each = nrow(relative)),
    RelativeAbundance = as.vector(relative), stringsAsFactors = FALSE)
  shared_features <- names(which(table(set_result$membership$Feature) > 1L))
  abundance$SetType <- ifelse(abundance$Feature %in% shared_features, "Shared", "Unique")
  if ("subset_boxplot" %in% plot_types) {
    plots$subset_boxplot <- ggplot2::ggplot(abundance,
      ggplot2::aes(SetType, RelativeAbundance, fill = SetType)) +
      ggplot2::geom_boxplot(outlier.shape = NA) +
      ggplot2::facet_wrap(~Group, scales = "free_y") +
      ggplot2::labs(title = "Abundance of shared and unique taxa", x = NULL,
        y = "Relative abundance") + ggplot2::theme_classic(base_size = 12) +
      ggplot2::theme(legend.position = "none")
  }
  if ("core_bar" %in% plot_types) {
    core <- data.frame(Group = levels(group), CoreTaxa = vapply(levels(group), function(level) {
      sum(colMeans(set_result$presence[group == level, , drop = FALSE]) >=
        as.numeric(spec$set_core_prevalence %||% 0.5))
    }, numeric(1)))
    plots$core_bar <- ggplot2::ggplot(core, ggplot2::aes(Group, CoreTaxa, fill = Group)) +
      ggplot2::geom_col(width = 0.72) +
      ggplot2::labs(title = "Core taxa by group", x = NULL, y = "Number of core taxa") +
      ggplot2::theme_classic(base_size = 12) + ggplot2::theme(legend.position = "none")
  }
  if ("set_taxonomy" %in% plot_types && "Taxon" %in% names(membership)) {
    taxonomy <- as.data.frame(table(membership$Group, membership$Taxon), stringsAsFactors = FALSE)
    names(taxonomy) <- c("Group", "Taxon", "FeatureCount")
    plots$set_taxonomy <- ggplot2::ggplot(taxonomy,
      ggplot2::aes(Group, FeatureCount, fill = Taxon)) +
      ggplot2::geom_col(position = "fill") +
      ggplot2::scale_y_continuous(labels = scales::percent) +
      ggplot2::labs(title = "Taxonomic composition of feature sets", x = NULL,
        y = "Taxon proportion", fill = "Taxon") + ggplot2::theme_classic(base_size = 12)
  }
  if ("unique_ratio" %in% plot_types) {
    ratio <- data.frame(Group = levels(group), UniqueRatio = vapply(levels(group), function(level) {
      sum(set_result$intersections$FeatureCount[set_result$intersections$Intersection == level]) /
        max(1, length(set_result$sets[[level]]))
    }, numeric(1)))
    plots$unique_ratio <- ggplot2::ggplot(ratio,
      ggplot2::aes(Group, UniqueRatio, fill = Group)) +
      ggplot2::geom_col(width = 0.72) +
      ggplot2::scale_y_continuous(labels = scales::percent) +
      ggplot2::labs(title = "Proportion of group-unique taxa", x = NULL,
        y = "Unique taxa (%)") + ggplot2::theme_classic(base_size = 12) +
      ggplot2::theme(legend.position = "none")
  }
  Filter(Negate(is.null), plots)
}

microbiome_run_composition <- function(method_id, bundle, spec = list()) {
  started <- proc.time()[["elapsed"]]
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  counts <- microbiome_numeric_matrix(bundle$counts)
  if (!nrow(bundle$taxonomy)) stop("This method requires a classification annotation table that matches the feature.", call. = FALSE)
  rank <- spec$taxonomic_rank %||% "Phylum"
  if (identical(rank, "feature")) taxa <- colnames(counts) else {
    if (!rank %in% names(bundle$taxonomy)) stop("Hierarchy does not exist in category annotation:", rank, call. = FALSE)
    taxonomy_ids <- if ("Feature" %in% names(bundle$taxonomy)) {
      as.character(bundle$taxonomy$Feature)
    } else {
      rownames(bundle$taxonomy)
    }
    taxa <- as.character(bundle$taxonomy[[rank]][match(colnames(counts), taxonomy_ids)])
    taxa[is.na(taxa) | !nzchar(trimws(taxa))] <- paste0("Unclassified_", rank)
  }
  relative <- counts / rowSums(counts)
  if (method_id == "taxonomic_composition") {
    microeco_object <- microbiome_bundle_to_microeco(bundle)
    microeco_object[["cal_abund"]]()
    aggregation <- microbiome_aggregate_taxonomic_abundance(counts, bundle$taxonomy, rank, spec)
    table <- aggregation$table
    attached <- microbiome_composition_attach_metadata(table, bundle, spec)
    table <- attached$table
    test_result <- microbiome_abundance_group_tests(table, spec)
    mixed_result <- is.list(test_result) && all(c("omnibus", "pairwise", "models") %in% names(test_result))
    tests <- if (mixed_result) test_result$pairwise else test_result
    tables <- list(
      composition = table,
      taxonomic_mapping = aggregation$mapping,
      taxonomic_aggregation_summary = aggregation$summary,
      abundance_tests = tests
    )
    if (mixed_result) {
      tables$abundance_omnibus_tests <- test_result$omnibus
      tables$abundance_marginal_means <- test_result$marginal_means
      tables$abundance_model_diagnostics <- test_result$diagnostics
      abundance_models <- test_result$models
    }
    plots <- microbiome_composition_plots(table, spec$plot_types, rank, spec)
    spec$abundance_merge_threshold <- aggregation$threshold
    spec$abundance_max_taxa <- aggregation$maximum_taxa
    spec$abundance_others_label <- aggregation$others_label
  } else if (method_id == "core_microbiome") {
    abundance <- as.numeric(spec$core_abundance %||% 0.001)
    prevalence <- as.numeric(spec$core_prevalence %||% 0.5)
    if (abundance < 0 || prevalence < 0 || prevalence > 1) stop("The core microbial threshold is invalid.", call. = FALSE)
    table <- data.frame(Feature = colnames(relative), Taxon = taxa, MeanRelativeAbundance = colMeans(relative), Prevalence = colMeans(relative >= abundance), stringsAsFactors = FALSE)
    table$Core <- table$Prevalence >= prevalence
    tables <- list(core_microbiome = table)
    plots <- list(core_abundance_prevalence = microbiome_core_abundance_plot(table))
    spec$core_abundance <- abundance
    spec$core_prevalence <- prevalence
  } else if (method_id == "indicator_taxa") {
    if (!requireNamespace("indicspecies", quietly = TRUE) || !requireNamespace("permute", quietly = TRUE)) stop("Missing indicspecies or permute packages.", call. = FALSE)
    group_name <- spec$group %||% "Treatment"
    if (!nrow(bundle$metadata) || !group_name %in% names(bundle$metadata)) stop("indicates that a valid grouping variable is required for cluster analysis.", call. = FALSE)
    group <- droplevels(factor(bundle$metadata[[group_name]]))
    permutations <- as.integer(spec$permutations %||% 999L)
    fit <- indicspecies::multipatt(relative, group, func = "IndVal.g", control = permute::how(nperm = permutations))
    sign <- as.data.frame(fit$sign, check.names = FALSE)
    sign$Feature <- rownames(sign)
    rownames(sign) <- NULL
    sign$adjusted_p <- stats::p.adjust(sign$p.value, method = spec$fdr_method %||% "BH")
    table <- microbiome_attach_taxonomy(sign, bundle)
    tables <- list(indicator_taxa = table)
    plots <- microbiome_indicator_plots(table, relative, bundle, spec)
    spec$group <- group_name
    spec$permutations <- permutations
  } else if (method_id == "venn_upset") {
    set_result <- microbiome_set_analysis(relative, taxa, bundle, spec)
    tables <- list(
      set_membership = set_result$membership,
      set_intersections = set_result$intersections,
      set_tests = set_result$tests
    )
    plots <- microbiome_set_plots(set_result, relative, bundle, spec)
    fit <- set_result
  } else stop("Composition adapter does not support method:", method_id, call. = FALSE)
  new_microbiome_result(method_id, marker_type = bundle$marker_type, data_version = bundle$data_version,
    input_summary = microbiome_data_summary(bundle, aligned$orientation), analysis_spec = spec, actual_parameters = spec,
    execution_time = proc.time()[["elapsed"]] - started,
    package_versions = microbiome_package_versions(switch(method_id,
      taxonomic_composition = c("microeco",
        if ((spec$composition_abundance_test %||% "") == "lmer") c("lme4", "emmeans") else
          if ((spec$composition_abundance_test %||% "") == "glmmTMB") c("glmmTMB", "emmeans") else character()),
      indicator_taxa = c("indicspecies", "permute"),
      venn_upset = "vegan",
      character())),
    model_objects = if (exists("microeco_object")) {
      c(list(microeco = microeco_object), if (exists("abundance_models")) list(abundance_models = abundance_models) else list())
    } else if (exists("fit")) list(fit = fit) else list(), tables = tables, plots = plots,
    available_outputs = names(tables), available_plots = names(plots), generated_code = microbiome_analysis_code(method_id, spec),
    registration_manifest = microbiome_registration_manifest(bundle, method_id, names(tables)))
}
