microbiome_run_preprocess <- function(method_id, bundle, spec = list()) {
  started <- proc.time()[["elapsed"]]
  aligned <- microbiome_align_bundle(bundle)
  bundle <- aligned$bundle
  input_summary <- microbiome_data_summary(bundle, aligned$orientation)
  seed <- as.integer(spec$seed %||% 2026L)
  if (method_id == "data_integrity") {
    tables <- list(data_summary = input_summary)
    output_bundle <- bundle
  } else if (method_id == "filter_prevalence") {
    minimum_total <- as.numeric(spec$minimum_total %||% 10)
    minimum_prevalence <- as.numeric(spec$minimum_prevalence %||% 0.1)
    if (!is.finite(minimum_total) || minimum_total < 0) stop("Minimum total abundance must be non-negative.", call. = FALSE)
    if (!is.finite(minimum_prevalence) || minimum_prevalence < 0 || minimum_prevalence > 1) stop("Minimum prevalence must be between 0 and 1.", call. = FALSE)
    counts <- microbiome_numeric_matrix(bundle$counts)
    feature_summary <- data.frame(Feature = colnames(counts), total = colSums(counts), prevalence = colMeans(counts > 0), stringsAsFactors = FALSE)
    keep <- feature_summary$total >= minimum_total & feature_summary$prevalence >= minimum_prevalence
    if (!any(keep)) stop("The filter removed all features, please lower the threshold.", call. = FALSE)
    feature_summary$kept <- keep
    output_bundle <- bundle
    output_bundle$counts <- as.data.frame(counts[, keep, drop = FALSE], check.names = FALSE)
    output_bundle$taxonomy <- if (nrow(bundle$taxonomy)) bundle$taxonomy[keep, , drop = FALSE] else bundle$taxonomy
    output_bundle$feature_ids <- colnames(output_bundle$counts)
    output_bundle$data_version <- paste0(bundle$data_version, "_filtered")
    output_bundle$provenance$filter <- list(minimum_total = minimum_total, minimum_prevalence = minimum_prevalence)
    tables <- list(filter_summary = feature_summary, removed_features = feature_summary[!keep, , drop = FALSE])
  } else if (method_id == "clr_transform") {
    transform_method <- spec$transform %||% "clr"
    if (!transform_method %in% c("relative", "hellinger", "clr", "rclr", "presence_absence")) stop("Unsupported data conversion.", call. = FALSE)
    pseudocount <- spec$pseudocount %||% if (transform_method == "clr") 0.5 else NULL
    output_bundle <- microbiome_transform_bundle(bundle, transform_method, pseudocount)
    transformed <- microbiome_numeric_matrix(output_bundle$counts)
    tables <- list(transformed_abundance = data.frame(SampleID = rownames(transformed), transformed, check.names = FALSE))
    spec$transform <- transform_method
    spec$pseudocount <- pseudocount
  } else {
    stop("Preprocessing adapter does not support method:", method_id, call. = FALSE)
  }
  new_microbiome_result(
    method_id, marker_type = bundle$marker_type, data_version = bundle$data_version, input_summary = input_summary,
    analysis_spec = spec, actual_parameters = spec, random_seed = seed, execution_time = proc.time()[["elapsed"]] - started,
    model_objects = list(output_bundle = output_bundle), tables = tables, available_outputs = names(tables),
    generated_code = microbiome_preprocess_code(method_id, spec),
    registration_manifest = microbiome_registration_manifest(bundle, method_id, names(tables))
  )
}
