microbiome_framework_version <- function() "0.1.0"

microbiome_configured_root <- getOption(
  "dava.project_root", Sys.getenv("DAVA_PROJECT_ROOT", unset = ""))
microbiome_root_candidates <- unique(c(
  microbiome_configured_root,
  ".", "..", file.path("..", ".."), file.path("..", "..", "..")))
microbiome_root_candidates <- microbiome_root_candidates[
  !is.na(microbiome_root_candidates) & nzchar(microbiome_root_candidates)]
microbiome_root_candidates <- microbiome_root_candidates[file.exists(file.path(microbiome_root_candidates, "app.R"))]
if (!length(microbiome_root_candidates)) stop("Unable to locate the DAVA project root directory.", call. = FALSE)
microbiome_project_root <- normalizePath(microbiome_root_candidates[1], winslash = "/", mustWork = TRUE)

microbiome_source_utf8 <- function(path) {
  bytes <- readBin(path, what = "raw", n = file.info(path)[["size"]])
  code <- rawToChar(bytes)
  Encoding(code) <- "UTF-8"
  code <- sub("^\ufeff", "", code)
  code <- gsub("\r\n?", "\n", code)
  expressions <- suppressWarnings(parse(text = code, encoding = "UTF-8", keep.source = FALSE))
  eval(expressions, envir = .GlobalEnv)
}

microbiome_support_files <- c(
  dava_local_demo_read = "R/demo_data/local_demo_datasets.R",
  dava_code_document = "R/module_support/code_document.R",
  dava_module_code_panel_ui = "R/module_support/module_code_support.R"
)
for (microbiome_support_name in names(microbiome_support_files)) {
  if (!exists(microbiome_support_name, mode = "function", inherits = TRUE)) {
    microbiome_source_utf8(file.path(
      microbiome_project_root, microbiome_support_files[[microbiome_support_name]]
    ))
  }
}

microbiome_framework_files <- c(
  "core/registries.R", "core/workflow_config.R", "core/contracts.R",
  "data/demo_data.R", "data/data_pipeline.R",
  "ui/analysis_module.R",
  "runtime/orchestrator.R",
  "adapters/preprocess.R", "adapters/preprocess_diagnostics.R", "adapters/composition.R", "adapters/alpha.R", "adapters/beta.R",
  "adapters/environment_spatial.R", "adapters/species_environment_association.R",
  "adapters/differential.R", "adapters/differential_taxa.R",
  "adapters/netcomi_network.R",
  "adapters/ggclusternet_network.R", "adapters/network.R",
  "adapters/function.R", "adapters/assembly_source.R", "adapters/longitudinal_stability.R",
  "adapters/function_assembly_extended.R",
  "adapters/integration_ml.R",
  "runtime/outputs.R", "compat/compatibility.R"
)

for (microbiome_file in microbiome_framework_files) {
  microbiome_path <- file.path(microbiome_project_root, "R", "microbiome", microbiome_file)
  microbiome_source_utf8(microbiome_path)
}
rm(microbiome_file, microbiome_path, microbiome_root_candidates,
  microbiome_configured_root, microbiome_support_name,
  microbiome_support_files)
