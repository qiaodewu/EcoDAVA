file_arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
script_path <- if (length(file_arg)) sub("^--file=", "", file_arg[[1]]) else
  file.path("R", "microbiome", "scripts", "install_microbiome_dependencies.R")
project_root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."),
  winslash = "/", mustWork = TRUE)
options(dava.project_root = project_root)
source(file.path(project_root, "R", "helpers.R"), local = FALSE)
source(file.path(project_root, "R", "microbiome", "00_bootstrap.R"),
  local = FALSE)

options(repos = c(CRAN = "https://cloud.r-project.org"))
registry <- microbiome_package_registry()
is_available <- function(package) requireNamespace(package, quietly = TRUE)
install_archive <- function(package, url) {
  destination <- file.path(tempdir(), basename(url))
  download.file(url, destination, mode = "wb", quiet = FALSE)
  system2(file.path(R.home("bin"), "R"), c("CMD", "INSTALL", "--preclean", shQuote(destination)))
}
install_github_package <- function(package, repository, ref = "") {
  if (!requireNamespace("remotes", quietly = TRUE)) install.packages("remotes")
  remote <- if (nzchar(ref)) paste0(repository, "@", ref) else repository
  remotes::install_github(remote, dependencies = TRUE, upgrade = "never", force = TRUE,
    INSTALL_opts = if (identical(package, "FEAST")) "--preclean" else character())
}

# R 4.5 uses the compatible mia/rbiom pair; rbiom 3.x removed rbiom::unifrac.
if (getRversion() < "4.6.0" && (!is_available("rbiom") || utils::packageVersion("rbiom") != "2.2.1")) {
  install_archive("rbiom", registry$archive_url[registry$package == "rbiom"])
}
if (getRversion() < "4.6.0" && (!is_available("mia") || utils::packageVersion("mia") != "1.16.1")) {
  install_archive("mia", registry$archive_url[registry$package == "mia"])
}

missing <- registry[!vapply(registry$package, is_available, logical(1)), , drop = FALSE]
cran <- missing$package[missing$source == "CRAN"]
bioc <- missing$package[missing$source == "Bioconductor"]
github <- missing[missing$source == "external/GitHub" & nzchar(missing$repository), , drop = FALSE]
if (length(cran)) install.packages(cran, dependencies = TRUE)
if (length(bioc)) {
  if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
  BiocManager::install(bioc, ask = FALSE, update = FALSE)
}
if (nrow(github)) for (index in seq_len(nrow(github))) {
  tryCatch(install_github_package(github$package[[index]], github$repository[[index]], github$ref[[index]]),
    error = function(error) message("Failed to install ", github$package[[index]], ": ", conditionMessage(error)))
}

status <- transform(registry[, c("package", "source")],
  installed = vapply(registry$package, is_available, logical(1)),
  version = vapply(registry$package, function(package) {
    if (is_available(package)) as.character(utils::packageVersion(package)) else NA_character_
  }, character(1)))
print(status, row.names = FALSE)
missing_after <- status$package[!status$installed]
if (length(missing_after)) stop("Unresolved microbiome packages: ", paste(missing_after, collapse = ", "), call. = FALSE)
message("All declared microbiome packages are installed and loadable.")
