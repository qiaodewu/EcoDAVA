options(repos = c(CRAN = "https://cloud.r-project.org"))

install_cran <- function(packages) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) install.packages(missing)
}

install_cran(c("microeco", "remotes"))

# microeco 2 can be installed from its official repository when CRAN has an older release.
if (utils::packageVersion("microeco") < "2.0.0") {
  remotes::install_github("ChiLiubio/microeco", upgrade = "never")
}

# ggClusterNet currently has unresolved upstream License metadata. Installation is therefore opt-in.
if (identical(tolower(Sys.getenv("DAVA_INSTALL_GGCLUSTERNET", "false")), "true")) {
  install_cran("ggalluvial")
  remotes::install_github("taowenmicro/ggClusterNet", upgrade = "never")
}

cat("microeco:", if (requireNamespace("microeco", quietly = TRUE)) as.character(utils::packageVersion("microeco")) else "missing", "\n")
cat("ggClusterNet:", if (requireNamespace("ggClusterNet", quietly = TRUE)) as.character(utils::packageVersion("ggClusterNet")) else "not installed", "\n")
cat("EasyAmplicon: external workflow/result import; not sourced in Shiny.\n")
cat("MicrobiomeStatPlot: reviewed GPL-3 script templates; not treated as an R package.\n")
cat("iNAP 2.0: external platform/result import; no runtime network call.\n")
