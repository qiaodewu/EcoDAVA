file_arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
script_path <- if (length(file_arg)) sub("^--file=", "", file_arg[[1]]) else
  file.path("R", "microbiome", "scripts", "check_microbiome_dependencies.R")
project_root <- normalizePath(
  file.path(dirname(script_path), "..", "..", ".."),
  winslash = "/", mustWork = TRUE)
options(dava.project_root = project_root)
source(file.path(project_root, "R", "helpers.R"), local = FALSE)
source(file.path(project_root, "R", "microbiome", "00_bootstrap.R"),
  local = FALSE)

status <- merge(microbiome_package_registry(), microbiome_package_status(), by = "package", all.x = TRUE, sort = FALSE)
print(status, row.names = FALSE)
cat("\nInstalled:", sum(status$installed), "/", nrow(status), "\n")
if (any(!status$installed)) cat("Missing optional packages:", paste(status$package[!status$installed], collapse = ", "), "\n")
quit(status = 0L)
