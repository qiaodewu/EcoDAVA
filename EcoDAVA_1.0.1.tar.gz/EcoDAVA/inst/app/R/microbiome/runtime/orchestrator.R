microbiome_output_name <- function(selected, outputs) {
  available <- names(outputs)
  if (!length(available)) return("")

  selected <- as.character(selected %||% character())
  selected <- selected[!is.na(selected) & nzchar(selected)]
  if (length(selected) && selected[[1]] %in% available) selected[[1]] else available[[1]]
}

microbiome_result_matches_method <- function(value, method_id,
    differential_method = "", network_engine = "") {
  if (is.null(value) || !is.list(value)) return(FALSE)
  result_method <- as.character(value$method_id %||% "")
  current_method <- as.character(method_id %||% "")
  method_matches <- length(result_method) > 0L && length(current_method) > 0L &&
    nzchar(result_method[[1L]]) && nzchar(current_method[[1L]]) &&
    identical(result_method[[1L]], current_method[[1L]])
  if (!method_matches) return(FALSE)
  expected_network_engine <- as.character(network_engine %||% "")
  expected_network_engine <- expected_network_engine[
    !is.na(expected_network_engine) & nzchar(expected_network_engine)]
  if (length(expected_network_engine)) {
    result_network_engine <- as.character(
      value$actual_parameters$network_engine %||%
        value$analysis_spec$network_engine %||% "netcomi")
    if (!length(result_network_engine) || is.na(result_network_engine[[1]]) ||
        !identical(result_network_engine[[1]], expected_network_engine[[1]])) {
      return(FALSE)
    }
  }
  if (!identical(current_method[[1L]], "ancombc2") ||
      !nzchar(differential_method %||% "")) return(TRUE)
  result_engine <- value$actual_parameters$differential_method %||% "ancombc2"
  identical(as.character(result_engine), as.character(differential_method))
}

microbiome_preview_window <- function(value, start = 1L, width = 50L,
    max_rows = 100L) {
  source <- value %||% data.frame()
  if (is.null(dim(source)) || inherits(source, "data.table")) {
    source <- as.data.frame(source, check.names = FALSE)
  }
  total_rows <- NROW(source)
  total_columns <- NCOL(source)
  scalar_integer <- function(x, default) {
    x <- suppressWarnings(as.integer(x %||% default))
    if (!length(x) || is.na(x[[1]])) default else x[[1]]
  }
  width <- max(1L, scalar_integer(width, 50L))
  max_rows <- max(1L, scalar_integer(max_rows, 100L))
  start <- max(1L, scalar_integer(start, 1L))
  if (!total_columns) {
    return(list(
      data = utils::head(as.data.frame(source, check.names = FALSE), max_rows),
      total_rows = total_rows,
      total_columns = total_columns,
      start = 0L,
      end = 0L
    ))
  }
  start <- min(start, total_columns)
  end <- min(total_columns, start + width - 1L)
  columns <- seq.int(start, end)
  rows <- seq_len(min(total_rows, max_rows))
  list(
    data = as.data.frame(
      source[rows, columns, drop = FALSE],
      check.names = FALSE
    ),
    total_rows = total_rows,
    total_columns = total_columns,
    start = start,
    end = end
  )
}

microbiome_input_issue <- function(error, values = list(), category_id = "",
    panel_id = "") {
  field <- function(name, fallback = "<not selected>") {
    value <- as.character(values[[name]] %||% character())
    value <- value[!is.na(value) & nzchar(value)]
    if (length(value)) paste(value, collapse = ", ") else fallback
  }
  list(
    protected = unique(as.character(unlist(values[c("count_dataset", "taxonomy_dataset", "metadata_dataset")], use.names = FALSE))),
    summary = paste0(
      "\u8f93\u5165\u6570\u636e\u683c\u5f0f\u4e0d\u7b26\u5408\u8981\u6c42\uff0c",
      "\u5df2\u6682\u505c\u9884\u89c8\u548c\u5206\u6790\u3002"
    ),
    details = c(
      paste0("Timestamp: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
      paste0("Module: ", category_id, if (nzchar(panel_id)) paste0(" / ", panel_id) else ""),
      paste0("Abundance dataset: ", field("count_dataset")),
      paste0("Feature ID mapping: ", field("otu_feature_id", field("feature_id"))),
      paste0("Sample ID mapping: ", field("otu_sample_id", field("sample_id"))),
      paste0("Taxonomy dataset: ", field("taxonomy_dataset")),
      paste0("Metadata dataset: ", field("metadata_dataset")),
      paste0("Validation error: ", conditionMessage(error)),
      paste0(
        "Action: analysis was not started; correct non-numeric, NA/Inf, ",
        "negative values, or the row/column mapping and try again."
      )
    )
  )
}

microbiome_invalid_preview_bundle <- function(values = list(), issue = NULL) {
  marker <- as.character(values$marker_type %||% "16S")
  if (!marker %in% c("16S", "ITS")) marker <- "16S"
  structure(list(
    counts = data.frame(), taxonomy = data.frame(), metadata = data.frame(),
    phylogeny = NULL, representative_sequences = NULL,
    environment = data.frame(), function_table = data.frame(),
    function_metadata = list(), functional_mapping = data.frame(),
    marker_type = marker, data_version = values$count_dataset %||% "",
    provenance = list(input_issue = issue), sample_ids = character(),
    feature_ids = character(), transform = "none", is_raw_count = FALSE
  ), class = c("microbiome_invalid_bundle", "microbiome_bundle", "list"))
}

microbiome_input_issue_text <- function(issue, language = "en") {
  if (is.null(issue)) return(list(summary = "", details = character()))
  language <- dava_i18n_language(language)
  protected <- issue$protected %||% character()
  list(
    summary = dava_translate_composed(issue$summary %||% "", language, protected),
    details = dava_translate_composed(issue$details %||% character(), language, protected)
  )
}

microbiome_input_issue_ui <- function(issue, language = "en") {
  if (is.null(issue)) return(NULL)
  text <- microbiome_input_issue_text(issue, language)
  shiny::div(
    class = "alert alert-warning py-2 px-3 mb-2",
    shiny::tags$strong(dava_translate_text("\u8f93\u5165\u6570\u636e\u9700\u8981\u4fee\u6b63", language)),
    shiny::tags$div(class = "small mt-1", text$summary),
    shiny::tags$div(
      class = "small mt-1",
      dava_translate_text("\u8be6\u7ec6\u4fe1\u606f\u5df2\u5199\u5165\u201c\u8bca\u65ad\u4e0e\u9519\u8bef\u201d\u9762\u677f\u3002", language)
    )
  )
}

microbiome_input_issue_key <- function(issue) {
  if (is.null(issue)) return("")
  details <- as.character(issue$details %||% character())
  details <- details[!startsWith(details, "Timestamp: ")]
  paste(c(issue$summary %||% "", details), collapse = "\n")
}

microbiome_network_progress_label <- function(engine = "netcomi") {
  if (identical(engine %||% "netcomi", "ggclusternet2")) {
    "ggClusterNet2"
  } else {
    "NetCoMi"
  }
}

microbiome_plot_settings_prefix <- function(plot_name) {
  paste0("microbiome_plot_", gsub("[^A-Za-z0-9]+", "_", plot_name %||% "result"))
}

microbiome_preferred_plot_name <- function(result) {
  plot_names <- names(result$plots %||% list())
  if (!length(plot_names)) return("")
  requested <- as.character(result$actual_parameters$plot_types %||% character())
  requested <- requested[!is.na(requested) & nzchar(requested)]
  preferred <- intersect(requested, plot_names)
  if (length(preferred)) return(preferred[[1]])
  analysis_plots <- plot_names[!startsWith(plot_names, "preprocess_")]
  if (length(analysis_plots)) analysis_plots[[1]] else plot_names[[1]]
}

microbiome_resolve_plot_selection <- function(current, result) {
  plot_names <- names(result$plots %||% list())
  if (!length(plot_names)) return("")
  current <- as.character(current %||% character())
  current <- current[!is.na(current) & nzchar(current)]
  if (length(current) && current[[1]] %in% plot_names) return(current[[1]])
  microbiome_preferred_plot_name(result)
}

microbiome_is_plot_compatibility_warning <- function(message) {
  message <- as.character(message %||% "")
  any(grepl(paste(
    "aes_string\\(\\).*deprecated",
    "Using.*size.*aesthetic.*deprecated",
    "Scale for y is already present",
    "Adding another scale for y",
    "multiple classes.*phylo",
    "Multiple classes found in cache.*phylo",
    sep = "|"), message, ignore.case = TRUE))
}

microbiome_quiet_plot_compatibility <- function(code) {
  withCallingHandlers(code,
    warning = function(condition) {
      if (microbiome_is_plot_compatibility_warning(
          conditionMessage(condition))) {
        invokeRestart("muffleWarning")
      }
    })
}

microbiome_prerender_plot_raster <- function(plot, width = 900L,
    height = 680L, res = 96L) {
  if (!inherits(plot, c("ggplot", "grob")) ||
      !requireNamespace("png", quietly = TRUE)) return(NULL)
  width <- max(1L, as.integer(width))
  height <- max(1L, as.integer(height))
  res <- max(72L, as.integer(res))
  path <- tempfile("microbiome-plot-", fileext = ".png")
  device_open <- FALSE
  on.exit({
    if (device_open) grDevices::dev.off()
    unlink(path)
  }, add = TRUE)
  dava_open_png_device(path, width = width, height = height, units = "px",
    res = res, background = "transparent")
  device_open <- TRUE
  if (inherits(plot, "grob")) grid::grid.draw(plot) else print(plot)
  grDevices::dev.off()
  device_open <- FALSE
  png::readPNG(path, native = TRUE)
}

microbiome_attach_runtime_capture <- function(result, captured) {
  clean <- function(value) {
    value <- trimws(as.character(value %||% character()), which = "right")
    unique(value[nzchar(trimws(value))])
  }
  captured_warnings <- clean(captured$warnings)
  compatibility <- captured_warnings[vapply(captured_warnings,
    microbiome_is_plot_compatibility_warning, logical(1))]
  analysis_warnings <- setdiff(captured_warnings, compatibility)
  compatibility_log <- if (length(compatibility)) {
    paste0("[Third-party plotting compatibility] ", compatibility)
  } else character()
  result$runtime_log <- clean(c(
    result$runtime_log, captured$log, compatibility_log))
  result$warnings <- clean(c(result$warnings, analysis_warnings))
  if (identical(result$status, "success") && length(result$warnings)) {
    result$status <- "warning"
  }
  result
}

microbiome_start_background_analysis <- function(bundle, spec, method_id) {
  if (!requireNamespace("callr", quietly = TRUE)) {
    stop("Background analysis requires the callr package.", call. = FALSE)
  }
  stdout_path <- tempfile("dava-microbiome-worker-", fileext = ".stdout.log")
  stderr_path <- tempfile("dava-microbiome-worker-", fileext = ".stderr.log")
  process <- callr::r_bg(
    func = function(project_root, analysis_bundle, analysis_spec,
        analysis_method_id) {
      setwd(project_root)
      source(file.path("R", "helpers.R"), local = FALSE)
      source(file.path("R", "microbiome", "00_bootstrap.R"), local = FALSE)
      microbiome_capture_runtime_output(function() {
        diagnostics <- microbiome_preprocessing_diagnostics(
          analysis_bundle, analysis_spec)
        prepared_bundle <- microbiome_apply_preprocessing(
          analysis_bundle, analysis_spec)
        value <- microbiome_run_method(
          analysis_method_id, prepared_bundle, analysis_spec)
        microbiome_attach_preprocessing_diagnostics(
          value, diagnostics, analysis_spec)
      })
    },
    args = list(
      project_root = microbiome_project_root,
      analysis_bundle = bundle,
      analysis_spec = spec,
      analysis_method_id = method_id),
    stdout = stdout_path, stderr = stderr_path,
    supervise = TRUE)
  attr(process, "dava_log_paths") <- c(stdout_path, stderr_path)
  process
}

microbiome_cleanup_background_analysis <- function(process) {
  if (is.null(process)) return(invisible(FALSE))
  paths <- attr(process, "dava_log_paths") %||% character()
  paths <- paths[file.exists(paths)]
  if (length(paths)) unlink(paths, force = TRUE)
  invisible(TRUE)
}

microbiome_cancel_background_analysis <- function(process) {
  if (is.null(process)) return(invisible(FALSE))
  if (isTRUE(tryCatch(process$is_alive(), error = function(error) FALSE))) {
    tryCatch(process$kill_tree(), error = function(error) {
      tryCatch(process$kill(), error = function(error) NULL)
    })
  }
  microbiome_cleanup_background_analysis(process)
  invisible(TRUE)
}

mod_microbiome_framework_server <- function(id, category_id, panel_id = "", file_data = NULL, requested_method = NULL) {
  shiny::moduleServer(id, function(input, output, session) {
    root_input <- session$rootScope()$input
    interface_language <- shiny::reactive({
      root_input$dava_interface_language
      dava_i18n_language(root_input$dava_interface_language)
    })
    # Progress polling and background callbacks run outside a reactive
    # consumer.  Read the language reactively when a consumer exists, but
    # fall back to an isolated read for later::later/worker callbacks.
    current_interface_language <- function() {
      tryCatch(
        interface_language(),
        error = function(error) shiny::isolate(interface_language())
      )
    }
    tr <- function(text) dava_translate_text(text, current_interface_language())
    tr_generated <- function(text) dava_translate_composed(text, current_interface_language())
    localize_microbiome_plot <- function(plot) {
      if (identical(current_interface_language(), "en")) {
        plot <- dava_plot_english_labels(plot)
      }
      bundle <- tryCatch(preview_bundle(), error = function(error) NULL)
      protected <- character()
      if (is.list(bundle)) {
        protected <- unique(c(
          bundle$sample_ids %||% character(), bundle$feature_ids %||% character(),
          unlist(lapply(bundle[c("counts", "taxonomy", "metadata", "environment")],
            function(table) {
              if (!is.data.frame(table)) return(character())
              c(names(table), rownames(table), unlist(lapply(table, function(column) {
                if (is.character(column) || is.factor(column)) as.character(unique(column))
                else character()
              }), use.names = FALSE))
            }), use.names = FALSE)
        ))
      }
      dava_localize_plot(plot, current_interface_language(), protected)
    }
    workspace_module_key <- paste("microbiome", id, sep = "/")
    workspace_state_enabled <- !is.null(file_data) &&
      "workspace_module_states" %in% names(shiny::isolate(
        shiny::reactiveValuesToList(file_data, all.names = TRUE)))
    restored_workspace_state <- if (!workspace_state_enabled) list() else
      shiny::isolate((file_data$workspace_module_states %||% list())[[
        workspace_module_key]] %||% list())
    is_alpha_panel <- identical(panel_id, "alpha_diversity")
    is_beta_panel <- identical(panel_id, "beta_diversity")
    is_phylogenetic_panel <- identical(panel_id, "phylogenetic_diversity")
    is_composition_panel <- identical(category_id, "composition_differential")
    is_species_environment_panel <- identical(panel_id, "multivariable_association")
    is_community_environment_panel <- identical(panel_id, "community_environment")
    is_function_panel <- panel_id %in% c(
      "bacterial_function", "fungal_function")
    is_assembly_panel <- panel_id %in% c(
      "community_assembly", "niche_breadth")
    is_network_panel <- panel_id %in% c(
      "microbial_network", "cross_domain_network")
    is_cross_domain_panel <- identical(panel_id, "cross_domain_network")
    is_custom_diversity_panel <- is_alpha_panel || is_beta_panel || is_phylogenetic_panel
    navigation_method <- shiny::reactiveVal(
      restored_workspace_state$navigation_method %||% "")
    precheck <- shiny::reactiveVal(NULL)
    preview_input_issue <- shiny::reactiveVal(NULL)
    method_parameter_state <- shiny::reactiveVal(
      restored_workspace_state$method_parameter_state %||% list())
    generated_rooted_tree_dataset <- shiny::reactiveVal("")
    network_plot_grouped_state <- shiny::reactiveVal(NULL)
    plot_runtime_diagnostics <- shiny::reactiveVal(character())
    record_plot_runtime_diagnostics <- function(captured, source = "Microbiome plot") {
      entries <- dava_plot_condition_text(captured, source)
      if (!length(entries)) return(invisible(NULL))
      current <- shiny::isolate(plot_runtime_diagnostics())
      plot_runtime_diagnostics(unique(c(current, entries)))
      invisible(entries)
    }
    network_worker_warmup <- shiny::reactiveVal(list())
    network_worker_warmed <- shiny::reactiveVal(FALSE)
    if (is_network_panel) {
      shiny::observeEvent(input$network_engine, {
        if (identical(input$network_engine %||% "netcomi", "netcomi") &&
            !isTRUE(network_worker_warmed())) {
          network_worker_warmed(TRUE)
          network_worker_warmup(microbiome_netcomi_warm_workers(2L))
        }
      }, ignoreInit = FALSE)
    }
    saved_method_parameters <- function(method_id = input$method_id %||% "") {
      method_parameter_state()[[method_id]] %||% list()
    }
    save_method_parameters <- function(method_id, ids) {
      state <- method_parameter_state()
      values <- stats::setNames(lapply(ids, function(field) shiny::isolate(input[[field]])), ids)
      values <- values[!vapply(values, is.null, logical(1))]
      state[[method_id]] <- utils::modifyList(state[[method_id]] %||% list(), values)
      method_parameter_state(state)
      invisible(values)
    }
    if (!is.null(requested_method)) {
      shiny::observeEvent(requested_method(), {
        request <- requested_method()
        if (is.null(request) || !identical(request$category_id, category_id)) return()
        if (nzchar(panel_id) && !identical(request$panel_id %||% "", panel_id)) return()
        choices <- unname(if (nzchar(panel_id)) microbiome_panel_method_choices(category_id, panel_id, TRUE) else
          microbiome_category_method_choices(category_id, include_planned = TRUE))
        if (!request$method_id %in% choices) return()
        target_method <- if (is_alpha_panel) "alpha_core" else request$method_id
        navigation_method(target_method)
        shiny::freezeReactiveValue(input, "method_id")
        shiny::updateSelectInput(session, "method_id", selected = target_method)
        if (is_composition_panel) {
          shiny::freezeReactiveValue(input, "composition_method")
          shiny::updateSelectInput(session, "composition_method", selected = target_method)
        }
      }, ignoreInit = FALSE)
    }
    beta_ordination_methods <- if (is_beta_panel) microbiome_beta_method_groups(TRUE)$ordination else character()
    active_method_id <- shiny::reactive({
      if (is_alpha_panel) return("alpha_core")
      if (is_beta_panel) {
        requested <- input$beta_ordination_method %||% input$method_id %||% "pcoa"
        if (requested %in% beta_ordination_methods) return(requested)
        return("pcoa")
      }
      if (is_composition_panel) return(input$composition_method %||% input$method_id %||% "")
      if (is_network_panel) {
        return(if (is_cross_domain_panel) {
          "cross_domain_network"
        } else {
          "netcomi_network"
        })
      }
      if (is_species_environment_panel) {
        requested <- input$method_id %||% navigation_method()
        return(if (length(requested) && nzchar(requested)) requested else
          "species_env_spearman")
      }
      input$method_id %||% ""
    })
    selected_method <- shiny::reactive({
      method_id <- active_method_id()
      row <- MICROBIOME_METHOD_REGISTRY[MICROBIOME_METHOD_REGISTRY$id == method_id, , drop = FALSE]
      valid <- nrow(row) && (!nzchar(panel_id) ||
        identical(row$navigation_panel[[1]], panel_id))
      if (valid) return(row[1, , drop = FALSE])

      # A restored/stale browser input must not blank the complete module.
      # Resolve an invalid method to the panel's canonical first method.
      candidates <- MICROBIOME_METHOD_REGISTRY
      if (nzchar(panel_id)) {
        candidates <- candidates[candidates$navigation_panel == panel_id, , drop = FALSE]
      } else {
        candidates <- candidates[candidates$secondary_category == category_id, , drop = FALSE]
      }
      if (nrow(candidates)) candidates[1, , drop = FALSE] else NULL
    })
    package_status_refresh <- shiny::reactiveVal(0L)
    current_method_packages <- shiny::reactive({
      method <- selected_method()
      if (!is.null(method) && identical(method$id[[1]], "ancombc2")) {
        differential_method <- input$composition_differential_method %||% "ancombc2"
        specialized <- switch(differential_method,
          deseq2 = "DESeq2", edger = "edgeR", "ANCOMBC")
        return(unique(c("stats", "ggplot2", "dplyr", specialized)))
      }
      engine <- if (is_network_panel) {
        input$network_engine %||% "netcomi"
      } else {
        ""
      }
      unique(c("stats", "ggplot2", "dplyr", "tibble", "tidyr",
        microbiome_method_packages(method, engine)))
    })

    output$package_status <- shiny::renderUI({
      package_status_refresh()
      packages <- current_method_packages()
      if (!length(packages)) {
        return(shiny::div(
          class = "microbiome-package-status",
          shiny::span(class = "package-ok", "No additional analysis package required ✓")))
      }
      status <- microbiome_package_status(packages, loadable = FALSE)
      items <- lapply(seq_len(nrow(status)), function(index) {
        installed <- isTRUE(status$installed[[index]])
        version <- status$version[[index]]
        shiny::span(
          class = if (installed) "package-ok" else "package-missing",
          title = if (installed && !is.na(version)) {
            paste("version", version)
          } else {
            "not installed"
          },
          paste0(status$package[[index]], if (installed) " ✓" else " is missing"))
      })
      shiny::div(class = "microbiome-package-status", items)
    })

    dava_bind_dependency_checker(
      input, session, packages = current_method_packages,
      method_label = function() {
        method <- selected_method()
        if (is.null(method) || !nrow(method)) return("Current microbiome analysis method")
        as.character(method$label_cn[[1]] %||% method$id[[1]])
      },
      refresh = function() package_status_refresh(package_status_refresh() + 1L))

    shiny::observe({
      if (!is_beta_panel) return()
      requested <- input$beta_ordination_method %||% input$method_id %||% "pcoa"
      target <- if (requested %in% beta_ordination_methods) requested else "pcoa"
      if (!identical(input$method_id, target)) {
        shiny::freezeReactiveValue(input, "method_id")
        shiny::updateSelectInput(session, "method_id", selected = target)
      }
    })
    shiny::observe({
      if (!is_composition_panel) return()
      target <- input$composition_method %||% input$method_id %||% ""
      if (nzchar(target) && !identical(input$method_id, target)) {
        shiny::freezeReactiveValue(input, "method_id")
        shiny::updateSelectInput(session, "method_id", selected = target)
      }
    })
    output$method_status <- shiny::renderUI({
      method <- selected_method()
      if (is.null(method)) return(NULL)
      if (method$status != "implemented") shiny::div(class = "alert alert-secondary py-2",
        shiny::tags$strong("is currently not operable:"), method$unavailable_reason %||% "This method has not yet closed the loop.",
        if (nzchar(method$required_packages %||% "")) shiny::tags$div("Mature engine:", method$engine,
          "; Dependent packages:", method$required_packages))
    })
    output$dynamic_fields <- shiny::renderUI({
      NULL
    })

    general_sidebar_context <- shiny::reactive({
      method <- selected_method()
      if (is.null(method)) return(NULL)
      datasets <- if (is.null(file_data)) character() else microbiome_dataset_names(file_data)
      selected <- input$count_dataset %||% ".__method_demo__"
      demo <- microbiome_demo_for_method(method$id[[1]])
      columns <- if (selected %in% c(".__method_demo__", ".__demo16s__", ".__demoits__") || is.null(file_data)) {
        names(demo$metadata)
      } else {
        names(file_data$global_datasets[[selected]] %||% data.frame())
      }
      other_columns <- if (is.null(file_data)) character() else
        unique(unlist(lapply(file_data$global_datasets %||% list(), names), use.names = FALSE))
      bundle <- tryCatch(preview_bundle(), error = function(error) demo)
      metadata <- bundle$metadata %||% demo$metadata %||% data.frame()
      environment <- bundle$environment %||% demo$environment %||% data.frame()
      taxonomy_ranks <- intersect(
        c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species"),
        names(bundle$taxonomy %||% data.frame())
      )
      metadata_columns <- setdiff(names(metadata), "SampleID")
      categorical <- metadata_columns[vapply(metadata[, metadata_columns, drop = FALSE], function(value) {
        count <- length(unique(value[!is.na(value)]))
        (is.factor(value) || is.character(value) || is.logical(value) || count <= 10L) && count >= 2L
      }, logical(1))]
      numeric_environment <- names(environment)[vapply(environment, is.numeric, logical(1))]
      numeric_metadata <- metadata_columns[vapply(metadata[, metadata_columns, drop = FALSE], is.numeric, logical(1))]
      explanatory <- unique(c(numeric_environment, numeric_metadata))
      ids <- microbiome_sidebar_field_ids(method)
      sequence_datasets <- if (is.null(file_data)) {
        character()
      } else {
        datasets[vapply(datasets, function(name) {
          table <- file_data$global_datasets[[name]] %||% data.frame()
          any(c("Sequence", "sequence", "DNA", "Nucleotide") %in%
            names(table))
        }, logical(1))]
      }
      demo_sequence_available <- method$id[[1]] %in%
        c("tax4fun2", "phylogenetic_tree_build") &&
        selected %in% c(".__method_demo__", ".__demo16s__") &&
        length(demo$representative_sequences %||% list())
      if (demo_sequence_available) {
        sequence_datasets <- c(
          "The current OTU table has a complete representative sequence built in" = ".__bundle_sequences__",
          sequence_datasets)
      }
      sequence_scores <- if (!is.null(file_data) &&
          length(sequence_datasets) &&
          !selected %in% c(".__method_demo__", ".__demo16s__", ".__demoits__")) {
        count_table <- file_data$global_datasets[[selected]] %||% data.frame()
        count_ids <- unique(c(rownames(count_table), colnames(count_table)))
        vapply(unname(sequence_datasets), function(name) {
          if (startsWith(name, ".__bundle_")) return(0)
          sequences <- tryCatch(microbiome_representative_sequence_list(
            file_data$global_datasets[[name]] %||% data.frame()),
            error = function(error) NULL)
          sum(names(sequences %||% list()) %in% count_ids)
        }, numeric(1))
      } else {
        rep(0, length(sequence_datasets))
      }
      default_sequence_dataset <- if (demo_sequence_available) {
        ".__bundle_sequences__"
      } else if (length(sequence_scores) && max(sequence_scores) > 0) {
        unname(sequence_datasets)[which.max(sequence_scores)]
      } else if (
          "micro_representative_sequences" %in% unname(sequence_datasets)) {
        "micro_representative_sequences"
      } else {
        utils::head(unname(sequence_datasets), 1L)
      }
      fungal_ranks <- c(
        "Kingdom", "Phylum", "Class", "Order",
        "Family", "Genus", "Species")
      fungal_taxonomy_datasets <- if (is.null(file_data)) {
        character()
      } else {
        datasets[vapply(datasets, function(name) {
          table <- file_data$global_datasets[[name]] %||% data.frame()
          all(fungal_ranks %in% names(table))
        }, logical(1))]
      }
      fungal_taxonomy_scores <- if (
          length(fungal_taxonomy_datasets) &&
          !selected %in% c(
            ".__method_demo__", ".__demo16s__", ".__demoits__")) {
        count_table <- file_data$global_datasets[[selected]] %||%
          data.frame()
        count_ids <- unique(c(
          rownames(count_table), colnames(count_table)))
        vapply(fungal_taxonomy_datasets, function(name) {
          table <- file_data$global_datasets[[name]]
          feature_column <- intersect(
            c("Feature", "FeatureID", "ASV", "OTU", "ID"),
            names(table))
          taxonomy_ids <- if (length(feature_column)) {
            as.character(table[[feature_column[[1]]]])
          } else {
            rownames(table)
          }
          sum(taxonomy_ids %in% count_ids)
        }, numeric(1))
      } else {
        stats::setNames(
          rep(0, length(fungal_taxonomy_datasets)),
          fungal_taxonomy_datasets)
      }
      default_fungal_taxonomy <- if (
          length(fungal_taxonomy_scores) &&
          max(fungal_taxonomy_scores) > 0) {
        names(which.max(fungal_taxonomy_scores))
      } else if ("micro_taxonomy" %in%
          fungal_taxonomy_datasets) {
        "micro_taxonomy"
      } else {
        utils::head(fungal_taxonomy_datasets, 1L)
      }
      selected_is_demo <- selected %in% c(
        ".__method_demo__", ".__demo16s__", ".__demoits__")
      default_matching_taxonomy <- if (selected_is_demo || is.null(file_data)) {
        ".__bundle_taxonomy__"
      } else {
        microbiome_matching_dataset_name(
          file_data, selected, bundle$feature_ids %||% character(), "taxonomy")
      }
      default_matching_metadata <- if (selected_is_demo || is.null(file_data)) {
        ".__bundle_metadata__"
      } else {
        microbiome_matching_dataset_name(
          file_data, selected, bundle$sample_ids %||% character(), "metadata")
      }
      current_values <- stats::setNames(
        lapply(ids, function(id) shiny::isolate(input[[id]])), ids)
      if (identical(method$id[[1]], "tax4fun2") &&
          !nzchar(current_values$sequence_dataset %||% "") &&
          length(default_sequence_dataset)) {
        current_values$sequence_dataset <- default_sequence_dataset
      }
      if (method$id[[1]] %in% c("funguild", "fungaltraits") &&
          !nzchar(current_values$taxonomy_dataset %||% "") &&
          length(default_fungal_taxonomy)) {
        current_values$taxonomy_dataset <- default_fungal_taxonomy
      }
      list(method = method, ids = ids, context = list(
        datasets = datasets,
        sequence_datasets = sequence_datasets,
        default_sequence_dataset = default_sequence_dataset,
        fungal_taxonomy_datasets = fungal_taxonomy_datasets,
        default_fungal_taxonomy = default_fungal_taxonomy,
        default_matching_taxonomy = default_matching_taxonomy,
        default_matching_metadata = default_matching_metadata,
        columns = unique(c(columns, other_columns)),
        field_choices = list(
          group = categorical, treatment = categorical, block = categorical, site = categorical,
          degradation = categorical, subject_or_plot_id = categorical,
          fixed_effects = explanatory, covariates = explanatory,
          random_effects = categorical, permutation_strata = categorical,
          time = unique(c(numeric_metadata, metadata_columns))
        ),
        taxonomy_ranks = taxonomy_ranks,
        metadata = metadata,
        environment = environment,
        demo_label = microbiome_method_demo_profile(method$id[[1]])$label,
        language = interface_language(),
        demo_data_version = demo$data_version %||% "demo_16s_cross_sectional_v1",
        current_values = current_values
      ))
    })

    general_data_ids <- c("marker_type", "count_dataset", "taxonomy_dataset", "metadata_dataset",
      "environment_dataset", "function_dataset", "function_mapping_dataset", "phylogeny_dataset",
      "sequence_dataset", "second_microbiome_dataset")

    output$general_data_sidebar <- shiny::renderUI({
      if (is_custom_diversity_panel) return(NULL)
      state <- general_sidebar_context()
      if (is.null(state)) return(NULL)
      if (is_cross_domain_panel) {
        datasets <- state$context$datasets %||% character()
        ranks <- c(
          "Phylum", "Class", "Order", "Family", "Genus", "Species")
        return(shiny::tagList(
          shiny::tags$h6(class = "fw-semibold mb-2",
            "16S bacterial data"),
          shiny::selectInput(
            session$ns("count_dataset"), "16S OTU/ASV abundance table",
            c("Matched 16S demo data" = ".__demo16s__", datasets),
            selected = shiny::isolate(input$count_dataset) %||%
              ".__demo16s__"),
          shiny::selectInput(
            session$ns("taxonomy_dataset"), "16S taxonomy table",
            c("Provided by demo bundle" = ".__bundle_taxonomy__", datasets),
            selected = shiny::isolate(input$taxonomy_dataset) %||%
              ".__bundle_taxonomy__"),
          shiny::selectInput(
            session$ns("bacteria_taxonomic_rank"),
            "Bacterial taxonomic rank", ranks,
            selected = shiny::isolate(input$bacteria_taxonomic_rank) %||%
              "Genus"),
          shiny::tags$hr(class = "my-3"),
          shiny::tags$h6(class = "fw-semibold mb-2",
            "ITS fungal data"),
          shiny::selectInput(
            session$ns("second_count_dataset"),
            "ITS OTU/ASV abundance table",
            c("Matched ITS demo data" = ".__demoits__", datasets),
            selected = shiny::isolate(input$second_count_dataset) %||%
              ".__demoits__"),
          shiny::selectInput(
            session$ns("second_taxonomy_dataset"), "ITS taxonomy table",
            c("Provided by demo bundle" = ".__bundle_taxonomy__", datasets),
            selected = shiny::isolate(input$second_taxonomy_dataset) %||%
              ".__bundle_taxonomy__"),
          shiny::selectInput(
            session$ns("fungi_taxonomic_rank"),
            "Fungal taxonomic rank", ranks,
            selected = shiny::isolate(input$fungi_taxonomic_rank) %||%
              "Genus"),
          shiny::tags$hr(class = "my-3"),
          shiny::selectInput(
            session$ns("metadata_dataset"), "Shared sample metadata",
            c("Provided by matched demo bundle" =
                ".__bundle_metadata__", datasets),
            selected = shiny::isolate(input$metadata_dataset) %||%
              ".__bundle_metadata__")
        ))
      }
      if (is_community_environment_panel) {
        datasets <- state$context$datasets %||% character()
        selected_count <- shiny::isolate(input$count_dataset) %||%
          ".__method_demo__"
        using_demo <- selected_count %in% c(
          ".__method_demo__", ".__demo16s__", ".__demoits__")
        demo_name <- state$context$demo_data_version %||%
          "demo_16s_cross_sectional_v1"
        metadata_selected <- shiny::isolate(input$metadata_dataset) %||% ""
        environment_selected <- shiny::isolate(input$environment_dataset) %||% ""
        if (using_demo) {
          if (!nzchar(metadata_selected) || startsWith(metadata_selected, ".__bundle_")) {
            metadata_selected <- ".__bundle_metadata__"
          }
          if (!nzchar(environment_selected) || startsWith(environment_selected, ".__bundle_")) {
            environment_selected <- ".__bundle_environment__"
          }
        } else {
          if (startsWith(metadata_selected, ".__bundle_")) metadata_selected <- ""
          if (startsWith(environment_selected, ".__bundle_")) environment_selected <- ""
        }
        return(shiny::tagList(
          microbiome_field_ui("marker_type", session$ns, state$context),
          microbiome_field_ui("count_dataset", session$ns, state$context),
          shiny::selectInput(session$ns("metadata_dataset"), "Sample table",
            c("Please select the matching sample table" = "", stats::setNames(".__bundle_metadata__",
              paste0(demo_name, "_sample_metadata (default simulation sample table)")), datasets),
            selected = metadata_selected),
          shiny::selectInput(session$ns("environment_dataset"), "Environment variable table",
            c("Please select the matching environment variable table" = "", stats::setNames(".__bundle_environment__",
              paste0(demo_name, "_environment (default simulation environment variable table)")), datasets),
            selected = environment_selected)
        ))
      }
      if (is_composition_panel) {
        datasets <- state$context$datasets %||% character()
        selected_count <- shiny::isolate(input$count_dataset) %||%
          ".__method_demo__"
        using_demo <- selected_count %in% c(
          ".__method_demo__", ".__demo16s__", ".__demoits__")
        demo_name <- state$context$demo_data_version %||%
          "demo_16s_cross_sectional_v1"
        taxonomy_selected <- shiny::isolate(input$taxonomy_dataset) %||% ""
        metadata_selected <- shiny::isolate(input$metadata_dataset) %||% ""
        if (using_demo) {
          taxonomy_selected <- ".__bundle_taxonomy__"
          metadata_selected <- ".__bundle_metadata__"
        } else {
          if (!nzchar(taxonomy_selected) || startsWith(taxonomy_selected, ".__bundle_")) {
            taxonomy_selected <- state$context$default_matching_taxonomy %||% ""
          }
          if (!nzchar(metadata_selected) || startsWith(metadata_selected, ".__bundle_")) {
            metadata_selected <- state$context$default_matching_metadata %||% ""
          }
        }
        return(shiny::tagList(
          microbiome_field_ui("marker_type", session$ns, state$context),
          microbiome_field_ui("count_dataset", session$ns, state$context),
          shiny::selectInput(session$ns("taxonomy_dataset"), "Classification annotation table",
            c("Please select the matching classification annotation table" = "",
              stats::setNames(".__bundle_taxonomy__",
                paste0(demo_name, "_taxonomy (current OTU table default classification annotation table)")),
              datasets), selected = taxonomy_selected),
          shiny::selectInput(session$ns("metadata_dataset"), "Sample table",
            c("Please select the matching sample table" = "",
              stats::setNames(".__bundle_metadata__",
                paste0(demo_name, "_sample_metadata (current OTU table default sample table)")),
              datasets), selected = metadata_selected)
        ))
      }
      if (is_species_environment_panel) {
        datasets <- state$context$datasets %||% character()
        rank_choices <- state$context$taxonomy_ranks %||%
          c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species")
        rank <- shiny::isolate(input$taxonomic_rank) %||%
          if ("Genus" %in% rank_choices) "Genus" else utils::head(rank_choices, 1L)
        return(shiny::tagList(
          shiny::tags$h6(class = "fw-semibold mb-2", "Data selection"),
          microbiome_field_ui("marker_type", session$ns, state$context),
          microbiome_field_ui("count_dataset", session$ns, state$context),
          microbiome_field_ui("taxonomy_dataset", session$ns, state$context),
          shiny::selectInput(session$ns("taxonomic_rank"), "Classification hierarchy",
            stats::setNames(rank_choices, rank_choices), selected = rank),
          microbiome_field_ui("metadata_dataset", session$ns, state$context),
          microbiome_field_ui("environment_dataset", session$ns, state$context)
        ))
      }
      if (identical(state$method$navigation_panel[[1]], "bacterial_function")) {
        environment_enabled <- identical(
          state$method$id[[1]], "faprotax") &&
          isTRUE(input$function_environment_enabled)
        ordered <- c(
          "marker_type", "count_dataset", "taxonomy_dataset",
          if (identical(state$method$id[[1]], "tax4fun2")) {
            "sequence_dataset"
          },
          "metadata_dataset",
          if (environment_enabled) "environment_dataset",
          "function_dataset",
          "function_mapping_dataset", "phylogeny_dataset",
          character())
        ids <- intersect(ordered, unique(c(
          state$ids,
          if (environment_enabled) "environment_dataset")))
        context <- state$context
        context$current_values$environment_dataset <-
          shiny::isolate(input$environment_dataset) %||% ""
        return(shiny::tagList(
          shiny::tags$h6(class = "fw-semibold mb-2", "Data selection"),
          lapply(ids, function(field_id) {
            if (identical(field_id, "marker_type")) {
              return(shiny::selectInput(
                session$ns("marker_type"), "Amplicon type",
                c("16S" = "16S"), selected = "16S"))
            }
            microbiome_field_ui(
              field_id, session$ns, context = context)
          })))
      }
      if (identical(state$method$navigation_panel[[1]], "fungal_function")) {
        taxonomy_choices <-
          state$context$fungal_taxonomy_datasets %||% character()
        demo_selected <- identical(
          shiny::isolate(input$count_dataset) %||%
            ".__method_demo__",
          ".__method_demo__")
        taxonomy_selected <- shiny::isolate(
          input$taxonomy_dataset) %||%
          state$context$default_fungal_taxonomy %||% ""
        taxonomy_selected <- as.character(taxonomy_selected)
        taxonomy_selected <- taxonomy_selected[
          !is.na(taxonomy_selected) & nzchar(taxonomy_selected)]
        taxonomy_selected <- if (length(taxonomy_selected)) {
          taxonomy_selected[[1]]
        } else {
          ""
        }
        if (!taxonomy_selected %in% taxonomy_choices) {
          taxonomy_selected <-
            state$context$default_fungal_taxonomy %||% ""
        }
        return(shiny::tagList(
          shiny::tags$h6(class = "fw-semibold mb-2", "Data selection"),
          shiny::selectInput(
            session$ns("marker_type"), "Amplicon type",
            c("ITS" = "ITS"), selected = "ITS"),
          microbiome_field_ui(
            "count_dataset", session$ns, state$context),
          shiny::selectInput(
            session$ns("taxonomy_dataset"), "Complete classification annotation table",
            if (demo_selected) {
              c("Method-specific simulation data built-in complete classification table The" = "")
            } else {
              stats::setNames(
                taxonomy_choices, taxonomy_choices)
            },
            selected = if (demo_selected) "" else
              taxonomy_selected),
          microbiome_field_ui(
            "metadata_dataset", session$ns, state$context)))
      }
      if (is_assembly_panel &&
          !identical(state$method$id[[1]], "icamp")) {
        datasets <- state$context$datasets %||% character()
        requires_tree <- isTRUE(state$method$phylogeny_required[[1]])
        selected_count <- shiny::isolate(input$count_dataset) %||%
          ".__method_demo__"
        demo_selected <- selected_count %in% c(
          ".__method_demo__", ".__demo16s__", ".__demoits__")
        metadata_selected <- shiny::isolate(input$metadata_dataset) %||% ""
        tree_selected <- shiny::isolate(input$phylogeny_dataset) %||% ""
        if (demo_selected) {
          metadata_selected <- ".__bundle_metadata__"
          tree_selected <- ".__bundle_phylogeny__"
        }
        metadata_choices <- c(
          if (demo_selected) "Default simulation metadata corresponding to the current OTU table" =
            ".__bundle_metadata__",
          stats::setNames(datasets, datasets))
        return(shiny::tagList(
          shiny::tags$h6(class = "fw-semibold mb-2", "Data selection"),
          microbiome_field_ui("marker_type", session$ns, state$context),
          microbiome_field_ui("count_dataset", session$ns, state$context),
          shiny::selectInput(session$ns("metadata_dataset"), "sample metadata",
            metadata_choices, selected = metadata_selected),
          if (requires_tree) shiny::selectInput(session$ns("phylogeny_dataset"),
            "Rooted phylogenetic tree (matches OTU/ASV)",
            c(if (demo_selected) {
              "Exclusive simulated rooted phylogeny tree corresponding to the current OTU table" =
                ".__bundle_phylogeny__"
            }, stats::setNames(datasets, datasets)), selected = tree_selected)
        ))
      }
      if (identical(state$method$id[[1]], "icamp")) {
        datasets <- state$context$datasets %||% character()
        selected_count <- shiny::isolate(input$count_dataset) %||%
          ".__method_demo__"
        demo_selected <- selected_count %in% c(
          ".__method_demo__", ".__demo16s__", ".__demoits__")
        tree_selected <- shiny::isolate(input$phylogeny_dataset) %||% ""
        if (demo_selected) tree_selected <- ".__bundle_phylogeny__"
        return(shiny::tagList(
          shiny::tags$h6(class = "fw-semibold mb-2", "Data selection"),
          microbiome_field_ui("marker_type", session$ns, state$context),
          microbiome_field_ui("count_dataset", session$ns, state$context),
          microbiome_field_ui("metadata_dataset", session$ns, state$context),
          shiny::selectInput(session$ns("phylogeny_dataset"),
            "Rooted phylogenetic tree (matches OTU/ASV)",
            c(if (demo_selected) {
              "The built-in rooted tree corresponding to the current OTU table" = ".__bundle_phylogeny__"
            }, datasets), selected = tree_selected)
        ))
      }
      ids <- intersect(state$ids, general_data_ids)
      shiny::tagList(
        shiny::tags$h6(class = "fw-semibold mb-2", "Data selection"),
        lapply(ids, microbiome_field_ui, ns = session$ns, context = state$context))
    })

    output$function_analysis_expression <- shiny::renderUI({
      if (!is_function_panel) return(NULL)
      state <- general_sidebar_context()
      if (is.null(state)) return(NULL)
      stored <- saved_method_parameters(state$method$id[[1]])
      current <- list(
        function_environment_enabled = isTRUE(
          input$function_environment_enabled %||%
            stored$function_environment_enabled),
        function_environment_variables = input$function_environment_variables %||%
          stored$function_environment_variables %||% character())
      group <- input$group %||% stored$group %||% ""
      microbiome_readonly_expression(
        session$ns,
      microbiome_function_analysis_expression(
          state$method$id[[1]], group, current))
    })

    shiny::observeEvent(input$function_environment_enabled, {
      if (!is_function_panel || is.null(input$function_plot_types)) return()
      state <- general_sidebar_context()
      if (is.null(state)) return()
      plot_choices <- microbiome_function_plot_choices(
        state$method$id[[1]])
      if (!isTRUE(input$function_environment_enabled)) {
        plot_choices <- plot_choices[
          unname(plot_choices) != "function_environment_correlation"]
      }
      selected <- intersect(
        input$function_plot_types %||% character(), unname(plot_choices))
      shiny::updateSelectizeInput(
        session, "function_plot_types", choices = plot_choices,
        selected = selected, server = FALSE)
    }, ignoreInit = TRUE)

    output$general_analysis_sidebar <- shiny::renderUI({
      if (is_custom_diversity_panel) return(NULL)
      restoring_workspace <- !is.null(file_data) && isTRUE(
        file_data$workspace_restore_in_progress %||% FALSE)
      if (is_assembly_panel) shiny::req(
        !restoring_workspace, cancelOutput = TRUE)
      state <- general_sidebar_context()
      if (is.null(state)) return(NULL)
      if (is_species_environment_panel) {
        bundle <- tryCatch(preview_bundle(), error = function(error) NULL)
        rank <- input$taxonomic_rank %||% "Genus"
        aggregation <- tryCatch(
          microbiome_species_environment_aggregate(bundle, rank),
          error = function(error) NULL)
        taxa_choices <- colnames(aggregation$counts %||% matrix(numeric(), 0, 0))
        selected_taxa <- intersect(shiny::isolate(input$association_taxa) %||%
          utils::head(taxa_choices, 12L), taxa_choices)
        combined <- if (is.null(bundle)) data.frame() else
          microbiome_species_environment_metadata(aggregation$bundle)
        numeric_choices <- names(combined)[vapply(combined, is.numeric, logical(1))]
        selected_environment <- intersect(
          shiny::isolate(input$association_environment) %||%
            utils::head(numeric_choices, 4L), numeric_choices)
        categorical_choices <- names(combined)[vapply(combined, function(value) {
          count <- length(unique(value[!is.na(value)]))
          count >= 2L && (is.factor(value) || is.character(value) || is.logical(value) ||
            count <= 10L)
        }, logical(1))]
        use_grouping <- isTRUE(input$association_use_grouping)
        group <- shiny::isolate(input$association_group) %||%
          if (length(categorical_choices)) categorical_choices[[1]] else ""
        if (!group %in% categorical_choices) group <- if (length(categorical_choices))
          categorical_choices[[1]] else ""
        method_id <- state$method$id[[1]]
        group_mode <- if (identical(method_id, "species_env_spearman")) {
          "independent"
        } else {
          input$association_group_mode %||% "independent"
        }
        if (identical(method_id, "mantel_correlation")) use_grouping <- FALSE
        group_levels <- if (nzchar(group)) levels(droplevels(factor(combined[[group]]))) else
          character()
        formula <- microbiome_species_environment_formula(
          method_id, selected_taxa, selected_environment,
          use_grouping, group, group_mode)
        formula_control <- htmltools::tagQuery(shiny::textAreaInput(
          session$ns("general_model_formula"), "Model formula / analytical expression",
          value = formula, rows = 4, resize = "vertical"))$
          find("textarea")$addAttrs(readonly = "readonly")$allTags()
        return(shiny::tagList(
          shiny::selectizeInput(session$ns("association_taxa"), "species variable",
            taxa_choices, selected = selected_taxa, multiple = TRUE,
            options = list(plugins = list("remove_button"), closeAfterSelect = FALSE)),
          shiny::selectizeInput(session$ns("association_environment"), "Environmental factors",
            numeric_choices, selected = selected_environment, multiple = TRUE,
            options = list(plugins = list("remove_button"), closeAfterSelect = FALSE)),
          shiny::selectInput(session$ns("method_id"), "Analysis method",
            microbiome_panel_method_choices(
              "association", "multivariable_association", include_planned = FALSE),
            selected = state$method$id[[1]]),
          if (!identical(method_id, "mantel_correlation"))
            shiny::checkboxInput(session$ns("association_use_grouping"), "Grouping",
              value = use_grouping),
          if (use_grouping && !identical(method_id, "mantel_correlation"))
            shiny::tagList(
            shiny::selectInput(session$ns("association_group"), "Grouping variables",
              categorical_choices, selected = group),
            if (identical(method_id, "maaslin2")) {
              shiny::selectInput(session$ns("association_group_mode"), "Analysis mode",
                c("Independent grouping" = "independent", "Interactive grouping" = "interaction"),
                selected = group_mode)
            },
            if (identical(method_id, "maaslin2") &&
                identical(group_mode, "interaction")) {
              shiny::selectInput(session$ns("association_reference_group"), "Reference Group",
                group_levels, selected = shiny::isolate(input$association_reference_group) %||%
                  utils::head(group_levels, 1L))
            }
          ),
          formula_control,
          shiny::selectizeInput(session$ns("association_plot_types"), "Graphic type",
            microbiome_species_environment_plot_choices(method_id, use_grouping),
            selected = intersect(
              shiny::isolate(input$association_plot_types) %||%
                unname(microbiome_species_environment_plot_choices(
                  method_id, use_grouping)),
              unname(microbiome_species_environment_plot_choices(
                method_id, use_grouping))),
            multiple = TRUE,
            options = list(plugins = list("remove_button"), closeAfterSelect = FALSE))
        ))
      }
      if (is_cross_domain_panel) {
        bacteria <- tryCatch(
          preview_bundle(), error = function(error) NULL)
        fungi <- tryCatch(
          cross_domain_second_bundle(), error = function(error) NULL)
        return(microbiome_cross_domain_analysis_ui(
          session$ns, bacteria, fungi,
          utils::modifyList(
            saved_method_parameters(state$method$id[[1]]),
            list(
            engine = input$network_engine %||% "netcomi",
            grouped = isTRUE(input$network_grouped),
            group = shiny::isolate(input$network_group) %||% "",
            measure = input$network_measure %||% "spearman",
            threshold = input$network_threshold %||% 0.3,
            fdr = input$network_fdr %||% 0.05,
            plot_types = shiny::isolate(input$network_plot_types) %||%
              "cross_domain_network",
            bacteria_rank = input$bacteria_taxonomic_rank %||% "Genus",
            fungi_rank = input$fungi_taxonomic_rank %||% "Genus"))))
      }
      if (is_network_panel) {
        bundle <- tryCatch(preview_bundle(), error = function(error) NULL)
        rank_choices <- state$context$taxonomy_ranks %||%
          c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species")
        rank <- shiny::isolate(input$taxonomic_rank) %||%
          if ("Genus" %in% rank_choices) "Genus" else utils::head(rank_choices, 1L)
        metadata <- bundle$metadata %||% data.frame()
        categorical <- names(metadata)[vapply(metadata, function(value) {
          levels <- unique(value[!is.na(value)])
          length(levels) >= 2L && length(levels) <= 12L &&
            (is.factor(value) || is.character(value) || is.logical(value) ||
              length(levels) <= 8L)
        }, logical(1))]
        grouped <- isTRUE(input$network_grouped)
        group <- shiny::isolate(input$network_group) %||%
          if (length(categorical)) categorical[[1]] else ""
        if (!group %in% categorical) group <- if (length(categorical))
          categorical[[1]] else ""
        engine <- input$network_engine %||% "netcomi"
        if (!engine %in% unname(microbiome_network_engine_choices())) {
          engine <- "netcomi"
        }
        measure_choices <- if (identical(engine, "ggclusternet2")) {
          microbiome_ggclusternet_measure_choices()
        } else {
          microbiome_netcomi_measure_choices()
        }
        measure <- input$network_measure %||%
          if (identical(engine, "ggclusternet2")) "spearman" else
            "spieceasi"
        if (!measure %in% unname(measure_choices)) {
          measure <- unname(measure_choices)[[1]]
        }
        threshold <- input$network_threshold %||% 0.3
        fdr <- input$network_fdr %||% 0.05
        plot_choices <- if (identical(engine, "ggclusternet2")) {
          microbiome_ggclusternet_plot_choices(grouped)
        } else {
          microbiome_netcomi_plot_choices(grouped)
        }
        default_plots <- if (identical(engine, "ggclusternet2")) {
          microbiome_ggclusternet_default_plot_types(grouped)
        } else {
          microbiome_netcomi_default_plot_types(grouped)
        }
        previous_grouped <- shiny::isolate(network_plot_grouped_state())
        reset_plot_selection <- is.null(previous_grouped) ||
          !identical(previous_grouped, paste(engine, grouped, sep = "::"))
        shiny::isolate(network_plot_grouped_state(
          paste(engine, grouped, sep = "::")))
        selected_plots <- intersect(
          if (reset_plot_selection) default_plots else
            shiny::isolate(input$network_plot_types) %||% default_plots,
          unname(plot_choices))
        if (!length(selected_plots)) selected_plots <- default_plots
        comparison_requested <- identical(engine, "netcomi") && any(
          c("network_metric_forest", "centrality_difference") %in%
            selected_plots)
        network_saved <- saved_method_parameters(state$method$id[[1]])
        expression_spec <- utils::modifyList(network_saved, list(
          group_network = grouped, group = group,
          taxonomic_rank = rank, network_measure = measure,
          network_threshold = threshold, network_fdr = fdr,
          plot_types = selected_plots,
          ggcluster_scale = network_saved$ggcluster_scale %||% "rela",
          ggcluster_layout = network_saved$ggcluster_layout %||%
            "module_fr",
          ggcluster_cluster_method =
            network_saved$ggcluster_cluster_method %||%
              "cluster_fast_greedy"))
        formula <- if (identical(engine, "ggclusternet2")) {
          microbiome_ggclusternet_analysis_expression(expression_spec)
        } else {
          paste0(
            "net <- NetCoMi::netConstruct(community[", rank,
            "], measure = '", measure,
            "', zeroMethod = 'pseudo', normMethod = 'clr', ",
            "associationThreshold = ", format(threshold),
            ", fdrThreshold = ", format(fdr), ")",
            if (grouped) paste0(
              "\nNetworks fitted independently by ", group,
              if (comparison_requested) {
                "; NetCoMi::netCompare() uses permutation comparison."
              } else {
                "; permutation comparison is skipped for the selected outputs."
              }) else "",
            "\nprops <- NetCoMi::netAnalyze(net, clustMethod = 'cluster_louvain', ",
            "hubPar = 'degree', hubQuant = 0.95)")
        }
        formula_control <- htmltools::tagQuery(shiny::textAreaInput(
          session$ns("general_model_formula"), "Analyze expressions",
          value = formula, rows = 7, resize = "vertical"))$
          find("textarea")$addAttrs(readonly = "readonly")$allTags()
        expensive_plots <- intersect(
          selected_plots,
          c(
            if (identical(engine, "netcomi")) {
              c("network_metric_forest", "centrality_difference")
            },
            "robustness", "node_vulnerability",
            "stability_summary"))
        return(shiny::tagList(
          shiny::selectInput(session$ns("taxonomic_rank"), "Classification hierarchy",
            rank_choices, selected = rank),
          shiny::checkboxInput(session$ns("network_grouped"), "Packet Network",
            value = grouped),
          if (grouped) shiny::selectInput(session$ns("network_group"),
            "Grouping variables", categorical, selected = group),
          shiny::selectInput(session$ns("network_engine"), "Analysis mode",
            microbiome_network_engine_choices(), selected = engine),
          shiny::selectInput(session$ns("network_measure"), "Network inference method",
            measure_choices, selected = measure),
          shiny::sliderInput(session$ns("network_threshold"),
            "Network association threshold |association|", 0, 1,
            as.numeric(threshold), 0.01),
          shiny::sliderInput(session$ns("network_fdr"),
            "Network FDR Threshold", 0.001, 0.2, as.numeric(fdr), 0.001),
          shiny::tags$hr(class = "my-3"),
          formula_control,
          shiny::selectizeInput(session$ns("network_plot_types"), "Drawing type",
            plot_choices, selected = selected_plots, multiple = TRUE,
            options = list(closeAfterSelect = FALSE,
              plugins = list("remove_button"))),
          if (length(expensive_plots)) {
            shiny::div(
              class = "alert alert-warning py-2 small mt-2",
              "Current selections that include permutation comparisons or repeated removal stability analyses, will significantly increase run time.")
          }
        ))
      }
      if (is_function_panel) {
        bundle <- tryCatch(preview_bundle(), error = function(error) NULL)
        metadata <- bundle$metadata %||% data.frame()
        environment <- bundle$environment %||% data.frame()
        current <- utils::modifyList(
          saved_method_parameters(state$method$id[[1]]),
          list(
            group = shiny::isolate(input$group) %||% "",
            p_adjust_method = shiny::isolate(input$p_adjust_method) %||% "BH",
            funguild_confidence = shiny::isolate(
              input$funguild_confidence) %||%
              c("Highly Probable", "Probable", "Possible"),
            fungal_fr_abundance_weighted = isTRUE(shiny::isolate(
              input$fungal_fr_abundance_weighted) %||% TRUE),
            fungal_fr_percent = isTRUE(shiny::isolate(
              input$fungal_fr_percent) %||% TRUE),
            function_environment_enabled = isTRUE(shiny::isolate(
              input$function_environment_enabled)),
            function_environment_variables = shiny::isolate(
              input$function_environment_variables) %||% character(),
            plot_types = shiny::isolate(input$function_plot_types) %||%
              unname(microbiome_function_plot_choices(
                state$method$id[[1]]))))
        return(microbiome_function_analysis_ui(
          session$ns, state$method$id[[1]], metadata, current, environment))
      }
      if (is_assembly_panel) {
        bundle <- tryCatch(preview_bundle(), error = function(error) NULL)
        metadata <- bundle$metadata %||% data.frame()
        current <- utils::modifyList(
          saved_method_parameters(state$method$id[[1]]),
          list(
            group = shiny::isolate(input$group) %||% "",
            distance_method = shiny::isolate(input$distance_method) %||% "jaccard",
            abundance_weighted = isTRUE(
              shiny::isolate(input$assembly_abundance_weighted) %||% TRUE),
            n_iterations = shiny::isolate(input$n_iterations) %||% 999L,
            n_cores = shiny::isolate(input$n_cores) %||% 1L,
            icamp_bin_size = shiny::isolate(input$icamp_bin_size) %||% 24L,
            null_model_method = shiny::isolate(input$null_model_method) %||%
              "taxa.labels",
            plot_types = shiny::isolate(input$assembly_plot_types) %||%
              unname(microbiome_assembly_plot_choices(
                state$method$id[[1]]))))
        return(microbiome_assembly_analysis_ui(
          session$ns, state$method$id[[1]], metadata, current,
          session = session))
      }
      if (is_community_environment_panel) {
        method_id <- state$method$id[[1]]
        environment_choices <- state$context$field_choices$fixed_effects %||% character()
        group_choices <- state$context$field_choices$group %||% character()
        stored <- saved_method_parameters(method_id)
        selected_group <- shiny::isolate(input$community_environment_group) %||%
          stored$group_variable %||% ""
        if (!selected_group %in% group_choices) selected_group <- ""
        selected_environment <- intersect(
          shiny::isolate(input$fixed_effects) %||% utils::head(environment_choices, 3L),
          environment_choices
        )
        if (!length(selected_environment)) selected_environment <- utils::head(environment_choices, 3L)
        formula_values <- utils::modifyList(stored, list(
          group = selected_group,
          group_variable = selected_group,
          fixed_effects = selected_environment,
          distance_method = input$distance_method %||% stored$distance_method %||% "bray",
          mantel_correlation = input$mantel_correlation %||%
            stored$mantel_correlation %||% "pearson"
        ))
        formula <- microbiome_method_sidebar_formula(state$method, formula_values)
        formula_control <- htmltools::tagQuery(shiny::textAreaInput(
          session$ns("general_model_formula"), "Model formula / analytical expression",
          value = formula, rows = 4, resize = "vertical"
        ))$find("textarea")$addAttrs(readonly = "readonly")$allTags()
        plot_choices <- microbiome_community_environment_plot_choices(method_id)
        selected_plots <- intersect(
          shiny::isolate(input$environment_plot_types) %||% unname(plot_choices),
          unname(plot_choices)
        )
        if (!length(selected_plots)) selected_plots <- unname(plot_choices)
        return(shiny::tagList(
          shiny::selectInput(session$ns("community_environment_group"),
            "Grouping variable (optional)", c("Not grouped" = "", group_choices),
            selected = selected_group),
          shiny::selectizeInput(session$ns("fixed_effects"), "Environment variables",
            choices = environment_choices, selected = selected_environment,
            multiple = TRUE,
            options = list(plugins = list("remove_button"), closeAfterSelect = FALSE)),
          formula_control,
          shiny::selectizeInput(session$ns("environment_plot_types"), "Drawing type",
            choices = plot_choices, selected = selected_plots, multiple = TRUE,
            options = list(plugins = list("remove_button"), closeAfterSelect = FALSE))
        ))
      }
      schema <- microbiome_method_sidebar_schema(state$method)
      ids <- schema$fields
      controls <- lapply(ids, microbiome_field_ui, ns = session$ns, context = state$context)
      hierarchy <- NULL
      plot_control <- NULL
      if (is_composition_panel) {
        current_method <- state$method$id[[1]]
        if (identical(panel_id, "exploratory_composition")) {
          method_choices <- microbiome_species_composition_method_choices()
          selected_composition_method <- shiny::isolate(input$composition_method) %||% current_method
          if (!selected_composition_method %in% unname(method_choices)) selected_composition_method <- "taxonomic_composition"
          group_choices <- state$context$field_choices$group %||% character()
          selected_groups <- intersect(shiny::isolate(input$composition_group_variables) %||% "Treatment", group_choices)
          selected_groups <- utils::head(selected_groups, 3L)
          rank_choices <- c("ASV/OTU" = "feature", state$context$taxonomy_ranks)
          rank <- shiny::isolate(input$taxonomic_rank) %||%
            if ("Genus" %in% unname(rank_choices)) "Genus" else unname(rank_choices)[[1]]
          if (!rank %in% unname(rank_choices)) {
            rank <- if ("Genus" %in% unname(rank_choices)) "Genus" else unname(rank_choices)[[1]]
          }
          selected_group_name <- if (length(selected_groups)) selected_groups[[1]] else ""
          selected_group_levels <- if (nzchar(selected_group_name) &&
              selected_group_name %in% names(state$context$metadata %||% data.frame())) {
            levels(droplevels(factor(state$context$metadata[[selected_group_name]])))
          } else if (nzchar(selected_group_name) &&
              selected_group_name %in% names(preview_bundle()$metadata %||% data.frame())) {
            levels(droplevels(factor(preview_bundle()$metadata[[selected_group_name]])))
          } else {
            character()
          }
          differential_method <- input$composition_differential_method %||% "ancombc2"
          if (!differential_method %in%
              unname(microbiome_differential_taxa_method_choices())) {
            differential_method <- "ancombc2"
          }
          default_ancom_mode <- if (length(selected_group_levels) == 2L) "two_group" else "global"
          available_ancom_modes <- microbiome_ancombc2_mode_choices()
          available_ancom_modes <- if (length(selected_group_levels) == 2L) {
            available_ancom_modes[available_ancom_modes == "two_group"]
          } else {
            available_ancom_modes[available_ancom_modes != "two_group"]
          }
          selected_ancom_mode <- input$composition_ancom_mode %||% default_ancom_mode
          if (!selected_ancom_mode %in% unname(available_ancom_modes)) {
            selected_ancom_mode <- default_ancom_mode
          }
          plot_choices <- microbiome_species_composition_plot_choices(
            selected_composition_method, selected_ancom_mode,
            differential_method)
          selected_plots <- if (identical(selected_composition_method, "ancombc2") &&
              identical(differential_method, "ancombc2")) {
            microbiome_ancombc2_resolve_plot_types(
              selected_ancom_mode,
              shiny::isolate(input$composition_plot_types) %||% unname(plot_choices)[1])
          } else {
            selected <- intersect(
              shiny::isolate(input$composition_plot_types) %||% unname(plot_choices)[1],
              unname(plot_choices))
            if (length(selected)) selected else utils::head(unname(plot_choices), 1L)
          }
          method_controls <- list()
          if (identical(selected_composition_method, "taxonomic_composition")) {
            abundance_test <- input$composition_abundance_test %||% "kruskal_dunn"
            p_adjust <- shiny::isolate(input$composition_p_adjust) %||% "BH"
            method_controls <- c(method_controls, list(
              dava_i18n_preserve_choice_language(shiny::selectInput(
                session$ns("composition_abundance_test"), "Statistical tests",
                microbiome_abundance_test_choices(), selected = abundance_test)),
              shiny::selectInput(session$ns("composition_p_adjust"), "Multiple comparisons",
                c("FDR (BH)" = "BH", "Bonferroni" = "bonferroni", "Holm" = "holm",
                  "Hochberg" = "hochberg", "Benjamini-Yekutieli" = "BY", "No correction" = "none"), selected = p_adjust)
            ))
            if (abundance_test %in% c("lmer", "glmmTMB")) {
              effect_structure <- input$composition_effect_structure %||% "random_intercept"
              random_choices <- setdiff(
                state$context$field_choices$random_effects %||% group_choices,
                selected_groups
              )
              slope_choices <- selected_groups
              preferred_random <- intersect(c("Block", "PlotID", "Subject", "Site"), random_choices)
              default_random <- shiny::isolate(input$composition_random_effect) %||%
                if (length(preferred_random)) preferred_random[[1]] else
                  if (length(random_choices)) random_choices[[1]] else ""
              method_controls <- c(method_controls, list(
                dava_i18n_preserve_choice_language(shiny::selectInput(
                  session$ns("composition_effect_structure"), "Random effects structure",
                  c("Repeat measurement" = "repeated", "Nested random" = "nested",
                    "Random intercept" = "random_intercept", "Random slope" = "random_slope"), selected = effect_structure))
              ))
              if (identical(effect_structure, "nested")) method_controls <- c(method_controls, list(
                shiny::selectInput(session$ns("composition_random_outer"), "Outer random variable",
                  c("Please select" = "", random_choices),
                  selected = shiny::isolate(input$composition_random_outer) %||% default_random),
                shiny::selectInput(session$ns("composition_random_inner"), "Inner nested variables",
                  c("Please select" = "", random_choices),
                  selected = shiny::isolate(input$composition_random_inner) %||%
                    if (length(setdiff(random_choices, default_random))) setdiff(random_choices, default_random)[[1]] else "")))
              if (effect_structure %in% c("repeated", "random_intercept", "random_slope")) method_controls <- c(method_controls, list(
                shiny::selectInput(session$ns("composition_random_effect"),
                  if (effect_structure == "repeated") "Repeated measurement of Subject/Plot variables" else "Random variable",
                  c("Please select" = "", random_choices), selected = default_random)))
              if (identical(effect_structure, "random_slope")) method_controls <- c(method_controls, list(
                shiny::selectInput(session$ns("composition_random_slope"), "Random slope variable",
                  c("Please select" = "", slope_choices),
                  selected = shiny::isolate(input$composition_random_slope) %||%
                    if (length(slope_choices)) slope_choices[[1]] else "")))
              if (identical(abundance_test, "glmmTMB")) method_controls <- c(method_controls, list(
                shiny::selectInput(session$ns("composition_glmm_family"), "Distribution families and links",
                  c("Beta (logit)" = "beta", "Gaussian (identity)" = "gaussian",
                    "Gamma (log)" = "Gamma"),
                  selected = shiny::isolate(input$composition_glmm_family) %||% "beta")
              ))
              if (!length(random_choices)) method_controls <- c(method_controls, list(
                shiny::div(class = "alert alert-warning py-2",
                  "There are no categorical variables available for random effects in the sample metadata.")
              ))
            }
          } else if (identical(selected_composition_method, "ancombc2") &&
              identical(differential_method, "ancombc2")) {
            significance_choices <- microbiome_composition_significance_choices(
              "ancombc2", preview_bundle()$metadata,
              if (length(selected_groups)) selected_groups[[1]] else "")
            selected_significance <- shiny::isolate(input$composition_significance_test) %||%
              unname(significance_choices)[[1]]
            metadata_names <- setdiff(
              names(preview_bundle()$metadata %||% data.frame()),
              selected_group_name)
            random_structure <- input$composition_ancom_random_structure %||% "none"
            method_controls <- list(
              dava_i18n_preserve_choice_language(shiny::selectInput(
                session$ns("composition_significance_test"), "Significance test",
                significance_choices, selected = selected_significance)),
              dava_i18n_preserve_choice_language(shiny::selectInput(
                session$ns("composition_ancom_mode"), "Analysis mode",
                available_ancom_modes, selected = selected_ancom_mode))
            )
            if (identical(selected_ancom_mode, "dunnett")) {
              method_controls <- c(method_controls, list(
                shiny::selectInput(session$ns("composition_ancom_reference"), "Reference Group",
                  selected_group_levels,
                  selected = shiny::isolate(input$composition_ancom_reference) %||%
                    if (length(selected_group_levels)) selected_group_levels[[1]] else "")
              ))
            }
            if (identical(selected_ancom_mode, "trend")) {
              selected_order <- intersect(
                shiny::isolate(input$composition_ancom_trend_order) %||% selected_group_levels,
                selected_group_levels)
              method_controls <- c(method_controls, list(
                shiny::selectizeInput(session$ns("composition_ancom_trend_order"),
                  "Confirm ordered levels (in selection order)", selected_group_levels,
                  selected = selected_order, multiple = TRUE,
                  options = list(maxItems = length(selected_group_levels),
                    closeAfterSelect = FALSE, plugins = list("remove_button")))
              ))
            }
            method_controls <- c(method_controls, list(
              shiny::selectInput(session$ns("composition_ancom_random_structure"),
                "Repeated Measures/Random Effects",
                c("Not used" = "none", "(1 | Cluster)" = "intercept",
                  "(Slope | Cluster)" = "slope", "(1 | Outer/Inner)" = "nested"),
                selected = random_structure)
            ))
            if (identical(random_structure, "intercept")) {
              cluster_selected <- input$composition_ancom_random_cluster %||% ""
              method_controls <- c(method_controls, list(
                shiny::selectInput(session$ns("composition_ancom_random_cluster"),
                  "Random intercept variable", c("Please select" = "", metadata_names),
                  selected = cluster_selected)
              ))
            } else if (identical(random_structure, "slope")) {
              cluster_selected <- input$composition_ancom_random_cluster %||% ""
              slope_selected <- input$composition_ancom_random_slope %||% ""
              if (identical(cluster_selected, slope_selected)) slope_selected <- ""
              cluster_choices <- setdiff(metadata_names,
                if (nzchar(slope_selected)) slope_selected else character())
              slope_choices <- setdiff(metadata_names,
                if (nzchar(cluster_selected)) cluster_selected else character())
              method_controls <- c(method_controls, list(
                shiny::selectInput(session$ns("composition_ancom_random_cluster"),
                  "Random intercept variable", c("Please select" = "", cluster_choices),
                  selected = cluster_selected),
                shiny::selectInput(session$ns("composition_ancom_random_slope"),
                  "Random slope variable", c("Please select" = "", slope_choices),
                  selected = slope_selected)
              ))
            } else if (identical(random_structure, "nested")) {
              outer_selected <- input$composition_ancom_random_outer %||% ""
              inner_selected <- input$composition_ancom_random_inner %||% ""
              if (identical(outer_selected, inner_selected)) inner_selected <- ""
              outer_choices <- setdiff(metadata_names,
                if (nzchar(inner_selected)) inner_selected else character())
              inner_choices <- setdiff(metadata_names,
                if (nzchar(outer_selected)) outer_selected else character())
              method_controls <- c(method_controls, list(
                shiny::selectInput(session$ns("composition_ancom_random_outer"),
                  "Outer variables", c("Please select" = "", outer_choices),
                  selected = outer_selected),
                shiny::selectInput(session$ns("composition_ancom_random_inner"),
                  "Inner variables", c("Please select" = "", inner_choices),
                  selected = inner_selected)
              ))
            }
            method_controls <- c(method_controls, list(
              shiny::selectInput(session$ns("composition_ancom_lfc_scale"), "LFC scale",
                c("Natural-log fold change" = "ln",
                  "log2 fold change" = "log2"),
                selected = shiny::isolate(input$composition_ancom_lfc_scale) %||% "ln"),
              shiny::div(class = "small text-muted mb-2",
                "Random effects variables must be explicitly selected by the study design and are not automatically inferred by the system based on column names.")
            ))
          } else if (identical(selected_composition_method, "ancombc2")) {
            current_inputs <- shiny::isolate(
              shiny::reactiveValuesToList(input, all.names = TRUE))
            method_controls <- list(
              microbiome_differential_taxa_sidebar_controls(
                session$ns, differential_method, selected_group_levels,
                current_inputs)
            )
          } else if (identical(selected_composition_method, "venn_upset")) {
            method_controls <- list(dava_i18n_preserve_choice_language(shiny::selectInput(
              session$ns("composition_set_test"), "Statistical tests",
              microbiome_set_test_choices(), selected = shiny::isolate(input$composition_set_test) %||% "jaccard_permutation")))
          }
          rank_control <- if (microbiome_species_composition_uses_taxonomic_rank(selected_composition_method)) {
            shiny::selectInput(session$ns("taxonomic_rank"), "Classification hierarchy",
              rank_choices, selected = rank)
          }
          hierarchy <- shiny::tagList(
            shiny::selectInput(session$ns("composition_method"), "Analysis method", method_choices,
              selected = selected_composition_method),
            rank_control,
            shiny::selectizeInput(session$ns("composition_group_variables"), "Grouping variables", group_choices,
              selected = selected_groups, multiple = TRUE,
              options = list(maxItems = 3, closeAfterSelect = FALSE, plugins = list("remove_button"))),
            if (identical(selected_composition_method, "ancombc2")) shiny::tagList(
              shiny::selectInput(session$ns("composition_differential_method"),
                "Screening method", microbiome_differential_taxa_method_choices(),
                selected = differential_method),
              microbiome_differential_taxa_applicability_ui(differential_method)
            ),
            method_controls,
            shiny::tags$hr(class = "my-3")
          )
          plot_control <- shiny::selectizeInput(
            session$ns("composition_plot_types"), "Drawing type", plot_choices,
              selected = selected_plots, multiple = TRUE,
              options = list(closeAfterSelect = FALSE, plugins = list("remove_button"))
          )
          controls <- list()
        } else {
          task_choices <- microbiome_composition_task_choices(panel_id, include_planned = TRUE)
          method_groups <- microbiome_composition_method_groups(panel_id, include_planned = TRUE)
          inferred_task <- names(method_groups)[vapply(method_groups, function(values) current_method %in% values, logical(1))]
          inferred_task <- if (length(inferred_task)) inferred_task[[1]] else ""
          selected_task <- shiny::isolate(input$composition_task) %||% inferred_task %||% unname(task_choices)[[1]]
          if (!selected_task %in% unname(task_choices)) selected_task <- unname(task_choices)[[1]]
          method_choices <- microbiome_method_choices_for_ids(method_groups[[selected_task]] %||% character())
          selected_composition_method <- shiny::isolate(input$composition_method) %||% current_method
          if (!selected_composition_method %in% unname(method_choices)) selected_composition_method <- unname(method_choices)[[1]]
          group <- shiny::isolate(input$group) %||% ""
          significance_choices <- microbiome_composition_significance_choices(
            selected_composition_method, preview_bundle()$metadata, group)
          selected_significance <- shiny::isolate(input$composition_significance_test)
          if (!length(selected_significance) || !selected_significance %in% unname(significance_choices)) {
            selected_significance <- unname(significance_choices)[[1]]
          }
          hierarchy <- shiny::tagList(
            shiny::selectInput(session$ns("composition_task"), "Analysis task", task_choices, selected = selected_task),
            shiny::selectInput(session$ns("composition_method"), "Analysis method", method_choices,
              selected = selected_composition_method),
            dava_i18n_preserve_choice_language(shiny::selectInput(
              session$ns("composition_significance_test"), "Significance test",
              significance_choices, selected = selected_significance)),
            shiny::tags$hr(class = "my-3")
          )
        }
      }
      formula_values <- stats::setNames(lapply(unique(c(ids, "preprocess_strategy")), function(id) {
        shiny::isolate(input[[id]]) %||% saved_method_parameters(state$method$id[[1]])[[id]]
      }), unique(c(ids, "preprocess_strategy")))
      formula <- microbiome_method_sidebar_formula(state$method, formula_values)
      if (is_composition_panel && identical(panel_id, "exploratory_composition")) {
        groups <- input$composition_group_variables %||% character()
        fixed_formula <- if (length(groups)) paste(groups, collapse = " * ") else "1"
        if (identical(state$method$id[[1]], "ancombc2")) {
          differential_method <- input$composition_differential_method %||% "ancombc2"
          if (differential_method %in% c("deseq2", "edger")) {
            engine_label <- if (identical(differential_method, "deseq2")) "DESeq2" else "edgeR"
            reference <- input$composition_differential_reference %||% "reference"
            comparison <- input$composition_differential_comparison %||% "comparison"
            formula <- paste0(engine_label, " negative-binomial count model: Count[",
              input$taxonomic_rank %||% "Genus", "] ~ ", fixed_formula,
              "; contrast = ", comparison, " vs ", reference)
          } else {
          selected_or <- function(value, fallback) {
            value <- value %||% ""
            if (nzchar(value)) value else fallback
          }
          random_formula <- switch(input$composition_ancom_random_structure %||% "none",
            intercept = paste0("(1 | ",
              selected_or(input$composition_ancom_random_cluster, "Cluster"), ")"),
            slope = paste0("(",
              selected_or(input$composition_ancom_random_slope, "Slope"), " | ",
              selected_or(input$composition_ancom_random_cluster, "Cluster"), ")"),
            nested = paste0("(1 | ",
              selected_or(input$composition_ancom_random_outer, "Outer"), "/",
              selected_or(input$composition_ancom_random_inner, "Inner"), ")"),
            "")
          formula <- paste0("FeatureAbundance[", input$taxonomic_rank %||% "Genus", "] ~ ",
            fixed_formula, if (nzchar(random_formula)) paste0(" + ", random_formula) else "")
          }
        } else {
          random_formula <- if ((input$composition_abundance_test %||% "") %in% c("lmer", "glmmTMB")) {
          switch(input$composition_effect_structure %||% "random_intercept",
            repeated = paste0("(1 | ", input$composition_random_effect %||% "Subject", ")"),
            nested = paste0("(1 | ", input$composition_random_outer %||% "Outer", "/",
              input$composition_random_inner %||% "Inner", ")"),
            random_slope = paste0("(1 + ", input$composition_random_slope %||%
              if (length(groups)) groups[[1]] else "Group", " | ",
              input$composition_random_effect %||% "Block", ")"),
            paste0("(1 | ", input$composition_random_effect %||% "Block", ")"))
          } else ""
          formula <- paste0("RelativeAbundance[", input$taxonomic_rank %||% "Genus", "] ~ ",
            fixed_formula, if (nzchar(random_formula)) paste0(" + ", random_formula) else "")
        }
      }
      formula_control <- htmltools::tagQuery(shiny::textAreaInput(session$ns("general_model_formula"),
        schema$formula_label, value = formula, rows = 3, resize = "vertical"))$
        find("textarea")$addAttrs(readonly = "readonly")$allTags()
      shiny::tagList(
        hierarchy,
        controls,
        formula_control,
        plot_control)
    })

    current_input_values <- shiny::reactive({
      method <- selected_method()
      shiny::req(method, nrow(method) == 1L)
      values <- microbiome_input_values(input)
      values$method_id <- method$id[[1]] %||% "alpha_core"
      values$count_dataset <- values$count_dataset %||% ".__method_demo__"
      if (identical(panel_id, "fungal_function")) {
        values$marker_type <- "ITS"
      }
      if (is_cross_domain_panel) {
        values$marker_type <- "16S"
        values$count_dataset <- input$count_dataset %||% ".__demo16s__"
        values$taxonomy_dataset <- input$taxonomy_dataset %||%
          ".__bundle_taxonomy__"
        values$metadata_dataset <- input$metadata_dataset %||%
          ".__bundle_metadata__"
        values$second_count_dataset <- input$second_count_dataset %||%
          ".__demoits__"
        values$second_taxonomy_dataset <-
          input$second_taxonomy_dataset %||% ".__bundle_taxonomy__"
        values$bacteria_taxonomic_rank <-
          input$bacteria_taxonomic_rank %||% "Genus"
        values$fungi_taxonomic_rank <-
          input$fungi_taxonomic_rank %||% "Genus"
      }
      # ID roles are part of the data contract for every microbiome method,
      # not diversity-only UI state. Modal inputs disappear when the dialog is
      # closed, so always rehydrate them from the per-method parameter store.
      stored <- saved_method_parameters(method$id[[1]])
      mapping_defaults <- list(
        otu_feature_id = ".__colnames__", otu_sample_id = ".__rownames__",
        taxonomy_feature_id = "Feature", metadata_sample_id = "SampleID")
      for (name in names(mapping_defaults)) {
        mapping <- input[[name]] %||% stored[[name]]
        if (!is.null(mapping)) {
          values[[name]] <- mapping
        } else if (is_custom_diversity_panel) {
          values[[name]] <- mapping_defaults[[name]]
        }
      }
      if (is_custom_diversity_panel) {
        values$rarefaction_depth_mode <- input$rarefaction_depth_mode %||%
          stored$rarefaction_depth_mode %||% "minimum"
      }
      values
    })

    preview_bundle <- shiny::reactive({
      values <- current_input_values()
      tryCatch({
        bundle <- microbiome_bundle_from_inputs(file_data, values)
        if (!is.null(shiny::isolate(preview_input_issue()))) {
          preview_input_issue(NULL)
        }
        bundle
      }, error = function(error) {
        issue <- microbiome_input_issue(error, values, category_id, panel_id)
        previous <- shiny::isolate(preview_input_issue())
        # Do not write a new timestamped issue on every reactive evaluation.
        # That creates a self-invalidating loop which leaves every dependent
        # sidebar/output permanently in the recalculating state.
        if (!identical(microbiome_input_issue_key(previous),
            microbiome_input_issue_key(issue))) {
          preview_input_issue(issue)
        }
        microbiome_invalid_preview_bundle(values, issue)
      })
    })

    shiny::observeEvent(preview_input_issue(), {
      issue <- preview_input_issue()
      if (is.null(issue)) return()
      text <- microbiome_input_issue_text(issue, interface_language())
      shiny::showNotification(
        paste0(text$summary, " ",
          dava_translate_text("\u8be6\u7ec6\u4fe1\u606f\u5df2\u5199\u5165\u201c\u8bca\u65ad\u4e0e\u9519\u8bef\u201d\u9762\u677f\u3002",
            interface_language())),
        type = "warning", duration = 6
      )
    }, ignoreInit = TRUE)

    cross_domain_second_bundle <- shiny::reactive({
      if (!is_cross_domain_panel) return(NULL)
      values <- current_input_values()
      if (identical(values$second_count_dataset, ".__demoits__")) {
        return(dava_local_demo_read("microbiome/base_its.rds"))
      }
      second_values <- values
      second_values$marker_type <- "ITS"
      second_values$count_dataset <- values$second_count_dataset
      second_values$taxonomy_dataset <- values$second_taxonomy_dataset
      microbiome_bundle_from_inputs(file_data, second_values)
    })

    output$alpha_sidebar <- shiny::renderUI({
      if (!is_alpha_panel) return(NULL)
      bundle <- preview_bundle()
      datasets <- if (is.null(file_data)) character() else microbiome_dataset_names(file_data)
      metadata_columns <- setdiff(names(bundle$metadata), "SampleID")
      group_columns <- metadata_columns[vapply(bundle$metadata[, metadata_columns, drop = FALSE], function(value) {
        unique_count <- length(unique(value[!is.na(value)]))
        (is.factor(value) || is.character(value) || is.logical(value) || unique_count <= 10L) && unique_count >= 2L
      }, logical(1))]
      group_default <- intersect(shiny::isolate(input$alpha_group_variables) %||% "Treatment", group_columns)
      shiny::tagList(
        microbiome_input_issue_ui(preview_input_issue(), interface_language()),
        shiny::tags$h6(class = "fw-semibold mb-2", "Data selection"),
        shiny::selectInput(session$ns("marker_type"), "Amplicon type", c("16S", "ITS"), selected = bundle$marker_type),
        shiny::selectInput(session$ns("count_dataset"), "OTU/ASV abundance table",
          c(stats::setNames(".__method_demo__", microbiome_method_demo_profile("alpha_core")$label), datasets),
          selected = shiny::isolate(input$count_dataset) %||% ".__method_demo__"),
        shiny::selectInput(session$ns("taxonomy_dataset"), "Classification annotation table",
          c("Provided with abundance table" = ".__bundle_taxonomy__", datasets),
          selected = shiny::isolate(input$taxonomy_dataset) %||% ".__bundle_taxonomy__"),
        shiny::selectInput(session$ns("metadata_dataset"), "sample metadata",
          c("Provided with abundance table" = ".__bundle_metadata__", datasets),
          selected = shiny::isolate(input$metadata_dataset) %||% ".__bundle_metadata__"),
        shiny::selectInput(session$ns("taxonomic_rank"), "Classification hierarchy",
          c("ASV/OTU" = "feature", "Phylum", "Class", "Order", "Family", "Genus", "Species"), selected = "feature"),
        shiny::selectizeInput(session$ns("diversity_indices"), "Diversity Indicators", microbiome_alpha_metric_choices(),
          selected = shiny::isolate(input$diversity_indices) %||% c("Observed", "Chao1", "Shannon", "Simpson", "Hill_numbers", "Pielou"),
          multiple = TRUE, options = list(closeAfterSelect = FALSE, plugins = list("remove_button"))),
        shiny::tags$hr(class = "my-3"),
        shiny::tags$h6(class = "fw-semibold mb-2", "Statistical analysis"),
        shiny::selectizeInput(session$ns("alpha_group_variables"), "Grouping variables", group_columns,
          selected = group_default, multiple = TRUE,
          options = list(closeAfterSelect = FALSE, plugins = list("remove_button"))),
        shiny::uiOutput(session$ns("alpha_stat_method_ui")),
        shiny::uiOutput(session$ns("alpha_method_controls")),
        htmltools::tagQuery(
          shiny::textAreaInput(session$ns("alpha_model_formula"), "Model formula", value = "", rows = 3, resize = "vertical"))$
          find("textarea")$addAttrs(readonly = "readonly")$allTags()
      )
    })

    diversity_sidebar_context <- shiny::reactive({
      bundle <- preview_bundle()
      datasets <- if (is.null(file_data)) character() else microbiome_dataset_names(file_data)
      phylogeny_datasets <- if (is.null(file_data)) character() else
        microbiome_phylogeny_dataset_names(file_data)
      metadata_columns <- setdiff(names(bundle$metadata), "SampleID")
      grouping_columns <- metadata_columns[vapply(bundle$metadata[, metadata_columns, drop = FALSE], function(value) {
        unique_count <- length(unique(value[!is.na(value)]))
        (is.factor(value) || is.character(value) || is.logical(value) || unique_count <= 10L) && unique_count >= 2L
      }, logical(1))]
      list(bundle = bundle, datasets = datasets,
        phylogeny_datasets = phylogeny_datasets,
        metadata_columns = metadata_columns,
        grouping_columns = grouping_columns)
    })

    diversity_first_choice <- function(values, fallback = "") {
      values <- as.character(values %||% character())
      values <- values[!is.na(values) & nzchar(values)]
      if (length(values)) values[[1]] else fallback
    }

    diversity_dataset_controls <- function(method_id, include_phylogeny = FALSE) {
      context <- diversity_sidebar_context()
      bundle <- context$bundle
      controls <- list(
        shiny::tags$h6(class = "fw-semibold mb-2", "Data selection"),
        shiny::selectInput(session$ns("marker_type"), "Amplicon type", c("16S", "ITS"), selected = bundle$marker_type),
        shiny::selectInput(session$ns("count_dataset"), "OTU/ASV abundance table",
          c(stats::setNames(".__method_demo__", microbiome_method_demo_profile(method_id)$label), context$datasets),
          selected = shiny::isolate(input$count_dataset) %||% ".__method_demo__"),
        shiny::selectInput(session$ns("taxonomy_dataset"), "Classification annotation table",
          c("Provided with abundance table" = ".__bundle_taxonomy__", context$datasets),
          selected = shiny::isolate(input$taxonomy_dataset) %||% ".__bundle_taxonomy__"),
        shiny::selectInput(session$ns("metadata_dataset"), "sample metadata",
          c("Provided with abundance table" = ".__bundle_metadata__", context$datasets),
          selected = shiny::isolate(input$metadata_dataset) %||% ".__bundle_metadata__")
      )
      if (include_phylogeny) controls <- c(controls, list(
        {
          tree_choices <- context$phylogeny_datasets %||% character()
          selected_tree <- shiny::isolate(input$phylogeny_dataset) %||%
            ".__bundle_phylogeny__"
          generated_tree <- generated_rooted_tree_dataset()
          current_is_rooted <- if (selected_tree %in% tree_choices &&
              requireNamespace("ape", quietly = TRUE)) {
            tryCatch(ape::is.rooted(microbiome_phylogeny_dataset_get(
              file_data, selected_tree)), error = function(error) FALSE)
          } else {
            FALSE
          }
          if (nzchar(generated_tree) && generated_tree %in% tree_choices &&
              !isTRUE(current_is_rooted)) {
            selected_tree <- generated_tree
          }
          shiny::selectInput(session$ns("phylogeny_dataset"),
            "Phylogenetic tree",
            c("Supplied with exclusive simulation data" = ".__bundle_phylogeny__",
              stats::setNames(tree_choices, tree_choices)),
            selected = selected_tree)
        }))
      controls <- c(controls, list(
        shiny::selectInput(session$ns("taxonomic_rank"), "Classification hierarchy",
          c("ASV/OTU" = "feature", "Phylum", "Class", "Order", "Family", "Genus", "Species"),
          selected = shiny::isolate(input$taxonomic_rank) %||% "feature")))
      do.call(shiny::tagList, controls)
    }

    output$beta_data_sidebar <- shiny::renderUI({
      if (!is_beta_panel) return(NULL)
      method <- selected_method()
      if (is.null(method)) return(NULL)
      diversity_dataset_controls(method$id[[1]])
    })

    output$beta_analysis_sidebar <- shiny::renderUI({
      if (!is_beta_panel) return(NULL)
      context <- diversity_sidebar_context()
      method <- selected_method()
      if (is.null(method)) return(NULL)
      method_id <- method$id[[1]]
      selected_ordination <- shiny::isolate(input$beta_ordination_method) %||% method_id
      if (!selected_ordination %in% beta_ordination_methods) selected_ordination <- "pcoa"
      ordination_choices <- microbiome_method_choices_for_ids(beta_ordination_methods)
      groups <- context$grouping_columns
      selected_groups <- intersect(shiny::isolate(input$beta_group_variables) %||% "Treatment", groups)
      if (!length(selected_groups)) selected_groups <- intersect("Treatment", groups)
      distance <- shiny::isolate(input$beta_distance) %||% "bray"
      significance <- shiny::isolate(input$beta_significance_test) %||% "permanova_permdisp"
      controls <- list(
        shiny::selectInput(session$ns("beta_ordination_method"), "Sorting method",
          ordination_choices, selected = selected_ordination),
        shiny::selectizeInput(session$ns("beta_group_variables"), "Grouping variables", groups,
          selected = selected_groups, multiple = TRUE,
          options = list(closeAfterSelect = FALSE, plugins = list("remove_button"))),
        shiny::selectInput(session$ns("beta_distance"), "Distance algorithm",
          c("Bray-Curtis" = "bray", "Jaccard" = "jaccard", "Euclidean" = "euclidean",
            "Hellinger" = "hellinger", "Aitchison" = "aitchison"), selected = distance),
        shiny::uiOutput(session$ns("beta_model_formula_ui")),
        dava_i18n_preserve_choice_language(shiny::selectInput(
          session$ns("beta_significance_test"), "Community difference significance test",
          c("PERMANOVA + PERMDISP" = "permanova_permdisp", "PERMANOVA" = "permanova",
            "PERMDISP / betadisper" = "permdisp", "ANOSIM" = "anosim", "MRPP" = "mrpp",
            "No significance test" = "none"), selected = significance)),
        shiny::conditionalPanel(
          sprintf("input['%s'] !== 'none'", session$ns("beta_significance_test")),
          shiny::numericInput(session$ns("beta_permutations"), "Number of replacements",
            value = shiny::isolate(input$beta_permutations) %||% 999L, min = 99L, step = 100L))
      )
      do.call(shiny::tagList, controls)
    })

    output$beta_model_formula_ui <- shiny::renderUI({
      if (!is_beta_panel) return(NULL)
      groups <- input$beta_group_variables %||% character()
      formula <- paste("community distance ~",
        if (length(groups)) paste(groups, collapse = " + ") else "1")
      htmltools::tagQuery(
        shiny::textAreaInput(session$ns("beta_model_formula"), "Model formula / analytical expression",
          value = formula, rows = 3, resize = "vertical"))$
        find("textarea")$addAttrs(readonly = "readonly")$allTags()
    })

    output$phylogenetic_data_sidebar <- shiny::renderUI({
      if (!is_phylogenetic_panel) return(NULL)
      method <- selected_method()
      if (is.null(method)) return(NULL)
      if (identical(method$id[[1]], "phylogenetic_tree_build")) {
        context <- diversity_sidebar_context()
        method_context <- general_sidebar_context()$context
        source <- input$phylo_build_source %||%
          "representative_sequences"
        selected_count <- shiny::isolate(input$count_dataset) %||%
          ".__method_demo__"
        demo_selected <- selected_count %in% c(
          ".__method_demo__", ".__demo16s__", ".__demoits__")
        controls <- list(
          shiny::tags$h6(class = "fw-semibold mb-2", "Data selection"),
          shiny::selectInput(session$ns("marker_type"), "Amplicon type",
            c("16S", "ITS"), selected = context$bundle$marker_type),
          shiny::selectInput(session$ns("count_dataset"), "OTU/ASV abundance table",
            c(stats::setNames(".__method_demo__",
              microbiome_method_demo_profile(method$id[[1]])$label),
              context$datasets), selected = selected_count)
        )
        if (identical(source, "newick")) {
          tree_choices <- if (is.null(file_data)) character() else
            microbiome_phylogeny_dataset_names(file_data)
          selected_tree <- shiny::isolate(input$phylogeny_dataset) %||% ""
          if (demo_selected) selected_tree <- ".__bundle_phylogeny__"
          if (!demo_selected && !selected_tree %in% tree_choices) {
            selected_tree <- utils::head(tree_choices, 1L)
          }
          controls <- c(controls, list(
            shiny::selectInput(session$ns("phylogeny_dataset"),
              "Phylogenetic tree (Newick/.nwk/.tree/.tre/phylo)",
              c(if (demo_selected) {
                "Phylogenetic tree of the current simulated OTU table" = ".__bundle_phylogeny__"
              }, stats::setNames(tree_choices, tree_choices)),
              selected = selected_tree)))
        } else {
          sequence_choices <- method_context$sequence_datasets %||% character()
          if (demo_selected) {
            sequence_choices <- c(
              "Representative sequence of the current analog OTU table" = ".__bundle_sequences__",
              sequence_choices)
          }
          selected_sequence <- shiny::isolate(input$sequence_dataset) %||%
            method_context$default_sequence_dataset %||% ""
          if (demo_selected) selected_sequence <- ".__bundle_sequences__"
          controls <- c(controls, list(
            shiny::selectInput(session$ns("sequence_dataset"),
              "Representative sequence FASTA/data table", sequence_choices,
              selected = selected_sequence)))
        }
        controls <- c(controls, list(
          shiny::uiOutput(session$ns("phylogenetic_tree_input_status"))))
        return(do.call(shiny::tagList, controls))
      }
      shiny::tagList(
        diversity_dataset_controls(method$id[[1]], include_phylogeny = TRUE),
        shiny::uiOutput(session$ns("phylogenetic_tree_input_status"))
      )
    })

    output$phylogenetic_tree_input_status <- shiny::renderUI({
      if (!is_phylogenetic_panel) return(NULL)
      method <- selected_method()
      if (is.null(method)) return(NULL)
      is_builder <- identical(method$id[[1]], "phylogenetic_tree_build")
      if (is_builder && !identical(
          input$phylo_build_source %||% "representative_sequences", "newick")) {
        return(NULL)
      }
      tree <- preview_bundle()$phylogeny
      if (is.null(tree) || !inherits(tree, "phylo") ||
          !requireNamespace("ape", quietly = TRUE)) return(NULL)
      if (ape::Nnode(tree) <= 1L) {
        return(shiny::div(class = "alert alert-danger py-2 px-3 mt-2 mb-0",
          "A phylogenetic tree with no internal nodes or stars was detected and cannot be used for phylogenetic distance analysis."))
      }
      if (!ape::is.rooted(tree)) {
        rooting <- input$phylo_build_rooting %||% "midpoint"
        if (is_builder && identical(rooting, "midpoint")) {
          return(shiny::div(class = "alert alert-warning py-2 px-3 mt-2 mb-0",
            "Unrooted phylogenetic tree detected; midpoint rooting will be used after running the build."))
        }
        return(shiny::div(class = "alert alert-danger py-2 px-3 mt-2 mb-0",
          "Unrooted phylogenetic tree detected. Please use Phylogenetic Tree Builder to perform midpoint rooting."))
      }
      feature_ids <- colnames(microbiome_numeric_matrix(
        preview_bundle()$counts))
      matching <- microbiome_phylogenetic_tip_diagnostics(feature_ids, tree)
      missing_tree <- sum(matching$Status == "missing_from_tree")
      missing_abundance <- sum(matching$Status == "missing_from_abundance")
      if (missing_tree || missing_abundance) {
        return(shiny::div(class = "alert alert-danger py-2 px-3 mt-2 mb-0",
          sprintf(paste0(
            "tip tag does not exactly match OTU/ASV feature ID: %d missing from tree,",
            "%d are missing from the abundance table. Names are case and symbol sensitive."),
            missing_tree, missing_abundance)))
      }
      shiny::div(class = "alert alert-success py-2 px-3 mt-2 mb-0",
        "The phylogenetic tree was identified as a rooted tree, with tip tags matching the OTU/ASV signature IDs exactly.")
    })

    output$phylogenetic_analysis_sidebar <- shiny::renderUI({
      if (!is_phylogenetic_panel) return(NULL)
      context <- diversity_sidebar_context()
      method <- selected_method()
      if (is.null(method)) return(NULL)
      method_id <- method$id[[1]]
      if (identical(method_id, "phylogenetic_tree_build")) {
        source <- input$phylo_build_source %||%
          "representative_sequences"
        feature_count <- ncol(microbiome_numeric_matrix(
          context$bundle$counts))
        max_ml_tips <- suppressWarnings(as.integer(
          input$phylo_build_max_ml_tips %||% 2000L))
        if (!length(max_ml_tips) || !is.finite(max_ml_tips) ||
            max_ml_tips < 3L) max_ml_tips <- 2000L
        requested_algorithm <- input$phylo_build_algorithm %||%
          if (feature_count > max_ml_tips) "nj" else "ml"
        algorithm_switched <- identical(requested_algorithm, "ml") &&
          feature_count > max_ml_tips
        algorithm <- if (algorithm_switched) "nj" else requested_algorithm
        large_threshold <- suppressWarnings(as.integer(
          input$phylo_build_large_dataset_threshold %||% 2000L))
        if (!length(large_threshold) || !is.finite(large_threshold) ||
            large_threshold < 3L) large_threshold <- 2000L
        alignment_preset <- input$phylo_build_alignment_preset %||% "auto"
        fast_alignment <- identical(alignment_preset, "fast") ||
          (identical(alignment_preset, "auto") &&
            feature_count > large_threshold)
        available_processors <- dava_available_cores(logical = TRUE)
        processors <- suppressWarnings(as.integer(
          input$phylo_build_processors %||% available_processors))
        if (!length(processors) || !is.finite(processors) ||
            processors < 1L) processors <- available_processors
        processors <- min(processors, available_processors)
        distance_memory_gib <- feature_count *
          max(feature_count - 1L, 0L) * 4 / 1024^3
        rooting <- input$phylo_build_rooting %||% "midpoint"
        if (identical(source, "representative_sequences")) rooting <- "midpoint"
        expression <- if (identical(source, "representative_sequences")) {
          paste0("DECIPHER::AlignSeqs -> phangorn::",
            if (identical(algorithm, "nj")) "NJ" else "optim.pml(GTR+G)",
            " -> phangorn::midpoint")
        } else {
          paste0("ape::read.tree -> ",
            if (identical(rooting, "midpoint")) {
              "phangorn::midpoint"
            } else {
              "Keep existing roots"
            })
        }
        return(shiny::tagList(
          shiny::selectInput(session$ns("phylo_build_source"), "Build method",
            c("Constructed from ASV/OTU representative sequence" = "representative_sequences",
              "Read Newick/.tre/phylo and root" = "newick"),
            selected = source),
          if (identical(source, "representative_sequences") &&
              (feature_count > large_threshold || algorithm_switched)) {
            shiny::div(
              class = "alert alert-warning py-2 px-3 mb-2",
              sprintf(paste0(
                "%s tips detected: using %d parallel threads, %s.",
                "Distance vectors are expected to take at least ~%.2f GiB of memory."),
                format(feature_count, big.mark = ","), processors,
                if (fast_alignment) {
                  "Automatic quick comparison is enabled"
                } else {
                  "Currently using standard comparison"
                },
                distance_memory_gib),
              if (algorithm_switched) shiny::tags$div(
                class = "small mt-1",
                sprintf("ML capped at %s tips, switched to NJ before run.",
                  format(max_ml_tips, big.mark = ",")))
            )
          },
          if (identical(source, "representative_sequences")) {
            shiny::selectInput(session$ns("phylo_build_algorithm"),
              "Tree building algorithm",
              c("Maximum likelihood ML (GTR+G, recommended)" = "ml",
                "Neighbor Joining NJ (Quick Trial)" = "nj"), selected = algorithm)
          },
          shiny::selectInput(session$ns("phylo_build_rooting"), "Fixed root method",
            if (identical(source, "representative_sequences")) {
              c("midpoint midpoint fixed root" = "midpoint")
            } else {
              c("midpoint midpoint root (recommended)" = "midpoint",
                "Keep existing roots" = "preserve")
            },
            selected = rooting),
          shiny::selectizeInput(session$ns("phylogenetic_plot_types"),
            "Drawing type", microbiome_phylogenetic_plot_choices(method_id),
            selected = "phylo_build_tree", multiple = TRUE,
            options = list(closeAfterSelect = FALSE,
              plugins = list("remove_button"))),
          htmltools::tagQuery(shiny::textAreaInput(
            session$ns("phylogenetic_model_formula"),
            "Build process", value = expression, rows = 3,
            resize = "vertical"))$find("textarea")$
            addAttrs(readonly = "readonly")$allTags()
        ))
      }
      groups <- context$grouping_columns
      group <- diversity_first_choice(c(shiny::isolate(input$phylogenetic_group), intersect("Treatment", groups), groups))
      if (!group %in% groups) group <- diversity_first_choice(groups)
      test_method <- shiny::isolate(input$phylogenetic_test_method) %||% "kruskal"
      plot_choices <- microbiome_phylogenetic_plot_choices(method_id)
      selected_plots <- intersect(
        shiny::isolate(input$phylogenetic_plot_types) %||%
          unname(plot_choices), unname(plot_choices))
      if (!length(selected_plots)) selected_plots <- unname(plot_choices)
      formula <- switch(method_id,
        faith_pd = sprintf("Faith's PD ~ %s", group %||% "1"),
        mpd_mntd_nri_nti = sprintf(
          "PD + MPD + MNTD + SES.PD + SES.MPD + SES.MNTD ~ %s",
          group %||% "1"),
        phylogenetic_tree = paste0(
          "microeco::trans_phylo$new(microtable, group_col = '",
          shiny::isolate(input$phylo_tree_group_col) %||% "Phylum",
          "')$plot_tree()"),
        if (identical(test_method, "none") || !nzchar(group)) {
          "Phylogenetic diversity ~ 1"
        } else paste("Phylogenetic diversity ~", group))
      controls <- list(
        shiny::selectInput(session$ns("phylogenetic_group"), "Grouping variables", groups, selected = group),
        if (!identical(method_id, "phylogenetic_tree")) dava_i18n_preserve_choice_language(shiny::selectInput(
          session$ns("phylogenetic_test_method"), "Significance test",
          c("Kruskal-Wallis + Dunn/Wilcoxon" = "kruskal", "Only diversity metrics are calculated" = "none"), selected = test_method))
      )
      if (method_id != "phylogenetic_tree") controls <- c(controls, list(
        shiny::selectInput(session$ns("phylogenetic_null_model"), "Empty model",
          c("Taxa labels" = "taxa_labels", "Richness" = "richness", "Frequency" = "frequency",
            "Independent swap" = "independentswap"), selected = shiny::isolate(input$phylogenetic_null_model) %||% "taxa_labels"),
        shiny::numericInput(session$ns("phylogenetic_iterations"), "Number of randomizations",
          value = shiny::isolate(input$phylogenetic_iterations) %||% 999L, min = 99L, step = 100L)))
      if (!identical(method_id, "phylogenetic_tree") &&
          !identical(test_method, "none")) controls <- c(controls, list(
        dava_i18n_preserve_choice_language(shiny::selectInput(
          session$ns("phylogenetic_p_adjust"), "Multiple comparison correction",
          c("FDR (BH)" = "BH", "Bonferroni" = "bonferroni", "Holm" = "holm"),
          selected = shiny::isolate(input$phylogenetic_p_adjust) %||% "BH"))))
      controls <- c(controls, list(
        shiny::selectizeInput(session$ns("phylogenetic_plot_types"), "Drawing type",
          plot_choices, selected = selected_plots, multiple = TRUE,
          options = list(closeAfterSelect = FALSE,
            plugins = list("remove_button"))),
        htmltools::tagQuery(
          shiny::textAreaInput(session$ns("phylogenetic_model_formula"),
            "Model formula / analytical expression", value = formula, rows = 3,
            resize = "vertical"))$find("textarea")$
          addAttrs(readonly = "readonly")$allTags()))
      do.call(shiny::tagList, controls)
    })

    output$alpha_stat_method_ui <- shiny::renderUI({
      bundle <- preview_bundle()
      choices <- microbiome_alpha_stat_method_choices(bundle$metadata, input$alpha_group_variables %||% character())
      selected <- input$alpha_stat_method
      if (!length(selected) || !selected %in% unname(choices)) selected <- unname(choices)[[1]]
      shiny::selectInput(session$ns("alpha_stat_method"), "Analysis method", choices, selected = selected)
    })

    output$alpha_method_controls <- shiny::renderUI({
      method <- input$alpha_stat_method %||% "descriptive"
      bundle <- preview_bundle()
      groups <- input$alpha_group_variables %||% character()
      if (method %in% c("t_test", "welch_t")) return(
        shiny::checkboxInput(session$ns("alpha_paired"), "Paired samples", FALSE))
      if (method %in% c("one_way_anova", "factorial_anova", "interaction_anova", "kruskal")) return(
        shiny::selectInput(session$ns("alpha_posthoc"), "Post-hoc comparison",
          if (method == "kruskal") c("Dunn/Wilcoxon" = "dunn", "None" = "none") else c("Tukey HSD" = "tukey", "None" = "none")))
      if (identical(method, "lmm")) {
        random_choices <- setdiff(names(bundle$metadata), groups)
        preferred <- intersect(c("Block", "PlotID"), random_choices)
        default_random <- if (length(preferred)) preferred[[1]] else if (length(random_choices)) random_choices[[1]] else ""
        return(shiny::selectInput(session$ns("alpha_random_effect"), "Random-effect variable", random_choices,
          selected = default_random))
      }
      NULL
    })

    shiny::observe({
      if (!is_alpha_panel) return()
      formula <- microbiome_alpha_formula(input$alpha_group_variables %||% character(),
        input$alpha_stat_method %||% "descriptive", input$alpha_random_effect %||% "")
      shiny::updateTextAreaInput(session, "alpha_model_formula", value = formula)
    })
    method_ui_context <- shiny::reactive({
      datasets <- if (is.null(file_data)) character() else microbiome_dataset_names(file_data)
      selected <- input$count_dataset %||% ".__method_demo__"
      demo <- microbiome_demo_for_method(selected_method()$id[[1]])
      is_demo <- selected %in% c(".__method_demo__", ".__demo16s__", ".__demoits__") || is.null(file_data)
      dataset_columns <- function(name, fallback) {
        if (is_demo || !nzchar(name %||% "") || startsWith(name, ".__bundle_")) return(names(fallback))
        names(file_data$global_datasets[[name]] %||% data.frame())
      }
      count_columns <- dataset_columns(selected, demo$counts)
      taxonomy_columns <- dataset_columns(input$taxonomy_dataset %||% "", demo$taxonomy)
      metadata_columns <- dataset_columns(input$metadata_dataset %||% "", demo$metadata)
      columns <- unique(c(count_columns, taxonomy_columns, metadata_columns))
      all_ids <- microbiome_field_catalog()$id
      live <- stats::setNames(lapply(all_ids, function(field) shiny::isolate(input[[field]])), all_ids)
      live <- live[!vapply(live, is.null, logical(1))]
      minimum_depth <- tryCatch(
        microbiome_resolve_rarefaction_depth(
          preview_bundle(), list(rarefaction_depth_mode = "minimum")),
        error = function(error) NA_integer_)
      list(datasets = datasets, columns = columns, metadata = preview_bundle()$metadata,
        count_columns = count_columns, taxonomy_columns = taxonomy_columns, metadata_columns = metadata_columns,
        minimum_depth = minimum_depth,
        groups = input$alpha_group_variables %||% character(),
        demo_label = microbiome_method_demo_profile(selected_method()$id[[1]])$label,
        language = interface_language(),
        current_values = utils::modifyList(live, saved_method_parameters()))
    })
    shiny::observeEvent(input$open_preprocessing, {
      method <- selected_method()
      shiny::req(!is.null(method))
      preprocessing_context <- method_ui_context()
      shiny::showModal(shiny::modalDialog(
        title = "Data inspection and preprocessing",
        microbiome_preprocessing_ui(session$ns, method, preprocessing_context),
        if (is_species_environment_panel) {
          shiny::tagList(
            shiny::tags$hr(),
            microbiome_species_environment_precheck_ui(
              session$ns, saved_method_parameters(method$id[[1]])))
        },
        shiny::actionButton(session$ns("run_precheck"), "Run data check", icon = shiny::icon("magnifying-glass"), class = "btn-outline-primary btn-sm"),
        shiny::uiOutput(session$ns("precheck_summary")),
        footer = shiny::tagList(shiny::modalButton("Cancel"),
          shiny::actionButton(session$ns("apply_preprocessing"), "Apply settings", class = "btn-primary")),
        size = "l", easyClose = TRUE
      ))
      current <- preprocessing_context$current_values %||% list()
      id_specs <- list(
        otu_feature_id = list(preprocessing_context$count_columns,
          ".__colnames__"),
        otu_sample_id = list(preprocessing_context$count_columns,
          ".__rownames__"),
        taxonomy_feature_id = list(preprocessing_context$taxonomy_columns,
          if ("Feature" %in% (preprocessing_context$taxonomy_columns %||%
              character())) "Feature" else ".__rownames__"),
        metadata_sample_id = list(preprocessing_context$metadata_columns,
          if ("SampleID" %in% (preprocessing_context$metadata_columns %||%
              character())) "SampleID" else ".__rownames__")
      )
      session$onFlushed(function() {
        for (id in names(id_specs)) {
          columns <- unique(as.character(id_specs[[id]][[1]] %||% character()))
          columns <- columns[!is.na(columns) & nzchar(columns)]
          choices <- c("row name" = ".__rownames__", "Listing" = ".__colnames__",
            stats::setNames(columns, columns))
          selected <- current[[id]] %||% id_specs[[id]][[2]]
          if (!length(selected) || !selected %in% unname(choices)) {
            selected <- id_specs[[id]][[2]]
          }
          shiny::updateSelectizeInput(session, id, choices = choices,
            selected = selected, server = TRUE)
        }
      }, once = TRUE)
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$apply_preprocessing, {
      ids <- c("preprocess_strategy", "rarefaction_depth", "rarefaction_depth_mode",
        "pseudocount", "minimum_total", "minimum_prevalence",
        "otu_feature_id", "otu_sample_id", "taxonomy_feature_id", "metadata_sample_id")
      if (is_species_environment_panel) {
        ids <- c(ids, "association_correlation_threshold",
          "association_vif_threshold")
      }
      save_method_parameters(active_method_id(), unique(ids))
      shiny::removeModal()
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$run_precheck, {
      progress <- dava_progress(session, min = 0, max = 1)
      on.exit(progress$close(), add = TRUE)
      progress$set(
        message = tr("Run microbiological data check"),
        detail = tr("Reading data and preprocessing parameters"),
        value = 0.15
      )
      values <- current_input_values()
      values <- utils::modifyList(values, saved_method_parameters())
      if (is_species_environment_panel) {
        values$taxonomic_rank <- input$taxonomic_rank %||% "Genus"
        values$taxa_variables <- input$association_taxa %||% character()
        values$environment_factors <- input$association_environment %||% character()
        values$use_grouping <- isTRUE(input$association_use_grouping) &&
          !identical(method$id[[1]], "mantel_correlation")
        values$group <- if (values$use_grouping) input$association_group %||% "" else ""
        values$environment_correlation_threshold <-
          input$association_correlation_threshold %||% 0.8
        values$vif_threshold <- input$association_vif_threshold %||% 10
      }
      bundle <- microbiome_bundle_from_inputs(file_data, values)
      progress$set(detail = tr("Calculating sequencing depth, sparsity and data quality"), value = 0.5)
      base_diagnostics <- microbiome_preprocessing_diagnostics(bundle, values)
      if (is_species_environment_panel) {
        base_diagnostics$species_environment <-
          microbiome_species_environment_diagnostics(bundle, values)
      }
      precheck(base_diagnostics)
      progress$set(detail = tr("Organize inspection results"), value = 0.95)
    }, ignoreInit = TRUE)
    output$precheck_summary <- shiny::renderUI({
      value <- precheck()
      if (is.null(value)) return(NULL)
      if (is_species_environment_panel) {
        association <- value$species_environment
        return(shiny::div(class = "alert alert-light border mt-3",
          shiny::tags$strong("Species-environment diagnostic summary"),
          shiny::tags$div(sprintf("Selected environmental factors: %d",
            nrow(association$vif))),
          shiny::tags$div(sprintf("High-correlation pairs: %d",
            nrow(association$high_correlation))),
          shiny::tags$div(sprintf("Environmental factors above VIF threshold: %d",
            sum(association$vif$ExceedsThreshold, na.rm = TRUE)))))
      }
      depth <- value$tables$sequencing_depth
      rare <- value$tables$rare_feature_summary
      environment <- value$tables$environment_quality
      shiny::div(class = "alert alert-light border mt-3",
        shiny::tags$strong("Diagnostic summary"),
        shiny::tags$div(sprintf("Samples: %d; median depth: %s", nrow(depth), format(stats::median(depth$SequencingDepth), big.mark = ","))),
        shiny::tags$div(sprintf("Rare feature fraction: %.1f%%", 100 * rare$value[rare$metric == "rare_feature_fraction"])),
        shiny::tags$div(sprintf("Potential PCoA outliers: %d", sum(value$tables$bray_pcoa_scores$Outlier %||% FALSE))),
        shiny::tags$div(sprintf("Environmental variables with VIF > 10: %d", sum(environment$vif > 10, na.rm = TRUE))))
    })
    shiny::observeEvent(input$open_advanced, {
      method <- selected_method()
      shiny::req(!is.null(method))
      shiny::showModal(shiny::modalDialog(
        title = paste("Advanced parameters -", method$label_cn[[1]]),
        if (is_alpha_panel) {
          microbiome_alpha_advanced_controls_ui(session$ns,
            input$alpha_stat_method %||% "descriptive", method_ui_context())
        } else if (is_composition_panel && identical(panel_id, "exploratory_composition")) {
          advanced_context <- method_ui_context()
          advanced_group <- input$composition_group_variables %||% character()
          advanced_group <- if (length(advanced_group)) advanced_group[[1]] else ""
          advanced_context$group_levels <- if (nzchar(advanced_group) &&
              advanced_group %in% names(preview_bundle()$metadata %||% data.frame())) {
            levels(droplevels(factor(preview_bundle()$metadata[[advanced_group]])))
          } else {
            character()
          }
          advanced_context$analysis_mode <- input$composition_ancom_mode %||% ""
          advanced_context$differential_method <-
            input$composition_differential_method %||% "ancombc2"
          if (identical(advanced_context$analysis_mode, "trend")) {
            confirmed_order <- as.character(input$composition_ancom_trend_order %||% character())
            if (length(confirmed_order)) advanced_context$group_levels <- confirmed_order
          }
          microbiome_species_composition_advanced_controls_ui(
            session$ns, method$id[[1]], advanced_context)
        } else if (is_species_environment_panel) {
          microbiome_species_environment_advanced_ui(
            session$ns, method$id[[1]], saved_method_parameters(method$id[[1]]))
        } else if (is_phylogenetic_panel) {
          advanced_context <- method_ui_context()
          advanced_context$taxonomy_columns <- names(preview_bundle()$taxonomy %||% data.frame())
          advanced_context$current_values <- saved_method_parameters(method$id[[1]])
          microbiome_phylogenetic_advanced_controls_ui(
            session$ns, method$id[[1]], advanced_context)
        } else if (identical(method$id[[1]], "tax4fun2")) {
          microbiome_tax4fun2_advanced_ui(
            session$ns, saved_method_parameters(method$id[[1]]))
        } else if (is_assembly_panel &&
            identical(method$id[[1]], "ncm")) {
          microbiome_ncm_advanced_ui(
            session$ns, saved_method_parameters(method$id[[1]]))
        } else if (is_network_panel) {
          if (identical(
              input$network_engine %||% "netcomi",
              "ggclusternet2")) {
            microbiome_ggclusternet_advanced_ui(
              session$ns,
              saved_method_parameters(method$id[[1]]),
              cross_domain = is_cross_domain_panel)
          } else if (is_cross_domain_panel) {
            microbiome_cross_domain_advanced_ui(
              session$ns, saved_method_parameters(method$id[[1]]))
          } else {
            microbiome_netcomi_advanced_ui(
              session$ns, saved_method_parameters(method$id[[1]]))
          }
        } else if (is_community_environment_panel) {
          microbiome_community_environment_advanced_ui(
            session$ns, method$id[[1]], saved_method_parameters(method$id[[1]]))
        } else {
          microbiome_advanced_controls_ui(session$ns, method, method_ui_context())
        },
        footer = shiny::tagList(shiny::modalButton("Cancel"),
          shiny::actionButton(session$ns("apply_advanced"), "Apply settings", class = "btn-primary")),
        size = "l", easyClose = TRUE
      ))
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$tax4fun2_download_reference, {
      method <- selected_method()
      shiny::req(!is.null(method), identical(method$id[[1]], "tax4fun2"))
      current_path <- input$tax4fun2_reference_path %||%
        microbiome_tax4fun2_reference_path()
      default_parent <- if (dir.exists(current_path)) {
        dirname(current_path)
      } else {
        dirname(microbiome_tax4fun2_reference_path())
      }
      destination_parent <- microbiome_choose_directory(
        default = default_parent,
        caption = "Select Tax4Fun2_ReferenceData_v2 download and unzip directory")
      if (is.na(destination_parent) || !nzchar(destination_parent)) return()
      tryCatch({
        result <- dava_with_progress(
          message = "Downloading Tax4Fun2_ReferenceData_v2",
          detail = "The download will be automatically decompressed, please do not close the application.",
          value = 0.2, {
            downloaded <- microbiome_download_tax4fun2_reference(
              destination_parent,
              input$tax4fun2_reference_source %||% "GitHub")
            dava_inc_progress(0.8, detail = "Reference database has been unpacked")
            downloaded
          })
        shiny::updateTextInput(
          session, "tax4fun2_reference_path", value = result$path)
        shiny::showNotification(
          paste0("Tax4Fun2 reference database passed ", result$source,
            " Download and unzip:", result$path),
          type = "message", duration = 10)
      }, error = function(error) {
        shiny::showNotification(
          conditionMessage(error), type = "error", duration = NULL)
      })
    }, ignoreInit = TRUE)
    output$tax4fun2_blast_status <- shiny::renderUI({
      method <- selected_method()
      if (is.null(method) || !identical(method$id[[1]], "tax4fun2")) {
        return(NULL)
      }
      configured_path <- trimws(input$tax4fun2_blast_path %||% "")
      executable_names <- if (.Platform$OS.type == "windows") {
        c("blastn.exe", "blastn")
      } else {
        "blastn"
      }
      configured_binary <- if (nzchar(configured_path)) {
        candidates <- file.path(configured_path, executable_names)
        candidates <- candidates[file.exists(candidates)]
        if (length(candidates)) candidates[[1]] else ""
      } else {
        ""
      }
      path_binary <- Sys.which("blastn")
      if (nzchar(configured_binary) || nzchar(path_binary)) {
        binary <- if (nzchar(configured_binary)) configured_binary else path_binary
        return(shiny::div(
          class = "alert alert-success py-2 mb-2",
          shiny::icon("check-circle"),
          paste0(" Found blastn:", binary)))
      }
      message <- if (nzchar(configured_path)) {
        "blastn was not found in the directory filled in. Please confirm that this directory is the bin folder of NCBI BLAST."
      } else {
        paste(
          "blastn not found in current PATH. After installing BLAST,",
          "Please fill in the NCBI BLAST bin path into the input box above.")
      }
      shiny::div(
        class = "alert alert-warning py-2 mb-2",
        shiny::icon("exclamation-triangle"), paste0(" ", message))
    })
    shiny::observeEvent(input$apply_advanced, {
      method <- selected_method()
      shiny::req(!is.null(method))
      advanced_ids <- if (is_alpha_panel) {
        c("alpha_p_adjust", "alpha_conf_level", "alpha_reml", "alpha_diagnostics", "alpha_seed")
      } else if (is_composition_panel && identical(panel_id, "exploratory_composition")) {
        microbiome_species_composition_advanced_field_ids(
          method$id[[1]], input$composition_differential_method %||% "ancombc2")
      } else if (is_species_environment_panel) {
        microbiome_species_environment_advanced_field_ids(method$id[[1]])
      } else if (is_phylogenetic_panel) {
        microbiome_phylogenetic_advanced_field_ids(method$id[[1]])
      } else if (identical(method$id[[1]], "tax4fun2")) {
        microbiome_tax4fun2_advanced_field_ids()
      } else if (is_network_panel) {
        if (identical(
            input$network_engine %||% "netcomi",
            "ggclusternet2")) {
          microbiome_ggclusternet_advanced_field_ids(
            cross_domain = is_cross_domain_panel)
        } else if (is_cross_domain_panel) {
          microbiome_cross_domain_advanced_field_ids()
        } else {
          microbiome_netcomi_advanced_field_ids()
        }
      } else if (is_community_environment_panel) {
        microbiome_community_environment_advanced_field_ids(method$id[[1]])
      } else {
        microbiome_advanced_field_ids(method)
      }
      save_method_parameters(method$id[[1]], advanced_ids)
      shiny::removeModal()
    }, ignoreInit = TRUE)
    output$preprocessing_summary <- shiny::renderUI({
      method <- selected_method()
      if (is.null(method)) return(NULL)
      recommended <- microbiome_preprocessing_profile(method)
      selected <- saved_method_parameters()$preprocess_strategy %||% input$preprocess_strategy %||% recommended$strategy
      shiny::div(class = "small text-muted mb-2",
        shiny::tags$strong("Preprocessing: "), selected,
        if (!identical(selected, recommended$strategy)) shiny::span(class = "badge text-bg-warning ms-1", "user override") else
          shiny::span(class = "badge text-bg-success ms-1", "recommended"))
    })
    shiny::observe({
      method <- selected_method()
      if (requireNamespace("shinyjs", quietly = TRUE)) shinyjs::toggleState(session$ns("run"), condition = !is.null(method) && method$status == "implemented" && isTRUE(method$visibility))
    })
    analysis_running <- shiny::reactiveVal(FALSE)
    analysis_task <- shiny::reactiveValues(
      process = NULL, token = 0L, progress = NULL,
      started_at = NULL, method_id = "", differential_method = "")
    output$analysis_action <- shiny::renderUI({
      if (isTRUE(analysis_running())) {
        return(shiny::actionButton(
          session$ns("cancel_analysis"), "Cancel analysis",
          icon = shiny::icon("stop"), class = "btn-danger w-100"))
      }
      method <- selected_method()
      button <- shiny::actionButton(
        session$ns("run"), "Run analysis",
        icon = shiny::icon("play"), class = "btn-primary w-100")
      enabled <- !is.null(method) && method$status == "implemented" &&
        isTRUE(method$visibility)
      if (!enabled) {
        button <- htmltools::tagQuery(button)$find("button")$
          addAttrs(disabled = "disabled")$allTags()
      }
      button
    })
    fit_count <- shiny::reactiveVal(as.integer(
      restored_workspace_state$fit_count %||% 0L))
    original_result <- shiny::reactiveVal(
      restored_workspace_state$result %||% NULL)
    shiny::observeEvent(list(
      active_method_id(), input$composition_differential_method), {
      current_method <- as.character(active_method_id() %||% "")
      if (!length(current_method) || !nzchar(current_method[[1L]])) return()
      current_method <- current_method[[1L]]
      running_method <- as.character(
        shiny::isolate(analysis_task$method_id) %||% "")
      current_engine <- if (identical(current_method, "ancombc2")) {
        input$composition_differential_method %||% "ancombc2"
      } else ""
      running_engine <- shiny::isolate(
        analysis_task$differential_method) %||% ""
      if (isTRUE(shiny::isolate(analysis_running())) &&
          length(running_method) && nzchar(running_method[[1L]]) &&
          (!identical(running_method[[1L]], current_method) ||
            !identical(running_engine, current_engine))) {
        analysis_task$token <- shiny::isolate(analysis_task$token) + 1L
        worker <- shiny::isolate(analysis_task$process)
        progress <- shiny::isolate(analysis_task$progress)
        microbiome_cancel_background_analysis(worker)
        if (!is.null(progress)) tryCatch(
          progress$close(), error = function(error) NULL)
        analysis_task$process <- NULL
        analysis_task$progress <- NULL
        analysis_task$method_id <- ""
        analysis_task$differential_method <- ""
        analysis_running(FALSE)
      }
    }, ignoreInit = FALSE, priority = 100)
    persist_workspace_state <- function() {
      if (!workspace_state_enabled) return(invisible(FALSE))
      can_serialize <- function(object) {
        if (exists("dava_workspace_can_serialize", mode = "function",
            inherits = TRUE)) {
          return(dava_workspace_can_serialize(object))
        }
        isTRUE(tryCatch({
          serialize(object, NULL, version = 3)
          TRUE
        }, error = function(error) FALSE))
      }
      value <- shiny::isolate(original_result())
      if (!is.null(value) && !can_serialize(value)) {
        value$model_objects <- list()
        if (!can_serialize(value)) {
          value$plots <- (value$plots %||% list())[vapply(
            value$plots %||% list(), can_serialize, logical(1))]
        }
      }
      if (!is.null(value) && !can_serialize(value)) value <- NULL
      states <- shiny::isolate(file_data$workspace_module_states %||% list())
      states[[workspace_module_key]] <- list(
        version = 1L,
        navigation_method = shiny::isolate(navigation_method()),
        method_parameter_state = shiny::isolate(method_parameter_state()),
        fit_count = shiny::isolate(fit_count()),
        result = value
      )
      file_data$workspace_module_states <- states
      invisible(TRUE)
    }
    shiny::observeEvent(list(
      original_result(), fit_count(), method_parameter_state(),
      navigation_method()), persist_workspace_state(), ignoreInit = FALSE)
    shiny::observeEvent(input$run, {
      shiny::req(input$run > 0)
      if (isTRUE(shiny::isolate(analysis_running()))) return()
      method <- selected_method()
      method_label <- if (is.null(method)) "\u5fae\u751f\u7269\u6570\u636e" else method$label_cn[[1]] %||% method$id[[1]]
      if (is_network_panel) {
        method_label <- microbiome_network_progress_label(
          input$network_engine %||% "netcomi")
      }
      progress <- dava_progress(session, min = 0, max = 1)
      keep_progress <- FALSE
      on.exit({
        if (!keep_progress) tryCatch(
          progress$close(), error = function(error) NULL)
      }, add = TRUE)
      progress$set(
        message = paste(tr("Run"), tr_generated(method_label)),
        detail = tr("Read method parameters and input data"),
        value = 0.06
      )
      shiny::validate(shiny::need(!is.null(method) && method$status == "implemented" && isTRUE(method$visibility), "The current method is not runnable."))
      packages <- current_method_packages()
      if (length(packages)) {
        missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
        if (length(missing)) {
          progress$set(detail = paste0(
            "First run, method dependencies are being automatically installed:", paste(missing, collapse = ", ")),
            value = 0.08)
          microbiome_install_packages(missing)
          if (exists("dava_installed_packages", mode = "function")) {
            dava_installed_packages(refresh = TRUE)
          }
          package_status_refresh(package_status_refresh() + 1L)
        }
      }
      values <- current_input_values()
      values <- utils::modifyList(values, saved_method_parameters(method$id[[1]]))
      if (is_alpha_panel) {
        values$diversity_indices <- input$diversity_indices %||% "Shannon"
        values$alpha_group_variables <- input$alpha_group_variables %||% character()
        values$alpha_stat_method <- input$alpha_stat_method %||% "descriptive"
        values$alpha_paired <- isTRUE(input$alpha_paired)
        values$alpha_posthoc <- input$alpha_posthoc %||% "none"
        values$alpha_random_effect <- input$alpha_random_effect %||% ""
        values$alpha_model_formula <- input$alpha_model_formula %||% ""
      }
      if (is_beta_panel) {
        values$distance <- input$beta_distance %||% values$distance_method %||% "bray"
        values$group_variables <- input$beta_group_variables %||% input$beta_group %||%
          values$group_variables %||% values$group %||% "Treatment"
        values$group <- if (length(values$group_variables)) values$group_variables[[1]] else
          values$group %||% "Treatment"
        values$beta_significance_test <- input$beta_significance_test %||% "permanova_permdisp"
        values$permutations <- input$beta_permutations %||% values$permutations %||% 999L
        values$beta_model_formula <- input$beta_model_formula %||% ""
      }
      if (is_phylogenetic_panel) {
        if (identical(method$id[[1]], "phylogenetic_tree_build")) {
          values$phylo_build_source <- input$phylo_build_source %||%
            "representative_sequences"
          values$phylo_build_algorithm <- input$phylo_build_algorithm %||% "ml"
          values$phylo_build_rooting <- input$phylo_build_rooting %||% "midpoint"
          if (identical(values$phylo_build_source,
              "representative_sequences")) {
            values$phylo_build_rooting <- "midpoint"
          }
        }
        values$group <- input$phylogenetic_group %||% values$group %||% "Treatment"
        values$phylogenetic_test_method <- input$phylogenetic_test_method %||% "kruskal"
        values$p_adjust_method <- input$phylogenetic_p_adjust %||% values$p_adjust_method %||% "BH"
        values$null_model_method <- input$phylogenetic_null_model %||% values$null_model_method %||% "taxa.labels"
        values$n_iterations <- input$phylogenetic_iterations %||% values$n_iterations %||% 999L
        values$phylogenetic_model_formula <- input$phylogenetic_model_formula %||% ""
        values$plot_types <- as.character(input$phylogenetic_plot_types %||%
          unname(microbiome_phylogenetic_plot_choices(method$id[[1]])))
        phylo_ids <- microbiome_phylogenetic_advanced_field_ids(method$id[[1]])
        for (field in phylo_ids) {
          saved <- saved_method_parameters(method$id[[1]])
          values[[field]] <- input[[field]] %||% saved[[field]] %||% values[[field]]
        }
      }
      if (is_function_panel) {
        values$group <- input$group %||% ""
        values$p_adjust_method <- input$p_adjust_method %||% "BH"
        values$function_environment_enabled <- identical(
          method$id[[1]], "faprotax") &&
          isTRUE(input$function_environment_enabled)
        values$function_environment_variables <- if (
          isTRUE(values$function_environment_enabled)) {
          as.character(input$function_environment_variables %||% character())
        } else {
          character()
        }
        values$plot_types <- as.character(
          input$function_plot_types %||%
            unname(microbiome_function_plot_choices(method$id[[1]])))
        values$analysis_expression <- input$general_model_formula %||% ""
        if (method$id[[1]] %in% c("funguild", "fungaltraits")) {
          values$fungal_fr_abundance_weighted <- isTRUE(
            input$fungal_fr_abundance_weighted %||% TRUE)
          values$fungal_fr_percent <- isTRUE(
            input$fungal_fr_percent %||% TRUE)
        }
        if (identical(method$id[[1]], "funguild")) {
          values$funguild_confidence <- as.character(
            input$funguild_confidence %||%
              c("Highly Probable", "Probable", "Possible"))
        }
      }
      if (is_assembly_panel) {
        values$group <- input$group %||% ""
        values$distance_method <- input$distance_method %||%
          values$distance_method %||% "jaccard"
        values$abundance_weighted <- isTRUE(
          input$assembly_abundance_weighted %||% TRUE)
        values$icamp_bin_size <- input$icamp_bin_size %||%
          values$icamp_bin_size %||% 24L
        values$plot_types <- as.character(
          input$assembly_plot_types %||%
            unname(microbiome_assembly_plot_choices(method$id[[1]])))
        if (identical(method$id[[1]], "ncm")) {
          values$ncm_data_type <- input$ncm_data_type %||% "relative"
          values$ncm_scale_factor <- input$ncm_scale_factor %||% 10000L
          values$ncm_seed <- input$ncm_seed %||% 2026L
          values$ncm_start_m <- input$ncm_start_m %||% 0.1
          values$ncm_lower_m <- input$ncm_lower_m %||% 0.000001
          values$ncm_upper_m <- input$ncm_upper_m %||% 0.999999
          values$ncm_maxiter <- input$ncm_maxiter %||% 1000L
          values$ncm_conf_level <- input$ncm_conf_level %||% 0.95
        }
        values$analysis_expression <- input$general_model_formula %||% ""
      }
      if (is_composition_panel && identical(panel_id, "exploratory_composition")) {
        groups <- utils::head(as.character(input$composition_group_variables %||% character()), 3L)
        values$group_variables <- groups
        values$group <- if (length(groups)) groups[[1]] else values$group %||% "Treatment"
        values$taxonomic_rank <- if (identical(method$id[[1]], "lefse")) {
          "all"
        } else {
          input$taxonomic_rank %||% values$taxonomic_rank %||% "Genus"
        }
        values$plot_types <- as.character(input$composition_plot_types %||% character())
        values$composition_abundance_test <- input$composition_abundance_test %||% "kruskal_dunn"
        values$fdr_method <- input$composition_p_adjust %||% values$fdr_method %||% "BH"
        values$p_adjust_method <- values$fdr_method
        values$effect_structure <- input$composition_effect_structure %||% "random_intercept"
        values$random_outer <- input$composition_random_outer %||% ""
        values$random_inner <- input$composition_random_inner %||% ""
        values$random_effect <- input$composition_random_effect %||% ""
        values$random_slope <- input$composition_random_slope %||% ""
        values$glmm_family <- input$composition_glmm_family %||% "beta"
        values$set_test <- input$composition_set_test %||% "jaccard_permutation"
        if (identical(method$id[[1]], "ancombc2")) {
          values$differential_method <-
            input$composition_differential_method %||% "ancombc2"
          values$reference_group <-
            input$composition_differential_reference %||% ""
          values$comparison_group <-
            input$composition_differential_comparison %||% ""
          if (identical(values$differential_method, "ancombc2")) {
            values$analysis_mode <- input$composition_ancom_mode %||%
            if (length(unique(preview_bundle()$metadata[[values$group]] %||% character())) == 2L)
              "two_group" else "global"
            values$reference_group <- input$composition_ancom_reference %||% ""
            values$trend_order <- as.character(input$composition_ancom_trend_order %||% character())
            values$random_structure <- input$composition_ancom_random_structure %||% "none"
            values$random_cluster <- input$composition_ancom_random_cluster %||% ""
            values$random_slope_variable <- input$composition_ancom_random_slope %||% ""
            values$random_outer_variable <- input$composition_ancom_random_outer %||% ""
            values$random_inner_variable <- input$composition_ancom_random_inner %||% ""
            values$lfc_scale <- input$composition_ancom_lfc_scale %||% "ln"
            values$minimum_prevalence <- input$ancombc2_min_prevalence %||% values$minimum_prevalence %||% 0.1
            values$fdr_method <- input$ancombc2_p_adjust %||% values$fdr_method %||% "BH"
            values$alpha <- input$ancombc2_alpha %||% values$alpha %||% 0.05
            values$maximum_features <- input$ancombc2_max_taxa %||% values$maximum_features %||% 30L
            values$top_labels <- input$ancombc2_top_labels %||% values$top_labels %||% 10L
            values$lfc_threshold <- input$ancombc2_lfc_threshold %||% values$lfc_threshold %||% 0
            values$heatmap_transform <- input$ancombc2_heatmap_transform %||% values$heatmap_transform %||% "relative"
            values$heatmap_nonsignificant <- input$ancombc2_heatmap_nonsignificant %||% values$heatmap_nonsignificant %||% "grey"
            values$heatmap_annotations <- as.character(input$ancombc2_heatmap_annotations %||% values$heatmap_annotations %||% character())
            values$facet_phylum <- isTRUE(input$ancombc2_facet_phylum)
            values$trend_pattern <- input$ancombc2_trend_pattern %||% values$trend_pattern %||% "increasing"
            values$trend_turning_level <- input$ancombc2_trend_turning_level %||% ""
            values$mdfdr_bootstraps <- input$ancombc2_mdfdr_bootstraps %||% values$mdfdr_bootstraps %||% 100L
          } else if (identical(values$differential_method, "deseq2")) {
            values$deseq2_test <- input$composition_deseq2_test %||% "Wald"
            values$deseq2_fit_type <- input$deseq2_fit_type %||% "parametric"
            values$deseq2_independent_filtering <- isTRUE(input$deseq2_independent_filtering %||% TRUE)
            values$deseq2_cooks_cutoff <- isTRUE(input$deseq2_cooks_cutoff %||% TRUE)
            values$deseq2_lfc_shrinkage <- input$deseq2_lfc_shrinkage %||% "none"
            values$minimum_count <- input$deseq2_min_count %||% 10L
            values$minimum_samples <- input$deseq2_min_samples %||% 2L
            values$fdr_method <- input$deseq2_p_adjust %||% "BH"
            values$alpha <- input$deseq2_alpha %||% 0.05
            values$lfc_threshold <- input$deseq2_lfc_threshold %||% 1
            values$maximum_features <- input$deseq2_max_taxa %||% 30L
            values$top_labels <- input$deseq2_top_labels %||% 10L
            values$heatmap_transform <- input$deseq2_heatmap_transform %||% "vst"
          } else {
            values$edger_test <- input$composition_edger_test %||% "QLF"
            values$edger_normalization <- input$composition_edger_normalization %||% "TMM"
            values$edger_robust <- isTRUE(input$edger_robust %||% TRUE)
            values$edger_prior_df <- input$edger_prior_df %||% 10
            values$minimum_cpm <- input$edger_min_cpm %||% 1
            values$minimum_samples <- input$edger_min_samples %||% 2L
            values$fdr_method <- input$edger_p_adjust %||% "BH"
            values$alpha <- input$edger_alpha %||% 0.05
            values$lfc_threshold <- input$edger_lfc_threshold %||% 1
            values$maximum_features <- input$edger_max_taxa %||% 30L
            values$top_labels <- input$edger_top_labels %||% 10L
            values$heatmap_transform <- input$edger_heatmap_transform %||% "logcpm"
          }
          values$p_adjust_method <- values$fdr_method
        }
        values$significance_test <- switch(method$id[[1]],
          taxonomic_composition = values$composition_abundance_test,
          ancombc2 = switch(values$differential_method %||% "ancombc2",
            deseq2 = paste0("DESeq2 ", values$deseq2_test %||% "Wald"),
            edger = paste0("edgeR ", values$edger_test %||% "QLF"),
            input$composition_significance_test %||% "wald_bias_corrected"),
          lefse = "lefse",
          indicator_taxa = "indval_permutation",
          venn_upset = values$set_test,
          "none")
        values$analysis_expression <- input$general_model_formula %||% ""
      } else if (is_composition_panel) {
        values$composition_task <- input$composition_task %||% ""
        values$significance_test <- input$composition_significance_test %||% "none"
        values$analysis_expression <- input$general_model_formula %||% ""
      }
      if (is_species_environment_panel) {
        values$taxonomic_rank <- input$taxonomic_rank %||% "Genus"
        values$taxa_variables <- as.character(input$association_taxa %||% character())
        values$environment_factors <- as.character(
          input$association_environment %||% character())
        values$use_grouping <- isTRUE(input$association_use_grouping)
        values$group <- if (values$use_grouping) input$association_group %||% "" else ""
        values$group_mode <- if (identical(method$id[[1]], "species_env_spearman")) {
          "independent"
        } else {
          input$association_group_mode %||% "independent"
        }
        values$reference_group <- input$association_reference_group %||% ""
        values$plot_types <- as.character(input$association_plot_types %||%
          unname(microbiome_species_environment_plot_choices(
            method$id[[1]], values$use_grouping)))
        values$analysis_expression <- input$general_model_formula %||% ""
        values$minimum_prevalence <- input$association_min_prevalence %||%
          values$association_min_prevalence %||% 0.1
        values$minimum_abundance <- input$association_min_abundance %||%
          values$association_min_abundance %||% 0
        values$fdr_method <- input$association_p_adjust %||%
          values$association_p_adjust %||% "BH"
        values$alpha <- input$association_alpha %||% values$association_alpha %||% 0.05
        values$pseudocount <- input$association_pseudocount %||%
          values$association_pseudocount %||% 0.5
        values$standardize_environment <- input$association_standardize %||%
          values$association_standardize %||% TRUE
        values$n_cores <- input$association_cores %||% values$association_cores %||% 1L
        values$maximum_plot_associations <- input$association_max_plot %||%
          values$association_max_plot %||% 30L
        values$environment_correlation_threshold <-
          input$association_correlation_threshold %||%
            values$association_correlation_threshold %||% 0.8
        values$vif_threshold <- input$association_vif_threshold %||%
          values$association_vif_threshold %||% 10
        if (identical(method$id[[1]], "species_env_spearman")) {
          values$spearman_cluster_rows <- input$spearman_cluster_rows %||%
            values$spearman_cluster_rows %||% TRUE
          values$spearman_cluster_columns <- input$spearman_cluster_columns %||%
            values$spearman_cluster_columns %||% TRUE
          values$spearman_show_values <- input$spearman_show_values %||%
            values$spearman_show_values %||% TRUE
          values$spearman_network_r_threshold <- input$spearman_network_r_threshold %||%
            values$spearman_network_r_threshold %||% 0.5
          values$spearman_network_p_threshold <- input$spearman_network_p_threshold %||%
            values$spearman_network_p_threshold %||% 0.05
          values$spearman_fisher_adjust <- input$spearman_fisher_adjust %||%
            values$spearman_fisher_adjust %||% values$fdr_method
          values$spearman_low_colour <- input$spearman_low_colour %||%
            values$spearman_low_colour %||% "#2C7BB6"
          values$spearman_high_colour <- input$spearman_high_colour %||%
            values$spearman_high_colour %||% "#D7191C"
        } else if (identical(method$id[[1]], "mantel_correlation")) {
          values$mantel_distance <- input$mantel_distance %||%
            values$mantel_distance %||% "bray"
          values$mantel_correlation_method <- input$mantel_correlation_method %||%
            values$mantel_correlation_method %||% "pearson"
          values$mantel_p_adjust <- input$mantel_p_adjust %||%
            values$mantel_p_adjust %||% "BH"
          values$mantel_permutations <- input$mantel_permutations %||%
            values$mantel_permutations %||% 999L
          values$mantel_standardize <- input$mantel_standardize %||%
            values$mantel_standardize %||% FALSE
          values$mantel_partial <- input$mantel_partial %||%
            values$mantel_partial %||% TRUE
          for (field in c("mantel_r_break_1", "mantel_r_break_2",
              "mantel_p_break_1", "mantel_p_break_2",
              "mantel_cor_sig_threshold", "mantel_star_size",
              "mantel_grid_width", "mantel_square_alpha",
              "mantel_r_width_low", "mantel_r_width_mid",
              "mantel_r_width_high", "mantel_link_curve",
              "mantel_taxon_label_size", "mantel_x_angle",
              "mantel_base_size")) {
            values[[field]] <- input[[field]] %||% values[[field]]
          }
          values$mantel_r_break_1 <- values$mantel_r_break_1 %||% 0.3
          values$mantel_r_break_2 <- values$mantel_r_break_2 %||% 0.6
          values$mantel_p_break_1 <- values$mantel_p_break_1 %||% 0.01
          values$mantel_p_break_2 <- values$mantel_p_break_2 %||% 0.05
          values$mantel_cor_sig_threshold <- values$mantel_cor_sig_threshold %||% 0.05
          values$mantel_star_size <- values$mantel_star_size %||% 6
          values$mantel_grid_width <- values$mantel_grid_width %||% 0.25
          values$mantel_square_alpha <- values$mantel_square_alpha %||% 1
          values$mantel_r_width_low <- values$mantel_r_width_low %||% 0.5
          values$mantel_r_width_mid <- values$mantel_r_width_mid %||% 1.5
          values$mantel_r_width_high <- values$mantel_r_width_high %||% 3
          values$mantel_link_curve <- values$mantel_link_curve %||% 0.3
          values$mantel_taxon_label_size <- values$mantel_taxon_label_size %||% 3.88
          values$mantel_x_angle <- values$mantel_x_angle %||% 45
          values$mantel_base_size <- values$mantel_base_size %||% 11
          values$mantel_triangle <- input$mantel_triangle %||%
            values$mantel_triangle %||% "upper"
          values$mantel_show_diagonal <- input$mantel_show_diagonal %||%
            values$mantel_show_diagonal %||% FALSE
          values$mantel_low_colour <- input$mantel_low_colour %||%
            values$mantel_low_colour %||% "#2166AC"
          values$mantel_mid_colour <- input$mantel_mid_colour %||%
            values$mantel_mid_colour %||% "white"
          values$mantel_high_colour <- input$mantel_high_colour %||%
            values$mantel_high_colour %||% "#B2182B"
          values$mantel_p_colour_low <- input$mantel_p_colour_low %||%
            values$mantel_p_colour_low %||% "#D95F02"
          values$mantel_p_colour_mid <- input$mantel_p_colour_mid %||%
            values$mantel_p_colour_mid %||% "#1B9E77"
          values$mantel_p_colour_high <- input$mantel_p_colour_high %||%
            values$mantel_p_colour_high %||% "#A2A2A288"
        }
      }
      if (is_network_panel) {
        stored <- saved_method_parameters(method$id[[1]])
        values$network_engine <- input$network_engine %||% "netcomi"
        if (!values$network_engine %in%
            unname(microbiome_network_engine_choices())) {
          values$network_engine <- "netcomi"
        }
        values$taxonomic_rank <- if (is_cross_domain_panel) {
          "CrossDomainTaxon"
        } else {
          input$taxonomic_rank %||% "Genus"
        }
        if (is_cross_domain_panel) {
          values$bacteria_taxonomic_rank <-
            input$bacteria_taxonomic_rank %||% "Genus"
          values$fungi_taxonomic_rank <-
            input$fungi_taxonomic_rank %||% "Genus"
          values$second_bundle <- cross_domain_second_bundle()
          values$cross_domain_clr <-
            identical(values$network_engine, "netcomi")
        }
        values$group_network <- isTRUE(input$network_grouped)
        values$group <- if (values$group_network) input$network_group %||% "" else ""
        values$network_measure <- input$network_measure %||%
          if (identical(values$network_engine, "ggclusternet2") ||
              is_cross_domain_panel) "spearman" else "spieceasi"
        values$network_threshold <- input$network_threshold %||% 0.3
        values$correlation_threshold <- values$network_threshold
        values$network_fdr <- input$network_fdr %||% 0.05
        values$alpha <- values$network_fdr
        default_network_plots <- if (identical(
            values$network_engine, "ggclusternet2")) {
          microbiome_ggclusternet_default_plot_types(
            values$group_network, is_cross_domain_panel)
        } else if (is_cross_domain_panel) {
          "cross_domain_network"
        } else {
          microbiome_netcomi_default_plot_types(values$group_network)
        }
        values$plot_types <- as.character(
          input$network_plot_types %||% default_network_plots)
        values$analysis_expression <- input$general_model_formula %||% ""
        network_advanced_fields <- if (identical(
            values$network_engine, "ggclusternet2")) {
          microbiome_ggclusternet_advanced_field_ids(
            cross_domain = is_cross_domain_panel)
        } else if (is_cross_domain_panel) {
          microbiome_cross_domain_advanced_field_ids()
        } else {
          microbiome_netcomi_advanced_field_ids()
        }
        for (field in network_advanced_fields) {
          values[[field]] <- input[[field]] %||% stored[[field]] %||% values[[field]]
        }
        if (identical(values$network_engine, "ggclusternet2")) {
          values$minimum_prevalence <-
            values$ggcluster_min_prevalence %||% 0.1
          values$maximum_features <-
            values$ggcluster_max_features %||% 60L
          values$cluster_method <-
            values$ggcluster_cluster_method %||% "cluster_fast_greedy"
          values$hub_quantile <- values$ggcluster_hub_quantile %||% 0.95
          values$robustness_strategy <-
            values$ggcluster_robustness_strategy %||%
              c("node_rand", "node_degree_high")
          values$robustness_runs <-
            values$ggcluster_robustness_runs %||% 20L
          values$robustness_step <-
            values$ggcluster_robustness_step %||% 0.1
          values$robustness_max_ratio <-
            values$ggcluster_robustness_max_ratio %||% 0.9
          values$robustness_measure <-
            values$ggcluster_robustness_measure %||% "Eff"
          values$seed <- values$ggcluster_seed %||% 2026L
          values$n_cores <- values$ggcluster_cores %||%
            microbiome_ggclusternet_default_cores()
          if (is_cross_domain_panel) {
            values$cross_max_features_per_domain <-
              values$ggcluster_max_features_per_domain %||% 30L
          }
        } else {
          values$zero_method <- values$netcomi_zero_method %||% "pseudo"
          values$norm_method <- values$netcomi_norm_method %||% "clr"
          values$minimum_prevalence <-
            values$netcomi_min_prevalence %||% 0.1
          values$maximum_features <-
            values$netcomi_max_features %||% 60L
          if (is_cross_domain_panel) {
            values$cross_domain_pseudocount <-
              values$cross_domain_pseudocount %||% 0.5
            values$cross_max_features_per_domain <-
              values$cross_max_features_per_domain %||% 30L
          }
          values$cluster_method <-
            values$netcomi_cluster_method %||% "cluster_louvain"
          values$hub_method <- values$netcomi_hub_method %||% "degree"
          values$hub_quantile <- values$netcomi_hub_quantile %||% 0.95
          values$compare_permutations <-
            values$netcomi_compare_permutations %||% 999L
          values$spring_nlambda <-
            values$netcomi_spring_nlambda %||% 20L
          values$spring_repetitions <-
            values$netcomi_spring_repetitions %||% 20L
          values$robustness_strategy <-
            values$netcomi_robustness_strategy %||% "node_rand"
          values$robustness_runs <-
            values$netcomi_robustness_runs %||% 20L
          values$robustness_step <-
            values$netcomi_robustness_step %||% 0.1
          values$seed <- values$netcomi_seed %||% 2026L
          values$n_cores <- values$netcomi_cores %||%
            microbiome_netcomi_default_cores()
        }
      }
      if (is_community_environment_panel) {
        stored <- saved_method_parameters(method$id[[1]])
        values$group_variable <- input$community_environment_group %||% ""
        values$group <- values$group_variable
        values$fixed_effects <- as.character(input$fixed_effects %||% character())
        values$covariates <- character()
        values$analysis_expression <- input$general_model_formula %||% ""
        values$plot_types <- as.character(input$environment_plot_types %||%
          unname(microbiome_community_environment_plot_choices(method$id[[1]])))
        for (field in microbiome_community_environment_advanced_field_ids(method$id[[1]])) {
          values[[field]] <- input[[field]] %||% stored[[field]] %||% values[[field]]
        }
        values$distance <- values$distance_method %||% "bray"
      }
      bundle <- if (is_phylogenetic_panel) {
        cached_bundle <- preview_bundle()
        if (inherits(cached_bundle, "microbiome_invalid_bundle") ||
            !is.null(preview_input_issue())) NULL else cached_bundle
      } else {
        tryCatch(
          microbiome_bundle_from_inputs(file_data, values),
          error = function(error) {
            issue <- microbiome_input_issue(
              error, values, category_id, panel_id)
            preview_input_issue(issue)
            NULL
          }
        )
      }
      if (is.null(bundle)) {
        progress$set(
          detail = tr("The input data verification failed and the analysis did not start."),
          value = 1
        )
        issue <- preview_input_issue()
        original_result(new_microbiome_result(
          method$id[[1]], status = "error", method_label = method_label,
          data_version = values$count_dataset %||% "",
          errors = c(microbiome_input_issue_text(issue, interface_language())$summary,
            microbiome_input_issue_text(issue, interface_language())$details),
          runtime_log = "Input validation stopped analysis before model execution."
        ))
        return(invisible(NULL))
      }
      preview_input_issue(NULL)
      spec <- values
      progress$set(detail = tr("Examine data and apply preprocessing"), value = 0.28)
      recommended <- microbiome_preprocessing_profile(method)$strategy
      spec$preprocess_strategy <- spec$preprocess_strategy %||% recommended
      if (isTRUE(microbiome_method_capabilities(method)$raw_counts)) spec$preprocess_strategy <- "none"
      if (identical(spec$preprocess_strategy, "rarefy")) spec$rarefaction_depth <- microbiome_resolve_rarefaction_depth(bundle, spec)
      if (method$id == "procrustes_cross_domain" && is.null(spec$second_bundle)) {
        spec$second_bundle <- dava_local_demo_read("microbiome/base_its.rds")
      }
      fit_count(fit_count() + 1L)
      root_session <- tryCatch(session$rootScope(), error = function(error) NULL)
      if (inherits(session, "MockShinySession") ||
          inherits(root_session, "MockShinySession")) {
        captured <- microbiome_capture_runtime_output(function() {
          diagnostics <- microbiome_preprocessing_diagnostics(bundle, spec)
          analysis_bundle <- microbiome_apply_preprocessing(bundle, spec)
          value <- microbiome_run_method(method$id[[1]], analysis_bundle, spec)
          microbiome_attach_preprocessing_diagnostics(value, diagnostics, spec)
        })
        original_result(microbiome_attach_runtime_capture(
          captured$value, captured))
        progress$set(detail = tr("Analysis completed"), value = 1)
        return(invisible(NULL))
      }
      progress$set(
        detail = paste(tr("Background execution"), tr_generated(method_label), tr("Analyze")),
        value = 0.55)
      process <- tryCatch(
        microbiome_start_background_analysis(
          bundle, spec, method$id[[1]]),
        error = function(error) error)
      if (inherits(process, "error")) {
        original_result(new_microbiome_result(
          method$id[[1]], status = "error", method_label = method_label,
          data_version = values$count_dataset %||% "",
          errors = conditionMessage(process),
          runtime_log = "Background worker failed to start."))
        return(invisible(NULL))
      }

      plot_input_snapshot <- shiny::reactiveValuesToList(input)
      token <- shiny::isolate(analysis_task$token) + 1L
      analysis_task$token <- token
      analysis_task$process <- process
      analysis_task$progress <- progress
      analysis_task$started_at <- Sys.time()
      analysis_task$method_id <- method$id[[1]]
      analysis_task$differential_method <- values$differential_method %||% ""
      analysis_running(TRUE)
      keep_progress <- TRUE

      poll_task <- NULL
      poll_task <- function() {
        if (!identical(token, shiny::isolate(analysis_task$token))) return()
        worker <- shiny::isolate(analysis_task$process)
        if (is.null(worker)) return()
        alive <- tryCatch(worker$is_alive(), error = function(error) FALSE)
        if (isTRUE(alive)) {
          elapsed <- round(as.numeric(difftime(
            Sys.time(), shiny::isolate(analysis_task$started_at),
            units = "secs")))
          tryCatch(progress$set(
            detail = dava_tr(
              "Background analysis is running (%s seconds); you can click \"Cancel Analysis\" on the left to terminate immediately",
              current_interface_language(), elapsed),
            value = 0.55), error = function(error) NULL)
          later::later(poll_task, delay = 0.25)
          return()
        }

        log_paths <- attr(worker, "dava_log_paths") %||% character()
        stderr_path <- if (length(log_paths) >= 2L) log_paths[[2]] else ""
        worker_stderr <- if (nzchar(stderr_path) && file.exists(stderr_path)) {
          readLines(stderr_path, warn = FALSE, encoding = "UTF-8")
        } else character()
        captured <- tryCatch(worker$get_result(), error = function(error) error)
        microbiome_cleanup_background_analysis(worker)
        analysis_task$process <- NULL
        analysis_task$progress <- NULL
        analysis_task$method_id <- ""
        analysis_task$differential_method <- ""

        value <- if (inherits(captured, "error")) {
          new_microbiome_result(
            method$id[[1]], status = "error", method_label = method_label,
            data_version = values$count_dataset %||% "",
            errors = conditionMessage(captured),
            runtime_log = unique(c(
              "Background analysis worker failed.", worker_stderr)))
        } else {
          microbiome_attach_runtime_capture(captured$value, captured)
        }
        if (is_phylogenetic_panel &&
            identical(method$id[[1]], "phylogenetic_tree") &&
            value$status %in% c("success", "warning") &&
            length(value$plots)) {
          selected_plot <- microbiome_preferred_plot_name(value)
          if (nzchar(selected_plot) &&
              grepl("^phylo_tree", selected_plot) &&
              inherits(value$plots[[selected_plot]], "ggplot")) {
            progress$set(
              detail = tr("Pre-rendered phylogenetic tree result map"),
              value = 0.94)
            display_plot <- microbiome_apply_phylogenetic_tree_plot_settings(
              value$plots[[selected_plot]], plot_input_snapshot,
              paste0(selected_plot, "_"))
            display_plot <- localize_microbiome_plot(display_plot)
            display_raster <- tryCatch(
              microbiome_prerender_plot_raster(display_plot),
              error = function(error) NULL)
            if (!is.null(display_raster)) {
              value$model_objects$display_rasters <-
                stats::setNames(list(display_raster), selected_plot)
            }
          }
        }
        progress$set(detail = tr("Analysis completed"), value = 1)
        tryCatch(progress$close(), error = function(error) NULL)
        original_result(value)
        analysis_running(FALSE)
      }
      later::later(poll_task, delay = 0.05)
      invisible(NULL)
    }, ignoreInit = TRUE)

    shiny::observeEvent(input$cancel_analysis, {
      if (!isTRUE(shiny::isolate(analysis_running()))) return()
      analysis_task$token <- shiny::isolate(analysis_task$token) + 1L
      worker <- shiny::isolate(analysis_task$process)
      progress <- shiny::isolate(analysis_task$progress)
      microbiome_cancel_background_analysis(worker)
      if (!is.null(progress)) tryCatch(
        progress$close(), error = function(error) NULL)
      analysis_task$process <- NULL
      analysis_task$progress <- NULL
      analysis_task$method_id <- ""
      analysis_task$differential_method <- ""
      analysis_running(FALSE)
      shiny::showNotification(
        "Analysis canceled and background calculation process terminated.",
        type = "message", duration = 4)
    }, ignoreInit = TRUE)

    session$onSessionEnded(function() {
      microbiome_cancel_background_analysis(
        shiny::isolate(analysis_task$process))
    })
    # Each microbiome screen can expose many methods.  Keep their editable
    # implementations and code documents in distinct namespaces, just as the
    # regression methods do, so applying a custom method never affects another
    # category, panel, or method with a similar output contract.
    microbiome_method_code_key <- function(method_id = active_method_id()) {
      paste(
        "microbiome", category_id %||% "category", panel_id %||% "panel",
        method_id %||% "analysis", sep = "/"
      )
    }
    microbiome_code_document_plot_settings <- function(method_id = active_method_id()) {
      if (identical(method_id, "phylogenetic_tree")) {
        fields <- c(
          "tree_layout", "tree_open_angle", "tree_branch_size",
          "tree_clade_coloring", "tree_palette", "tree_branch_colour",
          "tree_tip_point", "tree_tip_point_size", "tree_tip_point_shape",
          "tree_tip_point_stroke", "tree_tip_point_alpha", "tree_show_tip_label",
          "tree_tip_label_size", "tree_tip_label_offset", "tree_show_node_label",
          "tree_tip_label_colour", "tree_show_rings", "tree_ring_columns",
          "tree_ring_geom", "tree_ring_width", "tree_ring_offset", "tree_ring_gap",
          "tree_ring_point_size", "tree_ring_low_colour", "tree_ring_high_colour",
          "tree_ring_legend", "tree_ring_labels", "tree_ring_label_size",
          "tree_legend_position", "tree_legend_font_size", "tree_legend_title",
          "tree_scale_bar", "tree_scale_bar_label", "tree_scale_bar_size"
        )
        return(stats::setNames(lapply(fields, function(field) input[[field]]), fields))
      }
      if (!is_alpha_panel || !identical(method_id, "alpha_core")) return(list())
      prefix <- microbiome_plot_settings_prefix("alpha_diversity")
      settings <- dava_result_plot_settings(input, prefix)
      settings$plot_type <- input[[paste0(prefix, "_alpha_plot_type")]] %||%
        input$alpha_plot_type %||% "box_jitter"
      settings
    }
    microbiome_method_runner_code <- function(method_id = active_method_id()) {
      method <- MICROBIOME_METHOD_REGISTRY[
        MICROBIOME_METHOD_REGISTRY$id == method_id, , drop = FALSE]
      if (!nrow(method)) {
        return(paste0("stop('Unknown microbial analysis method:", method_id, "')"))
      }
      runner <- if (
        method_id %in% c("species_env_spearman", "mantel_correlation", "maaslin2") &&
          identical(method$navigation_panel[[1]] %||% "", "multivariable_association")
      ) {
        "microbiome_run_species_environment_association"
      } else {
        switch(method$secondary_category[[1]],
          preprocess = "microbiome_run_preprocess",
          composition = "microbiome_run_composition",
          alpha = "microbiome_run_alpha",
          beta = "microbiome_run_beta",
          environment_spatial = "microbiome_run_environment_spatial",
          differential = "microbiome_run_differential",
          network = "microbiome_run_network",
          "function" = "microbiome_run_function",
          assembly_source = "microbiome_run_assembly_source",
          longitudinal_stability = "microbiome_run_longitudinal",
          integration_ml = "microbiome_run_integration_ml",
          ""
        )
      }
      if (!nzchar(runner)) {
        return(paste0("stop('The method has not yet connected to the execution adapter:", method_id, "')"))
      }
      paste0(runner, "(", dQuote(method_id, q = FALSE), ", prepared_bundle, analysis_spec)")
    }

    custom_execution <- shiny::eventReactive(list(
      input$run,
      file_data$method_code_revision,
      active_method_id()
    ), {
      method_id <- active_method_id()
      method_key <- microbiome_method_code_key(method_id)
      entry <- dava_method_code_get(file_data, method_key)
      if (is.null(entry) || !isTRUE(entry$enabled)) return(NULL)
      dava_method_code_execute(
        file_data, method_key,
        data = preview_bundle()$counts %||% NULL,
        dataset_name = input$count_dataset %||% input$dataset %||% "__demo__",
        context = list(bundle = preview_bundle()),
        spec = dava_code_analysis_spec_from_input(input)
      )
    }, ignoreInit = FALSE)
    result <- shiny::reactive({
      method <- selected_method()
      method_id <- if (is.null(method)) active_method_id() else method$id[[1]]
      differential_method <- if (identical(method_id, "ancombc2")) {
        input$composition_differential_method %||% "ancombc2"
      } else ""
      network_engine <- if (is_network_panel) {
        input$network_engine %||% "netcomi"
      } else ""
      if (isTRUE(analysis_running())) {
        pending <- original_result()
        shiny::req(microbiome_result_matches_method(
          pending, method_id, differential_method, network_engine))
        return(pending)
      }
      method_label <- if (is.null(method)) method_id else
        method$label_cn[[1]] %||% method_id
      method_key <- microbiome_method_code_key(method_id)
      value <- dava_method_code_effective(
        original = function() {
          value <- original_result()
          shiny::req(microbiome_result_matches_method(
            value, method_id, differential_method, network_engine))
          value
        },
        file_data = file_data,
        method_key = method_key,
        adapter = function(run, entry) {
          current_run <- custom_execution()
          if (is.null(current_run)) {
            stop("Custom method execution status is unavailable.", call. = FALSE)
          }
          microbiome_custom_run_to_result(
            current_run, method_id = method_id, method_label = method_label,
            code = entry$custom_code %||% ""
          )
        },
        on_error = function(message) {
          value <- original_result()
          shiny::req(microbiome_result_matches_method(
            value, method_id, differential_method, network_engine))
          value$warnings <- unique(c(
            value$warnings,
            paste0("The user-defined method results are incompatible and the original method has been rolled back:", message)
          ))
          value$runtime_log <- c(
            value$runtime_log,
            paste0("[custom-method fallback] ", message)
          )
          value
        }
      )
      shiny::req(microbiome_result_matches_method(
        value, method_id, differential_method, network_engine))
      value
    })
    shiny::observeEvent(original_result(), {
      value <- result()
      method <- selected_method()
      if (is.null(method) ||
          !identical(method$id[[1]], "phylogenetic_tree_build") ||
          is.null(file_data)) return()
      if (!value$status %in% c("success", "warning")) return()
      tree <- value$model_objects$tree %||% NULL
      if (!inherits(tree, "phylo") ||
          !requireNamespace("ape", quietly = TRUE) ||
          !ape::is.rooted(tree)) return()
      tree_table <- value$tables$tree_newick %||% data.frame(
        Newick = ape::write.tree(tree), stringsAsFactors = FALSE,
        check.names = FALSE)
      dataset_name <- microbiome_register_rooted_phylogeny(
        file_data, tree_table)
      generated_rooted_tree_dataset(dataset_name)
      shiny::updateSelectInput(
        session, "phylogeny_dataset", selected = dataset_name)
      shiny::showNotification(
        paste0("Rooted phylogenetic tree has been added to the data selection:", dataset_name),
        type = "message")
    }, ignoreInit = FALSE, priority = -10)
    output$input_summary <- DT::renderDT({
      if (!input$run) return(DT::datatable(data.frame(status = "Please select methods and data before running the analysis."), rownames = FALSE))
      DT::datatable(result()$input_summary, rownames = FALSE, options = list(pageLength = 12, scrollX = TRUE))
    })
    wide_preview_threshold <- 200L
    wide_preview_controls <- function(value, prefix) {
      dimensions <- dim(value %||% data.frame())
      total_rows <- dimensions[[1]] %||% 0L
      total_columns <- dimensions[[2]] %||% 0L
      summary <- dava_tr(
        "%s rows × %s columns. %s", interface_language(),
        format(total_rows, big.mark = ","),
        format(total_columns, big.mark = ","),
        if (total_columns > wide_preview_threshold) {
            tr("Column window preview of wide table, complete data still used for analysis.")
        } else {
            tr("Currently showing full columns.")
        }
      )
      if (total_columns <= wide_preview_threshold) {
        return(shiny::div(class = "small text-muted mb-2", summary))
      }
      shiny::div(
        class = "d-flex flex-wrap align-items-end gap-2 mb-2",
        shiny::div(
          class = "small text-muted align-self-center me-2",
          summary
        ),
        shiny::numericInput(
          session$ns(paste0(prefix, "_column_start")),
          "starting column",
          value = 1L,
          min = 1L,
          max = total_columns,
          step = 50L,
          width = "110px"
        ),
        shiny::selectInput(
          session$ns(paste0(prefix, "_column_count")),
          "Show every time",
          choices = c("25 columns" = 25L, "50 columns" = 50L, "100 columns" = 100L),
          selected = 50L,
          width = "120px"
        ),
        shiny::actionButton(
          session$ns(paste0(prefix, "_column_prev")),
          label = NULL,
          icon = shiny::icon("chevron-left"),
          title = "Previous column window",
          class = "btn-outline-secondary"
        ),
        shiny::actionButton(
          session$ns(paste0(prefix, "_column_next")),
          label = NULL,
          icon = shiny::icon("chevron-right"),
          title = "Next column window",
          class = "btn-outline-secondary"
        )
      )
    }
    preview_window <- function(value, prefix) {
      total_columns <- NCOL(value %||% data.frame())
      is_wide <- total_columns > wide_preview_threshold
      microbiome_preview_window(
        value,
        start = if (is_wide) input[[paste0(prefix, "_column_start")]] %||% 1L else 1L,
        width = if (is_wide) input[[paste0(prefix, "_column_count")]] %||% 50L else
          max(1L, total_columns),
        max_rows = 100L
      )
    }
    preview_datatable <- function(window) {
      DT::datatable(
        window$data,
        rownames = TRUE,
        options = list(
          scrollX = TRUE,
          pageLength = 20,
          deferRender = TRUE,
          processing = FALSE,
          autoWidth = FALSE
        )
      )
    }
    output$input_data_controls <- shiny::renderUI({
      bundle <- preview_bundle()
      issue <- preview_input_issue()
      if (!is.null(issue)) return(microbiome_input_issue_ui(issue, interface_language()))
      wide_preview_controls(bundle$counts, "input_data")
    })
    output$input_second_data_controls <- shiny::renderUI({
      wide_preview_controls(
        cross_domain_second_bundle()$counts,
        "input_second_data"
      )
    })
    register_preview_navigation <- function(prefix, value_reactive) {
      shiny::observeEvent(input[[paste0(prefix, "_column_prev")]], {
        width <- max(1L, as.integer(
          input[[paste0(prefix, "_column_count")]] %||% 50L))
        start <- max(1L, as.integer(
          input[[paste0(prefix, "_column_start")]] %||% 1L))
        shiny::updateNumericInput(
          session,
          paste0(prefix, "_column_start"),
          value = max(1L, start - width)
        )
      }, ignoreInit = TRUE)
      shiny::observeEvent(input[[paste0(prefix, "_column_next")]], {
        width <- max(1L, as.integer(
          input[[paste0(prefix, "_column_count")]] %||% 50L))
        start <- max(1L, as.integer(
          input[[paste0(prefix, "_column_start")]] %||% 1L))
        total_columns <- NCOL(value_reactive() %||% data.frame())
        maximum_start <- max(1L, total_columns - width + 1L)
        shiny::updateNumericInput(
          session,
          paste0(prefix, "_column_start"),
          value = min(maximum_start, start + width)
        )
      }, ignoreInit = TRUE)
    }
    register_preview_navigation(
      "input_data",
      function() preview_bundle()$counts
    )
    register_preview_navigation(
      "input_second_data",
      function() cross_domain_second_bundle()$counts
    )
    output$input_data <- DT::renderDT({
      if (!nzchar(input$count_dataset %||% ".__method_demo__")) {
        return(DT::datatable(data.frame(status = "Please select a data set."), rownames = FALSE))
      }
      bundle <- preview_bundle()
      issue <- preview_input_issue()
      if (!is.null(issue)) {
        issue_text <- microbiome_input_issue_text(issue, interface_language())
        return(preview_table(data.frame(status = issue_text$summary), issue_text$summary))
      }
      preview_datatable(preview_window(bundle$counts, "input_data"))
    })
    output$data_matching <- DT::renderDT({
      if (!nzchar(input$count_dataset %||% "")) {
        return(DT::datatable(data.frame(status = "Please select a data set."), rownames = FALSE))
      }
      values <- microbiome_input_values(input)
      bundle <- microbiome_bundle_from_inputs(file_data, values)
      samples <- bundle$sample_ids
      metadata_ids <- rownames(bundle$metadata %||% data.frame())
      table <- data.frame(sample_id = samples, metadata_matched = samples %in% metadata_ids, stringsAsFactors = FALSE)
      DT::datatable(table, rownames = FALSE, options = list(pageLength = 20))
    })

    preview_table <- function(value, empty_message) {
      if (is.null(value) || !length(value) || !NROW(value)) value <- data.frame(status = empty_message)
      DT::datatable(utils::head(as.data.frame(value, check.names = FALSE), 100), rownames = TRUE,
        options = list(scrollX = TRUE, pageLength = 20))
    }
    output$input_taxonomy <- DT::renderDT(preview_table(preview_bundle()$taxonomy, "No taxonomy table is available."))
    output$input_phylogeny <- DT::renderDT({
      tree <- preview_bundle()$phylogeny
      if (is.null(tree) || !inherits(tree, "phylo")) {
        return(preview_table(NULL, "No matched rooted phylogenetic tree is available."))
      }
      preview_table(data.frame(
        Tip = tree$tip.label,
        Rooted = ape::is.rooted(tree),
        stringsAsFactors = FALSE
      ), "No matched rooted phylogenetic tree is available.")
    })
    output$input_sequences <- DT::renderDT({
      sequences <- microbiome_representative_sequence_table(
        preview_bundle()$representative_sequences)
      preview_table(
        sequences,
        "No representative-sequence table is available.")
    })
    output$input_second_data <- DT::renderDT({
      second <- cross_domain_second_bundle()
      if (is.null(second$counts) || !length(second$counts) ||
          !NROW(second$counts)) {
        return(preview_table(
          NULL,
          "No paired ITS abundance table is available."))
      }
      preview_datatable(preview_window(
        second$counts,
        "input_second_data"
      ))
    })
    output$input_second_taxonomy <- DT::renderDT({
      second <- cross_domain_second_bundle()
      preview_table(
        second$taxonomy,
        "No paired ITS taxonomy table is available.")
    })
    output$input_metadata <- DT::renderDT(preview_table(preview_bundle()$metadata, "No sample metadata are available."))
    output$input_environment <- DT::renderDT(preview_table(preview_bundle()$environment, "No environmental table is available."))
    output$input_auxiliary <- DT::renderDT({
      bundle <- preview_bundle()
      auxiliary <- if (NROW(bundle$function_table %||% data.frame())) bundle$function_table else if (
        NROW(bundle$functional_mapping %||% data.frame())) bundle$functional_mapping else if (
        length(bundle$representative_sequences %||% list())) {
          microbiome_representative_sequence_table(
            bundle$representative_sequences)
        } else
          data.frame(status = "No auxiliary table is required for this method.")
      preview_table(auxiliary, "No auxiliary table is available.")
    })
    output$preprocessed_data <- DT::renderDT({
      method <- selected_method()
      spec <- utils::modifyList(current_input_values(), saved_method_parameters(method$id[[1]]))
      bundle <- preview_bundle()
      issue <- preview_input_issue()
      if (inherits(bundle, "microbiome_invalid_bundle") || !is.null(issue)) {
        message <- if (!is.null(issue)) {
          microbiome_input_issue_text(issue, interface_language())$summary
        } else {
          dava_translate_text("Invalid input data, preprocessing preview stopped.", interface_language())
        }
        return(preview_table(data.frame(status = message), message))
      }
      if (is_species_environment_panel || is_network_panel) {
        if (is_network_panel) {
          spec$network_engine <- input$network_engine %||% "netcomi"
          if (identical(spec$network_engine, "ggclusternet2")) {
            spec$minimum_prevalence <-
              spec$ggcluster_min_prevalence %||% 0.1
            spec$maximum_features <-
              spec$ggcluster_max_features %||% 60L
            spec$cross_max_features_per_domain <-
              spec$ggcluster_max_features_per_domain %||% 30L
          }
        }
        if (is_cross_domain_panel) {
          spec$bacteria_taxonomic_rank <-
            input$bacteria_taxonomic_rank %||% "Genus"
          spec$fungi_taxonomic_rank <-
            input$fungi_taxonomic_rank %||% "Genus"
          prepared <- tryCatch(
            microbiome_cross_domain_prepare(
              bundle, cross_domain_second_bundle(), spec),
            error = function(error) NULL)
          if (is.null(prepared)) {
            return(preview_table(
              data.frame(
                status =
                  "Unable to match and aggregate the selected 16S/ITS data."),
              "No matched cross-domain data are available."))
          }
          return(preview_table(
            prepared$bundle$counts,
            "No matched cross-domain data are available."))
        }
        spec$taxonomic_rank <- input$taxonomic_rank %||% "Genus"
        aggregated <- tryCatch(
          if (is_network_panel) {
            if (identical(spec$network_engine, "ggclusternet2")) {
              microbiome_ggclusternet_aggregate(bundle, spec)$counts
            } else {
              microbiome_netcomi_aggregate(bundle, spec)$counts
            }
          } else {
            microbiome_species_environment_aggregate(
              bundle, spec$taxonomic_rank)$counts
          },
          error = function(error) data.frame(status = conditionMessage(error)))
        return(preview_table(aggregated, "No aggregated taxonomic data are available."))
      }
      spec$preprocess_strategy <- spec$preprocess_strategy %||% microbiome_preprocessing_profile(method)$strategy
      if (identical(spec$preprocess_strategy, "rarefy")) {
        resolved_depth <- tryCatch(
          microbiome_resolve_rarefaction_depth(bundle, spec),
          error = function(error) error)
        if (inherits(resolved_depth, "error")) {
          message <- paste0("Preprocessing stopped:", conditionMessage(resolved_depth))
          return(preview_table(data.frame(status = message), message))
        }
        spec$rarefaction_depth <- resolved_depth
      }
      transformed <- tryCatch(microbiome_apply_preprocessing(bundle, spec),
        error = function(error) error)
      if (inherits(transformed, "error")) {
        message <- paste0("Preprocessing stopped:", conditionMessage(transformed))
        return(preview_table(data.frame(status = message), message))
      }
      preview_table(transformed$counts, "No preprocessed data are available.")
    })
    output$analysis_parameters <- DT::renderDT({
      values <- microbiome_input_values(input)
      values <- utils::modifyList(values, saved_method_parameters())
      table <- data.frame(parameter = names(values), value = vapply(values, function(value) paste(value, collapse = ", "), character(1)))
      DT::datatable(table, rownames = FALSE, options = list(scrollX = TRUE, pageLength = 20))
    })
    output$method_description <- shiny::renderUI({
      method <- selected_method()
      if (is.null(method)) return(NULL)
      engine <- method$engine
      required_packages <- method$required_packages %||% ""
      if (identical(method$id[[1]], "ancombc2")) {
        differential_method <- input$composition_differential_method %||% "ancombc2"
        engine <- switch(differential_method,
          deseq2 = "DESeq2 negative-binomial model",
          edger = "edgeR negative-binomial GLM",
          "ANCOM-BC2 bias-corrected compositional model")
        required_packages <- switch(differential_method,
          deseq2 = "DESeq2", edger = "edgeR", "ANCOMBC")
      }
      if (is_network_panel) {
        network_engine <- input$network_engine %||% "netcomi"
        engine <- if (identical(network_engine, "ggclusternet2")) {
          "ggClusterNet2 (ggClusterNet package)"
        } else {
          "NetCoMi"
        }
        required_packages <- paste(current_method_packages(), collapse = ", ")
      }
      shiny::tagList(shiny::tags$h4(method$label_cn), shiny::tags$p(method$description %||% ""),
        shiny::tags$dl(shiny::tags$dt("Analysis Engine"), shiny::tags$dd(engine),
          shiny::tags$dt("Required dependencies"), shiny::tags$dd(required_packages)))
    })
    output$result_type <- shiny::renderUI({
      value <- result()
      if (!length(value$tables)) return(NULL)
      table_labels <- c(
        feature_results = "Feature-level differential results",
        significant_taxa = "Significant differential taxa",
        model_summary = "Differential model summary",
        normalized_abundance = "Normalized abundance",
        active_mode_results = "Active ANCOM-BC2 mode results",
        fixed_effect_results = "Fixed-effect primary results",
        global_results = "Multi-group global test",
        pairwise_results = "All pairwise comparisons",
        dunnett_results = "Dunnett-type comparisons",
        trend_results = "Ordered trend test",
        model_differential_taxa = "Differential taxa from the primary model",
        robust_differential_taxa = "Robust differential taxa",
        sensitivity_candidates = "Sensitivity-analysis candidates",
        structural_zero_results = "Structural-zero taxa"
      )
      table_names <- names(value$tables)
      labels <- table_names
      matched <- table_names %in% names(table_labels)
      labels[matched] <- unname(table_labels[table_names[matched]])
      shiny::selectInput(session$ns("result_name"), "Results table",
        stats::setNames(table_names, labels))
    })
    output$result_table <- DT::renderDT({
      value <- result()
      name <- microbiome_output_name(input$result_name, value$tables)
      table <- if (nzchar(name)) value$tables[[name]] else data.frame(status = "No table results")
      DT::datatable(as.data.frame(table, check.names = FALSE),
        rownames = FALSE, options = list(
          pageLength = 15, scrollX = TRUE, deferRender = TRUE,
          processing = TRUE, autoWidth = FALSE, searchDelay = 350))
    })
    output$plot_type <- shiny::renderUI({
      value <- result()
      if (!length(value$plots)) return(shiny::div(class = "text-muted", "The current method has no graphical results."))
      labels <- names(value$plots)
      labels[labels == "ordination"] <- "Ordination plot"
      labels[labels == "group_distance"] <- "Group distance boxplot"
      plot_labels <- c(
        composition = "Taxonomic composition",
        stacked_bar = "Grouped stacked composition",
        grouped_bar = "Grouped abundance bars",
        composition_heatmap = "Composition heatmap",
        bubble = "Composition bubble plot",
        sankey = "Composition Sankey plot",
        sunburst = "Composition sunburst plot",
        ternary = "Composition ternary plot",
        core_abundance_prevalence = "Core abundance-prevalence plot",
        indicator_value = "Indicator value ranking",
        differential_effect = "Differential effect ranking",
        volcano = "Volcano plot",
        ma_plot = "DESeq2 MA plot",
        smear_plot = "edgeR smear plot",
        dispersion_plot = "DESeq2 mean-dispersion diagnostic",
        mean_variance = "edgeR mean-variance diagnostic",
        pvalue_histogram = "P-value distribution",
        two_group_forest = "Two-group LFC forest plot",
        global_summary = "Global-test summary",
        pairwise_heatmap = "Pairwise LFC heatmap",
        dunnett_forest = "Dunnett-type LFC forest plot",
        differential_bubble = "Differential-taxa bubble plot",
        abundance_distribution = "Relative-abundance boxplot / violin plot",
        sample_heatmap = "Differential-taxa sample heatmap",
        contrast_upset = "Significant-taxa UpSet plot",
        taxonomy_tree = "ANCOM-BC2 taxonomy tree (not LEfSe)",
        trend_heatmap = "Trend-mode heatmap",
        trend_trajectory = "Faceted taxon trajectories",
        significant_heatmap = "Significant taxa abundance heatmap",
        key_taxa_distribution = "Key taxa boxplot / violin plot",
        differential_stacked_bar = "Differential taxa stacked composition",
        classic_heatmap = "Classic Spearman correlation heatmap",
        correlation_network = "Species-environment correlation network",
         correlation_bubble = "Species-environment correlation bubble plot",
         mantel_correlation_heatmap = "Mantel test + Correlation heatmap",
        grouped_heatmaps = "Side-by-side group correlation heatmaps",
        delta_heatmap = "Group difference in correlation (Delta r)",
        grouped_bubble = "Grouped correlation bubble plot",
        differential_significance_heatmap =
          "FDR-significant group differences in correlation",
        network_comparison = "Overall and group-specific network comparison",
        coefficient_forest = "Coefficient forest plot",
        ordination_biplot = "Community-environment ordination",
        term_significance = "Environmental-term significance",
        hierarchical_partition = "Hierarchical partitioning",
        variation_partition = "Unique and shared contribution",
        pcoa_envfit = "PCoA with environmental vectors",
        envfit_significance = "envfit variable significance",
        mantel_overview = "Mantel test overview",
        mantel_variables = "Variable-wise Mantel statistics",
        overall_network = "Overall co-occurrence network",
        grouped_network = "Grouped networks with shared layout",
        cross_domain_network = "Bacteria-fungi cross-domain network",
        ggcluster_curved_network = "ggClusterNet2 curved-edge network",
        ggcluster_module_network = "ggClusterNet2 module network",
        centrality_distribution = "Degree and centrality distribution",
        zipi_roles = "Zi-Pi node roles",
        module_composition = "Module taxonomic composition",
        network_properties = "Network properties",
        domain_edge_composition = "Cross-domain edge composition",
        cross_domain_heatmap = "Bacteria-fungi association heatmap",
        domain_centrality = "Node centrality by microbial domain"
      )
      matched <- labels %in% names(plot_labels)
      labels[matched] <- unname(plot_labels[labels[matched]])
      plot_names <- names(value$plots)
      analysis_index <- !startsWith(plot_names, "preprocess_")
      choices <- list()
      if (any(analysis_index)) choices[["Analysis result plots"]] <-
        stats::setNames(plot_names[analysis_index], labels[analysis_index])
      if (any(!analysis_index)) choices[["Preprocessing diagnostics"]] <-
        stats::setNames(plot_names[!analysis_index], labels[!analysis_index])
      selected <- microbiome_resolve_plot_selection(
        shiny::isolate(input$plot_name), value)
      shiny::selectInput(session$ns("plot_name"), "Plot", choices, selected = selected)
    })
    shiny::observeEvent(result(), {
      value <- result()
      current <- shiny::isolate(input$plot_name)
      selected <- microbiome_resolve_plot_selection(current, value)
      if (!nzchar(selected) || identical(selected, current)) return()
      session$onFlushed(function() {
        shiny::updateSelectInput(session, "plot_name", selected = selected)
      }, once = TRUE)
    }, ignoreInit = TRUE)
    output$plot_panel <- shiny::renderUI({
      value <- result()
      if (!length(value$plots)) return(shiny::div(class = "text-muted", "The current method has no graphical results."))
      plot_names <- names(value$plots)
      selector_id <- session$ns("plot_name")
      settings <- lapply(plot_names, function(plot_name) {
        condition_name <- gsub("'", "\\\\'", plot_name, fixed = TRUE)
        plot <- value$plots[[plot_name]]
        settings_ui <- if (is_network_panel &&
            microbiome_network_main_plot(plot_name)) {
          microbiome_network_plot_settings_ui(
            session$ns, paste0(plot_name, "_"),
            microbiome_network_plot_spec_for(value, plot_name))
        } else if (is_phylogenetic_panel &&
            grepl("^phylo_tree", plot_name)) {
          microbiome_phylogenetic_tree_plot_settings_ui(
            session$ns, paste0(plot_name, "_"), value)
        } else if (identical(microbiome_plot_kind(plot_name, plot), "ncm")) {
          prefix <- microbiome_plot_settings_prefix(plot_name)
          shiny::tagList(
            dava_result_plot_settings_ui(
              session$ns, prefix, paste0("Plot settings: ", plot_name)),
            microbiome_specific_plot_settings_ui(
              session$ns, prefix, "ncm"))
        } else if (dava_is_composite_plot(plot)) {
          dava_composite_plot_settings_ui(session$ns, plot,
            microbiome_plot_settings_prefix(plot_name))
        } else {
          prefix <- microbiome_plot_settings_prefix(plot_name)
          shiny::tagList(
            if (is_alpha_panel && identical(plot_name, "alpha_diversity")) {
              shiny::selectInput(
                session$ns(paste0(prefix, "_alpha_plot_type")),
                "Alpha diversity graphics type",
                microbiome_alpha_plot_type_choices(), selected = "box_jitter")
            },
            dava_result_plot_settings_ui(session$ns, prefix, paste0("Plot settings: ", plot_name)),
            microbiome_specific_plot_settings_ui(session$ns, prefix, microbiome_plot_kind(plot_name, plot))
          )
        }
        shiny::conditionalPanel(
          condition = sprintf("input['%s'] === '%s'", selector_id, condition_name),
          settings_ui
        )
      })
      bslib::layout_sidebar(
        sidebar = bslib::sidebar(
          width = if (is_phylogenetic_panel) 350 else 300,
          position = "right",
          dava_plot_action_buttons_ui(session$ns),
          do.call(shiny::tagList, settings)
        ),
        shiny::tagList(
          shiny::uiOutput(session$ns("plot_type")),
          dava_plot_size_ui(session$ns, "plot", "microbiome_plot_size", width = 900, height = 680)
        )
      )
    })
    phylogenetic_plot_settings_revision <- shiny::reactiveVal(0L)
    phylogenetic_plot_settings_baseline <- shiny::reactiveVal(NULL)
    phylogenetic_plot_settings_snapshot <- shiny::reactive({
      if (!is_phylogenetic_panel) return(list())
      values <- shiny::reactiveValuesToList(input)
      value_names <- names(values) %||% character()
      keep <- startsWith(value_names, "phylo_tree_") &
        grepl("_tree_", value_names, fixed = TRUE) &
        !endsWith(value_names, "tree_property_sections")
      values[sort(value_names[keep])]
    })
    phylogenetic_plot_settings_debounced <- shiny::debounce(
      phylogenetic_plot_settings_snapshot, millis = 350)
    shiny::observeEvent(phylogenetic_plot_settings_debounced(), {
      snapshot <- phylogenetic_plot_settings_debounced()
      if (!length(snapshot)) return()
      baseline <- shiny::isolate(phylogenetic_plot_settings_baseline())
      if (is.null(baseline)) {
        phylogenetic_plot_settings_baseline(snapshot)
      } else if (!identical(snapshot, baseline)) {
        phylogenetic_plot_settings_baseline(snapshot)
        phylogenetic_plot_settings_revision(
          shiny::isolate(phylogenetic_plot_settings_revision()) + 1L)
      }
    }, ignoreInit = FALSE)
    shiny::observeEvent(input$run, {
      if (!is_phylogenetic_panel) return()
      snapshot <- shiny::isolate(phylogenetic_plot_settings_snapshot())
      phylogenetic_plot_settings_baseline(
        if (length(snapshot)) snapshot else NULL)
      phylogenetic_plot_settings_revision(0L)
    }, ignoreInit = TRUE, priority = 20)
    current_microbiome_plot <- shiny::reactive({
      value <- result()
      name <- microbiome_output_name(input$plot_name, value$plots)
      shiny::req(nzchar(name))
      if (is_network_panel && microbiome_network_main_plot(name)) {
        spec <- microbiome_network_plot_spec_from_input(
          input, microbiome_network_plot_spec_for(value, name),
          paste0(name, "_"))
        return(localize_microbiome_plot(
          microbiome_render_network_result(value, spec)))
      }
      plot <- value$plots[[name]]
      if (is_phylogenetic_panel && grepl("^phylo_tree", name)) {
        settings_revision <- phylogenetic_plot_settings_revision()
        if (settings_revision < 1L) {
          plot <- shiny::isolate(
            microbiome_apply_phylogenetic_tree_plot_settings(
              plot, input, paste0(name, "_")))
          return(localize_microbiome_plot(plot))
        }
        return(localize_microbiome_plot(
          shiny::isolate(microbiome_render_phylogenetic_tree_result(
            value, input, paste0(name, "_"), name))))
      }
      if (identical(name, "mantel_correlation_heatmap")) {
        prefix <- microbiome_plot_settings_prefix(name)
        mantel_spec <- microbiome_mantel_plot_spec_from_input(
          input, prefix, value$analysis_spec %||% list())
        environment_data <- value$tables$mantel_environment_data
        if ("SampleID" %in% names(environment_data)) {
          rownames(environment_data) <- environment_data$SampleID
          environment_data$SampleID <- NULL
        }
        plot <- microbiome_species_environment_mantel_plot(
          environment_data, value$tables$mantel_plot_table, mantel_spec)
        plot <- dava_apply_result_plot_settings(
          plot, dava_result_plot_settings(input, prefix))
        return(localize_microbiome_plot(plot))
      }
      if (identical(name, "ncm_fit") &&
          !is.null(value$tables$feature_fit) &&
          !is.null(value$tables$ncm_summary)) {
        prefix <- microbiome_plot_settings_prefix(name)
        plot <- microbiome_render_ncm_plot(value, input, prefix)
        plot <- dava_apply_result_plot_settings(
          plot, dava_result_plot_settings(input, prefix))
        return(localize_microbiome_plot(plot))
      }
      if (identical(name, "ncm_fit") &&
          requireNamespace("ncmR", quietly = TRUE) &&
          !is.null(value$model_objects$ncm_fit)) {
        prefix <- microbiome_plot_settings_prefix(name)
        ncm_args <- microbiome_ncm_plot_args_from_input(input, prefix)
        plot <- do.call(
          ncmR::scatter_plot,
          c(list(object = value$model_objects$ncm_fit), ncm_args))
        return(localize_microbiome_plot(plot))
      }
      if (is_alpha_panel && identical(name, "alpha_diversity") &&
          !is.null(value$tables$alpha_diversity)) {
        prefix <- microbiome_plot_settings_prefix(name)
        plot <- microbiome_alpha_diversity_plot(
          value$tables$alpha_diversity, value$analysis_spec %||% list(),
          input[[paste0(prefix, "_alpha_plot_type")]] %||% "box_jitter")
        plot <- dava_apply_result_plot_settings(
          plot, dava_result_plot_settings(input, prefix))
        return(localize_microbiome_plot(plot))
      }
      plot <- if (dava_is_composite_plot(plot)) {
        dava_apply_composite_plot_settings(plot, input, microbiome_plot_settings_prefix(name))
      } else {
        prefix <- microbiome_plot_settings_prefix(name)
        plot <- dava_apply_result_plot_settings(plot, dava_result_plot_settings(input, prefix))
        microbiome_apply_specific_plot_settings(plot, input, prefix, microbiome_plot_kind(name, plot))
      }
      localize_microbiome_plot(plot)
    })
    output$plot <- shiny::renderPlot({
      captured <- dava_capture_conditions({
        value <- result()
        name <- microbiome_output_name(input$plot_name, value$plots)
        cached_raster <- NULL
        if (is_phylogenetic_panel &&
            phylogenetic_plot_settings_revision() < 1L &&
            nzchar(name)) {
          cached_raster <- value$model_objects$display_rasters[[name]] %||% NULL
        }
        if (inherits(cached_raster, "nativeRaster")) {
          grid::grid.newpage()
          grid::grid.raster(cached_raster,
            width = grid::unit(1, "npc"), height = grid::unit(1, "npc"))
          invisible(NULL)
        } else {
          microbiome_quiet_plot_compatibility(
            print(current_microbiome_plot()))
        }
      }, source = paste0("Microbiome plot: ", panel_id))
      record_plot_runtime_diagnostics(captured,
        paste0("Microbiome plot: ", panel_id))
      if (nzchar(captured$error %||% "")) {
        dava_plot_diagnostic_placeholder(captured$error, "error")
      }
      invisible(captured$value)
    })
    microbiome_plot_dimensions <- if (exists("dava_plot_size_server", mode = "function")) {
      dava_plot_size_server(input, output, session, "plot", "microbiome_plot_size", 900, 680)
    } else {
      shiny::reactive(list(
        width_px = 900, height_px = 680,
        width_in = 900 / 96, height_in = 680 / 96,
        lock_ratio = FALSE
      ))
    }
    shiny::observeEvent(input$add_plot_to_library, {
      plot <- microbiome_quiet_plot_compatibility(
        current_microbiome_plot())
      dims <- microbiome_plot_dimensions()
      name <- microbiome_output_name(input$plot_name, result()$plots)
      ok <- dava_plot_register(
        file_data, paste("microbiome", category_id, panel_id, input$method_id %||% "method", name, sep = "/"),
        plot, source = "Microbiome analysis", title = name,
        meta = list(module = "microbiome", method = input$method_id %||% "", plot_name = name, added_by = "manual"),
        params = c(list(width_px = dims$width_px, height_px = dims$height_px), dava_plot_input_params(input)),
        editor_svg = dava_plot_editor_svg_sized(plot, dims)
      )
      shiny::showNotification(
        if (isTRUE(ok)) "The current results plot has been added to the Analysis Gallery." else "Add failed: The current drawing is not a registrable object.",
        type = if (isTRUE(ok)) "message" else "error", duration = 3
      )
    })
    output$download_plot_png <- shiny::downloadHandler(
      filename = function() sprintf("microbiome_%s_%s.png", input$method_id %||% "result", Sys.Date()),
      content = function(file) microbiome_quiet_plot_compatibility(
        dava_save_sized_plot(file, current_microbiome_plot(), "png",
          microbiome_plot_dimensions(), 300))
    )
    output$download_plot_pdf <- shiny::downloadHandler(
      filename = function() sprintf("microbiome_%s_%s.pdf", input$method_id %||% "result", Sys.Date()),
      content = function(file) microbiome_quiet_plot_compatibility(
        dava_save_sized_plot(file, current_microbiome_plot(), "pdf",
          microbiome_plot_dimensions(), 300))
    )
    dava_module_code_panel_server(
      input, output, session, file_data,
      source_prefix = microbiome_method_code_key,
      default_code = function() {
        value <- original_result()
        differential_method <- if (identical(active_method_id(), "ancombc2")) {
          input$composition_differential_method %||% "ancombc2"
        } else ""
        network_engine <- if (is_network_panel) {
          input$network_engine %||% "netcomi"
        } else ""
        if (!microbiome_result_matches_method(
            value, active_method_id(), differential_method, network_engine)) {
          method_id <- active_method_id()
          # The code document must remain method-specific before a user first
          # runs the method.  This mirrors regression's immediately editable
          # template and is later replaced by the exact, parameterised result
          # script once a result is available.
          template_spec <- tryCatch(current_input_values(),
            error = function(error) list())
          template_spec <- template_spec[vapply(template_spec, function(item) {
            (is.atomic(item) || is.factor(item)) && length(item) <= 100L
          }, logical(1))]
          template_spec$preprocess_strategy <-
            template_spec$preprocess_strategy %||%
            microbiome_preprocessing_profile(selected_method())$strategy
          method_template <- tryCatch(
            microbiome_method_code_document(method_id, template_spec,
              microbiome_code_document_plot_settings(method_id)),
            error = function(error) paste0("# NoneMethod generation method details：", conditionMessage(error))
          )
          return(method_template)
        }
        method_id <- active_method_id()
        method_spec <- value$analysis_spec %||% list()
        method_spec <- method_spec[vapply(method_spec, function(item) {
          (is.atomic(item) || is.factor(item)) && length(item) <= 100L
        }, logical(1))]
        # Use the exact completed method specification so the code document
        # returns the same tables and selected plot objects as the main view.
        microbiome_method_code_document(method_id, method_spec,
          microbiome_code_document_plot_settings(method_id))
      },
      source = "Microbiome analysis",
      title = "Microbiome method R Markdown code document",
      kind = "analysis",
      # Unlike a regression screen, the shared microbiome UI keeps controls
      # for many hidden methods in `input`.  Do not snapshot that global input
      # set into this method's document; the result's analysis_spec above is
      # the complete, current-method parameter contract.
      plot_params = function() list(),
      data = function() preview_bundle()$counts %||% NULL,
      dataset_name = function() input$count_dataset %||% input$dataset %||% "__demo__",
      context = function() {
        method_id <- active_method_id()
        second_bundle <- if (identical(method_id, "cross_domain_network")) {
          cross_domain_second_bundle()
        } else if (identical(method_id, "procrustes_cross_domain")) {
          dava_local_demo_read("microbiome/base_its.rds")
        } else NULL
        list(bundle = preview_bundle(), second_bundle = second_bundle)
      },
      data_code = function() {
        dataset <- input$count_dataset %||% input$dataset %||% "current abundance table"
        method_id <- active_method_id()
        commented_demo_read <- function(relative_path, object_name) {
          paste0("# ", strsplit(
            dava_local_demo_code(relative_path, object_name = object_name),
            "\n", fixed = TRUE)[[1]])
        }
        if (identical(dataset, ".__method_demo__")) {
          asset <- paste0("microbiome/methods/", method_id, ".rds")
          second_bundle_code <- if (method_id %in% c("cross_domain_network", "procrustes_cross_domain")) c(
            "",
            "# Second domain source: versioned local ITS simulation used by the main method.",
            "# Local asset: data/simulated_datasets/microbiome/base_its.rds",
            "# The following commented statements reproduce the source in a clean R session:",
            commented_demo_read("microbiome/base_its.rds", object_name = "second_bundle"),
            "# The panel run uses the same already loaded bundle from analysis_context.",
            "second_bundle <- analysis_context$second_bundle"
          ) else character()
          context_code <- if (length(second_bundle_code)) {
            paste0("analysis_context <- list(bundle = bundle, second_bundle = second_bundle, data = bundle$counts, dataset_name = ",
              dQuote(dataset, q = FALSE), ", method_id = ", dQuote(method_id, q = FALSE), ")")
          } else {
            paste0("analysis_context <- list(bundle = bundle, data = bundle$counts, dataset_name = ",
              dQuote(dataset, q = FALSE), ", method_id = ", dQuote(method_id, q = FALSE), ")")
          }
          return(paste(
            "# ---- Input data ----",
            "# Data source: versioned local simulated data dedicated to this analysis method.",
            paste0("# Method ID: ", dQuote(method_id, q = FALSE)),
            paste0("# Local asset: data/simulated_datasets/", asset),
            "# This file is read directly. It is not generated while the analysis runs.",
            "# The following commented statements reproduce the source in a clean R session:",
            commented_demo_read(asset, object_name = "bundle"),
            "# The panel run uses the same already loaded bundle from analysis_context.",
            "bundle <- analysis_context$bundle",
            second_bundle_code,
            "",
            "# The RDS object is a microbiome bundle: counts, metadata, taxonomy, and optional",
            "# phylogeny, environmental variables, representative sequences, or function tables.",
            "# Make the application execution context explicit and reproducible.",
            context_code,
            "",
            "# Preserve the imported abundance table before any method-specific preprocessing.",
            "raw_counts <- as.matrix(analysis_context$bundle$counts) # rows: samples; columns: ASVs/OTUs/features",
            "storage.mode(raw_counts) <- 'numeric'",
            "if (is.null(rownames(raw_counts))) rownames(raw_counts) <- paste0('Sample_', seq_len(nrow(raw_counts)))",
            "",
            "# Read and align sample metadata to the abundance-matrix row order.",
            "raw_metadata <- as.data.frame(analysis_context$bundle$metadata, stringsAsFactors = FALSE)",
            "if (!'SampleID' %in% names(raw_metadata)) raw_metadata$SampleID <- rownames(raw_metadata)",
            "raw_metadata <- raw_metadata[match(rownames(raw_counts), raw_metadata$SampleID), , drop = FALSE]",
            "stopifnot(!anyNA(raw_counts), all(raw_counts >= 0), identical(rownames(raw_counts), raw_metadata$SampleID))",
            "analysis_bundle <- analysis_context$bundle",
            sep = "\n"
          ))
        }
        second_bundle_code <- if (method_id %in% c("cross_domain_network", "procrustes_cross_domain")) c(
          "",
          "# The second domain was assembled from the project selector and is part of the visible execution context.",
          "second_bundle <- analysis_context$second_bundle",
          "stopifnot(inherits(second_bundle, 'microbiome_bundle'))"
        ) else character()
        paste(
          "# ---- Input data ----",
          paste0("# Data source: abundance table selected in this project (", dQuote(dataset, q = FALSE), ")."),
          "# `analysis_context$bundle` is the method input assembled from the selected project tables.",
          "# It contains the imported abundance table (`counts`), sample metadata (`metadata`),",
          "# and, when available, taxonomy and phylogeny information.",
          "# Its explicit structure is: list(bundle = bundle, data = bundle$counts, dataset_name = selected_dataset).",
          "bundle <- analysis_context$bundle",
          second_bundle_code,
          "",
          "# Preserve the imported abundance table before any method-specific preprocessing.",
          "raw_counts <- as.matrix(bundle$counts) # rows: samples; columns: ASVs/OTUs/features",
          "storage.mode(raw_counts) <- 'numeric'",
          "if (is.null(rownames(raw_counts))) rownames(raw_counts) <- paste0('Sample_', seq_len(nrow(raw_counts)))",
          "",
          "# Read and align sample metadata to the abundance-matrix row order.",
          "raw_metadata <- as.data.frame(bundle$metadata, stringsAsFactors = FALSE)",
          "if (!'SampleID' %in% names(raw_metadata)) raw_metadata$SampleID <- rownames(raw_metadata)",
          "raw_metadata <- raw_metadata[match(rownames(raw_counts), raw_metadata$SampleID), , drop = FALSE]",
          "stopifnot(!anyNA(raw_counts), all(raw_counts >= 0), identical(rownames(raw_counts), raw_metadata$SampleID))",
          "",
          "# The following method section starts from this validated project input.",
          "analysis_bundle <- bundle",
          sep = "\n"
        )
      },
      # Microbiome documents are explicit, method-specific scripts.  Never
      # expand the application's helper dependency graph into the document.
      function_mode = "none",
      standalone_bootstrap = FALSE,
      include_input_snapshot = FALSE,
      preview_result = function() result(),
      preview_plots = function() list("Current result figure" = current_microbiome_plot()),
      preview_text = function() microbiome_model_text(result())
    )
    # Keep the legacy server output available for integrations without
    # restoring the removed duplicate code UI.
    output$code <- shiny::renderText(result()$generated_code %||% "")
    output$model_text <- shiny::renderText({
      bundle <- preview_bundle()
      protected <- unique(c(
        bundle$sample_ids %||% character(), bundle$feature_ids %||% character(),
        dava_user_data_text(bundle$counts), dava_user_data_text(bundle$taxonomy),
        dava_user_data_text(bundle$metadata), dava_user_data_text(bundle$environment)
      ))
      dava_localize_model_text(
        microbiome_model_text(result()), interface_language(), protected
      )
    })
    output$messages <- shiny::renderText({
      preview_bundle()
      issue <- preview_input_issue()
      value <- if (is.null(issue)) {
        tryCatch(result(), error = function(error) NULL)
      } else {
        NULL
      }
      sections <- sprintf("Number of fittings: %d", fit_count())
      if (!is.null(issue)) {
        issue_text <- microbiome_input_issue_text(issue, interface_language())
        sections <- c(
          sections, "", paste0("===== ", dava_translate_text("\u8f93\u5165\u6570\u636e\u8bca\u65ad", interface_language()), " ====="),
          issue_text$summary, issue_text$details
        )
      }
      if (is.null(value)) {
        bundle <- preview_bundle()
        protected <- unique(c(
          issue$protected %||% character(),
          bundle$sample_ids %||% character(), bundle$feature_ids %||% character(),
          dava_user_data_text(bundle$counts), dava_user_data_text(bundle$taxonomy),
          dava_user_data_text(bundle$metadata), dava_user_data_text(bundle$environment)
        ))
        return(dava_localize_model_text(
          paste(sections, collapse = "\n"), interface_language(), protected
        ))
      }
      if (length(value$runtime_log %||% character())) {
        sections <- c(sections, "", "===== Run log =====",
          value$runtime_log)
      }
      if (length(value$warnings %||% character())) {
        sections <- c(sections, "", "===== Warning =====",
          value$warnings)
      }
      if (length(value$errors %||% character())) {
        sections <- c(sections, "", "===== Error =====",
          value$errors)
      }
      if (length(plot_runtime_diagnostics())) {
        sections <- c(sections, "", "===== Plot rendering diagnostics =====",
          plot_runtime_diagnostics())
      }
      runtime_conditions <- dava_runtime_diagnostic_lines()
      if (length(runtime_conditions)) {
        sections <- c(sections, "", "===== Runtime warnings and errors =====",
          runtime_conditions)
      }
      startup <- dava_runtime_condition_records(
        levels = c("warning", "error"),
        source = grep("^Package startup:",
          dava_runtime_condition_records()$source, value = TRUE))
      if (nrow(startup)) {
        sections <- c(sections, "", "===== Application startup diagnostics =====",
          paste0(toupper(startup$level), ": ", startup$message))
      }
      bundle <- preview_bundle()
      protected <- unique(c(
        bundle$sample_ids %||% character(), bundle$feature_ids %||% character(),
        dava_user_data_text(bundle$counts), dava_user_data_text(bundle$taxonomy),
        dava_user_data_text(bundle$metadata), dava_user_data_text(bundle$environment)
      ))
      dava_localize_model_text(
        paste(sections, collapse = "\n"), interface_language(), protected
      )
    })
    output$download_results <- shiny::downloadHandler(
      filename = function() sprintf("microbiome_%s_%s.xlsx", input$method_id %||% "result", Sys.Date()),
      content = function(file) {
        value <- result()
        parameters <- data.frame(parameter = names(value$actual_parameters), value = vapply(value$actual_parameters, function(x) paste(x, collapse = ","), character(1)))
        code <- data.frame(code = strsplit(value$generated_code, "\n", fixed = TRUE)[[1]])
        if (!requireNamespace("writexl", quietly = TRUE)) stop("Unable to export XLSX due to missing writexl package.", call. = FALSE)
        tables <- lapply(c(value$tables, list(
          analysis_settings = parameters, generated_code = code)),
          as.data.frame)
        dava_write_xlsx(tables, file)
      }
    )
    registered_names <- shiny::reactiveVal(character())
    shiny::observeEvent(input$register_results, {
      selected_dataset_state <- shiny::isolate(list(
        count_dataset = input$count_dataset %||% "",
        taxonomy_dataset = input$taxonomy_dataset %||% "",
        metadata_dataset = input$metadata_dataset %||% "",
        environment_dataset = input$environment_dataset %||% "",
        function_dataset = input$function_dataset %||% ""
      ))
      value <- result()
      shiny::validate(shiny::need(length(value$tables), "There are currently no result tables to register."))
      prefix <- paste(value$data_version %||% "dataset", value$method_id, sep = "_")
      names <- dava_register_global_datasets(file_data, value$tables, source = paste("Microbiome analysis", value$method_label, sep = " / "), prefix = prefix)
      registered_names(names)
      # Registration updates the shared repository version. Restore the
      # method's active source selections after the selector UIs rerender;
      # adding result tables must never switch the analysis to demo data.
      for (field in names(selected_dataset_state)) {
        if (nzchar(selected_dataset_state[[field]] %||% "")) {
          shiny::updateSelectInput(session, field, selected = selected_dataset_state[[field]])
        }
      }
      shiny::showNotification(paste("Registered:", paste(unname(names), collapse = "、")), type = "message")
    }, ignoreInit = TRUE)
    invisible(list(result = result, fit_count = fit_count, registered_names = registered_names,
      navigation_method = navigation_method, method_parameter_state = method_parameter_state,
      current_input_values = current_input_values,
      preview_input_issue = preview_input_issue))
  })
}
microbiome_custom_run_to_result <- function(run, method_id, method_label = method_id,
                                            code = "") {
  if (!is.list(run) || !is.null(run$error)) {
    stop(run$error %||% "No successful run results are available for the custom code.", call. = FALSE)
  }
  value <- run$value
  supported_value <- function(object) {
    inherits(object, "microbiome_result") || is.data.frame(object) ||
      is.matrix(object) ||
      inherits(object, c("ggplot", "grob", "recordedplot", "trellis", "patchwork")) ||
      (is.list(object) && any(c(
        "result", "summary", "plot", "tables", "plots", "network_tables",
        "functional_tables", "assembly_tables", "network_objects"
      ) %in% names(object)))
  }
  if (!supported_value(value)) {
    objects <- run$objects %||% list()
    candidates <- c(
      "microbiome_result", "analysis_result", "network_result",
      "tax4fun2_result", "icamp_result", "result", "results"
    )
    for (name in candidates) {
      candidate <- objects[[name]]
      if (supported_value(candidate)) {
        value <- candidate
        break
      }
    }
    # The code-document renderer appends a generic plot-display block.  Its
    # invisible final expression can replace the method result as `.Last.value`.
    # Recover a named analysis plot/table before rejecting an otherwise valid
    # current-method script.
    if (!supported_value(value) && length(objects)) {
      supported_names <- names(objects)[vapply(objects, supported_value, logical(1))]
      preferred_names <- supported_names[grepl(
        "(^|_)(result|results|summary|table|tables|plot|plots|figure|tree)(_|$)",
        supported_names, ignore.case = TRUE, perl = TRUE)]
      candidate_names <- c(preferred_names, supported_names)
      candidate_names <- unique(candidate_names[nzchar(candidate_names)])
      if (length(candidate_names)) value <- objects[[candidate_names[[1]]]]
    }
  }
  if (is.list(value) && inherits(value$result %||% NULL, "microbiome_result")) {
    value <- value$result
  }
  if (inherits(value, "microbiome_result")) {
    validation <- validate_microbiome_result(value)
    if (!isTRUE(validation$valid)) {
      stop("Custom code returned an invalid microbiome_result.", call. = FALSE)
    }
    value$method_id <- method_id
    value$method_label <- method_label
    value$generated_code <- code %||% value$generated_code
    value$runtime_log <- c(value$runtime_log,
      "[custom-method] Result supplied by the isolated code document.")
    return(value)
  }

  tables <- list()
  plots <- list()
  add_table <- function(name, object) {
    if (is.matrix(object)) object <- as.data.frame(object, check.names = FALSE)
    if (is.data.frame(object)) tables[[name]] <<- object
  }
  add_plot <- function(name, object) {
    if (inherits(object, c("ggplot", "grob", "recordedplot", "trellis", "patchwork"))) {
      plots[[name]] <<- object
    }
  }
  add_table_collection <- function(collection, prefix = "table") {
    if (!is.list(collection)) return(invisible(NULL))
    collection_names <- names(collection)
    if (is.null(collection_names)) {
      collection_names <- paste0(prefix, seq_along(collection))
    }
    for (index in seq_along(collection)) {
      name <- collection_names[[index]]
      if (!nzchar(name)) name <- paste0(prefix, index)
      add_table(name, collection[[index]])
    }
  }
  add_plot_collection <- function(collection, prefix = "plot") {
    if (!is.list(collection)) return(invisible(NULL))
    collection_names <- names(collection)
    if (is.null(collection_names)) {
      collection_names <- paste0(prefix, seq_along(collection))
    }
    for (index in seq_along(collection)) {
      name <- collection_names[[index]]
      if (!nzchar(name)) name <- paste0(prefix, index)
      add_plot(name, collection[[index]])
    }
  }

  if (is.data.frame(value) || is.matrix(value)) {
    add_table("custom_result", value)
  } else if (inherits(value, c("ggplot", "grob", "recordedplot", "trellis", "patchwork"))) {
    add_plot("custom_plot", value)
  } else if (is.list(value)) {
    add_table_collection(value$tables)
    add_table_collection(value$network_tables, "network_table")
    add_table_collection(value$functional_tables, "functional_table")
    add_table_collection(value$assembly_tables, "assembly_table")
    add_plot_collection(value$plots)
    add_table("custom_result", value$result %||% NULL)
    add_table("custom_summary", value$summary %||% NULL)
    add_plot("custom_plot", value$plot %||% NULL)
  }
  if (!length(tables) && !length(plots)) {
    stop(paste(
      "Custom scripts must return microbiome_result, dataframe, plot object,",
      "or a list containing result/summary/plot/tables/plots."
    ), call. = FALSE)
  }

  metadata <- if (is.list(value) && !is.data.frame(value) &&
      !inherits(value, c("ggplot", "grob", "recordedplot", "trellis", "patchwork"))) {
    value
  } else {
    list()
  }
  custom_warnings <- unique(c(metadata$warnings %||% character()))
  custom_errors <- unique(c(metadata$errors %||% character()))
  if (length(custom_errors)) {
    stop(paste(custom_errors, collapse = "\n"), call. = FALSE)
  }
  specialized_tables <- function(name) {
    collection <- metadata[[name]] %||% list()
    if (!is.list(collection)) return(list())
    collection[vapply(collection, function(object) {
      is.data.frame(object) || is.matrix(object)
    }, logical(1))]
  }
  result <- new_microbiome_result(
    method_id, status = if (length(custom_warnings)) "warning" else "success",
    method_label = method_label,
    tables = tables, plots = plots,
    statistics = metadata$statistics %||% tables$custom_summary %||% data.frame(),
    actual_parameters = metadata$actual_parameters %||% list(),
    model_objects = metadata$model_objects %||% list(),
    network_objects = metadata$network_objects %||% list(),
    network_tables = specialized_tables("network_tables"),
    functional_tables = specialized_tables("functional_tables"),
    assembly_tables = specialized_tables("assembly_tables"),
    diagnostics = metadata$diagnostics %||% data.frame(),
    warnings = custom_warnings,
    available_outputs = names(tables), available_plots = names(plots),
    generated_code = code %||% "",
    runtime_log = c(
      "[custom-method] Result supplied by the isolated code document.",
      metadata$runtime_log %||% character(),
      run$output %||% ""
    )
  )
  result
}

microbiome_run_method <- function(method_id, bundle, spec = list()) {
  method <- MICROBIOME_METHOD_REGISTRY[MICROBIOME_METHOD_REGISTRY$id == method_id, , drop = FALSE]
  if (!nrow(method)) stop("Unknown microorganism analysis method:", method_id, call. = FALSE)
  if (!identical(method$status[[1]], "implemented") || !isTRUE(method$visibility[[1]])) {
    stop("This method has not completed the closed loop and is currently not operable:", method_id, call. = FALSE)
  }
  result <- tryCatch(
    if (method_id %in% c("species_env_spearman", "mantel_correlation", "maaslin2") &&
        identical(method$navigation_panel[[1]] %||% "", "multivariable_association")) {
      microbiome_run_species_environment_association(method_id, bundle, spec)
    } else switch(method$secondary_category[[1]], preprocess = microbiome_run_preprocess(method_id, bundle, spec),
           composition = microbiome_run_composition(method_id, bundle, spec),
           alpha = microbiome_run_alpha(method_id, bundle, spec),
           beta = microbiome_run_beta(method_id, bundle, spec),
           environment_spatial = microbiome_run_environment_spatial(method_id, bundle, spec),
           differential = microbiome_run_differential(method_id, bundle, spec),
           network = microbiome_run_network(method_id, bundle, spec),
           "function" = microbiome_run_function(method_id, bundle, spec),
           assembly_source = microbiome_run_assembly_source(method_id, bundle, spec),
           longitudinal_stability = microbiome_run_longitudinal(method_id, bundle, spec),
           integration_ml = microbiome_run_integration_ml(method_id, bundle, spec),
           stop("method has not yet connected to the execution adapter:", method_id, call. = FALSE)),
    error = function(error) new_microbiome_result(method_id, status = "error", marker_type = bundle$marker_type %||% "",
      data_version = bundle$data_version %||% "", analysis_spec = spec, errors = conditionMessage(error))
  )
  validation <- validate_microbiome_result(result)
  if (!validation$valid) stop("The analysis adapter returned an invalid result object.", call. = FALSE)
  result$method_label <- if (identical(
      method$secondary_category[[1]], "network")) {
    microbiome_network_progress_label(
      result$actual_parameters$network_engine %||%
        result$analysis_spec$network_engine %||% "netcomi")
  } else {
    method$label_cn[[1]]
  }
  result$category <- method$navigation_category[[1]] %||% method$secondary_category[[1]]
  result
}
