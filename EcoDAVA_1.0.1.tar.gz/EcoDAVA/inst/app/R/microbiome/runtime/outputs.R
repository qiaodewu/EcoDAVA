microbiome_registration_manifest <- function(bundle, method_id, tables = character()) {
  list(
    atomic = TRUE,
    source = paste("Microbiome analysis", method_id, sep = " / "),
    data_version = bundle$data_version,
    tables = stats::setNames(lapply(tables, function(name) list(suggested_name = paste(bundle$data_version, method_id, name, sep = "_"), overwrite = FALSE)), tables)
  )
}

microbiome_package_versions <- function(packages = character()) {
  data.frame(package = packages, version = vapply(packages, function(package) as.character(utils::packageVersion(package)), character(1)), stringsAsFactors = FALSE)
}
microbiome_ordination_plot <- function(scores, title) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) return(NULL)
  mapping <- if ("Group" %in% names(scores)) ggplot2::aes(x = Axis1, y = Axis2, colour = Group) else ggplot2::aes(x = Axis1, y = Axis2)
  ggplot2::ggplot(scores, mapping) + ggplot2::geom_point(size = 2.4, alpha = 0.8) + ggplot2::labs(title = title) + ggplot2::theme_bw()
}

microbiome_composition_plot <- function(table) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) return(NULL)
  ggplot2::ggplot(table, ggplot2::aes(x = SampleID, y = RelativeAbundance, fill = Taxon)) +
    ggplot2::geom_col(width = 0.9) + ggplot2::labs(x = NULL, y = "Relative abundance") +
    ggplot2::theme_bw() + ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90, hjust = 1, vjust = 0.5))
}

microbiome_volcano_plot <- function(table, effect_column = "effect") {
  if (!requireNamespace("ggplot2", quietly = TRUE) || !all(c(effect_column, "adjusted_p") %in% names(table))) return(NULL)
  table$Significant <- is.finite(table$adjusted_p) & table$adjusted_p < 0.05
  ggplot2::ggplot(table, ggplot2::aes(x = .data[[effect_column]], y = -log10(pmax(adjusted_p, .Machine$double.xmin)), colour = Significant)) +
    ggplot2::geom_point(alpha = 0.75) + ggplot2::scale_colour_manual(values = c("FALSE" = "#606A73", "TRUE" = "#C83E4D")) +
    ggplot2::labs(x = effect_column, y = "-log10(FDR)") + ggplot2::theme_bw()
}

microbiome_process_proportion_plot <- function(table) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) return(NULL)
  ggplot2::ggplot(table, ggplot2::aes(x = Process, y = Proportion, fill = Process)) +
    ggplot2::geom_col(width = 0.72, show.legend = FALSE) +
    ggplot2::scale_y_continuous(labels = function(value) paste0(round(100 * value), "%")) +
    ggplot2::labs(x = NULL, y = "Pairwise proportion", title = "Ecological process classification") +
    ggplot2::theme_bw() + ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 30, hjust = 1))
}
microbiome_parseable_code <- function(lines) {
  code <- paste(lines, collapse = "\n")
  parse(text = code, keep.source = FALSE)
  code
}

microbiome_environment_code_legacy <- function(method_id, spec) {
  variables <- spec$fixed_effects %||% character()
  covariates <- spec$covariates %||% character()
  rhs <- paste(variables, collapse = " + ")
  if (!nzchar(rhs)) rhs <- "SoilMoisture + SoilPH"
  lines <- switch(method_id,
    rda = c(sprintf("formula <- as.formula(%s)", dQuote(paste("community ~", rhs), q = FALSE)), "fit <- vegan::rda(formula, data = environment)", "test <- vegan::anova.cca(fit, permutations = 999)"),
    cca = c(sprintf("formula <- as.formula(%s)", dQuote(paste("community ~", rhs), q = FALSE)), "fit <- vegan::cca(formula, data = environment)", "test <- vegan::anova.cca(fit, permutations = 999)"),
    dbrda = c(sprintf("formula <- as.formula(%s)", dQuote(paste("community ~", rhs), q = FALSE)), "fit <- vegan::capscale(formula, data = environment, distance = 'bray')", "test <- vegan::anova.cca(fit, permutations = 999)"),
    partial_rda = c(sprintf("formula <- as.formula(%s)", dQuote(paste0("community ~ ", rhs, " + Condition(", paste(covariates, collapse = " + "), ")"), q = FALSE)), "fit <- vegan::rda(formula, data = environment)", "test <- vegan::anova.cca(fit, permutations = 999)"),
    partial_cca = c(sprintf("formula <- as.formula(%s)", dQuote(paste0("community ~ ", rhs, " + Condition(", paste(covariates, collapse = " + "), ")"), q = FALSE)), "fit <- vegan::cca(formula, data = environment)", "test <- vegan::anova.cca(fit, permutations = 999)"),
    constrained_term_tests = c(sprintf("fit <- vegan::rda(community ~ %s, data = environment)", rhs), "term_tests <- vegan::anova.cca(fit, by = 'term', permutations = 999)"),
    envfit = c("ordination <- vegan::rda(vegan::decostand(community, 'hellinger'))", sprintf("fit <- vegan::envfit(ordination, environment[, c(%s), drop = FALSE], permutations = 999)", paste(dQuote(variables), collapse = ", "))),
    varpart = c("response <- vegan::decostand(community, 'hellinger')", "fit <- vegan::varpart(response, environment[, 1, drop = FALSE], environment[, -1, drop = FALSE])"),
    procrustes_environment = c("community_fit <- cmdscale(vegan::vegdist(community, 'bray'), k = 2)", "environment_fit <- prcomp(scale(environment))$x[, 1:2]", "fit <- vegan::protest(community_fit, environment_fit, permutations = 999)"),
    partial_mantel = c("community_distance <- vegan::vegdist(community, method = 'bray')", "predictor_distance <- dist(scale(environment[, 1, drop = FALSE]))", "covariate_distance <- dist(scale(environment[, -1, drop = FALSE]))", "test <- vegan::mantel.partial(community_distance, predictor_distance, covariate_distance, permutations = 999)"),
    mantel = c("community_distance <- vegan::vegdist(community, method = 'bray')", "environment_distance <- dist(scale(environment))", "test <- vegan::mantel(community_distance, environment_distance, permutations = 999)"))
  microbiome_parseable_code(c("library(vegan)", "community <- as.matrix(bundle$counts)", lines))
}

microbiome_microeco_input_code <- function(object_name = "dataset", require_tree = FALSE) {
  c(
    "counts_for_microeco <- as.matrix(bundle$counts)",
    "sample_table <- as.data.frame(bundle$metadata, check.names = FALSE)",
    "if (!nrow(sample_table)) sample_table <- data.frame(SampleID = rownames(counts_for_microeco))",
    "rownames(sample_table) <- rownames(counts_for_microeco)",
    "tax_table <- as.data.frame(bundle$taxonomy, check.names = FALSE)",
    "if (!nrow(tax_table)) tax_table <- data.frame(Feature = colnames(counts_for_microeco))",
    "rownames(tax_table) <- colnames(counts_for_microeco)",
    paste0(object_name, " <- microeco::microtable$new(sample_table = sample_table, otu_table = as.data.frame(t(counts_for_microeco), check.names = FALSE), tax_table = tax_table, phylo_tree = ", if (require_tree) "bundle$phylogeny" else "NULL", ", auto_tidy = TRUE)")
  )
}

microbiome_function_table_input_code <- function() {
  c(
    "function_table <- as.matrix(bundle$function_table)",
    "storage.mode(function_table) <- 'double'",
    "row_match <- all(rownames(bundle$counts) %in% rownames(function_table))",
    "column_match <- all(rownames(bundle$counts) %in% colnames(function_table))",
    "if (!row_match && column_match) function_table <- t(function_table)",
    "stopifnot(all(rownames(bundle$counts) %in% rownames(function_table)))",
    "function_table <- function_table[rownames(bundle$counts), , drop = FALSE]",
    "stopifnot(all(is.finite(function_table)), all(function_table >= 0), all(rowSums(function_table) > 0), !anyDuplicated(colnames(function_table)))"
  )
}

microbiome_environment_code <- function(method_id, spec) {
  supported <- c("rda", "cca", "dbrda", "envfit", "mantel")
  if (!method_id %in% supported) {
    return(microbiome_environment_code_legacy(method_id, spec))
  }
  variables <- as.character(spec$fixed_effects %||% character())
  if (!length(variables)) variables <- c("SoilMoisture", "SoilPH")
  variable_code <- paste(dQuote(variables, q = FALSE), collapse = ", ")
  group_variable <- trimws(as.character(spec$group_variable %||% ""))
  group_code <- if (nzchar(group_variable)) dQuote(group_variable, q = FALSE) else "''"
  permutations <- as.integer(spec$permutations %||% 999L)
  distance <- spec$distance_method %||% spec$distance %||% "bray"
  common <- c(
    "library(vegan)",
    "community_counts <- as.matrix(bundle$counts)",
    sprintf("environment_variables <- c(%s)", variable_code),
    "environment_source <- as.data.frame(bundle$environment, check.names = FALSE)",
    "stopifnot(nrow(environment_source) > 0L)",
    "environment_ids <- if ('SampleID' %in% names(environment_source)) as.character(environment_source$SampleID) else rownames(environment_source)",
    "environment_index <- match(rownames(community_counts), environment_ids)",
    "stopifnot(!anyNA(environment_index))",
    "environment_source <- environment_source[environment_index, , drop = FALSE]",
    "rownames(environment_source) <- rownames(community_counts)",
    "if (!length(environment_variables)) environment_variables <- names(environment_source)[vapply(environment_source, is.numeric, logical(1))]",
    "environment_variables <- setdiff(environment_variables, 'SampleID')",
    "stopifnot(length(environment_variables) > 0L, all(environment_variables %in% names(environment_source)), all(vapply(environment_source[environment_variables], is.numeric, logical(1))), !anyNA(environment_source[environment_variables]))",
    "environment <- environment_source[, environment_variables, drop = FALSE]",
    sprintf("group_variable <- %s", group_code),
    "analysis_environment <- environment",
    "if (nzchar(group_variable)) {",
    "  group <- factor(bundle$metadata[[group_variable]])",
    "  analysis_environment[[group_variable]] <- group",
    "}",
    "model_terms <- c(if (nzchar(group_variable)) group_variable else character(), environment_variables)",
    sprintf("set.seed(%dL)", as.integer(spec$seed %||% 2026L))
  )
  lines <- switch(method_id,
    rda = c(
      "library(rdacca.hp)",
      "community_response <- vegan::decostand(community_counts, method = 'hellinger')",
      "formula <- stats::reformulate(model_terms, response = 'community_response')",
      "fit <- vegan::rda(formula, data = analysis_environment)",
      sprintf("overall_test <- vegan::anova.cca(fit, permutations = %dL)", permutations),
      sprintf("environmental_variable_tests <- vegan::anova.cca(fit, by = 'term', permutations = %dL)", permutations),
      sprintf("hierarchical_partitioning <- rdacca.hp::rdacca.hp(community_response, environment, method = 'RDA', type = %s, n.perm = %dL)",
        dQuote(spec$hierarchical_partition_type %||% "adjR2", q = FALSE),
        as.integer(spec$hierarchical_partition_permutations %||% permutations)),
      "print(overall_test)",
      "print(environmental_variable_tests)",
      "print(hierarchical_partitioning)"
    ),
    cca = c(
      "library(rdacca.hp)",
      "community_response <- community_counts",
      "formula <- stats::reformulate(model_terms, response = 'community_response')",
      "fit <- vegan::cca(formula, data = analysis_environment)",
      sprintf("overall_test <- vegan::anova.cca(fit, permutations = %dL)", permutations),
      sprintf("environmental_variable_tests <- vegan::anova.cca(fit, by = 'term', permutations = %dL)", permutations),
      sprintf("hierarchical_partitioning <- rdacca.hp::rdacca.hp(community_response, environment, method = 'CCA', type = %s, n.perm = %dL)",
        dQuote(spec$hierarchical_partition_type %||% "adjR2", q = FALSE),
        as.integer(spec$hierarchical_partition_permutations %||% permutations)),
      "print(overall_test)",
      "print(environmental_variable_tests)",
      "print(hierarchical_partitioning)"
    ),
    dbrda = c(
      "library(rdacca.hp)",
      "community_response <- community_counts",
      "formula <- stats::reformulate(model_terms, response = 'community_response')",
      sprintf("fit <- vegan::dbrda(formula, data = analysis_environment, distance = %s)",
        dQuote(distance, q = FALSE)),
      sprintf("overall_test <- vegan::anova.cca(fit, permutations = %dL)", permutations),
      sprintf("environmental_variable_tests <- vegan::anova.cca(fit, by = 'term', permutations = %dL)", permutations),
      sprintf("community_distance <- vegan::vegdist(community_response, method = %s)",
        dQuote(distance, q = FALSE)),
      sprintf("hierarchical_partitioning <- rdacca.hp::rdacca.hp(community_distance, environment, method = 'dbRDA', dbrdatype = 'dbrda', type = %s, n.perm = %dL)",
        dQuote(spec$hierarchical_partition_type %||% "adjR2", q = FALSE),
        as.integer(spec$hierarchical_partition_permutations %||% permutations)),
      "print(overall_test)",
      "print(environmental_variable_tests)",
      "print(hierarchical_partitioning)"
    ),
    envfit = c(
      sprintf("community_distance <- vegan::vegdist(community_counts, method = %s)",
        dQuote(distance, q = FALSE)),
      "ordination <- stats::cmdscale(community_distance, k = 2, eig = TRUE, add = TRUE)",
      sprintf("fit <- vegan::envfit(ordination$points, analysis_environment, permutations = %dL)",
        permutations),
      "environmental_variable_tests <- data.frame(R2 = fit$vectors$r, PValue = fit$vectors$pvals)",
      "group_factor_test <- if (nzchar(group_variable)) data.frame(R2 = fit$factors$r, PValue = fit$factors$pvals) else data.frame()",
      "print(environmental_variable_tests)"
    ),
    mantel = c(
      sprintf("community_distance <- vegan::vegdist(community_counts, method = %s)",
        dQuote(distance, q = FALSE)),
      sprintf("environment_distance <- stats::dist(scale(environment), method = %s)",
        dQuote(spec$environment_distance_method %||% "euclidean", q = FALSE)),
      sprintf("overall_test <- vegan::mantel(community_distance, environment_distance, method = %s, permutations = %dL)",
        dQuote(spec$mantel_correlation %||% "pearson", q = FALSE), permutations),
      sprintf("environmental_variable_tests <- lapply(environment_variables, function(variable) vegan::mantel(community_distance, stats::dist(scale(environment[, variable, drop = FALSE]), method = %s), method = %s, permutations = %dL))",
        dQuote(spec$environment_distance_method %||% "euclidean", q = FALSE),
        dQuote(spec$mantel_correlation %||% "pearson", q = FALSE), permutations),
      "names(environmental_variable_tests) <- environment_variables",
      sprintf("grouped_mantel_tests <- if (nzchar(group_variable)) lapply(split(seq_len(nrow(community_counts)), group), function(index) { if (length(index) < 4L) return(NULL); vegan::mantel(vegan::vegdist(community_counts[index, , drop = FALSE], method = %s), stats::dist(scale(environment[index, , drop = FALSE]), method = %s), method = %s, permutations = %dL) }) else list()",
        dQuote(distance, q = FALSE),
        dQuote(spec$environment_distance_method %||% "euclidean", q = FALSE),
        dQuote(spec$mantel_correlation %||% "pearson", q = FALSE), permutations),
      "print(overall_test)",
      "print(environmental_variable_tests)"
    )
  )
  microbiome_parseable_code(c(common, lines))
}

microbiome_differential_code <- function(method_id, spec) {
  group <- spec$group %||% "Treatment"
  if (method_id == "lefse") {
    subgroup <- as.character(spec$lefse_subgroup_variable %||% "")
    subgroup_code <- if (nzchar(subgroup)) dQuote(subgroup, q = FALSE) else "NULL"
    group_order <- as.character(spec$lefse_group_order %||% character())
    group_order_code <- if (length(group_order)) {
      paste0("c(", paste(dQuote(group_order, q = FALSE), collapse = ", "), ")")
    } else {
      "NULL"
    }
    labels <- microbiome_lefse_selected_labels(spec$lefse_cladogram_labels)
    labels_code <- if (length(labels)) {
      paste0("c(", paste(dQuote(labels, q = FALSE), collapse = ", "), ")")
    } else {
      "NULL"
    }
    return(microbiome_parseable_code(c(
      "library(microeco)",
      microbiome_microeco_input_code("dataset"),
      "dataset$tax_table <- microeco::tidy_taxonomy(dataset$tax_table, add_prefix = TRUE)",
      "dataset$tidy_dataset()",
      "dataset$cal_abund()",
      sprintf(paste0(
        "fit <- microeco::trans_diff$new(dataset = dataset, method = 'lefse', ",
        "group = %s, taxa_level = 'all', filter_thres = %s, alpha = %s, ",
        "p_adjust_method = %s, remove_unknown = %s, lefse_subgroup = %s, ",
        "lefse_min_subsam = %dL, lefse_sub_strict = %s, lefse_sub_alpha = %s, ",
        "lefse_norm = %s, nresam = %s, boots = %dL)"),
        dQuote(group, q = FALSE),
        format(as.numeric(spec$lefse_filter_threshold %||% 0)),
        format(as.numeric(spec$lefse_alpha %||% 0.05)),
        dQuote(spec$lefse_p_adjust_method %||% "fdr", q = FALSE),
        if (isTRUE(spec$lefse_remove_unknown %||% TRUE)) "TRUE" else "FALSE",
        subgroup_code,
        as.integer(spec$lefse_min_subsample %||% 10L),
        if (isTRUE(spec$lefse_subgroup_strict %||% FALSE)) "TRUE" else "FALSE",
        format(as.numeric(spec$lefse_subgroup_alpha %||% spec$lefse_alpha %||% 0.05)),
        format(as.numeric(spec$lefse_norm %||% 1e6), scientific = FALSE),
        format(as.numeric(spec$lefse_nresam %||% 0.6667)),
        as.integer(spec$lefse_boots %||% 30L)),
      "lefse_results <- fit$res_diff",
      sprintf(paste0(
        "lda_rows <- which(is.finite(fit$res_diff$LDA) & fit$res_diff$LDA > %s); ",
        "lda_rows <- head(lda_rows, %dL)"),
        format(as.numeric(spec$lefse_lda_threshold %||% 2)),
        as.integer(spec$lefse_plot_max_taxa %||% 30L)),
      "lda_plot_fit <- fit$clone(deep = TRUE)",
      "lda_plot_fit$res_diff <- lda_plot_fit$res_diff[lda_rows, , drop = FALSE]",
      sprintf(paste0(
        "lda_plot <- lda_plot_fit$plot_diff_bar(threshold = NULL, ",
        "use_number = seq_along(lda_rows), ",
        "keep_full_name = %s, keep_prefix = %s, group_order = %s, ",
        "group_aggre = %s, group_two_sep = %s, coord_flip = %s, add_sig = %s)"),
        if (isTRUE(spec$lefse_keep_full_name %||% FALSE)) "TRUE" else "FALSE",
        if (isTRUE(spec$lefse_keep_prefix %||% TRUE)) "TRUE" else "FALSE",
        group_order_code,
        if (isTRUE(spec$lefse_group_aggregate %||% TRUE)) "TRUE" else "FALSE",
        if (isTRUE(spec$lefse_two_group_separate %||% TRUE)) "TRUE" else "FALSE",
        if (isTRUE(spec$lefse_bar_coord_flip %||% TRUE)) "TRUE" else "FALSE",
        if (isTRUE(spec$lefse_bar_add_significance %||% FALSE)) "TRUE" else "FALSE"),
      sprintf(paste0(
        "cladogram <- fit$plot_diff_cladogram(use_taxa_num = %dL, ",
        "use_feature_num = %dL, clade_label_level = %dL, ",
        "select_show_labels = %s, only_select_show = %s, branch_size = %s, ",
        "alpha = %s, clade_label_size = %s, node_size_scale = %s, ",
        "node_size_offset = %s, annotation_shape = %dL, annotation_shape_size = %s)"),
        as.integer(spec$lefse_cladogram_background_taxa %||% 200L),
        as.integer(spec$lefse_cladogram_features %||% 120L),
        as.integer(spec$lefse_clade_label_level %||% 5L),
        labels_code,
        if (isTRUE(spec$lefse_cladogram_only_selected %||% FALSE)) "TRUE" else "FALSE",
        format(as.numeric(spec$lefse_branch_size %||% 0.2)),
        format(as.numeric(spec$lefse_branch_alpha %||% 0.2)),
        format(as.numeric(spec$lefse_clade_label_size %||% 2)),
        format(as.numeric(spec$lefse_node_size_scale %||% 1)),
        format(as.numeric(spec$lefse_node_size_offset %||% 1)),
        as.integer(spec$lefse_annotation_shape %||% 22L),
        format(as.numeric(spec$lefse_annotation_size %||% 5))),
      "# Keep the microeco/ggtree plot object returned by the same plotting call.",
      "cladogram <- cladogram"
    )))
  }
  if (method_id == "wilcoxon_kruskal") return(microbiome_parseable_code(c(
    "counts <- as.matrix(bundle$counts)", sprintf("group <- factor(bundle$metadata[[%s]])", dQuote(group, q = FALSE)),
    "relative <- counts / rowSums(counts)", "tests <- apply(relative, 2, function(x) if (nlevels(group) == 2) wilcox.test(x ~ group) else kruskal.test(x ~ group))",
    "p_adjusted <- p.adjust(vapply(tests, function(x) x$p.value, numeric(1)), method = 'BH')"
  )))
  if (method_id == "anova_welch") return(microbiome_parseable_code(c(
    "counts <- as.matrix(bundle$counts)", sprintf("group <- factor(bundle$metadata[[%s]])", dQuote(group, q = FALSE)),
    "relative <- counts / rowSums(counts)", "tests <- apply(relative, 2, function(x) oneway.test(x ~ group, var.equal = FALSE))",
    "p_adjusted <- p.adjust(vapply(tests, function(x) x$p.value, numeric(1)), method = 'BH')")))
  if (method_id == "simper") return(microbiome_parseable_code(c("library(vegan)", "counts <- as.matrix(bundle$counts)",
    sprintf("group <- factor(bundle$metadata[[%s]])", dQuote(group, q = FALSE)),
    "fit <- vegan::simper(counts / rowSums(counts), group, permutations = 999)")))
  if (method_id == "linda") return(microbiome_parseable_code(c("library(LinDA)", "counts <- as.matrix(bundle$counts)",
    sprintf("metadata <- transform(bundle$metadata, .dava_group = factor(bundle$metadata[[%s]]))", dQuote(group, q = FALSE)),
    "fit <- LinDA::linda(t(counts), metadata, '~ .dava_group', type = 'count', p.adj.method = 'BH', prev.cut = 0.1, n.cores = 1)")))
  if (method_id == "ancombc2") {
    differential_method <- spec$differential_method %||% "ancombc2"
    if (differential_method %in% c("deseq2", "edger")) {
      return(microbiome_parseable_code(strsplit(
        microbiome_count_differential_code(differential_method, spec),
        "\n", fixed = TRUE)[[1L]]))
    }
    mode <- spec$analysis_mode %||% "two_group"
    flags <- microbiome_ancombc2_flags(mode)
    levels_code <- if (length(spec$group_levels %||% character())) {
      paste0("c(", paste(dQuote(spec$group_levels, q = FALSE), collapse = ", "), ")")
    } else {
      "levels(factor(bundle$metadata[[group_variable]]))"
    }
    random_structure <- spec$random_structure %||% "none"
    random_variables <- switch(random_structure,
      none = character(),
      intercept = as.character(spec$random_cluster %||% ""),
      slope = as.character(c(
        spec$random_cluster %||% "", spec$random_slope_variable %||% "")),
      nested = as.character(c(
        spec$random_outer_variable %||% "", spec$random_inner_variable %||% "")),
      stop("Unsupported ANCOM-BC2 random-effect structure.", call. = FALSE)
    )
    random_variables <- unique(random_variables[
      !is.na(random_variables) & nzchar(random_variables)])
    random_formula <- switch(random_structure,
      none = "NULL",
      intercept = dQuote(sprintf("(1 | %s)", random_variables[[1]]), q = FALSE),
      slope = dQuote(sprintf("(%s | %s)", random_variables[[2]],
        random_variables[[1]]), q = FALSE),
      nested = dQuote(sprintf("(1 | %s/%s)", random_variables[[1]],
        random_variables[[2]]), q = FALSE))
    random_variables_code <- if (length(random_variables)) {
      paste0("c(", paste(dQuote(random_variables, q = FALSE), collapse = ", "), ")")
    } else {
      "character()"
    }
    lfc_conversion <- if (identical(spec$lfc_scale %||% "ln", "log2")) {
      c(
        "# ANCOM-BC2 reports natural-log fold changes; convert result columns only for display.",
        "convert_lfc_to_log2 <- function(table) {",
        "  if (is.null(table)) return(NULL)",
        "  lfc_columns <- grep('^lfc_', names(table), value = TRUE)",
        "  table[lfc_columns] <- lapply(table[lfc_columns], function(lfc) lfc / log(2))",
        "  table",
        "}",
        "fixed_effect_results <- convert_lfc_to_log2(fixed_effect_results)",
        "pairwise_results <- convert_lfc_to_log2(pairwise_results)",
        "dunnett_results <- convert_lfc_to_log2(dunnett_results)",
        "trend_results <- convert_lfc_to_log2(trend_results)"
      )
    } else {
      "# ANCOM-BC2 effect columns are Natural-log fold change."
    }
    trend_control_lines <- if (isTRUE(flags$trend)) c(
      "# Construct the ordered trend cone explicitly for the selected group levels.",
      "coefficient_count <- length(confirmed_levels) - 1L",
      "stopifnot(coefficient_count >= 2L)",
      "increasing_contrast <- matrix(0, nrow = coefficient_count, ncol = coefficient_count)",
      "increasing_contrast[1, 1] <- 1",
      "if (coefficient_count > 1L) for (index in 2:coefficient_count) { increasing_contrast[index, index - 1L] <- -1; increasing_contrast[index, index] <- 1 }",
      paste0("trend_pattern <- ", dQuote(spec$trend_pattern %||% "increasing", q = FALSE)),
      paste0("turning_level <- ", dQuote(spec$trend_turning_level %||% "", q = FALSE)),
      "turn <- match(turning_level, confirmed_levels); if (is.na(turn) || turn <= 1L || turn >= length(confirmed_levels)) turn <- ceiling(length(confirmed_levels) / 2)",
      "turn_node <- max(1L, min(coefficient_count, turn - 1L))",
      "umbrella_contrast <- increasing_contrast; if (turn <= coefficient_count) umbrella_contrast[turn:coefficient_count, ] <- -umbrella_contrast[turn:coefficient_count, ]",
      "trend_contrasts <- list(increasing = increasing_contrast, decreasing = -increasing_contrast, umbrella = umbrella_contrast, inverted_umbrella = -umbrella_contrast)",
      "selected_contrast <- trend_contrasts[[trend_pattern]]",
      "selected_node <- if (trend_pattern %in% c('increasing', 'decreasing')) coefficient_count else turn_node",
      paste0("trend_control <- list(contrast = list(selected_contrast, selected_contrast), node = list(selected_node, selected_node), solver = 'OSQP', B = ", max(10L, as.integer(spec$mdfdr_bootstraps %||% 100L)), "L)")
    ) else {
      paste0("trend_control <- list(contrast = NULL, node = NULL, solver = 'OSQP', B = ", as.integer(spec$mdfdr_bootstraps %||% 100L), "L)")
    }
    plot_spec_code <- paste(utils::capture.output(dput(spec)), collapse = "\n")
    result_assembly <- c(
      "",
      "# ---- Standardized result tables and selected plots ----",
      "# These helpers are also used by the main analysis to keep table columns and plot types identical.",
      "plot_spec <- ",
      plot_spec_code,
      "reference_group <- plot_spec$reference_group %||% confirmed_levels[[1L]]",
      "prevalence <- colMeans(counts > 0)",
      "mean_abundance <- colMeans(counts)",
      "fixed_effect_table <- microbiome_ancombc2_long_result(fit$res, 'fixed_effect', confirmed_levels, reference_group, plot_spec$lfc_scale %||% 'ln')",
      "global_table <- microbiome_ancombc2_long_result(fit$res_global, 'global', confirmed_levels, reference_group, plot_spec$lfc_scale %||% 'ln')",
      "pairwise_table <- microbiome_ancombc2_long_result(fit$res_pair, 'pairwise', confirmed_levels, reference_group, plot_spec$lfc_scale %||% 'ln')",
      "dunnett_table <- microbiome_ancombc2_long_result(fit$res_dunn, 'dunnett', confirmed_levels, reference_group, plot_spec$lfc_scale %||% 'ln')",
      "trend_table <- microbiome_ancombc2_long_result(fit$res_trend, 'trend', confirmed_levels, reference_group, plot_spec$lfc_scale %||% 'ln')",
      "if (NROW(trend_table)) trend_table$trend_pattern <- plot_spec$trend_pattern %||% 'increasing'",
      "structural_table <- microbiome_ancombc2_structural_zeros(fit$zero_ind)",
      "add_abundance <- function(value) {",
      "  if (!NROW(value)) return(value)",
      "  value$prevalence <- prevalence[value$Feature]",
      "  value$mean_abundance <- mean_abundance[value$Feature]",
      "  value$convergence <- if ('effect' %in% names(value)) is.finite(value$effect) else TRUE",
      "  value",
      "}",
      "active_mode_results <- switch(analysis_mode, two_group = fixed_effect_table, global = global_table, pairwise = pairwise_table, dunnett = dunnett_table, trend = trend_table)",
      "if (!NROW(active_mode_results)) stop('ANCOM-BC2 did not return results for the selected analysis mode.', call. = FALSE)",
      "ancom_tables <- list(fixed_effect_results = add_abundance(fixed_effect_table), global_results = add_abundance(global_table), pairwise_results = add_abundance(pairwise_table), dunnett_results = add_abundance(dunnett_table), trend_results = add_abundance(trend_table), structural_zero_results = add_abundance(structural_table))",
      "keep_tables <- vapply(ancom_tables, NROW, integer(1)) > 0L",
      "keep_tables[['structural_zero_results']] <- TRUE",
      "ancom_tables <- ancom_tables[keep_tables]",
      "active_mode_results <- microbiome_attach_taxonomy(add_abundance(active_mode_results), bundle)",
      "ancom_tables <- lapply(ancom_tables, microbiome_attach_taxonomy, bundle = bundle)",
      "ancom_tables$model_differential_taxa <- active_mode_results[as.logical(active_mode_results$differentially_abundant %||% FALSE), , drop = FALSE]",
      "ancom_tables$robust_differential_taxa <- active_mode_results[as.logical(active_mode_results$robust_difference %||% FALSE), , drop = FALSE]",
      "ancom_tables$sensitivity_candidates <- active_mode_results[as.logical(active_mode_results$differentially_abundant %||% FALSE) & !as.logical(active_mode_results$robust_difference %||% FALSE), , drop = FALSE]",
      "plots <- microbiome_ancombc2_plots(active_mode_results, ancom_tables, counts, group, group_variable, bundle$taxonomy, bundle$metadata, plot_spec)",
      "result <- list(tables = c(list(active_mode_results = active_mode_results), ancom_tables), plots = plots, model = fit)",
      "result"
    )
    return(microbiome_parseable_code(c(
      "library(ANCOMBC)",
      "stopifnot(bundle$is_raw_count)",
      sprintf("group_variable <- %s", dQuote(group, q = FALSE)),
      sprintf("confirmed_levels <- %s", levels_code),
      "counts <- as.matrix(bundle$counts)",
      "metadata <- as.data.frame(bundle$metadata, check.names = FALSE)",
      "if ('SampleID' %in% names(metadata)) rownames(metadata) <- as.character(metadata$SampleID)",
      "metadata <- metadata[match(rownames(counts), rownames(metadata)), , drop = FALSE]",
      "stopifnot(!anyNA(rownames(metadata)), identical(rownames(counts), rownames(metadata)))",
      "group <- factor(metadata[[group_variable]], levels = confirmed_levels)",
      sprintf("random_structure <- %s", dQuote(random_structure, q = FALSE)),
      sprintf("random_variables <- %s", random_variables_code),
      "stopifnot(all(random_variables %in% names(metadata)))",
      "model_metadata <- data.frame(SampleID = rownames(metadata), group = group, row.names = rownames(metadata), check.names = FALSE)",
      "for (variable in random_variables) {",
      "  value <- metadata[[variable]]",
      "  stopifnot(is.atomic(value), !is.matrix(value), length(value) == nrow(metadata))",
      "  model_metadata[[variable]] <- value",
      "}",
      sprintf("random_formula <- %s", random_formula),
      sprintf("analysis_mode <- %s", dQuote(mode, q = FALSE)),
      trend_control_lines,
      sprintf(paste0(
        "fit <- ancombc2(data = t(round(counts)), taxa_are_rows = TRUE, ",
        "meta_data = model_metadata, fix_formula = 'group', rand_formula = random_formula, ",
        "group = 'group', p_adj_method = %s, pseudo_sens = TRUE, prv_cut = %s, ",
        "lib_cut = 0, struc_zero = TRUE, neg_lb = TRUE, n_cl = 1, verbose = FALSE, ",
        "global = %s, pairwise = %s, dunnet = %s, trend = %s, ",
        "trend_control = trend_control, mdfdr_control = list(fwer_ctrl_method = 'holm', B = %dL))"),
        dQuote(spec$fdr_method %||% "BH", q = FALSE),
        format(as.numeric(spec$minimum_prevalence %||% 0.1)),
        if (flags$global) "TRUE" else "FALSE",
        if (flags$pairwise) "TRUE" else "FALSE",
        if (flags$dunnet) "TRUE" else "FALSE",
        if (flags$trend) "TRUE" else "FALSE",
        as.integer(spec$mdfdr_bootstraps %||% 100L)),
      "fixed_effect_results <- fit$res",
      "global_results <- fit$res_global",
      "pairwise_results <- fit$res_pair",
      "dunnett_results <- fit$res_dunn",
      "trend_results <- fit$res_trend",
      "structural_zero_results <- fit$zero_ind",
      lfc_conversion,
      result_assembly
    )))
  }
  if (method_id == "maaslin2") return(microbiome_parseable_code(c("library(Maaslin2)",
    sprintf("fixed_effects <- %s", deparse(c(group))), "metadata <- bundle$metadata[, fixed_effects, drop = FALSE]",
    "output_dir <- tempfile('maaslin2_')", "dir.create(output_dir)",
    "reference <- paste(fixed_effects[1], levels(factor(metadata[[fixed_effects[1]]]))[1], sep = ',')",
    "fit <- Maaslin2(input_data = as.data.frame(bundle$counts), input_metadata = metadata, output = output_dir, normalization = 'TSS', transform = 'LOG', analysis_method = 'LM', fixed_effects = fixed_effects, correction = 'BH', cores = 1, plot_heatmap = FALSE, plot_scatter = FALSE, save_models = FALSE, reference = reference)")))
  if (method_id == "ancombc") return(microbiome_parseable_code(c(
    "library(ANCOMBC)", "library(phyloseq)",
    "counts <- round(as.matrix(bundle$counts))",
    sprintf("group_variable <- %s", dQuote(group, q = FALSE)),
    "sample_data_table <- as.data.frame(bundle$metadata, check.names = FALSE)",
    "rownames(sample_data_table) <- rownames(counts)",
    "taxonomy <- as.matrix(bundle$taxonomy)",
    "if (!nrow(taxonomy)) taxonomy <- matrix(colnames(counts), ncol = 1, dimnames = list(colnames(counts), 'Feature'))",
    "phyloseq_data <- phyloseq::phyloseq(phyloseq::otu_table(t(counts), taxa_are_rows = TRUE), phyloseq::sample_data(sample_data_table), phyloseq::tax_table(taxonomy))",
    "fit <- ANCOMBC::ancombc(data = phyloseq_data, formula = group_variable, p_adj_method = 'BH', prv_cut = 0.1, lib_cut = 0, group = group_variable, struc_zero = TRUE, neg_lb = TRUE, tol = 1e-5, max_iter = 100, conserve = TRUE, alpha = 0.05, global = TRUE)",
    "coefficient <- setdiff(names(fit$res$beta), 'taxon')[1]",
    "table <- data.frame(Feature = fit$res$beta$taxon, effect = fit$res$beta[[coefficient]], standard_error = fit$res$se[[coefficient]], raw_p = fit$res$p_val[[coefficient]], adjusted_p = fit$res$q_val[[coefficient]], stringsAsFactors = FALSE)",
    "plot <- ggplot2::ggplot(table, ggplot2::aes(effect, -log10(pmax(adjusted_p, .Machine$double.xmin)), colour = adjusted_p < 0.05)) + ggplot2::geom_point() + ggplot2::theme_classic()",
    "tables <- list(differential_abundance = table); plots <- list(volcano = plot); print(plot)",
    "result <- list(tables = tables, plots = plots, model = fit)", "result"
  )))
  if (method_id == "aldex2") return(microbiome_parseable_code(c(
    "library(ALDEx2)", "counts <- round(t(as.matrix(bundle$counts)))",
    sprintf("group <- factor(bundle$metadata[[%s]])", dQuote(group, q = FALSE)),
    paste0("set.seed(", as.integer(spec$seed %||% 2026L), "L)"),
    "clr <- ALDEx2::aldex.clr(counts, group, mc.samples = 128, denom = 'all', verbose = FALSE)",
    "test_table <- if (nlevels(group) == 2L) ALDEx2::aldex.ttest(clr, paired.test = FALSE) else ALDEx2::aldex.kw(clr)",
    "effect_table <- if (nlevels(group) == 2L) ALDEx2::aldex.effect(clr) else NULL",
    "table <- data.frame(Feature = rownames(test_table), test_table, row.names = NULL, check.names = FALSE)",
    "if (!is.null(effect_table)) table <- cbind(table, effect_table[match(table$Feature, rownames(effect_table)), , drop = FALSE])",
    "p_column <- intersect(c('we.ep', 'kw.ep'), names(table))[1]; table$adjusted_p <- p.adjust(table[[p_column]], method = 'BH')",
    "tables <- list(differential_abundance = table); result <- list(tables = tables, model = list(clr = clr, test = test_table, effect = effect_table))", "result"
  )))
  if (method_id == "corncob") return(microbiome_parseable_code(c(
    "library(corncob)", "library(phyloseq)",
    "counts <- round(as.matrix(bundle$counts))",
    sprintf("group_variable <- %s", dQuote(group, q = FALSE)),
    "sample_data_table <- as.data.frame(bundle$metadata, check.names = FALSE); rownames(sample_data_table) <- rownames(counts)",
    "phyloseq_data <- phyloseq::phyloseq(phyloseq::otu_table(t(counts), taxa_are_rows = TRUE), phyloseq::sample_data(sample_data_table))",
    "model_formula <- stats::reformulate(group_variable)",
    "fit <- corncob::differentialTest(formula = model_formula, phi.formula = ~ 1, formula_null = ~ 1, phi.formula_null = ~ 1, test = 'Wald', boot = FALSE, data = phyloseq_data)",
    "table <- data.frame(Feature = names(fit$p), raw_p = unname(fit$p), adjusted_p = p.adjust(unname(fit$p), method = 'BH'), stringsAsFactors = FALSE)",
    "tables <- list(differential_abundance = table); result <- list(tables = tables, model = fit)", "result"
  )))
  if (method_id %in% c("feature_glm", "feature_mixed_model", "interaction_association", "continuous_gradient_association")) {
    predictor <- as.character((spec$fixed_effects %||% spec$environment_factors %||% group)[[1]])
    second_predictor <- as.character((spec$fixed_effects %||% c(group, predictor))[min(2L, length(spec$fixed_effects %||% c(group, predictor)))])
    random_effect <- as.character(spec$random_effect %||% "Subject")
    lines <- c(
      if (identical(method_id, "feature_mixed_model")) "library(lme4)" else character(),
      "counts <- as.matrix(bundle$counts)", "relative <- sweep(counts, 1, rowSums(counts), '/')",
      "metadata <- as.data.frame(bundle$metadata, check.names = FALSE)",
      paste0("predictor <- ", dQuote(predictor, q = FALSE)),
      if (identical(method_id, "interaction_association")) paste0("second_predictor <- ", dQuote(second_predictor, q = FALSE)) else character(),
      if (identical(method_id, "feature_mixed_model")) paste0("random_effect <- ", dQuote(random_effect, q = FALSE)) else character(),
      "model_data <- cbind(metadata, as.data.frame(log1p(relative), check.names = FALSE))",
      "feature_names <- colnames(relative)",
      if (identical(method_id, "feature_mixed_model")) {
        "model_formula <- function(feature) stats::as.formula(sprintf('`%s` ~ `%s` + (1 | `%s`)', feature, predictor, random_effect))"
      } else if (identical(method_id, "interaction_association")) {
        "model_formula <- function(feature) stats::as.formula(sprintf('`%s` ~ `%s` * `%s`', feature, predictor, second_predictor))"
      } else {
        "model_formula <- function(feature) stats::reformulate(predictor, response = feature)"
      },
      if (identical(method_id, "feature_mixed_model")) {
        "models <- lapply(feature_names, function(feature) lme4::lmer(model_formula(feature), data = model_data, REML = FALSE))"
      } else {
        "models <- lapply(feature_names, function(feature) stats::lm(model_formula(feature), data = model_data))"
      },
      "names(models) <- feature_names",
      "coefficient_rows <- lapply(names(models), function(feature) { coefficients <- summary(models[[feature]])$coefficients; term <- rownames(coefficients)[min(2L, nrow(coefficients))]; data.frame(Feature = feature, term = term, effect = coefficients[term, 1], standard_error = coefficients[term, 2], statistic = coefficients[term, 3], raw_p = coefficients[term, ncol(coefficients)], stringsAsFactors = FALSE) })",
      "table <- do.call(rbind, coefficient_rows); table$adjusted_p <- p.adjust(table$raw_p, method = 'BH')",
      "plot <- ggplot2::ggplot(table, ggplot2::aes(effect, -log10(pmax(adjusted_p, .Machine$double.xmin)), colour = adjusted_p < 0.05)) + ggplot2::geom_point() + ggplot2::theme_classic()",
      "tables <- list(feature_associations = table); plots <- list(effect_plot = plot); print(plot)",
      "result <- list(tables = tables, plots = plots, models = models)", "result"
    )
    return(microbiome_parseable_code(lines))
  }
  stop("Unsupported differential method code: ", method_id, call. = FALSE)
}

microbiome_species_environment_code <- function(method_id, spec) {
  taxa <- spec$taxa_variables %||% character()
  environments <- spec$environment_factors %||% character()
  rank <- spec$taxonomic_rank %||% "Genus"
  group <- spec$group %||% ""
  use_grouping <- isTRUE(spec$use_grouping) && nzchar(group)
  group_mode <- spec$group_mode %||% "independent"
  common <- c(
    "counts <- as.matrix(bundle$counts)",
    sprintf("taxonomy_rank <- %s", dQuote(rank, q = FALSE)),
    "taxon_labels <- bundle$taxonomy[[taxonomy_rank]]",
    "aggregated_counts <- t(rowsum(t(counts), group = taxon_labels, reorder = FALSE))",
    sprintf("taxa <- c(%s)", paste(dQuote(taxa, q = FALSE), collapse = ", ")),
    sprintf("environment_factors <- c(%s)",
      paste(dQuote(environments, q = FALSE), collapse = ", ")),
    "feature_table <- aggregated_counts[, taxa, drop = FALSE]",
    "metadata <- cbind(bundle$metadata, bundle$environment)",
    "metadata <- metadata[rownames(feature_table), , drop = FALSE]"
  )
  if (identical(method_id, "species_env_spearman")) {
    analysis <- c(
      sprintf("pseudocount <- %s", format(as.numeric(spec$pseudocount %||% 0.5))),
      "logged <- log(feature_table + pseudocount)",
      "clr_table <- logged - rowMeans(logged)",
      if (use_grouping) sprintf("group <- factor(metadata[[%s]])", dQuote(group, q = FALSE)) else
        "group <- factor(rep('All samples', nrow(metadata)))",
      if (use_grouping && identical(group_mode, "independent"))
        "analysis_sets <- split(seq_len(nrow(metadata)), group)" else
          "analysis_sets <- list(Global = seq_len(nrow(metadata)))",
      "results <- do.call(rbind, lapply(names(analysis_sets), function(scope) {",
      "  index <- analysis_sets[[scope]]",
      "  do.call(rbind, lapply(taxa, function(taxon) do.call(rbind, lapply(environment_factors, function(variable) {",
      "    complete <- index[complete.cases(clr_table[index, taxon], metadata[index, variable])]",
      "    test <- cor.test(clr_table[complete, taxon], metadata[complete, variable], method = 'spearman', exact = FALSE)",
      "    data.frame(Feature = taxon, EnvironmentFactor = variable, Scope = scope,",
      "      effect = unname(test$estimate), raw_p = test$p.value, SampleSize = length(complete))",
      "  }))))",
      "}))",
      sprintf("results$adjusted_p <- ave(results$raw_p, results$Scope, FUN = function(p) p.adjust(p, method = %s))",
        dQuote(spec$fdr_method %||% "BH", q = FALSE)),
      if (use_grouping) c(
        "# Compare every pair of groups with Fisher's z transformation.",
        "group_pairs <- combn(names(analysis_sets), 2, simplify = FALSE)",
        "group_differences <- do.call(rbind, lapply(group_pairs, function(pair) {",
        "  first <- results[results$Scope == pair[1], ]",
        "  second <- results[results$Scope == pair[2], ]",
        "  value <- merge(first, second, by = c('Feature', 'EnvironmentFactor'), suffixes = c('_first', '_second'))",
        "  se <- sqrt(1 / (value$SampleSize_first - 3) + 1 / (value$SampleSize_second - 3))",
        "  z <- (atanh(pmax(-0.999999, pmin(0.999999, value$effect_second))) -",
        "    atanh(pmax(-0.999999, pmin(0.999999, value$effect_first)))) / se",
        "  value$Contrast <- paste(pair[2], '-', pair[1])",
        "  value$DeltaR <- value$effect_second - value$effect_first",
        "  value$raw_p <- 2 * pnorm(-abs(z))",
        sprintf("  value$adjusted_p <- p.adjust(value$raw_p, method = %s)",
          dQuote(spec$spearman_fisher_adjust %||% spec$fdr_method %||% "BH", q = FALSE)),
        "  value",
        "}))"
      )
    )
  } else if (identical(method_id, "mantel_correlation")) {
    analysis <- c(
      "library(microeco)",
      "library(vegan)",
      "library(ggcor)",
      "library(ggplot2)",
      sprintf("distance_method <- %s",
        dQuote(spec$mantel_distance %||% "bray", q = FALSE)),
      sprintf("correlation_method <- %s",
        dQuote(spec$mantel_correlation_method %||% "pearson", q = FALSE)),
      "environment_data <- metadata[, environment_factors, drop = FALSE]",
      "taxonomic_mapping <- data.frame(Feature = colnames(counts), Taxon = taxon_labels)",
      "mantel_fits <- lapply(taxa, function(taxon) {",
      "  features <- taxonomic_mapping$Feature[taxonomic_mapping$Taxon == taxon]",
      "  group_counts <- counts[, features, drop = FALSE]",
      "  method <- distance_method",
      "  if (method == 'aitchison') {",
      sprintf("    group_counts <- log(group_counts + %s)",
        format(as.numeric(spec$pseudocount %||% 0.5))),
      "    group_counts <- group_counts - rowMeans(group_counts)",
      "    method <- 'euclidean'",
      "  }",
      "  community_distance <- as.matrix(vegan::vegdist(group_counts, method = method))",
      "  env_model <- microeco::trans_env$new(dataset = NULL, add_data = environment_data)",
      sprintf("  env_model$cal_mantel(add_matrix = community_distance, partial_mantel = %s, method = correlation_method, p_adjust_method = %s, permutations = %dL)",
        if (isTRUE(spec$mantel_partial %||% TRUE)) "TRUE" else "FALSE",
        dQuote(if (identical(spec$mantel_p_adjust %||% "BH", "BH")) "fdr" else
          spec$mantel_p_adjust, q = FALSE),
        max(99L, as.integer(spec$mantel_permutations %||% 999L))),
      "  data.frame(spec = taxon, env_model$res_mantel, check.names = FALSE)",
      "})",
      "mantel_results <- do.call(rbind, mantel_fits)",
      "plot_table <- data.frame(spec = mantel_results$spec,",
      "  env = mantel_results$Variables,",
      "  r = mantel_results$`Correlation coefficient`,",
      "  p.value = mantel_results$p.adjusted)",
      "plot_table$rd <- cut(plot_table$r, c(-Inf, 0.3, 0.6, Inf),",
      "  labels = c('< 0.3', '0.3 - 0.6', '>= 0.6'))",
      "plot_table$pd <- cut(plot_table$p.value, c(-Inf, 0.01, 0.05, Inf),",
      "  labels = c('< 0.01', '0.01 - 0.05', '>= 0.05'))",
      "mantel_correlation_plot <- ggcor::quickcor(environment_data, type = 'upper',",
      "  cor.test = TRUE, method = 'pearson', show.diag = FALSE) +",
      "  ggplot2::geom_tile(width = 0.95, height = 0.95) +",
      "  ggcor::geom_mark(sig.thres = 0.05,",
      "    colour = 'black', size = 6) +",
      "  ggcor::anno_link(ggplot2::aes(colour = pd, size = rd), data = plot_table) +",
      "  ggplot2::scale_size_manual(values = c(0.5, 1.5, 3)) +",
      "  ggplot2::scale_colour_manual(values = c('#D95F02', '#1B9E77', '#A2A2A288')) +",
      "  ggplot2::scale_fill_gradient2(low = '#2166AC', mid = 'white',",
      "    high = '#B2182B', midpoint = 0, limits = c(-1, 1))"
    )
  } else {
    fixed <- paste(dQuote(environments, q = FALSE), collapse = ", ")
    analysis <- c(
      "library(Maaslin2)",
      sprintf("group_mode <- %s", dQuote(group_mode, q = FALSE)),
      sprintf("use_grouping <- %s", if (use_grouping) "TRUE" else "FALSE"),
      sprintf("group_variable <- %s", dQuote(group, q = FALSE)),
      sprintf("fixed_effects <- c(%s)", fixed),
      "# For independent groups, loop over metadata levels and fit the same model per subset.",
      "# For interaction mode, add the group main effect and group-by-environment product terms.",
      "output_dir <- tempfile('dava_maaslin2_'); dir.create(output_dir)",
      "fit <- Maaslin2(input_data = as.data.frame(feature_table),",
      "  input_metadata = metadata, output = output_dir,",
      sprintf("  min_prevalence = %s, normalization = 'CLR', transform = 'NONE',",
        format(as.numeric(spec$minimum_prevalence %||% 0.1))),
      "  analysis_method = 'LM', fixed_effects = fixed_effects,",
      sprintf("  correction = %s, standardize = %s, cores = %dL,",
        dQuote(spec$fdr_method %||% "BH", q = FALSE),
        if (isTRUE(spec$standardize_environment %||% TRUE)) "TRUE" else "FALSE",
        max(1L, as.integer(spec$n_cores %||% 1L))),
      "  plot_heatmap = FALSE, plot_scatter = FALSE, save_models = FALSE)",
      "results <- fit$results"
    )
  }
  microbiome_parseable_code(c(common, analysis))
}

microbiome_netcomi_code <- function(spec) {
  grouped <- isTRUE(spec$group_network)
  group <- spec$group %||% ""
  requested <- as.character(spec$plot_types %||%
    microbiome_netcomi_default_plot_types(grouped))
  requirements <- microbiome_netcomi_analysis_requirements(
    requested, grouped)
  stability_requested <- any(unlist(
    requirements[c("cohesion", "robustness", "vulnerability")],
    use.names = FALSE))
  robustness_strategies <- unique(as.character(
    spec$robustness_strategy %||%
      spec$netcomi_robustness_strategy %||% "node_rand"))
  robustness_strategy_code <- paste(
    dQuote(robustness_strategies, q = FALSE), collapse = ", ")
  lines <- c(
    "library(NetCoMi)",
    if (stability_requested) "library(microeco)",
    if (stability_requested) "library(meconetcomp)",
    "counts <- as.matrix(bundle$counts)",
    sprintf("taxonomic_rank <- %s",
      dQuote(spec$taxonomic_rank %||% "Genus", q = FALSE)),
    "taxon <- bundle$taxonomy[[taxonomic_rank]]",
    "network_counts <- t(rowsum(t(counts), group = taxon, reorder = FALSE))",
    sprintf("network_measure <- %s",
      dQuote(spec$network_measure %||% "spieceasi", q = FALSE)),
    sprintf("association_threshold <- %s",
      format(as.numeric(spec$network_threshold %||% 0.3))),
    sprintf("fdr_threshold <- %s",
      format(as.numeric(spec$network_fdr %||% 0.05))),
    sprintf("zero_method <- %s",
      dQuote(spec$zero_method %||% "pseudo", q = FALSE)),
    sprintf("norm_method <- %s",
      dQuote(spec$norm_method %||% "clr", q = FALSE)),
    sprintf(
      "spring_measure_par <- list(ncores = %dL, nlambda = %dL, rep.num = %dL, verbose = FALSE)",
      max(1L, as.integer(spec$n_cores %||%
        microbiome_netcomi_default_cores())),
      as.integer(spec$spring_nlambda %||% 20L),
      as.integer(spec$spring_repetitions %||% 20L)),
    "measure_par <- if (identical(network_measure, 'spring')) spring_measure_par else NULL",
    if (grouped) sprintf("network_group <- factor(bundle$metadata[[%s]])",
      dQuote(group, q = FALSE)) else
        "network_group <- factor(rep('Overall', nrow(network_counts)))",
    "network_sets <- split(seq_len(nrow(network_counts)), network_group)",
    "net_construct <- lapply(network_sets, function(index) {",
    "  netConstruct(network_counts[index, , drop = FALSE], dataType = 'counts',",
    "    measure = network_measure, measurePar = measure_par, zeroMethod = zero_method,",
    "    normMethod = norm_method, alpha = fdr_threshold, adjust = 'BH',",
    sprintf("    cores = %dL, seed = %dL, verbose = 0)",
      max(1L, as.integer(spec$n_cores %||%
        microbiome_netcomi_default_cores())),
      as.integer(spec$seed %||% 2026L)),
    "})",
    "net_properties <- lapply(net_construct, function(net) {",
    sprintf("  netAnalyze(net, clustMethod = %s, hubPar = %s, hubQuant = %s,",
      dQuote(spec$cluster_method %||% "cluster_louvain", q = FALSE),
      dQuote(spec$hub_method %||% "degree", q = FALSE),
      format(as.numeric(spec$hub_quantile %||% 0.95))),
    "    graphlet = FALSE, gcmHeat = FALSE, gcmHeatLCC = FALSE)",
    "})")
  if (stability_requested) {
    lines <- c(
      lines,
      "# Convert each named NetCoMi network to a microeco::trans_network object.",
      "# The adapter joins every node and edge attribute by taxon name.",
      "# Cohesion retains signed r; path weights use sqrt(0.5 * (1 - r)).",
      "trans_network_list <- lapply(names(net_construct), function(group_name) {",
      "  # See DAVA generated node/edge tables for the name-safe conversion.",
      "  NULL",
      "})",
      "names(trans_network_list) <- names(net_construct)")
  }
  if (isTRUE(requirements$cohesion)) {
    lines <- c(
      lines,
      "cohesion_result <- meconetcomp::cohesionclass$new(trans_network_list)")
  }
  if (isTRUE(requirements$robustness)) {
    lines <- c(
      lines,
      "robustness_result <- meconetcomp::robustness$new(trans_network_list,",
      sprintf(
        paste0(
          "  remove_strategy = c(%s), remove_ratio = seq(0, %s, by = %s), ",
          "measure = %s, run = %dL)"),
        robustness_strategy_code,
        format(as.numeric(spec$robustness_max_ratio %||% 0.9)),
        format(as.numeric(spec$robustness_step %||% 0.1)),
        dQuote(spec$robustness_measure %||% "Eff", q = FALSE),
        as.integer(spec$robustness_runs %||% 20L)))
  }
  if (isTRUE(requirements$vulnerability)) {
    lines <- c(
      lines,
      "vulnerability_result <- meconetcomp::vulnerability(trans_network_list)")
  }
  if (isTRUE(requirements$comparison)) {
    lines <- c(
      lines,
      "# Fit joint two-network objects only for requested permutation comparisons.",
      sprintf("comparison_permutations <- %dL",
        as.integer(spec$compare_permutations %||% 999L)),
      "comparison_pairs <- utils::combn(names(network_sets), 2L, simplify = FALSE)",
      "comparison_results <- lapply(comparison_pairs, function(pair) {",
      "  joint_net <- NetCoMi::netConstruct(",
      "    data = network_counts[network_sets[[pair[[1]]]], , drop = FALSE],",
      "    data2 = network_counts[network_sets[[pair[[2]]]], , drop = FALSE],",
      "    dataType = 'counts', measure = network_measure, measurePar = measure_par,",
      "    zeroMethod = zero_method, normMethod = norm_method,",
      "    jointPrepro = TRUE, alpha = fdr_threshold, adjust = 'BH',",
      sprintf("    cores = %dL, seed = %dL, verbose = 0)",
        max(1L, as.integer(spec$n_cores %||%
          microbiome_netcomi_default_cores())),
        as.integer(spec$seed %||% 2026L)),
      sprintf(
        paste0(
          "  joint_props <- NetCoMi::netAnalyze(joint_net, ",
          "clustMethod = %s, hubPar = %s, hubQuant = %s, ",
          "graphlet = FALSE, gcmHeat = FALSE, gcmHeatLCC = FALSE)"),
        dQuote(spec$cluster_method %||% "cluster_louvain", q = FALSE),
        dQuote(spec$hub_method %||% "degree", q = FALSE),
        format(as.numeric(spec$hub_quantile %||% 0.95))),
      sprintf(
        paste0(
          "  NetCoMi::netCompare(joint_props, permTest = TRUE, ",
          "testRand = FALSE, gcd = FALSE, nPerm = comparison_permutations, ",
          "cores = %dL, verbose = FALSE, seed = %dL)"),
        max(1L, as.integer(spec$n_cores %||%
          microbiome_netcomi_default_cores())),
        as.integer(spec$seed %||% 2026L)),
      "})")
  }
  microbiome_parseable_code(lines)
}

microbiome_network_code_document <- function(method_id, spec = list()) {
  engine <- as.character(spec$network_engine %||% "netcomi")
  engine <- if (length(engine) && !is.na(engine[[1]]) && nzchar(engine[[1]])) {
    engine[[1]]
  } else {
    "netcomi"
  }
  cross_domain <- identical(method_id, "cross_domain_network")
  if (identical(engine, "ggclusternet2")) {
    return(microbiome_ggclusternet_code(spec, cross_domain = cross_domain))
  }
  if (!identical(engine, "netcomi")) {
    stop("Unknown network analysis engine: ", engine, call. = FALSE)
  }
  if (cross_domain) {
    microbiome_cross_domain_network_code(spec)
  } else {
    microbiome_netcomi_code(spec)
  }
}

microbiome_cross_domain_network_code <- function(spec) {
  microbiome_parseable_code(c(
    "library(NetCoMi)",
    "common_samples <- intersect(rownames(bundle$counts), rownames(second_bundle$counts))",
    "stopifnot(length(common_samples) >= 6L)",
    "if (identical(bundle$marker_type, '16S')) { bacteria_counts <- as.matrix(bundle$counts[common_samples, , drop = FALSE]); fungi_counts <- as.matrix(second_bundle$counts[common_samples, , drop = FALSE]) } else { bacteria_counts <- as.matrix(second_bundle$counts[common_samples, , drop = FALSE]); fungi_counts <- as.matrix(bundle$counts[common_samples, , drop = FALSE]) }",
    sprintf("bacteria_rank <- %s",
      dQuote(spec$bacteria_taxonomic_rank %||% "Genus", q = FALSE)),
    sprintf("fungi_rank <- %s",
      dQuote(spec$fungi_taxonomic_rank %||% "Genus", q = FALSE)),
    "bacteria_counts <- bacteria_counts[common_samples, , drop = FALSE]",
    "fungi_counts <- fungi_counts[common_samples, , drop = FALSE]",
    "domain_clr <- function(x, pseudocount = 0.5) {",
    "  logged <- log(as.matrix(x) + pseudocount)",
    "  clr <- logged - rowMeans(logged)",
    "  sweep(clr, 2, apply(clr, 2, min), '-') + 1e-8",
    "}",
    "cross_domain_data <- cbind(",
    "  `Bacteria` = domain_clr(bacteria_counts),",
    "  `Fungi` = domain_clr(fungi_counts))",
    "colnames(cross_domain_data) <- c(",
    "  paste0('Bacteria::', colnames(bacteria_counts)),",
    "  paste0('Fungi::', colnames(fungi_counts)))",
    sprintf("network_measure <- %s",
      dQuote(spec$network_measure %||% "spearman", q = FALSE)),
    "network <- NetCoMi::netConstruct(",
    "  cross_domain_data, dataType = 'counts',",
    "  measure = network_measure, zeroMethod = 'none', normMethod = 'none',",
    sprintf("  alpha = %s, adjust = 'BH', cores = %dL, seed = %dL)",
      format(as.numeric(spec$network_fdr %||% 0.05)),
      max(1L, as.integer(spec$n_cores %||%
        microbiome_netcomi_default_cores())),
      as.integer(spec$seed %||% 2026L)),
    "properties <- NetCoMi::netAnalyze(",
    sprintf(
      "  network, clustMethod = %s, hubPar = %s, hubQuant = %s)",
      dQuote(spec$cluster_method %||% "cluster_louvain", q = FALSE),
      dQuote(spec$hub_method %||% "degree", q = FALSE),
      format(as.numeric(spec$hub_quantile %||% 0.95)))))
}

microbiome_function_import_code <- function(spec) {
  microbiome_parseable_code(c("# Import a completed PICRUSt2 pathway abundance table; no ASV-to-function proxy is generated.",
    "function_table <- as.data.frame(bundle$function_table, check.names = FALSE)",
    "stopifnot(all(is.finite(as.matrix(function_table))), all(as.matrix(function_table) >= 0))",
    "relative_function <- function_table / rowSums(function_table)",
    "function_summary <- data.frame(Function = colnames(function_table), MeanAbundance = colMeans(function_table), Prevalence = colMeans(function_table > 0))"))
}

microbiome_taxonomy_function_code <- function(method_id) {
  microbiome_parseable_code(c(sprintf("method_id <- %s", dQuote(method_id, q = FALSE)),
    "mapping <- bundle$functional_mapping", "stopifnot(all(c('Taxon', 'Function', 'DatabaseVersion') %in% names(mapping)))",
    "genus <- bundle$taxonomy$Genus", "counts <- as.matrix(bundle$counts)",
    "function_counts <- sapply(unique(mapping$Function), function(fun) rowSums(counts[, genus %in% mapping$Taxon[mapping$Function == fun], drop = FALSE]))"))
}

microbiome_ncm_code <- function(spec) {
  microbiome_parseable_code(c(
    "library(Hmisc)",
    "library(minpack.lm)",
    "library(ggplot2)",
    "library(patchwork)",
    "spp <- as.matrix(bundle$counts)",
    "spp[is.na(spp)] <- 0",
    "spp <- spp[rowSums(spp) > 0, , drop = FALSE]",
    sprintf("data_type <- '%s'", spec$ncm_data_type %||% "relative"),
    sprintf("scale_factor <- %dL", as.integer(spec$ncm_scale_factor %||% 10000L)),
    "spp_norm <- spp / rowSums(spp)",
    "spp_scaled <- t(apply(spp_norm, 1, function(x) rmultinom(1, scale_factor, x)))",
    "N <- mean(rowSums(spp_scaled))",
    "p <- colMeans(spp_scaled) / N",
    "freq <- colMeans(spp_scaled > 0)",
    "keep <- p > 0 & p < 1 & freq > 0",
    "p <- p[keep]; freq <- freq[keep]",
    "d <- 1 / N",
    "m.fit <- minpack.lm::nlsLM(freq ~ pbeta(d, N*m*p, N*m*(1-p), lower.tail = FALSE), start = list(m = 0.1), lower = c(m = 1e-6), upper = c(m = 0.999999))",
    "freq.pred <- pbeta(d, N*coef(m.fit)*p, N*coef(m.fit)*(1-p), lower.tail = FALSE)",
    "pred.ci <- Hmisc::binconf(freq.pred*nrow(spp_scaled), nrow(spp_scaled), alpha = 0.05, method = 'wilson', return.df = TRUE)",
    "bacnlsALL <- data.frame(Taxa = names(p), p = p, freq = freq, freq.pred = freq.pred, Lower = pred.ci[,2], Upper = pred.ci[,3])",
    "bacnlsALL$Group <- ifelse(bacnlsALL$freq < bacnlsALL$Lower, 'low', ifelse(bacnlsALL$freq > bacnlsALL$Upper, 'high', 'med'))",
    "ggplot(bacnlsALL, aes(log10(p), freq, colour = Group)) + geom_point(alpha = 0.8) + geom_line(aes(y = freq.pred), colour = 'black') + geom_line(aes(y = Lower), linetype = 2) + geom_line(aes(y = Upper), linetype = 2) + theme_bw()"))
}

microbiome_bnti_rcbray_code <- function(spec) {
  microbiome_parseable_code(c("library(iCAMP)", "library(ape)",
    sprintf("permutations <- %dL", max(9L, as.integer(spec$permutations %||% 999L))),
    sprintf("seed <- %dL", as.integer(spec$seed %||% 2026L)), "counts <- as.matrix(bundle$counts)",
    "tree <- bundle$phylogeny", "shared <- intersect(colnames(counts), tree$tip.label)",
    "counts <- counts[, shared, drop = FALSE]", "tree <- ape::keep.tip(tree, shared)",
    "phylogenetic_distance <- as.matrix(ape::cophenetic.phylo(tree))", "set.seed(seed)",
    "bnti <- iCAMP::bNTI.cm(counts, phylogenetic_distance, rand = permutations, nworker = 1, weighted = TRUE, sig.index = 'SES')",
    "set.seed(seed)",
    "rcbray <- iCAMP::RC.cm(counts, rand = permutations, nworker = 1, weighted = TRUE, sig.index = 'RC', silent = TRUE)"))
}

microbiome_longitudinal_code <- function(method_id, spec) {
  subject <- spec$subject_or_plot_id %||% "PlotID"
  time <- spec$time %||% "Year"
  common <- c(
    "counts <- as.matrix(bundle$counts)",
    sprintf("subject_name <- %s", dQuote(subject, q = FALSE)),
    sprintf("time_name <- %s", dQuote(time, q = FALSE)),
    "metadata <- as.data.frame(bundle$metadata, check.names = FALSE)",
    "subject <- factor(metadata[[subject_name]])",
    "time <- metadata[[time_name]]",
    "stopifnot(!anyNA(subject), !anyNA(time), all(table(subject) >= 2L))")
  if (method_id == "temporal_beta") return(microbiome_parseable_code(c(common,
    "library(vegan)",
    "transition_rows <- lapply(levels(subject), function(subject_level) {",
    "  index <- which(subject == subject_level); index <- index[order(time[index], seq_along(index))]",
    "  if (length(index) < 2L) return(NULL)",
    "  data.frame(Subject = subject_level, FromSample = rownames(counts)[head(index, -1)], ToSample = rownames(counts)[tail(index, -1)], FromTime = head(time[index], -1), ToTime = tail(time[index], -1), BrayCurtis = vapply(seq_len(length(index) - 1L), function(position) as.numeric(vegan::vegdist(counts[index[c(position, position + 1L)], , drop = FALSE], method = 'bray')), numeric(1)))",
    "})",
    "transitions <- do.call(rbind, transition_rows)",
    "time_summary <- stats::aggregate(BrayCurtis ~ FromTime + ToTime, transitions, function(value) c(mean = mean(value), sd = stats::sd(value), n = length(value)))",
    "result <- list(tables = list(transitions = transitions, time_summary = time_summary))",
    "result")))
  fixed <- spec$fixed_effects %||% c("Treatment", time)
  microbiome_parseable_code(c(common,
    "library(lme4)",
    "relative <- counts / rowSums(counts)",
    "shannon <- -rowSums(ifelse(relative > 0, relative * log(relative), 0))",
    "model_data <- metadata; model_data$Shannon <- shannon; model_data$Subject <- subject",
    paste0("fixed_effects <- c(", paste(dQuote(fixed, q = FALSE), collapse = ", "), ")"),
    "fit <- lme4::lmer(stats::as.formula(paste('Shannon ~', paste(fixed_effects, collapse = ' + '), '+ (1 | Subject)')), data = model_data, REML = TRUE)",
    "fixed_effect_table <- as.data.frame(summary(fit)$coefficients); fixed_effect_table$term <- rownames(fixed_effect_table); rownames(fixed_effect_table) <- NULL",
    "random_effect_table <- as.data.frame(lme4::VarCorr(fit))",
    "diagnostics <- data.frame(converged = is.null(fit@optinfo$conv$lme4$messages), singular = lme4::isSingular(fit))",
    "fitted_table <- data.frame(SampleID = rownames(counts), Observed = shannon, Fitted = stats::fitted(fit), Residual = stats::residuals(fit))",
    "result <- list(tables = list(fixed_effects = fixed_effect_table, random_effects = random_effect_table, diagnostics = diagnostics, fitted = fitted_table), diagnostics = diagnostics)",
    "result"))
}

microbiome_procrustes_code <- function(spec) {
  microbiome_parseable_code(c(
    "library(vegan)",
    "common_samples <- intersect(rownames(bundle$counts), rownames(second_bundle$counts))",
    "stopifnot(length(common_samples) >= 6L, bundle$marker_type != second_bundle$marker_type)",
    "first <- as.matrix(bundle$counts[common_samples, , drop = FALSE])",
    "second <- as.matrix(second_bundle$counts[common_samples, , drop = FALSE])",
    paste0("distance_method <- ", dQuote(spec$distance %||% "bray", q = FALSE)),
    "first_pcoa <- stats::cmdscale(vegan::vegdist(first, method = distance_method), k = 2, add = TRUE)",
    "second_pcoa <- stats::cmdscale(vegan::vegdist(second, method = distance_method), k = 2, add = TRUE)",
    paste0("permutations <- ", as.integer(spec$permutations %||% 999L), "L"),
    paste0("set.seed(", as.integer(spec$seed %||% 2026L), "L)"),
    "test <- vegan::protest(first_pcoa, second_pcoa, permutations = permutations)",
    "fit <- vegan::procrustes(first_pcoa, second_pcoa, symmetric = TRUE)",
    "matched_scores <- data.frame(SampleID = common_samples, FirstAxis1 = fit$X[, 1], FirstAxis2 = fit$X[, 2], SecondAxis1 = fit$Yrot[, 1], SecondAxis2 = fit$Yrot[, 2])",
    "protest_table <- data.frame(ProcrustesCorrelation = unname(test$t0), SumOfSquares = fit$ss, PValue = test$signif, Permutations = permutations, MatchedSamples = length(common_samples), FirstMarker = bundle$marker_type, SecondMarker = second_bundle$marker_type)",
    "result <- list(tables = list(protest = protest_table, matched_scores = matched_scores), statistics = protest_table)",
    "result"))
}

microbiome_ml_code <- function(method_id, spec) {
  package <- if (method_id == "rf_classification") "ranger" else "glmnet"
  seed <- as.integer(spec$seed %||% 2026L)
  folds <- as.integer(spec$cv_folds %||% 5L)
  common <- c(
    sprintf("library(%s)", package),
    "counts <- as.matrix(bundle$counts)",
    paste0("pseudocount <- ", format(as.numeric(spec$pseudocount %||% 0.5), scientific = FALSE)),
    "x <- log(counts + pseudocount)", "x <- x - rowMeans(x)",
    sprintf("outcome_name <- %s", dQuote(spec$group %||% "Treatment", q = FALSE)),
    sprintf("split_name <- %s", dQuote(spec$block %||% "Block", q = FALSE)),
    "outcome <- droplevels(factor(bundle$metadata[[outcome_name]]))",
    "split_group <- as.character(bundle$metadata[[split_name]])",
    "unique_groups <- unique(split_group)",
    paste0("fold_count <- min(", folds, "L, length(unique_groups))"),
    sprintf("set.seed(%dL)", seed),
    "shuffled_groups <- sample(unique_groups)",
    "group_assignment <- stats::setNames(rep(seq_len(fold_count), length.out = length(shuffled_groups)), shuffled_groups)",
    "fold_id <- unname(group_assignment[split_group])",
    "predictions <- rep(NA_character_, nrow(x))",
    "fold_models <- vector('list', fold_count)")
  fit_lines <- if (identical(method_id, "rf_classification")) c(
    paste0("num_trees <- ", as.integer(spec$num_trees %||% 500L), "L"),
    "for (fold in sort(unique(fold_id))) {",
    "  train <- fold_id != fold",
    "  model_data <- data.frame(.response = outcome[train], x[train, , drop = FALSE], check.names = FALSE)",
    paste0("  fit <- ranger::ranger(.response ~ ., data = model_data, probability = TRUE, num.trees = num_trees, importance = 'permutation', seed = ", seed, "L + fold)"),
    "  probability <- predict(fit, data = data.frame(x[!train, , drop = FALSE], check.names = FALSE))$predictions",
    "  predictions[!train] <- colnames(probability)[max.col(probability, ties.method = 'first')]",
    "  fold_models[[fold]] <- fit",
    "}",
    "full_data <- data.frame(.response = outcome, x, check.names = FALSE)",
    paste0("full_fit <- ranger::ranger(.response ~ ., data = full_data, probability = TRUE, num.trees = num_trees, importance = 'permutation', seed = ", seed, "L)"),
    "feature_results <- data.frame(Feature = names(full_fit$variable.importance), Importance = unname(full_fit$variable.importance))",
    "feature_results <- feature_results[order(feature_results$Importance, decreasing = TRUE), , drop = FALSE]"
  ) else c(
    "family <- if (nlevels(outcome) == 2L) 'binomial' else 'multinomial'",
    paste0("alpha <- ", format(as.numeric(spec$alpha %||% 0.5), scientific = FALSE)),
    "for (fold in sort(unique(fold_id))) {",
    "  train <- fold_id != fold",
    "  inner_groups <- split_group[train]; inner_unique <- unique(inner_groups)",
    paste0("  set.seed(", seed, "L + fold)"),
    "  inner_shuffled <- sample(inner_unique); inner_count <- min(5L, length(inner_unique))",
    "  inner_assignment <- stats::setNames(rep(seq_len(inner_count), length.out = length(inner_shuffled)), inner_shuffled)",
    "  inner_fold <- unname(inner_assignment[inner_groups])",
    "  fit <- glmnet::cv.glmnet(x[train, , drop = FALSE], outcome[train], family = family, alpha = alpha, foldid = inner_fold, type.measure = 'class', standardize = TRUE)",
    "  predicted <- predict(fit, newx = x[!train, , drop = FALSE], s = 'lambda.min', type = 'class')",
    "  predictions[!train] <- as.character(predicted[, 1]); fold_models[[fold]] <- fit",
    "}",
    "full_fit <- glmnet::cv.glmnet(x, outcome, family = family, alpha = alpha, foldid = fold_id, type.measure = 'class', standardize = TRUE)",
    "coefficient <- stats::coef(full_fit, s = 'lambda.min'); if (!is.list(coefficient)) coefficient <- list(coefficient)",
    "feature_results <- do.call(rbind, lapply(seq_along(coefficient), function(index) { matrix <- as.matrix(coefficient[[index]]); class_name <- names(coefficient)[index]; if (is.null(class_name) || is.na(class_name) || !nzchar(class_name)) class_name <- levels(outcome)[min(index, nlevels(outcome))]; data.frame(Class = class_name, Feature = rownames(matrix), Coefficient = matrix[, 1]) }))",
    "feature_results <- feature_results[feature_results$Feature != '(Intercept)' & feature_results$Coefficient != 0, , drop = FALSE]"
  )
  output <- c(
    "predicted_factor <- factor(predictions, levels = levels(outcome))",
    "confusion_matrix <- table(Observed = outcome, Predicted = predicted_factor)",
    "recall <- diag(confusion_matrix) / pmax(rowSums(confusion_matrix), 1)",
    "metrics <- data.frame(Accuracy = mean(outcome == predicted_factor), BalancedAccuracy = mean(recall), Samples = length(outcome))",
    "prediction_table <- data.frame(SampleID = rownames(counts), Observed = as.character(outcome), Predicted = predictions, Fold = fold_id, SplitGroup = split_group, Correct = as.character(outcome) == predictions)",
    "fold_assignment <- unique(prediction_table[, c('SplitGroup', 'Fold')])",
    "tables <- list(predictions = prediction_table, metrics = metrics, confusion = data.frame(as.table(confusion_matrix), stringsAsFactors = FALSE), feature_results = feature_results, fold_assignment = fold_assignment)",
    "result <- list(tables = tables, predictions = prediction_table, feature_results = feature_results, statistics = metrics)",
    "result")
  microbiome_parseable_code(c(common, fit_lines, output))
}

microbiome_preprocess_code <- function(method_id, spec) {
  if (method_id == "data_integrity") return(microbiome_parseable_code(c(
    "# Inspect the already imported and sample-aligned bundle without a hidden validator.",
    "counts <- as.matrix(bundle$counts)",
    "storage.mode(counts) <- 'double'",
    "stopifnot(nrow(counts) > 0L, ncol(counts) > 0L, all(is.finite(counts)), all(counts >= 0), !anyDuplicated(rownames(counts)), !anyDuplicated(colnames(counts)))",
    "depth <- rowSums(counts)",
    "summary <- data.frame(metric = c('orientation', 'samples', 'features', 'zero_fraction', 'minimum_depth', 'median_depth', 'maximum_depth', 'raw_integer_counts'), value = c('samples_by_features', nrow(counts), ncol(counts), signif(mean(counts == 0), 5), min(depth), stats::median(depth), max(depth), all(counts == floor(counts))))"
  )))
  if (method_id == "filter_prevalence") return(microbiome_parseable_code(c(
    "# bundle is a DAVA microbiome_bundle", sprintf("minimum_total <- %s", format(spec$minimum_total %||% 0, scientific = FALSE)),
    sprintf("minimum_prevalence <- %s", format(spec$minimum_prevalence %||% 0.1, scientific = FALSE)),
    "counts <- as.matrix(bundle$counts)",
    "keep <- colSums(counts) >= minimum_total & colMeans(counts > 0) >= minimum_prevalence",
    "filtered_counts <- counts[, keep, drop = FALSE]"
  )))
  transform <- spec$transform %||% if (identical(method_id, "clr_transform")) "clr" else "relative"
  pseudocount <- as.numeric(spec$pseudocount %||% 0.5)
  transform_lines <- switch(transform,
    clr = c(sprintf("pseudocount <- %s", format(pseudocount, scientific = FALSE)), "transformed_counts <- log(counts + pseudocount)", "transformed_counts <- transformed_counts - rowMeans(transformed_counts)"),
    hellinger = "transformed_counts <- sqrt(sweep(counts, 1, rowSums(counts), '/'))",
    presence_absence = "transformed_counts <- (counts > 0) * 1",
    relative = "transformed_counts <- sweep(counts, 1, rowSums(counts), '/')",
    "transformed_counts <- counts")
  microbiome_parseable_code(c(
    "# Transform the imported abundance matrix explicitly.",
    sprintf("transform_method <- %s", dQuote(transform, q = FALSE)),
    "counts <- as.matrix(bundle$counts)", "stopifnot(all(rowSums(counts) > 0))",
    transform_lines,
    "transformed_bundle <- bundle", "transformed_bundle$counts <- as.data.frame(transformed_counts, check.names = FALSE)",
    "transformed_bundle$transform <- transform_method", "transformed_bundle$is_raw_count <- FALSE"
  ))
}

# A code document is a learning and reproduction artifact, not an export of
# the application's implementation graph.  Keep this template deliberately
# flat: it uses only package APIs and base R, and contains every step used by
# the Alpha diversity screen in one readable script.
microbiome_code_document_preprocessing <- function(spec = list()) {
  strategy <- spec$preprocess_strategy %||% "none"
  rarefaction_depth <- if (identical(spec$rarefaction_depth_mode %||% "minimum", "minimum") ||
      is.null(spec$rarefaction_depth)) {
    "rarefaction_depth <- min(rowSums(counts)) # minimum library size"
  } else {
    sprintf("rarefaction_depth <- %dL", as.integer(spec$rarefaction_depth))
  }
  preprocessing <- switch(strategy,
    rarefy = c(
      "library(vegan)",
      rarefaction_depth,
      sprintf("set.seed(%dL)", as.integer(spec$seed %||% 2026L)),
      "stopifnot(all(rowSums(counts) >= rarefaction_depth))",
      "counts <- vegan::rrarefy(counts, sample = rarefaction_depth)"),
    relative = c(
      "library(vegan)",
      "library_sizes <- rowSums(counts)",
      "stopifnot(all(library_sizes > 0))",
      "counts <- sweep(counts, 1, library_sizes, '/')"),
    presence_absence = "counts <- (counts > 0) * 1",
    hellinger = c(
      "library_sizes <- rowSums(counts)",
      "stopifnot(all(library_sizes > 0))",
      "counts <- sqrt(sweep(counts, 1, library_sizes, '/'))"),
    clr = c(
      sprintf("pseudocount <- %s", format(as.numeric(spec$pseudocount %||% 0.5), scientific = FALSE)),
      "counts <- log(counts + pseudocount)",
      "counts <- counts - rowMeans(counts)"),
    filter_prevalence = c(
      sprintf("minimum_total <- %s", format(as.numeric(spec$minimum_total %||% 0), scientific = FALSE)),
      sprintf("minimum_prevalence <- %s", format(as.numeric(spec$minimum_prevalence %||% 0), scientific = FALSE)),
      "keep_features <- colSums(counts) >= minimum_total & colMeans(counts > 0) >= minimum_prevalence",
      "counts <- counts[, keep_features, drop = FALSE]"),
    "# No abundance transformation was selected."
  )
  paste(c(
    "# ---- Data preprocessing ----",
    "# Start from the imported and validated objects in the Input data section.",
    "counts <- raw_counts",
    "metadata <- raw_metadata",
    paste0("# Selected strategy: ", strategy),
    preprocessing,
    "# Use the explicitly preprocessed objects in every downstream method step.",
    "bundle$counts <- counts",
    "bundle$metadata <- metadata",
    "analysis_bundle <- bundle",
    ""
  ), collapse = "\n")
}

microbiome_alpha_plot_style_code <- function(settings = list()) {
  settings <- settings %||% list()
  palette_name <- settings$palette %||% "Nature"
  palette <- if (exists("dava_plot_palette", mode = "function")) {
    dava_plot_palette(palette_name, 16L)
  } else {
    c("#3B7EA1", "#D95F02", "#1B9E77", "#7570B3", "#E7298A", "#66A61E")
  }
  palette_code <- paste(capture.output(dput(unname(palette))), collapse = " ")
  theme_name <- settings$theme %||% "publication"
  base_size <- suppressWarnings(as.numeric(settings$base_size %||% 14))
  if (!is.finite(base_size)) base_size <- 14
  x_angle <- suppressWarnings(as.numeric(settings$x_angle %||% 0))
  if (!is.finite(x_angle)) x_angle <- 0
  title <- settings$title %||% ""
  legend_position <- settings$legend_position %||% "right"
  show_legend <- isTRUE(settings$show_legend %||% TRUE)
  flip <- isTRUE(settings$flip %||% FALSE)
  paste(c(
    "# Apply the same visible plot-panel settings as the main result figure.",
    paste0("plot_palette <- ", palette_code),
    paste0("plot_theme <- ", dQuote(theme_name, q = FALSE)),
    paste0("plot_base_size <- ", format(base_size, scientific = FALSE)),
    paste0("plot_title <- ", dQuote(title, q = FALSE)),
    paste0("plot_x_angle <- ", format(x_angle, scientific = FALSE)),
    paste0("plot_legend_position <- ", dQuote(legend_position, q = FALSE)),
    paste0("plot_show_legend <- ", if (show_legend) "TRUE" else "FALSE"),
    paste0("plot_flip <- ", if (flip) "TRUE" else "FALSE"),
    "plot <- plot + ggplot2::scale_fill_manual(values = plot_palette)",
    "base_theme <- switch(plot_theme, classic = ggplot2::theme_classic, minimal = ggplot2::theme_minimal, clean = ggplot2::theme_minimal, nature = ggplot2::theme_classic, science = ggplot2::theme_bw, cell = ggplot2::theme_classic, nejm = ggplot2::theme_bw, lancet = ggplot2::theme_classic, jama = ggplot2::theme_bw, pnas = ggplot2::theme_minimal, prism = ggplot2::theme_classic, dark = ggplot2::theme_minimal, publication = ggplot2::theme_bw, ggplot2::theme_bw)",
    "plot <- plot + base_theme(base_size = plot_base_size) + ggplot2::theme(plot.title = ggplot2::element_text(face = 'bold', hjust = 0, size = plot_base_size + 2), legend.position = if (plot_show_legend) plot_legend_position else 'none', panel.grid.minor = ggplot2::element_blank(), axis.text.x = ggplot2::element_text(angle = plot_x_angle, hjust = if (plot_x_angle == 0) 0.5 else 1))",
    "if (plot_theme %in% c('nature', 'cell', 'lancet', 'prism')) plot <- plot + ggplot2::theme(axis.line = ggplot2::element_line(linewidth = 0.45, color = '#1F2933'), axis.ticks = ggplot2::element_line(linewidth = 0.35, color = '#1F2933'), panel.grid.major = ggplot2::element_blank())",
    "if (plot_theme %in% c('science', 'nejm', 'jama')) plot <- plot + ggplot2::theme(panel.border = ggplot2::element_rect(linewidth = 0.55, color = '#1F2933', fill = NA), panel.grid.major = ggplot2::element_line(linewidth = 0.22, color = '#E5E7EB'))",
    "if (plot_theme == 'pnas') plot <- plot + ggplot2::theme(panel.grid.major = ggplot2::element_line(linewidth = 0.22, color = '#E6E8EB'), axis.line = ggplot2::element_line(linewidth = 0.35, color = '#374151'))",
    "if (plot_theme == 'clean') plot <- plot + ggplot2::theme(panel.grid.major = ggplot2::element_blank())",
    "if (nzchar(plot_title)) plot <- plot + ggplot2::labs(title = plot_title)",
    "if (plot_flip) plot <- plot + ggplot2::coord_flip()"
  ), collapse = "\n")
}

microbiome_alpha_core_code_document <- function(spec = list(), plot_settings = list()) {
  indices <- microbiome_alpha_selected_indices(spec)
  groups <- as.character(spec$alpha_group_variables %||% character())
  statistic <- spec$alpha_stat_method %||% "descriptive"
  quote_values <- function(values) paste(dQuote(values, q = FALSE), collapse = ", ")
  selected_code <- paste0("c(", quote_values(indices), ")")
  group_code <- paste0("c(", quote_values(groups), ")")
  confidence <- format(as.numeric(spec$alpha_conf_level %||% 0.95), scientific = FALSE)
  adjustment <- dQuote(spec$alpha_p_adjust %||% "BH", q = FALSE)
  random_effect <- dQuote(spec$alpha_random_effect %||% "", q = FALSE)
  plot_type <- dQuote(plot_settings$plot_type %||% spec$alpha_plot_type %||% "box_jitter", q = FALSE)
  test_lines <- switch(statistic,
    descriptive = c("statistical_tests <- data.frame()", "posthoc_comparisons <- data.frame()"),
    t_test = c(
      "statistical_tests <- do.call(rbind, lapply(selected_indices, function(index) {",
      "  dat <- alpha_table[, c(index, group_variables), drop = FALSE]",
      "  dat <- dat[stats::complete.cases(dat), , drop = FALSE]",
      "  group <- droplevels(factor(dat[[group_variables[[1]]]]))",
      "  stopifnot(nlevels(group) == 2L)",
      sprintf("  fit <- stats::t.test(dat[[index]] ~ group, var.equal = TRUE, conf.level = %s)", confidence),
      "  data.frame(DiversityIndex = index, Test = fit$method, Statistic = unname(fit$statistic), Df = unname(fit$parameter), PValue = fit$p.value)",
      "}))", "posthoc_comparisons <- data.frame()"),
    welch_t = c(
      "statistical_tests <- do.call(rbind, lapply(selected_indices, function(index) {",
      "  dat <- alpha_table[, c(index, group_variables), drop = FALSE]; dat <- dat[stats::complete.cases(dat), , drop = FALSE]",
      "  group <- droplevels(factor(dat[[group_variables[[1]]]])); stopifnot(nlevels(group) == 2L)",
      sprintf("  fit <- stats::t.test(dat[[index]] ~ group, var.equal = FALSE, conf.level = %s)", confidence),
      "  data.frame(DiversityIndex = index, Test = fit$method, Statistic = unname(fit$statistic), Df = unname(fit$parameter), PValue = fit$p.value)",
      "}))", "posthoc_comparisons <- data.frame()"),
    wilcoxon = c(
      "statistical_tests <- do.call(rbind, lapply(selected_indices, function(index) {",
      "  dat <- alpha_table[, c(index, group_variables), drop = FALSE]; dat <- dat[stats::complete.cases(dat), , drop = FALSE]",
      "  group <- droplevels(factor(dat[[group_variables[[1]]]])); stopifnot(nlevels(group) == 2L)",
      sprintf("  fit <- stats::wilcox.test(dat[[index]] ~ group, exact = FALSE, conf.int = TRUE, conf.level = %s)", confidence),
      "  data.frame(DiversityIndex = index, Test = fit$method, Statistic = unname(fit$statistic), Df = NA_real_, PValue = fit$p.value)",
      "}))", "posthoc_comparisons <- data.frame()"),
    welch_anova = c(
      "statistical_tests <- do.call(rbind, lapply(selected_indices, function(index) {",
      "  dat <- alpha_table[, c(index, group_variables), drop = FALSE]; dat <- dat[stats::complete.cases(dat), , drop = FALSE]",
      "  fit <- stats::oneway.test(stats::reformulate(group_variables, response = index), data = dat, var.equal = FALSE)",
      "  data.frame(DiversityIndex = index, Test = fit$method, Statistic = unname(fit$statistic), Df = paste(fit$parameter, collapse = ', '), PValue = fit$p.value)",
      "}))", "posthoc_comparisons <- data.frame()"),
    kruskal = c(
      "statistical_tests <- do.call(rbind, lapply(selected_indices, function(index) {",
      "  dat <- alpha_table[, c(index, group_variables), drop = FALSE]; dat <- dat[stats::complete.cases(dat), , drop = FALSE]",
      "  fit <- stats::kruskal.test(stats::reformulate(group_variables, response = index), data = dat)",
      "  data.frame(DiversityIndex = index, Test = fit$method, Statistic = unname(fit$statistic), Df = unname(fit$parameter), PValue = fit$p.value)",
      "}))",
      "posthoc_comparisons <- do.call(rbind, lapply(selected_indices, function(index) {",
      "  dat <- alpha_table[, c(index, group_variables), drop = FALSE]; dat <- dat[stats::complete.cases(dat), , drop = FALSE]",
      sprintf("  pw <- stats::pairwise.wilcox.test(dat[[index]], factor(dat[[group_variables[[1]]]]), p.adjust.method = %s, exact = FALSE)", adjustment),
      "  out <- as.data.frame(as.table(pw$p.value), stringsAsFactors = FALSE); names(out) <- c('Group1', 'Group2', 'AdjustedP')",
      "  out <- out[is.finite(out$AdjustedP), , drop = FALSE]; cbind(DiversityIndex = index, out)",
      "}))"),
    lmm = c(
      "if (!requireNamespace('lme4', quietly = TRUE)) stop('Package lme4 is required for the selected mixed model.')",
      sprintf("random_effect <- %s", random_effect),
      "statistical_tests <- do.call(rbind, lapply(selected_indices, function(index) {",
      "  dat <- alpha_table[, unique(c(index, group_variables, random_effect)), drop = FALSE]; dat <- dat[stats::complete.cases(dat), , drop = FALSE]",
      "  fixed <- paste(sprintf('`%s`', group_variables), collapse = ' + ')",
      "  fit <- lme4::lmer(stats::as.formula(sprintf('`%s` ~ %s + (1 | `%s`)', index, fixed, random_effect)), data = dat)",
      "  out <- as.data.frame(coef(summary(fit))); out$Term <- rownames(out); rownames(out) <- NULL; cbind(DiversityIndex = index, out)",
      "}))", "posthoc_comparisons <- data.frame()"),
    c(
      "statistical_tests <- do.call(rbind, lapply(selected_indices, function(index) {",
      "  dat <- alpha_table[, c(index, group_variables), drop = FALSE]; dat <- dat[stats::complete.cases(dat), , drop = FALSE]",
      "  fit <- stats::lm(stats::reformulate(group_variables, response = index), data = dat)",
      "  out <- as.data.frame(stats::anova(fit)); out$Term <- rownames(out); rownames(out) <- NULL; cbind(DiversityIndex = index, out)",
      "}))", "posthoc_comparisons <- data.frame()")
  )
  plot_lines <- c(
    "# Plot the same selected indices used in the result panel.",
    "long_alpha <- do.call(rbind, lapply(selected_indices, function(index) data.frame(SampleID = alpha_table$SampleID, DiversityIndex = index, Value = alpha_table[[index]])))",
    "if (length(group_variables)) {",
    "  long_alpha$Group <- rep(interaction(alpha_table[, group_variables, drop = FALSE], drop = TRUE, sep = ' × '), times = length(selected_indices))",
    "  x_label <- paste(group_variables, collapse = ' × ')",
    "} else { long_alpha$Group <- long_alpha$DiversityIndex; x_label <- NULL }",
    "plot <- ggplot2::ggplot(long_alpha, ggplot2::aes(Group, Value, fill = Group))",
    sprintf("plot_type <- %s", plot_type),
    "if (plot_type == 'violin_box') {",
    "  plot <- plot + ggplot2::geom_violin(trim = FALSE, alpha = 0.55) + ggplot2::geom_boxplot(width = 0.2, outlier.shape = NA) + ggplot2::geom_jitter(width = 0.10, size = 1.25, alpha = 0.55)",
    "} else if (plot_type == 'violin') {",
    "  plot <- plot + ggplot2::geom_violin(trim = FALSE, alpha = 0.72) + ggplot2::stat_summary(fun = stats::median, geom = 'point')",
    "} else if (plot_type == 'mean_se') {",
    "  plot <- plot + ggplot2::stat_summary(fun = mean, geom = 'col') + ggplot2::stat_summary(fun.data = ggplot2::mean_se, geom = 'errorbar') + ggplot2::geom_jitter(width = 0.11, alpha = 0.55)",
    "} else if (plot_type == 'jitter') {",
    "  plot <- plot + ggplot2::geom_jitter(width = 0.16, size = 2, alpha = 0.72)",
    "} else {",
    "  plot <- plot + ggplot2::geom_boxplot(width = 0.68, outlier.shape = NA, alpha = 0.82) + ggplot2::geom_jitter(width = 0.12, size = 1.5, alpha = 0.65)",
    "}",
    "plot <- plot + ggplot2::facet_wrap(~ DiversityIndex, scales = 'free_y') + ggplot2::theme_classic() + ggplot2::theme(legend.position = 'none', axis.text.x = ggplot2::element_text(angle = 30, hjust = 1)) + ggplot2::labs(x = x_label, y = 'Alpha diversity', title = 'Alpha diversity by group')",
    microbiome_alpha_plot_style_code(plot_settings),
    "print(plot)"
  )
  paste(c(
    microbiome_code_document_preprocessing(spec),
    "# Alpha diversity: method-specific reproducible code",
    "library(vegan)", "library(ggplot2)",
    "# estimateR's minimum-count message is non-fatal for valid sequencing counts.",
    "estimates <- suppressWarnings(vegan::estimateR(counts))",
    "observed <- as.numeric(vegan::specnumber(counts))",
    "shannon <- as.numeric(vegan::diversity(counts, index = 'shannon'))",
    "inverse_simpson <- as.numeric(vegan::diversity(counts, index = 'invsimpson'))",
    "alpha_table <- data.frame(SampleID = rownames(counts), Observed = observed, Chao1 = as.numeric(estimates['S.chao1', ]), ACE = as.numeric(estimates['S.ACE', ]), FisherAlpha = as.numeric(vegan::fisher.alpha(counts)), Shannon = shannon, Simpson = as.numeric(vegan::diversity(counts, index = 'simpson')), InverseSimpson = inverse_simpson, Hill_q0 = observed, Hill_q1 = exp(shannon), Hill_q2 = inverse_simpson, Pielou = ifelse(observed > 1, shannon / log(observed), NA_real_), check.names = FALSE)",
    "alpha_table <- cbind(alpha_table, metadata[, setdiff(names(metadata), 'SampleID'), drop = FALSE])",
    paste0("selected_indices <- ", selected_code),
    paste0("group_variables <- ", group_code),
    "group_variables <- intersect(group_variables, names(alpha_table))",
    "metadata_columns <- setdiff(names(alpha_table), c('SampleID', 'Observed', 'Chao1', 'ACE', 'FisherAlpha', 'Shannon', 'Simpson', 'InverseSimpson', 'Hill_q0', 'Hill_q1', 'Hill_q2', 'Pielou'))",
    "alpha_results <- alpha_table[, unique(c('SampleID', selected_indices, metadata_columns)), drop = FALSE]",
    test_lines, plot_lines,
    "result <- list(tables = list(alpha_diversity = alpha_results, statistical_tests = statistical_tests, posthoc_comparisons = posthoc_comparisons), plot = plot)",
    "result"
  ), collapse = "\n")
}

microbiome_alpha_metric_code_lines <- function(indices) {
  indices <- unique(as.character(indices %||% character()))
  lines <- c("# Calculate only the alpha-diversity metrics required by this method.")
  if (any(indices %in% c("Chao1", "ACE"))) {
    lines <- c(lines, "richness_estimates <- suppressWarnings(vegan::estimateR(counts))")
  }
  if (any(indices %in% c("Observed", "Hill_q0", "Pielou"))) {
    lines <- c(lines, "observed <- as.numeric(vegan::specnumber(counts))")
  }
  if (any(indices %in% c("FisherAlpha"))) {
    lines <- c(lines, "fisher_alpha <- as.numeric(vegan::fisher.alpha(counts))")
  }
  if (any(indices %in% c("Shannon", "Hill_q1", "Pielou"))) {
    lines <- c(lines, "shannon <- as.numeric(vegan::diversity(counts, index = 'shannon'))")
  }
  if (any(indices %in% c("Simpson"))) {
    lines <- c(lines, "simpson <- as.numeric(vegan::diversity(counts, index = 'simpson'))")
  }
  if (any(indices %in% c("InverseSimpson", "Hill_q2"))) {
    lines <- c(lines, "inverse_simpson <- as.numeric(vegan::diversity(counts, index = 'invsimpson'))")
  }
  columns <- c("SampleID = rownames(counts)")
  values <- c(
    Observed = "observed", Chao1 = "as.numeric(richness_estimates['S.chao1', ])",
    ACE = "as.numeric(richness_estimates['S.ACE', ])", FisherAlpha = "fisher_alpha",
    Shannon = "shannon", Simpson = "simpson", InverseSimpson = "inverse_simpson",
    Hill_q0 = "observed", Hill_q1 = "exp(shannon)", Hill_q2 = "inverse_simpson",
    Pielou = "ifelse(observed > 1, shannon / log(observed), NA_real_)"
  )
  columns <- c(columns, paste0(indices, " = ", unname(values[indices])))
  c(lines,
    paste0("alpha_table <- data.frame(", paste(columns, collapse = ", "), ", check.names = FALSE)"),
    "alpha_table <- cbind(alpha_table, metadata[, setdiff(names(metadata), 'SampleID'), drop = FALSE])")
}

microbiome_alpha_method_code_document <- function(method_id, spec = list()) {
  index <- spec$alpha_index %||% "Shannon"
  all_indices <- c("Observed", "Chao1", "ACE", "FisherAlpha", "Shannon", "Simpson", "InverseSimpson", "Hill_q0", "Hill_q1", "Hill_q2", "Pielou")
  indices <- switch(method_id,
    richness_indices = c("Observed", "Chao1", "ACE", "FisherAlpha"),
    diversity_indices = c("Shannon", "Simpson", "InverseSimpson", "Hill_q0", "Hill_q1", "Hill_q2"),
    evenness_indices = c("Observed", "Shannon", "Pielou"),
    alpha_group_comparison = all_indices,
    alpha_multifactor_model = all_indices,
    alpha_repeated_mixed = all_indices,
    alpha_environment_regression = all_indices,
    alpha_rarefaction = all_indices,
    character())
  common <- c("library(vegan)", if (identical(method_id, "alpha_rarefaction")) "library(ggplot2)" else character(), microbiome_alpha_metric_code_lines(indices))
  metadata_columns <- "setdiff(names(alpha_table), c('SampleID', 'Observed', 'Chao1', 'ACE', 'FisherAlpha', 'Shannon', 'Simpson', 'InverseSimpson', 'Hill_q0', 'Hill_q1', 'Hill_q2', 'Pielou'))"
  analysis <- switch(method_id,
    richness_indices = c(paste0("alpha_results <- alpha_table[, unique(c('SampleID', c('Observed', 'Chao1', 'ACE', 'FisherAlpha'), ", metadata_columns, ")), drop = FALSE]"), "result <- list(tables = list(alpha_diversity = alpha_results))", "result"),
    diversity_indices = c(paste0("alpha_results <- alpha_table[, unique(c('SampleID', c('Shannon', 'Simpson', 'InverseSimpson', 'Hill_q0', 'Hill_q1', 'Hill_q2'), ", metadata_columns, ")), drop = FALSE]"), "result <- list(tables = list(alpha_diversity = alpha_results))", "result"),
    evenness_indices = c(paste0("alpha_results <- alpha_table[, unique(c('SampleID', 'Pielou', ", metadata_columns, ")), drop = FALSE]"), "result <- list(tables = list(alpha_diversity = alpha_results))", "result"),
    alpha_group_comparison = c(
      paste0("group_variable <- ", dQuote(spec$group %||% "Treatment", q = FALSE)),
      paste0("alpha_index <- ", dQuote(index, q = FALSE)),
      "analysis_data <- alpha_table[, c(alpha_index, group_variable), drop = FALSE]",
      "analysis_data <- analysis_data[stats::complete.cases(analysis_data), , drop = FALSE]",
      "group <- droplevels(factor(analysis_data[[group_variable]]))",
      "omnibus <- if (nlevels(group) == 2L) stats::wilcox.test(analysis_data[[alpha_index]] ~ group, exact = FALSE) else stats::kruskal.test(analysis_data[[alpha_index]] ~ group)",
      paste0("pairwise <- stats::pairwise.wilcox.test(analysis_data[[alpha_index]], group, p.adjust.method = ", dQuote(spec$fdr_method %||% "BH", q = FALSE), ", exact = FALSE)"),
      "omnibus_test <- data.frame(index = alpha_index, test = omnibus$method, statistic = unname(omnibus$statistic), p_value = omnibus$p.value)",
      "pairwise_tests <- as.data.frame(as.table(pairwise$p.value), stringsAsFactors = FALSE); names(pairwise_tests) <- c('group_1', 'group_2', 'adjusted_p'); pairwise_tests <- pairwise_tests[is.finite(pairwise_tests$adjusted_p), , drop = FALSE]",
      "result <- list(tables = list(alpha_diversity = alpha_table, omnibus_test = omnibus_test, pairwise_tests = pairwise_tests))", "result"),
    alpha_multifactor_model = c(
      paste0("alpha_index <- ", dQuote(index, q = FALSE)),
      paste0("fixed_effects <- c(", paste(dQuote(spec$fixed_effects %||% spec$group %||% "Treatment", q = FALSE), collapse = ", "), ")"),
      "fit <- stats::lm(stats::reformulate(fixed_effects, response = alpha_index), data = alpha_table)",
      "model_coefficients <- data.frame(term = rownames(summary(fit)$coefficients), summary(fit)$coefficients, row.names = NULL, check.names = FALSE)",
      "model_anova <- data.frame(term = rownames(stats::anova(fit)), stats::anova(fit), row.names = NULL, check.names = FALSE)",
      "result <- list(tables = list(alpha_diversity = alpha_table, model_coefficients = model_coefficients, model_anova = model_anova))", "result"),
    alpha_repeated_mixed = c(
      "library(lme4)",
      paste0("alpha_index <- ", dQuote(index, q = FALSE)),
      paste0("fixed_effect <- ", dQuote(spec$group %||% "Treatment", q = FALSE)),
      paste0("random_effect <- ", dQuote(spec$random_effect %||% spec$subject_id %||% "Subject", q = FALSE)),
      paste0("fit <- lme4::lmer(stats::as.formula(sprintf('`%s` ~ `%s` + (1 | `%s`)', alpha_index, fixed_effect, random_effect)), data = alpha_table, REML = ", if (isTRUE(spec$reml %||% TRUE)) "TRUE" else "FALSE", ")"),
      "model_coefficients <- data.frame(term = rownames(coef(summary(fit))), coef(summary(fit)), row.names = NULL, check.names = FALSE)",
      "random_effects <- as.data.frame(lme4::VarCorr(fit))",
      "result <- list(tables = list(alpha_diversity = alpha_table, model_coefficients = model_coefficients, random_effects = random_effects))", "result"),
    alpha_environment_regression = c(
      paste0("alpha_index <- ", dQuote(index, q = FALSE)),
      paste0("environment_variables <- c(", paste(dQuote(spec$fixed_effects %||% character(), q = FALSE), collapse = ", "), ")"),
      "environment <- as.data.frame(bundle$environment, stringsAsFactors = FALSE)",
      "if (!'SampleID' %in% names(environment)) environment$SampleID <- rownames(environment)",
      "environment <- environment[match(alpha_table$SampleID, environment$SampleID), , drop = FALSE]",
      "if (!length(environment_variables)) environment_variables <- names(environment)[vapply(environment, is.numeric, logical(1))]",
      "environment_variables <- setdiff(environment_variables, 'SampleID')",
      "environment <- environment[, environment_variables, drop = FALSE]",
      "analysis_data <- cbind(alpha_table[, c('SampleID', alpha_index), drop = FALSE], environment)",
      "fit <- stats::lm(stats::reformulate(names(environment), response = alpha_index), data = analysis_data)",
      "model_coefficients <- data.frame(term = rownames(summary(fit)$coefficients), summary(fit)$coefficients, row.names = NULL, check.names = FALSE)",
      "model_anova <- data.frame(term = rownames(stats::anova(fit)), stats::anova(fit), row.names = NULL, check.names = FALSE)",
      "result <- list(tables = list(alpha_diversity = alpha_table, model_coefficients = model_coefficients, model_anova = model_anova))", "result"),
    alpha_rarefaction = c(
      "minimum_depth <- min(rowSums(counts))",
      "depths <- unique(pmax(1L, round(seq(1, minimum_depth, length.out = min(40L, minimum_depth)))))",
      "rarefaction <- do.call(rbind, lapply(seq_len(nrow(counts)), function(row) { valid <- depths[depths <= sum(counts[row, ])]; data.frame(SampleID = rownames(counts)[row], Depth = valid, Richness = vapply(valid, function(depth) as.numeric(vegan::rarefy(counts[row, , drop = FALSE], sample = depth)[[1]]), numeric(1))) }))",
      "plot <- ggplot2::ggplot(rarefaction, ggplot2::aes(Depth, Richness, group = SampleID)) + ggplot2::geom_line(alpha = 0.65, linewidth = 0.6, colour = '#2878A8') + ggplot2::theme_classic() + ggplot2::labs(x = 'Sequencing depth', y = 'Expected richness', title = 'Sample rarefaction curves')",
      "print(plot)", "result <- list(tables = list(alpha_diversity = alpha_table, rarefaction = rarefaction), plots = list(rarefaction = plot))", "result"),
    character())
  paste(c(microbiome_code_document_preprocessing(spec), common, analysis), collapse = "\n")
}

microbiome_beta_method_code_document <- function(method_id, spec = list()) {
  distance_method <- spec$distance %||% spec$distance_method %||% "bray"
  group_variable <- spec$group %||% (spec$group_variables %||% "Treatment")[[1]]
  permutations <- as.integer(spec$permutations %||% 999L)
  seed <- as.integer(spec$seed %||% 2026L)
  trymax <- as.integer(spec$trymax %||% 50L)
  quote_vector <- function(values) {
    values <- unique(as.character(values %||% character()))
    paste0("c(", paste(dQuote(values, q = FALSE), collapse = ", "), ")")
  }
  distance_lines <- c(
    "library(vegan)",
    paste0("distance_method <- ", dQuote(distance_method, q = FALSE)),
    "counts <- as.matrix(counts)",
    "storage.mode(counts) <- 'double'",
    "if (distance_method == 'hellinger') {",
    "  community_distance <- stats::dist(vegan::decostand(counts, method = 'hellinger'))",
    "} else if (distance_method == 'aitchison') {",
    "  clr_counts <- log(counts + 0.5)",
    "  clr_counts <- clr_counts - rowMeans(clr_counts)",
    "  community_distance <- stats::dist(clr_counts)",
    "} else if (distance_method %in% c('unifrac', 'weighted_unifrac')) {",
    "  stopifnot(requireNamespace('GUniFrac', quietly = TRUE), inherits(bundle$phylogeny, 'phylo'))",
    "  unifrac_array <- GUniFrac::GUniFrac(counts, bundle$phylogeny, alpha = c(0, 1))$unifracs",
    "  community_distance <- stats::as.dist(unifrac_array[, , if (distance_method == 'unifrac') 'd_UW' else 'd_1'])",
    "} else {",
    "  vegan_method <- if (distance_method == 'sorensen') 'bray' else distance_method",
    "  community_distance <- vegan::vegdist(counts, method = vegan_method, binary = distance_method %in% c('jaccard', 'sorensen'))",
    "}")
  group_lines <- c(
    paste0("set.seed(", seed, "L)"),
    paste0("group_variable <- ", dQuote(group_variable, q = FALSE)),
    "group <- if (group_variable %in% names(metadata)) factor(metadata[[group_variable]]) else NULL")
  significance_method <- spec$beta_significance_test %||% "none"
  significance_groups <- spec$group_variables %||% group_variable
  significance_lines <- if (method_id %in% c("pcoa", "nmds", "pca") &&
      !identical(significance_method, "none")) c(
    "# Run only the significance test selected for this ordination.",
    paste0("significance_method <- ", dQuote(significance_method, q = FALSE)),
    paste0("significance_groups <- ", quote_vector(significance_groups)),
    "significance_groups <- intersect(significance_groups, names(metadata))",
    "complete <- stats::complete.cases(metadata[, significance_groups, drop = FALSE])",
    "stopifnot(sum(complete) >= 3L)",
    "test_metadata <- droplevels(metadata[complete, significance_groups, drop = FALSE])",
    "significance_groups <- significance_groups[vapply(test_metadata, function(value) nlevels(factor(value)) >= 2L, logical(1))]",
    "stopifnot(length(significance_groups) > 0L)",
    "test_metadata <- test_metadata[, significance_groups, drop = FALSE]",
    "distance_matrix_for_test <- as.matrix(community_distance)",
    "test_distance <- stats::as.dist(distance_matrix_for_test[complete, complete, drop = FALSE])",
    paste0("permutations <- ", permutations, "L"),
    "significance_tables <- list()",
    "significance_summary <- list()",
    if (significance_method %in% c("permanova", "permanova_permdisp")) c(
      "permanova_formula <- stats::reformulate(significance_groups, response = 'test_distance')",
      "permanova_fit <- vegan::adonis2(permanova_formula, data = test_metadata, permutations = permutations)",
      "permanova_table <- data.frame(term = rownames(permanova_fit), permanova_fit, row.names = NULL, check.names = FALSE)",
      "significance_tables$permanova <- permanova_table",
      "term_rows <- !permanova_table$term %in% c('Residual', 'Total')",
      "significance_summary[[length(significance_summary) + 1L]] <- data.frame(test = 'PERMANOVA', grouping = permanova_table$term[term_rows], statistic = permanova_table$F[term_rows], p_value = permanova_table[['Pr(>F)']][term_rows], permutations = permutations)"
    ) else character(),
    if (significance_method %in% c("permdisp", "permanova_permdisp")) c(
      "dispersion_tables <- lapply(significance_groups, function(variable) {",
      "  dispersion <- vegan::betadisper(test_distance, factor(test_metadata[[variable]]))",
      "  dispersion_fit <- vegan::permutest(dispersion, permutations = permutations)",
      "  table <- data.frame(grouping = variable, term = rownames(dispersion_fit$tab), dispersion_fit$tab, row.names = NULL, check.names = FALSE)",
      "  significance_summary[[length(significance_summary) + 1L]] <<- data.frame(test = 'PERMDISP', grouping = variable, statistic = table$F[[1]], p_value = table[['Pr(>F)']][[1]], permutations = permutations)",
      "  table",
      "})",
      "significance_tables$permdisp <- do.call(rbind, dispersion_tables)"
    ) else character(),
    if (significance_method %in% c("anosim", "mrpp")) c(
      "single_test_tables <- lapply(significance_groups, function(variable) {",
      "  test_group <- factor(test_metadata[[variable]])",
      if (identical(significance_method, "anosim")) {
        "  fit <- vegan::anosim(test_distance, test_group, permutations = permutations); data.frame(test = 'ANOSIM', grouping = variable, statistic = unname(fit$statistic), p_value = fit$signif, permutations = permutations)"
      } else {
        "  fit <- vegan::mrpp(test_distance, test_group, permutations = permutations); data.frame(test = 'MRPP', grouping = variable, statistic = fit$A, p_value = fit$Pvalue, permutations = permutations)"
      },
      "})",
      paste0("significance_tables$", significance_method, " <- do.call(rbind, single_test_tables)"),
      paste0("significance_summary <- c(significance_summary, single_test_tables)")
    ) else character(),
    "significance_tables$community_significance_summary <- do.call(rbind, significance_summary)",
    "tables <- c(tables, significance_tables)"
  ) else character()
  ordination_plot_lines <- c(
    "# Reproduce the result-panel ordination figure, including group shapes and 95% ellipses.",
    "if (!'Group' %in% names(scores)) {",
    "  ordination_plot <- ggplot2::ggplot(scores, ggplot2::aes(Axis1, Axis2)) + ggplot2::geom_point(size = 3, alpha = 0.85, colour = '#1B9E77') + ggplot2::labs(x = axis_labels[[1]], y = axis_labels[[2]]) + ggplot2::theme_bw(base_size = 13)",
    "} else {",
    "  scores$Group <- droplevels(factor(scores$Group))",
    "  group_levels <- levels(scores$Group)",
    "  group_colours <- stats::setNames(rep(c('#1B9E77', '#D95F02', '#7570B3', '#E7298A', '#66A61E', '#E6AB02', '#A6761D', '#1F78B4'), length.out = length(group_levels)), group_levels)",
    "  group_shapes <- stats::setNames(rep(c(16, 17, 7, 18, 15, 8, 3, 4), length.out = length(group_levels)), group_levels)",
    "  ellipse_parts <- lapply(group_levels, function(level_name) {",
    "    values <- scores[scores$Group == level_name, c('Axis1', 'Axis2'), drop = FALSE]",
    "    if (nrow(values) < 3L || any(!is.finite(as.matrix(values)))) return(NULL)",
    "    covariance <- stats::cov(values); decomposition <- eigen(covariance, symmetric = TRUE)",
    "    largest <- max(decomposition$values, na.rm = TRUE); if (!is.finite(largest) || largest <= 0) return(NULL)",
    "    regularized <- pmax(decomposition$values, largest * 1e-6)",
    "    transform <- decomposition$vectors %*% diag(sqrt(regularized), nrow = 2L)",
    "    angle <- seq(0, 2 * pi, length.out = 120L); circle <- rbind(cos(angle), sin(angle))",
    "    polygon <- sweep(t(sqrt(stats::qchisq(0.95, df = 2L)) * transform %*% circle), 2L, colMeans(values), '+')",
    "    data.frame(Axis1 = polygon[, 1], Axis2 = polygon[, 2], Group = level_name)",
    "  })",
    "  ellipse_parts <- Filter(Negate(is.null), ellipse_parts)",
    "  ellipse_data <- if (length(ellipse_parts)) do.call(rbind, ellipse_parts) else data.frame()",
    "  ordination_plot <- ggplot2::ggplot(scores, ggplot2::aes(Axis1, Axis2, colour = Group, shape = Group))",
    "  if (nrow(ellipse_data)) ordination_plot <- ordination_plot + ggplot2::geom_polygon(data = ellipse_data, ggplot2::aes(Axis1, Axis2, colour = Group, fill = Group, group = Group), inherit.aes = FALSE, alpha = 0.10, linewidth = 0.9, show.legend = FALSE) + ggplot2::scale_fill_manual(values = group_colours)",
    "  ordination_plot <- ordination_plot + ggplot2::geom_point(size = 3.2, alpha = 0.86) + ggplot2::scale_colour_manual(values = group_colours) + ggplot2::scale_shape_manual(values = group_shapes) + ggplot2::labs(x = axis_labels[[1]], y = axis_labels[[2]], colour = 'Group', shape = 'Group') + ggplot2::theme_bw(base_size = 13) + ggplot2::theme(panel.grid.minor = ggplot2::element_blank(), legend.position = 'right', legend.title = ggplot2::element_text(face = 'plain'))",
    "}",
    "plots$ordination <- ordination_plot",
    "print(ordination_plot)",
    "# Reproduce the result-panel distance-to-centroid table, comparisons and plot.",
    "if (!is.null(group) && nlevels(droplevels(group)) >= 2L && !anyNA(group)) {",
    "  group <- droplevels(group)",
    "  group_dispersion <- vegan::betadisper(community_distance, group)",
    "  group_distances <- data.frame(Group = group, Distance = as.numeric(group_dispersion$distances))",
    "  distance_levels <- levels(group); distance_colours <- stats::setNames(rep(c('#1B9E77', '#D95F02', '#7570B3', '#E7298A', '#66A61E', '#E6AB02', '#A6761D', '#1F78B4'), length.out = length(distance_levels)), distance_levels)",
    "  group_distance_plot <- ggplot2::ggplot(group_distances, ggplot2::aes(Group, Distance, colour = Group)) + ggplot2::geom_boxplot(width = 0.66, fill = 'white', linewidth = 0.8, outlier.shape = NA) + ggplot2::stat_summary(fun = mean, geom = 'point', size = 2.8, show.legend = FALSE) + ggplot2::scale_colour_manual(values = distance_colours) + ggplot2::labs(x = NULL, y = paste(distance_label, 'distance')) + ggplot2::theme_classic(base_size = 14) + ggplot2::theme(legend.position = 'none', plot.margin = ggplot2::margin(8, 24, 8, 8))",
    "  distance_pairs <- utils::combn(distance_levels, 2L, simplify = FALSE)",
    "  group_distance_comparisons <- if (length(distance_pairs)) do.call(rbind, lapply(distance_pairs, function(pair) { fit <- stats::wilcox.test(group_distances$Distance[group_distances$Group == pair[[1]]], group_distances$Distance[group_distances$Group == pair[[2]]], exact = FALSE); data.frame(group1 = pair[[1]], group2 = pair[[2]], p_value = fit$p.value) })) else data.frame()",
    "  if (nrow(group_distance_comparisons)) { group_distance_comparisons$p_adjusted <- stats::p.adjust(group_distance_comparisons$p_value, method = 'BH'); group_distance_comparisons$significance <- cut(group_distance_comparisons$p_adjusted, breaks = c(-Inf, 0.001, 0.01, 0.05, Inf), labels = c('***', '**', '*', 'ns')) }",
    "  tables$group_distances <- group_distances; tables$group_distance_comparisons <- group_distance_comparisons; plots$group_distance <- group_distance_plot",
    "}")
  analysis <- switch(method_id,
    pcoa = c(distance_lines,
      group_lines, "library(ggplot2)", "plots <- list()",
      "ordination <- stats::cmdscale(community_distance, eig = TRUE, add = TRUE, k = 2)",
      "scores <- data.frame(SampleID = rownames(ordination$points), Axis1 = ordination$points[, 1], Axis2 = ordination$points[, 2])",
      "if (!is.null(group)) scores$Group <- group",
      "positive_eigenvalues <- ordination$eig[ordination$eig > 0]",
      "statistics <- data.frame(metric = c('Axis1_explained', 'Axis2_explained', 'negative_eigenvalues'), value = c(positive_eigenvalues[1] / sum(positive_eigenvalues), positive_eigenvalues[2] / sum(positive_eigenvalues), sum(ordination$eig < 0)))",
      "tables <- list(scores = scores, eigenvalues = data.frame(Axis = seq_along(ordination$eig), Eigenvalue = ordination$eig))",
      "axis_labels <- c(sprintf('PCo1 [%.1f%%]', 100 * positive_eigenvalues[1] / sum(positive_eigenvalues)), sprintf('PCo2 [%.1f%%]', 100 * positive_eigenvalues[2] / sum(positive_eigenvalues)))",
      "distance_label <- switch(distance_method, bray = 'Bray-Curtis', jaccard = 'Jaccard', euclidean = 'Euclidean', hellinger = 'Hellinger', aitchison = 'Aitchison', distance_method)",
      significance_lines, ordination_plot_lines,
      "result <- list(tables = tables, statistics = statistics, plots = plots, ordination_scores = scores, distance_matrix = community_distance)", "result"),
    nmds = c(distance_lines,
      group_lines, "library(ggplot2)", "plots <- list()", paste0("set.seed(", seed, "L)"),
      paste0("ordination <- vegan::metaMDS(community_distance, k = 2, trymax = ", trymax, "L, trace = FALSE)"),
      "site_scores <- vegan::scores(ordination, display = 'sites')",
      "scores <- data.frame(SampleID = rownames(site_scores), Axis1 = site_scores[, 1], Axis2 = site_scores[, 2])",
      "if (!is.null(group)) scores$Group <- group", "statistics <- data.frame(metric = 'stress', value = ordination$stress)",
      "tables <- list(scores = scores, diagnostics = statistics)", "axis_labels <- c('NMDS1', 'NMDS2')",
      "distance_label <- switch(distance_method, bray = 'Bray-Curtis', jaccard = 'Jaccard', euclidean = 'Euclidean', hellinger = 'Hellinger', aitchison = 'Aitchison', distance_method)",
      significance_lines, ordination_plot_lines,
      "result <- list(tables = tables, statistics = statistics, plots = plots, ordination_scores = scores, distance_matrix = community_distance)", "result"),
    distance_matrix = c(distance_lines,
      "distance_matrix <- as.matrix(community_distance)",
      "tables <- list(distance_matrix = data.frame(SampleID = rownames(distance_matrix), distance_matrix, check.names = FALSE))",
      "statistics <- data.frame(metric = c('samples', 'minimum', 'median', 'maximum'), value = c(nrow(distance_matrix), min(community_distance), stats::median(community_distance), max(community_distance)))",
      "result <- list(tables = tables, statistics = statistics, distance_matrix = community_distance)", "result"),
    beta_cluster_heatmap = c(distance_lines,
      paste0("cluster_method <- ", dQuote(spec$cluster_method %||% "average", q = FALSE)),
      "distance_matrix <- as.matrix(community_distance)",
      "fit <- stats::hclust(community_distance, method = cluster_method)",
      "tables <- list(distance_matrix = data.frame(SampleID = rownames(distance_matrix), distance_matrix, check.names = FALSE), cluster_order = data.frame(Order = seq_along(fit$order), SampleID = fit$labels[fit$order]))",
      "statistics <- data.frame(samples = nrow(distance_matrix), linkage = fit$method)",
      "result <- list(tables = tables, statistics = statistics, distance_matrix = community_distance)", "result"),
    pca = c(
      distance_lines, group_lines, "library(ggplot2)", "plots <- list()",
      "community <- vegan::decostand(counts, method = 'hellinger')", "ordination <- stats::prcomp(community, center = TRUE, scale. = FALSE)",
      "scores <- data.frame(SampleID = rownames(ordination$x), Axis1 = ordination$x[, 1], Axis2 = ordination$x[, 2])", "if (!is.null(group)) scores$Group <- group",
      "explained <- summary(ordination)$importance[2, ]", "statistics <- data.frame(metric = c('PC1_explained', 'PC2_explained'), value = explained[1:2])",
      "tables <- list(scores = scores, loadings = data.frame(Feature = rownames(ordination$rotation), ordination$rotation[, 1:2, drop = FALSE]))",
      "axis_labels <- c(sprintf('PC1 [%.1f%%]', 100 * explained[[1]]), sprintf('PC2 [%.1f%%]', 100 * explained[[2]]))",
      "distance_label <- switch(distance_method, bray = 'Bray-Curtis', jaccard = 'Jaccard', euclidean = 'Euclidean', hellinger = 'Hellinger', aitchison = 'Aitchison', distance_method)",
      significance_lines, ordination_plot_lines,
      "result <- list(tables = tables, statistics = statistics, plots = plots, ordination_scores = scores, distance_matrix = community_distance)", "result"),
    robust_aitchison_pca = c(
      group_lines, "library(ggplot2)", "plots <- list()",
      "pseudocount <- 0.5",
      "clr_counts <- log(as.matrix(counts) + pseudocount)",
      "clr_counts <- clr_counts - rowMeans(clr_counts)",
      "ordination <- stats::prcomp(clr_counts, center = FALSE, scale. = FALSE)",
      "scores <- data.frame(SampleID = rownames(ordination$x), Axis1 = ordination$x[, 1], Axis2 = ordination$x[, 2])",
      "if (!is.null(group)) scores$Group <- group",
      "explained <- summary(ordination)$importance[2, ]",
      "statistics <- data.frame(metric = c('PC1_explained', 'PC2_explained'), value = explained[1:2])",
      "tables <- list(scores = scores, loadings = data.frame(Feature = rownames(ordination$rotation), ordination$rotation[, 1:2, drop = FALSE]))",
      "community_distance <- stats::dist(clr_counts)",
      "axis_labels <- c(sprintf('Robust PC1 [%.1f%%]', 100 * explained[[1]]), sprintf('Robust PC2 [%.1f%%]', 100 * explained[[2]]))",
      "distance_label <- 'Aitchison'", ordination_plot_lines,
      "result <- list(tables = tables, statistics = statistics, plots = plots, ordination_scores = scores, distance_matrix = community_distance)", "result"),
    community_trajectory = c(
      distance_lines, group_lines, "library(ggplot2)",
      paste0("time_variable <- ", dQuote(spec$time_variable %||% "Time", q = FALSE)),
      paste0("subject_variable <- ", dQuote(spec$subject_variable %||% "Subject", q = FALSE)),
      "stopifnot(time_variable %in% names(metadata))",
      "ordination <- stats::cmdscale(community_distance, eig = TRUE, add = TRUE, k = 2)",
      "scores <- data.frame(SampleID = rownames(ordination$points), Axis1 = ordination$points[, 1], Axis2 = ordination$points[, 2], Time = metadata[[time_variable]])",
      "scores$Group <- if (!is.null(group)) group else factor('All')",
      "scores$Subject <- if (subject_variable %in% names(metadata)) factor(metadata[[subject_variable]]) else scores$Group",
      "scores <- scores[order(scores$Subject, scores$Time), , drop = FALSE]",
      "trajectory_plot <- ggplot2::ggplot(scores, ggplot2::aes(Axis1, Axis2, colour = Group, group = Subject)) + ggplot2::geom_path(arrow = grid::arrow(length = grid::unit(2, 'mm')), alpha = 0.7) + ggplot2::geom_point(ggplot2::aes(shape = Group), size = 2.8) + ggplot2::theme_bw() + ggplot2::labs(title = 'Community trajectory')",
      "tables <- list(trajectory_scores = scores)", "plots <- list(community_trajectory = trajectory_plot)",
      "print(trajectory_plot)",
      "result <- list(tables = tables, plots = plots, ordination_scores = scores, distance_matrix = community_distance)", "result"),
    permanova_interaction = c(distance_lines, group_lines,
      paste0("fixed_effects <- ", quote_vector(spec$fixed_effects %||% group_variable)),
      "fixed_effects <- intersect(fixed_effects, names(metadata)); if (!length(fixed_effects)) { metadata$.dava_group <- group; fixed_effects <- '.dava_group' }",
      paste0("permutations <- ", permutations, "L"),
      "permanova_formula <- if (length(fixed_effects) > 1L) stats::as.formula(paste('community_distance ~', paste(fixed_effects, collapse = ' * '))) else stats::reformulate(fixed_effects, response = 'community_distance')",
      "permanova <- vegan::adonis2(permanova_formula, data = metadata, permutations = permutations)",
      "dispersion <- vegan::betadisper(community_distance, group); permdisp <- vegan::permutest(dispersion, permutations = permutations)",
      "tables <- list(permanova = data.frame(term = rownames(permanova), permanova, row.names = NULL, check.names = FALSE), permdisp = data.frame(term = rownames(permdisp$tab), permdisp$tab, row.names = NULL, check.names = FALSE))",
      "statistics <- data.frame(test = c('PERMANOVA', 'PERMDISP'), permutations = permutations)", "result <- list(tables = tables, statistics = statistics)", "result"),
    permanova_restricted = c(distance_lines, group_lines,
      paste0("fixed_effects <- ", quote_vector(spec$fixed_effects %||% group_variable)),
      "fixed_effects <- intersect(fixed_effects, names(metadata)); if (!length(fixed_effects)) { metadata$.dava_group <- group; fixed_effects <- '.dava_group' }",
      paste0("strata_variable <- ", dQuote(spec$strata %||% spec$random_effect %||% "", q = FALSE)), paste0("permutations <- ", permutations, "L"),
      "permutation_design <- permutations", "if (nzchar(strata_variable) && strata_variable %in% names(metadata)) { permutation_design <- permute::how(nperm = permutations); permute::setBlocks(permutation_design) <- factor(metadata[[strata_variable]]) }",
      "permanova_formula <- stats::reformulate(fixed_effects, response = 'community_distance')", "permanova <- vegan::adonis2(permanova_formula, data = metadata, permutations = permutation_design)",
      "dispersion <- vegan::betadisper(community_distance, group); permdisp <- vegan::permutest(dispersion, permutations = permutations)",
      "tables <- list(permanova = data.frame(term = rownames(permanova), permanova, row.names = NULL, check.names = FALSE), permdisp = data.frame(term = rownames(permdisp$tab), permdisp$tab, row.names = NULL, check.names = FALSE))",
      "statistics <- data.frame(test = c('PERMANOVA', 'PERMDISP'), permutations = permutations)", "result <- list(tables = tables, statistics = statistics)", "result"),
    permdisp = c(distance_lines,
      group_lines,
      paste0("permutations <- ", permutations, "L"),
      "dispersion <- vegan::betadisper(community_distance, group)", "permdisp <- vegan::permutest(dispersion, permutations = permutations)",
      "tables <- list(permdisp = data.frame(term = rownames(permdisp$tab), permdisp$tab, row.names = NULL, check.names = FALSE), distances_to_centroid = data.frame(SampleID = names(dispersion$distances), Group = group, Distance = dispersion$distances))",
      "statistics <- tables$permdisp", "result <- list(tables = tables, statistics = statistics)", "result"),
    anosim = c(distance_lines,
      group_lines,
      paste0("permutations <- ", permutations, "L"),
      "fit <- vegan::anosim(community_distance, group, permutations = permutations)",
      "statistics <- data.frame(test = 'ANOSIM', statistic = unname(fit$statistic), p_value = fit$signif)", "result <- list(tables = list(test_result = statistics), statistics = statistics)", "result"),
    mrpp = c(distance_lines,
      group_lines,
      paste0("permutations <- ", permutations, "L"),
      "fit <- vegan::mrpp(community_distance, group, permutations = permutations)",
      "statistics <- data.frame(test = 'MRPP', statistic = fit$A, p_value = fit$Pvalue, observed_delta = fit$delta)", "result <- list(tables = list(test_result = statistics), statistics = statistics)", "result"),
    between_group_distance = c(distance_lines,
      group_lines,
      "distance_matrix <- as.matrix(community_distance)",
      "pairs <- which(upper.tri(distance_matrix), arr.ind = TRUE)",
      "pairwise_distances <- data.frame(Sample1 = rownames(distance_matrix)[pairs[, 1]], Sample2 = colnames(distance_matrix)[pairs[, 2]], Group1 = group[pairs[, 1]], Group2 = group[pairs[, 2]], Distance = distance_matrix[pairs])",
      "pairwise_distances$Comparison <- ifelse(pairwise_distances$Group1 == pairwise_distances$Group2, 'Within group', 'Between groups')",
      "fit <- stats::wilcox.test(Distance ~ Comparison, data = pairwise_distances, exact = FALSE)", "statistics <- data.frame(test = fit$method, statistic = unname(fit$statistic), p_value = fit$p.value)",
      "result <- list(tables = list(pairwise_distances = pairwise_distances, comparison_test = statistics), statistics = statistics)", "result"),
    permanova_permdisp = c(distance_lines, group_lines,
      paste0("permutations <- ", permutations, "L"),
      paste0("fixed_effects <- ", quote_vector(spec$fixed_effects %||% group_variable)),
      "metadata$.dava_group <- group", "fixed_effects <- intersect(fixed_effects, names(metadata)); if (!length(fixed_effects)) fixed_effects <- '.dava_group'",
      "permanova_formula <- stats::reformulate(fixed_effects, response = 'community_distance')", "permanova <- vegan::adonis2(permanova_formula, data = metadata, permutations = permutations)",
      "dispersion <- vegan::betadisper(community_distance, group)", "permdisp <- vegan::permutest(dispersion, permutations = permutations)",
      "tables <- list(permanova = data.frame(term = rownames(permanova), permanova, row.names = NULL, check.names = FALSE), permdisp = data.frame(term = rownames(permdisp$tab), permdisp$tab, row.names = NULL, check.names = FALSE))",
      "statistics <- data.frame(test = c('PERMANOVA', 'PERMDISP'), permutations = permutations)", "result <- list(tables = tables, statistics = statistics)", "result"),
    character())
  paste(c(microbiome_code_document_preprocessing(spec), analysis), collapse = "\n")
}

microbiome_phylogenetic_tree_code_document <- function(spec = list(),
    plot_settings = list()) {
  # The tree screen has several coordinated outputs.  Keep their construction
  # explicit so the document is a runnable account of the displayed analysis.
  value <- function(setting, parameter, default) {
    plot_settings[[setting]] %||% spec[[parameter]] %||% default
  }
  quote_text <- function(x) dQuote(as.character(x), q = FALSE)
  quote_logical <- function(x) if (isTRUE(x)) "TRUE" else "FALSE"
  group_col <- as.character(spec$phylo_tree_group_col %||% "Phylum")
  prefix_remove <- as.character(spec$phylo_tree_group_prefix_remove %||% "p__")
  layout <- value("tree_layout", "phylo_tree_layout", "fan")
  open_angle <- value("tree_open_angle", "phylo_tree_open_angle", 30)
  branch_size <- value("tree_branch_size", "phylo_tree_branch_size", 0.3)
  tip_point <- value("tree_tip_point", "phylo_tree_tip_point", TRUE)
  tip_point_size <- value("tree_tip_point_size", "phylo_tree_tip_point_size", 2)
  tip_point_shape <- value("tree_tip_point_shape", "phylo_tree_tip_point_shape", 21)
  tip_point_stroke <- value("tree_tip_point_stroke", "phylo_tree_tip_point_stroke", 0.3)
  tip_point_alpha <- value("tree_tip_point_alpha", "phylo_tree_tip_point_alpha", 0.9)
  show_tip_label <- value("tree_show_tip_label", "phylo_tree_show_tip_label", FALSE)
  tip_label_size <- value("tree_tip_label_size", "phylo_tree_tip_label_size", 2)
  tip_label_offset <- value("tree_tip_label_offset", "phylo_tree_tip_label_offset", 0.5)
  show_node_label <- value("tree_show_node_label", "phylo_tree_show_node_label", FALSE)
  clade_coloring <- value("tree_clade_coloring", "phylo_tree_clade_coloring", TRUE)
  branch_colour <- value("tree_branch_colour", "phylo_tree_branch_colour", "#666666")
  legend_position <- value("tree_legend_position", "phylo_tree_legend_position", "right")
  legend_font_size <- value("tree_legend_font_size", "phylo_tree_legend_font_size", 3.5)
  legend_title <- value("tree_legend_title", "phylo_tree_legend_title", "")
  palette_name <- value("tree_palette", "phylo_tree_palette", "Dark 3")
  ring_columns <- as.character(value("tree_ring_columns", "phylo_tree_ring_columns",
    c("RelAbund", "Prevalence")))
  ring_geom <- value("tree_ring_geom", "phylo_tree_ring_geom", "bar")
  ring_width <- value("tree_ring_width", "phylo_tree_ring_width", 0.05)
  ring_offset <- value("tree_ring_offset", "phylo_tree_ring_offset", 0.03)
  ring_gap <- value("tree_ring_gap", "phylo_tree_ring_gap", 0.03)
  ring_point_size <- value("tree_ring_point_size", "phylo_tree_ring_point_size", 1.5)
  ring_low <- value("tree_ring_low_colour", "phylo_tree_ring_low_colour", "#0D0887")
  ring_high <- value("tree_ring_high_colour", "phylo_tree_ring_high_colour", "#F0F921")
  ring_legend <- value("tree_ring_legend", "phylo_tree_ring_legend", TRUE)
  ring_labels <- value("tree_ring_labels", "phylo_tree_ring_labels", FALSE)
  ring_label_size <- value("tree_ring_label_size", "phylo_tree_ring_label_size", 1.8)
  scale_bar <- value("tree_scale_bar", "phylo_tree_scale_bar", FALSE)
  scale_bar_label <- value("tree_scale_bar_label", "phylo_tree_scale_bar_label", "0.05")
  scale_bar_size <- value("tree_scale_bar_size", "phylo_tree_scale_bar_size", 2)
  label_colour <- value("tree_tip_label_colour", "phylo_tree_tip_label_colour", "#222222")
  requested <- as.character(spec$plot_types %||%
    c("phylo_tree", "phylo_tree_rings", "phylo_tree_labels"))
  if (!length(requested)) requested <- c("phylo_tree", "phylo_tree_rings", "phylo_tree_labels")
  show_rings <- value("tree_show_rings", "phylo_tree_show_rings",
    any(grepl("rings|labels", requested)))

  lines <- c(
    "# ---- Phylogenetic tree input and annotations ----",
    "library(microeco)", "library(ggtree)", "library(ggtreeExtra)",
    microbiome_microeco_input_code("microtable", require_tree = TRUE),
    "taxonomy <- as.data.frame(bundle$taxonomy, check.names = FALSE)",
    "tips <- rownames(microtable$otu_table)",
    "relative_abundance <- sweep(as.matrix(microtable$otu_table), 2, pmax(colSums(microtable$otu_table), 1), '/')",
    "ring_data <- data.frame(label = tips, RelAbund = rowMeans(relative_abundance) * 100, Prevalence = rowMeans(as.matrix(microtable$otu_table) > 0) * 100, stringsAsFactors = FALSE)",
    "if (nrow(taxonomy)) {",
    "  taxonomy <- taxonomy[match(tips, rownames(taxonomy)), , drop = FALSE]",
    "  taxonomy_columns <- intersect(names(taxonomy), c('Kingdom', 'Phylum', 'Class', 'Order', 'Family', 'Genus', 'Species'))",
    "  for (column in taxonomy_columns) ring_data[[column]] <- as.character(taxonomy[[column]])",
    "}",
    sprintf("group_column <- %s", quote_text(group_col)),
    "if (!group_column %in% names(ring_data)) group_column <- 'Phylum'",
    "group_values <- as.character(microtable$tax_table[match(tips, rownames(microtable$tax_table)), group_column])",
    sprintf("group_values <- gsub(%s, '', group_values)", quote_text(prefix_remove)),
    "group_values[is.na(group_values) | !nzchar(group_values)] <- 'Others'",
    "group_levels <- unique(group_values)",
    "group_count <- length(group_levels)",
    sprintf("palette_name <- %s", quote_text(palette_name)),
    "palette <- if (identical(palette_name, 'Okabe-Ito')) rep(c('#0072B2', '#E69F00', '#009E73', '#D55E00', '#CC79A7', '#56B4E9', '#F0E442', '#000000'), length.out = max(1L, group_count)) else grDevices::hcl.colors(max(1L, group_count), palette_name)",
    "if (identical(palette_name, 'Dark 3') && requireNamespace('RColorBrewer', quietly = TRUE) && group_count <= 8L) palette <- RColorBrewer::brewer.pal(max(3L, group_count), 'Dark2')[seq_len(group_count)]",
    "names(palette) <- group_levels",
    sprintf("tree_view <- microeco::trans_phylo$new(dataset = microtable, group_col = group_column, ring_data = ring_data, color_palette = palette, group_prefix_remove = %s, clade_coloring = %s)", quote_text(prefix_remove), quote_logical(clade_coloring)),
    "# ---- Base phylogenetic tree ----",
    sprintf("tree_view$plot_tree(layout = %s, open_angle = %s, branch_size = %s, tip_point = %s, tip_point_size = %s, tip_point_shape = %s, tip_point_stroke = %s, tip_point_alpha = %s, show_tip_label = %s, tip_label_size = %s, tip_label_offset = %s, show_node_label = %s, branch_color_by_group = %s, branch_color = %s, legend_title = %s, legend_position = %s, legend_font_size = %s)", quote_text(layout), format(as.numeric(open_angle)), format(as.numeric(branch_size)), quote_logical(tip_point), format(as.numeric(tip_point_size)), as.integer(tip_point_shape), format(as.numeric(tip_point_stroke)), format(as.numeric(tip_point_alpha)), quote_logical(show_tip_label), format(as.numeric(tip_label_size)), format(as.numeric(tip_label_offset)), quote_logical(show_node_label), quote_logical(clade_coloring), quote_text(branch_colour), quote_text(if (nzchar(legend_title)) legend_title else group_col), quote_text(legend_position), format(as.numeric(legend_font_size))),
    "base_tree_plot <- tree_view$get_plot()",
    sprintf("ring_columns <- intersect(c(%s), names(ring_data))", paste(quote_text(ring_columns), collapse = ", ")),
    "# ---- Taxonomy, relative-abundance and prevalence rings ----",
    paste0("if (", quote_logical(show_rings), " && length(ring_columns)) tree_view$add_rings_batch(col_names = ring_columns, numeric_geom = ", quote_text(ring_geom), ", ring_width = ", format(as.numeric(ring_width)), ", ring_offset = ", format(as.numeric(ring_offset)), ", color_low = ", quote_text(ring_low), ", color_high = ", quote_text(ring_high), ", show_legend = ", quote_logical(ring_legend), ", ring_gap = ", format(as.numeric(ring_gap)), ", point_size = ", format(as.numeric(ring_point_size)), ")"),
    if (isTRUE(show_rings) && isTRUE(ring_labels)) sprintf("if (length(ring_columns)) tree_view$add_ring_labels(size = %s)", format(as.numeric(ring_label_size))) else "# Ring labels are disabled for this view.",
    if (isTRUE(scale_bar)) sprintf("tree_view$add_scale_bar(label = %s, fontsize = %s)", quote_text(scale_bar_label), format(as.numeric(scale_bar_size))) else "# Scale bar is disabled for this view.",
    "ring_tree_plot <- tree_view$get_plot()",
    sprintf("for (index in seq_along(ring_tree_plot$layers)) if (grepl('Text', class(ring_tree_plot$layers[[index]]$geom)[1], fixed = TRUE)) ring_tree_plot$layers[[index]]$aes_params$colour <- %s", quote_text(label_colour)),
    sprintf("requested_plots <- c(%s)", paste(quote_text(requested), collapse = ", ")),
    "plots <- list()",
    "if ('phylo_tree' %in% requested_plots) plots$phylo_tree <- base_tree_plot",
    "if ('phylo_tree_rings' %in% requested_plots) plots$phylo_tree_rings <- ring_tree_plot",
    "if ('phylo_tree_labels' %in% requested_plots) plots$phylo_tree_labels <- ring_tree_plot",
    "tables <- list(ring_data = ring_data)",
    "result <- list(tables = tables, plots = plots)",
    "result"
  )
  paste(microbiome_code_document_preprocessing(spec),
    paste(lines, collapse = "\n"), sep = "\n\n")
}

microbiome_taxonomic_composition_code_document <- function(spec = list()) {
  quote_text <- function(x) dQuote(as.character(x), q = FALSE)
  rank <- as.character(spec$taxonomic_rank %||% "Genus")
  group_variables <- utils::head(as.character(
    spec$group_variables %||% spec$group %||% "Treatment"), 3L)
  plot_types <- as.character(spec$plot_types %||%
    c("stacked_bar", "grouped_bar", "composition_heatmap",
      "abundance_boxplot", "bubble"))
  threshold <- if (!is.null(spec$abundance_merge_threshold_percent)) {
    as.numeric(spec$abundance_merge_threshold_percent) / 100
  } else {
    as.numeric(spec$abundance_merge_threshold %||% 0.005)
  }
  maximum_taxa <- max(1L, as.integer(spec$abundance_max_taxa %||% 20L))
  others_label <- trimws(as.character(spec$abundance_others_label %||% "Others"))
  if (!nzchar(others_label)) others_label <- "Others"
  summary_method <- spec$abundance_group_summary %||% "mean"

  lines <- c(
    "# ---- Taxonomic aggregation ----",
    "library(ggplot2)",
    "counts <- as.matrix(bundle$counts)",
    "taxonomy <- as.data.frame(bundle$taxonomy, check.names = FALSE)",
    sprintf("taxonomic_rank <- %s", quote_text(rank)),
    "taxonomy_ids <- if ('Feature' %in% names(taxonomy)) as.character(taxonomy$Feature) else rownames(taxonomy)",
    "taxon <- if (identical(taxonomic_rank, 'feature')) colnames(counts) else as.character(taxonomy[[taxonomic_rank]][match(colnames(counts), taxonomy_ids)])",
    "taxon[is.na(taxon) | !nzchar(trimws(taxon))] <- paste0('Unclassified_', taxonomic_rank)",
    "aggregated_counts <- rowsum(t(counts), group = taxon, reorder = FALSE)",
    "sample_depth <- colSums(aggregated_counts); sample_depth[sample_depth <= 0] <- 1",
    "relative_abundance <- sweep(aggregated_counts, 2, sample_depth, '/')",
    sprintf("merge_threshold <- %s", format(max(0, threshold), scientific = FALSE)),
    sprintf("maximum_taxa <- %dL", maximum_taxa),
    sprintf("others_label <- %s", quote_text(others_label)),
    "mean_abundance <- rowMeans(relative_abundance, na.rm = TRUE)",
    "ordered_taxa <- names(sort(mean_abundance, decreasing = TRUE))",
    "retained_taxa <- head(ordered_taxa[mean_abundance[ordered_taxa] >= merge_threshold], maximum_taxa)",
    "display_taxon <- ifelse(rownames(relative_abundance) %in% retained_taxa, rownames(relative_abundance), others_label)",
    "aggregation_summary <- data.frame(Taxon = rownames(relative_abundance), MeanRelativeAbundance = as.numeric(mean_abundance[rownames(relative_abundance)]), Threshold = merge_threshold, Retained = rownames(relative_abundance) %in% retained_taxa, DisplayTaxon = display_taxon, stringsAsFactors = FALSE)",
    "aggregation_summary <- aggregation_summary[order(aggregation_summary$MeanRelativeAbundance, decreasing = TRUE), , drop = FALSE]",
    "composition_matrix <- rowsum(relative_abundance, group = display_taxon, reorder = FALSE)",
    "if (others_label %in% rownames(composition_matrix)) composition_matrix <- composition_matrix[intersect(c(setdiff(retained_taxa, others_label), others_label), rownames(composition_matrix)), , drop = FALSE]",
    "composition <- data.frame(SampleID = rep(colnames(composition_matrix), each = nrow(composition_matrix)), Taxon = rep(rownames(composition_matrix), times = ncol(composition_matrix)), RelativeAbundance = as.vector(composition_matrix), stringsAsFactors = FALSE)",
    "taxonomic_mapping <- data.frame(Feature = colnames(counts), Taxon = taxon, stringsAsFactors = FALSE)",
    "# ---- Grouping and summaries used by every plot ----",
    "metadata <- as.data.frame(bundle$metadata, check.names = FALSE)",
    "if (!'SampleID' %in% names(metadata)) metadata$SampleID <- rownames(metadata)",
    sprintf("group_variables <- intersect(c(%s), names(metadata))", paste(quote_text(group_variables), collapse = ", ")),
    "if (!length(group_variables)) { metadata$.DAVA_Group <- 'All samples' } else { metadata$.DAVA_Group <- interaction(metadata[, group_variables, drop = FALSE], sep = ' / ', drop = TRUE) }",
    "composition <- merge(composition, metadata, by = 'SampleID', all.x = TRUE, sort = FALSE)",
    "composition$.DAVA_Group <- droplevels(factor(composition$.DAVA_Group))",
    "top_taxa <- names(sort(tapply(composition$RelativeAbundance, composition$Taxon, mean, na.rm = TRUE), decreasing = TRUE))",
    "if (others_label %in% top_taxa) top_taxa <- c(setdiff(top_taxa, others_label), others_label)",
    "display <- composition[composition$Taxon %in% top_taxa, , drop = FALSE]",
    "display$Taxon <- factor(display$Taxon, levels = top_taxa)",
    if (identical(summary_method, "median")) {
      "group_summary <- stats::aggregate(RelativeAbundance ~ .DAVA_Group + Taxon, display, stats::median)"
    } else {
      "group_summary <- stats::aggregate(RelativeAbundance ~ .DAVA_Group + Taxon, display, mean)"
    },
    "grouped_values <- split(display, list(display$.DAVA_Group, display$Taxon), drop = TRUE)",
    "grouped_intervals <- lapply(grouped_values, function(grouped_table) {",
    "  value <- grouped_table$RelativeAbundance; value <- value[is.finite(value)]",
    "  keys <- data.frame(.DAVA_Group = as.character(grouped_table$.DAVA_Group[[1]]), Taxon = as.character(grouped_table$Taxon[[1]]), stringsAsFactors = FALSE)",
    "  if (!length(value)) return(cbind(keys, Centre = NA_real_, Lower = NA_real_, Upper = NA_real_))",
    if (identical(summary_method, "median")) {
      "  interval <- stats::quantile(value, c(0.25, 0.75), na.rm = TRUE, names = FALSE); cbind(keys, Centre = stats::median(value), Lower = interval[[1]], Upper = interval[[2]])"
    } else {
      "  centre <- mean(value); standard_error <- if (length(value) > 1L) stats::sd(value) / sqrt(length(value)) else 0; cbind(keys, Centre = centre, Lower = max(0, centre - standard_error), Upper = centre + standard_error)"
    },
    "})",
    "grouped_intervals <- do.call(rbind, grouped_intervals); rownames(grouped_intervals) <- NULL",
    "grouped_intervals$Taxon <- factor(grouped_intervals$Taxon, levels = top_taxa)",
    "grouped_intervals$.DAVA_Group <- factor(grouped_intervals$.DAVA_Group, levels = levels(factor(display$.DAVA_Group)))",
    sprintf("selected_plots <- c(%s)", paste(quote_text(plot_types), collapse = ", ")),
    "plots <- list()",
    "if ('stacked_bar' %in% selected_plots) plots$stacked_bar <- ggplot(group_summary, aes(.DAVA_Group, RelativeAbundance, fill = Taxon)) + geom_col(position = 'fill', width = 0.78) + scale_y_continuous(labels = scales::percent) + labs(title = paste(taxonomic_rank, 'composition'), x = 'Group', y = 'Mean relative abundance', fill = taxonomic_rank) + theme_classic(base_size = 12)",
    "if ('grouped_bar' %in% selected_plots) { dodge <- position_dodge(width = 0.78); plots$grouped_bar <- ggplot(grouped_intervals, aes(Taxon, Centre * 100, fill = .DAVA_Group)) + geom_col(position = dodge, width = 0.72) + geom_errorbar(aes(ymin = Lower * 100, ymax = Upper * 100), position = dodge, width = 0.22, linewidth = 0.45) + labs(title = paste(taxonomic_rank, 'abundance by group'), x = NULL, y = 'Mean relative abundance (%)', fill = 'Group') + theme_classic(base_size = 12) + theme(axis.text.x = element_text(angle = 45, hjust = 1)) }",
    "if ('composition_heatmap' %in% selected_plots) { heatmap_data <- display[order(display$.DAVA_Group, match(display$SampleID, unique(display$SampleID))), , drop = FALSE]; heatmap_data$SampleID <- factor(heatmap_data$SampleID, levels = unique(heatmap_data$SampleID)); heatmap_data$Taxon <- factor(heatmap_data$Taxon, levels = rev(top_taxa)); heatmap_data$AbundancePercent <- pmax(heatmap_data$RelativeAbundance * 100, 0.01); heatmap_limits <- range(heatmap_data$AbundancePercent, finite = TRUE); heatmap_limits[[1]] <- max(0.01, heatmap_limits[[1]]); if (heatmap_limits[[2]] <= heatmap_limits[[1]]) heatmap_limits[[2]] <- heatmap_limits[[1]] * 10; heatmap_breaks <- 10 ^ seq(floor(log10(heatmap_limits[[1]])), ceiling(log10(heatmap_limits[[2]]))); plots$composition_heatmap <- ggplot(heatmap_data, aes(SampleID, Taxon, fill = AbundancePercent)) + geom_tile() + facet_grid(cols = vars(.DAVA_Group), scales = 'free_x', space = 'free_x') + scale_fill_gradientn(colours = c('#313695', '#74ADD1', '#FFFFBF', '#FDAE61', '#A50026'), trans = 'log10', limits = heatmap_limits, breaks = heatmap_breaks, oob = scales::squish) + labs(title = paste(taxonomic_rank, 'composition heatmap'), x = 'Sample', y = NULL, fill = '% Relative\\nabundance') + theme_minimal(base_size = 11) + theme(panel.grid = element_blank(), axis.text.x = element_blank(), axis.ticks.x = element_blank(), strip.text = element_text(size = 11), strip.background = element_rect(fill = '#E8E8E8', colour = NA), panel.spacing.x = grid::unit(2, 'mm')) }",
    "if ('abundance_boxplot' %in% selected_plots) { box_dodge <- position_dodge2(width = 0.8, preserve = 'single'); plots$abundance_boxplot <- ggplot(display, aes(Taxon, RelativeAbundance * 100, fill = .DAVA_Group, colour = .DAVA_Group)) + geom_boxplot(position = box_dodge, width = 0.68, outlier.shape = NA, alpha = 0.92, linewidth = 0.45) + geom_point(position = position_jitterdodge(jitter.width = 0.12, dodge.width = 0.8), size = 1.5, alpha = 0.78) + labs(title = paste(taxonomic_rank, 'relative abundance distribution'), x = NULL, y = 'Relative abundance (%)', fill = 'Group', colour = 'Group') + theme_minimal(base_size = 12) + theme(panel.grid.minor = element_blank(), axis.text.x = element_text(angle = 45, hjust = 1), legend.position = 'right') }",
    "if ('bubble' %in% selected_plots) plots$bubble <- ggplot(group_summary, aes(.DAVA_Group, Taxon, size = RelativeAbundance, colour = RelativeAbundance)) + geom_point(alpha = 0.82) + scale_colour_gradient(low = '#9CD7D3', high = '#B33A3A') + labs(title = paste(taxonomic_rank, 'composition bubble plot'), x = NULL, y = NULL, size = 'Relative\\nabundance', colour = 'Relative\\nabundance') + theme_classic(base_size = 12)",
    "if ('sunburst' %in% selected_plots) plots$sunburst <- ggplot(group_summary, aes(x = .DAVA_Group, y = RelativeAbundance, fill = Taxon)) + geom_col(width = 1, colour = 'white', linewidth = 0.15) + coord_polar(theta = 'y') + labs(title = paste(taxonomic_rank, 'sunburst composition'), x = NULL, y = NULL, fill = taxonomic_rank) + theme_void(base_size = 12)",
    "if ('sankey' %in% selected_plots && requireNamespace('ggalluvial', quietly = TRUE)) plots$sankey <- ggplot(group_summary, aes(axis1 = .DAVA_Group, axis2 = Taxon, y = RelativeAbundance)) + ggalluvial::geom_alluvium(aes(fill = Taxon), width = 0.16, alpha = 0.75) + ggalluvial::geom_stratum(width = 0.16, fill = '#F4F5F5', colour = '#5F676C') + ggalluvial::stat_stratum(geom = 'text', aes(label = after_stat(stratum)), size = 3) + scale_x_discrete(limits = c('Group', taxonomic_rank), expand = c(0.08, 0.08)) + labs(title = paste('Group-to-', taxonomic_rank, 'composition', sep = ''), y = 'Mean relative abundance', x = NULL) + theme_classic(base_size = 12) + theme(legend.position = 'none')",
    "if ('ternary' %in% selected_plots && length(unique(group_summary$.DAVA_Group)) == 3L) { wide <- reshape(group_summary, idvar = 'Taxon', timevar = '.DAVA_Group', direction = 'wide'); values <- as.matrix(wide[, -1, drop = FALSE]); values <- values / rowSums(values); ternary <- data.frame(Taxon = wide$Taxon, X = values[, 2] + 0.5 * values[, 3], Y = sqrt(3) / 2 * values[, 3], stringsAsFactors = FALSE); plots$ternary <- ggplot(ternary, aes(X, Y, label = Taxon, colour = Taxon)) + geom_polygon(data = data.frame(X = c(0, 1, 0.5), Y = c(0, 0, sqrt(3) / 2)), aes(X, Y), inherit.aes = FALSE, fill = NA, colour = '#31373B') + geom_point(size = 3) + geom_text(nudge_y = 0.025, size = 3, check_overlap = TRUE) + coord_equal() + labs(title = paste(taxonomic_rank, 'ternary composition'), x = NULL, y = NULL) + theme_void(base_size = 12) + theme(legend.position = 'none') }",
    "tables <- list(composition = composition, taxonomic_mapping = taxonomic_mapping, taxonomic_aggregation_summary = aggregation_summary)",
    "result <- list(tables = tables, plots = plots)",
    "result"
  )
  paste(microbiome_code_document_preprocessing(spec),
    paste(lines, collapse = "\n"), sep = "\n\n")
}

microbiome_method_code_document_legacy <- function(method_id, spec = list(), plot_settings = list()) {
  if (identical(method_id, "alpha_core")) return(microbiome_alpha_core_code_document(spec, plot_settings))
  if (method_id %in% c("richness_indices", "diversity_indices", "evenness_indices", "alpha_group_comparison", "alpha_multifactor_model", "alpha_repeated_mixed", "alpha_environment_regression", "alpha_rarefaction")) return(microbiome_alpha_method_code_document(method_id, spec))
  if (method_id %in% c("pcoa", "nmds", "distance_matrix", "pca", "beta_cluster_heatmap", "permanova_interaction", "permanova_restricted", "permdisp", "anosim", "mrpp", "between_group_distance", "permanova_permdisp")) return(microbiome_beta_method_code_document(method_id, spec))
  if (identical(method_id, "phylogenetic_tree")) return(microbiome_phylogenetic_tree_code_document(spec, plot_settings))
  if (identical(method_id, "taxonomic_composition")) return(microbiome_taxonomic_composition_code_document(spec))
  if (method_id %in% c("top_taxa", "taxonomic_aggregation", "taxonomic_heatmap", "taxonomic_bubble")) {
    plot_by_method <- c(
      top_taxa = "stacked_bar", taxonomic_aggregation = "grouped_bar",
      taxonomic_heatmap = "composition_heatmap", taxonomic_bubble = "bubble"
    )
    spec$plot_types <- unname(plot_by_method[[method_id]])
    return(paste0("# Method-specific document: ", method_id, "\n",
      microbiome_taxonomic_composition_code_document(spec)))
  }
  if (method_id %in% c("dominant_rare_taxa", "abundance_occupancy")) {
    rank <- dQuote(as.character(spec$taxonomic_rank %||% "Genus"), q = FALSE)
    abundance <- format(as.numeric(spec$core_abundance %||% 0.001), scientific = FALSE)
    prevalence <- format(as.numeric(spec$core_prevalence %||% 0.5), scientific = FALSE)
    analysis <- c(
      "library(ggplot2)", "counts <- as.matrix(analysis_bundle$counts)",
      "relative <- sweep(counts, 1, rowSums(counts), '/')",
      paste0("taxonomic_rank <- ", rank),
      "taxonomy <- as.data.frame(analysis_bundle$taxonomy, check.names = FALSE)",
      "taxonomy_ids <- if ('Feature' %in% names(taxonomy)) as.character(taxonomy$Feature) else rownames(taxonomy)",
      "taxon <- if (identical(taxonomic_rank, 'feature')) colnames(relative) else as.character(taxonomy[[taxonomic_rank]][match(colnames(relative), taxonomy_ids)])",
      "taxon[is.na(taxon) | !nzchar(taxon)] <- paste0('Unclassified_', taxonomic_rank)",
      paste0("abundance_threshold <- ", abundance),
      paste0("prevalence_threshold <- ", prevalence),
      "feature_table <- data.frame(Feature = colnames(relative), Taxon = taxon, MeanRelativeAbundance = colMeans(relative), Prevalence = colMeans(relative >= abundance_threshold), stringsAsFactors = FALSE)",
      if (identical(method_id, "dominant_rare_taxa")) {
        "feature_table$Class <- ifelse(feature_table$MeanRelativeAbundance >= abundance_threshold & feature_table$Prevalence >= prevalence_threshold, 'Dominant', ifelse(feature_table$MeanRelativeAbundance < abundance_threshold & feature_table$Prevalence < prevalence_threshold, 'Rare', 'Intermediate'))"
      } else {
        "feature_table$OccupancyClass <- ifelse(feature_table$Prevalence >= prevalence_threshold, 'Widespread', 'Restricted')"
      },
      "plot <- ggplot2::ggplot(feature_table, ggplot2::aes(Prevalence, MeanRelativeAbundance, colour = .data[[if ('Class' %in% names(feature_table)) 'Class' else 'OccupancyClass']])) + ggplot2::geom_point(alpha = 0.8) + ggplot2::scale_y_log10() + ggplot2::theme_classic()",
      "tables <- list(feature_classification = feature_table)",
      "plots <- list(abundance_occupancy = plot)", "print(plot)",
      "result <- list(tables = tables, plots = plots)", "result"
    )
    return(paste(microbiome_code_document_preprocessing(spec),
      microbiome_parseable_code(analysis), sep = "\n\n"))
  }
  if (method_id %in% c("shared_unique_features", "taxonomy_tree_abundance")) {
    if (identical(method_id, "shared_unique_features")) {
      return(paste(
        microbiome_code_document_preprocessing(spec),
        "# Method-specific document: shared_unique_features",
        microbiome_analysis_code("venn_upset", spec), sep = "\n\n"))
    }
    tree_spec <- spec
    tree_spec$plot_types <- "phylo_tree_rings"
    return(paste0("# Method-specific document: taxonomy_tree_abundance\n",
      microbiome_phylogenetic_tree_code_document(tree_spec, plot_settings)))
  }
  if (method_id %in% c("robust_aitchison_pca", "community_trajectory")) {
    return(microbiome_beta_method_code_document(method_id, spec))
  }
  if (identical(method_id, "differential_indicator_species")) {
    return(paste(
      microbiome_code_document_preprocessing(spec),
      "# Method-specific document: differential_indicator_species",
      microbiome_analysis_code("indicator_taxa", spec), sep = "\n\n"))
  }

  category <- ""
  if (exists("MICROBIOME_METHOD_REGISTRY", inherits = TRUE)) {
    row <- MICROBIOME_METHOD_REGISTRY[MICROBIOME_METHOD_REGISTRY$id == method_id, , drop = FALSE]
    if (nrow(row)) category <- as.character(row$secondary_category[[1]])
  }
  method_code <- if (method_id %in% c("species_env_spearman", "mantel_correlation", "maaslin2")) {
    microbiome_species_environment_code(method_id, spec)
  } else switch(category,
    preprocess = microbiome_preprocess_code(method_id, spec),
    environment_spatial = microbiome_environment_code(method_id, spec),
    differential = microbiome_differential_code(method_id, spec),
    network = {
      legacy_measure <- c(spearman_network = "spearman", pearson_network = "pearson", sparcc = "sparcc", spieceasi = "spieceasi", spring_network = "spring")
      if (method_id %in% names(legacy_measure)) spec$network_measure <- unname(legacy_measure[[method_id]])
      microbiome_network_code_document(method_id, spec)
    },
    "function" = microbiome_extended_function_code(method_id),
    assembly_source = if (identical(method_id, "ncm")) {
      microbiome_ncm_code(spec)
    } else if (identical(method_id, "bnti_rcbray")) {
      microbiome_bnti_rcbray_code(spec)
    } else microbiome_assembly_code(method_id, spec),
    longitudinal_stability = microbiome_longitudinal_code(method_id, spec),
    integration_ml = if (identical(method_id, "procrustes_cross_domain")) {
      microbiome_procrustes_code(spec)
    } else microbiome_ml_code(method_id, spec),
    composition = microbiome_analysis_code(method_id, spec),
    alpha = microbiome_analysis_code(method_id, spec),
    beta = microbiome_analysis_code(method_id, spec),
    microbiome_analysis_code(method_id, spec)
  )
  paste(microbiome_code_document_preprocessing(spec), method_code, sep = "\n\n")
}

# Every code document uses the same preprocessing and method entry point as
# the main analysis.  This keeps selected result tables and plots in sync.
microbiome_method_code_document <- function(method_id, spec = list(),
                                             plot_settings = list()) {
  code <- microbiome_method_code_document_legacy(method_id, spec, plot_settings)
  internal <- dava_code_internal_call_names(code)
  if (length(internal)) {
    local_implementations <- dava_code_function_sources(code, mode = "closure")
    if (length(local_implementations)) {
      code <- paste(c(
        "# ---- Method-specific local helpers ----",
        unname(local_implementations), code
      ), collapse = "\n\n")
    }
  }
  dava_code_assert_standalone(code, method_id)
  code
}

microbiome_analysis_code <- function(method_id, spec = list()) {
  group <- spec$group %||% "Treatment"
  distance <- spec$distance %||% "bray"
  alpha_indices <- microbiome_alpha_selected_indices(spec)
  alpha_groups <- spec$alpha_group_variables %||% character()
  alpha_method <- spec$alpha_stat_method %||% "descriptive"
  alpha_lines <- c(
    "library(vegan)", "counts <- as.matrix(analysis_bundle$counts)",
    "alpha_table <- microbiome_alpha_table(analysis_bundle)",
    sprintf("selected_indices <- c(%s)", paste(dQuote(alpha_indices, q = FALSE), collapse = ", ")),
    sprintf("group_variables <- c(%s)", paste(dQuote(alpha_groups, q = FALSE), collapse = ", ")),
    sprintf("statistical_method <- %s", dQuote(alpha_method, q = FALSE)),
    "alpha_results <- alpha_table[, c('SampleID', selected_indices, group_variables), drop = FALSE]"
  )
  if (!identical(alpha_method, "descriptive") && length(alpha_groups)) {
    alpha_lines <- c(alpha_lines,
      "statistical_results <- lapply(selected_indices, function(index) {",
      "  model_formula <- reformulate(group_variables, response = index)",
      switch(alpha_method,
        t_test = "  t.test(model_formula, data = alpha_table, var.equal = TRUE)",
        welch_t = "  t.test(model_formula, data = alpha_table, var.equal = FALSE)",
        wilcoxon = "  wilcox.test(model_formula, data = alpha_table, exact = FALSE)",
        welch_anova = "  oneway.test(model_formula, data = alpha_table, var.equal = FALSE)",
        kruskal = "  kruskal.test(model_formula, data = alpha_table)",
        lmm = sprintf("  lme4::lmer(as.formula(paste(index, '~', paste(group_variables, collapse = ' + '), '+ (1 | %s)')), data = alpha_table)",
          spec$alpha_random_effect %||% "Block"),
        "  lm(model_formula, data = alpha_table)"),
      "})", "names(statistical_results) <- selected_indices")
  }
  composition_test_method <- spec$composition_abundance_test %||% "kruskal_dunn"
  composition_mixed_lines <- character()
  if (composition_test_method %in% c("lmer", "glmmTMB")) {
    quote_name <- function(value) paste0("`", gsub("`", "", value, fixed = TRUE), "`")
    random_term <- switch(spec$effect_structure %||% "random_intercept",
      repeated = paste0("(1 | ", quote_name(spec$random_effect %||% "Subject"), ")"),
      nested = paste0("(1 | ", quote_name(spec$random_outer %||% "Outer"), "/",
        quote_name(spec$random_inner %||% "Inner"), ")"),
      random_slope = paste0("(1 + ", quote_name(spec$random_slope %||% "Treatment"), " | ",
        quote_name(spec$random_effect %||% "Block"), ")"),
      paste0("(1 | ", quote_name(spec$random_effect %||% "Block"), ")"))
    group_variables <- utils::head(spec$group_variables %||% spec$group %||% "Treatment", 3L)
    adjustment <- spec$p_adjust_method %||% spec$fdr_method %||% "BH"
    family_id <- spec$glmm_family %||% "beta"
    composition_mixed_lines <- c(
      "",
      "# Fit one mixed-effects model for every retained taxon",
      "library(emmeans)",
      if (identical(composition_test_method, "lmer")) "library(lme4)" else "library(glmmTMB)",
      "composition_long <- data.frame(",
      "  SampleID = rep(colnames(composition), each = nrow(composition)),",
      "  Taxon = rep(rownames(composition), times = ncol(composition)),",
      "  RelativeAbundance = as.vector(composition), check.names = FALSE)",
      "metadata_for_model <- bundle$metadata",
      "if (!'SampleID' %in% names(metadata_for_model)) metadata_for_model$SampleID <- rownames(metadata_for_model)",
      "composition_long <- merge(composition_long, metadata_for_model, by = 'SampleID', all.x = TRUE, sort = FALSE)",
      sprintf("group_variables <- c(%s)", paste(dQuote(group_variables, q = FALSE), collapse = ", ")),
      "composition_long$.DAVA_Group <- interaction(composition_long[, group_variables, drop = FALSE], sep = ' / ', drop = TRUE)",
      sprintf("random_term <- %s", dQuote(random_term, q = FALSE)),
      sprintf("p_adjust_method <- %s", dQuote(adjustment, q = FALSE)),
      sprintf("taxa_to_test <- setdiff(unique(composition_long$Taxon), %s)",
        dQuote(spec$abundance_others_label %||% "Others", q = FALSE)),
      "mixed_models <- lapply(taxa_to_test, function(taxon) {",
      "  model_data <- subset(composition_long, Taxon == taxon)",
      "  model_data$.DAVA_Group <- droplevels(factor(model_data$.DAVA_Group))",
      "  model_data$.DAVA_Response <- model_data$RelativeAbundance",
      if (identical(composition_test_method, "glmmTMB") && identical(family_id, "beta")) {
        "  model_data$.DAVA_Response <- (model_data$.DAVA_Response * (nrow(model_data) - 1) + 0.5) / nrow(model_data)"
      } else if (identical(composition_test_method, "glmmTMB") && identical(family_id, "Gamma")) {
        "  model_data$.DAVA_Response[model_data$.DAVA_Response <= 0] <- min(model_data$.DAVA_Response[model_data$.DAVA_Response > 0]) / 2"
      } else character(),
      "  full_formula <- as.formula(paste('.DAVA_Response ~ .DAVA_Group +', random_term))",
      "  null_formula <- as.formula(paste('.DAVA_Response ~ 1 +', random_term))",
      if (identical(composition_test_method, "lmer")) {
        "  full_model <- lme4::lmer(full_formula, data = model_data, REML = FALSE)"
      } else {
        sprintf("  family_object <- %s", switch(family_id,
          beta = "glmmTMB::beta_family(link = 'logit')",
          Gamma = "stats::Gamma(link = 'log')",
          "stats::gaussian(link = 'identity')"))
      },
      if (identical(composition_test_method, "lmer")) {
        "  null_model <- lme4::lmer(null_formula, data = model_data, REML = FALSE)"
      } else {
        "  full_model <- glmmTMB::glmmTMB(full_formula, data = model_data, family = family_object)"
      },
      if (!identical(composition_test_method, "lmer")) {
        "  null_model <- glmmTMB::glmmTMB(null_formula, data = model_data, family = family_object)"
      } else character(),
      "  omnibus <- anova(null_model, full_model)",
      "  marginal_means <- emmeans::emmeans(full_model, ~ .DAVA_Group, type = 'response')",
      "  pairwise <- summary(emmeans::contrast(marginal_means, 'pairwise', adjust = 'none'), infer = c(TRUE, TRUE))",
      "  pairwise$adjusted_p <- if (p_adjust_method == 'none') pairwise$p.value else p.adjust(pairwise$p.value, method = p_adjust_method)",
      "  list(model = full_model, omnibus = omnibus, marginal_means = marginal_means, pairwise = pairwise)",
      "})",
      "names(mixed_models) <- taxa_to_test"
    )
  }
  lines <- switch(method_id,
    taxonomic_composition = c(
      "# Aggregate features to the selected taxonomy level (tax_glom equivalent)",
      "counts <- as.matrix(bundle$counts)",
      "taxonomy <- bundle$taxonomy",
      sprintf("taxonomic_rank <- %s", dQuote(spec$taxonomic_rank %||% "Genus", q = FALSE)),
      "taxonomy_ids <- if ('Feature' %in% names(taxonomy)) taxonomy$Feature else rownames(taxonomy)",
      "taxon <- if (taxonomic_rank == 'feature') colnames(counts) else taxonomy[[taxonomic_rank]][match(colnames(counts), taxonomy_ids)]",
      "taxon[is.na(taxon) | !nzchar(trimws(taxon))] <- paste0('Unclassified_', taxonomic_rank)",
      "tax_glom_counts <- rowsum(t(counts), group = taxon, reorder = FALSE)",
      "relative_abundance <- sweep(tax_glom_counts, 2, colSums(tax_glom_counts), '/')",
      sprintf("merge_threshold <- %s / 100",
        format(as.numeric(spec$abundance_merge_threshold_percent %||% 0.5))),
      sprintf("maximum_taxa <- %dL", as.integer(spec$abundance_max_taxa %||% 20L)),
      sprintf("others_label <- %s", dQuote(spec$abundance_others_label %||% "Others", q = FALSE)),
      "mean_abundance <- rowMeans(relative_abundance, na.rm = TRUE)",
      "retained <- head(names(sort(mean_abundance[mean_abundance >= merge_threshold], decreasing = TRUE)), maximum_taxa)",
      "merged_taxa <- ifelse(rownames(relative_abundance) %in% retained, rownames(relative_abundance), others_label)",
      "composition <- rowsum(relative_abundance, group = merged_taxa, reorder = FALSE)",
      composition_mixed_lines),
    core_microbiome = c("relative <- sweep(as.matrix(bundle$counts), 1, rowSums(bundle$counts), '/')", "core <- colMeans(relative > 0.001) >= 0.5"),
    indicator_taxa = c("relative <- sweep(as.matrix(bundle$counts), 1, rowSums(bundle$counts), '/')", "group <- factor(bundle$metadata$Treatment)", "fit <- indicspecies::multipatt(relative, group, func = 'IndVal.g', control = permute::how(nperm = 999))",
      sprintf("indicator_results <- subset(as.data.frame(fit$sign), stat >= %s & p.value < %s)",
        format(as.numeric(spec$indicator_min_indval %||% 0.7)),
        format(as.numeric(spec$indicator_alpha %||% 0.05)))),
    venn_upset = c(
      "library(vegan)",
      sprintf("presence_threshold <- %s / 100",
        format(as.numeric(spec$set_presence_threshold_percent %||% 0))),
      "relative <- sweep(as.matrix(bundle$counts), 1, rowSums(bundle$counts), '/')",
      "presence <- relative > presence_threshold",
      sprintf("group <- interaction(bundle$metadata[, c(%s), drop = FALSE], drop = TRUE)",
        paste(dQuote(utils::head(spec$group_variables %||% spec$group %||% "Treatment", 3L), q = FALSE),
          collapse = ", ")),
      "feature_sets <- split(seq_len(nrow(presence)), group)",
      "feature_sets <- lapply(feature_sets, function(index) colnames(presence)[colSums(presence[index, , drop = FALSE]) > 0])",
      "jaccard <- vegan::vegdist(presence * 1, method = 'jaccard', binary = TRUE)",
      sprintf("set_test <- vegan::adonis2(jaccard ~ group, permutations = %dL)",
        as.integer(spec$set_permutations %||% 999L))
    ),
    alpha_core = alpha_lines,
    richness_indices = c("library(vegan)", "counts <- as.matrix(bundle$counts)", "richness <- suppressWarnings(vegan::estimateR(counts))", "observed <- vegan::specnumber(counts)", "fisher_alpha <- vegan::fisher.alpha(counts)"),
    diversity_indices = c("library(vegan)", "counts <- as.matrix(bundle$counts)", "shannon <- vegan::diversity(counts, 'shannon')", "simpson <- vegan::diversity(counts, 'simpson')", "inverse_simpson <- vegan::diversity(counts, 'invsimpson')"),
    evenness_indices = c("library(vegan)", "counts <- as.matrix(bundle$counts)", "observed <- vegan::specnumber(counts)", "pielou <- vegan::diversity(counts, 'shannon') / log(observed)"),
    alpha_group_comparison = c("alpha <- microbiome_alpha_table(bundle)", sprintf("group <- factor(alpha[[%s]])", dQuote(group, q = FALSE)), "omnibus <- kruskal.test(alpha$Shannon ~ group)", "posthoc <- pairwise.wilcox.test(alpha$Shannon, group, p.adjust.method = 'BH')"),
    alpha_multifactor_model = c("alpha <- microbiome_alpha_table(bundle)", sprintf("fit <- lm(Shannon ~ %s, data = alpha)", group), "anova(fit)"),
    alpha_repeated_mixed = c("library(lme4)", "alpha <- microbiome_alpha_table(bundle)", sprintf("fit <- lmer(Shannon ~ %s + (1 | Subject), data = alpha)", group)),
    alpha_environment_regression = c("alpha <- microbiome_alpha_table(bundle)", "analysis <- cbind(alpha, bundle$environment)", "fit <- lm(Shannon ~ ., data = analysis[, -1, drop = FALSE])"),
    alpha_rarefaction = c("library(vegan)", "counts <- as.matrix(bundle$counts)", "vegan::rarecurve(counts, step = 100, sample = min(rowSums(counts)))"),
    phylogenetic_tree_build = if (identical(
        spec$phylo_build_source %||% "representative_sequences",
        "representative_sequences")) {
      c(
        "library(DECIPHER)",
        "library(Biostrings)",
        "library(phangorn)",
        "library(ape)",
        "sequence_text <- vapply(bundle$representative_sequences, paste, collapse = '', FUN.VALUE = character(1))",
        "sequences <- Biostrings::DNAStringSet(sequence_text)",
        if (identical(spec$phylo_build_algorithm %||% "ml", "ml")) {
          sprintf(paste0(
            "if (length(sequences) > %dL) stop(",
            "'ML tip limit exceeded before sequence alignment.')"),
            as.integer(spec$phylo_build_max_ml_tips %||% 2000L))
        },
        sprintf("available_processors <- max(1L, parallel::detectCores(logical = TRUE)); processors <- min(%dL, available_processors)",
          as.integer(spec$phylo_build_processors %||%
            suppressWarnings(parallel::detectCores(logical = TRUE)) %||% 1L)),
        sprintf("fast_alignment <- %s",
          if (identical(spec$phylo_build_alignment_preset %||% "auto",
              "fast")) {
            "TRUE"
          } else if (identical(
              spec$phylo_build_alignment_preset %||% "auto", "auto")) {
            sprintf("length(sequences) > %dL", as.integer(
              spec$phylo_build_large_dataset_threshold %||% 2000L))
          } else {
            "FALSE"
          }),
        sprintf(paste0(
          "alignment <- DECIPHER::AlignSeqs(sequences, iterations = ",
          "if (fast_alignment) 0L else %dL, refinements = ",
          "if (fast_alignment) 0L else %dL, processors = processors, ",
          "verbose = FALSE)"),
          as.integer(spec$phylo_build_alignment_iterations %||% 2L),
          as.integer(spec$phylo_build_alignment_refinements %||% 1L)),
        "phangorn_alignment <- phangorn::phyDat(as.matrix(alignment), type = 'DNA')",
        if (identical(spec$phylo_build_distance_engine %||%
            "decipher_jc", "decipher_jc")) {
          paste0("distance <- DECIPHER::DistanceMatrix(alignment, ",
            "type = 'dist', correction = 'Jukes-Cantor', ",
            "processors = processors, verbose = FALSE)")
        } else {
          "distance <- phangorn::dist.ml(phangorn_alignment)"
        },
        "if (any(!is.finite(distance))) distance <- phangorn::dist.ml(phangorn_alignment)",
        "tree_nj <- phangorn::NJ(distance)",
        "tree_nj <- phangorn::nnls.tree(distance, tree_nj, trace = 0)",
        if (identical(spec$phylo_build_algorithm %||% "ml", "ml")) c(
          "fit <- phangorn::pml(tree_nj, data = phangorn_alignment)",
          sprintf("fit <- update(fit, k = %dL, model = 'GTR')",
            as.integer(spec$phylo_build_gamma_categories %||% 4L)),
          sprintf(paste0("fit <- phangorn::optim.pml(fit, model = 'GTR', ",
            "optNni = %s, optGamma = %s)"),
            if (isTRUE(spec$phylo_build_optimize_nni %||% TRUE)) "TRUE" else "FALSE",
            if (isTRUE(spec$phylo_build_optimize_gamma %||% TRUE)) "TRUE" else "FALSE"),
          "tree <- fit$tree"
        ) else {
          "tree <- tree_nj"
        },
        "tree <- phangorn::midpoint(tree)",
        "ape::write.tree(tree, file = 'asv_phylogenetic_tree.newick')"
      )
    } else {
      c(
        "library(ape)",
        "library(phangorn)",
        "tree <- bundle$phylogeny",
        if (identical(spec$phylo_build_rooting %||% "midpoint", "midpoint")) {
          "tree <- phangorn::midpoint(tree)"
        } else {
          "stopifnot(ape::is.rooted(tree))"
        },
        "ape::write.tree(tree, file = 'rooted_phylogenetic_tree.newick')"
      )
    },
    faith_pd = c(
      "stopifnot(inherits(bundle$phylogeny, 'phylo'))",
      "faith <- picante::pd(as.matrix(bundle$counts), bundle$phylogeny, include.root = TRUE)",
      sprintf("group_name <- %s", dQuote(group, q = FALSE)),
      if (!identical(spec$phylogenetic_test_method %||% "kruskal", "none"))
        "group_test <- kruskal.test(faith$PD ~ factor(bundle$metadata[[group_name]]))" else
        "group_test <- NULL",
      if (!identical(spec$phylogenetic_test_method %||% "kruskal", "none"))
        sprintf("posthoc <- pairwise.wilcox.test(faith$PD, factor(bundle$metadata[[group_name]]), p.adjust.method = %s)",
          dQuote(spec$p_adjust_method %||% "BH", q = FALSE)) else
        "posthoc <- NULL"),
    mpd_mntd_nri_nti = c(
      "library(picante)",
      "library(ape)",
      "counts <- as.matrix(bundle$counts)",
      "tree <- ape::keep.tip(bundle$phylogeny, intersect(colnames(counts), bundle$phylogeny$tip.label))",
      "counts <- counts[, tree$tip.label, drop = FALSE]",
      "phylogenetic_distance <- ape::cophenetic.phylo(tree)",
      sprintf("abundance_weighted <- %s",
        if (isTRUE(spec$phylo_abundance_weighted %||% TRUE)) "TRUE" else "FALSE"),
      sprintf("runs <- %dL", as.integer(spec$phylo_permutations %||% 999L)),
      sprintf("pd <- picante::pd(counts, tree, include.root = %s)",
        if (isTRUE(spec$phylo_include_root %||% FALSE)) "TRUE" else "FALSE"),
      "mpd <- picante::mpd(counts, phylogenetic_distance, abundance.weighted = abundance_weighted)",
      "mntd <- picante::mntd(counts, phylogenetic_distance, abundance.weighted = abundance_weighted)",
      sprintf("ses_pd <- picante::ses.pd(counts, tree, null.model = '%s', runs = runs)",
        spec$phylo_null_model %||% "taxa.labels"),
      sprintf("ses_mpd <- picante::ses.mpd(counts, phylogenetic_distance, null.model = '%s', runs = runs, abundance.weighted = abundance_weighted)",
        spec$phylo_null_model %||% "taxa.labels"),
      sprintf("ses_mntd <- picante::ses.mntd(counts, phylogenetic_distance, null.model = '%s', runs = runs, abundance.weighted = abundance_weighted)",
        spec$phylo_null_model %||% "taxa.labels"),
      "beta_mpd <- picante::comdist(counts, phylogenetic_distance, abundance.weighted = abundance_weighted)",
      "beta_mntd <- picante::comdistnt(counts, phylogenetic_distance, abundance.weighted = abundance_weighted)"
    ),
    phylogenetic_tree = c(
      "library(microeco)",
      "library(ggtree)",
      "library(ggtreeExtra)",
      microbiome_microeco_input_code("microtable", require_tree = TRUE),
      sprintf("phylo_view <- microeco::trans_phylo$new(microtable, group_col = '%s', group_prefix_remove = '%s', clade_coloring = %s)",
        spec$phylo_tree_group_col %||% "Phylum",
        spec$phylo_tree_group_prefix_remove %||% "p__",
        if (isTRUE(spec$phylo_tree_clade_coloring %||% TRUE)) "TRUE" else "FALSE"),
      sprintf("phylo_view$plot_tree(layout = '%s', open_angle = %s, branch_size = %s, tip_point_size = %s, show_tip_label = %s)",
        spec$phylo_tree_layout %||% "fan",
        format(as.numeric(spec$phylo_tree_open_angle %||% 30)),
        format(as.numeric(spec$phylo_tree_branch_size %||% 0.3)),
        format(as.numeric(spec$phylo_tree_tip_point_size %||% 2)),
        if (isTRUE(spec$phylo_tree_show_tip_label %||% FALSE)) "TRUE" else "FALSE"),
      "tree_plot <- phylo_view$get_plot()",
      "result <- list(plots = list(phylogenetic_tree = tree_plot))",
      "result"
    ),
    pcoa = c(sprintf("distance_method <- %s", dQuote(distance, q = FALSE)), "distance <- vegan::vegdist(bundle$counts, method = distance_method)", "ordination <- cmdscale(distance, eig = TRUE, k = 2)"),
    nmds = c(sprintf("distance_method <- %s", dQuote(distance, q = FALSE)), sprintf("seed <- %dL", as.integer(spec$seed %||% 2026L)), "set.seed(seed)", "ordination <- vegan::metaMDS(bundle$counts, distance = distance_method, k = 2, trymax = 50)"),
    distance_matrix = c(sprintf("distance_method <- %s", dQuote(distance, q = FALSE)), "distance <- microbiome_distance(bundle, distance_method)"),
    pca = c("community <- vegan::decostand(as.matrix(bundle$counts), 'hellinger')", "fit <- prcomp(community)"),
    beta_cluster_heatmap = c(sprintf("distance <- microbiome_distance(bundle, %s)", dQuote(distance, q = FALSE)), "fit <- hclust(distance, method = 'average')"),
    permanova_interaction = c(sprintf("group_name <- %s", dQuote(group, q = FALSE)), "distance <- microbiome_distance(bundle, 'bray')", "fit <- vegan::adonis2(distance ~ bundle$metadata[[group_name]], permutations = 999)"),
    permanova_restricted = c(sprintf("group_name <- %s", dQuote(group, q = FALSE)), "distance <- microbiome_distance(bundle, 'bray')", "fit <- vegan::adonis2(distance ~ bundle$metadata[[group_name]], permutations = 999)"),
    permdisp = c(sprintf("group <- factor(bundle$metadata[[%s]])", dQuote(group, q = FALSE)), "distance <- microbiome_distance(bundle, 'bray')", "fit <- vegan::permutest(vegan::betadisper(distance, group), permutations = 999)"),
    anosim = c(sprintf("group <- factor(bundle$metadata[[%s]])", dQuote(group, q = FALSE)), "fit <- vegan::anosim(microbiome_distance(bundle, 'bray'), group, permutations = 999)"),
    mrpp = c(sprintf("group <- factor(bundle$metadata[[%s]])", dQuote(group, q = FALSE)), "fit <- vegan::mrpp(microbiome_distance(bundle, 'bray'), group, permutations = 999)"),
    between_group_distance = c(sprintf("group <- factor(bundle$metadata[[%s]])", dQuote(group, q = FALSE)), "distance <- as.matrix(microbiome_distance(bundle, 'bray'))"),
    permanova_permdisp = c(sprintf("group_name <- %s", dQuote(group, q = FALSE)), sprintf("permutations <- %dL", as.integer(spec$permutations %||% 999L)), "distance <- vegan::vegdist(bundle$counts, method = 'bray')", "group <- factor(bundle$metadata[[group_name]])", "permanova <- vegan::adonis2(distance ~ group, permutations = permutations)", "dispersion <- vegan::betadisper(distance, group)", "permdisp <- vegan::permutest(dispersion, permutations = permutations)"),
    stop("No code template:", method_id, call. = FALSE)
  )
  if (method_id %in% c("pcoa", "nmds", "pca") &&
      !identical(spec$beta_significance_test %||% "none", "none")) {
    test_method <- spec$beta_significance_test %||% "none"
    group_variables <- as.character(spec$group_variables %||% group)
    permutations <- as.integer(spec$permutations %||% 999L)
    test_lines <- c(
      "# Community-composition significance tests for metadata groups",
      sprintf("group_variables <- c(%s)", paste(dQuote(group_variables, q = FALSE), collapse = ", ")),
      sprintf("distance_method <- %s", dQuote(distance, q = FALSE)),
      sprintf("permutations <- %dL", permutations),
      "distance <- microbiome_distance(bundle, distance_method)"
    )
    if (test_method %in% c("permanova", "permanova_permdisp")) test_lines <- c(test_lines,
      "permanova_formula <- reformulate(group_variables, response = 'distance')",
      "permanova <- vegan::adonis2(permanova_formula, data = bundle$metadata, permutations = permutations)")
    if (test_method %in% c("permdisp", "permanova_permdisp")) test_lines <- c(test_lines,
      "permdisp <- lapply(group_variables, function(variable) {",
      "  dispersion <- vegan::betadisper(distance, factor(bundle$metadata[[variable]]))",
      "  vegan::permutest(dispersion, permutations = permutations)",
      "})", "names(permdisp) <- group_variables")
    if (test_method == "anosim") test_lines <- c(test_lines,
      "anosim_results <- lapply(group_variables, function(variable) vegan::anosim(",
      "  distance, factor(bundle$metadata[[variable]]), permutations = permutations))",
      "names(anosim_results) <- group_variables")
    if (test_method == "mrpp") test_lines <- c(test_lines,
      "mrpp_results <- lapply(group_variables, function(variable) vegan::mrpp(",
      "  distance, factor(bundle$metadata[[variable]]), permutations = permutations))",
      "names(mrpp_results) <- group_variables")
    lines <- c(lines, test_lines)
  }
  microbiome_parseable_code(c("# bundle is a validated DAVA microbiome_bundle", lines))
}
