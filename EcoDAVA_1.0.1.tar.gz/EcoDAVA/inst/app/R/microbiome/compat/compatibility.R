microbiome_legacy_navigation_map <- function() {
  c(
    micro_alpha = "alpha_diversity", micro_beta = "beta_diversity",
    micro_composition = "exploratory_composition", micro_differential = "exploratory_composition",
    micro_phylo = "phylogenetic_diversity", micro_correlation = "community_environment",
    micro_network = "microbial_network", micro_function = "bacterial_function",
    micro_assembly = "community_assembly", micro_maaslin2 = "multivariable_association",
    micro_ancombc2 = "exploratory_composition",
    micro_multivariable_association = "multivariable_association", micro_pgls = "species_environment_response",
    micro_rda = "community_environment", micro_cca = "community_environment", micro_dbrda = "community_environment"
  )
}

microbiome_resolve_legacy_navigation <- function(value) {
  mapping <- microbiome_legacy_navigation_map()
  if (length(value) == 1L && value %in% names(mapping)) unname(mapping[value]) else value
}

microbiome_legacy_nav_target <- function(value) {
  panel_id <- microbiome_resolve_legacy_navigation(value)
  if (!panel_id %in% microbiome_panel_registry()$id) return(value)
  microbiome_panel_nav_value(panel_id)
}
microbiome_framework_self_check <- function() {
  categories <- microbiome_category_registry()
  methods <- MICROBIOME_METHOD_REGISTRY
  panels <- microbiome_panel_registry()
  errors <- character()
  if (nrow(categories) != 6L) errors <- c(errors, "Secondary navigation must be 6 scientific research analysis processes.")
  if (anyDuplicated(methods$id)) errors <- c(errors, "Method ID must be unique.")
  visible_methods <- methods[methods$navigation_visibility, , drop = FALSE]
  if (length(setdiff(visible_methods$navigation_category, categories$id))) errors <- c(errors, "Method references an unknown navigation class.")
  if (any(methods$status == "implemented" & !methods$visibility)) errors <- c(errors, "Implemented methods must have explicit visibility.")
  if (nrow(panels) != 12L) errors <- c(errors, "Analysis panels must be 12.")
  if (anyDuplicated(panels$id)) errors <- c(errors, "Tertiary panel IDs must be unique.")
  if (length(setdiff(visible_methods$navigation_panel, panels$id))) errors <- c(errors, "Method references an unknown tertiary panel.")
  list(valid = !length(errors), errors = errors, framework_version = microbiome_framework_version())
}
