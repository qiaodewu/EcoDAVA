sem_node_variable <- function(spec, node_id) {
  node <- spec$nodes[match(node_id, spec$nodes$id), , drop = FALSE]
  if (!nrow(node)) stop("Unknown node: ", node_id, call. = FALSE)
  value <- node$variable_name[[1]]
  if (!nzchar(value)) value <- node$construct_name[[1]]
  if (!nzchar(value)) value <- node$label[[1]]
  value
}

sem_graph_to_lavaan <- function(spec) {
  check <- validate_sem_model_spec(spec); if (!check$valid) stop(paste(check$errors, collapse = "; "), call. = FALSE)
  lines <- character()
  latent <- spec$nodes[spec$nodes$node_type == "latent_variable", , drop = FALSE]
  if (nrow(latent)) for (index in seq_len(nrow(latent))) {
    indicators <- latent$indicator_variables[[index]]
    if (length(indicators) < 2L) stop("Latent construct requires at least two indicators: ", latent$label[[index]], call. = FALSE)
    construct <- latent$construct_name[[index]] %||% latent$label[[index]]
    lines <- c(lines, paste(construct, "=~", paste(indicators, collapse = " + ")))
  }
  directed <- spec$edges[spec$edges$active & spec$edges$edge_type == "directed_path", , drop = FALSE]
  if (nrow(directed)) {
    targets <- unique(directed$target)
    for (target in targets) {
      selected <- directed[directed$target == target, , drop = FALSE]
      lhs <- sem_node_variable(spec, target)
      rhs <- vapply(selected$source, sem_node_variable, character(1), spec = spec)
      terms <- ifelse(nzchar(selected$parameter_name), paste0(selected$parameter_name, "*", rhs), rhs)
      lines <- c(lines, paste(lhs, "~", paste(terms, collapse = " + ")))
    }
  }
  covariance <- spec$edges[spec$edges$active & spec$edges$edge_type %in% c("covariance", "residual_covariance"), , drop = FALSE]
  if (nrow(covariance)) for (index in seq_len(nrow(covariance))) {
    lines <- c(lines, paste(sem_node_variable(spec, covariance$source[[index]]), "~~",
      sem_node_variable(spec, covariance$target[[index]])))
  }
  paste(lines, collapse = "\n")
}

sem_graph_to_path_code <- function(spec) {
  check <- validate_sem_model_spec(spec)
  if (!check$valid) stop(paste(check$errors, collapse = "; "), call. = FALSE)
  if (identical(spec$method, "piecewise_sem")) {
    formulas <- sem_graph_to_piecewise(spec)
    return(paste(c(sprintf("# %s (v%d)", spec$model_name, spec$revision), "",
      "# Piecewise equation：response variable ~ Explanatory variables1 + Explanatory variables2",
      vapply(formulas, function(value) paste(deparse(value), collapse = ""), character(1))), collapse = "\n"))
  }
  if (identical(spec$method, "pls_pm")) {
    return(sem_plspm_model_code(spec))
  }
  lines <- c(sprintf("# %s (v%d)", spec$model_name, spec$revision))
  constructs <- spec$nodes[spec$nodes$node_type %in% c("latent_variable", "composite_construct"), , drop = FALSE]
  if (nrow(constructs)) {
    lines <- c(lines, "", "# 1. Measurement model：Latent variables =~ indicator1 + indicator2")
    for (index in seq_len(nrow(constructs))) {
      name <- constructs$construct_name[[index]]
      if (!nzchar(name)) name <- make.names(constructs$label[[index]])
      indicators <- constructs$indicator_variables[[index]]
      if (length(indicators)) lines <- c(lines, paste(name, "=~", paste(indicators, collapse = " + ")))
      else lines <- c(lines, sprintf("# %s =~ indicator1 + indicator2", name))
    }
  }
  structural_section <- if (nrow(constructs)) 2L else 1L
  lines <- c(lines, "", sprintf("# %d. structure path：response variable ~ Explanatory variables1 + Explanatory variables2", structural_section))
  directed <- spec$edges[spec$edges$active & spec$edges$edge_type == "directed_path", , drop = FALSE]
  for (target in unique(directed$target)) {
    selected <- directed[directed$target == target, , drop = FALSE]
    lhs <- sem_node_variable(spec, target)
    rhs <- vapply(selected$source, sem_node_variable, character(1), spec = spec)
    terms <- ifelse(nzchar(selected$parameter_name), paste0(selected$parameter_name, "*", rhs), rhs)
    lines <- c(lines, paste(lhs, "~", paste(terms, collapse = " + ")))
  }
  lines <- c(lines, "", sprintf("# %d. error orResidualrelated：variable1 ~~ variable2", structural_section + 1L))
  covariance <- spec$edges[spec$edges$active & spec$edges$edge_type %in% c("covariance", "residual_covariance"), , drop = FALSE]
  if (nrow(covariance)) for (index in seq_len(nrow(covariance))) {
    lines <- c(lines, paste(sem_node_variable(spec, covariance$source[[index]]), "~~",
      sem_node_variable(spec, covariance$target[[index]])))
  }
  paste(lines, collapse = "\n")
}

sem_graph_to_piecewise <- function(spec) {
  check <- validate_sem_model_spec(spec); if (!check$valid) stop(paste(check$errors, collapse = "; "), call. = FALSE)
  directed <- spec$edges[spec$edges$active & spec$edges$edge_type == "directed_path", , drop = FALSE]
  targets <- unique(directed$target)
  formulas <- lapply(targets, function(target) {
    selected <- directed[directed$target == target, , drop = FALSE]
    lhs <- sem_node_variable(spec, target)
    rhs <- vapply(selected$source, sem_node_variable, character(1), spec = spec)
    stats::reformulate(rhs, response = lhs)
  })
  names(formulas) <- vapply(targets, sem_node_variable, character(1), spec = spec)
  formulas
}

sem_piecewise_components_from_spec <- function(spec, component_specs = list()) {
  formulas <- sem_graph_to_piecewise(spec)
  stats::setNames(lapply(seq_along(formulas), function(index) {
    response <- names(formulas)[[index]]
    settings <- component_specs[[response]] %||% list()
    list(name = paste0("mod", index), composite = if (any(spec$nodes$node_type == "composite_construct")) paste0("comp", index) else "", formula = formulas[[index]],
      engine = settings$engine %||% "lm", family = settings$family %||% "gaussian",
      random_intercept = settings$random_intercept %||% "", reml = isTRUE(settings$reml))
  }), paste0("mod", seq_along(formulas)))
}

sem_piecewise_component_call <- function(component, data_name = "grass_data") {
  engine <- component$engine %||% "lm"
  formula <- paste(deparse(component$formula), collapse = "")
  extras <- character()
  family <- component$family %||% "gaussian"
  family_call <- switch(family, poisson = "poisson(link = \"log\")", binomial = "binomial(link = \"logit\")",
    nbinom2 = "nbinom2(link = \"log\")", zi_nbinom2 = "nbinom2(link = \"log\")", family)
  if (engine %in% c("glm", "glmer", "glmmTMB", "glmmPQL")) extras <- c(extras, paste0("family = ", family_call))
  if (engine == "glmmTMB" && identical(family, "zi_nbinom2"))
    extras <- c(extras, paste0("ziformula = ~", component$zero_group %||% "1"))
  random <- component$random_intercept %||% ""
  if (engine %in% c("lmer", "glmer", "glmmTMB")) {
    structure <- component$random_structure %||% "block"
    slopes <- component$random_slope %||% character(); slope_group <- component$slope_group %||% ""
    if (identical(structure, "slope") && length(slopes) && nzchar(slope_group))
      formula <- paste0(formula, " + ", paste(sprintf("(1 + %s | %s)", slopes, slope_group), collapse = " + "))
    else if (nzchar(random)) formula <- paste0(formula, " + (1 | ", random, ")")
  }
  if (engine == "glmmPQL" && nzchar(random)) extras <- c(extras, paste0("random = ~1 | ", random))
  if (engine == "lmer") extras <- c(extras, "REML = FALSE")
  paste0(component$name, " <- ", engine, "(", formula, ", data = ", data_name,
    if (length(extras)) paste0(", ", paste(extras, collapse = ", ")) else "", ")")
}

sem_piecewise_components_to_code <- function(components, data_name = "grass_data", psem_name = "psem_grass") {
  if (!length(components)) return("# No component models")
  component_lines <- unlist(lapply(components, function(component) {
    marker <- component$composite %||% ""
    c(if (nzchar(marker)) paste0("# composite: ", marker), sem_piecewise_component_call(component, data_name))
  }))
  paste(c("# Build causal paths step by step（Componentsmodel）", component_lines, "", "# Consolidate into segments SEM model",
    paste0(psem_name, " <- psem(", paste(vapply(components, `[[`, character(1), "name"), collapse = ", "), ")")),
    collapse = "\n")
}

sem_parse_piecewise_code <- function(code) {
  lines <- trimws(strsplit(code, "\n", fixed = TRUE)[[1]])
  assignment_index <- grep("^[A-Za-z][A-Za-z0-9_.]*\\s*<-\\s*(lm|glm|lmer|glmer|glmmTMB|glmmPQL)\\s*\\(", lines)
  if (!length(assignment_index)) stop("No supported piecewiseSEM component models were found.", call. = FALSE)
  components <- list(); composite_index <- 0L
  for (line_index in assignment_index) {
    line <- lines[[line_index]]
    matched <- regexec("^([A-Za-z][A-Za-z0-9_.]*)\\s*<-\\s*(lm|glm|lmer|glmer|glmmTMB|glmmPQL)\\s*\\((.*)\\)\\s*$", line)
    parts <- regmatches(line, matched)[[1]]
    if (length(parts) != 4L) stop("Unsupported component model statement: ", line, call. = FALSE)
    name <- parts[[2]]; engine <- parts[[3]]; arguments <- parts[[4]]
    formula_text <- trimws(sub(",\\s*data\\s*=.*$", "", arguments))
    if (!grepl("^[A-Za-z][A-Za-z0-9_.]*\\s*~\\s*[A-Za-z0-9_.*+:()| -]+$", formula_text))
      stop("Unsafe component formula: ", formula_text, call. = FALSE)
    random_match <- regmatches(formula_text, regexpr("\\(1\\s*\\|\\s*[A-Za-z][A-Za-z0-9_.]*\\)", formula_text))
    random <- if (length(random_match) && nzchar(random_match)) sub(".*\\|\\s*", "", sub("\\)$", "", random_match)) else ""
    fixed_formula <- trimws(gsub("\\s*\\+?\\s*\\(1\\s*\\|\\s*[A-Za-z][A-Za-z0-9_.]*\\)", "", formula_text))
    family_match <- regmatches(arguments, regexpr("family\\s*=\\s*[A-Za-z][A-Za-z0-9_.]*", arguments))
    family <- if (length(family_match) && nzchar(family_match)) trimws(sub("family\\s*=\\s*", "", family_match)) else "gaussian"
    pql_random <- regmatches(arguments, regexpr("random\\s*=\\s*~1\\s*\\|\\s*[A-Za-z][A-Za-z0-9_.]*", arguments))
    if (!nzchar(random) && length(pql_random) && nzchar(pql_random)) random <- trimws(sub(".*\\|\\s*", "", pql_random))
    composite_index <- composite_index + 1L
    previous_line <- if (line_index > 1L) lines[[line_index - 1L]] else ""
    composite <- if (grepl("^#\\s*composite\\s*:", previous_line, ignore.case = TRUE))
      trimws(sub("^#\\s*composite\\s*:\\s*", "", previous_line, ignore.case = TRUE)) else paste0("comp", composite_index)
    if (!grepl("^[A-Za-z][A-Za-z0-9_.]*$", composite)) stop("Unsafe composite name: ", composite, call. = FALSE)
    components[[name]] <- list(name = name, composite = composite,
      formula = stats::as.formula(fixed_formula), engine = engine, family = family,
      random_intercept = random, reml = FALSE)
  }
  components
}

sem_piecewise_components_to_spec <- function(components, model_name = "Imported piecewise SEM") {
  if (!length(components)) stop("At least one component model is required.", call. = FALSE)
  paths <- vapply(components, function(component) paste(deparse(component$formula), collapse = ""), character(1))
  spec <- sem_parse_lavaan_syntax(paste(paths, collapse = "\n"), "piecewise_sem")
  spec$model_name <- model_name
  spec
}

sem_graph_to_plspm <- function(spec) {
  check <- validate_sem_model_spec(spec); if (!check$valid) stop(paste(check$errors, collapse = "; "), call. = FALSE)
  constructs <- spec$nodes[spec$nodes$node_type %in% c("latent_variable", "observed_variable"), , drop = FALSE]
  if (nrow(constructs) < 2L) stop("PLS-PM requires at least two constructs.", call. = FALSE)
  construct_labels <- ifelse(constructs$node_type == "latent_variable" & nzchar(constructs$construct_name),
    constructs$construct_name, constructs$label)
  names <- make.names(construct_labels, unique = TRUE)
  blocks <- lapply(seq_len(nrow(constructs)), function(index) {
    if (identical(constructs$node_type[[index]], "observed_variable"))
      constructs$variable_name[[index]] else constructs$indicator_variables[[index]]
  })
  if (any(lengths(blocks) < 1L)) stop("Every PLS construct requires an indicator block.", call. = FALSE)
  modes <- ifelse(constructs$node_type == "observed_variable", "A",
    ifelse(constructs$measurement_mode == "formative", "B", "A"))
  path <- matrix(0, nrow(constructs), nrow(constructs), dimnames = list(names, names))
  directed <- spec$edges[spec$edges$active & spec$edges$edge_type == "directed_path", , drop = FALSE]
  for (index in seq_len(nrow(directed))) {
    source <- match(directed$source[[index]], constructs$id); target <- match(directed$target[[index]], constructs$id)
    if (is.na(source) || is.na(target)) stop("PLS structural paths must connect constructs.", call. = FALSE)
    path[target, source] <- 1
  }
  list(path_matrix = path, blocks = stats::setNames(unname(blocks), names), modes = modes,
    construct_names = names)
}

sem_plspm_model_code <- function(spec, include_fit = TRUE) {
  design <- sem_graph_to_plspm(spec)
  quote_values <- function(values) paste(dQuote(values, q = FALSE), collapse = ", ")
  block_lines <- vapply(seq_along(design$blocks), function(index) sprintf("  %s = c(%s)%s",
    design$construct_names[[index]], quote_values(design$blocks[[index]]),
    if (index < length(design$blocks)) "," else ""), character(1))
  path_targets <- rownames(design$path_matrix)[rowSums(design$path_matrix != 0) > 0]
  path_lines <- if (length(path_targets)) vapply(path_targets, function(target) {
    sources <- colnames(design$path_matrix)[design$path_matrix[target, ] != 0]
    source_code <- if (length(sources) == 1L) dQuote(sources, q = FALSE) else
      sprintf("c(%s)", quote_values(sources))
    sprintf("path_matrix[%s, %s] <- 1", dQuote(target, q = FALSE), source_code)
  }, character(1)) else character()
  lines <- c(sprintf("# %s (v%d)", spec$model_name, spec$revision), "# 1. Latent variablesandMeasurement block",
    sprintf("LV_names <- c(%s)", quote_values(design$construct_names)), "blocks <- list(", block_lines, ")", "",
    "# 2. Measurement mode：A = Reflective，B = form",
    sprintf("modes <- c(%s)", quote_values(design$modes)), "", "# 3. withinmodelpath matrix",
    "path_matrix <- matrix(0, nrow = length(LV_names), ncol = length(LV_names),",
    "  dimnames = list(LV_names, LV_names))", path_lines)
  if (isTRUE(include_fit)) lines <- c(lines, "", "# Fit PLS-SEM",
    "pls_model <- plspm::plspm(pls_data, path_matrix, blocks, modes = modes, scheme = \"path\",",
    "  scaled = TRUE, boot.val = TRUE, maxiter = 100, tol = 1e-06, br = 500)")
  paste(lines, collapse = "\n")
}

sem_parse_plspm_code <- function(code, model_name = "Imported PLS-SEM model") {
  block_match <- regexpr("(?ms)^\\s*blocks\\s*<-\\s*list\\s*\\(.*?^\\s*\\)", code, perl = TRUE)
  if (block_match[[1]] < 0L) stop("PLS-SEM code must define blocks <- list(...).", call. = FALSE)
  block_text <- regmatches(code, block_match)
  entry_pattern <- "([A-Za-z][A-Za-z0-9_.]*)\\s*=\\s*c\\s*\\(([^)]*)\\)"
  entry_matches <- gregexpr(entry_pattern, block_text, perl = TRUE)[[1]]
  if (entry_matches[[1]] < 0L) stop("No valid PLS measurement blocks were found.", call. = FALSE)
  entries <- regmatches(block_text, list(entry_matches))[[1]]
  block_names <- sub(entry_pattern, "\\1", entries, perl = TRUE)
  block_values <- lapply(entries, function(entry) {
    value_text <- sub(entry_pattern, "\\2", entry, perl = TRUE)
    quoted <- regmatches(value_text, gregexpr('"[^"]+"', value_text, perl = TRUE))[[1]]
    if (!length(quoted)) character() else gsub('^"|"$', "", quoted)
  })
  if (any(!lengths(block_values))) stop("Every PLS measurement block requires at least one data variable.", call. = FALSE)
  mode_match <- regexpr("modes\\s*<-\\s*c\\s*\\(([^)]*)\\)", code, perl = TRUE)
  if (mode_match[[1]] < 0L) stop("PLS-SEM code must define modes.", call. = FALSE)
  mode_text <- regmatches(code, mode_match)
  modes <- regmatches(mode_text, gregexpr('"[AB]"', mode_text, perl = TRUE))[[1]]
  modes <- gsub('"', "", modes, fixed = TRUE)
  if (length(modes) != length(block_names)) stop("The number of PLS modes must match the number of blocks.", call. = FALSE)
  nodes <- sem_node_table()
  template_positions <- list(Env = c(80, 220), Soil = c(300, 90), Microbe = c(300, 350),
    Community = c(540, 220), Product = c(780, 220))
  for (index in seq_along(block_names)) {
    name <- block_names[[index]]; indicators <- block_values[[index]]
    observed <- length(indicators) == 1L && identical(indicators[[1]], name)
    position <- template_positions[[name]] %||% c(100 + 190 * ((index - 1L) %% 4), 120 + 130 * floor((index - 1L) / 4))
    nodes[index, ] <- list(make.names(name), name, if (observed) "observed_variable" else "latent_variable",
      if (observed) indicators[[1]] else "", if (observed) "" else name,
      I(list(if (observed) character() else indicators)), if (observed) "" else if (modes[[index]] == "B") "formative" else "reflective",
      "exogenous", FALSE, observed, !observed, FALSE, FALSE, position[[1]], position[[2]], 150, 64,
      FALSE, if (observed) "observed" else "latent", index, FALSE, "")
  }
  path_lines <- grep("path_matrix\\s*\\[.*\\]\\s*<-\\s*1", strsplit(code, "\n", fixed = TRUE)[[1]], value = TRUE)
  edges <- sem_edge_table(); edge_index <- 0L
  for (line in path_lines) {
    target_match <- regmatches(line, regexpr('path_matrix\\s*\\[\\s*"[^"]+"', line, perl = TRUE))
    target <- sub('.*"([^"]+)"$', "\\1", target_match, perl = TRUE)
    source_part <- sub("^[^,]*,", "", sub("\\]\\s*<-.*$", "", line))
    sources <- regmatches(source_part, gregexpr('"[^"]+"', source_part, perl = TRUE))[[1]]
    sources <- gsub('^"|"$', "", sources)
    if (!target %in% block_names || any(!sources %in% block_names)) stop("PLS path matrix references an unknown construct.", call. = FALSE)
    for (source in sources) {
      edge_index <- edge_index + 1L
      edges[edge_index, ] <- list(paste0("pls", edge_index), make.names(source), make.names(target),
        "directed_path", "forward", "", "", NA_real_, NA_real_, TRUE, FALSE, FALSE, TRUE,
        FALSE, FALSE, TRUE, FALSE, "", "")
      nodes$endogenous[nodes$id == make.names(target)] <- TRUE
      nodes$role[nodes$id == make.names(target)] <- "endogenous"
      nodes$r_squared_display[nodes$id == make.names(target)] <- TRUE
    }
  }
  new_sem_model_spec("pls_pm", nodes, edges, model_name = model_name,
    data_version = "sem_grassland_demo", provenance = list(source = "formula_editor"))
}

sem_parse_lavaan_syntax <- function(code, method = "covariance_sem") {
  lines <- trimws(strsplit(code, "\n", fixed = TRUE)[[1]])
  lines <- lines[nzchar(lines) & !startsWith(lines, "#")]
  allowed <- "^[A-Za-z][A-Za-z0-9_.]*\\s*(=~|~|~~)\\s*[A-Za-z0-9_.*+ -]+$"
  if (!length(lines) || any(!grepl(allowed, lines))) stop("Unsupported or unsafe model statement.", call. = FALSE)
  operators <- regmatches(lines, regexpr("=~|~~|~", lines))
  lhs <- trimws(sub("(=~|~~|~).*", "", lines))
  rhs_text <- trimws(sub("^.*?(=~|~~|~)", "", lines))
  rhs <- lapply(rhs_text, function(value) trimws(gsub("^[A-Za-z][A-Za-z0-9_.]*\\*", "", strsplit(value, "+", fixed = TRUE)[[1]])))
  measurement <- operators == "=~"
  variables <- unique(c(lhs[measurement], lhs[!measurement], unlist(rhs[!measurement], use.names = FALSE)))
  node_ids <- make.names(variables, unique = TRUE)
  nodes <- sem_node_table()
  for (index in seq_along(variables)) {
    nodes[nrow(nodes) + 1L, ] <- list(node_ids[[index]], variables[[index]], "observed_variable", variables[[index]], "",
      I(list(character())), "", "", FALSE, TRUE, FALSE, FALSE, FALSE, 100 + 180 * ((index - 1) %% 4),
      100 + 120 * floor((index - 1) / 4), 130, 58, FALSE, "observed", index, TRUE, "")
  }
  edges <- sem_edge_table(); edge_index <- 0L
  for (line_index in seq_along(lines)) {
    if (operators[[line_index]] == "=~") {
      latent_index <- match(lhs[[line_index]], variables)
      nodes$node_type[[latent_index]] <- "latent_variable"; nodes$observed[[latent_index]] <- FALSE
      nodes$latent[[latent_index]] <- TRUE; nodes$construct_name[[latent_index]] <- lhs[[line_index]]
      nodes$indicator_variables[[latent_index]] <- rhs[[line_index]]
      next
    }
    for (term in rhs[[line_index]]) {
      edge_index <- edge_index + 1L
      source_name <- if (operators[[line_index]] == "~") term else lhs[[line_index]]
      target_name <- if (operators[[line_index]] == "~") lhs[[line_index]] else term
      edges[edge_index, ] <- list(paste0("e", edge_index), node_ids[match(source_name, variables)],
        node_ids[match(target_name, variables)], if (operators[[line_index]] == "~") "directed_path" else "covariance",
        if (operators[[line_index]] == "~") "forward" else "bidirectional", "", "", NA_real_, NA_real_, TRUE,
        FALSE, FALSE, TRUE, operators[[line_index]] == "~~", FALSE, operators[[line_index]] == "~", FALSE, "", "")
    }
  }
  new_sem_model_spec(method, nodes, edges, model_name = "Imported model", provenance = list(source = "code"))
}
