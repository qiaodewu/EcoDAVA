sem_demo_data_generate <- function(seed = 123L, n = 280L) {
  set.seed(seed)
  Temp <- stats::rnorm(n, mean = 8.5, sd = 2.2)
  Prec <- stats::rnorm(n, mean = 420, sd = 60)
  Dry <- 0.6 * Temp - 0.4 * Prec / 100 + stats::rnorm(n, 0, 0.3)
  SOC <- -0.5 * Dry + stats::rnorm(n, 12, 1.5)
  TN <- 0.8 * SOC + stats::rnorm(n, 1.2, 0.2)
  AP <- 0.7 * SOC + stats::rnorm(n, 0.8, 0.15)
  Bac <- -0.4 * Dry + 0.6 * TN + stats::rnorm(n, 6.2, 0.8)
  Fun <- 0.5 * AP + stats::rnorm(n, 4.5, 0.6)
  MBC <- 0.7 * Bac + 0.6 * Fun + stats::rnorm(n, 220, 25)
  Rich <- -0.3 * Dry + 0.5 * MBC + stats::rnorm(n, 18, 2.5)
  Shan <- 0.8 * Rich + stats::rnorm(n, 2.8, 0.3)
  Cover <- 0.6 * Shan + 0.4 * MBC + stats::rnorm(n, 75, 8)
  AGB <- 0.5 * Cover + 0.3 * Shan + stats::rnorm(n, 320, 35)
  BGB <- 0.6 * Cover + 0.4 * AGB / 10 + stats::rnorm(n, 480, 45)
  data.frame(Temp, Prec, Dry, SOC, TN, AP, Bac, Fun, MBC, Rich, Shan, Cover, AGB, BGB)
}

sem_demo_data <- function(seed = 123L, n = 280L) {
  value <- dava_local_demo_read("structural_sem/sem_data.rds")
  value[seq_len(min(as.integer(n), nrow(value))), , drop = FALSE]
}

sem_demo_composite_scores <- function(data) {
  blocks <- list(Env = c("Temp", "Prec", "Dry"), Soil = c("SOC", "TN", "AP"),
    Microbe = c("Bac", "Fun", "MBC"), Community = c("Rich", "Shan", "Cover"), Product = c("AGB", "BGB"))
  missing <- setdiff(unique(unlist(blocks)), names(data))
  if (length(missing)) stop("Missing grassland SEM indicators: ", paste(missing, collapse = ", "), call. = FALSE)
  scores <- lapply(blocks, function(variables) rowMeans(scale(data[, variables, drop = FALSE])))
  as.data.frame(scores, stringsAsFactors = FALSE)
}

sem_piecewise_composite_data_code <- function(spec, data_name = "grass_data", records = NULL,
    data_is_standardized = FALSE) {
  if (length(records)) {
    lines <- character()
    for (record in records) {
      if (identical(record$method, "z_mean")) {
        indicators <- record$variables
        reverse <- record$reverse_variables %||% character()
        signs <- ifelse(indicators %in% reverse, -1, 1)
        lines <- c(lines, sprintf("%s$%s <- rowMeans(%s[, c(%s), drop = FALSE] * c(%s), na.rm = TRUE)",
          data_name, record$construct_name, data_name,
          paste(dQuote(indicators, q = FALSE), collapse = ", "), paste(signs, collapse = ", ")))
      } else lines <- c(lines, sem_composite_construction_code(record, data_name,
        data_is_standardized = data_is_standardized))
    }
    return(lines)
  }
  nodes <- spec$nodes[spec$nodes$node_type == "composite_construct", , drop = FALSE]
  if (!nrow(nodes)) return(character())
  lines <- character()
  for (index in seq_len(nrow(nodes))) {
    name <- nodes$construct_name[[index]] %||% nodes$label[[index]]
    indicators <- nodes$indicator_variables[[index]] %||% character()
    if (length(indicators) >= 2L) lines <- c(lines,
      sprintf("%s$%s <- rowMeans(%s[, c(%s), drop = FALSE], na.rm = TRUE)", data_name, name, data_name,
        paste(dQuote(indicators, q = FALSE), collapse = ", ")))
  }
  lines
}

sem_demo_covariance <- function(data = sem_demo_data()) {
  variables <- c("Temp", "Prec", "Dry", "SOC", "TN", "AP", "Bac", "Fun", "MBC", "Rich", "Shan", "Cover", "AGB", "BGB")
  stats::cov(data[, variables], use = "pairwise.complete.obs")
}

sem_demo_structural_edges <- function() {
  links <- list(c("env", "soil"), c("env", "microbe"), c("soil", "microbe"),
    c("env", "community"), c("soil", "community"), c("microbe", "community"),
    c("community", "product"), c("microbe", "product"), c("soil", "product"))
  edges <- sem_edge_table()
  for (index in seq_along(links)) edges[index, ] <- list(paste0("p", index), links[[index]][[1]], links[[index]][[2]],
    "directed_path", "forward", "", "", NA_real_, NA_real_, TRUE, FALSE, FALSE, TRUE, FALSE, FALSE, TRUE, FALSE, "", "")
  edges
}

sem_demo_construct_nodes <- function(node_type = "latent_variable") {
  nodes <- sem_node_table()
  ids <- c("env", "soil", "microbe", "community", "product")
  labels <- c("Env", "Soil", "Microbe", "Community", "Product")
  blocks <- list(c("Temp", "Prec", "Dry"), c("SOC", "TN", "AP"), c("Bac", "Fun", "MBC"),
    c("Rich", "Shan", "Cover"), c("AGB", "BGB"))
  positions <- list(c(80, 220), c(300, 90), c(300, 350), c(540, 220), c(780, 220))
  for (index in seq_along(ids)) {
    observed <- identical(node_type, "observed_variable")
    nodes[index, ] <- list(ids[[index]], labels[[index]], node_type, if (observed) labels[[index]] else "",
      if (observed) "" else labels[[index]], I(list(if (observed) character() else blocks[[index]])),
      if (observed) "" else "reflective", if (index == 1L) "exogenous" else "endogenous", index > 1L,
      observed, identical(node_type, "latent_variable"), identical(node_type, "composite_construct"), FALSE,
      positions[[index]][[1]], positions[[index]][[2]], 150, 64, FALSE,
      if (observed) "observed" else "latent", index, index > 1L, "")
  }
  nodes
}

sem_cbsem_spec_from_definition <- function(model_name, node_definitions, paths, template_id) {
  node_ids <- vapply(node_definitions, `[[`, character(1), "id")
  endogenous_ids <- unique(vapply(paths, `[[`, character(1), 2L))
  nodes <- sem_node_table()
  for (index in seq_along(node_definitions)) {
    definition <- node_definitions[[index]]
    latent <- identical(definition$type, "latent_variable")
    endogenous <- definition$id %in% endogenous_ids
    nodes[index, ] <- list(definition$id, definition$label, definition$type,
      if (latent) "" else definition$variable, if (latent) definition$label else "",
      I(list(if (latent) definition$indicators else character())), if (latent) "reflective" else "",
      if (endogenous) "endogenous" else "exogenous", endogenous, !latent, latent, FALSE, FALSE,
      definition$x, definition$y, if (latent) 150 else 125, if (latent) 64 else 54, FALSE,
      if (latent) "latent" else if (endogenous) "endogenous" else "exogenous", index, endogenous, "")
  }
  stopifnot(all(vapply(paths, function(pair) all(pair %in% node_ids), logical(1))))
  edges <- sem_edge_table()
  for (index in seq_along(paths)) {
    pair <- paths[[index]]
    edges[index, ] <- list(paste0("cb", index), pair[[1]], pair[[2]], "directed_path", "forward", "", "",
      NA_real_, NA_real_, TRUE, FALSE, FALSE, TRUE, FALSE, FALSE, TRUE, FALSE, "", "")
  }
  new_sem_model_spec("covariance_sem", nodes, edges, model_name = model_name,
    data_version = "sem_grassland_demo",
    provenance = list(source = "template", template_id = template_id, dataset_id = ".__sem_demo__"))
}

sem_demo_cbsem_latent_spec <- function() {
  definitions <- list(
    list(id = "env", label = "Env", type = "latent_variable", variable = "", indicators = c("Temp", "Prec", "Dry"), x = 90, y = 230),
    list(id = "soil", label = "Soil", type = "latent_variable", variable = "", indicators = c("SOC", "TN", "AP"), x = 320, y = 90),
    list(id = "microbe", label = "Microbe", type = "latent_variable", variable = "", indicators = c("Bac", "Fun", "MBC"), x = 320, y = 370),
    list(id = "community", label = "Community", type = "latent_variable", variable = "", indicators = c("Rich", "Shan", "Cover"), x = 570, y = 230),
    list(id = "product", label = "Product", type = "latent_variable", variable = "", indicators = c("AGB", "BGB"), x = 820, y = 230))
  paths <- list(c("env", "soil"), c("env", "microbe"), c("soil", "microbe"),
    c("env", "community"), c("soil", "community"), c("microbe", "community"),
    c("community", "product"), c("microbe", "product"), c("soil", "product"))
  sem_cbsem_spec_from_definition("Latent variable model", definitions, paths, "cbsem_latent")
}

sem_demo_cbsem_observed_spec <- function() {
  positions <- list(Prec = c(170, 90), Temp = c(650, 90), Fun = c(90, 300),
    Bac = c(410, 300), SOC = c(750, 300), AGB = c(410, 510))
  definitions <- lapply(names(positions), function(variable) list(id = tolower(variable), label = variable,
    type = "observed_variable", variable = variable, indicators = character(), x = positions[[variable]][[1]], y = positions[[variable]][[2]]))
  paths <- list(c("temp", "soc"), c("prec", "bac"), c("temp", "bac"), c("soc", "bac"),
    c("prec", "fun"), c("soc", "agb"), c("bac", "agb"), c("fun", "agb"))
  sem_cbsem_spec_from_definition("Observed variable model", definitions, paths, "cbsem_observed")
}

sem_demo_cbsem_mixed_spec <- function() {
  definitions <- list(
    list(id = "env", label = "Env", type = "latent_variable", variable = "", indicators = c("Temp", "Prec", "Dry"), x = 100, y = 230),
    list(id = "soil", label = "Soil", type = "latent_variable", variable = "", indicators = c("SOC", "TN", "AP"), x = 340, y = 100),
    list(id = "microbe", label = "Microbe", type = "latent_variable", variable = "", indicators = c("Bac", "Fun", "MBC"), x = 340, y = 360),
    list(id = "rich", label = "Rich", type = "observed_variable", variable = "Rich", indicators = character(), x = 590, y = 100),
    list(id = "shan", label = "Shan", type = "observed_variable", variable = "Shan", indicators = character(), x = 760, y = 100),
    list(id = "cover", label = "Cover", type = "observed_variable", variable = "Cover", indicators = character(), x = 920, y = 230),
    list(id = "agb", label = "AGB", type = "observed_variable", variable = "AGB", indicators = character(), x = 1090, y = 170),
    list(id = "bgb", label = "BGB", type = "observed_variable", variable = "BGB", indicators = character(), x = 1090, y = 320))
  paths <- list(c("env", "soil"), c("env", "microbe"), c("soil", "microbe"), c("env", "rich"),
    c("soil", "rich"), c("microbe", "rich"), c("rich", "shan"), c("shan", "cover"),
    c("microbe", "cover"), c("cover", "agb"), c("microbe", "agb"), c("soil", "agb"),
    c("cover", "bgb"), c("agb", "bgb"))
  sem_cbsem_spec_from_definition("Observed variable-latent variable mixed model", definitions, paths, "cbsem_mixed")
}

sem_demo_cbsem_spec <- function() sem_demo_cbsem_latent_spec()

sem_demo_piecewise_observed_spec <- function() {
  predictors <- list(Cover = c("Bac", "SOC"), SOC = c("Prec", "Dry"), Bac = "SOC")
  positions <- list(Dry = c(250, 80), Prec = c(650, 80), SOC = c(450, 280),
    Cover = c(250, 500), Bac = c(650, 500))
  endogenous_variables <- names(predictors)
  nodes <- sem_node_table(); all_variables <- names(positions)
  for (index in seq_along(all_variables)) {
    value <- all_variables[[index]]; endogenous <- value %in% endogenous_variables
    nodes[index, ] <- list(make.names(value), value, "observed_variable", value, "", I(list(character())), "",
      if (endogenous) "endogenous" else "exogenous", endogenous, TRUE, FALSE, FALSE, FALSE,
      positions[[value]][[1]], positions[[value]][[2]],
      140, 58, FALSE, if (endogenous) "endogenous" else "exogenous", index, endogenous, "")
  }
  edges <- sem_edge_table(); edge_index <- 0L
  for (response in names(predictors)) for (predictor in predictors[[response]]) {
    edge_index <- edge_index + 1L
    edges[edge_index, ] <- list(paste0("pw", edge_index), make.names(predictor), make.names(response), "directed_path",
      "forward", "", "", NA_real_, NA_real_, TRUE, FALSE, FALSE, TRUE, FALSE, FALSE, TRUE, FALSE, "", "")
  }
  new_sem_model_spec("piecewise_sem", nodes, edges, model_name = "Grassland piecewiseSEM observed-path model",
    data_version = "sem_grassland_demo", provenance = list(source = "template",
      template_id = "piecewise_observed", dataset_id = ".__sem_demo__"))
}

sem_demo_piecewise_composite_spec <- function() {
  new_sem_model_spec("piecewise_sem", sem_demo_construct_nodes("composite_construct"), sem_demo_structural_edges(),
    model_name = "Grassland piecewiseSEM composite-path model", data_version = "sem_grassland_demo",
    provenance = list(source = "piecewise_composite_demo"))
}

sem_demo_piecewise_spec <- function(version = "observed") {
  if (identical(version, "composite")) sem_demo_piecewise_composite_spec() else sem_demo_piecewise_observed_spec()
}

sem_demo_plspm_spec <- function() {
  nodes <- sem_demo_construct_nodes("latent_variable")
  nodes$measurement_mode <- c("formative", rep("reflective", nrow(nodes) - 1L))
  new_sem_model_spec("pls_pm", nodes, sem_demo_structural_edges(),
    model_name = "Grassland PLS-SEM latent-variable model", data_version = "sem_grassland_demo",
    provenance = list(source = "template", template_id = "plspm_grassland",
      dataset_id = ".__sem_demo__"))
}

sem_demo_prior_spec <- function(method = "covariance_sem") {
  switch(method, covariance_sem = sem_demo_cbsem_spec(), piecewise_sem = sem_demo_piecewise_spec(),
    pls_pm = sem_demo_plspm_spec(), stop("Unsupported SEM method.", call. = FALSE))
}

sem_template_registry <- function() data.frame(
  id = c("grassland", "piecewise_observed", "piecewise_composite", "single_mediation", "parallel_mediation", "serial_mediation", "multi_response", "latent_measurement", "fertilization_microbiome"),
  label = c("Grassland degradation-soil-microorganism-plant", "piecewiseSEM manifest variable path model", "piecewiseSEM composite variable path model", "Single mediation model", "Parallel mediation model", "Series mediation model", "Multiple response path model", "Latent variable measurement model", "Fertilization - nutrients - microbial function - productivity"),
  stringsAsFactors = FALSE
)

sem_cbsem_template_registry <- function() data.frame(
  id = c("cbsem_observed", "cbsem_latent", "cbsem_mixed"),
  label = c("Observed variable model", "Latent variable model", "Observed variable-latent variable mixed model"),
  stringsAsFactors = FALSE
)

sem_plspm_template_registry <- function() data.frame(
  id = "plspm_grassland", label = "Grassland ecological PLS-SEM latent variable model",
  stringsAsFactors = FALSE)

sem_model_template <- function(template_id = "grassland", method = "covariance_sem") {
  if (identical(template_id, "cbsem_latent")) return(sem_demo_cbsem_latent_spec())
  if (identical(template_id, "cbsem_observed")) return(sem_demo_cbsem_observed_spec())
  if (identical(template_id, "cbsem_mixed")) return(sem_demo_cbsem_mixed_spec())
  if (identical(template_id, "grassland")) return(sem_demo_prior_spec(method))
  if (identical(template_id, "piecewise_observed")) return(sem_demo_piecewise_observed_spec())
  if (identical(template_id, "piecewise_composite")) return(sem_demo_piecewise_composite_spec())
  if (identical(template_id, "plspm_grassland")) return(sem_demo_plspm_spec())
  definitions <- switch(template_id,
    single_mediation = list(nodes = c("X", "Mediator", "Y"), edges = list(c(1, 2), c(2, 3), c(1, 3))),
    parallel_mediation = list(nodes = c("X", "Mediator A", "Mediator B", "Y"), edges = list(c(1, 2), c(1, 3), c(2, 4), c(3, 4), c(1, 4))),
    serial_mediation = list(nodes = c("X", "Mediator A", "Mediator B", "Y"), edges = list(c(1, 2), c(2, 3), c(3, 4), c(1, 4))),
    multi_response = list(nodes = c("Driver", "Mediator", "Response A", "Response B"), edges = list(c(1, 2), c(2, 3), c(2, 4), c(1, 3), c(1, 4))),
    latent_measurement = list(nodes = c("Soil construct", "Plant construct", "Microbial function"), edges = list(c(1, 2), c(1, 3), c(2, 3)), latent = TRUE),
    fertilization_microbiome = list(nodes = c("Fertilization", "Soil nutrients", "Microbial function", "Plant productivity"), edges = list(c(1, 2), c(2, 3), c(3, 4), c(2, 4))),
    stop("Unknown SEM template.", call. = FALSE)
  )
  nodes <- sem_node_table()
  for (index in seq_along(definitions$nodes)) {
    latent <- isTRUE(definitions$latent)
    nodes[index, ] <- list(paste0("n", index), definitions$nodes[[index]], if (latent) "latent_variable" else "observed_variable",
      "", if (latent) make.names(definitions$nodes[[index]]) else "", I(list(character())), if (latent) "reflective" else "",
      if (index == 1L) "exogenous" else "endogenous", index > 1L, !latent, latent, FALSE, FALSE,
      100 + 190 * (index - 1L), 170 + ifelse(index %% 2L, -55, 55), 145, 60, FALSE,
      if (latent) "latent" else "observed", index, index > 1L, "")
  }
  edges <- sem_edge_table()
  for (index in seq_along(definitions$edges)) {
    pair <- definitions$edges[[index]]
    edges[index, ] <- list(paste0("e", index), nodes$id[[pair[[1]]]], nodes$id[[pair[[2]]]], "directed_path", "forward",
      "", "", NA_real_, NA_real_, TRUE, FALSE, FALSE, TRUE, FALSE, FALSE, TRUE, FALSE, "", "")
  }
  new_sem_model_spec(method, nodes, edges, model_name = sem_template_registry()$label[match(template_id, sem_template_registry()$id)],
    provenance = list(source = "template", template_id = template_id))
}
