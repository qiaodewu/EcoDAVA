validate_sem_data_bundle <- function(bundle) {
  errors <- character(); warnings <- character()
  if (!inherits(bundle, "sem_data_bundle")) errors <- c(errors, "Object is not a sem_data_bundle.")
  if (inherits(bundle, "sem_data_bundle")) {
    input_type <- bundle$input_type %||% "raw_data"
    if (!input_type %in% c("raw_data", "covariance_matrix")) errors <- c(errors, "Unsupported SEM input type.")
    if (input_type == "raw_data" && !nrow(bundle$data)) errors <- c(errors, "Dataset has no rows.")
    if (input_type == "covariance_matrix") {
      covariance <- bundle$covariance_matrix
      if (!is.matrix(covariance) || !nrow(covariance) || nrow(covariance) != ncol(covariance))
        errors <- c(errors, "Sample covariance input must be a non-empty square matrix.")
      if (is.matrix(covariance) && (!identical(rownames(covariance), colnames(covariance)) || any(!is.finite(covariance))))
        errors <- c(errors, "Sample covariance matrix requires matching names and finite values.")
      if (is.null(bundle$sample_size) || length(bundle$sample_size) != 1L || is.na(bundle$sample_size) || bundle$sample_size < 2L)
        errors <- c(errors, "Sample covariance input requires sample_size >= 2.")
      if (is.matrix(covariance) && !isTRUE(all.equal(covariance, t(covariance), tolerance = 1e-8)))
        errors <- c(errors, "Sample covariance matrix must be symmetric.")
    }
    if (input_type != "raw_data") return(list(valid = !length(errors), errors = errors, warnings = warnings))
    if (nzchar(bundle$row_id) && anyDuplicated(bundle$data[[bundle$row_id]])) errors <- c(errors, "Row IDs are duplicated.")
    empty <- names(bundle$data)[vapply(bundle$data, function(x) all(is.na(x)), logical(1))]
    if (length(empty)) errors <- c(errors, paste("Completely missing columns:", paste(empty, collapse = ", ")))
    zero <- names(bundle$data)[vapply(bundle$data, function(x) length(unique(x[!is.na(x)])) < 2L, logical(1))]
    if (length(zero)) warnings <- c(warnings, paste("Zero-variance columns:", paste(zero, collapse = ", ")))
  }
  list(valid = !length(errors), errors = errors, warnings = warnings)
}

sem_directed_cycle <- function(nodes, edges) {
  directed <- edges[edges$edge_type %in% c("directed_path", "measurement_loading", "formative_weight") & edges$active, , drop = FALSE]
  adjacency <- split(directed$target, directed$source)
  visiting <- character(); visited <- character()
  walk <- function(node) {
    if (node %in% visiting) return(TRUE)
    if (node %in% visited) return(FALSE)
    visiting <<- c(visiting, node)
    for (next_node in adjacency[[node]] %||% character()) if (walk(next_node)) return(TRUE)
    visiting <<- setdiff(visiting, node); visited <<- c(visited, node); FALSE
  }
  any(vapply(nodes$id, walk, logical(1)))
}

validate_sem_model_spec <- function(spec) {
  errors <- character(); warnings <- character()
  if (!inherits(spec, "sem_model_spec")) errors <- c(errors, "Object is not a sem_model_spec.")
  if (inherits(spec, "sem_model_spec")) {
    if (!spec$method %in% SEM_METHOD_REGISTRY$id) errors <- c(errors, "Unknown SEM method.")
    if (anyDuplicated(spec$nodes$id)) errors <- c(errors, "Node IDs must be unique.")
    if (anyDuplicated(spec$edges$id)) errors <- c(errors, "Edge IDs must be unique.")
    if (any(spec$edges$source == spec$edges$target)) errors <- c(errors, "Self loops are forbidden.")
    missing_nodes <- setdiff(unique(c(spec$edges$source, spec$edges$target)), spec$nodes$id)
    if (length(missing_nodes)) errors <- c(errors, paste("Edges reference unknown nodes:", paste(missing_nodes, collapse = ", ")))
    duplicate_key <- paste(spec$edges$source, spec$edges$target, spec$edges$edge_type, sep = "|")
    if (anyDuplicated(duplicate_key)) errors <- c(errors, "Duplicate edges are forbidden.")
    if (!length(errors) && spec$method != "pls_pm" && sem_directed_cycle(spec$nodes, spec$edges)) errors <- c(errors, "Directed cycle detected.")
    unmapped <- spec$nodes$node_type == "observed_variable" & !nzchar(spec$nodes$variable_name)
    if (any(unmapped)) warnings <- c(warnings, paste("Unmapped observed nodes:", paste(spec$nodes$label[unmapped], collapse = ", ")))
    isolated <- !spec$nodes$id %in% unique(c(spec$edges$source[spec$edges$active], spec$edges$target[spec$edges$active]))
    if (any(isolated)) warnings <- c(warnings, paste("Isolated nodes:", paste(spec$nodes$label[isolated], collapse = ", ")))
    latent <- spec$nodes$node_type == "latent_variable"
    insufficient <- latent & lengths(spec$nodes$indicator_variables) < 2L
    if (any(insufficient)) warnings <- c(warnings, paste("Latent constructs with fewer than two indicators:", paste(spec$nodes$label[insufficient], collapse = ", ")))
    if (spec$method == "covariance_sem") {
      if (any(spec$nodes$node_type == "composite_construct"))
        errors <- c(errors, "CB-SEM does not permit composite-construct nodes.")
      observed_values <- spec$nodes$variable_name[spec$nodes$node_type == "observed_variable"]
      observed_values <- observed_values[nzchar(observed_values)]
      latent_indicators <- unlist(spec$nodes$indicator_variables[latent], use.names = FALSE)
      assigned_variables <- c(observed_values, latent_indicators)
      duplicated_variables <- unique(assigned_variables[duplicated(assigned_variables)])
      if (length(duplicated_variables)) errors <- c(errors,
        paste("CB-SEM data variables cannot be assigned to multiple independent nodes:",
          paste(duplicated_variables, collapse = ", ")))
    }
    if (spec$method == "piecewise_sem") {
      if (any(latent)) errors <- c(errors, "piecewiseSEM does not permit latent-variable nodes.")
      observed_values <- spec$nodes$variable_name[spec$nodes$node_type == "observed_variable"]
      observed_values <- observed_values[nzchar(observed_values)]
      if (anyDuplicated(observed_values)) errors <- c(errors, "Observed data variables must be unique in piecewiseSEM.")
      composite <- spec$nodes[spec$nodes$node_type == "composite_construct", , drop = FALSE]
      if (nrow(composite)) {
        indicators <- unlist(composite$indicator_variables, use.names = FALSE)
        if (anyDuplicated(indicators)) errors <- c(errors, "Composite indicators cannot be shared by multiple constructs.")
        overlap <- intersect(indicators, observed_values)
        if (length(overlap)) errors <- c(errors, paste("Composite indicators overlap observed nodes:", paste(overlap, collapse = ", ")))
      }
    }
    if (spec$method == "pls_pm") {
      if (any(spec$nodes$node_type == "composite_construct"))
        errors <- c(errors, "PLS-SEM editor does not permit composite-construct nodes; use latent-variable measurement modes A or B.")
      observed_values <- spec$nodes$variable_name[spec$nodes$node_type == "observed_variable"]
      observed_values <- observed_values[nzchar(observed_values)]
      latent_indicators <- unlist(spec$nodes$indicator_variables[latent], use.names = FALSE)
      assigned_variables <- c(observed_values, latent_indicators)
      duplicated_variables <- unique(assigned_variables[duplicated(assigned_variables)])
      if (length(duplicated_variables)) errors <- c(errors,
        paste("PLS-SEM data variables cannot be assigned to multiple independent nodes:",
          paste(duplicated_variables, collapse = ", ")))
    }
    endogenous <- spec$nodes$endogenous
    without_equation <- endogenous & !spec$nodes$id %in% spec$edges$target[spec$edges$active & spec$edges$edge_type == "directed_path"]
    if (any(without_equation)) warnings <- c(warnings, paste("Endogenous nodes without an incoming equation:", paste(spec$nodes$label[without_equation], collapse = ", ")))
  }
  list(valid = !length(errors), errors = errors, warnings = warnings)
}

validate_sem_result <- function(result) {
  required <- c("status", "method", "prior_model_spec", "final_model_spec", "parameter_estimates",
    "warnings", "errors", "generated_code", "execution_metrics", "registration_manifest")
  missing <- setdiff(required, names(result))
  list(valid = inherits(result, "sem_result") && !length(missing), missing = missing)
}
