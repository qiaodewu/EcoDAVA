sem_method_registry <- function() {
  registry <- data.frame(
    id = c("covariance_sem", "piecewise_sem", "pls_pm"),
    label_cn = c("Covariance structural equation model (CB-SEM)", "Piecewise Structural Equation Model (piecewise SEM)", "Partial Least Squares Path Model (PLS-PM)"),
    label_en = c("Covariance-based SEM", "Piecewise SEM", "Partial least squares path modeling"),
    primary_engine = c("lavaan", "piecewiseSEM", "plspm"),
    required_packages = c("lavaan", "piecewiseSEM", "plspm"),
    optional_packages = c("semTools,semPlot,tidySEM", "lme4,nlme,glmmTMB,DHARMa", "cSEM,seminr"),
    status = "implemented", visibility = TRUE, stringsAsFactors = FALSE
  )
  registry$navigation_aliases <- I(list("sem", "piecewise_sem", "plspm"))
  registry$supported_data_types <- I(list(
    c("numeric", "ordered", "factor"), c("numeric", "binary", "count", "proportion", "factor"), c("numeric")))
  registry$input_modes <- I(list(c("raw_data", "covariance_matrix"), "raw_data", "raw_data"))
  registry$model_engines <- I(list("lavaan", c("lm", "glm", "lmer", "glmer", "glmmTMB", "glmmPQL", "gam"), "plspm"))
  registry$capabilities <- I(list(
    list(observed_path_model = TRUE, latent_variables = TRUE, measurement_model = TRUE,
      composite_constructs = FALSE, formative_measurement = FALSE, reflective_measurement = TRUE,
      categorical_endogenous = TRUE, ordinal_indicators = TRUE, count_endogenous = FALSE,
      random_intercept = FALSE, random_slope = FALSE, multigroup = TRUE, measurement_invariance = TRUE,
      mediation = TRUE, moderation = TRUE, correlated_errors = TRUE, missing_fiml = TRUE,
      bootstrap = TRUE, robust_estimators = TRUE, model_comparison = TRUE, predictive_assessment = FALSE),
    list(observed_path_model = TRUE, latent_variables = FALSE, measurement_model = FALSE,
      composite_constructs = TRUE, formative_measurement = FALSE, reflective_measurement = FALSE,
      categorical_endogenous = TRUE, ordinal_indicators = FALSE, count_endogenous = TRUE,
      random_intercept = TRUE, random_slope = TRUE, multigroup = FALSE, measurement_invariance = FALSE,
      mediation = TRUE, moderation = TRUE, correlated_errors = TRUE, missing_fiml = FALSE,
      bootstrap = FALSE, robust_estimators = FALSE, model_comparison = TRUE, predictive_assessment = TRUE),
    list(observed_path_model = TRUE, latent_variables = TRUE, measurement_model = TRUE,
      composite_constructs = FALSE, formative_measurement = TRUE, reflective_measurement = TRUE,
      categorical_endogenous = FALSE, ordinal_indicators = FALSE, count_endogenous = FALSE,
      random_intercept = FALSE, random_slope = FALSE, multigroup = FALSE, measurement_invariance = FALSE,
      mediation = TRUE, moderation = FALSE, correlated_errors = FALSE, missing_fiml = FALSE,
      bootstrap = TRUE, robust_estimators = FALSE, model_comparison = TRUE, predictive_assessment = TRUE)
  ))
  registry$data_fields <- I(list(
    c("dataset", "row_id", "group", "ordered", "sample_covariance", "sample_size", "sample_means"),
    c("dataset", "row_id", "cluster", "block", "subject", "component_engine", "family", "random_intercept"),
    c("dataset", "row_id")))
  registry$plot_types <- I(list(
    c("prior_path", "final_path", "effect_forest", "residual_heatmap", "modification_indices"),
    c("prior_path", "final_path", "component_forest", "dsep", "component_r2"),
    c("prior_path", "final_path", "outer_loadings", "construct_scores", "bootstrap_paths")))
  registry$result_sections <- I(list(
    c("fit_measures", "parameter_estimates", "effects", "r_squared", "diagnostics"),
    c("fisher_c", "d_sep", "component_models", "parameter_estimates", "r_squared"),
    c("inner_model", "outer_model", "effects", "reliability", "construct_scores")))
  registry
}

SEM_METHOD_REGISTRY <- sem_method_registry()

sem_method_from_alias <- function(alias) {
  index <- match(alias, vapply(SEM_METHOD_REGISTRY$navigation_aliases, `[[`, character(1), 1L))
  if (is.na(index)) "" else SEM_METHOD_REGISTRY$id[[index]]
}

sem_method_capability <- function(method_id) {
  index <- match(method_id, SEM_METHOD_REGISTRY$id)
  if (is.na(index)) stop("Unknown SEM method: ", method_id, call. = FALSE)
  SEM_METHOD_REGISTRY$capabilities[[index]]
}
