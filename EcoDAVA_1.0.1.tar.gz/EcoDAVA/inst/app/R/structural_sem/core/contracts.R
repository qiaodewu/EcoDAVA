new_sem_data_bundle <- function(dataset_name, data, data_version = dataset_name, row_id = "",
    group_variable = "", cluster_variable = "", block_variable = "", subject_variable = "",
    weight_variable = "", ordered_variables = character(), source_metadata = list(), transformation_history = list(),
    input_type = "raw_data", covariance_matrix = NULL, sample_size = NULL, sample_means = NULL) {
  data <- as.data.frame(data, stringsAsFactors = FALSE, check.names = FALSE)
  structure(list(dataset_name = dataset_name, data_version = data_version, input_type = input_type, data = data,
    covariance_matrix = covariance_matrix, sample_size = sample_size, sample_means = sample_means, row_id = row_id,
    group_variable = group_variable, cluster_variable = cluster_variable, block_variable = block_variable,
    subject_variable = subject_variable, weight_variable = weight_variable,
    ordered_variables = intersect(ordered_variables, names(data)),
    categorical_variables = names(data)[vapply(data, function(x) is.factor(x) || is.character(x), logical(1))],
    numeric_variables = names(data)[vapply(data, is.numeric, logical(1))],
    missing_summary = data.frame(variable = names(data), missing = vapply(data, function(x) sum(is.na(x)), integer(1))),
    source_metadata = source_metadata, transformation_history = transformation_history),
    class = c("sem_data_bundle", "list"))
}

new_sem_covariance_bundle <- function(dataset_name, covariance_matrix, sample_size, sample_means = NULL,
    data_version = dataset_name, source_metadata = list()) {
  covariance_matrix <- as.matrix(covariance_matrix)
  storage.mode(covariance_matrix) <- "double"
  new_sem_data_bundle(dataset_name, data.frame(), data_version = data_version,
    source_metadata = source_metadata, input_type = "covariance_matrix",
    covariance_matrix = covariance_matrix, sample_size = as.integer(sample_size), sample_means = sample_means)
}

sem_node_table <- function() data.frame(id = character(), label = character(), node_type = character(),
  variable_name = character(), construct_name = character(), indicator_variables = I(list()), measurement_mode = character(),
  role = character(), endogenous = logical(), observed = logical(), latent = logical(), composite = logical(),
  error_term = logical(), x = numeric(), y = numeric(), width = numeric(), height = numeric(), locked = logical(),
  color_role = character(), display_order = integer(), r_squared_display = logical(), notes = character(), stringsAsFactors = FALSE)

sem_edge_table <- function() data.frame(id = character(), source = character(), target = character(), edge_type = character(),
  direction = character(), label = character(), parameter_name = character(), fixed_value = numeric(), starting_value = numeric(),
  free = logical(), optional = logical(), locked = logical(), active = logical(), residual_covariance = logical(),
  measurement_loading = logical(), structural_path = logical(), moderation_path = logical(), style = character(),
  notes = character(), stringsAsFactors = FALSE)

new_sem_model_spec <- function(method, nodes = sem_node_table(), edges = sem_edge_table(), model_name = "Prior model",
    data_version = "", constraints = list(), model_options = list(), revision = 1L, parent_revision = NA_integer_, provenance = list()) {
  now <- format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
  structure(list(schema_version = "1.0", model_id = paste0("sem_", format(Sys.time(), "%Y%m%d%H%M%S")),
    model_name = model_name, method = method, data_version = data_version, created_at = now, updated_at = now,
    nodes = nodes, edges = edges, constraints = constraints, model_options = model_options,
    layout = nodes[, intersect(c("id", "x", "y", "width", "height"), names(nodes)), drop = FALSE],
    locked_items = unique(c(nodes$id[nodes$locked], edges$id[edges$locked])), optional_items = edges$id[edges$optional],
    comments = character(), revision = as.integer(revision), parent_revision = parent_revision, provenance = provenance),
    class = c("sem_model_spec", "list"))
}

new_sem_result <- function(method, status = "success", ...) {
  defaults <- list(status = status, method = method, metadata = list(), data_adequacy = data.frame(), prior_model_spec = NULL,
    final_model_spec = NULL, model_syntax = "", fitted_model = NULL, fit_measures = data.frame(), parameter_estimates = data.frame(),
    standardized_estimates = data.frame(), measurement_results = data.frame(), variance_diagnostics = data.frame(), structural_results = data.frame(),
    reliability = data.frame(), convergent_validity = data.frame(), discriminant_validity = data.frame(), direct_effects = data.frame(),
    indirect_effects = data.frame(), total_effects = data.frame(), r_squared = data.frame(), residuals = data.frame(),
    modification_indices = data.frame(), basis_set = data.frame(), d_sep = data.frame(), fisher_c = data.frame(), component_diagnostics = data.frame(),
    composite_construction = data.frame(), composite_code = character(),
    outer_model = data.frame(), inner_model = data.frame(), construct_scores = data.frame(), bootstrap_results = data.frame(),
    goodness_of_fit = data.frame(), collinearity = data.frame(), dummy_encoding = data.frame(),
    predictions = data.frame(), candidate_models = data.frame(), model_comparison = data.frame(), warnings = character(), errors = character(),
    package_versions = data.frame(), execution_metrics = list(fit_count = 1L), generated_code = "", available_outputs = character(),
    available_plots = character(), registration_manifest = list())
  additions <- list(...)
  defaults[names(additions)] <- additions
  values <- defaults
  structure(values, class = c("sem_result", "list"))
}

sem_rows_to_table <- function(rows, template) {
  if (is.null(rows) || !length(rows)) return(template)
  frame <- jsonlite::fromJSON(jsonlite::toJSON(rows, auto_unbox = TRUE, null = "null"), simplifyDataFrame = TRUE)
  frame <- as.data.frame(frame, stringsAsFactors = FALSE, check.names = FALSE)
  for (name in setdiff(names(template), names(frame))) {
    prototype <- template[[name]]
    frame[[name]] <- if (is.list(prototype)) rep(list(character()), nrow(frame)) else if (is.logical(prototype)) FALSE else if (is.numeric(prototype)) NA_real_ else if (is.integer(prototype)) NA_integer_ else ""
  }
  # Keep versioned editor metadata (for example visual styling and bend
  # points) while still normalizing every required analytical field.
  frame[, c(names(template), setdiff(names(frame), names(template))), drop = FALSE]
}

sem_model_spec_from_payload <- function(payload) {
  if (is.null(payload) || !is.list(payload)) stop("Invalid editor model payload.", call. = FALSE)
  nodes <- sem_rows_to_table(payload$nodes, sem_node_table())
  edges <- sem_rows_to_table(payload$edges, sem_edge_table())
  spec <- new_sem_model_spec(payload$method %||% "covariance_sem", nodes, edges,
    model_name = payload$model_name %||% "Editor model", data_version = payload$data_version %||% "",
    constraints = payload$constraints %||% list(), model_options = payload$model_options %||% list(),
    revision = as.integer(payload$revision %||% 1L), parent_revision = payload$parent_revision %||% NA_integer_,
    provenance = payload$provenance %||% list(source = "editor"))
  spec$model_id <- payload$model_id %||% spec$model_id
  spec$created_at <- payload$created_at %||% spec$created_at
  spec$updated_at <- payload$updated_at %||% spec$updated_at
  check <- validate_sem_model_spec(spec)
  if (!check$valid) stop(paste(check$errors, collapse = "; "), call. = FALSE)
  spec
}
