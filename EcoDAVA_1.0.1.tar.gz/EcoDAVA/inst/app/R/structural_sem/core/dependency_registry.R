sem_package_registry <- function() {
  data.frame(
    package = c("lavaan", "piecewiseSEM", "plspm", "lme4", "nlme", "glmmTMB", "mgcv",
      "broom", "broom.mixed", "parameters", "performance", "insight", "ggplot2", "igraph",
      "jsonlite", "htmltools", "semTools", "tidySEM", "semPlot", "qgraph", "ggraph", "patchwork",
      "cSEM", "seminr", "MVN", "psych", "effectsize", "car", "DHARMa"),
    tier = c(rep("core", 3), rep("standard", 13), rep("optional", 13)),
    feature = c("CB-SEM", "piecewise SEM", "PLS-PM", "mixed components", "mixed components",
      "non-Gaussian mixed components", "smooth components", "model tidying", "mixed model tidying",
      "parameter formatting", "diagnostics", "model inspection", "plots", "graph operations", "JSON model spec",
      "local UI resources", "reliability and invariance", "SEM plotting", "SEM plotting", "SEM plotting",
      "graph plotting", "plot composition", "advanced composite SEM", "advanced PLS-SEM", "multivariate normality",
      "reliability", "effect sizes", "collinearity", "simulated residuals"),
    startup_required = FALSE, stringsAsFactors = FALSE)
}

sem_package_status <- function(packages = sem_package_registry()$package) {
  data.frame(package = packages, installed = vapply(packages, requireNamespace, logical(1), quietly = TRUE), stringsAsFactors = FALSE)
}

sem_method_dependency_status <- function(method_id) {
  row <- SEM_METHOD_REGISTRY[SEM_METHOD_REGISTRY$id == method_id, , drop = FALSE]
  packages <- strsplit(row$required_packages[[1]], ",", fixed = TRUE)[[1]]
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  list(available = !length(missing), missing = missing,
    install_command = if (length(missing)) sprintf("install.packages(c(%s))", paste(sprintf("'%s'", missing), collapse = ", ")) else "")
}
