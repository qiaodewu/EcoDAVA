sem_editor_dependency <- function() {
  htmltools::htmlDependency("dava-sem-builder", "1.2.6", src = c(href = "structural_sem"),
    script = c("vendor/cytoscape-3.34.0.min.js", "vendor/lodash-4.17.21.min.js",
      "vendor/cytoscape-edgehandles-4.0.1.js",
      "vendor/cytoscape-undo-redo-1.3.3.js", "vendor/cytoscape-context-menus-4.2.1.js",
      "vendor/cytoscape-grid-guide-2.3.3.js", "vendor/konva-7.2.5.min.js",
      "vendor/cytoscape-node-editing-4.1.1.js", "vendor/cytoscape-edge-editing-5.0.0.js",
      "sem-builder-loader-v1.2.6.js"), stylesheet = "sem-builder-style-v1.2.3.css?v=20260909-2")
}

sem_builder_ui <- function(id, input_id, variables, spec, template_input_id = NULL, template_action_id = NULL,
    new_model_id = NULL, save_revision_id = NULL, document_controls = NULL, templates = sem_template_registry(),
    language = "en") {
  language <- dava_i18n_language(language)
  if (is.data.frame(templates) && "label" %in% names(templates)) {
    templates$label <- dava_translate_composed(templates$label, language)
  }
  htmltools::attachDependencies(
    shiny::tags$div(id = id, class = paste("dava-sem-builder", if (isTRUE(spec$provenance$result_overlay)) "dava-sem-result-builder dava-sem-layout-editor" else ""), `data-input-id` = input_id,
      `data-template-input-id` = template_input_id %||% "", `data-template-action-id` = template_action_id %||% "",
      `data-new-model-id` = new_model_id %||% "",
      `data-save-revision-id` = save_revision_id %||% "",
      `data-language` = language,
      `data-templates` = jsonlite::toJSON(templates, dataframe = "rows", auto_unbox = TRUE),
      `data-variables` = jsonlite::toJSON(variables, auto_unbox = TRUE),
      `data-initial` = jsonlite::toJSON(unclass(spec), dataframe = "rows", auto_unbox = TRUE, null = "null"),
      shiny::div(class = "dava-sem-document-controls", `data-sem-document-controls` = "", document_controls)),
    sem_editor_dependency())
}

sem_result_layout_editor_ui <- function(id, input_id, spec, language = "en") {
  sem_builder_ui(id, input_id, character(), spec,
    templates = sem_template_registry()[0, , drop = FALSE], language = language)
}

sem_model_message_payload <- function(spec) {
  jsonlite::fromJSON(jsonlite::toJSON(unclass(spec), dataframe = "rows", auto_unbox = TRUE, null = "null"),
    simplifyVector = FALSE)
}

sem_method_choices <- function() stats::setNames(SEM_METHOD_REGISTRY$id, SEM_METHOD_REGISTRY$label_cn)

sem_covariance_from_data <- function(data, variables) {
  variables <- intersect(variables, names(data))
  if (length(variables) < 2L) stop("The covariance matrix requires at least two numeric variables.", call. = FALSE)
  if (!all(vapply(data[variables], is.numeric, logical(1)))) stop("The covariance matrix variable must be numeric.", call. = FALSE)
  stats::cov(data[variables], use = "pairwise.complete.obs")
}

sem_covariance_from_table <- function(data) {
  data <- as.data.frame(data, check.names = FALSE)
  labels <- NULL
  if (ncol(data) == nrow(data) + 1L && !is.numeric(data[[1]])) {
    labels <- as.character(data[[1]])
    data <- data[-1]
  }
  if (nrow(data) != ncol(data) || !all(vapply(data, is.numeric, logical(1))))
    stop("The current data set is not a valid square numeric covariance matrix.", call. = FALSE)
  covariance <- as.matrix(data)
  labels <- labels %||% colnames(covariance)
  rownames(covariance) <- labels
  colnames(covariance) <- labels
  covariance
}

sem_data_screening_nav <- function(ns, numeric_variables) {
  default_variables <- intersect(c("SoilC", "SoilN", "SoilP", "Plant1", "Plant2", "Microbial",
    "BacterialShannon", "FungalShannon", "Function", "CO2Flux"), numeric_variables)
  if (length(default_variables) < 3L) default_variables <- utils::head(numeric_variables, 10L)
  default_response <- if ("Function" %in% numeric_variables) "Function" else utils::tail(default_variables, 1L)
  default_community <- intersect(c("BacterialShannon", "FungalShannon", "Microbial", "Function"), default_variables)
  bslib::nav_panel("Data pre-inspection and screening", value = "data_screening",
    bslib::layout_columns(col_widths = c(4, 4, 4),
      shiny::selectizeInput(ns("screen_variables"), "Testing and filtering variables", numeric_variables,
        selected = default_variables, multiple = TRUE),
      shiny::selectInput(ns("screen_response"), "Core response variables", numeric_variables, selected = default_response),
      shiny::selectizeInput(ns("screen_community"), "RDA/CCA response variable group", numeric_variables,
        selected = default_community, multiple = TRUE),
      shiny::numericInput(ns("screen_correlation_threshold"), "Lowest average absolute correlation", 0.1, min = 0, max = 1, step = 0.05),
      shiny::numericInput(ns("screen_vif_threshold"), "VIF culling threshold", 5, min = 1, max = 100, step = 0.5),
      shiny::selectInput(ns("screen_ordination_method"), "Environmental interpretation method", c("RDA" = "rda", "CCA" = "cca")),
      shiny::numericInput(ns("screen_permutations"), "Number of replacements", 999, min = 99, max = 9999, step = 100),
      shiny::numericInput(ns("screen_seed"), "Random seed", 20260717, min = 1, step = 1),
      shiny::div(shiny::actionButton(ns("run_screening"), "Run pretest", class = "btn-primary w-100"))),
    shiny::uiOutput(ns("screening_status")),
    bslib::navset_card_tab(
      bslib::nav_panel("Normality", DT::DTOutput(ns("screen_normality"))),
      bslib::nav_panel("Related filters", DT::DTOutput(ns("screen_correlation")), DT::DTOutput(ns("screen_correlation_matrix"))),
      bslib::nav_panel("VIF", DT::DTOutput(ns("screen_vif"))),
      bslib::nav_panel("Random Forest", DT::DTOutput(ns("screen_rf"))),
      bslib::nav_panel("PCA", DT::DTOutput(ns("screen_pca")), DT::DTOutput(ns("screen_pca_loadings"))),
      bslib::nav_panel("RDA/CCA", DT::DTOutput(ns("screen_ordination")), DT::DTOutput(ns("screen_ordination_test"))),
      bslib::nav_panel("Related pictures", shiny::plotOutput(ns("screen_pairs_plot"), height = "700px"))
    ))
}

mod_structural_sem_ui <- function(id, navigation_alias = "sem") {
  ns <- shiny::NS(id)
  bslib::page_sidebar(
    title = NULL,
    sidebar = bslib::sidebar(width = 330,
      shiny::selectInput(ns("method"), "Model method", sem_method_choices(), selected = sem_method_from_alias(navigation_alias)),
      shiny::selectInput(ns("dataset"), "data set", c("Grassland ecological SEM simulation data" = ".__sem_demo__")),
      dava_dependency_button_ui(ns),
      shiny::uiOutput(ns("dependency_status")),
      shiny::uiOutput(ns("cb_sidebar")),
      shiny::uiOutput(ns("cb_run_control")),
      shiny::uiOutput(ns("legacy_sidebar_controls"))),
    bslib::navset_card_tab(id = ns("sem_results_nav"),
      bslib::nav_panel("Priori model construction", value = "prior_model", shiny::uiOutput(ns("builder"))),
      bslib::nav_panel("Data", value = "raw_data",
        bslib::navset_tab(
          bslib::nav_panel("Raw data", DT::DTOutput(ns("raw_data_table"))),
          bslib::nav_panel("Model building data", DT::DTOutput(ns("model_build_data_table")))
        )),
      bslib::nav_panel("Data Suitability", DT::DTOutput(ns("adequacy"))),
      bslib::nav_panel("Model Overview", DT::DTOutput(ns("overview"))),
      bslib::nav_panel("Results", shiny::uiOutput(ns("result_selector")), DT::DTOutput(ns("result_table"))),
      bslib::nav_panel("Model text", shiny::verbatimTextOutput(ns("model_text"))),
      bslib::nav_panel("Plots",
        shiny::uiOutput(ns("final_plot_status")),
        bslib::navset_tab(
          bslib::nav_panel("Roadmap", shiny::uiOutput(ns("result_model_builder"))),
          bslib::nav_panel("Effect diagram", shiny::plotOutput(ns("effect_plot"), height = "640px"))
        ),
        shiny::div(class = "dava-sem-plot-export-actions",
          shiny::actionButton(ns("download_png"), "PNG", class = "btn btn-success btn-sm"),
          shiny::actionButton(ns("download_svg"), "SVG", class = "btn btn-outline-success btn-sm"),
          shiny::actionButton(ns("download_pdf"), "PDF", class = "btn btn-outline-success btn-sm"),
          shiny::actionButton(ns("download_tiff"), "TIFF", class = "btn btn-outline-success btn-sm"),
          shiny::actionButton(ns("copy_path_to_svgedit"), "Copy path diagram to SVG editor", class = "btn btn-outline-primary btn-sm"))),
      bslib::nav_panel("Model optimization and adjustment",
        shiny::div(class = "alert alert-warning py-2", "Optimization suggestions are for manual review only; the system does not automatically delete paths, metrics, or refit."),
        shiny::verbatimTextOutput(ns("optimization_summary")),
        shiny::uiOutput(ns("optimization_controls")),
        shiny::uiOutput(ns("optimization_selector")),
        DT::DTOutput(ns("optimization_table")),
        shiny::verbatimTextOutput(ns("optimization_status"))),
      bslib::nav_panel("R Markdown code document", dava_module_code_panel_ui(ns)),
      bslib::nav_panel("Warnings and Errors", shiny::verbatimTextOutput(ns("messages")))
    ))
}

sem_result_tables <- function(result) {
  fields <- c("data_adequacy", "fit_measures", "parameter_estimates", "standardized_estimates", "measurement_results", "variance_diagnostics",
    "structural_results", "reliability", "convergent_validity", "discriminant_validity", "basis_set", "direct_effects",
    "indirect_effects", "total_effects", "r_squared", "residuals", "modification_indices", "d_sep", "fisher_c",
    "component_diagnostics", "composite_construction", "goodness_of_fit", "outer_model", "inner_model",
    "construct_scores", "collinearity", "dummy_encoding", "bootstrap_results", "model_comparison")
  values <- stats::setNames(lapply(fields, function(field) result[[field]]), fields)
  Filter(function(value) is.data.frame(value) && nrow(value), values)
}

dava_sem_custom_result <- function(run, method, spec, code = "") {
  dava_custom_run_assert(run)
  value <- if (inherits(run$value, "sem_result")) run$value else
    dava_custom_run_find(run, c("result", "sem_result", "fit_result"),
      function(object) inherits(object, "sem_result"))
  if (is.null(value)) {
    stop(paste(
      "Structural equation model custom code must return sem_result.",
      "Please use new_sem_result() or sem_fit() to build the complete result object."
    ), call. = FALSE)
  }
  value$method <- method %||% value$method
  value$prior_model_spec <- value$prior_model_spec %||% spec
  value$final_model_spec <- value$final_model_spec %||% spec
  value$generated_code <- code %||% value$generated_code
  value
}

mod_structural_sem_server <- function(id, file_data, navigation_alias = "sem") {
  shiny::moduleServer(id, function(input, output, session) {
    root_input <- session$rootScope()$input
    interface_language <- shiny::reactive({
      root_input$dava_interface_language
      dava_i18n_language(root_input$dava_interface_language)
    })
    default_method <- sem_method_from_alias(navigation_alias)
    sem_dependency_packages <- shiny::reactive({
      method <- input$method %||% default_method
      row <- SEM_METHOD_REGISTRY[SEM_METHOD_REGISTRY$id == method, , drop = FALSE]
      specialized <- if (nrow(row)) trimws(unlist(strsplit(
        row$required_packages[[1]] %||% "", ",", fixed = TRUE))) else character()
      unique(c("stats", "ggplot2", "dplyr", "broom", "patchwork",
        specialized[nzchar(specialized)]))
    })
    dava_bind_dependency_checker(
      input, session, packages = sem_dependency_packages,
      method_label = function() {
        method <- input$method %||% default_method
        row <- SEM_METHOD_REGISTRY[SEM_METHOD_REGISTRY$id == method, , drop = FALSE]
        if (nrow(row)) row$label_cn[[1]] else method
      })
    initial_spec <- if (identical(default_method, "covariance_sem"))
      sem_model_template("cbsem_observed", default_method) else sem_demo_prior_spec(default_method)
    current_spec <- shiny::reactiveVal(initial_spec)
    component_models <- shiny::reactiveVal(if (default_method == "piecewise_sem")
      sem_piecewise_components_from_spec(initial_spec) else list())
    composite_values <- shiny::reactiveVal(list())
    composite_records <- shiny::reactiveVal(list())
    composite_validation <- shiny::reactiveVal(NULL)
    revisions <- shiny::reactiveVal(list(initial_spec))
    fit_count <- shiny::reactiveVal(0L)
    analysis_generation <- shiny::reactiveVal(0L)
    stale <- shiny::reactiveVal(FALSE)
    last_error <- shiny::reactiveVal("")
    plot_runtime_diagnostics <- shiny::reactiveVal(character())
    record_plot_runtime_diagnostics <- function(captured, source = "SEM plot") {
      entries <- dava_plot_condition_text(captured, source)
      if (!length(entries)) return(invisible(NULL))
      plot_runtime_diagnostics(unique(c(shiny::isolate(plot_runtime_diagnostics()), entries)))
      invisible(entries)
    }
    local_diagnostic <- shiny::reactiveVal(NULL)
    result_editor_spec <- shiny::reactiveVal(NULL)
    result_editor_generation <- shiny::reactiveVal(0L)
    formula_status <- shiny::reactiveVal(list(type = "muted", text = "Formulas and model diagrams can be edited separately and synchronized after clicking the button"))
    cb_sidebar_state <- shiny::reactiveVal(list(template_id = "continuous_path", user_overrides = list()))
    cb_validation_requested <- shiny::reactiveVal(0L)
    cb_normality_state <- shiny::reactiveVal("unknown")
    reset_analysis_state <- function() {
      composite_values(list()); composite_records(list()); composite_validation(NULL)
      fit_count(0L); analysis_generation(analysis_generation() + 1L); stale(TRUE); last_error("")
      local_diagnostic(NULL); result_editor_spec(NULL)
      result_editor_generation(result_editor_generation() + 1L)
    }

    serialize_component_models <- function(models) lapply(models, function(model) list(
      name = model$name, composite = model$composite %||% "", response = model$response %||% all.vars(model$formula)[[1]],
      formula = paste(deparse(model$formula), collapse = ""), engine = model$engine %||% "lm",
      family = model$family %||% "gaussian", random_intercept = model$random_intercept %||% "",
      random_structure = model$random_structure %||% "block", random_slope = model$random_slope %||% character(),
      slope_group = model$slope_group %||% "", zero_group = model$zero_group %||% "",
      reml = isTRUE(model$reml), locked = isTRUE(model$locked)))
    restore_component_models <- function(spec) {
      saved <- spec$model_options$piecewise_components %||% list()
      if (!length(saved)) return(sem_piecewise_components_from_spec(spec))
      models <- lapply(saved, function(model) {
        model$formula <- stats::as.formula(model$formula)
        model$random_slope <- unlist(model$random_slope %||% character(), use.names = FALSE)
        model
      })
      stats::setNames(models, vapply(models, `[[`, character(1), "name"))
    }
    rebuild_piecewise_components <- function(spec) {
      defaults <- sem_piecewise_components_from_spec(spec)
      saved <- restore_component_models(spec)
      if (!length(defaults)) return(list())
      responses <- names(defaults)
      matched <- lapply(responses, function(response) {
        index <- which(vapply(saved, function(model) identical(model$response %||% all.vars(model$formula)[[1]], response), logical(1)))
        if (length(index)) {
          model <- saved[[index[[1]]]]
          model$response <- response
          model$formula <- defaults[[response]]$formula
          model$name <- model$name %||% defaults[[response]]$name
          model
        } else defaults[[response]]
      })
      stats::setNames(matched, vapply(matched, `[[`, character(1), "name"))
    }
    reset_piecewise_local_selection <- function(spec) {
      directed <- spec$edges[spec$edges$active & spec$edges$edge_type == "directed_path", , drop = FALSE]
      if (!nrow(directed)) return(invisible(NULL))
      node_names <- stats::setNames(vapply(spec$nodes$id, sem_node_variable, character(1), spec = spec), spec$nodes$id)
      endogenous <- unique(unname(node_names[directed$target]))
      if (length(endogenous)) shiny::updateSelectInput(session, "piecewise_endogenous", choices = endogenous, selected = endogenous[[1]])
      invisible(endogenous)
    }
    persist_component_models <- function(models) {
      spec <- current_spec(); spec$model_options$piecewise_components <- serialize_component_models(models)
      current_spec(spec); invisible(spec)
    }

    push_revision <- function(spec) {
      history <- revisions()
      spec$parent_revision <- if (length(history)) history[[length(history)]]$revision else NA_integer_
      spec$revision <- if (length(history)) max(vapply(history, function(item) item$revision, integer(1))) + 1L else 1L
      spec$updated_at <- format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
      revisions(c(history, list(spec)))
      current_spec(spec)
      spec
    }
    shiny::observe({
      history <- Filter(function(item) identical(item$method, current_spec()$method), revisions())
      labels <- vapply(history, function(spec) sprintf("v%d · %s", spec$revision, spec$model_name), character(1))
      selected <- as.character(current_spec()$revision)
      shiny::updateSelectInput(session, "revision", choices = stats::setNames(vapply(history, function(spec) as.character(spec$revision), character(1)), labels), selected = selected)
    })

    dataset_names <- shiny::reactive(dava_global_dataset_names(file_data))
    shiny::observe({
      choices <- c("Grassland ecological SEM simulation data" = ".__sem_demo__", stats::setNames(dataset_names(), dataset_names()))
      selected <- shiny::isolate(input$dataset) %||% ".__sem_demo__"
      if (!is.null(shiny::isolate(input$dataset))) shiny::freezeReactiveValue(input, "dataset")
      shiny::updateSelectInput(session, "dataset", choices = choices, selected = selected)
    })

    raw_data <- shiny::reactive({
      if (identical(input$dataset %||% ".__sem_demo__", ".__sem_demo__")) sem_demo_data()
      else as.data.frame(file_data$global_datasets[[input$dataset]], stringsAsFactors = FALSE, check.names = FALSE)
    })
    cb_model_summary <- shiny::reactive({
      if (!identical(input$method %||% default_method, "covariance_sem")) return(NULL)
      sem_cbsem_model_summary(current_spec())
    })
    cb_data_profile <- shiny::reactive({
      if (!identical(input$method %||% default_method, "covariance_sem")) return(NULL)
      profile <- sem_cbsem_data_profile(raw_data(), current_spec())
      profile$normality <- cb_normality_state()
      profile
    })
    cb_context <- shiny::reactive({
      list(group = input$cb_group_variable %||% "", group_levels = input$cb_group_levels %||% character(),
        group_strategy = input$cb_group_target %||% NULL,
        has_mean_vector = isTRUE(input$cb_include_means), sample_size = as.integer(input$cb_sample_size %||% cb_data_profile()$rows))
    })
    cb_sidebar_snapshot <- shiny::reactive({
      if (!identical(input$method %||% default_method, "covariance_sem")) return(NULL)
      state <- cb_sidebar_state(); profile <- cb_data_profile(); summary <- cb_model_summary()
      sem_cbsem_normalize_sidebar(state$template_id, profile, summary, state$user_overrides, cb_context())
    })
    cb_group_diagnostics <- shiny::reactive({
      snapshot <- cb_sidebar_snapshot(); if (is.null(snapshot) || !nzchar(snapshot$values$group %||% "")) return(data.frame())
      sem_cbsem_group_diagnostics(raw_data(), snapshot$values$group, snapshot$values$group_levels, cb_data_profile()$model_variables)
    })
    cb_matrix_status <- shiny::reactive({
      snapshot <- cb_sidebar_snapshot()
      if (is.null(snapshot) || !isTRUE(snapshot$capabilities$covariance_input)) return(NULL)
      sem_cbsem_covariance_status(raw_data(), input$cb_covariance_source %||% "derive",
        input$cb_covariance_variables %||% cb_data_profile()$numeric,
        snapshot$values$sample_size, snapshot$values$include_means, input$cb_mean_vector_text %||% "")
    })
    cb_sidebar_validation <- shiny::reactive({
      snapshot <- cb_sidebar_snapshot(); if (is.null(snapshot)) return(list(valid = TRUE, errors = character(), warnings = character(), suggestions = character()))
      sem_cbsem_validate_sidebar(snapshot, cb_data_profile(), cb_model_summary(), cb_group_diagnostics(), cb_matrix_status())
    })
    shiny::observeEvent(input$cb_template, {
      if (!identical(input$method %||% default_method, "covariance_sem")) return()
      state <- cb_sidebar_state(); selected <- input$cb_template %||% state$template_id
      if (!selected %in% names(sem_cbsem_sidebar_templates())) selected <- "continuous_path"
      if (!identical(selected, state$template_id)) {
        candidate <- sem_cbsem_normalize_sidebar(selected, cb_data_profile(), cb_model_summary(), state$user_overrides, cb_context())
        compatible <- state$user_overrides[setdiff(names(state$user_overrides), candidate$cleared)]
        cb_sidebar_state(list(template_id = selected, user_overrides = compatible))
        if (length(candidate$cleared)) shiny::showNotification(
          paste("Cleaned up incompatible settings:", paste(candidate$cleared, collapse = "、")), type = "warning")
        stale(TRUE); last_error("")
      }
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$dataset, {
      if (!identical(input$method %||% default_method, "covariance_sem")) return()
      state <- cb_sidebar_state()
      candidate <- sem_cbsem_normalize_sidebar(state$template_id, cb_data_profile(), cb_model_summary(),
        state$user_overrides, cb_context())
      compatible <- state$user_overrides[setdiff(names(state$user_overrides), candidate$cleared)]
      cb_sidebar_state(list(template_id = state$template_id, user_overrides = compatible))
      if (length(candidate$cleared)) shiny::showNotification(
        paste("Incompatible settings have been cleaned up after data set switching:", paste(candidate$cleared, collapse = "、")), type = "warning")
      cb_normality_state("unknown")
      stale(TRUE)
    }, ignoreInit = TRUE)
    source_data_code_name <- shiny::reactive({
      if (identical(input$dataset %||% ".__sem_demo__", ".__sem_demo__")) "grass_data" else make.names(input$dataset)
    })
    analysis_data_code_name <- shiny::reactive({
      if (isTRUE(input$data_standardization)) "grass_std" else source_data_code_name()
    })
    standardization_code <- shiny::reactive({
      if (!isTRUE(input$data_standardization)) return(character())
      c("# Standardize numeric variables",
        sprintf("grass_std <- as.data.frame(lapply(%s, function(x) if (is.numeric(x)) as.numeric(scale(x)) else x))",
          source_data_code_name()))
    })
    analysis_base_data <- shiny::reactive({
      data <- raw_data()
      if (isTRUE(input$data_standardization)) sem_standardize_numeric_data(data) else data
    })
    screening_nav_inserted <- shiny::reactiveVal(FALSE)
    shiny::observeEvent(input$enable_data_screening, {
      if (isTRUE(input$enable_data_screening) && !screening_nav_inserted()) {
        numeric_variables <- names(raw_data())[vapply(raw_data(), is.numeric, logical(1))]
        bslib::nav_insert("sem_results_nav", sem_data_screening_nav(session$ns, numeric_variables),
          target = "raw_data", position = "after", session = session)
        screening_nav_inserted(TRUE)
      } else if (!isTRUE(input$enable_data_screening) && screening_nav_inserted()) {
        bslib::nav_remove("sem_results_nav", target = "data_screening", session = session)
        screening_nav_inserted(FALSE)
      }
    }, ignoreInit = FALSE)
    data_bundle <- shiny::reactive({
      method <- input$method %||% default_method
      cb_values <- if (identical(method, "covariance_sem")) cb_sidebar_snapshot()$values else list()
      if (method == "covariance_sem" && identical(cb_values$input_type, "covariance_matrix")) {
        direct_matrix <- identical(input$cb_covariance_source %||% "derive", "matrix")
        if (direct_matrix) covariance <- sem_covariance_from_table(raw_data()) else {
          source_data <- analysis_base_data()
          numeric_names <- names(source_data)[vapply(source_data, is.numeric, logical(1))]
          variables <- input$cb_covariance_variables %||% intersect(c("Soil1", "Soil2", "Plant1", "Plant2", "Microbial", "Function"), numeric_names)
          covariance <- sem_covariance_from_data(source_data, variables)
        }
        means <- NULL
        if (isTRUE(cb_values$include_means)) {
          if (!direct_matrix) means <- colMeans(analysis_base_data()[colnames(covariance)], na.rm = TRUE)
          else {
            parsed <- suppressWarnings(as.numeric(trimws(strsplit(input$cb_mean_vector_text %||% "", ",", fixed = TRUE)[[1]])))
            if (length(parsed) == ncol(covariance) && all(is.finite(parsed))) means <- stats::setNames(parsed, colnames(covariance))
          }
        }
        return(new_sem_covariance_bundle(input$dataset %||% ".__sem_demo__", covariance,
          sample_size = as.integer(cb_values$sample_size %||% nrow(raw_data())), sample_means = means))
      }
      analysis_data <- analysis_base_data()
      if (identical(method, "piecewise_sem")) {
        composite_nodes <- current_spec()$nodes[current_spec()$nodes$node_type == "composite_construct", , drop = FALSE]
        for (index in seq_len(nrow(composite_nodes))) {
          construct <- composite_nodes$construct_name[[index]] %||% composite_nodes$label[[index]]
          indicators <- composite_nodes$indicator_variables[[index]] %||% character()
          if (nzchar(construct) && length(indicators) >= 2L && all(indicators %in% names(analysis_data)) && !construct %in% names(analysis_data))
            analysis_data[[construct]] <- rowMeans(analysis_data[, indicators, drop = FALSE], na.rm = TRUE)
        }
      }
      for (name in names(composite_values())) analysis_data[[name]] <- composite_values()[[name]]
      new_sem_data_bundle(input$dataset %||% ".__sem_demo__", analysis_data,
        row_id = if (identical(method, "covariance_sem")) "" else if ("SampleID" %in% names(analysis_data)) "SampleID" else "",
        group_variable = if (identical(method, "covariance_sem")) cb_values$group %||% "" else input$group %||% "", cluster_variable = "",
        ordered_variables = if (identical(method, "covariance_sem")) cb_values$ordered %||% character() else input$ordered %||% character())
    })
    model_build_data <- shiny::reactive({
      bundle <- data_bundle()
      if (inherits(bundle, "sem_data_bundle")) bundle$data else raw_data()
    })

    shiny::observeEvent(input$method, {
      method <- input$method %||% default_method
      if (!identical(current_spec()$method, method)) {
        next_spec <- if (identical(method, "covariance_sem")) sem_model_template("cbsem_observed", method) else sem_demo_prior_spec(method)
        current_spec(next_spec)
        if (identical(method, "pls_pm")) revisions(list(next_spec)) else revisions(c(revisions(), list(next_spec)))
        reset_analysis_state()
        component_models(if (method == "piecewise_sem") rebuild_piecewise_components(current_spec()) else list())
        if (identical(method, "pls_pm")) {
          shiny::updateSelectInput(session, "dataset", selected = next_spec$provenance$dataset_id %||% ".__sem_demo__")
        }
      }
      update_formula_from_graph(sprintf("%s model formula has been initialized", method))
    }, ignoreInit = FALSE)

    shiny::observeEvent(input$new_model, {
      spec <- new_sem_model_spec(input$method %||% default_method, model_name = "Untitled prior model", provenance = list(source = "blank"))
      spec <- push_revision(spec); stale(TRUE); last_error("")
      session$sendCustomMessage("sem-builder-load", list(id = session$ns("model_builder"), model_spec = sem_model_message_payload(spec)))
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$load_template, {
      method <- input$method %||% default_method
      template_id <- input$template %||% if (identical(method, "piecewise_sem")) "piecewise_observed" else
        if (identical(method, "covariance_sem")) "cbsem_observed" else "plspm_grassland"
      if (identical(method, "covariance_sem") || identical(method, "pls_pm")) {
        spec <- sem_model_template(template_id, method)
        spec$revision <- 1L
        spec$parent_revision <- NA_integer_
        revisions(list(spec))
        current_spec(spec)
        template_dataset <- spec$provenance$dataset_id %||% ".__sem_demo__"
        shiny::updateSelectInput(session, "dataset", selected = template_dataset)
      } else spec <- push_revision(sem_model_template(template_id, method))
      reset_analysis_state()
      if (identical(method, "piecewise_sem")) component_models(rebuild_piecewise_components(spec)) else component_models(list())
      if (identical(method, "piecewise_sem")) reset_piecewise_local_selection(spec)
      stale(TRUE); last_error("")
      session$sendCustomMessage("sem-builder-load", list(id = session$ns("model_builder"), model_spec = sem_model_message_payload(spec)))
      if (identical(method, "piecewise_sem")) sync_imported_piecewise_formula("The model formula has been initialized according to the piecewiseSEM special template")
      else if (identical(method, "pls_pm")) update_formula_from_graph("Cleared old status and initialized by PLS-SEM dedicated template")
      else update_formula_from_graph("The model formula has been initialized according to the current prior model template")
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$save_revision, { push_revision(current_spec()); stale(TRUE) }, ignoreInit = TRUE)
    shiny::observeEvent(input$restore_revision, {
      selected <- as.integer(input$revision %||% NA_integer_)
      matches <- Filter(function(spec) identical(spec$revision, selected) && identical(spec$method, current_spec()$method), revisions())
      shiny::validate(shiny::need(length(matches), "The selected version was not found."))
      current_spec(matches[[1]]); reset_analysis_state(); if (identical(matches[[1]]$method, "piecewise_sem")) component_models(rebuild_piecewise_components(matches[[1]])) else component_models(list())
      if (identical(matches[[1]]$method, "piecewise_sem")) reset_piecewise_local_selection(matches[[1]])
      session$sendCustomMessage("sem-builder-load", list(id = session$ns("model_builder"), model_spec = sem_model_message_payload(matches[[1]])))
      sync_imported_piecewise_formula("Model formula initialized according to piecewiseSEM dedicated version")
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$import_model, {
      tryCatch({
        payload <- jsonlite::read_json(input$import_model$datapath, simplifyVector = FALSE)
        spec <- push_revision(sem_model_spec_from_payload(payload));
        reset_analysis_state()
        if (identical(spec$method, "piecewise_sem")) component_models(rebuild_piecewise_components(spec))
        else component_models(list())
        if (identical(spec$method, "piecewise_sem")) reset_piecewise_local_selection(spec)
        stale(TRUE); last_error("")
        session$sendCustomMessage("sem-builder-load", list(id = session$ns("model_builder"), model_spec = sem_model_message_payload(spec)))
        if (identical(spec$method, "piecewise_sem")) sync_imported_piecewise_formula("Model formula initialized by imported piecewiseSEM model")
      }, error = function(error) last_error(conditionMessage(error)))
    }, ignoreInit = TRUE)

    output$dependency_status <- shiny::renderUI({
      status <- sem_method_dependency_status(input$method %||% default_method)
      if (status$available) NULL
      else shiny::div(class = "alert alert-warning py-2", "Missing:", paste(status$missing, collapse = ", "),
        shiny::tags$pre(status$install_command))
    })
    output$legacy_sidebar_controls <- shiny::renderUI({
      method <- input$method %||% default_method
      if (identical(method, "covariance_sem")) return(NULL)
      standardization_value <- shiny::isolate(input$data_standardization)
      if (is.null(standardization_value)) standardization_value <- identical(method, "pls_pm")
      shiny::tagList(
        shiny::checkboxInput(session$ns("enable_data_screening"), "Data pre-inspection and screening", FALSE),
        shiny::checkboxInput(session$ns("data_standardization"), "Data normalization", isTRUE(standardization_value)),
        shiny::textAreaInput(session$ns("model_code"), "Model formula", rows = 12, width = "100%",
          placeholder = "Plant ~ Soil\nMicrobial ~ Soil + Plant\nSoil ~~ Treatment"),
        shiny::actionButton(session$ns("apply_model_formula"), "Apply model formula", class = "btn-primary w-100 mb-1"),
        shiny::uiOutput(session$ns("formula_sync_status")),
        shiny::uiOutput(session$ns("method_options")),
        shiny::actionButton(session$ns("run"), "Run analysis", class = "btn-primary w-100"),
        shiny::actionButton(session$ns("register"), "Add to data table repository", icon = shiny::icon("plus"),
          title = "Add to data table repository", class = "btn-success w-100 mt-2"),
        shiny::downloadButton(session$ns("download_xlsx"), "Download analysis results table", icon = shiny::icon("download"), class = "btn-success w-100 mt-2"))
    })
    output$cb_sidebar <- shiny::renderUI({
      language <- interface_language()
      if (!identical(input$method %||% default_method, "covariance_sem")) return(NULL)
      state <- cb_sidebar_state(); snapshot <- cb_sidebar_snapshot(); template <- sem_cbsem_sidebar_template(state$template_id); profile <- cb_data_profile()
      validation <- cb_sidebar_validation()
      factor_names <- profile$group_candidates
      group_mode <- template$grouping
      data_section <- if (identical(template$input_type, "covariance_matrix")) shiny::tagList(
        shiny::selectInput(session$ns("cb_covariance_source"), "Matrix source",
          c("Calculated from current numerical data" = "derive", "The current data set is the covariance matrix" = "matrix"), "derive"),
        shiny::conditionalPanel(sprintf("input['%s'] === 'derive'", session$ns("cb_covariance_source")), ns = session$ns,
          shiny::selectizeInput(session$ns("cb_covariance_variables"), "Matrix variable", profile$numeric,
            selected = intersect(profile$numeric, shiny::isolate(input$cb_covariance_variables %||% profile$numeric)), multiple = TRUE)),
        shiny::numericInput(session$ns("cb_sample_size"), "Sample size", snapshot$values$sample_size, min = 2, step = 1),
        shiny::checkboxInput(session$ns("cb_include_means"), "provides the mean vector", isTRUE(snapshot$values$include_means)),
      shiny::conditionalPanel(sprintf("input['%s'] === true", session$ns("cb_include_means")), ns = session$ns,
          shiny::textInput(session$ns("cb_mean_vector_text"), "Mean vector (comma separated)", "")),
        shiny::uiOutput(session$ns("cb_matrix_status")),
        shiny::div(class = "small text-muted", "The covariance matrix scenario has hidden individual-level missingness, outliers, and distribution diagnostics.")) else shiny::tagList(
        shiny::div(class = "small text-muted mb-1", paste0(
          dava_translate_text("Current data set:", language),
          if (identical(input$dataset %||% ".__sem_demo__", ".__sem_demo__")) {
            dava_translate_text("Grassland ecological SEM simulation data", language)
          } else input$dataset
        )),
        shiny::checkboxInput(session$ns("enable_data_screening"), "Open the data inspection entrance", isTRUE(shiny::isolate(input$enable_data_screening))),
        shiny::checkboxInput(session$ns("data_standardization"), "Standardized numerical variable", isTRUE(shiny::isolate(input$data_standardization))),
        shiny::div(class = "small text-muted", dava_tr("Data scale: %d rows × %d columns; %d numerical variables; %d categorical variables; %d missing cells; distribution judgment: %s.", language,
          profile$rows, profile$columns, length(profile$numeric), length(profile$categorical), profile$missing_cells,
          dava_translate_text(switch(profile$normality, normal = "Approximately normal", non_normal = "Non-normal", "Not checked yet"), language))))
      group_section <- if (group_mode == "none") NULL else shiny::tagList(
        shiny::selectizeInput(session$ns("cb_group_variable"), "Grouping variables", c("Please select" = "", factor_names),
          selected = snapshot$values$group %||% "", options = list(placeholder = "Select grouping variable")),
        shiny::selectizeInput(session$ns("cb_group_levels"), "Effective level", character(), multiple = TRUE),
        shiny::selectInput(session$ns("cb_group_target"), "Comparison target", if (group_mode == "two")
          c("Compare structure paths" = "compare_paths", "Comparing latent variable means with structural paths" = "compare_means_paths") else
          c("Each group estimates independently" = "independent", "Compare structure paths" = "compare_paths", "Comparison after measuring invariance" = "invariance"),
          selected = snapshot$values$group_strategy),
        shiny::uiOutput(session$ns("cb_group_diagnostics")))
      shiny::tagList(
        shiny::div(class = "dava-sem-sidebar-section", shiny::tags$strong("Basic scenario"),
          shiny::selectInput(session$ns("cb_template"), "Analysis Template", stats::setNames(sem_cbsem_sidebar_template_table()$id,
            sem_cbsem_sidebar_template_table()$label), selected = state$template_id),
          shiny::div(class = "small text-muted", dava_translate_composed(template$description, language)),
          shiny::div(class = "small", paste0(
            dava_translate_text("Applicable data:", language), dava_translate_text(template$data_label, language),
            dava_translate_text(";Latent variable:", language), dava_translate_text(template$latent, language),
            dava_translate_text(";Group:", language), dava_translate_text(template$grouping, language),
            dava_translate_text(";Default estimate:", language), template$estimator))),
        shiny::div(class = "dava-sem-sidebar-section", shiny::tags$strong("Data source"), data_section),
        shiny::div(class = "dava-sem-sidebar-section", shiny::tags$strong("Model formula"),
          shiny::tags$style(shiny::HTML(sprintf("#%s {font-family: Consolas, 'Courier New', monospace; font-size: 13px; line-height: 1.45; white-space: pre;}",
            session$ns("model_code")))),
          shiny::textAreaInput(session$ns("model_code"), NULL,
            value = shiny::isolate(input$model_code %||% sem_graph_to_path_code(current_spec())),
            rows = 12, width = "100%"),
          shiny::actionButton(session$ns("apply_model_formula"), "Apply model formula", class = "btn-primary w-100 mb-1"),
          shiny::uiOutput(session$ns("formula_sync_status"))),
        if (!is.null(group_section)) shiny::div(class = "dava-sem-sidebar-section", shiny::tags$strong("Group settings"), group_section),
        shiny::div(class = "dava-sem-sidebar-section", shiny::tags$strong("Smart parameter summary"), shiny::uiOutput(session$ns("cb_parameter_summary"))),
        shiny::div(class = "dava-sem-sidebar-section", shiny::tags$strong("Check and run"), shiny::uiOutput(session$ns("cb_validation_summary")),
          shiny::div(class = "d-flex gap-1 flex-wrap", shiny::actionButton(session$ns("cb_advanced"), "Advanced settings", class = "btn-outline-secondary btn-sm"),
            shiny::actionButton(session$ns("cb_validate"), "Validation model", class = "btn-outline-info btn-sm"),
            shiny::actionButton(session$ns("cb_reset"), "Reset parameters", class = "btn-outline-danger btn-sm"))))
    })
    # Keep the CB-SEM run input outside the frequently re-rendered parameter
    # panel. Replacing an actionButton during the same reactive flush can drop
    # its first click before the fitting observer opens the progress UI.
    output$cb_run_control <- shiny::renderUI({
      if (!identical(input$method %||% default_method, "covariance_sem")) return(NULL)
      shiny::div(class = "dava-sem-sidebar-section pt-0",
        shiny::actionButton(session$ns("run"), "Run analysis", class = "btn-primary w-100"))
    })
    output$cb_matrix_status <- shiny::renderUI({
      status <- cb_matrix_status(); if (is.null(status)) return(NULL)
      shiny::div(class = paste("small alert py-1", if (status$valid) "alert-success" else "alert-danger"),
        if (status$valid) sprintf("Matrix verification passed: %d × %d.", status$dimension, status$dimension)
        else paste(status$errors, collapse = "；"),
        if (length(status$warnings)) shiny::div(class = "text-warning", paste(status$warnings, collapse = "；")))
    })
    output$cb_group_diagnostics <- shiny::renderUI({
      diagnostics <- cb_group_diagnostics(); if (!nrow(diagnostics)) return(shiny::div(class = "small text-muted", "Displays the sample size and validity of each group after selecting the grouping variable."))
      shiny::div(class = "small", paste(vapply(seq_len(nrow(diagnostics)), function(index)
        sprintf("%s: n=%d, missing=%d, zero variance=%s, %s", diagnostics$level[[index]], diagnostics$samples[[index]],
          diagnostics$missing_group[[index]], if (diagnostics$zero_variance[[index]]) "Yes" else "No",
          if (diagnostics$adequate[[index]]) "Basically satisfied" else "Sample size is low"), character(1)), collapse = "；"))
    })
    output$cb_parameter_summary <- shiny::renderUI({
      snapshot <- cb_sidebar_snapshot(); shiny::req(snapshot)
      names_to_show <- c("estimator", "missing", "identification", "meanstructure", "fixed_x", "parameterization", "group_strategy")
      labels <- c(estimator = "Estimator", missing = "Missing handling", identification = "Latent variable identification", meanstructure = "Mean structure",
        fixed_x = "Exogenous variable processing", parameterization = "Ordered parameterization", group_strategy = "Grouping strategy")
      rows <- lapply(names_to_show, function(name) {
        parameter <- snapshot$parameters[[name]]; value <- parameter$value
        if (length(value) > 1L) value <- paste(value, collapse = ", ")
        shiny::div(class = "small mb-1", shiny::tags$strong(labels[[name]]), "：", as.character(value),
          shiny::tags$span(class = "text-muted ms-1", paste0("[", parameter$source, "]")))
      })
      shiny::tagList(rows, if (length(snapshot$cleared)) shiny::div(class = "small text-warning", paste("Cleaned up incompatible settings:", paste(snapshot$cleared, collapse = "、"))))
    })
    output$cb_validation_summary <- shiny::renderUI({
      validation <- cb_sidebar_validation(); badge <- if (validation$valid) "success" else "danger"
      shiny::tagList(shiny::div(class = paste0("alert alert-", badge, " py-1 small"), if (validation$valid) "Current parameters can be entered into existing fitting entries." else paste(validation$errors, collapse = "；")),
        if (length(validation$warnings)) shiny::div(class = "small text-warning", paste("Warning:", paste(validation$warnings, collapse = "；"))),
        if (length(validation$suggestions)) shiny::div(class = "small text-muted", paste(validation$suggestions, collapse = "；")))
    })
    shiny::observe({
      if (!identical(input$method %||% default_method, "covariance_sem")) return()
      template <- sem_cbsem_sidebar_template(cb_sidebar_state()$template_id)
      if (identical(template$grouping, "none")) return()
      if (is.null(input$cb_group_variable) || is.null(input$cb_group_levels)) return()
      variable <- input$cb_group_variable %||% ""
      levels <- if (nzchar(variable) && variable %in% names(raw_data())) unique(as.character(raw_data()[[variable]][!is.na(raw_data()[[variable]])])) else character()
      selected <- intersect(shiny::isolate(input$cb_group_levels %||% character()), levels)
      shiny::freezeReactiveValue(input, "cb_group_levels")
      shiny::updateSelectizeInput(session, "cb_group_levels", choices = levels, selected = selected, server = TRUE)
    })
    shiny::observeEvent(input$cb_reset, {
      state <- cb_sidebar_state()
      cb_sidebar_state(list(template_id = state$template_id, user_overrides = list()))
      stale(TRUE); last_error("")
      shiny::showNotification("CB-SEM parameters have been reset.", type = "message")
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$cb_validate, {
      cb_validation_requested(cb_validation_requested() + 1L)
      validation <- cb_sidebar_validation()
      status_block <- function(title, values, class) shiny::tagList(shiny::tags$h5(title),
        if (length(values)) shiny::tags$ul(lapply(values, shiny::tags$li), class = class) else shiny::div(class = "text-muted", "None"))
      shiny::showModal(shiny::modalDialog(title = "CB-SEM Sidebar Verification", size = "l", easyClose = TRUE,
        status_block("blocking error", validation$errors, "text-danger"),
        status_block("Warning", validation$warnings, "text-warning"),
        status_block("Suggestions", validation$suggestions, "text-muted"),
        footer = shiny::modalButton("Close")))
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$cb_advanced, {
      snapshot <- cb_sidebar_snapshot(); values <- snapshot$values; capabilities <- snapshot$capabilities
      estimator_choices <- capabilities$estimators
      missing_choices <- stats::setNames(capabilities$missing, ifelse(capabilities$missing == "none", "Not applicable",
        ifelse(capabilities$missing == "pairwise", "Pairwise", ifelse(capabilities$missing == "fiml", "FIML", "Complete sample"))))
      output_choices <- c("Normalized results" = "standardized", "Confidence interval" = "ci", "R²" = "r_squared",
        "Direct and indirect effects" = "direct_indirect", "Factor loadings" = "loadings", "CR" = "cr", "AVE" = "ave",
        "Discriminant validity" = "discriminant", "Fitting index" = "fit_indices", "Correction index" = "modification_indices",
        "Residual" = "residuals", "Roadmap" = "path_plot")
      shiny::showModal(shiny::modalDialog(title = "CB-SEM Advanced Settings", size = "xl", easyClose = FALSE,
        bslib::navset_card_tab(
          bslib::nav_panel("Estimates and Missing",
            shiny::selectInput(session$ns("cb_adv_estimator"), "Estimator", estimator_choices, selected = values$estimator),
            shiny::selectInput(session$ns("cb_adv_missing"), "Missing handling", missing_choices, selected = values$missing),
            shiny::selectInput(session$ns("cb_adv_se"), "Standard error type", c("Standard" = "standard", "Robust" = "robust.huber.white", "Bootstrap" = "bootstrap"), selected = values$se),
            if (capabilities$bootstrap) shiny::checkboxInput(session$ns("cb_adv_bootstrap"), "Enable Bootstrap", isTRUE(values$bootstrap_enabled)),
            if (capabilities$bootstrap) shiny::numericInput(session$ns("cb_adv_bootstrap_samples"), "Bootstrap times", values$bootstrap_samples, min = 100, max = 10000),
            shiny::numericInput(session$ns("cb_adv_seed"), "Random seed", values$seed, min = 1)),
          if (capabilities$latent) bslib::nav_panel("Latent variable identification",
            shiny::selectInput(session$ns("cb_adv_identification"), "Identification method", c("Fixed latent variable variance" = "fixed_variance", "Fixed first load" = "marker"), values$identification),
            shiny::checkboxInput(session$ns("cb_adv_meanstructure"), "Mean structure", isTRUE(values$meanstructure)),
            shiny::selectInput(session$ns("cb_adv_fixed_x"), "Exogenous variable processing", c("Random exogenous variables" = "FALSE", "Fixed exogenous variables" = "TRUE"), as.character(isTRUE(values$fixed_x))),
            shiny::checkboxInput(session$ns("cb_adv_single_indicator"), "Allow single-index latent variable constraints", FALSE),
            shiny::checkboxInput(session$ns("cb_adv_two_indicator"), "Enable two-index latent variable identification constraints", cb_model_summary()$two_indicator > 0L)),
          if (capabilities$ordered || identical(snapshot$template$id, "ordered_binary")) bslib::nav_panel("Ordinal variable",
            shiny::selectizeInput(session$ns("cb_adv_ordered"), "Ordinal and binary variables", cb_data_profile()$ordered_candidates,
              selected = values$ordered, multiple = TRUE),
            shiny::textInput(session$ns("cb_adv_level_order"), "Horizontal sequence description", "By data factor level order"),
            shiny::selectInput(session$ns("cb_adv_parameterization"), "Parameterization", c("Theta" = "theta", "Delta" = "delta"), values$parameterization),
            if (length(cb_data_profile()$sparse_ordered)) shiny::div(class = "alert alert-warning py-1", paste("Sparsity level:", paste(cb_data_profile()$sparse_ordered, collapse = "、")))),
          if (!identical(capabilities$grouping, "none")) bslib::nav_panel("Multiple sets of constraints",
            shiny::selectizeInput(session$ns("cb_adv_group_levels"), "Group horizontal order", values$group_levels, selected = values$group_levels, multiple = TRUE),
            shiny::checkboxGroupInput(session$ns("cb_adv_group_equal"), "Equality constraints between groups", c("payload" = "loadings", "Intercept" = "intercepts", "Residual" = "residuals", "structure path" = "regressions")),
            shiny::textInput(session$ns("cb_adv_group_release"), "Partially releasing constraints", ""),
            shiny::selectInput(session$ns("cb_adv_reference_group"), "Reference Group", values$group_levels),
            shiny::checkboxInput(session$ns("cb_adv_compare_means"), "Compare latent variable means", identical(values$group_strategy, "compare_means_paths")),
            shiny::checkboxInput(session$ns("cb_adv_compare_paths"), "Compare structure paths", values$group_strategy %in% c("compare_paths", "compare_means_paths", "invariance"))),
          bslib::nav_panel("Output settings", shiny::checkboxGroupInput(session$ns("cb_adv_outputs"), "Output content", output_choices, selected = values$outputs))
        ),
        footer = shiny::tagList(shiny::modalButton("Cancel"), shiny::actionButton(session$ns("cb_apply_advanced"), "Apply advanced settings", class = "btn-primary"))))
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$cb_apply_advanced, {
      state <- cb_sidebar_state(); snapshot <- cb_sidebar_snapshot()
      bootstrap_enabled <- isTRUE(input$cb_adv_bootstrap) && isTRUE(snapshot$capabilities$bootstrap)
      overrides <- list(estimator = input$cb_adv_estimator %||% snapshot$values$estimator,
        missing = input$cb_adv_missing %||% snapshot$values$missing, se = input$cb_adv_se %||% snapshot$values$se,
        bootstrap_enabled = bootstrap_enabled, bootstrap_samples = as.integer(input$cb_adv_bootstrap_samples %||% 1000L),
        seed = as.integer(input$cb_adv_seed %||% 123L), outputs = input$cb_adv_outputs %||% snapshot$values$outputs)
      if (bootstrap_enabled) overrides$se <- "bootstrap"
      if (snapshot$capabilities$latent) overrides <- c(overrides, list(
        identification = input$cb_adv_identification %||% snapshot$values$identification,
        std_lv = identical(input$cb_adv_identification %||% snapshot$values$identification, "fixed_variance"),
        meanstructure = isTRUE(input$cb_adv_meanstructure), fixed_x = identical(input$cb_adv_fixed_x, "TRUE"),
        allow_single_indicator = isTRUE(input$cb_adv_single_indicator), constrain_two_indicator = isTRUE(input$cb_adv_two_indicator)))
      if (snapshot$capabilities$ordered || identical(snapshot$template$id, "ordered_binary")) overrides <- c(overrides,
        list(ordered = input$cb_adv_ordered %||% character(), parameterization = input$cb_adv_parameterization %||% "theta"))
      if (!identical(snapshot$capabilities$grouping, "none")) overrides <- c(overrides, list(
        group_levels = input$cb_adv_group_levels %||% snapshot$values$group_levels,
        group_equal = input$cb_adv_group_equal %||% character(), group_release = input$cb_adv_group_release %||% "",
        reference_group = input$cb_adv_reference_group %||% "", compare_latent_means = isTRUE(input$cb_adv_compare_means),
        compare_paths = isTRUE(input$cb_adv_compare_paths)))
      candidate <- sem_cbsem_normalize_sidebar(state$template_id, cb_data_profile(), cb_model_summary(), overrides, cb_context())
      compatible <- overrides[setdiff(names(overrides), candidate$cleared)]
      cb_sidebar_state(list(template_id = state$template_id, user_overrides = compatible))
      if (length(candidate$cleared)) shiny::showNotification(
        paste("Cleaned up incompatible settings:", paste(candidate$cleared, collapse = "、")), type = "warning")
      shiny::removeModal(); stale(TRUE); last_error("")
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$cb_adv_estimator, {
      estimator <- input$cb_adv_estimator %||% "MLR"
      covariance_input <- isTRUE(cb_sidebar_snapshot()$capabilities$covariance_input)
      choices <- if (covariance_input) c("Not applicable" = "none") else if (estimator %in% c("WLSMV", "DWLS"))
        c("Pairwise" = "pairwise") else c("FIML" = "fiml", "Complete sample" = "listwise")
      selected <- if (estimator %in% c("WLSMV", "DWLS")) "pairwise" else shiny::isolate(input$cb_adv_missing %||% "listwise")
      shiny::freezeReactiveValue(input, "cb_adv_missing")
      shiny::updateSelectInput(session, "cb_adv_missing", choices = choices, selected = selected)
      if (estimator %in% c("WLSMV", "DWLS") || covariance_input) {
        shiny::updateCheckboxInput(session, "cb_adv_bootstrap", value = FALSE)
        shiny::updateSelectInput(session, "cb_adv_se", selected = "standard")
      }
    }, ignoreInit = TRUE)
    output$method_options <- shiny::renderUI({
      method <- input$method %||% default_method
      numeric_names <- names(raw_data())[vapply(raw_data(), is.numeric, logical(1))]
      factor_names <- names(raw_data())[vapply(raw_data(), function(value) is.factor(value) || is.character(value), logical(1))]
      if (method == "covariance_sem") {
        NULL
      } else if (method == "piecewise_sem") {
        shiny::tagList(
          shiny::checkboxInput(session$ns("bootstrap"), "Bootstrap mediating effect", FALSE),
          shiny::numericInput(session$ns("bootstrap_samples"), "Bootstrap times", 500, min = 100, max = 5000),
          shiny::selectInput(session$ns("bootstrap_cluster"), "Clustering Bootstrap Units", c("Line-by-line resampling" = "", factor_names), ""))
      } else shiny::tagList(
        shiny::selectInput(session$ns("scheme"), "Inner weighting", c("path", "centroid", "factorial"), "path"),
        shiny::checkboxInput(session$ns("bootstrap"), "Bootstrap", TRUE),
        shiny::numericInput(session$ns("bootstrap_samples"), "Bootstrap times", 500, min = 100, max = 5000),
        shiny::numericInput(session$ns("max_iterations"), "Maximum number of iterations", 100, min = 10, max = 10000),
        shiny::numericInput(session$ns("tolerance"), "Convergence Tolerance", 1e-6, min = 1e-10, max = 1e-2, step = 1e-6))
    })
    output$builder <- shiny::renderUI({
      # Rebuild only when the selected method or dataset changes. Editor events
      # update the specification without replacing the Cytoscape DOM.
      input$method
      input$dataset
      spec <- shiny::isolate(current_spec()); variables <- names(raw_data())
      templates <- sem_template_registry()
      if (identical(spec$method, "piecewise_sem")) {
        templates <- templates[grepl("^piecewise_", templates$id), , drop = FALSE]
      } else if (identical(spec$method, "covariance_sem")) {
        templates <- sem_cbsem_template_registry()
      } else if (identical(spec$method, "pls_pm")) {
        templates <- sem_plspm_template_registry()
      }
      sem_builder_ui(session$ns("model_builder"), session$ns("builder_event"), variables, spec,
        template_input_id = session$ns("template"), template_action_id = session$ns("load_template"),
        new_model_id = session$ns("new_model"), save_revision_id = session$ns("save_revision"),
        document_controls = shiny::tagList(
          shiny::selectInput(session$ns("revision"), "Model version", choices = stats::setNames(as.character(spec$revision),
            sprintf("v%d · %s", spec$revision, spec$model_name)), selected = as.character(spec$revision)),
          shiny::actionButton(session$ns("restore_revision"), "Restore selected version", class = "btn-outline-secondary btn-sm w-100"),
          shiny::fileInput(session$ns("import_model"), "Import model definition (JSON)", accept = c("application/json", ".json")),
          shiny::downloadButton(session$ns("download_model"), "Export model definition", class = "btn-outline-secondary w-100"),
          shiny::actionButton(session$ns("apply_model_graph"), "Application model diagram",
            class = "btn-primary w-100 dava-sem-apply-graph"),
          if (identical(spec$method, "piecewise_sem")) shiny::div(`data-sem-local-controls` = "",
            shiny::uiOutput(session$ns("piecewise_local_model_controls")))),
        templates = templates, language = interface_language())
    })
    local_model_formula <- function(response, engine, fixed_formula, random_structure = "", group = "",
                                     outer = "", inner = "", slope_group = "", random_variables = character(),
                                     family = "poisson", zero_group = "") {
      formula_text <- paste(deparse(fixed_formula), collapse = "")
      if (engine == "lmer") {
        random_text <- switch(random_structure,
          block = if (nzchar(group)) paste0(" + (1 | ", group, ")") else " + (1 | block variable)",
          nested = if (nzchar(outer) && nzchar(inner)) paste0(" + (1 | ", outer, "/", inner, ")") else " + (1 | outer layer/inner layer)",
          slope = if (length(random_variables) && nzchar(slope_group))
            paste0(" + ", paste(sprintf("(1 + %s | %s)", random_variables, slope_group), collapse = " + ")) else
            " + (1 + random variable | slope block)", "")
        return(sprintf("mod_%s <- lmer(%s%s, data = sem_dat, REML = FALSE)", response, formula_text, random_text))
      }
      if (engine == "glm") return(sprintf("mod_%s <- glm(%s, family = %s, data = sem_dat)", response,
        formula_text, if (family == "binomial") "binomial(link = \"logit\")" else "poisson(link = \"log\")"))
      if (engine == "glmmTMB") {
        random_text <- if (nzchar(group)) paste0(" + (1 | ", group, ")") else " + (1 | Blocking effect)"
        family_text <- switch(family, nbinom2 = "nbinom2(link = \"log\")", zi_nbinom2 =
          paste0("nbinom2(link = \"log\"), ziformula = ~", if (nzchar(zero_group)) zero_group else "Processing Group"),
          "poisson(link = \"log\")")
        return(sprintf("mod_%s <- glmmTMB(%s%s, family = %s, data = sem_dat)", response, formula_text, random_text, family_text))
      }
      sprintf("mod_%s <- lm(%s, data = sem_dat)", response, formula_text)
    }
    output$piecewise_local_model_controls <- shiny::renderUI({
      if (!identical(input$method %||% default_method, "piecewise_sem")) return(NULL)
      input$load_template
      input$restore_revision
      input$import_model
      input$apply_model_graph
      spec <- shiny::isolate(current_spec()); nodes <- spec$nodes; edges <- spec$edges
      node_names <- stats::setNames(vapply(nodes$id, sem_node_variable, character(1), spec = spec), nodes$id)
      incoming <- edges[edges$active & edges$edge_type == "directed_path", , drop = FALSE]
      endogenous <- unique(node_names[incoming$target])
      if (!length(endogenous)) return(shiny::div(class = "alert alert-secondary py-2", "There are no endogenous variables in the path diagram."))
      response <- input$piecewise_endogenous %||% endogenous[[1]]
      if (!response %in% endogenous) response <- endogenous[[1]]
      target_id <- names(node_names)[match(response, node_names)]
      predictor_ids <- incoming$source[incoming$target == target_id]
      predictors <- unique(unname(node_names[predictor_ids]))
      models <- component_models(); model_index <- which(vapply(models, function(x) identical(x$response %||% all.vars(x$formula)[[1]], response), logical(1)))
      current <- if (length(model_index)) models[[model_index[[1]]]] else NULL
      if (is.null(current)) current <- list(name = paste0("mod_", response), formula = stats::reformulate(predictors, response), engine = "lm", family = "poisson")
      setting <- function(input_value, model_value, default) input_value %||% model_value %||% default
      engine <- setting(input$piecewise_local_engine, current$engine, "lm")
      fixed_formula <- tryCatch(stats::as.formula(input$piecewise_local_fixed %||% paste(deparse(current$formula), collapse = "")), error = function(e) current$formula)
      model_vars <- unique(c(endogenous, unname(node_names[incoming$source]), unname(node_names[incoming$target])))
      categorical <- names(raw_data())[vapply(raw_data(), function(x) is.factor(x) || is.character(x), logical(1))]
      random_choices <- setdiff(categorical, model_vars)
      random_structure <- setting(input$piecewise_random_structure, current$random_structure, "block")
      selected_group <- setting(input$piecewise_group, current$random_intercept, "")
      selected_outer <- setting(input$piecewise_outer, if (identical(current$random_structure, "nested")) strsplit(current$random_intercept %||% "", "/", fixed = TRUE)[[1]][1] else "", "")
      selected_inner <- setting(input$piecewise_inner, if (identical(current$random_structure, "nested")) utils::tail(strsplit(current$random_intercept %||% "", "/", fixed = TRUE)[[1]], 1) else "", "")
      selected_slope_group <- setting(input$piecewise_slope_group, current$slope_group, "")
      selected_random_variables <- setting(input$piecewise_random_variables, current$random_slope, character())
      selected_family <- setting(input$piecewise_family, current$family, "poisson")
      selected_zero_group <- setting(input$piecewise_zero_group, current$zero_group, "")
      formula_text <- local_model_formula(response, engine, fixed_formula, random_structure,
        selected_group, selected_outer, selected_inner, selected_slope_group, selected_random_variables,
        selected_family, selected_zero_group)
      ui <- list(shiny::selectInput(session$ns("piecewise_endogenous"), "Endogenous variables", endogenous, selected = response),
        shiny::selectInput(session$ns("piecewise_local_engine"), "Model fitting method",
          c("Linear model lm" = "lm", "linear mixed effects lmer" = "lmer", "Generalized linear glm" = "glm", "Generalized mixed effects glmmTMB" = "glmmTMB"), selected = engine),
        shiny::textAreaInput(session$ns("piecewise_local_formula"), "Local model formula", value = formula_text, rows = 4, width = "100%"))
      if (engine == "lmer") ui <- c(ui, list(
        shiny::selectInput(session$ns("piecewise_random_structure"), "Random structure",
          c("Random block effect" = "block", "Nested random effects" = "nested", "Random slope" = "slope"), selected = random_structure),
        if (random_structure == "block") shiny::selectInput(session$ns("piecewise_group"), "Block", random_choices, selected = selected_group)
        else if (random_structure == "nested") shiny::tagList(shiny::selectInput(session$ns("piecewise_outer"), "outer layer", random_choices, selected = selected_outer),
          shiny::selectInput(session$ns("piecewise_inner"), "Inner layer", setdiff(random_choices, selected_outer), selected = selected_inner))
        else shiny::tagList(shiny::selectInput(session$ns("piecewise_slope_group"), "slope block", random_choices, selected = selected_slope_group),
          shiny::selectizeInput(session$ns("piecewise_random_variables"), "Random variable", predictors, selected = selected_random_variables, multiple = TRUE))))
      if (engine == "glm") ui <- c(ui, list(shiny::selectInput(session$ns("piecewise_family"), "Distribution family",
        c("Count Poisson" = "poisson", "Binomial-logit" = "binomial"), selected = selected_family)))
      if (engine == "glmmTMB") ui <- c(ui, list(
        shiny::selectInput(session$ns("piecewise_group"), "Blocking effect", random_choices, selected = selected_group),
        shiny::selectInput(session$ns("piecewise_family"), "Generalized distribution family", c("Poisson" = "poisson", "Negative binomial NB2" = "nbinom2", "Zero-inflated negative binomial" = "zi_nbinom2"), selected = selected_family),
        if (selected_family == "zi_nbinom2") shiny::selectInput(session$ns("piecewise_zero_group"), "Processing Group", random_choices, selected = selected_zero_group)))
      c(ui, list(shiny::actionButton(session$ns("piecewise_submit_local"), "Submit model", class = "btn-primary w-100"),
        shiny::checkboxInput(session$ns("piecewise_lock_local"), "Lock", isTRUE(current$locked)),
        shiny::actionButton(session$ns("piecewise_diagnose_local"), "Local model diagnosis", class = "btn-outline-secondary btn-sm w-100")))
    })
    shiny::observeEvent(input$piecewise_endogenous, {
      if (!identical(input$method %||% default_method, "piecewise_sem")) return()
      response <- input$piecewise_endogenous %||% ""
      models <- component_models()
      index <- which(vapply(models, function(model) identical(model$response %||% all.vars(model$formula)[[1]], response), logical(1)))
      if (!length(index)) return()
      model <- models[[index[[1]]]]; engine <- model$engine %||% "lm"
      shiny::updateSelectInput(session, "piecewise_local_engine", selected = engine)
      formula_text <- local_model_formula(response, engine, model$formula,
        model$random_structure %||% "block", model$random_intercept %||% "",
        if (identical(model$random_structure, "nested")) strsplit(model$random_intercept %||% "", "/", fixed = TRUE)[[1]][1] else "",
        if (identical(model$random_structure, "nested")) utils::tail(strsplit(model$random_intercept %||% "", "/", fixed = TRUE)[[1]], 1) else "",
        model$slope_group %||% "", model$random_slope %||% character(), model$family %||% "poisson", model$zero_group %||% "")
      shiny::updateTextAreaInput(session, "piecewise_local_formula", value = formula_text)
      if (engine %in% c("glm", "glmmTMB")) shiny::updateSelectInput(session, "piecewise_family", selected = model$family %||% "poisson")
      if (engine == "glmmTMB" && identical(model$family, "zi_nbinom2")) shiny::updateSelectInput(session, "piecewise_zero_group", selected = model$zero_group %||% "")
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$piecewise_diagnose_local, {
      if (!identical(input$method %||% default_method, "piecewise_sem")) return()
      response <- input$piecewise_endogenous %||% ""
      models <- component_models()
      index <- which(vapply(models, function(model) identical(model$response %||% all.vars(model$formula)[[1]], response), logical(1)))
      if (!length(index)) {
        shiny::showNotification("Please submit the current local model of endogenous variables first.", type = "warning")
        return()
      }
      model <- models[[index[[1]]]]; data <- tryCatch(model_build_data(), error = function(e) NULL)
      if (!is.data.frame(data)) return(shiny::showNotification("The current data set is not available for diagnostics.", type = "error"))
      engine <- model$engine %||% "lm"
      fit <- tryCatch({
        if (engine == "lmer" && requireNamespace("lme4", quietly = TRUE))
          lme4::lmer(model$formula, data = data, REML = FALSE)
        else if (engine == "glm")
          stats::glm(model$formula, data = data, family = if ((model$family %||% "poisson") == "binomial") stats::binomial(link = "logit") else stats::poisson(link = "log"))
        else if (engine == "glmmTMB" && requireNamespace("glmmTMB", quietly = TRUE))
          glmmTMB::glmmTMB(model$formula, data = data, family = if ((model$family %||% "poisson") == "nbinom2") glmmTMB::nbinom2(link = "log") else glmmTMB::poisson(link = "log"))
        else stats::lm(model$formula, data = data)
      }, error = function(e) e)
      if (inherits(fit, "error")) return(shiny::showNotification(conditionMessage(fit), type = "error"))
      local_diagnostic(list(engine = engine, model = fit))
      output$piecewise_local_diagnostic_text <- shiny::renderPrint({
        d <- local_diagnostic(); fit <- d$model
        if (d$engine == "lm") return(list(linearity = summary(fit)$coefficients, residual_normality = shapiro.test(stats::residuals(fit)),
          homoscedasticity = summary(stats::lm(abs(stats::residuals(fit)) ~ stats::fitted(fit)))$coefficients,
          high_leverage = which(stats::hatvalues(fit) > 2 * mean(stats::hatvalues(fit))),
          influential_points = which(stats::cooks.distance(fit) > 4 / nrow(stats::model.frame(fit)))))
        if (d$engine == "lmer" && requireNamespace("performance", quietly = TRUE)) return(list(
          singularity = performance::check_singularity(fit), random_effect_variance = lme4::VarCorr(fit),
          residual_pattern = performance::check_model(fit), collinearity = performance::check_collinearity(fit)))
        if (d$engine %in% c("glm", "glmmTMB") && requireNamespace("DHARMa", quietly = TRUE)) {
          sim <- DHARMa::simulateResiduals(fit)
          return(list(overdispersion = DHARMa::testDispersion(sim), zero_inflation = DHARMa::testZeroInflation(sim), uniformity = DHARMa::testUniformity(sim)))
        }
        "The diagnostic dependency package is not installed and a complete test of this model type cannot be generated."
      })
      output$piecewise_local_diagnostic_plot <- shiny::renderPlot({
        d <- local_diagnostic(); fit <- d$model
        if (d$engine == "lm") { old <- graphics::par(mfrow = c(2, 2)); on.exit(graphics::par(old), add = TRUE); plot(fit) }
        else if (d$engine %in% c("glm", "glmmTMB") && requireNamespace("DHARMa", quietly = TRUE)) DHARMa::plotSimulatedResiduals(DHARMa::simulateResiduals(fit))
        else plot(stats::fitted(fit), stats::residuals(fit), xlab = "Fitted", ylab = "Residuals")
      })
      shiny::showModal(shiny::modalDialog(title = paste("Local model diagnosis:", response), size = "l", easyClose = TRUE,
        shiny::tabsetPanel(shiny::tabPanel("Graphical diagnostics", shiny::plotOutput(session$ns("piecewise_local_diagnostic_plot"), height = "520px")),
          shiny::tabPanel("Test results", shiny::verbatimTextOutput(session$ns("piecewise_local_diagnostic_text"))), footer = shiny::modalButton("Close")))
    )
    })
    shiny::observeEvent(input$piecewise_submit_local, {
      shiny::validate(shiny::need((input$method %||% default_method) == "piecewise_sem", "Partial models are only available with piecewiseSEM."))
      if (isTRUE(input$piecewise_lock_local)) {
        formula_status(list(type = "warning", text = "The current partial model is locked and modifications cannot be submitted.")); return()
      }
      text <- trimws(input$piecewise_local_formula %||% "")
      matched <- regexec("^([A-Za-z][A-Za-z0-9_.]*)\\s*<-\\s*(lm|lmer|glm|glmmTMB)\\s*\\((.*)\\)\\s*$", text, perl = TRUE)
      parts <- regmatches(text, matched)[[1]]
      if (length(parts) != 4L) stop("Local model formulaformatNoneeffect，please use mod_Y <- engine(Y ~ X1 + X2, data = sem_dat)。", call. = FALSE)
      name <- parts[[2]]; engine <- parts[[3]]; arguments <- parts[[4]]
      fixed_text <- trimws(sub(",.*$", "", arguments, perl = TRUE))
      formula <- tryCatch(stats::as.formula(fixed_text), error = function(error) stop("The local model formula cannot be parsed:", conditionMessage(error), call. = FALSE))
      spec <- current_spec(); nodes <- spec$nodes; edges <- spec$edges
      node_names <- vapply(nodes$id, sem_node_variable, character(1), spec = spec)
      model_variables <- c(node_names, names(raw_data()), names(composite_values()))
      undefined <- setdiff(all.vars(formula), model_variables)
      if (length(undefined)) stop(paste0("Local model contains undefined variables:", paste(undefined, collapse = ", ")), call. = FALSE)
      response <- all.vars(formula)[[1]]; models <- component_models()
      idx <- which(vapply(models, function(x) identical(x$response %||% all.vars(x$formula)[[1]], response), logical(1)))
      old <- if (length(idx)) models[[idx[[1]]]] else list(composite = paste0("comp_", response))
      random <- if (engine %in% c("lmer", "glmmTMB")) {
        if (engine == "lmer" && identical(input$piecewise_random_structure, "nested")) paste0(input$piecewise_outer, "/", input$piecewise_inner)
        else input$piecewise_group %||% ""
      } else ""
      updated <- utils::modifyList(old, list(name = name, response = response, formula = formula, engine = engine,
        family = input$piecewise_family %||% old$family %||% "poisson", random_intercept = random,
        random_structure = input$piecewise_random_structure %||% "block",
        random_slope = input$piecewise_random_variables %||% character(), slope_group = input$piecewise_slope_group %||% "",
        zero_group = input$piecewise_zero_group %||% "", locked = isTRUE(input$piecewise_lock_local)))
      if (length(idx)) models[[idx[[1]]]] <- updated else models[[length(models) + 1L]] <- updated
      names(models) <- vapply(models, `[[`, character(1), "name"); component_models(models); persist_component_models(models)
      formula_status(list(type = "success", text = paste0("Submitted partial model:", name)))
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$piecewise_lock_local, {
      response <- input$piecewise_endogenous %||% ""; if (!nzchar(response)) return()
      models <- component_models(); idx <- which(vapply(models,
        function(x) identical(x$response %||% all.vars(x$formula)[[1]], response), logical(1)))
      if (length(idx)) {
        models[[idx[[1]]]]$locked <- isTRUE(input$piecewise_lock_local)
        component_models(models); persist_component_models(models)
      }
    }, ignoreInit = TRUE)
    output$raw_data_table <- DT::renderDT({
      DT::datatable(raw_data(), rownames = FALSE, filter = "top",
        extensions = "Scroller", options = list(scrollX = TRUE, scrollY = 620,
          scroller = TRUE, deferRender = TRUE, pageLength = 50))
    }, server = TRUE)
    output$model_build_data_table <- DT::renderDT({
      DT::datatable(model_build_data(), rownames = FALSE, filter = "top",
        extensions = "Scroller", options = list(scrollX = TRUE, scrollY = 620,
          scroller = TRUE, deferRender = TRUE, pageLength = 50))
    }, server = TRUE)
    screening_result <- shiny::eventReactive(input$run_screening, {
      progress <- dava_progress(session, min = 0, max = 1)
      on.exit(progress$close(), add = TRUE)
      progress$set(
        message = "\u8fd0\u884c\u7ed3\u6784\u65b9\u7a0b\u6a21\u578b\u6570\u636e\u524d\u7f6e\u68c0\u9a8c",
        detail = "\u68c0\u67e5\u53d8\u91cf\u4e0e\u68c0\u9a8c\u53c2\u6570",
        value = 0.1
      )
      progress$set(detail = "\u8ba1\u7b97\u6b63\u6001\u6027\u3001\u76f8\u5173\u6027\u4e0e\u5171\u7ebf\u6027", value = 0.35)
      value <- tryCatch(sem_run_data_screening(raw_data(), input$screen_variables %||% character(),
        input$screen_response %||% "", correlation_threshold = input$screen_correlation_threshold %||% 0.1,
        vif_threshold = input$screen_vif_threshold %||% 5,
        community_variables = input$screen_community %||% character(),
        ordination_method = input$screen_ordination_method %||% "rda",
        permutations = as.integer(input$screen_permutations %||% 999L),
        seed = as.integer(input$screen_seed %||% 20260717L)),
      error = function(error) list(error = conditionMessage(error)))
      progress$set(detail = "\u6574\u7406\u7b5b\u9009\u7ed3\u679c\u4e0e\u8bca\u65ad\u8868", value = 0.92)
      value
    }, ignoreInit = TRUE)
    shiny::observeEvent(screening_result(), {
      value <- screening_result()
      if (!identical(input$method %||% default_method, "covariance_sem") || !is.null(value$error) || !is.data.frame(value$normality)) return()
      assessed <- value$normality$normal_at_0_05
      assessed <- assessed[!is.na(assessed)]
      cb_normality_state(if (length(assessed) && all(assessed)) "normal" else "non_normal")
    }, ignoreInit = TRUE)
    output$screening_status <- shiny::renderUI({
      if (!input$run_screening) return(shiny::div(class = "alert alert-secondary py-2", "Run pretest after setting variables."))
      value <- screening_result()
      if (!is.null(value$error)) shiny::div(class = "alert alert-danger py-2", value$error)
      else shiny::div(class = "alert alert-success py-2", "Pre-test completed; filtering results will not automatically delete original variables.")
    })
    output$screen_normality <- DT::renderDT({
      value <- screening_result(); shiny::req(is.null(value$error))
      DT::datatable(value$normality, rownames = FALSE, options = list(scrollX = TRUE, pageLength = 15))
    })
    output$screen_correlation <- DT::renderDT({
      value <- screening_result(); shiny::req(is.null(value$error))
      DT::datatable(value$correlation$screening, rownames = FALSE, options = list(scrollX = TRUE, pageLength = 15))
    })
    output$screen_correlation_matrix <- DT::renderDT({
      value <- screening_result(); shiny::req(is.null(value$error))
      matrix <- round(value$correlation$matrix, 2)
      DT::datatable(data.frame(variable = rownames(matrix), matrix, row.names = NULL, check.names = FALSE),
        rownames = FALSE, options = list(scrollX = TRUE, pageLength = 15))
    })
    output$screen_vif <- DT::renderDT({
      value <- screening_result(); shiny::req(is.null(value$error))
      DT::datatable(value$vif, rownames = FALSE, options = list(scrollX = TRUE, pageLength = 15))
    })
    output$screen_rf <- DT::renderDT({
      value <- screening_result(); shiny::req(is.null(value$error))
      DT::datatable(value$random_forest, rownames = FALSE, options = list(scrollX = TRUE, pageLength = 15))
    })
    output$screen_pca <- DT::renderDT({
      value <- screening_result(); shiny::req(is.null(value$error))
      DT::datatable(value$pca$summary, rownames = FALSE, options = list(scrollX = TRUE, pageLength = 10))
    })
    output$screen_pca_loadings <- DT::renderDT({
      value <- screening_result(); shiny::req(is.null(value$error))
      DT::datatable(value$pca$loadings, rownames = FALSE, options = list(scrollX = TRUE, pageLength = 15))
    })
    output$screen_ordination <- DT::renderDT({
      value <- screening_result(); shiny::req(is.null(value$error))
      DT::datatable(value$ordination$explained, rownames = FALSE, options = list(dom = "t"))
    })
    output$screen_ordination_test <- DT::renderDT({
      value <- screening_result(); shiny::req(is.null(value$error))
      DT::datatable(value$ordination$test, rownames = FALSE, options = list(scrollX = TRUE, pageLength = 10))
    })
    output$screen_pairs_plot <- shiny::renderPlot({
      captured <- dava_capture_conditions({
        value <- screening_result(); shiny::req(is.null(value$error))
        plot_data <- sem_screening_numeric(raw_data(), input$screen_variables %||% character())
        print(sem_screen_correlation_plot(plot_data))
      }, source = "SEM screening plot")
      record_plot_runtime_diagnostics(captured, "SEM screening plot")
      if (nzchar(captured$error %||% "")) dava_plot_diagnostic_placeholder(captured$error)
      invisible(captured$value)
    })
    shiny::observeEvent(input$builder_event, {
      tryCatch({
        spec <- sem_model_spec_from_payload(input$builder_event$model_spec)
        spec$method <- input$method %||% spec$method
        event <- input$builder_event$event %||% ""
        previous <- current_spec()
        same_elements <- identical(sort(as.character(spec$nodes$id)), sort(as.character(previous$nodes$id))) &&
          identical(sort(as.character(spec$edges$id)), sort(as.character(previous$edges$id)))
        hydration_only <- identical(event, "sem_model_updated") && same_elements
        current_spec(spec)
        if (!hydration_only) stale(TRUE)
        last_error("")
        if (event %in% c("sem_composite_build", "sem_composite_validate")) {
          notification_id <- paste0(session$ns("composite_build_"), as.integer(Sys.time()))
          shiny::showNotification("Building composite variable...", id = notification_id, duration = NULL, type = "message")
          selected_id <- (input$builder_event$selection %||% character())[[1]]
          node <- spec$nodes[spec$nodes$id == selected_id, , drop = FALSE]
          if (!nrow(node) || node$node_type[[1]] != "composite_construct") stop("Please select a composite construct node.", call. = FALSE)
          indicators <- node$indicator_variables[[1]] %||% character()
          reverse <- if ("reverse_indicators" %in% names(node)) node$reverse_indicators[[1]] %||% character() else character()
          method <- if ("composite_method" %in% names(node)) node$composite_method[[1]] %||% "z_mean" else "z_mean"
          direction <- if ("score_direction" %in% names(node)) as.numeric(node$score_direction[[1]] %||% 1) else 1
          validation_data <- analysis_base_data()
          validation <- dava_with_progress(message = "Construct composite variables", value = 0, {
            dava_inc_progress(0.2, detail = "Prepare indicator data")
            value <- sem_build_composite_variable(validation_data, node$construct_name[[1]], indicators,
              method = method, reverse_variables = reverse, score_direction = direction,
              data_is_standardized = isTRUE(input$data_standardization))
            dava_inc_progress(0.6, detail = "Calculate composite score")
            if (requireNamespace("psych", quietly = TRUE)) dava_inc_progress(0.15, detail = "Calculate Cronbach's α")
            dava_inc_progress(0.05, detail = "Organize verification results")
            value
          })
          validation$score_direction <- direction
          values <- composite_values(); values[[node$construct_name[[1]]]] <- validation$score; composite_values(values)
          records <- composite_records(); records[[node$construct_name[[1]]]] <- validation; composite_records(records)
          composite_validation(validation)
          sync_imported_piecewise_formula(paste0("Composite variable codes have been replaced with new methods:", node$construct_name[[1]]))
          formula_status(list(type = "success", text = paste0("Composite variable constructed:", node$construct_name[[1]])))
          shiny::removeNotification(notification_id)
          shiny::showNotification(sprintf("Composite variable %s constructed: %s, %d valid scores.",
            node$construct_name[[1]], method, sum(is.finite(validation$score))), type = "message", duration = 5)
          if (event == "sem_composite_validate") shiny::showModal(shiny::modalDialog(
            title = paste0("Validate composite variables:", node$construct_name[[1]]), size = "l", easyClose = FALSE,
            bslib::navset_card_tab(
              bslib::nav_panel("Data", DT::DTOutput(session$ns("composite_validation_table"))),
              bslib::nav_panel("Cronbach's alpha reliability test", DT::DTOutput(session$ns("composite_validation_alpha"))),
              bslib::nav_panel("Relevance", shiny::plotOutput(session$ns("composite_validation_plot"), height = "420px")),
              if (method == "pca") bslib::nav_panel("PCA explanation rate", shiny::div(class = "dava-sem-validation-code",
                shiny::verbatimTextOutput(session$ns("composite_validation_summary")))),
              if (method %in% c("pca", "factor")) bslib::nav_panel(if (method == "pca") "PCA payload" else "Factor loadings",
                shiny::div(class = "dava-sem-validation-code", shiny::verbatimTextOutput(session$ns("composite_validation_loadings"))))),
            footer = shiny::actionButton(session$ns("close_composite_validation"), "Close", class = "btn-primary")))
        }
      }, error = function(error) {
        if (exists("notification_id", inherits = FALSE)) shiny::removeNotification(notification_id)
        last_error(conditionMessage(error)); formula_status(list(type = "danger", text = conditionMessage(error)))
        shiny::showNotification(paste0("Composite variable construction failed:", conditionMessage(error)), type = "error", duration = 8)
      })
    })
    output$composite_validation_table <- DT::renderDT({
      value <- composite_validation(); shiny::req(value)
      DT::datatable(value$preview, rownames = FALSE, options = list(scrollX = TRUE, pageLength = 12))
    })
    output$composite_validation_alpha <- DT::renderDT({
      value <- composite_validation(); shiny::req(value)
      DT::datatable(value$alpha_table, rownames = FALSE, options = list(dom = "t", scrollX = TRUE))
    })
    output$composite_validation_plot <- shiny::renderPlot({
      captured <- dava_capture_conditions({
        value <- composite_validation(); shiny::req(value)
        print(sem_composite_correlation_plot(value))
      }, source = "SEM composite validation plot")
      record_plot_runtime_diagnostics(captured, "SEM composite validation plot")
      if (nzchar(captured$error %||% "")) dava_plot_diagnostic_placeholder(captured$error)
      invisible(captured$value)
    })
    output$composite_validation_summary <- shiny::renderText({ paste(composite_validation()$summary_text %||% "", collapse = "\n") })
    output$composite_validation_loadings <- shiny::renderText({ paste(composite_validation()$loading_text %||% "", collapse = "\n") })
    shiny::observeEvent(input$close_composite_validation, {
      shiny::removeModal()
      session$sendCustomMessage("sem-builder-reset-composite-validation", list(id = session$ns("model_builder")))
    }, ignoreInit = TRUE)
    update_formula_from_graph <- function(message = "Model diagram applied to model formula") {
      tryCatch({
        spec <- shiny::isolate(current_spec())
        if (identical(spec$method, "piecewise_sem")) {
          previous_models <- shiny::isolate(component_models())
          previous_by_response <- stats::setNames(previous_models,
            vapply(previous_models, function(model) all.vars(model$formula)[[1]], character(1)))
          models <- sem_piecewise_components_from_spec(spec)
          for (index in seq_along(models)) {
            response <- all.vars(models[[index]]$formula)[[1]]
            old <- previous_by_response[[response]]
            if (!is.null(old)) models[[index]] <- utils::modifyList(models[[index]],
              old[c("name", "composite", "response", "engine", "family", "random_intercept", "random_structure",
                "random_slope", "slope_group", "zero_group", "reml", "locked")])
          }
          names(models) <- vapply(models, `[[`, character(1), "name")
          component_models(models); persist_component_models(models)
          composite_code <- sem_piecewise_composite_data_code(spec, data_name = analysis_data_code_name(),
            records = shiny::isolate(composite_records_for_spec(spec)),
            data_is_standardized = isTRUE(input$data_standardization))
          code <- paste(c(standardization_code(), composite_code, if (length(composite_code)) "",
            sem_piecewise_components_to_code(models, data_name = analysis_data_code_name(), psem_name = "psem_grass")), collapse = "\n")
        } else code <- sem_graph_to_path_code(spec)
        shiny::updateTextAreaInput(session, "model_code", value = code)
        formula_status(list(type = "success", text = message))
      }, error = function(error) formula_status(list(type = "danger", text = conditionMessage(error))))
    }
    sync_imported_piecewise_formula <- function(message) {
      tryCatch({
        spec <- shiny::isolate(current_spec())
        if (!identical(spec$method, "piecewise_sem")) return(invisible(NULL))
        models <- shiny::isolate(component_models())
        if (!length(models)) models <- sem_piecewise_components_from_spec(spec)
        component_models(models)
        composite_code <- sem_piecewise_composite_data_code(spec, data_name = analysis_data_code_name(),
          records = shiny::isolate(composite_records_for_spec(spec)),
          data_is_standardized = isTRUE(input$data_standardization))
        component_code <- sem_piecewise_components_to_code(models, data_name = analysis_data_code_name(), psem_name = "psem_grass")
        shiny::updateTextAreaInput(session, "model_code",
          value = paste(c(standardization_code(), composite_code, if (length(composite_code)) "", component_code), collapse = "\n"))
        formula_status(list(type = "success", text = message))
      }, error = function(error) formula_status(list(type = "danger", text = conditionMessage(error))))
      invisible(NULL)
    }
    session$onFlushed(function() update_formula_from_graph("Model formula has been initialized"), once = TRUE)
    shiny::observeEvent(input$data_standardization, {
      stale(TRUE)
      if (identical(input$method %||% default_method, "piecewise_sem")) {
        composite_values(list())
        composite_records(list())
        update_formula_from_graph(if (isTRUE(input$data_standardization)) "Data normalization enabled" else "Data normalization turned off")
      } else formula_status(list(type = "success",
        text = if (isTRUE(input$data_standardization)) "Data normalization enabled" else "Data normalization turned off"))
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$apply_model_graph, {
      update_formula_from_graph()
    }, ignoreInit = TRUE)

    shiny::observeEvent(input$apply_model_formula, {
      tryCatch({
        previous <- current_spec()
        method <- input$method %||% default_method
        if (identical(method, "piecewise_sem")) {
          models <- sem_parse_piecewise_code(input$model_code %||% "")
          spec <- sem_piecewise_components_to_spec(models, previous$model_name)
          component_models(models)
        } else if (identical(method, "pls_pm")) {
          spec <- sem_parse_plspm_code(input$model_code %||% "", previous$model_name)
        } else spec <- sem_parse_lavaan_syntax(input$model_code %||% "", method)
        spec$model_name <- previous$model_name
        spec$revision <- previous$revision + 1L
        spec$parent_revision <- previous$revision
        spec$comments <- previous$comments
        spec$provenance <- c(previous$provenance, list(source = "formula_editor"))
        current_spec(spec)
        stale(TRUE)
        last_error("")
        formula_status(list(type = "success", text = "Model formula has been applied to the prior model graph"))
        session$sendCustomMessage("sem-builder-load", list(
          id = session$ns("model_builder"), model_spec = sem_model_message_payload(spec)))
      }, error = function(error) formula_status(list(type = "danger", text = conditionMessage(error))))
    }, ignoreInit = TRUE)

    output$formula_sync_status <- shiny::renderUI({
      status <- formula_status()
      shiny::div(class = paste0("text-", status$type, " small mb-2"), status$text)
    })
    composite_records_for_spec <- function(spec) {
      nodes <- spec$nodes[spec$nodes$node_type == "composite_construct", , drop = FALSE]
      if (!nrow(nodes)) return(list())
      saved <- composite_records()
      records <- lapply(seq_len(nrow(nodes)), function(index) {
        name <- nodes$construct_name[[index]] %||% nodes$label[[index]]
        if (!is.null(saved[[name]])) return(saved[[name]])
        method <- nodes$composite_method[[index]] %||% "z_mean"
        indicators <- nodes$indicator_variables[[index]] %||% character()
        sem_build_composite_variable(analysis_base_data(), name, indicators, method = method,
          reverse_variables = nodes$reverse_indicators[[index]] %||% character(),
          score_direction = as.numeric(nodes$score_direction[[index]] %||% 1), compute_alpha = FALSE,
          data_is_standardized = isTRUE(input$data_standardization))
      })
      stats::setNames(records, vapply(seq_len(nrow(nodes)), function(index)
        nodes$construct_name[[index]] %||% nodes$label[[index]], character(1)))
    }
    options <- shiny::reactive({
      method <- input$method %||% default_method
      if (identical(method, "covariance_sem")) {
        snapshot <- cb_sidebar_snapshot(); values <- snapshot$values
        return(list(estimator = values$estimator, missing = values$missing, fixed_x = isTRUE(values$fixed_x),
          std_lv = isTRUE(values$std_lv), meanstructure = isTRUE(values$meanstructure), ordered = values$ordered,
          group = values$group, group_levels = values$group_levels, group_strategy = values$group_strategy,
          group_equal = values$group_equal, group_release = values$group_release, reference_group = values$reference_group,
          compare_latent_means = values$compare_latent_means, compare_paths = values$compare_paths,
          se = if (isTRUE(values$bootstrap_enabled)) "bootstrap" else values$se,
          bootstrap = as.integer(values$bootstrap_samples), seed = as.integer(values$seed),
          parameterization = values$parameterization, identification = values$identification,
          allow_single_indicator = values$allow_single_indicator, constrain_two_indicator = values$constrain_two_indicator,
          output_settings = values$outputs, sidebar_snapshot = snapshot$parameters,
          data_standardization = isTRUE(input$data_standardization)))
      }
      models <- if (method == "piecewise_sem") component_models() else list()
      component_specs <- stats::setNames(lapply(models, function(model) list(engine = model$engine,
        family = model$family, random_intercept = model$random_intercept, random_structure = model$random_structure,
        random_slope = model$random_slope, slope_group = model$slope_group, zero_group = model$zero_group,
        reml = model$reml, locked = model$locked)),
        vapply(models, function(model) all.vars(model$formula)[[1]], character(1)))
      list(estimator = input$estimator %||% "MLR",
        missing = input$missing %||% "fiml", fixed_x = isTRUE(input$fixed_x), std_lv = isTRUE(input$std_lv),
        meanstructure = isTRUE(input$meanstructure), ordered = input$ordered %||% character(), group = input$group %||% "",
        se = input$se %||% "standard", component_specs = component_specs, bootstrap_cluster = input$bootstrap_cluster %||% "",
        data_standardization = isTRUE(input$data_standardization),
        component_models = models,
        composite_records = composite_records_for_spec(current_spec()),
        scheme = input$scheme %||% "path",
        scaled = if (identical(method, "pls_pm")) isTRUE(input$data_standardization %||% TRUE) else isTRUE(input$scaled %||% TRUE),
        bootstrap = if (identical(method, "pls_pm")) isTRUE(input$bootstrap %||% TRUE) else isTRUE(input$bootstrap),
        bootstrap_samples = as.integer(input$bootstrap_samples %||% 500L),
        max_iterations = as.integer(input$max_iterations %||% 100L), tolerance = as.numeric(input$tolerance %||% 1e-6))
    })
    composite_payload <- shiny::reactive({
      records <- composite_records_for_spec(current_spec())
      if (!length(records)) return(list(table = data.frame(), code = character()))
      data_name <- analysis_data_code_name()
      list(table = do.call(rbind, lapply(records, sem_composite_construction_row)),
        reliability = do.call(rbind, lapply(records, sem_composite_reliability_row)),
        code = vapply(records, sem_composite_construction_code, character(1), data_name = data_name,
          data_is_standardized = isTRUE(input$data_standardization)))
    })
    decorate_result <- function(value) {
      payload <- composite_payload()
      if (!length(payload$code) || !identical(value$method, "piecewise_sem")) return(value)
      value$composite_construction <- payload$table
      value$composite_reliability <- payload$reliability
      value$composite_code <- payload$code
      value
    }
    displayed_tables <- shiny::reactive({
      payload <- composite_payload()
      if (!isTRUE(input$run > 0L) || stale()) return(list())
      sem_result_tables(decorate_result(result()))
    })
    original_result <- shiny::eventReactive(input$run, {
      analysis_generation()
      method <- input$method %||% default_method
      if (identical(method, "covariance_sem")) {
        sidebar_check <- cb_sidebar_validation()
        shiny::validate(shiny::need(sidebar_check$valid, paste(sidebar_check$errors, collapse = "；")))
      }
      dependency <- sem_method_dependency_status(method)
      if (!dependency$available) {
        dava_install_packages(dependency$missing,
          purpose = paste0("Structural equation modeling approach ", method))
        dependency <- sem_method_dependency_status(method)
      }
      shiny::validate(shiny::need(dependency$available, paste("Missing package:", paste(dependency$missing, collapse = ", "))))
      fit_count(fit_count() + 1L); last_error("")
      progress_message <- switch(method, covariance_sem = "Running Lavaan CB-SEM analysis",
        piecewise_sem = "Run piecewiseSEM analysis", pls_pm = "Running PLS-PM analysis", "Running a structural equation model analysis")
      fit_detail <- switch(method, covariance_sem = "Fit Lavaan model",
        piecewise_sem = "Fit component model", pls_pm = "Fit PLS-PM model", "Fitting model")
      value <- tryCatch(dava_with_progress(message = progress_message, value = 0, {
        dava_inc_progress(0.15, detail = "Prepare data for analysis")
        dava_inc_progress(0.15, detail = fit_detail)
        fit_value <- sem_fit(data_bundle(), current_spec(), options())
        dava_inc_progress(0.60, detail = "\u6574\u7406\u5206\u6790\u7ed3\u679c")
        dava_inc_progress(0.10, detail = "\u5206\u6790\u5b8c\u6210")
        fit_value
      }), error = function(error) {
        last_error(conditionMessage(error)); new_sem_result(method, status = "error",
          prior_model_spec = current_spec(), final_model_spec = current_spec(), errors = conditionMessage(error), execution_metrics = list(fit_count = fit_count()))
      })
      value$execution_metrics$fit_count <- fit_count(); stale(FALSE); value
    }, ignoreInit = TRUE)
    custom_result <- shiny::eventReactive(list(
      input$run, file_data$method_code_revision
    ), {
      method <- input$method %||% default_method
      method_key <- paste("structural_sem", method, sep = "/")
      entry <- dava_method_code_get(file_data, method_key)
      if (is.null(entry) || !isTRUE(entry$enabled)) return(NULL)
      run <- dava_method_code_execute(file_data, method_key,
        data = model_build_data(),
        dataset_name = input$dataset %||% ".__sem_demo__",
        spec = utils::modifyList(
          dava_code_analysis_spec_from_input(input), current_spec()))
      value <- dava_sem_custom_result(run, method, current_spec(), entry$custom_code)
      fit_count(fit_count() + 1L)
      value$execution_metrics$fit_count <- fit_count()
      stale(FALSE)
      value
    }, ignoreInit = TRUE)
    result <- shiny::reactive({
      method <- input$method %||% default_method
      method_key <- paste("structural_sem", method, sep = "/")
      dava_method_code_effective(
        original = function() original_result(),
        file_data = file_data, method_key = method_key,
        adapter = function(run, entry) custom_result(),
        on_error = function(message) {
          last_error(paste0("The user-defined SEM method failed and the original method has been rolled back:", message))
          original_result()
        }
      )
    })
    shiny::observeEvent(input$run, {
      value <- result()
      result_editor_spec(if (identical(value$status, "success")) sem_result_editor_spec(value) else NULL)
      result_editor_generation(result_editor_generation() + 1L)
      invisible(NULL)
    }, ignoreInit = TRUE, priority = 100)

    shiny::observeEvent(input$result_model_event, {
      tryCatch({
        spec <- sem_model_spec_from_payload(input$result_model_event$model_spec)
        if (!isTRUE(spec$provenance$result_overlay))
          stop("Result editor payload is missing result provenance.", call. = FALSE)
        result_editor_spec(spec)
      }, error = function(error) last_error(conditionMessage(error)))
    }, ignoreInit = TRUE)

    output$adequacy <- DT::renderDT({ if (stale()) return(DT::datatable(data.frame(status = "The current model has not been run yet"), rownames = FALSE)); value <- result(); DT::datatable(value$data_adequacy, rownames = FALSE) })
    output$overview <- DT::renderDT({
      if (stale()) return(DT::datatable(data.frame(method = input$method %||% default_method, status = "The current model has not been run yet", revision = current_spec()$revision), rownames = FALSE))
      value <- result(); spec <- value$final_model_spec
      table <- data.frame(method = value$method, status = value$status, revision = spec$revision,
        samples = value$data_adequacy$samples %||% NA, nodes = nrow(spec$nodes), paths = nrow(spec$edges),
        fit_count = value$execution_metrics$fit_count, stringsAsFactors = FALSE)
      DT::datatable(table, rownames = FALSE)
    })
    output$result_selector <- shiny::renderUI({
      tables <- displayed_tables()
      if (!length(tables) || is.null(names(tables)) || !any(nzchar(names(tables))))
        return(shiny::div(class = "alert alert-secondary py-2", "The current model has not been run yet and there is no result table yet."))
      names(tables) <- make.unique(ifelse(nzchar(names(tables)), names(tables), paste0("result_", seq_along(tables))))
      shiny::selectInput(session$ns("result_name"), "Results table", choices = stats::setNames(names(tables),
        sem_result_table_labels(input$method %||% default_method, names(tables))))
    })
    output$result_table <- DT::renderDT({
      tables <- displayed_tables()
      if (!length(tables)) return(DT::datatable(data.frame(status = "The current model has not been run yet"), rownames = FALSE, options = list(dom = "t")))
      if (is.null(names(tables)) || !any(nzchar(names(tables)))) names(tables) <- paste0("result_", seq_along(tables))
      name <- input$result_name %||% names(tables)[1]
      if (!name %in% names(tables)) name <- names(tables)[1]
      table <- as.data.frame(tables[[name]], stringsAsFactors = FALSE, check.names = FALSE)
      if (!ncol(table)) table <- data.frame(status = "The current result is empty", stringsAsFactors = FALSE)
      names(table) <- make.unique(ifelse(nzchar(names(table)), names(table), paste0("V", seq_along(table))))
      for (column in names(table)) if (is.list(table[[column]])) table[[column]] <- vapply(table[[column]], function(value) paste(value, collapse = ", "), character(1))
      DT::datatable(table, rownames = FALSE, options = list(scrollX = TRUE, pageLength = 20, searching = TRUE))
    })
    output$model_text <- shiny::renderText({
      payload <- composite_payload()
      if (!isTRUE(input$run > 0L) || stale()) return("")
      dava_localize_model_text(
        sem_model_text(decorate_result(result())), interface_language(),
        dava_user_data_text(raw_data())
      )
    })
    output$final_plot_status <- shiny::renderUI({
      if (!input$run) return(shiny::div(class = "alert alert-secondary py-2", "Displays the final model with path coefficients and R² after running the analysis."))
      if (stale()) return(shiny::div(class = "alert alert-warning py-2", "The prior model has been modified; the current final model belongs to the last run."))
      NULL
    })
    output$result_model_builder <- shiny::renderUI({
      result_editor_generation()
      shiny::req(input$run, !stale())
      result_spec <- shiny::isolate(result_editor_spec())
      shiny::req(result_spec)
      sem_result_layout_editor_ui(session$ns("result_model_editor"),
        session$ns("result_model_event"), result_spec, language = interface_language())
    })
    output$effect_plot <- shiny::renderPlot({
      captured <- dava_capture_conditions({
        shiny::req(input$run, !stale(), result()$status == "success")
        print(sem_effect_plot(result()))
      }, source = "SEM effect plot")
      record_plot_runtime_diagnostics(captured, "SEM effect plot")
      if (nzchar(captured$error %||% "")) dava_plot_diagnostic_placeholder(captured$error)
      invisible(captured$value)
    })

    optimization_analysis <- shiny::reactive({
      fitted <- if (isTRUE(input$run > 0L) && !stale() && identical(result()$status, "success")) result() else NULL
      sem_model_optimization(current_spec(), fitted)
    })
    output$optimization_summary <- shiny::renderText({
      optimization_analysis()$summary
    })
    output$optimization_controls <- shiny::renderUI({
      if (!identical(current_spec()$method, "covariance_sem")) return(NULL)
      shiny::tagList(
        bslib::layout_columns(
          shiny::numericInput(session$ns("mi_threshold"), "Minimum modification index", 3.84, min = 0, step = 0.1),
          shiny::numericInput(session$ns("mi_max"), "Show most suggestions", 20, min = 1, max = 100, step = 1)),
        shiny::actionButton(session$ns("apply_optimization"), "Add selected suggestions to new prior version", class = "btn-outline-primary"))
    })

    optimization_candidates <- shiny::reactive({
      if (!identical(current_spec()$method, "covariance_sem") || !input$run || stale() || result()$status != "success") return(data.frame())
      candidates <- result()$modification_indices
      if (!is.data.frame(candidates) || !nrow(candidates)) return(data.frame())
      mi_column <- sem_find_column(candidates, c("mi", "modificationindex"))
      if (is.na(mi_column)) return(data.frame())
      candidates <- candidates[is.finite(candidates[[mi_column]]) & candidates[[mi_column]] >= (input$mi_threshold %||% 3.84), , drop = FALSE]
      candidates <- candidates[order(candidates[[mi_column]], decreasing = TRUE), , drop = FALSE]
      utils::head(candidates, as.integer(input$mi_max %||% 20L))
    })
    output$optimization_table <- DT::renderDT({
      if (!identical(current_spec()$method, "covariance_sem")) {
        strategies <- optimization_analysis()$strategies
        return(DT::datatable(strategies, rownames = FALSE,
          options = list(scrollX = TRUE, pageLength = nrow(strategies), searching = FALSE, ordering = FALSE)))
      }
      candidates <- optimization_candidates()
      if (!nrow(candidates)) return(DT::datatable(data.frame(status = "There are currently no available optimization suggestions that reach the threshold."), rownames = FALSE))
      DT::datatable(candidates, rownames = FALSE, options = list(scrollX = TRUE, pageLength = 10))
    })
    output$optimization_selector <- shiny::renderUI({
      if (!identical(current_spec()$method, "covariance_sem")) return(NULL)
      candidates <- optimization_candidates()
      if (!nrow(candidates) || !all(c("lhs", "op", "rhs") %in% names(candidates))) return(NULL)
      labels <- sprintf("%s %s %s", candidates$lhs, candidates$op, candidates$rhs)
      shiny::selectInput(session$ns("optimization_choice"), "Candidate relationships to be added manually",
        stats::setNames(as.character(seq_len(nrow(candidates))), labels))
    })
    optimization_message <- shiny::reactiveVal("The optimization suggestion has not been applied yet.")
    shiny::observeEvent(input$apply_optimization, {
      shiny::req(identical(current_spec()$method, "covariance_sem"))
      candidates <- optimization_candidates()
      selected <- as.integer(input$optimization_choice %||% NA_integer_)
      shiny::validate(shiny::need(nrow(candidates) && !is.na(selected) && selected <= nrow(candidates), "Please select a valid opportunity."))
      candidate <- candidates[selected, , drop = FALSE]
      shiny::validate(shiny::need(candidate$op[[1]] %in% c("~", "~~"), "Currently only path or covariance suggestions are supported."))
      spec <- current_spec()
      node_names <- vapply(spec$nodes$id, sem_node_variable, character(1), spec = spec)
      source_name <- if (candidate$op[[1]] == "~") candidate$rhs[[1]] else candidate$lhs[[1]]
      target_name <- if (candidate$op[[1]] == "~") candidate$lhs[[1]] else candidate$rhs[[1]]
      source <- spec$nodes$id[match(source_name, node_names)]
      target <- spec$nodes$id[match(target_name, node_names)]
      shiny::validate(shiny::need(length(source) && length(target) && !is.na(source) && !is.na(target), "The suggestion references a node that does not exist in the current prior model."))
      edge_type <- if (candidate$op[[1]] == "~") "directed_path" else "covariance"
      duplicate <- spec$edges$source == source & spec$edges$target == target & spec$edges$edge_type == edge_type
      shiny::validate(shiny::need(!any(duplicate), "This relationship already exists in the a priori model."))
      edge <- sem_edge_table()
      edge[1, ] <- list(paste0("opt_", format(Sys.time(), "%H%M%S")), source, target, edge_type,
        if (edge_type == "directed_path") "forward" else "bidirectional", "", "", NA_real_, NA_real_, TRUE,
        TRUE, FALSE, TRUE, edge_type == "covariance", FALSE, edge_type == "directed_path", FALSE, "", "Modification index suggestions for manual review")
      spec$edges <- rbind(spec$edges, edge)
      spec <- push_revision(spec); stale(TRUE)
      optimization_message(sprintf("%s %s %s has been added to the prior model v%d; please review it on the prior model construction page, confirm and rerun.",
        candidate$lhs[[1]], candidate$op[[1]], candidate$rhs[[1]], spec$revision))
      session$sendCustomMessage("sem-builder-load", list(id = session$ns("model_builder"), model_spec = sem_model_message_payload(spec)))
    }, ignoreInit = TRUE)
    output$optimization_status <- shiny::renderText({
      text <- if (!identical(current_spec()$method, "covariance_sem")) {
        "The above is the diagnosis and manual adjustment route; after modifying the model, please keep the original version and refit, compare and verify."
      } else optimization_message()
      text
    })
    generated_code_value <- shiny::reactive({
      base_code <- if (isTRUE(input$run > 0L) && !stale()) result()$generated_code else
        tryCatch(sem_generate_code(data_bundle(), current_spec(), options()), error = function(error) paste0("# ", conditionMessage(error)))
      base_code
    })
    dava_module_code_panel_server(
      input, output, session, file_data,
      source_prefix = function() paste(
        "structural_sem", input$method %||% navigation_alias, sep = "/"
      ),
      default_code = generated_code_value,
      source = "Structural Equation Model",
      title = "Structural equation model R Markdown code document",
      kind = "analysis",
      plot_params = function() dava_code_plot_params_from_input(input),
      data = function() model_build_data(),
      dataset_name = function() input$dataset %||% ".__sem_demo__",
      data_code = function() {
        if (!identical(input$dataset %||% ".__sem_demo__", ".__sem_demo__")) return(NULL)
        dava_local_demo_code("structural_sem/sem_data.rds", "grass_data")
      },
      function_mode = "none",
      code_document_style = "ols",
      preview_result = function() decorate_result(result()),
      preview_tables = function() sem_result_tables(decorate_result(result())),
      preview_plots = function() list("SEM effect plot" = sem_effect_plot(result())),
      preview_text = function() sem_model_text(decorate_result(result()))
    )
    output$messages <- shiny::renderText({
      protected <- dava_user_data_text(raw_data())
      if (stale()) return(dava_localize_model_text(
        paste(c("The model has changed and needs to be rerun.", last_error(),
          plot_runtime_diagnostics()), collapse = "\n"),
        interface_language(), protected
      ))
      value <- result()
      dava_localize_model_text(
        paste(c(value$warnings, value$errors, last_error(),
          plot_runtime_diagnostics()), collapse = "\n"),
        interface_language(), protected
      )
    })

    output$download_xlsx <- shiny::downloadHandler(function() sprintf("sem_%s_%s.xlsx", input$method, Sys.Date()), function(file) {
      value <- decorate_result(result()); tables <- sem_result_tables(value)
      tables$model_nodes <- value$final_model_spec$nodes; tables$model_edges <- value$final_model_spec$edges
      tables$generated_code <- data.frame(code = strsplit(value$generated_code, "\n", fixed = TRUE)[[1]])
      dava_write_xlsx(lapply(tables, as.data.frame), file)
    })
    request_result_export <- function(action, file_name) {
      shiny::req(result_editor_spec(), !stale())
      session$sendCustomMessage("sem-builder-export", list(id = session$ns("result_model_editor"),
        input_id = session$ns("result_model_export"), action = action, file_name = file_name))
    }
    shiny::observeEvent(input$download_png, request_result_export("png", "sem_path.png"), ignoreInit = TRUE)
    shiny::observeEvent(input$download_svg, request_result_export("svg", "sem_path.svg"), ignoreInit = TRUE)
    shiny::observeEvent(input$download_pdf, request_result_export("pdf", "sem_path.pdf"), ignoreInit = TRUE)
    shiny::observeEvent(input$download_tiff, request_result_export("tiff", "sem_path.tiff"), ignoreInit = TRUE)
    shiny::observeEvent(input$copy_path_to_svgedit,
      request_result_export("copy_to_svgedit", "sem_path.svg"), ignoreInit = TRUE)
    shiny::observeEvent(input$result_model_export, {
      payload <- input$result_model_export
      shiny::req(nzchar(payload$svg %||% ""))
      if (identical(payload$action, "copy_to_svgedit")) {
        session$sendCustomMessage("dava-load-svg-into-svgedit",
          list(svg = payload$svg, iframeId = "dava_svg_editor_iframe"))
        return(invisible(NULL))
      }
      shiny::validate(shiny::need(payload$action %in% c("pdf", "tiff"), "Unsupported result graph export."))
      shiny::validate(shiny::need(requireNamespace("rsvg", quietly = TRUE) && requireNamespace("base64enc", quietly = TRUE),
        "PDF/TIFF export requires the rsvg and base64enc packages."))
      svg_file <- tempfile(fileext = ".svg"); output_file <- tempfile(fileext = paste0(".", payload$action))
      on.exit(unlink(c(svg_file, output_file), force = TRUE), add = TRUE)
      writeLines(payload$svg, svg_file, useBytes = TRUE)
      if (identical(payload$action, "pdf")) {
        rsvg::rsvg_pdf(svg_file, output_file)
        mime_type <- "application/pdf"
      } else {
        shiny::validate(shiny::need(requireNamespace("png", quietly = TRUE), "TIFF export requires the png package."))
        png_file <- tempfile(fileext = ".png"); on.exit(unlink(png_file, force = TRUE), add = TRUE)
        rsvg::rsvg_png(svg_file, png_file, width = 2400)
        raster <- png::readPNG(png_file)
        grDevices::tiff(output_file, width = ncol(raster), height = nrow(raster), units = "px",
          res = 300, compression = "lzw")
        grid::grid.raster(raster); grDevices::dev.off()
        mime_type <- "image/tiff"
      }
      session$sendCustomMessage("sem-builder-download", list(file_name = payload$file_name,
        data_uri = paste0("data:", mime_type, ";base64,", base64enc::base64encode(output_file))))
    }, ignoreInit = TRUE)
    output$download_model <- shiny::downloadHandler(
      filename = function() sprintf("%s_v%d.json", make.names(current_spec()$model_name), current_spec()$revision),
      content = function(file) jsonlite::write_json(unclass(current_spec()), file, dataframe = "rows", auto_unbox = TRUE, null = "null", pretty = TRUE))
    registered_names <- shiny::reactiveVal(character())
    shiny::observeEvent(input$register, {
      selected_dataset <- shiny::isolate(input$dataset %||% "")
      tables <- sem_result_tables(decorate_result(result())); shiny::validate(shiny::need(length(tables), "There are no results to register."))
      prefix <- paste(input$dataset %||% "dataset", result()$method, paste0("v", result()$final_model_spec$revision), sep = "_")
      registered_names(dava_register_global_datasets(file_data, tables,
        source = paste("Structural Equation Model", result()$method, paste0("v", result()$final_model_spec$revision), sep = " / "), prefix = prefix))
      shiny::updateSelectInput(session, "dataset", selected = selected_dataset)
    }, ignoreInit = TRUE)
    invisible(list(result = result, current_spec = current_spec, component_models = component_models,
      revisions = revisions, fit_count = fit_count,
      stale = stale, last_error = last_error, result_editor_spec = result_editor_spec,
      result_editor_generation = result_editor_generation, registered_names = registered_names,
      optimization_analysis = optimization_analysis,
      cb_sidebar_state = cb_sidebar_state, cb_sidebar_snapshot = cb_sidebar_snapshot,
      cb_sidebar_validation = cb_sidebar_validation, cb_data_profile = cb_data_profile,
      cb_matrix_status = cb_matrix_status, cb_options = options))
  })
}
