sem_screening_numeric <- function(data, variables) {
  variables <- intersect(variables, names(data))
  variables <- variables[vapply(data[variables], is.numeric, logical(1))]
  if (length(variables) < 2L) stop("Data pretesting requires at least two numerical variables.", call. = FALSE)
  data[, variables, drop = FALSE]
}

sem_screen_normality <- function(data) {
  rows <- lapply(names(data), function(variable) {
    values <- data[[variable]]
    values <- values[is.finite(values)]
    if (length(values) < 3L) return(data.frame(variable = variable, n = length(values), statistic = NA_real_, p_value = NA_real_, normal_at_0_05 = NA))
    if (length(values) > 5000L) values <- values[seq_len(5000L)]
    test <- stats::shapiro.test(values)
    data.frame(variable = variable, n = length(values), statistic = unname(test$statistic),
      p_value = test$p.value, normal_at_0_05 = test$p.value >= 0.05)
  })
  do.call(rbind, rows)
}

sem_screen_correlation <- function(data, threshold = 0.1) {
  matrix <- stats::cor(data, use = "pairwise.complete.obs")
  mean_absolute <- vapply(seq_len(ncol(matrix)), function(index) {
    values <- abs(matrix[index, -index, drop = TRUE])
    mean(values[is.finite(values)], na.rm = TRUE)
  }, numeric(1))
  screening <- data.frame(variable = colnames(matrix), mean_absolute_correlation = mean_absolute,
    keep = mean_absolute >= threshold, threshold = threshold, row.names = NULL)
  list(matrix = matrix, screening = screening)
}

sem_screen_correlation_plot <- function(data) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) return(NULL)
  data <- sem_screening_numeric(data, names(data))
  variables <- names(data)
  correlation <- stats::cor(data, use = "pairwise.complete.obs")
  cells <- expand.grid(x = variables, y = variables, stringsAsFactors = FALSE)
  cells$x_index <- match(cells$x, variables)
  cells$y_index <- match(cells$y, variables)
  cells <- cells[cells$y_index >= cells$x_index, , drop = FALSE]
  cells$correlation <- correlation[cbind(cells$y_index, cells$x_index)]
  cells$p_value <- NA_real_
  off_diagonal <- cells$x_index != cells$y_index
  cells$p_value[off_diagonal] <- vapply(which(off_diagonal), function(index) {
    x <- data[[cells$x[[index]]]]; y <- data[[cells$y[[index]]]]
    keep <- stats::complete.cases(x, y)
    if (sum(keep) < 3L || stats::sd(x[keep]) == 0 || stats::sd(y[keep]) == 0) return(NA_real_)
    tryCatch(stats::cor.test(x[keep], y[keep])$p.value, error = function(error) NA_real_)
  }, numeric(1))
  cells$significance <- ifelse(!is.finite(cells$p_value), "",
    ifelse(cells$p_value < 0.001, "***", ifelse(cells$p_value < 0.01, "**",
      ifelse(cells$p_value < 0.05, "*", ""))))
  cells$label <- ifelse(is.finite(cells$correlation),
    paste0(sprintf("%.2f", cells$correlation), cells$significance), "")
  cells$x <- factor(cells$x, levels = variables)
  cells$y <- factor(cells$y, levels = rev(variables))
  label_size <- if (length(variables) <= 8L) 3.5 else 2.6
  ggplot2::ggplot(cells, ggplot2::aes(x = x, y = y, fill = correlation)) +
    ggplot2::geom_tile(colour = "white", linewidth = 0.6) +
    ggplot2::geom_text(ggplot2::aes(label = label), size = label_size, colour = "#202a30") +
    ggplot2::scale_fill_gradient2(low = "#2166ac", mid = "#f7f7f7", high = "#b2182b",
      midpoint = 0, limits = c(-1, 1), name = "r") +
    ggplot2::scale_x_discrete(drop = FALSE) + ggplot2::scale_y_discrete(drop = FALSE) +
    ggplot2::coord_fixed() +
    ggplot2::labs(x = NULL, y = NULL, caption = "The lower triangle is the Pearson correlation coefficient; * p<0.05, ** p<0.01, *** p<0.001.") +
    ggplot2::theme_minimal(base_size = 11) +
    ggplot2::theme(panel.grid = ggplot2::element_blank(), axis.text.x = ggplot2::element_text(angle = 45, hjust = 1),
      axis.text = ggplot2::element_text(colour = "#34434b"), legend.position = "right",
      plot.caption = ggplot2::element_text(colour = "#59636b", hjust = 0))
}

sem_screen_vif <- function(data, response, predictors, threshold = 5) {
  if (!requireNamespace("car", quietly = TRUE)) stop("VIF inspection requires the car package to be installed.", call. = FALSE)
  predictors <- setdiff(intersect(predictors, names(data)), response)
  if (!response %in% names(data) || length(predictors) < 2L) stop("The VIF test requires a response variable and at least two explanatory variables.", call. = FALSE)
  model <- stats::lm(stats::reformulate(predictors, response = response), data = data)
  values <- car::vif(model)
  if (is.matrix(values)) values <- values[, "GVIF"]^(1 / (2 * values[, "Df"]))
  values <- as.numeric(values)
  names(values) <- if (is.matrix(car::vif(model))) rownames(car::vif(model)) else names(car::vif(model))
  data.frame(variable = names(values), vif = values, keep = values < threshold, threshold = threshold, row.names = NULL)
}

sem_screen_random_forest <- function(data, response, predictors, seed = 20260717L) {
  if (!requireNamespace("ranger", quietly = TRUE)) stop("Random forest importance requires the ranger package to be installed.", call. = FALSE)
  predictors <- setdiff(intersect(predictors, names(data)), response)
  model_data <- data[, c(response, predictors), drop = FALSE]
  model_data <- model_data[stats::complete.cases(model_data), , drop = FALSE]
  set.seed(seed)
  fit <- ranger::ranger(stats::reformulate(predictors, response = response), data = model_data,
    importance = "permutation", seed = seed)
  importance <- sort(fit$variable.importance, decreasing = TRUE)
  data.frame(variable = names(importance), importance = as.numeric(importance), rank = seq_along(importance), row.names = NULL)
}

sem_screen_pca <- function(data) {
  complete <- data[stats::complete.cases(data), , drop = FALSE]
  fit <- stats::prcomp(complete, center = TRUE, scale. = TRUE)
  explained <- fit$sdev^2 / sum(fit$sdev^2)
  list(
    summary = data.frame(component = paste0("PC", seq_along(explained)), explained_variance = explained,
      cumulative_variance = cumsum(explained)),
    loadings = data.frame(variable = rownames(fit$rotation), fit$rotation, row.names = NULL, check.names = FALSE),
    scores = data.frame(fit$x, row.names = NULL, check.names = FALSE))
}

sem_screen_ordination <- function(data, community_variables, environmental_variables, method = "rda", permutations = 999L) {
  if (!requireNamespace("vegan", quietly = TRUE)) stop("RDA/CCA environment interpretation analysis requires the installation of the vegan package.", call. = FALSE)
  community_variables <- intersect(community_variables, names(data))
  environmental_variables <- setdiff(intersect(environmental_variables, names(data)), community_variables)
  if (length(community_variables) < 2L || !length(environmental_variables))
    stop("RDA/CCA requires at least two response variables and one environmental explanatory variable.", call. = FALSE)
  model_data <- data[, c(community_variables, environmental_variables), drop = FALSE]
  model_data <- model_data[stats::complete.cases(model_data), , drop = FALSE]
  response <- as.matrix(model_data[community_variables])
  environment <- model_data[environmental_variables]
  fit <- if (identical(method, "cca")) vegan::cca(response ~ ., data = environment) else vegan::rda(response ~ ., data = environment)
  test <- as.data.frame(vegan::anova.cca(fit, permutations = as.integer(permutations)))
  test$term <- rownames(test); rownames(test) <- NULL
  r_squared <- vegan::RsquareAdj(fit)
  list(method = toupper(method), fit = fit, test = test,
    explained = data.frame(r_squared = unname(r_squared$r.squared), adjusted_r_squared = unname(r_squared$adj.r.squared)))
}

sem_run_data_screening <- function(data, variables, response, correlation_threshold = 0.1, vif_threshold = 5,
    community_variables = character(), ordination_method = "rda", permutations = 999L, seed = 20260717L) {
  numeric_data <- sem_screening_numeric(data, variables)
  predictors <- setdiff(names(numeric_data), response)
  list(
    normality = sem_screen_normality(numeric_data),
    correlation = sem_screen_correlation(numeric_data, correlation_threshold),
    vif = tryCatch(sem_screen_vif(numeric_data, response, predictors, vif_threshold), error = function(error) data.frame(error = conditionMessage(error))),
    random_forest = tryCatch(sem_screen_random_forest(numeric_data, response, predictors, seed), error = function(error) data.frame(error = conditionMessage(error))),
    pca = sem_screen_pca(numeric_data),
    ordination = tryCatch(sem_screen_ordination(numeric_data, community_variables,
      setdiff(predictors, community_variables), ordination_method, permutations),
      error = function(error) list(method = toupper(ordination_method), test = data.frame(error = conditionMessage(error)), explained = data.frame())))
}
sem_build_composite_variable <- function(data, construct_name, variables, method = "z_mean",
    reverse_variables = character(), score_direction = 1, compute_alpha = TRUE, data_is_standardized = FALSE) {
  if (!grepl("^[A-Za-z][A-Za-z0-9_.]*$", construct_name)) stop("Construct names must be safe R variable names.", call. = FALSE)
  variables <- unique(intersect(variables, names(data)))
  if (length(variables) < 2L) stop("Constructing a composite variable requires at least two valid data variables.", call. = FALSE)
  selected <- data[, variables, drop = FALSE]
  original_selected <- selected
  if (!all(vapply(selected, is.numeric, logical(1)))) stop("Composite variable indicators must all be numeric.", call. = FALSE)
  complete <- stats::complete.cases(selected)
  if (sum(complete) < 3L) stop("Insufficient complete observations to construct composite variable.", call. = FALSE)
  standardized_selected <- if (isTRUE(data_is_standardized)) selected else as.data.frame(scale(selected))
  details <- list(method = method, variables = variables, construct_name = construct_name)
  alpha_data <- standardized_selected
  alpha_result <- if (isTRUE(compute_alpha) && requireNamespace("psych", quietly = TRUE)) {
    tryCatch(suppressWarnings(suppressMessages(psych::alpha(alpha_data))), error = function(error) NULL)
  } else NULL
  details$alpha <- if (!is.null(alpha_result)) unname(alpha_result$total$raw_alpha) else NA_real_
  details$alpha_table <- data.frame(construct = construct_name, cronbach_alpha = details$alpha,
    alpha_above_0_7 = is.finite(details$alpha) && details$alpha > 0.7,
    stringsAsFactors = FALSE)
  if (method == "z_mean") {
    reverse_variables <- intersect(reverse_variables, variables)
    scaled <- as.matrix(standardized_selected)
    if (length(reverse_variables)) scaled[, reverse_variables] <- -scaled[, reverse_variables, drop = FALSE]
    alpha_data <- as.data.frame(scaled)
    if (isTRUE(compute_alpha) && requireNamespace("psych", quietly = TRUE)) {
      alpha_result <- tryCatch(suppressWarnings(suppressMessages(psych::alpha(alpha_data))), error = function(error) NULL)
      details$alpha <- if (!is.null(alpha_result)) unname(alpha_result$total$raw_alpha) else NA_real_
      details$alpha_table$cronbach_alpha <- details$alpha
      details$alpha_table$alpha_above_0_7 <- is.finite(details$alpha) && details$alpha > 0.7
    }
    score <- rowMeans(scaled, na.rm = TRUE)
    score[rowSums(!is.na(scaled)) == 0L] <- NA_real_
    details$reverse_variables <- reverse_variables
  } else if (method == "pca") {
    fit <- stats::prcomp(standardized_selected[complete, , drop = FALSE], center = FALSE, scale. = FALSE)
    score <- rep(NA_real_, nrow(data)); score[complete] <- fit$x[, 1] * as.numeric(score_direction)
    details$model <- fit
    explained <- fit$sdev^2 / sum(fit$sdev^2)
    details$summary_text <- capture.output(print(data.frame(
      component = paste0("PC", seq_along(explained)), standard_deviation = fit$sdev,
      explained_variance = explained, cumulative_variance = cumsum(explained)),
      row.names = FALSE, digits = 4))
    loading_table <- data.frame(variable = rownames(fit$rotation), fit$rotation,
      row.names = NULL, check.names = FALSE)
    details$loading_text <- capture.output(print(loading_table, row.names = FALSE, digits = 4))
  } else if (method == "factor") {
    fit <- stats::factanal(standardized_selected[complete, , drop = FALSE], factors = 1L, scores = "regression")
    score <- rep(NA_real_, nrow(data)); score[complete] <- as.numeric(fit$scores[, 1])
    details$model <- fit
    loading_table <- data.frame(variable = rownames(unclass(fit$loadings)),
      loading = as.numeric(fit$loadings[, 1]), row.names = NULL)
    details$loading_text <- capture.output(print(loading_table, row.names = FALSE, digits = 4))
  } else stop("Unsupported composite variable construction method.", call. = FALSE)
  details$score <- as.numeric(score)
  validation_indicators <- original_selected
  if (identical(method, "z_mean") && length(reverse_variables))
    validation_indicators[reverse_variables] <- lapply(validation_indicators[reverse_variables], function(value) -value)
  details$preview <- data.frame(validation_indicators,
    stats::setNames(list(details$score), construct_name), check.names = FALSE)
  details
}

sem_standardize_numeric_data <- function(data) {
  as.data.frame(lapply(data, function(x) if (is.numeric(x)) as.numeric(scale(x)) else x),
    stringsAsFactors = FALSE, check.names = FALSE)
}

sem_composite_construction_code <- function(validation, data_name = "sem_dat", data_is_standardized = FALSE) {
  quote_names <- function(values) paste(dQuote(values, q = FALSE), collapse = ", ")
  construct <- validation$construct_name
  variables <- validation$variables
  lines <- c(sprintf("# Build composite variable: %s", construct),
    sprintf("composite_data <- %s[, c(%s), drop = FALSE]", data_name, quote_names(variables)))
  if (identical(validation$method, "z_mean")) {
    reverse <- validation$reverse_variables %||% character()
    if (length(reverse)) lines <- c(lines,
      sprintf("composite_data[, c(%s)] <- -composite_data[, c(%s), drop = FALSE]",
        quote_names(reverse), quote_names(reverse)))
    lines <- c(lines, if (isTRUE(data_is_standardized)) "composite_z <- as.matrix(composite_data)" else "composite_z <- scale(composite_data)",
      sprintf("%s$%s <- rowMeans(composite_z, na.rm = TRUE)", data_name, construct),
      sprintf("%s$%s[rowSums(!is.na(composite_z)) == 0L] <- NA_real_", data_name, construct),
      character())
  } else if (identical(validation$method, "pca")) {
    direction <- validation$score_direction %||% 1
    lines <- c(lines, "composite_complete <- complete.cases(composite_data)",
      if (isTRUE(data_is_standardized)) "composite_z <- composite_data" else "composite_z <- as.data.frame(scale(composite_data))",
      "composite_pca <- prcomp(composite_z[composite_complete, , drop = FALSE], center = FALSE, scale. = FALSE)",
      sprintf("%s$%s <- NA_real_", data_name, construct),
      sprintf("%s$%s[composite_complete] <- composite_pca$x[, 1] * %s", data_name, construct, direction))
  } else {
    lines <- c(lines, "composite_complete <- complete.cases(composite_data)",
      if (isTRUE(data_is_standardized)) "composite_z <- composite_data" else "composite_z <- as.data.frame(scale(composite_data))",
      "composite_fa <- factanal(composite_z[composite_complete, , drop = FALSE], factors = 1, scores = \"regression\")",
      sprintf("%s$%s <- NA_real_", data_name, construct),
      sprintf("%s$%s[composite_complete] <- as.numeric(composite_fa$scores[, 1])", data_name, construct))
  }
  paste(lines, collapse = "\n")
}

sem_composite_construction_row <- function(validation) {
  method_labels <- c(z_mean = "Z-score mean", pca = "PCA score", factor = "Factor-analysis score")
  data.frame(construct = validation$construct_name, method = unname(method_labels[validation$method]),
    indicators = paste(validation$variables, collapse = ", "),
    reversed_indicators = paste(validation$reverse_variables %||% character(), collapse = ", "),
    score_direction = if (identical(validation$method, "pca")) validation$score_direction %||% 1 else NA_real_,
    complete_scores = sum(is.finite(validation$score)), missing_scores = sum(!is.finite(validation$score)),
    cronbach_alpha = validation$alpha %||% NA_real_, alpha_above_0_7 = isTRUE(validation$alpha > 0.7),
    stringsAsFactors = FALSE)
}

sem_composite_reliability_row <- function(validation) validation$alpha_table %||%
  data.frame(construct = validation$construct_name, cronbach_alpha = NA_real_, alpha_above_0_7 = FALSE)

sem_composite_correlations <- function(validation) {
  data <- validation$preview[c(validation$variables, validation$construct_name)]
  pairs <- utils::combn(names(data), 2L, simplify = FALSE)
  rows <- lapply(pairs, function(pair) {
    keep <- stats::complete.cases(data[[pair[[1]]]], data[[pair[[2]]]])
    test <- if (sum(keep) >= 3L) stats::cor.test(data[[pair[[1]]]][keep], data[[pair[[2]]]][keep]) else NULL
    p <- if (is.null(test)) NA_real_ else test$p.value
    data.frame(x = pair[[1]], y = pair[[2]], correlation = if (is.null(test)) NA_real_ else unname(test$estimate),
      p_value = p, significance = if (is.na(p)) "" else if (p < 0.001) "***" else if (p < 0.01) "**" else if (p < 0.05) "*" else "",
      stringsAsFactors = FALSE)
  })
  do.call(rbind, rows)
}

sem_composite_correlation_plot <- function(validation) {
  values <- sem_composite_correlations(validation)
  variable_order <- c(validation$variables, validation$construct_name)
  ggplot2::ggplot(values, ggplot2::aes(x = x, y = y, fill = correlation)) +
    ggplot2::geom_tile(colour = "white", linewidth = 0.8) +
    ggplot2::geom_text(ggplot2::aes(label = sprintf("%.2f%s", correlation, significance)), size = 4) +
    ggplot2::scale_fill_gradient2(low = "#3976a8", mid = "white", high = "#c84b4b", midpoint = 0, limits = c(-1, 1)) +
    ggplot2::scale_x_discrete(limits = variable_order, drop = FALSE) +
    ggplot2::scale_y_discrete(limits = rev(variable_order), drop = FALSE) +
    ggplot2::coord_equal() + ggplot2::labs(x = NULL, y = NULL, fill = "r") +
    ggplot2::theme_minimal(base_size = 12) + ggplot2::theme(panel.grid = ggplot2::element_blank(), axis.text.x = ggplot2::element_text(angle = 35, hjust = 1))
}
