sem_result_table_labels <- function(method, fields) {
  common <- c(data_adequacy = "Data Suitability", parameter_estimates = "Parameter estimation", r_squared = "Explanatory power R²")
  method_labels <- switch(method,
    covariance_sem = c(fit_measures = "Overall fit index", standardized_estimates = "Normalization parameters",
      measurement_results = "Measurement model", structural_results = "structure path", residuals = "Residual matrix",
      variance_diagnostics = "Variable Variance Diagnosis", modification_indices = "Correction index"),
      piecewise_sem = c(composite_construction = "Composite variable construction", parameter_estimates = "Normalized path coefficient", d_sep = "Missing path check (d-separation)",
      basis_set = "Basic independent set", fisher_c = "Global fitting (Fisher C)", component_diagnostics = "Step-by-step model diagnosis", r_squared = "Step-by-step model R²",
      direct_effects = "Direct effect", indirect_effects = "Indirect effects", total_effects = "Total effect",
      model_comparison = "AIC/AICc model comparison"),
    pls_pm = c(goodness_of_fit = "Goodness of fit GoF", fit_measures = "Model quality and explanatory power",
      outer_model = "External measurement model", inner_model = "Internal structure model", construct_scores = "Construct Score",
      reliability = "Reliability and validity", direct_effects = "Direct effect", indirect_effects = "Indirect effects",
      total_effects = "Total effect", collinearity = "Intra-model collinearity VIF",
      dummy_encoding = "Dummy variable coding for categorical variables", bootstrap_results = "Bootstrap path"), character())
  labels <- c(common, method_labels)
  unname(ifelse(fields %in% names(labels), labels[fields], fields))
}

sem_generate_code <- function(bundle, spec, options = list()) {
  data_name <- bundle$dataset_name %||% "grass_data"
  source_data_name <- if (identical(data_name, ".__sem_demo__")) "grass_data" else make.names(data_name)
  standardize_data <- isTRUE(options$data_standardization) && identical(bundle$input_type %||% "raw_data", "raw_data")
  analysis_data_name <- if (standardize_data) "grass_std" else source_data_name
  standardization_code <- if (standardize_data) c("# Standardize numeric variables",
    sprintf("grass_std <- as.data.frame(lapply(%s, function(x) if (is.numeric(x)) as.numeric(scale(x)) else x))",
      source_data_name)) else character()
  lines <- switch(spec$method,
    covariance_sem = {
      has_measurement_model <- any(spec$nodes$node_type == "latent_variable")
      measurement_code <- if (has_measurement_model) c(
        "# Evaluate standardized loadings, composite reliability (CR), and AVE.",
        "standardized_loadings <- lavaan::parameterEstimates(fit_lavaan, standardized = TRUE) %>%",
        "  dplyr::filter(op == \"=~\") %>%",
        "  dplyr::transmute(construct = lhs, indicator = rhs, loading = std.all, loading_above_0_6 = abs(std.all) > 0.6)",
        "measurement_validity <- standardized_loadings %>%",
        "  dplyr::group_by(construct) %>%",
        "  dplyr::summarise(CR = sum(loading)^2 / (sum(loading)^2 + sum(1 - loading^2)),",
        "    AVE = sum(loading^2) / (sum(loading^2) + sum(1 - loading^2)), .groups = \"drop\") %>%",
        "  dplyr::mutate(CR_above_0_7 = CR > 0.7, AVE_above_0_5 = AVE > 0.5)",
        "# Prefer semTools for composite reliability and AVE when available.",
        "if (requireNamespace(\"semTools\", quietly = TRUE)) {",
        "  CR_semTools <- semTools::compRelSEM(fit_lavaan)",
        "  AVE_semTools <- semTools::AVE(fit_lavaan)",
        "}") else character()
      c("library(lavaan)", "library(dplyr)", standardization_code,
        "# Define and fit the CB-SEM model.", sprintf("model_syntax <- %s", dQuote(sem_graph_to_lavaan(spec), q = FALSE)),
        if (identical(bundle$input_type %||% "raw_data", "covariance_matrix"))
          sprintf("fit_lavaan <- lavaan::sem(model_syntax, sample.cov = %s, sample.nobs = %d, estimator = %s)",
            data_name, bundle$sample_size, dQuote(options$estimator %||% "ML", q = FALSE)) else
          sprintf("fit_lavaan <- lavaan::sem(model_syntax, data = %s, estimator = %s, missing = %s, fixed.x = %s)",
            analysis_data_name, dQuote(options$estimator %||% "MLR", q = FALSE), dQuote(options$missing %||% "fiml", q = FALSE),
            if (isTRUE(options$fixed_x)) "TRUE" else "FALSE"),
        "# Model summary with standardized estimates and confidence intervals.",
        "model_summary <- summary(fit_lavaan, standardized = TRUE, ci = TRUE)",
        "# Extract standardized structural path coefficients.",
        "standardized_paths <- lavaan::parameterEstimates(fit_lavaan, standardized = TRUE) %>%",
        "  dplyr::filter(op == \"~\") %>%",
        "  dplyr::select(lhs, rhs, est, se, pvalue, std.all)", measurement_code,
        "# Assess absolute, incremental, and parsimonious fit jointly; never use one index alone.",
        "fit_indices <- lavaan::fitMeasures(fit_lavaan, c(\"chisq\", \"df\", \"rmsea\", \"rmsea.ci.lower\",",
        "  \"rmsea.ci.upper\", \"srmr\", \"cfi\", \"tli\", \"aic\", \"bic\"))",
        "chisq_df <- unname(fit_indices[\"chisq\"] / fit_indices[\"df\"])",
        "model_summary", "standardized_paths",
        if (has_measurement_model) c("standardized_loadings", "measurement_validity") else character(),
        "fit_indices", "chisq_df")
    },
    piecewise_sem = {
      formulas <- sem_graph_to_piecewise(spec); component_specs <- sem_piecewise_component_specs(formulas, options)
      models <- options$component_models %||% sem_piecewise_components_from_spec(spec, component_specs)
      composite_code <- sem_piecewise_composite_data_code(spec, analysis_data_name,
        options$composite_records %||% NULL, data_is_standardized = standardize_data)
      c("library(piecewiseSEM)", "library(dplyr)", sprintf("# Model revision %d", spec$revision),
        standardization_code, composite_code,
        sem_piecewise_components_to_code(models, analysis_data_name, "psem_grass"),
        "# ============================================================", "# Overall results", "# ============================================================",
        "sem_result <- summary(psem_grass, standardize = \"scale\")", "print(sem_result)",
        "# Basis set, directed separation and Fisher C", "basis_set <- piecewiseSEM::basisSet(psem_grass)",
        "d_sep <- piecewiseSEM::dSep(psem_grass)", "fisher_c <- piecewiseSEM::fisherC(psem_grass)",
        "print(basis_set)", "print(d_sep)", "print(fisher_c)",
        "# Standardized path coefficients and local R-squared", "path_table <- piecewiseSEM::coefs(psem_grass, standardize = \"scale\")", "r2_table <- piecewiseSEM::rsquared(psem_grass)", "print(path_table)", "print(r2_table)",
        "# Direct, indirect and total effects are calculated from standardized paths.",
        if (isTRUE(options$bootstrap)) c("# Bootstrap indirect effects with percentile 95% CIs are computed by the analysis engine.", sprintf("# Replicates: %d", as.integer(options$bootstrap_samples %||% 500L)), "# A configured cluster variable is resampled by independent clusters.") else character())
    },
    pls_pm = {
      design <- sem_graph_to_plspm(spec)
      model_code <- strsplit(sem_plspm_model_code(spec, include_fit = FALSE), "\n", fixed = TRUE)[[1]]
      c("library(plspm)",
        "# install.packages(\"fastDummies\") # Run once if the package is unavailable.",
        "library(fastDummies)", standardization_code, "",
        model_code, "",
        "# Automatically dummy-code categorical indicators; the original dataset is unchanged.",
        sprintf("pls_data <- %s", analysis_data_name),
        "all_indicators <- unique(unlist(blocks, use.names = FALSE))",
        "categorical_vars <- all_indicators[vapply(pls_data[all_indicators], function(x) is.factor(x) || is.character(x) || is.ordered(x), logical(1))]",
        "if (length(categorical_vars)) {",
        "  pls_data <- fastDummies::dummy_cols(pls_data, select_columns = categorical_vars,",
        "    remove_first_dummy = TRUE, remove_selected_columns = TRUE)",
        "  dummy_map <- setNames(lapply(categorical_vars, function(variable)",
        "    names(pls_data)[startsWith(names(pls_data), paste0(variable, \"_\"))]), categorical_vars)",
        "  blocks <- lapply(blocks, function(block) unname(unlist(lapply(block, function(variable)",
        "    if (variable %in% categorical_vars) dummy_map[[variable]] else variable), use.names = FALSE)))",
        "}", "",
        "# Fit PLS-SEM with construct-specific Mode A/Mode B measurement settings.",
        sprintf("pls_model <- plspm::plspm(pls_data, path_matrix, blocks, modes = modes, scheme = %s,",
          dQuote(options$scheme %||% "path", q = FALSE)),
        sprintf("  scaled = %s, boot.val = %s, maxiter = %d, tol = %s, br = %d)",
          if (isTRUE(options$scaled %||% TRUE)) "TRUE" else "FALSE",
          if (isTRUE(options$bootstrap %||% TRUE)) "TRUE" else "FALSE",
          as.integer(options$max_iterations %||% 100L), format(options$tolerance %||% 1e-6, scientific = TRUE),
          as.integer(options$bootstrap_samples %||% 500L)), "",
        "# Full model results, GoF, measurement model, structural model and construct scores.",
        "print(pls_model)", "pls_model$gof", "pls_model$outer_model", "pls_model$inner_model",
        "pls_model$scores", "if (!is.null(pls_model$quality)) pls_model$quality", "",
        "# Direct, indirect and total effects.", "pls_model$effects", "",
        "# Inner-model VIF; values below 3.3 meet the recommended threshold.",
        "inner_vif <- do.call(rbind, lapply(rownames(path_matrix), function(target) {",
        "  predictors <- colnames(path_matrix)[path_matrix[target, ] != 0]",
        "  if (!length(predictors)) return(NULL)",
        "  do.call(rbind, lapply(predictors, function(predictor) {",
        "    others <- setdiff(predictors, predictor)",
        "    value <- if (!length(others)) 1 else 1 / (1 - summary(lm(reformulate(others, predictor), data = pls_model$scores))$r.squared)",
        "    data.frame(target = target, predictor = predictor, VIF = value, VIF_below_3.3 = value < 3.3)",
        "  }))",
        "}))", "print(inner_vif)")
    })
  code <- paste(lines, collapse = "\n")
  parse(text = code)
  code
}

sem_find_column <- function(data, candidates) {
  if (!is.data.frame(data) || !ncol(data)) return(NA_character_)
  normalized <- gsub("[^a-z0-9]", "", tolower(names(data)))
  wanted <- gsub("[^a-z0-9]", "", tolower(candidates))
  match_index <- match(wanted, normalized, nomatch = 0L)
  match_index <- match_index[match_index > 0L]
  if (length(match_index)) names(data)[match_index[[1]]] else NA_character_
}

sem_result_path_labels <- function(result, standardized = TRUE) {
  data <- result$structural_results
  if (!is.data.frame(data) || !nrow(data)) return(data.frame())
  if (identical(result$method, "covariance_sem")) {
    data <- data[data$op == "~", , drop = FALSE]
    estimate <- if ("std.all" %in% names(data)) data$std.all else data$est
    return(data.frame(source = data$rhs, target = data$lhs, estimate = estimate,
      p_value = data$pvalue %||% NA_real_, stringsAsFactors = FALSE))
  }
  source_column <- sem_find_column(data, c("source", "predictor"))
  target_column <- sem_find_column(data, c("target", "response"))
  estimate_column <- if (isTRUE(standardized)) sem_find_column(data, c("std.estimate", "standardized", "std.all")) else sem_find_column(data, c("estimate", "coefficient", "est"))
  p_column <- sem_find_column(data, c("p.value", "pvalue"))
  if (anyNA(c(source_column, target_column, estimate_column))) return(data.frame())
  data.frame(source = as.character(data[[source_column]]), target = as.character(data[[target_column]]),
    estimate = as.numeric(data[[estimate_column]]),
    p_value = if (!is.na(p_column)) as.numeric(data[[p_column]]) else NA_real_, stringsAsFactors = FALSE)
}

sem_result_r_squared <- function(result) {
  data <- result$r_squared
  if ((!is.data.frame(data) || !nrow(data)) && identical(result$method, "pls_pm") && !is.null(result$fitted_model$inner_summary)) {
    data <- as.data.frame(result$fitted_model$inner_summary)
    data$variable <- rownames(data)
  }
  variable_column <- sem_find_column(data, c("variable", "response", "name"))
  value_column <- sem_find_column(data, c("r_squared", "rsquared", "r2"))
  if (anyNA(c(variable_column, value_column))) return(data.frame())
  data.frame(variable = as.character(data[[variable_column]]), r_squared = as.numeric(data[[value_column]]), stringsAsFactors = FALSE)
}

sem_result_path_annotations <- function(result, spec, p_threshold = 0.05) {
  if (is.null(spec) || !nrow(spec$edges)) return(data.frame())
  active <- if ("active" %in% names(spec$edges)) as.logical(spec$edges$active) else rep(TRUE, nrow(spec$edges))
  directed <- spec$edges[active & spec$edges$edge_type == "directed_path", , drop = FALSE]
  if (!nrow(directed)) return(data.frame())
  names_by_id <- stats::setNames(vapply(spec$nodes$id, sem_node_variable, character(1), spec = spec), spec$nodes$id)
  annotations <- data.frame(edge_id = directed$id, source = unname(names_by_id[directed$source]),
    target = unname(names_by_id[directed$target]), estimate = NA_real_, p_value = NA_real_,
    significant = NA, status = "unavailable", label = "", line_color = "#9b9b9b",
    line_width = 1.2, line_style = "solid", stringsAsFactors = FALSE)
  paths <- sem_result_path_labels(result, standardized = TRUE)
  if (!is.data.frame(paths) || !nrow(paths)) return(annotations)
  for (index in seq_len(nrow(annotations))) {
    match_index <- which(paths$source == annotations$source[[index]] & paths$target == annotations$target[[index]])
    if (!length(match_index)) next
    selected <- match_index[[1]]
    estimate <- suppressWarnings(as.numeric(paths$estimate[[selected]]))
    p_value <- suppressWarnings(as.numeric(paths$p_value[[selected]]))
    if (!is.finite(estimate)) next
    non_significant <- is.finite(p_value) && p_value > p_threshold
    significant <- is.finite(p_value) && p_value <= p_threshold
    stars <- if (!is.finite(p_value)) "" else if (p_value <= 0.001) "***" else if (p_value <= 0.01) "**" else if (p_value <= p_threshold) "*" else ""
    annotations$estimate[[index]] <- estimate
    annotations$p_value[[index]] <- if (is.finite(p_value)) p_value else NA_real_
    annotations$significant[[index]] <- if (is.finite(p_value)) significant else NA
    annotations$status[[index]] <- if (non_significant) "non_significant" else if (significant) "significant" else "p_unavailable"
    annotations$label[[index]] <- if (non_significant) "" else sprintf("%.2f%s", estimate, stars)
    annotations$line_color[[index]] <- if (non_significant) "#9b9b9b" else if (estimate < 0) "#d73027" else "#111111"
    annotations$line_width[[index]] <- max(1.2, min(8, 1.2 + 6 * abs(estimate)))
  }
  annotations
}

sem_model_text <- function(result) {
  if (is.null(result) || !inherits(result, "sem_result")) return("The model has not been run yet.")
  sections <- c(sprintf("Method: %s", result$method), "", "Model syntax:", result$model_syntax %||% "")
  if (!is.null(result$fitted_model)) {
    summary_text <- tryCatch(capture.output(summary(result$fitted_model, standardized = TRUE, ci = TRUE)),
      error = function(error) tryCatch(capture.output(summary(result$fitted_model)),
        error = function(inner_error) paste("Summary unavailable:", conditionMessage(inner_error))))
    sections <- c(sections, "", "Model summary:", summary_text)
  }
  append_table <- function(title, value) {
    if (is.data.frame(value) && nrow(value)) c("", title, capture.output(print(value, row.names = FALSE))) else character()
  }
  sections <- c(sections,
    append_table("Composite variable construction:", result$composite_construction),
    append_table("Cronbach's alpha reliability (alpha > 0.7):", result$composite_reliability),
    append_table("Overall fit indices (evaluate jointly; do not judge by one metric):", result$fit_measures),
    append_table("Standardized structural paths:", result$standardized_estimates),
    append_table("Measurement validity (loading > 0.6, CR > 0.7, AVE > 0.5):", result$measurement_results),
    append_table("Observed-variable variance diagnostics:", result$variance_diagnostics),
    append_table("R-squared:", result$r_squared),
    append_table("Residuals:", result$residuals),
    append_table("Modification indices:", result$modification_indices),
    append_table("D-separation:", result$d_sep),
    append_table("Fisher C:", result$fisher_c),
    append_table("Component diagnostics:", result$component_diagnostics),
    append_table("Basis set:", result$basis_set),
    append_table("Direct effects:", result$direct_effects),
    append_table("Indirect effects:", result$indirect_effects),
    append_table("Total effects:", result$total_effects),
    append_table("Outer model:", result$outer_model),
    append_table("Inner model:", result$inner_model),
    append_table("PLS goodness-of-fit (GoF):", result$goodness_of_fit),
    append_table("PLS reliability and validity:", result$reliability),
    append_table("PLS inner-model collinearity (VIF < 3.3):", result$collinearity),
    append_table("Categorical indicator dummy encoding:", result$dummy_encoding),
    append_table("Construct scores:", result$construct_scores),
    append_table("Bootstrap results:", result$bootstrap_results),
    if (length(result$warnings)) c("", "Warnings:", paste0("- ", result$warnings)) else character())
  paste(sections, collapse = "\n")
}

sem_effect_plot_data <- function(result) {
  tables <- list(direct = result$direct_effects, indirect = result$indirect_effects,
    total = result$total_effects)
  frames <- lapply(names(tables), function(type) {
    value <- tables[[type]]
    if (!is.data.frame(value) || !nrow(value) || !all(c("Response", "Predictor", "Effect") %in% names(value))) return(NULL)
    template <- sem_effect_empty()
    for (name in setdiff(names(template), names(value))) {
      prototype <- template[[name]]
      value[[name]] <- if (is.logical(prototype)) rep(NA, nrow(value)) else if (is.numeric(prototype))
        rep(NA_real_, nrow(value)) else rep("", nrow(value))
    }
    value$Effect.Type <- type
    value
  })
  frames <- Filter(Negate(is.null), frames)
  if (!length(frames)) return(data.frame())
  data <- do.call(rbind, frames)
  data$Effect.Type <- factor(data$Effect.Type, levels = c("direct", "indirect", "total"))
  data$Label <- paste(data$Predictor, "→", data$Response,
    ifelse(nzchar(data$Group), paste0(" [", data$Group, "]"), ""))
  data$Evidence <- ifelse(is.na(data$Significant), "not_tested",
    ifelse(!data$Significant, "non_significant",
      ifelse(data$Effect >= 0, "positive_significant", "negative_significant")))
  data$Annotation <- ifelse(is.na(data$Significant), "",
    ifelse(data$Significant, data$Significance, "ns"))
  data$Annotation.X <- ifelse(data$Effect >= 0,
    ifelse(is.finite(data$CI.Upper), data$CI.Upper, data$Effect),
    ifelse(is.finite(data$CI.Lower), data$CI.Lower, data$Effect))
  finite_effects <- abs(data$Effect[is.finite(data$Effect)])
  annotation_offset <- if (length(finite_effects)) max(0.02, max(finite_effects) * 0.04) else 0.02
  data$Annotation.X <- ifelse(data$Effect >= 0, data$Annotation.X + annotation_offset,
    data$Annotation.X - annotation_offset)
  data
}

sem_effect_plot <- function(result) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) return(NULL)
  data <- sem_effect_plot_data(result)
  method_title <- switch(result$method, covariance_sem = "Lavaan CB-SEM", piecewise_sem = "piecewiseSEM",
    pls_pm = "plspm PLS-SEM", "Structural Equation Model")
  if (!nrow(data)) return(ggplot2::ggplot() + ggplot2::annotate("text", x = 0, y = 0,
    label = paste0(method_title, " There is no drawing effect yet"), size = 5, colour = "#59636b") +
    ggplot2::theme_void())
  ci_data <- data[is.finite(data$CI.Lower) & is.finite(data$CI.Upper), , drop = FALSE]
  facet_labels <- c(direct = "Direct effect", indirect = "Indirect effects", total = "Total effect")
  evidence_colours <- c(positive_significant = "#147d6f", negative_significant = "#c23b4a",
    non_significant = "#9aa1a6", not_tested = "#536878")
  evidence_shapes <- c(positive_significant = 21, negative_significant = 21,
    non_significant = 1, not_tested = 4)
  evidence_labels <- c(positive_significant = "Significant positive effect", negative_significant = "Significant negative effect",
    non_significant = "Not significant", not_tested = "Not checked")
  ggplot2::ggplot(data, ggplot2::aes(x = Effect, y = stats::reorder(Label, abs(Effect)), colour = Evidence)) +
    ggplot2::geom_vline(xintercept = 0, linewidth = 0.45, linetype = "dashed", colour = "#7b858d") +
    ggplot2::geom_errorbar(data = ci_data, ggplot2::aes(xmin = CI.Lower, xmax = CI.Upper),
      orientation = "y", width = 0.16, linewidth = 0.55, show.legend = FALSE) +
    ggplot2::geom_point(ggplot2::aes(shape = Evidence), size = 3.2, stroke = 0.8, fill = "white") +
    ggplot2::geom_text(ggplot2::aes(x = Annotation.X, label = Annotation,
      hjust = ifelse(Effect >= 0, 0, 1)), size = 3.15, colour = "#28333b", show.legend = FALSE) +
    ggplot2::facet_wrap(~Effect.Type, ncol = 3, scales = "free_y", drop = FALSE,
      labeller = ggplot2::as_labeller(facet_labels)) +
    ggplot2::scale_colour_manual(values = evidence_colours, labels = evidence_labels, drop = FALSE) +
    ggplot2::scale_shape_manual(values = evidence_shapes, labels = evidence_labels, drop = FALSE) +
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0.18, 0.30))) +
    ggplot2::labs(title = paste0(method_title, " Standardization effect"), subtitle = "Direct, indirect and total effects and significance test",
      x = "Standardized effect size", y = NULL, colour = NULL, shape = NULL,
      caption = "Dots represent effect sizes, horizontal lines represent 95% CI; * p<0.05, ** p<0.01, *** p<0.001.") +
    ggplot2::coord_cartesian(clip = "off") +
    ggplot2::theme_bw(base_size = 11) +
    ggplot2::theme(plot.title = ggplot2::element_text(face = "bold", size = 14),
      plot.subtitle = ggplot2::element_text(colour = "#59636b"), strip.background = ggplot2::element_rect(fill = "#eef2f3", colour = "#aab4ba"),
      strip.text = ggplot2::element_text(face = "bold", size = 11), panel.grid.major.y = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(), panel.spacing.x = grid::unit(1.2, "lines"),
      legend.position = "bottom", plot.margin = ggplot2::margin(8, 46, 8, 8))
}

sem_result_editor_spec <- function(result, p_threshold = 0.05) {
  spec <- result$prior_model_spec %||% result$final_model_spec
  if (is.null(spec)) return(NULL)
  spec <- unserialize(serialize(spec, NULL))
  r_squared <- sem_result_r_squared(result)
  node_names <- vapply(spec$nodes$id, sem_node_variable, character(1), spec = spec)
  annotations <- sem_result_path_annotations(result, spec, p_threshold)
  active <- if ("active" %in% names(spec$edges)) as.logical(spec$edges$active) else rep(TRUE, nrow(spec$edges))
  endogenous_ids <- unique(spec$edges$target[active & spec$edges$edge_type == "directed_path"])
  if (!"label" %in% names(spec$edges)) spec$edges$label <- ""
  if (!"line_color" %in% names(spec$edges)) spec$edges$line_color <- "#567483"
  if (!"line_width" %in% names(spec$edges)) spec$edges$line_width <- 2
  if (!"line_style" %in% names(spec$edges)) spec$edges$line_style <- ifelse(spec$edges$edge_type == "covariance", "dashed", "solid")
  if (!"label_font_size" %in% names(spec$edges)) spec$edges$label_font_size <- 11
  if (!"label_color" %in% names(spec$edges)) spec$edges$label_color <- "#17242b"
  if (!"label_offset_x" %in% names(spec$edges)) spec$edges$label_offset_x <- 0
  if (!"label_offset_y" %in% names(spec$edges)) spec$edges$label_offset_y <- 0
  spec$nodes$result_endogenous <- spec$nodes$id %in% endogenous_ids
  spec$nodes$result_r_squared <- NA_real_
  spec$edges$result_estimate <- NA_real_
  spec$edges$result_p_value <- NA_real_
  spec$edges$result_significant <- NA
  spec$edges$result_status <- "not_structural"
  for (index in seq_len(nrow(spec$nodes))) {
    label <- spec$nodes$label[[index]] %||% node_names[[index]]
    r_index <- if (spec$nodes$id[[index]] %in% endogenous_ids) match(node_names[[index]], r_squared$variable) else NA_integer_
    if (!is.na(r_index) && is.finite(r_squared$r_squared[[r_index]])) {
      spec$nodes$result_r_squared[[index]] <- r_squared$r_squared[[r_index]]
      label <- sprintf("%s\nR² = %.2f", label, r_squared$r_squared[[r_index]])
    }
    spec$nodes$label[[index]] <- label
  }
  for (index in seq_len(nrow(spec$edges))) {
    if (!identical(spec$edges$edge_type[[index]], "directed_path")) next
    annotation_index <- match(spec$edges$id[[index]], annotations$edge_id)
    if (is.na(annotation_index)) next
    spec$edges$label[[index]] <- annotations$label[[annotation_index]]
    spec$edges$line_color[[index]] <- annotations$line_color[[annotation_index]]
    spec$edges$line_width[[index]] <- annotations$line_width[[annotation_index]]
    spec$edges$line_style[[index]] <- annotations$line_style[[annotation_index]]
    spec$edges$result_estimate[[index]] <- annotations$estimate[[annotation_index]]
    spec$edges$result_p_value[[index]] <- annotations$p_value[[annotation_index]]
    spec$edges$result_significant[[index]] <- annotations$significant[[annotation_index]]
    spec$edges$result_status[[index]] <- annotations$status[[annotation_index]]
  }
  spec$model_name <- paste0(spec$model_name, " - results")
  spec$provenance$result_overlay <- TRUE
  spec$provenance$result_annotation <- list(p_threshold = p_threshold, coefficient = "standardized",
    positive_color = "#111111", negative_color = "#d73027", non_significant_color = "#9b9b9b",
    non_significant_labels = FALSE, source = c("model_syntax", "prior_model_spec", "analysis_result"))
  spec
}
