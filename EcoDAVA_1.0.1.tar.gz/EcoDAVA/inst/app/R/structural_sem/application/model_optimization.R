sem_optimization_model_profile <- function(spec) {
  if (is.null(spec) || !inherits(spec, "sem_model_spec")) {
    return(list(id = "unknown", label = "Model type not yet recognized", method = ""))
  }
  node_types <- unique(as.character(spec$nodes$node_type))
  if (identical(spec$method, "piecewise_sem")) {
    composite <- "composite_construct" %in% node_types
    return(list(
      id = if (composite) "piecewise_composite" else "piecewise_manifest",
      label = if (composite) "Composite variable path model" else "Manifest variable path model",
      method = "piecewiseSEM"
    ))
  }
  if (identical(spec$method, "pls_pm")) {
    latent <- "latent_variable" %in% node_types
    return(list(
      id = if (latent) "pls_latent" else "pls_manifest",
      label = if (latent) "Latent variable path model" else "Manifest variable path model",
      method = "PLS-PM"
    ))
  }
  list(id = "cbsem", label = "Covariance structure equation model", method = "CB-SEM")
}

sem_optimization_find_column <- function(table, candidates) {
  if (!is.data.frame(table) || !ncol(table)) return(NA_character_)
  normalized <- gsub("[^a-z0-9]", "", tolower(names(table)))
  index <- match(gsub("[^a-z0-9]", "", tolower(candidates)), normalized)
  index <- index[!is.na(index)]
  if (length(index)) names(table)[index[[1]]] else NA_character_
}

sem_optimization_numeric <- function(table, candidates) {
  column <- sem_optimization_find_column(table, candidates)
  if (is.na(column)) return(numeric())
  suppressWarnings(as.numeric(table[[column]]))
}

sem_optimization_strategy_table <- function(spec, result = NULL) {
  profile <- sem_optimization_model_profile(spec)
  fitted <- inherits(result, "sem_result") && identical(result$status, "success")
  rows <- list()
  add <- function(priority, dimension, evidence, strategy, rule) {
    rows[[length(rows) + 1L]] <<- data.frame(
      priority = priority, adjustment_dimension = dimension, diagnostic_evidence = evidence,
      optimization_strategy = strategy, decision_rule = rule,
      stringsAsFactors = FALSE, check.names = FALSE)
  }

  active_edges <- spec$edges[
    as.logical(spec$edges$active) & spec$edges$edge_type == "directed_path", , drop = FALSE]
  node_names <- stats::setNames(
    vapply(spec$nodes$id, sem_node_variable, character(1), spec = spec), spec$nodes$id)
  endogenous <- unique(unname(node_names[active_edges$target]))
  model_evidence <- sprintf("Node: manifest variable %d, latent variable %d, composite variable %d; structure path %d",
    sum(spec$nodes$node_type == "observed_variable"),
    sum(spec$nodes$node_type == "latent_variable"),
    sum(spec$nodes$node_type == "composite_construct"), nrow(active_edges))

  if (profile$id == "piecewise_manifest") {
    add("1-High", "Model types and causal structures", model_evidence,
      "Check path directions, missing direct effects, and common causes one by one according to the manifest variable path model; add paths only when supported by ecological/experimental theory.",
      "Confirm causal time order first; prohibit data-driven incremental edge addition just to improve fit.")
    add("2-High", "Global fitting and d-separation", "Check Fisher's C, basis set and d-separation",
      "If the global test fails, priority is given to reviewing significant independence claims in d-separation, and missing relationships with theoretical basis as candidate models.",
      "Fisher's C of P < 0.05 indicates that the model is inconsistent with the data; candidate pathways require independent validation.")
    add("3-High", "Stepwise regression model", paste("Endogenous response:", paste(endogenous, collapse = "、")),
      "Checks residuals, normality/heteroskedasticity, overdispersion, zero-inflation, and influence points separately for each response; choose lm, glm, glmmTMB, or GAM based on the response distribution.",
      "The distribution family, link function, and random effects structure of the local model must match the sampling design.")
    add("4-medium", "Hierarchy and Dependence", "Examine plot, block, time, or repeated measurement structures",
      "Add random intercepts/random slopes when grouping or repeated measurements are present; compare reasonable random structures and check for singular fits.",
      "Do not treat repeated observations of the same subject as independent samples.")
  } else if (profile$id == "piecewise_composite") {
    composite_names <- spec$nodes$construct_name[spec$nodes$node_type == "composite_construct"]
    composite_names <- composite_names[nzchar(composite_names)]
    add("1-High", "Composite variable construction", paste("Composite variable:", paste(composite_names, collapse = "、")),
      "First review the theoretical isotropy, dimensions, missingness and outliers of the indicators, and then compare the construction methods such as standardized mean, PCA/factor scores; record the reverse scoring and weights.",
      "The construction method should be determined by the construct definition; changing the construction method must refit the entire step-by-step model.")
    add("2-High", "Composite variable robustness", "Examine Cronbach's alpha, indicator correlations, loadings, and leave-one-out indicator sensitivity",
      "Check the internal consistency of reflective indicators; do not use α as the basis for deleting indicators for formative composite variables, and instead check weight stability, collinearity and content validity.",
      "The reflective scale can refer to α ≥ 0.70; the formative indicators are judged by VIF, weight bootstrap and theoretical coverage.")
    add("3-High", "Global fitting and missing paths", "Check Fisher's C, basis set and d-separation",
      "When the global test fails, first determine whether the problem comes from composite scores or structural omissions; only significant independence claims with theoretical basis are converted into candidate paths.",
      "A Fisher's C of P < 0.05 requires adjusting or comparing models without mechanically adding all significant paths.")
    add("4-medium", "Step-by-step model and hierarchy", paste("Endogenous response:", paste(endogenous, collapse = "、")),
      "Examine distributions, residuals, overdispersion, and random effects equation by equation; compare AIC/AICc and path stability using the same composite version.",
      "Candidate models must be defined using the same analysis sample and the same composite score.")
  } else if (profile$id == "pls_manifest") {
    add("1-High", "Model type and structure path", model_evidence,
      "Interpret single-indicator constructs according to manifest variable path models; check path direction, omitted confounding, and mediating order, and do not interpret single-indicator results as latent variables corrected for measurement error.",
      "Path additions and deletions are mainly based on theoretical and predicted goals and cannot be based solely on GoF.")
    add("2-High", "Path stability", "Check inner model and bootstrap paths",
      "Increase the number of bootstrap replicates and report coefficients, confidence intervals, and stability; compare prediction performance after retaining/removing unstable paths.",
      "It is not appropriate to draw conclusions based solely on sample coefficients for paths whose confidence intervals span 0; theoretically necessary paths can be retained and reported truthfully.")
    add("3-High", "Intra-model collinearity", "Check VIF for each endogenous variable predictor",
      "Check for redundant predictors, variable coding, and highly correlated parallel paths for high-VIF pathways; prioritizing merging or rearranging structures based on theory.",
      "It is recommended that VIF < 3.3; above the threshold, handle collinearity before interpreting path sizes.")
    add("4-medium", "Explanatory and predictive power", "Joint examination of R², effect size, and out-of-sample predictions",
      "Use cross-validation or hold-out sets to compare RMSE/MAE; report R² changes and prediction errors, do not use plspm GoF alone to judge model quality.",
      "The adjusted model should be no worse than the original model in out-of-sample predictions.")
  } else if (profile$id == "pls_latent") {
    construct_names <- spec$nodes$construct_name[spec$nodes$node_type == "latent_variable"]
    construct_names <- construct_names[nzchar(construct_names)]
    add("1-High", "Measurement model", paste("Latent variables:", paste(construct_names, collapse = "、")),
      "First distinguish between reflective Mode A and formative Mode B. Mode A checks external loading, indicator reliability, CR and AVE; Mode B checks external weight significance, VIF and content validity.",
      "Mode A can refer to load ≥ 0.708, CR 0.70–0.95, AVE ≥ 0.50; Mode B does not mechanically delete indicators according to the load threshold.")
    add("2-High", "Discriminant validity", "Checking Cross Loadings, Fornell–Larcker and HTMT",
      "If the construct distinction is insufficient, first review the item semantics and construct boundaries, and then consider merging constructs or deleting indicators that are indeed redundant.",
      "HTMT can refer to < 0.85 (loose standard < 0.90), combined with bootstrap interval judgment.")
    add("3-High", "Structural model", "Examine bootstrap paths, within-model VIF, R², and effect sizes",
      "Compares theoretically sound nested candidate structures for highly collinear or unstable paths; reports bootstrap intervals for direct, indirect, and total effects.",
      "Intra-model VIF recommendation < 3.3; interpret with caution when path confidence intervals span 0.")
    add("4-medium", "Predictive correlation", "Check Q²/PLSpredict or cross-validation error",
      "Use out-of-sample predictions to test whether adjustments improve; do not rely on GoF as the only evidence of overall fit for a latent variable model.",
      "Priority is given to models with acceptable measurement quality, lower prediction errors, and simpler structures.")
  }

  if (fitted && startsWith(profile$id, "piecewise")) {
    fisher_p <- sem_optimization_numeric(result$fisher_c, c("P.Value", "P", "pvalue"))
    dsep_p <- sem_optimization_numeric(result$d_sep, c("P.Value", "P", "pvalue"))
    evidence <- if (length(fisher_p) && any(is.finite(fisher_p)))
      sprintf("This time Fisher's C: Minimum P = %.4f", min(fisher_p, na.rm = TRUE)) else "The P value of Fisher's C cannot be automatically read this time"
    strategy <- if (length(fisher_p) && any(is.finite(fisher_p) & fisher_p < 0.05))
      "This global fitting failed: Prioritize the missing relationship with the smallest P value and theoretical support in the d-separation table, establish a candidate version, and then refit." else
      "No obvious mismatch was found in this global inspection; continue to check local model diagnosis and path stability, and there is no need to mechanically add edges in pursuit of higher fitting."
    if (length(dsep_p) && any(is.finite(dsep_p))) evidence <- paste0(evidence,
      sprintf("; d-separation minimum P = %.4f", min(dsep_p, na.rm = TRUE)))
    add("Result determination", "This fitting", evidence, strategy, "All adjustments retain the original model version and perform sensitivity comparisons.")
  }

  if (fitted && startsWith(profile$id, "pls")) {
    vif <- sem_optimization_numeric(result$collinearity, c("vif"))
    loadings <- sem_optimization_numeric(result$outer_model, c("loading", "loadings"))
    evidence <- c(
      if (length(vif) && any(is.finite(vif))) sprintf("Maximum inner model VIF = %.3f", max(vif, na.rm = TRUE)),
      if (length(loadings) && any(is.finite(loadings))) sprintf("Minimum absolute external load = %.3f", min(abs(loadings), na.rm = TRUE)))
    if (!length(evidence)) evidence <- "No VIF/payload column that can be automatically summarized was found in this result"
    flagged <- (length(vif) && any(is.finite(vif) & vif >= 3.3)) ||
      (profile$id == "pls_latent" && length(loadings) && any(is.finite(loadings) & abs(loadings) < 0.708))
    add("Result determination", "This fitting", paste(evidence, collapse = "；"),
      if (flagged) "There is a threshold warning in this result; review the measurement model first, then the structural model, and use bootstrap/out-of-sample prediction to verify candidate adjustments." else
        "There is no obvious early warning for this automatic threshold; discriminant validity, bootstrap and out-of-sample prediction checks still need to be completed.",
      "Thresholds are used for screening rather than automatically deleting indicators or paths.")
  }

  if (!length(rows)) return(data.frame())
  do.call(rbind, rows)
}

sem_model_optimization <- function(spec, result = NULL) {
  profile <- sem_optimization_model_profile(spec)
  fitted <- inherits(result, "sem_result") && identical(result$status, "success")
  list(
    profile = profile,
    strategies = sem_optimization_strategy_table(spec, result),
    summary = paste0(
      "Automatic recognition:", profile$method, " · ", profile$label, "\n",
      "Identification rules:", switch(profile$id,
        piecewise_composite = "composite_construct node detected.",
        piecewise_manifest = "No composite construct or latent variable nodes were detected, the structure consists of observed_variable nodes.",
        pls_latent = "latent_variable node detected.",
        pls_manifest = "No latent variable nodes were detected, the structure consists of observed_variable (manifest variable) nodes.",
        "Modified exponential process using CB-SEM."), "\n",
      "Policy status:", if (fitted) "has been generated based on the results of this fitting." else "is currently a general strategy before fitting; the result judgment will be added after running the model."
    )
  )
}
