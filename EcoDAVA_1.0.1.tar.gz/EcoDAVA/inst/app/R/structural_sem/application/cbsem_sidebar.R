sem_cbsem_sidebar_templates <- function() {
  list(
    continuous_path = list(id = "continuous_path", label = "Continuous variable path analysis",
      description = "Direct, indirect and covariance paths for continuous observed variables.", input_type = "raw_data",
      data_label = "Continuous raw data", latent = "forbidden", grouping = "none", estimator = "MLR"),
    continuous_latent = list(id = "continuous_latent", label = "Continuous latent variable SEM",
      description = "Joint analysis of measurement model and structural model of continuous indicators.", input_type = "raw_data",
      data_label = "Continuous raw data", latent = "required", grouping = "none", estimator = "MLR"),
    ordered_binary = list(id = "ordered_binary", label = "Ordinal or binary index SEM",
      description = "Latent variable or path models for endogenous ordinal or binary indicators.", input_type = "raw_data",
      data_label = "Raw data with ordinal or binary indicators", latent = "optional", grouping = "none", estimator = "WLSMV"),
    two_group = list(id = "two_group", label = "Comparison of two groups SEM",
      description = "Comparison of structural or latent variable means at exactly two valid levels.", input_type = "raw_data",
      data_label = "Raw data with two-level grouping variables", latent = "optional", grouping = "two", estimator = "MLR"),
    multi_group = list(id = "multi_group", label = "Multiple group comparison SEM",
      description = "Independent estimates, path comparisons, or measurement invariance at two or more levels.", input_type = "raw_data",
      data_label = "Raw data with multi-level grouping variables", latent = "optional", grouping = "multi", estimator = "MLR"),
    covariance_matrix = list(id = "covariance_matrix", label = "Covariance matrix SEM",
      description = "Fit using sample covariance matrix, sample size, and optional mean vector.", input_type = "covariance_matrix",
      data_label = "covariance matrix", latent = "optional", grouping = "none", estimator = "ML")
  )
}

sem_cbsem_sidebar_template_table <- function() {
  templates <- sem_cbsem_sidebar_templates()
  data.frame(id = names(templates), label = vapply(templates, `[[`, character(1), "label"),
    stringsAsFactors = FALSE)
}

sem_cbsem_sidebar_template <- function(template_id) {
  templates <- sem_cbsem_sidebar_templates()
  templates[[template_id %||% "continuous_path"]] %||% templates$continuous_path
}

sem_cbsem_model_summary <- function(spec) {
  latent <- spec$nodes$node_type == "latent_variable"
  observed <- spec$nodes$node_type == "observed_variable"
  indicators <- unique(c(spec$nodes$variable_name[observed & nzchar(spec$nodes$variable_name)],
    unlist(spec$nodes$indicator_variables[latent], use.names = FALSE)))
  active <- spec$edges$active
  indirect <- spec$constraints$indirect_effects %||% list()
  list(latent_variables = sum(latent), observed_indicators = length(indicators),
    structural_paths = sum(active & spec$edges$edge_type == "directed_path"),
    covariances = sum(active & spec$edges$edge_type %in% c("covariance", "residual_covariance")),
    indirect_effects = length(indirect), single_indicator = sum(latent & lengths(spec$nodes$indicator_variables) == 1L),
    two_indicator = sum(latent & lengths(spec$nodes$indicator_variables) == 2L),
    has_measurement = any(latent & lengths(spec$nodes$indicator_variables) >= 1L))
}

sem_cbsem_data_profile <- function(data, spec) {
  data <- as.data.frame(data, stringsAsFactors = FALSE, check.names = FALSE)
  model_variables <- unique(c(spec$nodes$variable_name[nzchar(spec$nodes$variable_name)],
    unlist(spec$nodes$indicator_variables, use.names = FALSE)))
  latent_indicators <- unique(unlist(spec$nodes$indicator_variables[spec$nodes$node_type == "latent_variable"], use.names = FALSE))
  endogenous_observed <- spec$nodes$variable_name[spec$nodes$node_type == "observed_variable" & spec$nodes$endogenous]
  endogenous_indicators <- unique(c(latent_indicators, endogenous_observed[nzchar(endogenous_observed)]))
  factor_names <- names(data)[vapply(data, function(value) is.factor(value) || is.character(value) || is.ordered(value), logical(1))]
  binary_numeric <- names(data)[vapply(data, function(value) is.numeric(value) && length(unique(value[!is.na(value)])) == 2L, logical(1))]
  ordered_names <- intersect(endogenous_indicators, unique(c(factor_names, binary_numeric)))
  low_cardinality <- names(data)[vapply(data, function(value) length(unique(value[!is.na(value)])) >= 2L && length(unique(value[!is.na(value)])) <= 20L, logical(1))]
  missing_cells <- sum(is.na(data)); total_cells <- max(1L, nrow(data) * max(1L, ncol(data)))
  numeric <- data[vapply(data, is.numeric, logical(1))]
  high_correlation <- FALSE
  if (ncol(numeric) >= 2L) {
    correlation <- suppressWarnings(stats::cor(numeric, use = "pairwise.complete.obs"))
    high_correlation <- any(abs(correlation[upper.tri(correlation)]) > 0.9, na.rm = TRUE)
  }
  sparse_ordered <- factor_names[vapply(data[factor_names], function(value) {
    counts <- table(value, useNA = "no"); length(counts) > 0L && any(counts < 10L)
  }, logical(1))]
  list(exists = nrow(data) > 0L && ncol(data) > 0L, rows = nrow(data), columns = ncol(data),
    numeric = names(numeric), categorical = factor_names, ordered_candidates = unique(c(factor_names, binary_numeric)),
    group_candidates = unique(c(factor_names, low_cardinality)),
    model_variables = model_variables, ordered_model_variables = ordered_names,
    missing_cells = missing_cells, missing_rate = missing_cells / total_cells,
    zero_variance = names(data)[vapply(data, function(value) length(unique(value[!is.na(value)])) < 2L, logical(1))],
    high_correlation = high_correlation, sparse_ordered = sparse_ordered, normality = "unknown")
}

sem_cbsem_covariance_status <- function(data, source = "derive", variables = character(), sample_size = NA_integer_,
    include_means = FALSE, mean_vector_text = "") {
  errors <- warnings <- character()
  sample_size <- suppressWarnings(as.integer(sample_size))
  if (!is.finite(sample_size) || sample_size < 2L) errors <- c(errors, "Sample size must be an integer no less than 2.")
  matrix_value <- NULL
  if (identical(source, "matrix")) {
    numeric_data <- data[vapply(data, is.numeric, logical(1))]
    if (nrow(data) != ncol(data) || ncol(numeric_data) != ncol(data)) {
      errors <- c(errors, "The current data set must be a complete square matrix of numeric values.")
    } else matrix_value <- as.matrix(numeric_data)
  } else {
    variables <- intersect(variables, names(data))
    variables <- variables[vapply(data[variables], is.numeric, logical(1))]
    if (length(variables) < 2L) errors <- c(errors, "Select at least two numeric variables to calculate the covariance matrix.")
    else matrix_value <- suppressWarnings(stats::cov(data[variables], use = "pairwise.complete.obs"))
  }
  if (!is.null(matrix_value)) {
    if (any(!is.finite(matrix_value))) errors <- c(errors, "Matrix contains non-finite values.")
    if (!isTRUE(all.equal(unname(matrix_value), unname(t(matrix_value)), tolerance = 1e-8)))
      errors <- c(errors, "The matrix is ​​not a symmetric matrix.")
    if (any(diag(matrix_value) <= 0, na.rm = TRUE)) errors <- c(errors, "Matrix diagonal must be positive.")
    eigenvalues <- tryCatch(eigen(matrix_value, symmetric = TRUE, only.values = TRUE)$values, error = function(error) numeric())
    if (length(eigenvalues) && any(eigenvalues < -1e-8)) errors <- c(errors, "The matrix is not a positive semidefinite matrix.")
    else if (length(eigenvalues) && any(eigenvalues <= 1e-8)) warnings <- c(warnings, "The matrix is ​​close to singular and the fit may be unstable.")
    if (isTRUE(include_means) && identical(source, "matrix")) {
      parsed <- suppressWarnings(as.numeric(trimws(strsplit(mean_vector_text %||% "", ",", fixed = TRUE)[[1]])))
      if (length(parsed) != ncol(matrix_value) || any(!is.finite(parsed)))
        errors <- c(errors, "The length of the mean vector must be consistent with the matrix dimensions, and all must be finite values.")
    }
  }
  list(valid = !length(errors), errors = unique(errors), warnings = unique(warnings),
    dimension = if (is.null(matrix_value)) 0L else ncol(matrix_value))
}

sem_cbsem_parameter <- function(value, source, overridden = FALSE, reason = "") {
  list(value = value, source = source, overridden = isTRUE(overridden), reason = reason)
}

sem_cbsem_normalize_sidebar <- function(template_id, profile, model_summary, user_overrides = list(), context = list()) {
  template <- sem_cbsem_sidebar_template(template_id)
  covariance_input <- identical(template$input_type, "covariance_matrix")
  has_ordered <- !covariance_input && length(profile$ordered_model_variables) > 0L
  estimator <- if (covariance_input) "ML" else if (identical(template$id, "ordered_binary") || has_ordered) "WLSMV" else
    if (identical(profile$normality, "normal")) "ML" else "MLR"
  missing <- if (covariance_input) "none" else if (identical(estimator, "WLSMV")) "pairwise" else
    if (profile$missing_cells > 0L) "fiml" else "listwise"
  latent <- model_summary$latent_variables > 0L
  template_defaults <- list(input_type = template$input_type, estimator = template$estimator,
    missing = if (covariance_input) "none" else "listwise", identification = if (latent) "fixed_variance" else "not_applicable",
    std_lv = latent, meanstructure = covariance_input && isTRUE(context$has_mean_vector), fixed_x = FALSE)
  data_recommendations <- list(estimator = estimator, missing = missing,
    ordered = if (identical(estimator, "WLSMV")) profile$ordered_model_variables else character(),
    parameterization = if (identical(estimator, "WLSMV")) "theta" else "none",
    se = if (identical(estimator, "MLR")) "robust.huber.white" else "standard")
  defaults <- list(input_type = template$input_type, estimator = estimator, missing = missing,
    identification = if (latent) "fixed_variance" else "not_applicable", std_lv = latent,
    allow_single_indicator = FALSE, constrain_two_indicator = model_summary$two_indicator > 0L,
    meanstructure = covariance_input && isTRUE(context$has_mean_vector), fixed_x = FALSE,
    parameterization = if (identical(estimator, "WLSMV")) "theta" else "none",
    ordered = if (identical(estimator, "WLSMV")) profile$ordered_model_variables else character(),
    group = if (template$grouping == "none") "" else context$group %||% "",
    group_levels = if (template$grouping == "none") character() else context$group_levels %||% character(),
    group_strategy = context$group_strategy %||% switch(template$grouping, two = "compare_paths", multi = "independent", "none"),
    group_equal = character(), group_release = "", reference_group = "",
    compare_latent_means = FALSE, compare_paths = template$grouping != "none",
    se = if (identical(estimator, "MLR")) "robust.huber.white" else "standard",
    bootstrap_enabled = FALSE, bootstrap_samples = 1000L, seed = 123L,
    sample_size = as.integer(context$sample_size %||% profile$rows),
    include_means = isTRUE(context$has_mean_vector),
    outputs = c("standardized", "ci", "r_squared", "direct_indirect", "fit_indices", "path_plot"))
  sources <- stats::setNames(rep("Template default", length(defaults)), names(defaults))
  for (name in c("estimator", "missing", "ordered", "parameterization", "se")) sources[[name]] <- "Data intelligent recommendation"
  compatible <- function(name, value) {
    if (covariance_input && name %in% c("missing", "ordered", "group", "group_levels", "group_strategy", "bootstrap_enabled")) return(FALSE)
    if (!latent && name %in% c("identification", "std_lv", "allow_single_indicator", "constrain_two_indicator", "compare_latent_means")) return(FALSE)
    if (!has_ordered && name %in% c("ordered", "parameterization")) return(FALSE)
    if (!has_ordered && name == "estimator" && value %in% c("WLSMV", "DWLS")) return(FALSE)
    if (covariance_input && name == "estimator" && !value %in% c("ML", "GLS", "ULS")) return(FALSE)
    if (template$grouping == "none" && name %in% c("group", "group_levels", "group_strategy", "group_equal", "group_release", "reference_group", "compare_latent_means", "compare_paths")) return(FALSE)
    if (estimator %in% c("WLSMV", "DWLS") && name == "missing" && identical(value, "fiml")) return(FALSE)
    if (estimator %in% c("WLSMV", "DWLS") && name == "bootstrap_enabled" && isTRUE(value)) return(FALSE)
    TRUE
  }
  cleared <- character()
  for (name in intersect(names(user_overrides), names(defaults))) {
    if (compatible(name, user_overrides[[name]])) {
      defaults[[name]] <- user_overrides[[name]]; sources[[name]] <- "User advanced settings override"
    } else cleared <- c(cleared, name)
  }
  if (defaults$estimator %in% c("WLSMV", "DWLS")) {
    if (!identical(defaults$missing, "pairwise")) cleared <- c(cleared, "missing")
    if (isTRUE(defaults$bootstrap_enabled)) cleared <- c(cleared, "bootstrap_enabled")
    defaults$missing <- "pairwise"; defaults$parameterization <- if (defaults$parameterization %in% c("theta", "delta")) defaults$parameterization else "theta"
    defaults$bootstrap_enabled <- FALSE; defaults$se <- "standard"
    sources[["missing"]] <- "Data intelligent recommendation"
    sources[["bootstrap_enabled"]] <- "Template default"
    sources[["se"]] <- "Data intelligent recommendation"
  }
  if (covariance_input) {
    if (!identical(defaults$missing, "none")) cleared <- c(cleared, "missing")
    if (isTRUE(defaults$bootstrap_enabled)) cleared <- c(cleared, "bootstrap_enabled")
    if (length(defaults$ordered)) cleared <- c(cleared, "ordered")
    if (nzchar(defaults$group)) cleared <- c(cleared, "group")
    defaults$missing <- "none"; defaults$ordered <- character(); defaults$group <- ""; defaults$group_levels <- character()
    defaults$bootstrap_enabled <- FALSE; defaults$meanstructure <- isTRUE(defaults$include_means)
  }
  parameters <- lapply(names(defaults), function(name) sem_cbsem_parameter(defaults[[name]], sources[[name]],
    identical(sources[[name]], "User advanced settings override"), switch(name,
      estimator = if (identical(defaults[[name]], "WLSMV")) "Model contains ordinal or binary indicators" else if (identical(defaults[[name]], "MLR")) "Normality is unknown or the data may be non-normal" else "Current situation default",
      missing = if (identical(defaults[[name]], "fiml")) "Continuous raw data has missing values" else "Compatible with estimators and data sources",
      identification = if (latent) "Model contains latent variables" else "The current model has no latent variables", "")))
  names(parameters) <- names(defaults)
  list(template = template, parameters = parameters, values = defaults, cleared = unique(cleared),
    layers = list(template_defaults = template_defaults, data_recommendations = data_recommendations,
      user_overrides = user_overrides[setdiff(names(user_overrides), unique(cleared))]),
    capabilities = list(covariance_input = covariance_input, latent = latent, ordered = has_ordered,
      grouping = template$grouping, raw_diagnostics = !covariance_input,
      estimators = if (covariance_input) c("ML", "GLS", "ULS") else if (has_ordered || identical(template$id, "ordered_binary"))
        c("WLSMV", "DWLS") else c("MLR", "ML"),
      missing = if (covariance_input) "none" else if (has_ordered || identical(template$id, "ordered_binary"))
        "pairwise" else c("fiml", "listwise"), bootstrap = !covariance_input && !has_ordered))
}

sem_cbsem_group_diagnostics <- function(data, variable, levels = character(), model_variables = names(data)) {
  if (!nzchar(variable %||% "") || !variable %in% names(data)) return(data.frame())
  values <- data[[variable]]; available <- unique(as.character(values[!is.na(values)]))
  selected <- if (length(levels)) intersect(levels, available) else available
  model_variables <- intersect(model_variables, names(data))
  data.frame(level = selected, samples = vapply(selected, function(level) sum(as.character(values) == level, na.rm = TRUE), integer(1)),
    missing_group = vapply(selected, function(level) sum(is.na(data[as.character(values) == level, model_variables, drop = FALSE])), integer(1)),
    zero_variance = vapply(selected, function(level) any(vapply(data[as.character(values) == level, model_variables, drop = FALSE],
      function(column) length(unique(column[!is.na(column)])) < 2L, logical(1))), logical(1)),
    adequate = vapply(selected, function(level) sum(as.character(values) == level, na.rm = TRUE) >= 30L, logical(1)),
    stringsAsFactors = FALSE)
}

sem_cbsem_validate_sidebar <- function(snapshot, profile, model_summary, group_diagnostics = data.frame(), matrix_status = NULL) {
  values <- snapshot$values; template <- snapshot$template
  errors <- warnings <- suggestions <- character()
  if (!isTRUE(profile$exists)) errors <- c(errors, "The data source does not exist or is empty.")
  if (identical(template$input_type, "covariance_matrix") && (!is.finite(values$sample_size) || values$sample_size < 2L))
    errors <- c(errors, "The covariance matrix mode must provide a valid sample size.")
  if (identical(template$input_type, "covariance_matrix") && !is.null(matrix_status)) {
    errors <- c(errors, matrix_status$errors %||% character())
    warnings <- c(warnings, matrix_status$warnings %||% character())
  }
  if (identical(template$grouping, "two") && length(values$group_levels) != 2L)
    errors <- c(errors, "Exactly two valid levels must be chosen for two sets of comparisons.")
  if (identical(template$grouping, "multi") && length(values$group_levels) < 2L)
    errors <- c(errors, "Multiple comparisons must select at least two valid levels.")
  if (identical(values$estimator, "WLSMV") && identical(values$missing, "fiml")) errors <- c(errors, "Ordinal indicators cannot use FIML.")
  if (identical(template$latent, "required") && (!model_summary$latent_variables || !model_summary$has_measurement))
    errors <- c(errors, "The latent variable template requires at least one latent variable and measurement relationship.")
  if (identical(template$latent, "forbidden") && model_summary$latent_variables > 0L)
    errors <- c(errors, "The continuous variable path template temporarily disables the latent variable structure; the model node has been reserved, please switch the template or edit the prior model.")
  if (identical(template$id, "ordered_binary") && !length(profile$ordered_model_variables))
    errors <- c(errors, "The ordered or binary indicator template has not yet identified endogenous ordered indicators.")
  if (identical(template$input_type, "covariance_matrix") && !identical(values$missing, "none"))
    errors <- c(errors, "Covariance matrix mode does not preserve original missing data handling.")
  if (nrow(group_diagnostics) && any(!group_diagnostics$adequate)) warnings <- c(warnings, "Some group sample sizes are below 30.")
  if (model_summary$two_indicator) warnings <- c(warnings, "The model contains two indicator latent variables, please check the identification constraints.")
  if (model_summary$single_indicator) warnings <- c(warnings, "The model contains a single indicator latent variable, please set reliability or error constraints.")
  if (!identical(template$input_type, "covariance_matrix") && identical(values$estimator, "ML") &&
      !identical(profile$normality, "normal")) warnings <- c(warnings, "Normality not confirmed but ML was manually selected.")
  if (profile$missing_rate > 0.2) warnings <- c(warnings, "More than 20% of data are missing.")
  if (isTRUE(profile$high_correlation)) warnings <- c(warnings, "There are variables with absolute correlation coefficients higher than 0.90.")
  if (length(profile$sparse_ordered)) warnings <- c(warnings, paste("Ordinal variable level sparseness:", paste(profile$sparse_ordered, collapse = "、")))
  if (length(profile$zero_variance)) warnings <- c(warnings, paste("There is a zero-variance variable:", paste(profile$zero_variance, collapse = "、")))
  suggestions <- c(suggestions, sprintf("Recommended estimator: %s; missing handling: %s.", values$estimator, values$missing))
  if (model_summary$latent_variables) suggestions <- c(suggestions, "recommends examining the CFA measurement model before interpreting structural paths.")
  list(valid = !length(errors), errors = unique(errors), warnings = unique(warnings), suggestions = unique(suggestions))
}
