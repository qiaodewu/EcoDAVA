sem_cbsem_fit_table <- function(fit, sample_size) {
  fit_names <- c("chisq", "df", "rmsea", "rmsea.ci.lower", "rmsea.ci.upper", "srmr", "cfi", "tli", "aic", "bic")
  values <- tryCatch(lavaan::fitMeasures(fit, fit_names), error = function(error)
    stats::setNames(rep(NA_real_, length(fit_names)), fit_names))
  ratio <- unname(values[["chisq"]] / values[["df"]])
  metric <- c("CHISQ/DF", "RMSEA", "RMSEA 90% CI LOWER", "RMSEA 90% CI UPPER", "SRMR", "CFI", "TLI", "AIC", "BIC")
  value <- c(ratio, values[c("rmsea", "rmsea.ci.lower", "rmsea.ci.upper", "srmr", "cfi", "tli", "aic", "bic")])
  criterion <- c(if (sample_size > 200L) "1-3; optimal <2" else "1-3; optimal <2",
    "<0.06 excellent; <0.08 acceptable", "report with RMSEA", "<0.08", "<0.08 excellent; <0.10 acceptable",
    ">0.95 excellent; >0.90 acceptable", ">0.95 excellent; >0.90 acceptable",
    "smaller is better for model comparison", "smaller is better for model comparison")
  if (anyNA(values)) assessment <- rep("Unavailable: model did not converge", length(metric)) else assessment <- c(
    if (ratio < 2) "Excellent" else if (ratio < 3) "Acceptable" else "Review model",
    if (value[[2]] < 0.06) "Excellent" else if (value[[2]] < 0.08) "Acceptable" else "Review model",
    "Confidence interval", if (value[[4]] < 0.08) "Acceptable upper bound" else "Upper bound too high",
    if (value[[5]] < 0.08) "Excellent" else if (value[[5]] < 0.1) "Acceptable" else "Review model",
    if (value[[6]] > 0.95) "Excellent" else if (value[[6]] > 0.9) "Acceptable" else "Review model",
    if (value[[7]] > 0.95) "Excellent" else if (value[[7]] > 0.9) "Acceptable" else "Review model",
    "Compare candidate models", "Compare candidate models")
  data.frame(metric, value = as.numeric(value), criterion, assessment, stringsAsFactors = FALSE)
}

sem_cbsem_named_metric <- function(value, metric_name) {
  if (is.null(value)) return(numeric())
  if (is.matrix(value) || is.data.frame(value)) {
    value <- as.data.frame(value)
    column <- names(value)[tolower(names(value)) == tolower(metric_name)][1]
    if (is.na(column)) column <- names(value)[1]
    result <- as.numeric(value[[column]])
    names(result) <- rownames(value)
    return(result)
  }
  result <- as.numeric(value)
  names(result) <- names(value)
  result
}

sem_cbsem_measurement_validity <- function(fit, parameters) {
  loadings <- parameters[parameters$op == "=~", c("lhs", "rhs", "est", "se", "pvalue", "std.all"), drop = FALSE]
  if (!nrow(loadings)) return(data.frame())
  names(loadings)[1:2] <- c("construct", "indicator")
  loadings$loading <- loadings$std.all
  summaries <- lapply(split(loadings$std.all, loadings$construct), function(lambda) {
    error_variance <- pmax(0, 1 - lambda^2)
    cr <- sum(lambda)^2 / (sum(lambda)^2 + sum(error_variance))
    ave <- sum(lambda^2) / (sum(lambda^2) + sum(error_variance))
    c(CR = cr, AVE = ave)
  })
  summary_table <- data.frame(construct = names(summaries), do.call(rbind, summaries), row.names = NULL)
  engine <- "standardized_loadings_fallback"
  if (requireNamespace("semTools", quietly = TRUE)) {
    semtools_values <- tryCatch(list(CR = semTools::compRelSEM(fit), AVE = semTools::AVE(fit)), error = function(error) NULL)
    if (!is.null(semtools_values)) {
      cr <- sem_cbsem_named_metric(semtools_values$CR, "CR")
      ave <- sem_cbsem_named_metric(semtools_values$AVE, "AVE")
      cr_match <- match(summary_table$construct, names(cr)); ave_match <- match(summary_table$construct, names(ave))
      if (all(!is.na(cr_match)) && all(!is.na(ave_match))) {
        summary_table$CR <- cr[cr_match]; summary_table$AVE <- ave[ave_match]
        engine <- "semTools::compRelSEM + semTools::AVE"
      }
    }
  }
  summary_table$validity_engine <- engine
  result <- merge(loadings, summary_table, by = "construct", all.x = TRUE, sort = FALSE)
  result$loading_above_0_6 <- abs(result$loading) > 0.6
  summary_table$CR_above_0_7 <- summary_table$CR > 0.7
  summary_table$AVE_above_0_5 <- summary_table$AVE > 0.5
  result$CR_above_0_7 <- result$CR > 0.7
  result$AVE_above_0_5 <- result$AVE > 0.5
  result[c("construct", "indicator", "est", "se", "pvalue", "std.all", "loading", "CR", "AVE",
    "validity_engine", "loading_above_0_6", "CR_above_0_7", "AVE_above_0_5")]
}

sem_cbsem_variance_diagnostics <- function(fit) {
  table <- tryCatch(as.data.frame(lavaan::varTable(fit)), error = function(error) data.frame())
  if (!nrow(table) || !all(c("name", "var") %in% names(table))) return(data.frame())
  variance <- suppressWarnings(as.numeric(table$var))
  positive <- variance[is.finite(variance) & variance > 0]
  minimum <- if (length(positive)) min(positive) else NA_real_
  ratio <- if (is.finite(minimum)) variance / minimum else rep(NA_real_, length(variance))
  data.frame(variable = as.character(table$name), observations = as.integer(table$nobs %||% NA_integer_),
    mean = suppressWarnings(as.numeric(table$mean %||% NA_real_)), variance = variance,
    standard_deviation = sqrt(pmax(variance, 0)), variance_ratio_to_smallest = ratio,
    ratio_above_1000 = is.finite(ratio) & ratio >= 1000,
    recommendation = ifelse(is.finite(ratio) & ratio >= 1000,
      "The dimensions vary greatly; please check the units and check Data Standardization on the left if necessary.", "Dimensional differences are acceptable."),
    stringsAsFactors = FALSE)
}

sem_cbsem_warning_message <- function(message) {
  message <- trimws(sub("^lavaan WARNING:\\s*", "", message))
  if (grepl("observed variances are", message, fixed = TRUE))
    return("Observed variable variances differ in magnitude by at least a factor of 1000; see the Variable Variance Diagnostics, verify the units, and enable data normalization as needed.")
  paste0("lavaan：", message)
}

sem_fit_covariance <- function(bundle, spec, options = list()) {
  dependency <- sem_method_dependency_status("covariance_sem")
  if (!dependency$available) stop("Missing package: ", paste(dependency$missing, collapse = ", "), call. = FALSE)
  syntax <- sem_graph_to_lavaan(spec)
  if (!nzchar(syntax)) stop("The prior model has no estimable statements.", call. = FALSE)
  estimator <- options$estimator %||% "MLR"
  covariance_input <- identical(bundle$input_type %||% "raw_data", "covariance_matrix")
  ordered <- if (covariance_input) character() else intersect(options$ordered %||% bundle$ordered_variables, names(bundle$data))
  if (length(ordered) && identical(estimator, "MLR")) estimator <- "WLSMV"
  use_fiml <- !covariance_input && identical(options$missing %||% "fiml", "fiml")
  fit_args <- list(model = syntax, estimator = estimator, fixed.x = options$fixed_x %||% FALSE,
    std.lv = options$std_lv %||% FALSE, meanstructure = isTRUE(options$meanstructure) || use_fiml,
    se = options$se %||% "standard",
    bootstrap = if (identical(options$se, "bootstrap")) as.integer(options$bootstrap %||% 1000L) else 1000L)
  if (covariance_input) {
    fit_args$sample.cov <- bundle$covariance_matrix
    fit_args$sample.nobs <- bundle$sample_size
    if (!is.null(bundle$sample_means) && isTRUE(options$meanstructure)) fit_args$sample.mean <- bundle$sample_means
  } else {
    latent_names <- spec$nodes$construct_name[spec$nodes$node_type == "latent_variable"]
    latent_names <- latent_names[nzchar(latent_names)]
    fit_args$data <- bundle$data[, setdiff(names(bundle$data), latent_names), drop = FALSE]
    fit_args$ordered <- if (length(ordered)) ordered else NULL
    fit_args$missing <- if (estimator == "WLSMV") "pairwise" else options$missing %||% "fiml"
    fit_args$group <- if (nzchar(options$group %||% "")) options$group else NULL
  }
  lavaan_warnings <- character()
  fit <- withCallingHandlers(do.call("sem", fit_args, envir = asNamespace("lavaan")),
    warning = function(warning) {
      lavaan_warnings <<- c(lavaan_warnings, sem_cbsem_warning_message(conditionMessage(warning)))
      invokeRestart("muffleWarning")
    })
  parameters <- as.data.frame(lavaan::parameterEstimates(fit, standardized = TRUE, ci = TRUE))
  sample_size <- if (covariance_input) bundle$sample_size else nrow(bundle$data)
  fit_measures <- sem_cbsem_fit_table(fit, sample_size)
  measurement_validity <- sem_cbsem_measurement_validity(fit, parameters)
  standardized_paths <- parameters[parameters$op == "~",
    intersect(c("lhs", "rhs", "est", "se", "pvalue", "std.all"), names(parameters)), drop = FALSE]
  r2 <- tryCatch(data.frame(variable = names(lavaan::inspect(fit, "r2")), r_squared = as.numeric(lavaan::inspect(fit, "r2"))), error = function(e) data.frame())
  residual_table <- tryCatch(as.data.frame(lavaan::residuals(fit, type = "cor")$cov),
    error = function(error) data.frame(error = conditionMessage(error)))
  modification_table <- tryCatch(as.data.frame(lavaan::modindices(fit)),
    error = function(error) data.frame(error = conditionMessage(error)))
  variance_diagnostics <- sem_cbsem_variance_diagnostics(fit)
  effects <- sem_cbsem_effects(fit, parameters)
  new_sem_result("covariance_sem", prior_model_spec = spec, final_model_spec = spec, model_syntax = syntax,
    fitted_model = fit, fit_measures = fit_measures, parameter_estimates = parameters,
    standardized_estimates = standardized_paths, measurement_results = measurement_validity,
    variance_diagnostics = variance_diagnostics,
    structural_results = parameters[parameters$op == "~", , drop = FALSE], r_squared = r2,
    direct_effects = effects$direct, indirect_effects = effects$indirect, total_effects = effects$total,
    residuals = residual_table, modification_indices = modification_table,
    warnings = unique(c(lavaan_warnings,
      if (!lavaan::lavInspect(fit, "converged")) "lavaan did not converge." else character())),
    package_versions = data.frame(package = "lavaan", version = as.character(packageVersion("lavaan")), stringsAsFactors = FALSE),
    available_outputs = c("fit_measures", "standardized_estimates", "measurement_results", "parameter_estimates",
      "variance_diagnostics", "direct_effects", "indirect_effects", "total_effects", "r_squared", "residuals", "modification_indices"),
    available_plots = "effect_plot")
}

sem_piecewise_family <- function(name) {
  switch(name %||% "gaussian", gaussian = stats::gaussian(), binomial = stats::binomial(),
    poisson = stats::poisson(), Gamma = stats::Gamma(link = "log"),
    negative_binomial = if (requireNamespace("MASS", quietly = TRUE)) MASS::negative.binomial(theta = 1) else NULL,
    stop("Unsupported component family: ", name, call. = FALSE))
}

sem_piecewise_family_call <- function(name) {
  switch(name %||% "gaussian", gaussian = quote(stats::gaussian()), binomial = quote(stats::binomial()),
    poisson = quote(stats::poisson()), Gamma = quote(stats::Gamma(link = "log")),
    negative_binomial = quote(MASS::negative.binomial(theta = 1)),
    stop("Unsupported component family: ", name, call. = FALSE))
}

sem_piecewise_component_specs <- function(formulas, options) {
  defaults <- list(engine = options$component_engine %||% "lm", family = options$family_name %||% "gaussian",
    random_intercept = options$random_intercept %||% "", reml = options$reml %||% FALSE)
  specs <- options$component_specs %||% list()
  stats::setNames(lapply(names(formulas), function(response) utils::modifyList(defaults, specs[[response]] %||% list())), names(formulas))
}

sem_fit_piecewise_component <- function(formula, specification, data) {
  environment(formula) <- environment()
  engine <- specification$engine %||% "lm"
  family_name <- specification$family %||% "gaussian"
  random_intercept <- specification$random_intercept %||% ""
  random_structure <- specification$random_structure %||% "block"
  random_slope <- specification$random_slope %||% character()
  slope_group <- specification$slope_group %||% ""
  factor_variables <- unique(c(unlist(strsplit(random_intercept, "/", fixed = TRUE)), slope_group,
    specification$zero_group %||% ""))
  factor_variables <- intersect(factor_variables[nzchar(factor_variables)], names(data))
  data[factor_variables] <- lapply(data[factor_variables], as.factor)
  if (engine %in% c("lmer", "glmer", "glmmTMB")) {
    if (identical(random_structure, "slope") && length(random_slope) && nzchar(slope_group))
      for (variable in random_slope) formula <- stats::update.formula(formula,
        paste(". ~ . + (1 +", variable, "|", slope_group, ")"))
    else if (nzchar(random_intercept)) formula <- stats::update.formula(formula, paste(". ~ . + (1 |", random_intercept, ")"))
  }
  if (engine == "lm") return(stats::lm(formula, data = data))
  if (engine == "glm") {
    fit <- stats::glm(formula, data = data, family = sem_piecewise_family(family_name))
    fit$call$family <- sem_piecewise_family_call(family_name)
    return(fit)
  }
  if (engine == "lmer") return(lme4::lmer(formula, data = data, REML = isTRUE(specification$reml)))
  if (engine == "glmer") {
    if (!nzchar(random_intercept)) stop("glmer requires a random intercept variable.", call. = FALSE)
    return(lme4::glmer(formula, data = data, family = sem_piecewise_family(family_name)))
  }
  if (engine == "glmmTMB") {
    if (!requireNamespace("glmmTMB", quietly = TRUE)) stop("Component engine glmmTMB requires package glmmTMB.", call. = FALSE)
    family <- if (family_name %in% c("negative_binomial", "nbinom2", "zi_nbinom2")) glmmTMB::nbinom2(link = "log") else sem_piecewise_family(family_name)
    zero_formula <- if (family_name == "zi_nbinom2") stats::as.formula(paste("~", specification$zero_group %||% "1")) else ~0
    return(glmmTMB::glmmTMB(formula, data = data, family = family, ziformula = zero_formula))
  }
  if (engine == "gam") {
    if (!requireNamespace("mgcv", quietly = TRUE)) stop("Component engine gam requires package mgcv.", call. = FALSE)
    return(mgcv::gam(formula, data = data, family = sem_piecewise_family(family_name), method = "REML"))
  }
  if (engine == "glmmPQL") {
    if (!requireNamespace("MASS", quietly = TRUE)) stop("glmmPQL requires package MASS.", call. = FALSE)
    if (!nzchar(random_intercept)) stop("glmmPQL requires a random intercept variable.", call. = FALSE)
    random_formula <- stats::as.formula(paste("~1 |", random_intercept))
    return(MASS::glmmPQL(fixed = formula, random = random_formula, data = data,
      family = sem_piecewise_family(family_name), verbose = FALSE))
  }
  stop("Unsupported piecewise component engine: ", engine, call. = FALSE)
}

sem_piecewise_effects_legacy <- function(coefficients, spec) {
  if (!is.data.frame(coefficients) || !nrow(coefficients)) return(list(direct = data.frame(), indirect = data.frame(), total = data.frame()))
  pick <- function(candidates) { value <- intersect(candidates, names(coefficients)); if (length(value)) value[[1]] else NA_character_ }
  response_col <- pick(c("Response", "response", "lhs")); predictor_col <- pick(c("Predictor", "predictor", "rhs")); estimate_col <- pick(c("Std.Estimate", "Estimate", "estimate", "est"))
  if (anyNA(c(response_col, predictor_col, estimate_col))) return(list(direct = coefficients, indirect = data.frame(), total = coefficients))
  direct <- data.frame(Response = as.character(coefficients[[response_col]]), Predictor = as.character(coefficients[[predictor_col]]),
    Effect = as.numeric(coefficients[[estimate_col]]), Path = paste(coefficients[[predictor_col]], "->", coefficients[[response_col]]),
    stringsAsFactors = FALSE)
  edges <- spec$edges[spec$edges$active & spec$edges$edge_type == "directed_path", , drop = FALSE]
  names_by_id <- stats::setNames(vapply(spec$nodes$id, sem_node_variable, character(1), spec = spec), spec$nodes$id)
  adjacency <- split(unname(names_by_id[edges$target]), unname(names_by_id[edges$source]))
  edge_effect <- function(source, target) {
    hit <- which(direct$Predictor == source & direct$Response == target)
    if (!length(hit)) return(NA_real_)
    direct$Effect[[hit[[1]]]]
  }
  indirect <- list()
  walk <- function(origin, current, product, path, visited) {
    next_nodes <- adjacency[[current]] %||% character()
    for (target in next_nodes) {
      if (target %in% visited) next()
      value <- edge_effect(current, target); if (!is.finite(value)) next()
      next_product <- product * value; next_path <- c(path, target)
      if (length(path) >= 2L) indirect[[length(indirect) + 1L]] <<- data.frame(Response = target,
        Predictor = origin, Effect = next_product, Path = paste(next_path, collapse = " -> "), stringsAsFactors = FALSE)
      walk(origin, target, next_product, next_path, c(visited, target))
    }
  }
  sources <- unique(unname(names_by_id[edges$source])); for (source in sources) walk(source, source, 1, source, source)
  indirect_table <- if (length(indirect)) do.call(rbind, indirect) else data.frame(Response = character(), Predictor = character(), Effect = numeric(), Path = character())
  total_pairs <- unique(rbind(direct[c("Response", "Predictor")], indirect_table[c("Response", "Predictor")]))
  total <- merge(total_pairs, aggregate(Effect ~ Response + Predictor, direct, sum), by = c("Response", "Predictor"), all.x = TRUE)
  names(total)[names(total) == "Effect"] <- "Direct"
  indirect_sum <- aggregate(Effect ~ Response + Predictor, indirect_table, sum)
  names(indirect_sum)[names(indirect_sum) == "Effect"] <- "Indirect"
  total <- merge(total, indirect_sum, by = c("Response", "Predictor"), all.x = TRUE); total$Direct[is.na(total$Direct)] <- 0; total$Indirect[is.na(total$Indirect)] <- 0
  total$Total <- total$Direct + total$Indirect
  list(direct = direct, indirect = indirect_table, total = total)
}

sem_fit_piecewise <- function(bundle, spec, options = list()) {
  dependency <- sem_method_dependency_status("piecewise_sem")
  if (!dependency$available) stop("Missing package: ", paste(dependency$missing, collapse = ", "), call. = FALSE)
  formulas <- sem_graph_to_piecewise(spec)
  if (!length(formulas)) stop("The prior model has no component formulas.", call. = FALSE)
  model_data <- bundle$data
  required <- unique(c(names(formulas), unlist(lapply(formulas, all.vars), use.names = FALSE)))
  if (any(!required %in% names(model_data)) && all(c("Temp", "Prec", "Dry", "SOC", "TN", "AP",
      "Bac", "Fun", "MBC", "Rich", "Shan", "Cover", "AGB", "BGB") %in% names(model_data))) {
    model_data <- cbind(model_data, sem_demo_composite_scores(model_data))
  }
  component_specs <- sem_piecewise_component_specs(formulas, options)
  models <- lapply(names(formulas), function(response) {
    formula <- formulas[[response]]
    environment(formula) <- environment()
    sem_fit_piecewise_component(formula, component_specs[[response]], model_data)
  })
  names(models) <- names(formulas)
  psem <- do.call("psem", unname(models), envir = asNamespace("piecewiseSEM"))
  summary_value <- summary(psem)
  coefficients <- as.data.frame(piecewiseSEM::coefs(psem))
  basis <- tryCatch(as.data.frame(piecewiseSEM::basisSet(psem)), error = function(e) data.frame(error = conditionMessage(e)))
  dsep <- tryCatch(as.data.frame(piecewiseSEM::dSep(psem)), error = function(e) data.frame(error = conditionMessage(e)))
  fisher <- tryCatch(as.data.frame(piecewiseSEM::fisherC(psem)), error = function(e) as.data.frame(summary_value$Cstat))
  r2 <- tryCatch(as.data.frame(piecewiseSEM::rsquared(psem)), error = function(e) data.frame(error = conditionMessage(e)))
  diagnostics <- Map(function(model, response) {
    value <- tryCatch(as.data.frame(broom::glance(model)), error = function(error) data.frame(error = conditionMessage(error)))
    value$response <- response; value
  }, models, names(models))
  diagnostic_columns <- unique(unlist(lapply(diagnostics, names), use.names = FALSE))
  diagnostics <- do.call(rbind, lapply(diagnostics, function(value) {
    for (column in setdiff(diagnostic_columns, names(value))) value[[column]] <- NA
    value[diagnostic_columns]
  }))
  effects <- sem_piecewise_effects(coefficients, spec)
  bootstrap_results <- data.frame()
  if (isTRUE(options$bootstrap)) {
    B <- max(100L, min(as.integer(options$bootstrap_samples %||% 500L), 5000L)); cluster <- options$bootstrap_cluster %||% ""
    draws <- vector("list", B); set.seed(as.integer(options$seed %||% 20260719L))
    for (b in seq_len(B)) {
      indices <- if (nzchar(cluster) && cluster %in% names(model_data)) {
        levels <- unique(model_data[[cluster]]); sampled <- sample(levels, length(levels), replace = TRUE); unlist(lapply(sampled, function(value) which(model_data[[cluster]] == value)))
      } else sample.int(nrow(model_data), nrow(model_data), replace = TRUE)
      draw_data <- model_data[indices, , drop = FALSE]
      draw_models <- tryCatch(lapply(names(formulas), function(response) sem_fit_piecewise_component(formulas[[response]], component_specs[[response]], draw_data)), error = function(e) NULL)
      if (!is.null(draw_models)) {
        draw_coef <- tryCatch(as.data.frame(piecewiseSEM::coefs(do.call("psem", unname(draw_models), envir = asNamespace("piecewiseSEM")))), error = function(e) NULL)
        if (!is.null(draw_coef)) {
          draw_effects <- sem_piecewise_effects(draw_coef, spec)$indirect
          if (nrow(draw_effects)) { draw_effects$replicate <- b; draws[[b]] <- draw_effects }
        }
      }
    }
    draws <- Filter(Negate(is.null), draws)
    if (length(draws)) {
      boot <- do.call(rbind, draws); split_boot <- split(boot$Effect, paste(boot$Response, boot$Predictor, boot$Path, sep = "\r"))
      bootstrap_results <- do.call(rbind, lapply(names(split_boot), function(key) {
        parts <- strsplit(key, "\r", fixed = TRUE)[[1]]; values <- split_boot[[key]]
        data.frame(Response = parts[[1]], Predictor = parts[[2]], Path = parts[[3]], Bootstrap_SE = stats::sd(values, na.rm = TRUE), CI_lower = stats::quantile(values, 0.025, na.rm = TRUE), CI_upper = stats::quantile(values, 0.975, na.rm = TRUE), Significant = stats::quantile(values, 0.025, na.rm = TRUE) * stats::quantile(values, 0.975, na.rm = TRUE) > 0, stringsAsFactors = FALSE)
      }))
    }
  }
  new_sem_result("piecewise_sem", prior_model_spec = spec, final_model_spec = spec,
    model_syntax = paste(vapply(formulas, deparse, character(1)), collapse = "\n"), fitted_model = psem,
    parameter_estimates = coefficients, structural_results = coefficients, basis_set = basis, d_sep = dsep, fisher_c = fisher,
    r_squared = r2, component_diagnostics = diagnostics, direct_effects = effects$direct,
    indirect_effects = effects$indirect, total_effects = effects$total, bootstrap_results = bootstrap_results,
    package_versions = data.frame(package = "piecewiseSEM", version = as.character(packageVersion("piecewiseSEM")), stringsAsFactors = FALSE),
    available_outputs = c("parameter_estimates", "basis_set", "d_sep", "fisher_c", "r_squared", "component_diagnostics", "direct_effects", "indirect_effects", "total_effects"),
    available_plots = "effect_plot")
}

sem_plspm_prepare_data <- function(data, design) {
  indicators <- unique(unlist(design$blocks, use.names = FALSE))
  missing <- setdiff(indicators, names(data))
  if (length(missing)) stop("Missing indicators: ", paste(missing, collapse = ", "), call. = FALSE)
  prepared <- data.frame(row.names = seq_len(nrow(data)))
  replacements <- stats::setNames(vector("list", length(indicators)), indicators)
  encoding_rows <- list()
  reserved_names <- names(data)

  for (variable in indicators) {
    value <- data[[variable]]
    if (is.numeric(value)) {
      prepared[[variable]] <- as.numeric(value)
      replacements[[variable]] <- variable
      next
    }
    if (!(is.factor(value) || is.character(value) || is.ordered(value))) {
      stop("PLS-PM indicator must be numeric or categorical: ", variable, call. = FALSE)
    }
    factor_value <- if (is.factor(value)) droplevels(value) else factor(value)
    levels_value <- levels(factor_value)
    if (length(levels_value) < 2L) {
      stop("Categorical PLS-PM indicator requires at least two levels: ", variable, call. = FALSE)
    }
    reference <- levels_value[[1]]
    dummy_names <- character()
    for (level in levels_value[-1L]) {
      base_name <- make.names(paste(variable, level, sep = "_"))
      dummy_name <- make.unique(c(reserved_names, names(prepared), dummy_names, base_name))
      dummy_name <- utils::tail(dummy_name, 1L)
      dummy_value <- as.numeric(factor_value == level)
      dummy_value[is.na(factor_value)] <- NA_real_
      prepared[[dummy_name]] <- dummy_value
      dummy_names <- c(dummy_names, dummy_name)
      encoding_rows[[length(encoding_rows) + 1L]] <- data.frame(
        variable = variable, reference_level = reference, level = level,
        dummy_variable = dummy_name, stringsAsFactors = FALSE)
    }
    replacements[[variable]] <- dummy_names
  }

  design$blocks <- lapply(design$blocks, function(block) {
    unname(unlist(replacements[block], use.names = FALSE))
  })
  encoding <- if (length(encoding_rows)) do.call(rbind, encoding_rows) else data.frame(
    variable = character(), reference_level = character(), level = character(),
    dummy_variable = character(), stringsAsFactors = FALSE)
  list(data = prepared, design = design, dummy_encoding = encoding)
}

sem_plspm_inner_vif <- function(scores, path_matrix) {
  rows <- list()
  for (target in rownames(path_matrix)) {
    predictors <- colnames(path_matrix)[path_matrix[target, ] != 0]
    if (!length(predictors)) next
    for (predictor in predictors) {
      others <- setdiff(predictors, predictor)
      vif <- 1
      if (length(others)) {
        model_data <- scores[, c(predictor, others), drop = FALSE]
        model_data <- model_data[stats::complete.cases(model_data), , drop = FALSE]
        if (nrow(model_data) > length(others) + 1L) {
          fit <- stats::lm(stats::reformulate(others, predictor), data = model_data)
          r_squared <- summary(fit)$r.squared
          vif <- if (is.finite(r_squared) && r_squared < 1) 1 / (1 - r_squared) else Inf
        } else vif <- NA_real_
      }
      rows[[length(rows) + 1L]] <- data.frame(target = target, predictor = predictor,
        vif = vif, below_3_3 = is.finite(vif) && vif < 3.3, stringsAsFactors = FALSE)
    }
  }
  if (length(rows)) do.call(rbind, rows) else data.frame(target = character(), predictor = character(),
    vif = numeric(), below_3_3 = logical(), stringsAsFactors = FALSE)
}

sem_fit_plspm <- function(bundle, spec, options = list()) {
  dependency <- sem_method_dependency_status("pls_pm")
  if (!dependency$available) stop("PLS-PM requires plspm; no PCA fallback is permitted.", call. = FALSE)
  design <- sem_graph_to_plspm(spec)
  variables <- unique(unlist(design$blocks, use.names = FALSE))
  missing <- setdiff(variables, names(bundle$data)); if (length(missing)) stop("Missing indicators: ", paste(missing, collapse = ", "), call. = FALSE)
  prepared <- sem_plspm_prepare_data(bundle$data, design)
  data <- prepared$data; design <- prepared$design
  data <- data[stats::complete.cases(data), , drop = FALSE]
  modes <- design$modes
  fit <- plspm::plspm(data, design$path_matrix, design$blocks, modes = modes,
    scheme = options$scheme %||% "path", scaled = options$scaled %||% TRUE,
    boot.val = isTRUE(options$bootstrap %||% TRUE), br = as.integer(options$bootstrap_samples %||% 500L),
    maxiter = as.integer(options$max_iterations %||% 100L), tol = as.numeric(options$tolerance %||% 1e-6))
  inner <- as.data.frame(as.table(fit$path_coefs), stringsAsFactors = FALSE)
  names(inner) <- c("target", "source", "estimate"); inner <- inner[inner$estimate != 0, , drop = FALSE]
  effects <- sem_plspm_effects(fit, design)
  gof_value <- suppressWarnings(as.numeric(fit$gof %||% NA_real_))
  gof <- data.frame(metric = "GoF", value = gof_value,
    assessment = if (is.finite(gof_value)) {
      if (gof_value > 0.36) "Big effect" else if (gof_value >= 0.25) "Moderate effect" else "Small effect"
    } else "Not available",
    fit_above_0_33 = is.finite(gof_value) && gof_value > 0.33, stringsAsFactors = FALSE)
  collinearity <- sem_plspm_inner_vif(as.data.frame(fit$scores), design$path_matrix)
  fit_measures <- if (!is.null(fit$inner_summary)) as.data.frame(fit$inner_summary) else data.frame()
  reliability <- if (!is.null(fit$unidim)) as.data.frame(fit$unidim) else data.frame()
  bootstrap_enabled <- isTRUE(options$bootstrap %||% TRUE)
  bootstrap_results <- if (bootstrap_enabled && !is.null(fit$boot$paths)) as.data.frame(fit$boot$paths) else data.frame()
  new_sem_result("pls_pm", prior_model_spec = spec, final_model_spec = spec,
    model_syntax = paste(capture.output(design$path_matrix), collapse = "\n"), fitted_model = fit,
    fit_measures = fit_measures, parameter_estimates = inner, structural_results = inner,
    outer_model = as.data.frame(fit$outer_model), inner_model = inner, construct_scores = as.data.frame(fit$scores),
    reliability = reliability, goodness_of_fit = gof, collinearity = collinearity,
    dummy_encoding = prepared$dummy_encoding,
    direct_effects = effects$direct, indirect_effects = effects$indirect, total_effects = effects$total,
    bootstrap_results = bootstrap_results,
    package_versions = data.frame(package = "plspm", version = as.character(packageVersion("plspm")), stringsAsFactors = FALSE),
    available_outputs = c("goodness_of_fit", "fit_measures", "inner_model", "outer_model", "reliability",
      "construct_scores", "direct_effects", "indirect_effects", "total_effects", "collinearity",
      "dummy_encoding", "bootstrap_results"),
    available_plots = "effect_plot")
}

sem_fit <- function(bundle, spec, options = list()) {
  data_check <- validate_sem_data_bundle(bundle); if (!data_check$valid) stop(paste(data_check$errors, collapse = "; "), call. = FALSE)
  model_check <- validate_sem_model_spec(spec); if (!model_check$valid) stop(paste(model_check$errors, collapse = "; "), call. = FALSE)
  started <- proc.time()[["elapsed"]]
  result <- switch(spec$method, covariance_sem = sem_fit_covariance(bundle, spec, options),
    piecewise_sem = sem_fit_piecewise(bundle, spec, options), pls_pm = sem_fit_plspm(bundle, spec, options),
    stop("Unsupported SEM method.", call. = FALSE))
  covariance_input <- identical(bundle$input_type %||% "raw_data", "covariance_matrix")
  result$data_adequacy <- data.frame(input_type = bundle$input_type %||% "raw_data",
    samples = if (covariance_input) bundle$sample_size else nrow(bundle$data),
    variables = if (covariance_input) ncol(bundle$covariance_matrix) else ncol(bundle$data),
    missing_cells = if (covariance_input) 0L else sum(is.na(bundle$data)),
    free_paths = sum(spec$edges$active), stringsAsFactors = FALSE)
  result$warnings <- unique(c(data_check$warnings, model_check$warnings, result$warnings))
  result$execution_metrics$elapsed_seconds <- proc.time()[["elapsed"]] - started
  result$generated_code <- sem_generate_code(bundle, spec, options)
  result
}
