sem_effect_empty <- function() {
  data.frame(Response = character(), Predictor = character(), Effect = numeric(), Std.Error = numeric(),
    CI.Lower = numeric(), CI.Upper = numeric(), P.Value = numeric(), Significant = logical(),
    Significance = character(), Path = character(), Group = character(), Inference = character(),
    Method = character(), stringsAsFactors = FALSE)
}

sem_effect_stars <- function(p_value) {
  ifelse(!is.finite(p_value), "", ifelse(p_value < 0.001, "***",
    ifelse(p_value < 0.01, "**", ifelse(p_value < 0.05, "*", "ns"))))
}

sem_effect_complete_inference <- function(effect, std_error = NA_real_, p_value = NA_real_,
    ci_lower = NA_real_, ci_upper = NA_real_) {
  effect <- as.numeric(effect); std_error <- as.numeric(std_error); p_value <- as.numeric(p_value)
  ci_lower <- as.numeric(ci_lower); ci_upper <- as.numeric(ci_upper)
  missing_se <- !is.finite(std_error) & is.finite(effect) & is.finite(p_value) & p_value > 0 & p_value < 1
  if (any(missing_se)) {
    critical <- stats::qnorm(p_value[missing_se] / 2, lower.tail = FALSE)
    std_error[missing_se] <- abs(effect[missing_se] / critical)
  }
  missing_p <- !is.finite(p_value) & is.finite(effect) & is.finite(std_error) & std_error > 0
  p_value[missing_p] <- 2 * stats::pnorm(abs(effect[missing_p] / std_error[missing_p]), lower.tail = FALSE)
  missing_lower <- !is.finite(ci_lower) & is.finite(effect) & is.finite(std_error)
  missing_upper <- !is.finite(ci_upper) & is.finite(effect) & is.finite(std_error)
  ci_lower[missing_lower] <- effect[missing_lower] - stats::qnorm(0.975) * std_error[missing_lower]
  ci_upper[missing_upper] <- effect[missing_upper] + stats::qnorm(0.975) * std_error[missing_upper]
  significant <- rep(NA, length(effect))
  significant[is.finite(p_value)] <- p_value[is.finite(p_value)] < 0.05
  ci_known <- !is.finite(p_value) & is.finite(ci_lower) & is.finite(ci_upper)
  significant[ci_known] <- ci_lower[ci_known] * ci_upper[ci_known] > 0
  list(std_error = std_error, p_value = p_value, ci_lower = ci_lower, ci_upper = ci_upper,
    significant = significant, stars = sem_effect_stars(p_value))
}

sem_effect_direct_table <- function(response, predictor, effect, std_error = NA_real_, p_value = NA_real_,
    ci_lower = NA_real_, ci_upper = NA_real_, group = "", method, inference) {
  n <- length(effect)
  recycle <- function(value) rep(value, length.out = n)
  completed <- sem_effect_complete_inference(effect, recycle(std_error), recycle(p_value), recycle(ci_lower), recycle(ci_upper))
  data.frame(Response = as.character(response), Predictor = as.character(predictor), Effect = as.numeric(effect),
    Std.Error = completed$std_error, CI.Lower = completed$ci_lower, CI.Upper = completed$ci_upper,
    P.Value = completed$p_value, Significant = completed$significant, Significance = completed$stars,
    Path = paste(as.character(predictor), "->", as.character(response)), Group = as.character(recycle(group)),
    Inference = recycle(inference), Method = recycle(method), stringsAsFactors = FALSE)
}

sem_effect_summarize_rows <- function(rows, effect_type, inference) {
  if (!nrow(rows)) return(sem_effect_empty())
  keys <- paste(rows$Group, rows$Predictor, rows$Response, sep = "\r")
  values <- lapply(split(seq_len(nrow(rows)), keys), function(index) {
    value <- rows[index, , drop = FALSE]
    effect <- sum(value$Effect, na.rm = TRUE)
    standard_errors <- value$Std.Error[is.finite(value$Std.Error)]
    std_error <- if (length(standard_errors) == nrow(value)) sqrt(sum(standard_errors^2)) else NA_real_
    completed <- sem_effect_complete_inference(effect, std_error)
    data.frame(Response = value$Response[[1]], Predictor = value$Predictor[[1]], Effect = effect,
      Std.Error = completed$std_error, CI.Lower = completed$ci_lower, CI.Upper = completed$ci_upper,
      P.Value = completed$p_value, Significant = completed$significant, Significance = completed$stars,
      Path = paste(unique(value$Path), collapse = " | "), Group = value$Group[[1]], Inference = inference,
      Method = value$Method[[1]], stringsAsFactors = FALSE)
  })
  result <- do.call(rbind, values)
  rownames(result) <- NULL
  result
}

sem_effects_from_direct <- function(direct, method, indirect_inference = "delta_product") {
  if (!is.data.frame(direct) || !nrow(direct))
    return(list(direct = sem_effect_empty(), indirect = sem_effect_empty(), total = sem_effect_empty()))
  direct$Group[is.na(direct$Group)] <- ""
  indirect_rows <- list()
  for (group_name in unique(direct$Group)) {
    group_direct <- direct[direct$Group == group_name, , drop = FALSE]
    walk <- function(origin, current, effect, variance, path, visited) {
      candidates <- which(group_direct$Predictor == current)
      for (index in candidates) {
        target <- group_direct$Response[[index]]
        if (target %in% visited) next
        edge_effect <- group_direct$Effect[[index]]
        if (!is.finite(edge_effect)) next
        edge_se <- group_direct$Std.Error[[index]]
        next_effect <- effect * edge_effect
        next_variance <- if (is.finite(edge_se)) variance * edge_effect^2 + effect^2 * edge_se^2 else NA_real_
        next_path <- c(path, target)
        if (length(next_path) >= 3L) {
          completed <- sem_effect_complete_inference(next_effect, if (is.finite(next_variance)) sqrt(next_variance) else NA_real_)
          indirect_rows[[length(indirect_rows) + 1L]] <<- data.frame(Response = target, Predictor = origin,
            Effect = next_effect, Std.Error = completed$std_error, CI.Lower = completed$ci_lower,
            CI.Upper = completed$ci_upper, P.Value = completed$p_value, Significant = completed$significant,
            Significance = completed$stars, Path = paste(next_path, collapse = " -> "), Group = group_name,
            Inference = indirect_inference, Method = method, stringsAsFactors = FALSE)
        }
        walk(origin, target, next_effect, next_variance, next_path, c(visited, target))
      }
    }
    for (origin in unique(group_direct$Predictor)) walk(origin, origin, 1, 0, origin, origin)
  }
  indirect_paths <- if (length(indirect_rows)) do.call(rbind, indirect_rows) else sem_effect_empty()
  indirect <- sem_effect_summarize_rows(indirect_paths, "indirect", indirect_inference)
  pair_keys <- unique(c(paste(direct$Group, direct$Predictor, direct$Response, sep = "\r"),
    paste(indirect$Group, indirect$Predictor, indirect$Response, sep = "\r")))
  total_rows <- lapply(pair_keys, function(key) {
    parts <- strsplit(key, "\r", fixed = TRUE)[[1]]
    direct_row <- direct[direct$Group == parts[[1]] & direct$Predictor == parts[[2]] & direct$Response == parts[[3]], , drop = FALSE]
    indirect_row <- indirect[indirect$Group == parts[[1]] & indirect$Predictor == parts[[2]] & indirect$Response == parts[[3]], , drop = FALSE]
    effect <- sum(c(direct_row$Effect, indirect_row$Effect), na.rm = TRUE)
    errors <- c(direct_row$Std.Error, indirect_row$Std.Error)
    std_error <- if (length(errors) && all(is.finite(errors))) sqrt(sum(errors^2)) else NA_real_
    completed <- sem_effect_complete_inference(effect, std_error)
    data.frame(Response = parts[[3]], Predictor = parts[[2]], Effect = effect, Std.Error = completed$std_error,
      CI.Lower = completed$ci_lower, CI.Upper = completed$ci_upper, P.Value = completed$p_value,
      Significant = completed$significant, Significance = completed$stars,
      Path = paste(parts[[2]], "->", parts[[3]]), Group = parts[[1]], Inference = "direct_plus_indirect",
      Method = method, stringsAsFactors = FALSE)
  })
  total <- if (length(total_rows)) do.call(rbind, total_rows) else sem_effect_empty()
  rownames(total) <- NULL
  list(direct = direct, indirect = indirect, total = total, indirect_paths = indirect_paths)
}

sem_cbsem_effects <- function(fit, parameters = data.frame()) {
  standardized <- tryCatch(as.data.frame(lavaan::standardizedSolution(fit, ci = TRUE)), error = function(error) data.frame())
  paths <- standardized[standardized$op == "~", , drop = FALSE]
  if (nrow(paths)) {
    direct <- sem_effect_direct_table(paths$lhs, paths$rhs, paths$est.std, paths$se, paths$pvalue,
      paths$ci.lower, paths$ci.upper, group = paths$group %||% "", method = "Lavaan CB-SEM",
      inference = "lavaan standardized solution")
  } else {
    paths <- parameters[parameters$op == "~", , drop = FALSE]
    direct <- sem_effect_direct_table(paths$lhs, paths$rhs, paths$std.all, p_value = paths$pvalue,
      group = paths$group %||% "", method = "Lavaan CB-SEM", inference = "lavaan parameter estimates")
  }
  sem_effects_from_direct(direct, "Lavaan CB-SEM", "delta method for standardized path products")
}

sem_piecewise_effects <- function(coefficients, spec = NULL) {
  if (!is.data.frame(coefficients) || !nrow(coefficients))
    return(list(direct = sem_effect_empty(), indirect = sem_effect_empty(), total = sem_effect_empty()))
  pick <- function(candidates) { value <- intersect(candidates, names(coefficients)); if (length(value)) value[[1]] else NA_character_ }
  response <- pick(c("Response", "response", "lhs")); predictor <- pick(c("Predictor", "predictor", "rhs"))
  estimate <- pick(c("Std.Estimate", "Estimate", "estimate", "est")); p_value <- pick(c("P.Value", "p.value", "pvalue"))
  statistic <- pick(c("Crit.Value", "statistic", "z.value", "t.value"))
  if (anyNA(c(response, predictor, estimate)))
    return(list(direct = sem_effect_empty(), indirect = sem_effect_empty(), total = sem_effect_empty()))
  effect <- as.numeric(coefficients[[estimate]])
  test_value <- if (!is.na(statistic)) as.numeric(coefficients[[statistic]]) else rep(NA_real_, length(effect))
  std_error <- ifelse(is.finite(test_value) & test_value != 0, abs(effect / test_value), NA_real_)
  direct <- sem_effect_direct_table(coefficients[[response]], coefficients[[predictor]], effect, std_error,
    if (!is.na(p_value)) coefficients[[p_value]] else NA_real_, method = "piecewiseSEM",
    inference = "component-model coefficient test")
  sem_effects_from_direct(direct, "piecewiseSEM", "delta method across component paths")
}

sem_plspm_effects <- function(fit, design) {
  path_matrix <- fit$path_coefs
  positions <- which(path_matrix != 0, arr.ind = TRUE)
  if (!nrow(positions)) return(list(direct = sem_effect_empty(), indirect = sem_effect_empty(), total = sem_effect_empty()))
  scores <- as.data.frame(fit$scores)
  direct_rows <- lapply(unique(rownames(path_matrix)[positions[, "row"]]), function(response) {
    predictors <- colnames(path_matrix)[path_matrix[response, ] != 0]
    formula <- stats::reformulate(predictors, response)
    score_fit <- stats::lm(formula, data = scores)
    summary_table <- summary(score_fit)$coefficients
    intervals <- suppressMessages(stats::confint(score_fit))
    lapply(predictors, function(predictor) sem_effect_direct_table(response, predictor,
      path_matrix[response, predictor], summary_table[predictor, "Std. Error"], summary_table[predictor, "Pr(>|t|)"],
      intervals[predictor, 1], intervals[predictor, 2], method = "plspm PLS-SEM",
      inference = "construct-score regression test"))
  })
  direct <- do.call(rbind, unlist(direct_rows, recursive = FALSE))
  bootstrap_paths <- tryCatch(as.data.frame(fit$boot$paths), error = function(error) data.frame())
  if (nrow(bootstrap_paths) && !is.null(rownames(bootstrap_paths))) {
    relation <- paste(direct$Predictor, "->", direct$Response)
    index <- match(relation, rownames(bootstrap_paths))
    matched <- !is.na(index)
    bootstrap_column <- function(candidates) {
      column <- intersect(candidates, names(bootstrap_paths))
      if (length(column)) column[[1]] else NA_character_
    }
    se_column <- bootstrap_column(c("Std.Error", "Std. Error"))
    lower_column <- bootstrap_column(c("perc.025", "CI.Lower", "CI.lower"))
    upper_column <- bootstrap_column(c("perc.975", "CI.Upper", "CI.upper"))
    if (!is.na(se_column)) direct$Std.Error[matched] <- bootstrap_paths[[se_column]][index[matched]]
    if (!is.na(lower_column)) direct$CI.Lower[matched] <- bootstrap_paths[[lower_column]][index[matched]]
    if (!is.na(upper_column)) direct$CI.Upper[matched] <- bootstrap_paths[[upper_column]][index[matched]]
    completed <- sem_effect_complete_inference(direct$Effect, direct$Std.Error,
      p_value = rep(NA_real_, nrow(direct)), ci_lower = direct$CI.Lower, ci_upper = direct$CI.Upper)
    direct$P.Value[matched] <- completed$p_value[matched]
    direct$Significant[matched] <- direct$CI.Lower[matched] * direct$CI.Upper[matched] > 0
    direct$Significance[matched] <- completed$stars[matched]
    direct$Inference[matched] <- "plspm bootstrap percentile interval"
  }
  effects <- sem_effects_from_direct(direct, "plspm PLS-SEM", "delta method across PLS path products")
  package_effects <- as.data.frame(fit$effects, stringsAsFactors = FALSE)
  if (nrow(package_effects) && all(c("relationships", "direct", "indirect", "total") %in% names(package_effects))) {
    relationship <- strsplit(as.character(package_effects$relationships), " -> ", fixed = TRUE)
    predictor <- vapply(relationship, `[[`, character(1), 1L)
    response <- vapply(relationship, `[[`, character(1), 2L)
    overwrite <- function(table, column) {
      if (!nrow(table)) return(table)
      index <- match(paste(table$Predictor, table$Response), paste(predictor, response))
      matched <- !is.na(index)
      table$Effect[matched] <- package_effects[[column]][index[matched]]
      table
    }
    effects$direct <- overwrite(effects$direct, "direct")
    effects$indirect <- overwrite(effects$indirect, "indirect")
    effects$total <- overwrite(effects$total, "total")
  }
  effects
}
