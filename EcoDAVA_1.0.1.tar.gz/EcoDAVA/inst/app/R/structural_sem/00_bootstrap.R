sem_framework_version <- function() "0.1.0"

sem_configured_root <- getOption(
  "dava.project_root", Sys.getenv("DAVA_PROJECT_ROOT", unset = ""))
sem_root_candidates <- unique(c(
  sem_configured_root,
  ".", "..", file.path("..", ".."), file.path("..", "..", "..")))
sem_root_candidates <- sem_root_candidates[
  !is.na(sem_root_candidates) & nzchar(sem_root_candidates)]
sem_root_candidates <- sem_root_candidates[file.exists(file.path(sem_root_candidates, "app.R"))]
if (!length(sem_root_candidates)) stop("Cannot locate the DAVA project root.", call. = FALSE)
sem_project_root <- normalizePath(sem_root_candidates[[1]], winslash = "/", mustWork = TRUE)

sem_source_utf8 <- function(path) {
  bytes <- readBin(path, what = "raw", n = file.info(path)[["size"]])
  code <- rawToChar(bytes)
  Encoding(code) <- "UTF-8"
  code <- gsub("\r\n?", "\n", sub("^\ufeff", "", code))
  eval(parse(text = code, encoding = "UTF-8", keep.source = FALSE), envir = .GlobalEnv)
}

sem_support_files <- c(
  dava_local_demo_read = "R/demo_data/local_demo_datasets.R",
  dava_code_document = "R/module_support/code_document.R",
  dava_module_code_panel_ui = "R/module_support/module_code_support.R"
)
for (sem_support_name in names(sem_support_files)) {
  if (!exists(sem_support_name, mode = "function", inherits = TRUE)) {
    sem_source_utf8(file.path(sem_project_root, sem_support_files[[sem_support_name]]))
  }
}

sem_framework_files <- c(
  file.path("core", "method_registry.R"),
  file.path("core", "dependency_registry.R"),
  file.path("core", "contracts.R"),
  file.path("core", "validation.R"),
  file.path("domain", "demo_data_templates.R"),
  file.path("domain", "model_translation.R"),
  file.path("engines", "sem_effects.R"),
  file.path("engines", "sem_method_adapters.R"),
  file.path("application", "data_screening.R"),
  file.path("application", "cbsem_sidebar.R"),
  file.path("application", "model_optimization.R"),
  file.path("application", "results_reporting.R"),
  file.path("application", "shiny_module.R"),
  file.path("quality", "self_check.R")
)
for (sem_file in sem_framework_files) {
  sem_source_utf8(file.path(sem_project_root, "R", "structural_sem", sem_file))
}
rm(sem_file, sem_root_candidates, sem_configured_root,
  sem_support_name, sem_support_files)
