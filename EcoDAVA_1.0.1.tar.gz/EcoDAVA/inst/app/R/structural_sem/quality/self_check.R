sem_framework_self_check <- function() {
  registry_ok <- identical(sort(SEM_METHOD_REGISTRY$id), sort(c("covariance_sem", "piecewise_sem", "pls_pm")))
  aliases_ok <- identical(unname(vapply(c("sem", "piecewise_sem", "plspm"), sem_method_from_alias, character(1))),
    c("covariance_sem", "piecewise_sem", "pls_pm"))
  spec <- sem_demo_prior_spec()
  list(valid = registry_ok && aliases_ok && validate_sem_model_spec(spec)$valid,
    registry = registry_ok, aliases = aliases_ok, model_spec = validate_sem_model_spec(spec))
}
