dava_package_available <- function(package) {
  package <- trimws(as.character(package %||% ""))
  package %in% c("", "base", "stats", "utils", "graphics", "grDevices",
    "methods", "parallel", "MASS") ||
    requireNamespace(package, quietly = TRUE)
}

dava_package_list <- function(value) {
  packages <- trimws(unlist(strsplit(
    as.character(value %||% ""), ",", fixed = TRUE), use.names = FALSE))
  unique(packages[nzchar(packages)])
}

dava_method_compatibility_status <- function() {
  rows <- list()
  add_rows <- function(module, id, label, packages,
      supported = "windows,macos,linux", external = "") {
    at <- function(value, index) {
      if (length(value) == 1L) value[[1]] else value[[index]]
    }
    for (index in seq_along(id)) {
      required <- dava_package_list(at(packages, index))
      missing <- required[!vapply(
        required, dava_package_available, logical(1))]
      platforms <- dava_package_list(at(supported, index))
      current_supported <- dava_platform() %in% platforms
      external_requirement <- at(external, index)
      if (is.na(external_requirement)) external_requirement <- ""
      external_ready <- !nzchar(external_requirement) ||
        nzchar(Sys.which(external_requirement))
      rows[[length(rows) + 1L]] <<- data.frame(
        module = module, method_id = id[[index]], method = label[[index]],
        supported_platforms = paste(platforms, collapse = ","),
        current_platform_supported = current_supported,
        required_packages = paste(required, collapse = ","),
        missing_packages = paste(missing, collapse = ","),
        external_requirement = external_requirement,
        ready = current_supported && !length(missing) && external_ready,
        stringsAsFactors = FALSE)
    }
  }

  if (exists("regression_model_registry", mode = "function")) {
    registry <- regression_model_registry()
    registry <- registry[
      registry$implemented %in% TRUE & registry$ui_exposed %in% TRUE,
      , drop = FALSE]
    add_rows("regression", registry$id, registry$label, registry$package)
  }
  if (exists("MICROBIOME_METHOD_REGISTRY", inherits = TRUE)) {
    registry <- MICROBIOME_METHOD_REGISTRY
    registry <- registry[
      registry$status == "implemented" & registry$visibility %in% TRUE,
      , drop = FALSE]
    external <- ifelse(registry$id == "tax4fun2", "blastn", "")
    add_rows(
      "microbiome", registry$id, registry$label_cn,
      registry$required_packages,
      registry$supported_operating_systems, external)
  }
  if (exists("sem_method_registry", mode = "function")) {
    registry <- sem_method_registry()
    add_rows(
      "structural_sem", registry$id, registry$label_cn,
      registry$required_packages)
  }
  if (exists("vi_method_registry", mode = "function")) {
    registry <- vi_method_registry()
    add_rows(
      "variable_importance", registry$id, registry$label,
      registry$required_packages)
  }
  if (!length(rows)) return(data.frame())
  result <- do.call(rbind, rows)
  rownames(result) <- NULL
  result
}

dava_external_tool_status <- function() {
  tools <- c(
    blastn = "Tax4Fun2",
    pdftocairo = "PDF import",
    pdf2svg = "PDF import",
    inkscape = "PDF/SVG import and export",
    magick = "TIFF export",
    python3 = "CairoSVG fallback",
    python = "CairoSVG fallback")
  paths <- Sys.which(names(tools))
  data.frame(
    tool = names(tools), purpose = unname(tools),
    available = nzchar(paths), path = unname(paths),
    required = names(tools) == "blastn",
    stringsAsFactors = FALSE)
}

dava_cross_platform_audit <- function() {
  list(
    runtime = dava_platform_status(),
    methods = dava_method_compatibility_status(),
    external_tools = dava_external_tool_status())
}
