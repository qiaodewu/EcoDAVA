/* Bridge running inside the SVG-Edit iframe.
 * It exposes a narrow DAVA message protocol while leaving SVG-Edit's own UI,
 * layers, selection, and undo stack under SVG-Edit control.
 */
(function () {
  "use strict";

  var ready = false;
  var lastError = "";
  var shuttingDown = false;
  var toolbarToggleRetryCount = 0;
  var appHeaderCollapsed = false;
  var strokeStyleVisibilityBound = false;
  var strokeStyleBeforeNone = typeof WeakMap === "function" ? new WeakMap() : null;
  var defaultStrokeToolBindingBound = false;
  var symbolToolsBound = false;
  var symbolModulesLoading = false;
  var symbolModulesReady = false;
  var symbolTextInputSnapshot = null;
  var equationToolsBound = false;
  var equationModulesLoading = false;
  var equationModulesReady = false;
  var pdfImportModulesLoading = false;
  var pdfImportModulesReady = false;
  var exportModulesLoading = false;
  var exportModulesReady = false;
  var exportToolBound = false;
  var interfaceLanguage = "zh-CN";
  var svgInterfaceLanguage = "zh-CN";
  var svgInterfaceTexts = {
    "zh-CN": { saving: "保存中...", saved: "已保存", save: "保存", saveNameTitle: "保存到 SVG Gallery", saveNamePrompt: "请输入保存名称。", confirm: "确认", cancel: "取消", exitTitle: "保存并退出 SVG-Edit？", savingCurrent: "正在保存当前 SVG 编辑内容...", unsaved: "当前 SVG 编辑内容尚未保存。", savedCanExit: "当前 SVG 编辑内容已保存，可以退出。", exit: "退出", continueEditing: "继续编辑" },
    en: { saving: "Saving...", saved: "Saved", save: "Save", saveNameTitle: "Save to SVG Gallery", saveNamePrompt: "Enter a name to save.", confirm: "Confirm", cancel: "Cancel", exitTitle: "Save and exit SVG-Edit?", savingCurrent: "Saving the current SVG editing content...", unsaved: "The current SVG editing content has not been saved.", savedCanExit: "The current SVG editing content is saved and can be exited.", exit: "Exit", continueEditing: "Continue editing" },
    "zh-TW": { saving: "儲存中...", saved: "已儲存", save: "儲存", saveNameTitle: "儲存到 SVG Gallery", saveNamePrompt: "請輸入儲存名稱。", confirm: "確認", cancel: "取消", exitTitle: "儲存並退出 SVG-Edit？", savingCurrent: "正在儲存目前 SVG 編輯內容...", unsaved: "目前 SVG 編輯內容尚未儲存。", savedCanExit: "目前 SVG 編輯內容已儲存，可以退出。", exit: "退出", continueEditing: "繼續編輯" },
    ja: { saving: "保存中...", saved: "保存済み", save: "保存", saveNameTitle: "SVG Gallery に保存", saveNamePrompt: "保存名を入力してください。", confirm: "確認", cancel: "キャンセル", exitTitle: "SVG-Edit を保存して終了しますか？", savingCurrent: "現在の SVG 編集内容を保存しています...", unsaved: "現在の SVG 編集内容は保存されていません。", savedCanExit: "現在の SVG 編集内容は保存されています。終了できます。", exit: "終了", continueEditing: "編集を続ける" },
    es: { saving: "Guardando...", saved: "Guardado", save: "Guardar", saveNameTitle: "Guardar en SVG Gallery", saveNamePrompt: "Introduzca un nombre para guardar.", confirm: "Confirmar", cancel: "Cancelar", exitTitle: "¿Guardar y salir de SVG-Edit?", savingCurrent: "Guardando el contenido SVG actual...", unsaved: "El contenido SVG actual no se ha guardado.", savedCanExit: "El contenido SVG actual está guardado y puede salir.", exit: "Salir", continueEditing: "Continuar editando" }
  };
  function svgText(key) {
    var language = svgInterfaceTexts[svgInterfaceLanguage] ? svgInterfaceLanguage : "en";
    return svgInterfaceTexts[language][key] || svgInterfaceTexts.en[key] || key;
  }
  function setSvgInterfaceLanguage(language) {
    svgInterfaceLanguage = svgInterfaceTexts[language] ? language : "en";
    updateSaveNameDialog();
    updateExitDialog();
  }
  var simpleDocumentModulesLoading = false;
  var simpleDocumentModulesReady = false;
  var saveState = {
    dirty: false,
    pending: false,
    requestId: "",
    dirtyRevision: 0,
    pendingRevision: 0,
    dirtyBound: false,
    ignoreNativeChange: false,
    saveTimer: null,
    defaultGalleryName: "SVGEdit"
  };
  var illustratorShortcutsBound = false;

  function allowedOrigin() {
    try {
      return window.parent && window.parent.location ? window.parent.location.origin : window.location.origin;
    } catch (error) {
      // Local file/dev fallback only; Shiny serves SVG-Edit same-origin in normal use.
      return "*";
    }
  }

  function post(type, payload) {
    if (shuttingDown) return;
    payload = payload || {};
    payload.type = type;
    payload.source = "DAVA_SVGEDIT_BRIDGE";
    window.parent.postMessage(payload, allowedOrigin());
  }

  function currentDocumentId() {
    try {
      return window.frameElement && (window.frameElement.getAttribute("data-artboard-id") || window.frameElement.getAttribute("data-document-id")) || "";
    } catch (error) {
      return "";
    }
  }

  function hostAction(action, payload) {
    payload = payload || {};
    payload.action = action;
    post("DAVA_HOST_ACTION", payload);
  }

  function isEditableShortcutTarget(target) {
    if (!target || !target.tagName) return false;
    var tag = target.tagName.toLowerCase();
    return tag === "input" || tag === "textarea" || tag === "select" || target.isContentEditable;
  }

  function symbolModuleUrls() {
    return [
      "/js/svg-editor/symbols/unicodeUtils.js",
      "/js/svg-editor/symbols/symbolCategories.js",
      "/js/svg-editor/symbols/symbolRegistry.js",
      "/js/svg-editor/symbols/symbolRecentStore.js",
      "/js/svg-editor/symbols/symbolInsertCommand.js",
      "/js/svg-editor/symbols/symbolPanel.js"
    ];
  }

  function equationModuleUrls() {
    return [
      "/js/svg-editor/equations/equationSanitizer.js",
      "/js/svg-editor/equations/equationTemplates.js",
      "/js/svg-editor/equations/equationRegistry.js",
      "/js/svg-editor/equations/equationRecentStore.js",
      "/js/svg-editor/equations/equationMathLiveAdapter.js",
      "/js/svg-editor/equations/equationRendererMathJax.js",
      "/js/svg-editor/equations/equationObjectModel.js",
      "/js/svg-editor/equations/equationInsertCommand.js",
      "/js/svg-editor/equations/equationEditCommand.js",
      "/js/svg-editor/equations/equationExport.js",
      "/js/svg-editor/equations/equationPanel.js",
      "/js/svg-editor/equations/equationTool.js"
    ];
  }

  function pdfImportModuleUrls() {
    return [
      "/js/svg-editor/pdf/pdfImportShinyBridge.js",
      "/js/svg-editor/pdf/pdfSvgSanitizer.js",
      "/js/svg-editor/pdf/pdfSvgImporter.js",
      "/js/svg-editor/pdf/pdfImportClient.js",
      "/js/svg-editor/pdf/pdfImportPanel.js",
      "/js/svg-editor/pdf/pdfImportTool.js"
    ];
  }

  function simpleDocumentModuleUrls() {
    return [
      "/js/svg-editor/documents/simpleDocumentShinyBridge.js",
      "/js/svg-editor/documents/simpleDocumentTabs.js",
      "/js/svg-editor/documents/simpleDocumentClipboard.js",
      "/js/svg-editor/documents/simpleDocumentStore.js"
    ];
  }

  function exportModuleUrls() {
    return [
      "/js/svg-editor/export/exportFormatRegistry.js",
      "/js/svg-editor/export/exportClient.js",
      "/js/svg-editor/export/exportPanel.js",
      "/js/svg-editor/export/exportShinyBridge.js"
    ];
  }

  function loadScriptOnce(src, callback) {
    var existing = document.querySelector("script[data-dava-symbol-src='" + src + "']");
    if (existing && existing.getAttribute("data-loaded") === "1") {
      callback();
      return;
    }
    if (existing) {
      existing.addEventListener("load", callback, { once: true });
      return;
    }
    var script = document.createElement("script");
    script.src = src;
    script.async = false;
    script.setAttribute("data-dava-symbol-src", src);
    script.onload = function () {
      script.setAttribute("data-loaded", "1");
      callback();
    };
    script.onerror = function () {
      console.warn("[DAVA SVG-Edit bridge] Could not load symbol module:", src);
      callback();
    };
    document.head.appendChild(script);
  }

  function loadSymbolModules(callback) {
    if (symbolModulesReady) {
      callback();
      return;
    }
    if (symbolModulesLoading) {
      window.setTimeout(function () { loadSymbolModules(callback); }, 100);
      return;
    }
    symbolModulesLoading = true;
    var urls = symbolModuleUrls();
    var index = 0;
    var next = function () {
      if (index >= urls.length) {
        symbolModulesReady = !!(window.DavaSymbolPanel && window.DavaSymbolInsertCommand);
        symbolModulesLoading = false;
        callback();
        return;
      }
      loadScriptOnce(urls[index], function () {
        index += 1;
        next();
      });
    };
    next();
  }

  function loadEquationModules(callback) {
    if (equationModulesReady) {
      callback();
      return;
    }
    if (equationModulesLoading) {
      window.setTimeout(function () { loadEquationModules(callback); }, 100);
      return;
    }
    equationModulesLoading = true;
    var urls = equationModuleUrls();
    var index = 0;
    var next = function () {
      if (index >= urls.length) {
        equationModulesReady = !!(window.DavaEquationPanel && window.DavaEquationInsertCommand);
        equationModulesLoading = false;
        callback();
        return;
      }
      loadScriptOnce(urls[index], function () {
        index += 1;
        next();
      });
    };
    next();
  }

  function loadCssOnce(href) {
    if (document.querySelector("link[data-dava-css-src='" + href + "']")) return;
    var link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = href;
    link.setAttribute("data-dava-css-src", href);
    document.head.appendChild(link);
  }

  function loadPdfImportModules(callback) {
    loadCssOnce("/css/svg-editor-pdf-import.css");
    if (pdfImportModulesReady) {
      callback();
      return;
    }
    if (pdfImportModulesLoading) {
      window.setTimeout(function () { loadPdfImportModules(callback); }, 100);
      return;
    }
    pdfImportModulesLoading = true;
    var urls = pdfImportModuleUrls();
    var index = 0;
    var next = function () {
      if (index >= urls.length) {
        pdfImportModulesReady = !!(window.DavaPdfImportTool && window.DavaPdfSvgImporter);
        pdfImportModulesLoading = false;
        callback();
        return;
      }
      loadScriptOnce(urls[index], function () {
        index += 1;
        next();
      });
    };
    next();
  }

  function loadSimpleDocumentModules(callback) {
    loadCssOnce("/css/svg-editor-document-tabs.css");
    if (simpleDocumentModulesReady) {
      callback();
      return;
    }
    if (simpleDocumentModulesLoading) {
      window.setTimeout(function () { loadSimpleDocumentModules(callback); }, 100);
      return;
    }
    simpleDocumentModulesLoading = true;
    var urls = simpleDocumentModuleUrls();
    var index = 0;
    var next = function () {
      if (index >= urls.length) {
        simpleDocumentModulesReady = !!(window.DavaSimpleDocumentStore && window.DavaSimpleDocumentTabs);
        simpleDocumentModulesLoading = false;
        callback();
        return;
      }
      loadScriptOnce(urls[index], function () {
        index += 1;
        next();
      });
    };
    next();
  }

  function loadExportModules(callback) {
    loadCssOnce("/css/svg-editor-export-panel.css");
    if (exportModulesReady) {
      callback();
      return;
    }
    if (exportModulesLoading) {
      window.setTimeout(function () { loadExportModules(callback); }, 100);
      return;
    }
    exportModulesLoading = true;
    var urls = exportModuleUrls();
    var index = 0;
    var next = function () {
      if (index >= urls.length) {
        exportModulesReady = !!(window.DavaExportClient && window.DavaExportPanel);
        exportModulesLoading = false;
        callback();
        return;
      }
      loadScriptOnce(urls[index], function () {
        index += 1;
        next();
      });
    };
    next();
  }

  function normalizedShortcutKey(event) {
    var parts = [];
    if (event.ctrlKey || event.metaKey) parts.push("mod");
    if (event.shiftKey) parts.push("shift");
    if (event.altKey) parts.push("alt");

    var key = (event.key || "").toLowerCase();
    if (key === " ") key = "space";
    if (key === "esc") key = "escape";
    // Browser/keyboard layouts report the plus and minus keys differently
    // ("+", "=", NumpadAdd, NumpadSubtract).  Normalize the numpad forms so
    // Ctrl/Cmd +/- behaves consistently on Windows and macOS.
    var code = String(event.code || "").toLowerCase();
    if (code === "numpadadd") key = "+";
    if (code === "numpadsubtract") key = "-";
    if ((event.code || "").toLowerCase() === "backslash") key = "\\";
    parts.push(key);
    return parts.join("+");
  }

  function clickSvgEditButton(id) {
    var button = document.getElementById(id);
    if (!button || button.disabled || button.classList.contains("disabled")) return false;
    button.click();
    return true;
  }

  function currentSvgEditor() {
    return window.svgEditor || null;
  }

  function withSvgEditor(callback) {
    var editor = currentSvgEditor();
    var canvas = getSvgCanvas();
    if (!editor || !canvas) return false;
    return callback(editor, canvas) === false ? false : true;
  }

  function isMacPlatform() {
    return /Mac|iPhone|iPad|iPod/.test(String(navigator.platform || navigator.userAgent || ""));
  }

  function displayShortcut(shortcut) {
    return String(shortcut || "").replace(/\bMod\b/g, isMacPlatform() ? "Cmd" : "Ctrl");
  }

  function refreshShortcutElement(element) {
    if (!element) return;
    ["label", "title"].forEach(function (attribute) {
      var value = element.getAttribute(attribute);
      if (value === null) return;
      element.setAttribute(attribute, value + " ");
      element.setAttribute(attribute, value);
    });
  }

  function setShortcutHint(id, shortcut) {
    var element = document.getElementById(id);
    if (!element) return;
    if (shortcut) {
      element.setAttribute("shortcut", displayShortcut(shortcut));
    } else {
      element.removeAttribute("shortcut");
    }
    refreshShortcutElement(element);
  }

  function setAnchorShortcut(root, id, shortcut) {
    if (!root) return;
    var anchor = root.getElementById ? root.getElementById(id) : root.querySelector("#" + id);
    if (!anchor) return;
    var span = anchor.querySelector(".shortcut");
    if (!span) {
      span = document.createElement("span");
      span.className = "shortcut";
      anchor.appendChild(span);
    }
    span.textContent = displayShortcut(shortcut);
  }

  function updateLegacyShortcutText(root) {
    if (!root || !root.querySelectorAll) return;
    Array.prototype.forEach.call(root.querySelectorAll(".shortcut"), function (span) {
      var text = String(span.textContent || "").trim();
      if (!text) return;
      text = text
        .replace(/^META\+/i, displayShortcut("Mod+"))
        .replace(/^CTRL\+SHFT\+/i, displayShortcut("Mod+Shift+"))
        .replace(/^CTRL\+SHIFT\+/i, displayShortcut("Mod+Shift+"))
        .replace(/^CTRL\+/i, displayShortcut("Mod+"))
        .replace(/^BACKSPACE$/i, "Delete/Backspace");
      span.textContent = text;
    });
  }

  function updateIllustratorContextMenuLabels() {
    var menu = document.getElementById("se-cmenu_canvas");
    var root = menu && menu.shadowRoot ? menu.shadowRoot : null;
    if (root) {
      setAnchorShortcut(root, "se-cut", "Mod+X");
      setAnchorShortcut(root, "se-copy", "Mod+C");
      setAnchorShortcut(root, "se-paste", "Mod+V");
      setAnchorShortcut(root, "se-paste-in-place", "Mod+Shift+V");
      setAnchorShortcut(root, "se-delete", "Delete/Backspace");
      setAnchorShortcut(root, "se-group", "Mod+G");
      setAnchorShortcut(root, "se-ungroup", "Mod+Shift+G");
      setAnchorShortcut(root, "se-move-front", "Mod+Shift+]");
      setAnchorShortcut(root, "se-move-up", "Mod+]");
      setAnchorShortcut(root, "se-move-down", "Mod+[");
      setAnchorShortcut(root, "se-move-back", "Mod+Shift+[");
      updateLegacyShortcutText(root);
    }
    updateLegacyShortcutText(document);
    Array.prototype.forEach.call(document.querySelectorAll("*"), function (element) {
      if (element.shadowRoot && element !== menu) updateLegacyShortcutText(element.shadowRoot);
    });
  }

  function updateIllustratorShortcutHints() {
    var hints = {
      tool_select: "V",
      tool_zoom: "Z",
      tool_fhpath: "N",
      tool_line: "\\",
      tool_path: "P",
      tool_rect: "M",
      tool_ellipse: "L",
      tool_text: "T",
      tool_undo: "Mod+Z",
      tool_redo: "Mod+Shift+Z",
      tool_clone: "Mod+D",
      tool_clone_multi: "Mod+D",
      tool_delete: "Delete/Backspace",
      tool_delete_multi: "Delete/Backspace",
      tool_group_elements: "Mod+G",
      tool_ungroup: "Mod+Shift+G",
      tool_move_top: "Mod+Shift+]",
      tool_move_bottom: "Mod+Shift+[",
      tool_save: "Mod+S",
      tool_wireframe: "Mod+Y",
      tool_bold: "Mod+B",
      tool_italic: "Mod+I"
    };
    Object.keys(hints).forEach(function (id) {
      setShortcutHint(id, hints[id]);
    });
    [
      "tool_source",
      "tool_clear",
      "tool_square",
      "tool_circle",
      "tool_docprops",
      "tool_editor_prefs",
      "tool_editor_homepage"
    ].forEach(function (id) {
      setShortcutHint(id, "");
    });
    updateIllustratorContextMenuLabels();
  }

  function selectedSvgEditElements(canvas) {
    if (!canvas || typeof canvas.getSelectedElements !== "function") return [];
    return canvas.getSelectedElements().filter(Boolean);
  }

  function hasSvgSelection(editor, canvas) {
    return !!(editor && (editor.selectedElement || editor.multiselected)) || selectedSvgEditElements(canvas).length > 0;
  }

  function deleteSvgSelection(editor, canvas) {
    if (!hasSvgSelection(editor, canvas) || typeof canvas.deleteSelectedElements !== "function") return false;
    canvas.deleteSelectedElements();
    return true;
  }

  function nudgeSvgSelection(editor, canvas, dx, dy) {
    if (!hasSvgSelection(editor, canvas)) return false;
    if (typeof editor.moveSelected === "function") {
      editor.moveSelected(dx, dy);
      return true;
    }
    if (typeof canvas.moveSelectedElements === "function") {
      canvas.moveSelectedElements(dx, dy);
      return true;
    }
    return false;
  }

  function activateDirectSelectionLikeTool(editor, canvas) {
    var selected = selectedSvgEditElements(canvas)[0];
    if (selected && (selected.tagName || "").toLowerCase() === "path" && canvas.pathActions) {
      try {
        if (typeof canvas.pathActions.select === "function") {
          canvas.pathActions.select(selected);
          return;
        }
        if (typeof canvas.pathActions.toEditMode === "function") {
          canvas.pathActions.toEditMode(selected);
          return;
        }
      } catch (error) {
        console.warn("[DAVA SVG-Edit shortcuts] Direct selection fallback failed.", error);
      }
    }
    if (editor.leftPanel && typeof editor.leftPanel.clickSelect === "function") {
      editor.leftPanel.clickSelect();
    } else {
      canvas.setMode("select");
    }
  }

  function installIllustratorShortcuts() {
    if (illustratorShortcutsBound) {
      updateIllustratorShortcutHints();
      return;
    }
    illustratorShortcutsBound = true;
    updateIllustratorShortcutHints();

    var blockedLegacySingleKeys = {
      b: true,
      c: true,
      d: true,
      e: true,
      f: true,
      g: true,
      i: true,
      q: true,
      r: true,
      s: true,
      u: true
    };

    var actions = {
      v: function () {
        return withSvgEditor(function (editor, canvas) {
          editor.leftPanel && editor.leftPanel.clickSelect ? editor.leftPanel.clickSelect() : canvas.setMode("select");
        });
      },
      a: function () {
        return withSvgEditor(activateDirectSelectionLikeTool);
      },
      p: function () {
        return withSvgEditor(function (editor, canvas) {
          editor.leftPanel && editor.leftPanel.clickPath ? editor.leftPanel.clickPath() : canvas.setMode("path");
        });
      },
      n: function () {
        return withSvgEditor(function (editor, canvas) {
          editor.leftPanel && editor.leftPanel.clickFHPath ? editor.leftPanel.clickFHPath() : canvas.setMode("fhpath");
        });
      },
      "\\": function () {
        return withSvgEditor(function (editor, canvas) {
          editor.leftPanel && editor.leftPanel.clickLine ? editor.leftPanel.clickLine() : canvas.setMode("line");
        });
      },
      m: function () {
        return withSvgEditor(function (editor, canvas) {
          editor.leftPanel && editor.leftPanel.clickRect ? editor.leftPanel.clickRect() : canvas.setMode("rect");
        });
      },
      l: function () {
        return withSvgEditor(function (editor, canvas) {
          editor.leftPanel && editor.leftPanel.clickEllipse ? editor.leftPanel.clickEllipse() : canvas.setMode("ellipse");
        });
      },
      t: function () {
        return withSvgEditor(function (editor, canvas) {
          editor.leftPanel && editor.leftPanel.clickText ? editor.leftPanel.clickText() : canvas.setMode("text");
        });
      },
      z: function () {
        return withSvgEditor(function (editor, canvas) {
          editor.leftPanel && editor.leftPanel.clickZoom ? editor.leftPanel.clickZoom() : canvas.setMode("zoom");
        });
      },
      h: function () {
        return withSvgEditor(function (editor, canvas) {
          canvas.setMode("ext-panning");
          if (editor.workarea) editor.workarea.style.cursor = "grab";
        });
      },
      escape: function () {
        return withSvgEditor(function (editor, canvas) {
          if (editor.enableToolCancel && typeof editor.cancelTool === "function") {
            editor.cancelTool();
          } else {
            canvas.setMode("select");
          }
        });
      },
      delete: function () {
        return withSvgEditor(deleteSvgSelection);
      },
      backspace: function () {
        return withSvgEditor(deleteSvgSelection);
      },
      arrowup: function () {
        return withSvgEditor(function (editor, canvas) {
          return nudgeSvgSelection(editor, canvas, 0, -1);
        });
      },
      arrowdown: function () {
        return withSvgEditor(function (editor, canvas) {
          return nudgeSvgSelection(editor, canvas, 0, 1);
        });
      },
      arrowleft: function () {
        return withSvgEditor(function (editor, canvas) {
          return nudgeSvgSelection(editor, canvas, -1, 0);
        });
      },
      arrowright: function () {
        return withSvgEditor(function (editor, canvas) {
          return nudgeSvgSelection(editor, canvas, 1, 0);
        });
      },
      "shift+arrowup": function () {
        return withSvgEditor(function (editor, canvas) {
          return nudgeSvgSelection(editor, canvas, 0, -10);
        });
      },
      "shift+arrowdown": function () {
        return withSvgEditor(function (editor, canvas) {
          return nudgeSvgSelection(editor, canvas, 0, 10);
        });
      },
      "shift+arrowleft": function () {
        return withSvgEditor(function (editor, canvas) {
          return nudgeSvgSelection(editor, canvas, -10, 0);
        });
      },
      "shift+arrowright": function () {
        return withSvgEditor(function (editor, canvas) {
          return nudgeSvgSelection(editor, canvas, 10, 0);
        });
      },
      "mod+z": function () {
        return withSvgEditor(function (editor) {
          editor.topPanel && editor.topPanel.clickUndo ? editor.topPanel.clickUndo() : clickSvgEditButton("tool_undo");
        });
      },
      "mod+shift+z": function () {
        return withSvgEditor(function (editor) {
          editor.topPanel && editor.topPanel.clickRedo ? editor.topPanel.clickRedo() : clickSvgEditButton("tool_redo");
        });
      },
      "mod+x": function () {
        return withSvgEditor(function (editor) {
          editor.cutSelected();
        });
      },
      "mod+c": function () {
        return withSvgEditor(function (editor) {
          editor.copySelected();
        });
      },
      "mod+v": function () {
        return withSvgEditor(function (editor) {
          editor.pasteInCenter();
        });
      },
      "mod+a": function () {
        return withSvgEditor(function (editor, canvas) {
          canvas.selectAllInCurrentLayer();
        });
      },
      "mod+s": function () {
        requestSave("shortcut");
        return true;
      },
      "mod+d": function () {
        return withSvgEditor(function (editor, canvas) {
          if (editor.selectedElement || editor.multiselected) canvas.cloneSelectedElements(20, 20);
        });
      },
      "mod+g": function () {
        return withSvgEditor(function (editor, canvas) {
          canvas.groupSelectedElements();
        });
      },
      "mod+shift+g": function () {
        return withSvgEditor(function (editor, canvas) {
          canvas.ungroupSelectedElement();
        });
      },
      "mod+]": function () {
        return withSvgEditor(function (editor) {
          editor.moveUpDownSelected("Up");
        });
      },
      "mod+[": function () {
        return withSvgEditor(function (editor) {
          editor.moveUpDownSelected("Down");
        });
      },
      "mod+shift+]": function () {
        return withSvgEditor(function (editor, canvas) {
          if (editor.selectedElement) canvas.moveToTopSelectedElement();
        });
      },
      "mod+shift+[": function () {
        return withSvgEditor(function (editor, canvas) {
          if (editor.selectedElement) canvas.moveToBottomSelectedElement();
        });
      },
      "mod+y": function () {
        return clickSvgEditButton("tool_wireframe");
      },
      "mod+b": function () {
        return clickSvgEditButton("tool_bold");
      },
      "mod+i": function () {
        return clickSvgEditButton("tool_italic");
      },
      "mod+=": function () {
        return withSvgEditor(function (editor) {
          editor.zoomImage(2);
        });
      },
      "mod++": function () {
        return withSvgEditor(function (editor) {
          editor.zoomImage(2);
        });
      },
      "mod+shift+=": function () {
        return withSvgEditor(function (editor) {
          editor.zoomImage(2);
        });
      },
      "mod+shift++": function () {
        return withSvgEditor(function (editor) {
          editor.zoomImage(2);
        });
      },
      "mod+numpadadd": function () {
        return withSvgEditor(function (editor) {
          editor.zoomImage(2);
        });
      },
      "mod+-": function () {
        return withSvgEditor(function (editor) {
          editor.zoomImage(0.5);
        });
      },
      "mod+shift+-": function () {
        return withSvgEditor(function (editor) {
          editor.zoomImage(0.5);
        });
      },
      "mod+numpadsubtract": function () {
        return withSvgEditor(function (editor) {
          editor.zoomImage(0.5);
        });
      },
      "mod+0": function () {
        return withSvgEditor(function (editor) {
          editor.zoomImage();
        });
      },
      "alt+=": function () {
        openEquationPanel();
        return true;
      },
      "alt++": function () {
        openEquationPanel();
        return true;
      },
      "alt+shift+s": function () {
        openSymbolPanel();
        return true;
      }
    };

    document.addEventListener("keydown", function (event) {
      if (document.body && (document.body.classList.contains("dava-symbol-panel-open") || document.body.classList.contains("dava-equation-panel-open"))) return;
      if (shuttingDown || isEditableShortcutTarget(event.target)) return;
      var key = normalizedShortcutKey(event);
      var action = actions[key];
      // Some Chromium/Windows combinations expose Ctrl/Cmd + '+' as
      // mod+'=' (without the shift modifier), while numpad keys expose a
      // dedicated code.  Resolve these aliases before handing the event to
      // SVG-Edit's native keyboard dispatcher.
      if (!action && (event.ctrlKey || event.metaKey) && !event.altKey) {
        var code = String(event.code || "").toLowerCase();
        if (key === "mod+=" || key === "mod+shift+=" || key === "mod++" || code === "numpadadd" || code === "equal") {
          action = actions["mod+="];
        } else if (key === "mod+-" || key === "mod+shift+-" || code === "numpadsubtract" || code === "minus") {
          action = actions["mod+-"];
        }
      }
      if (!action && !event.ctrlKey && !event.metaKey && !event.altKey && !event.shiftKey && blockedLegacySingleKeys[key]) {
        action = function () { return true; };
      }
      if (!action) return;
      if (action(event) !== false) {
        event.preventDefault();
        event.stopImmediatePropagation();
        event.stopPropagation();
      }
    }, true);

    document.addEventListener("wheel", function (event) {
      if (shuttingDown || isEditableShortcutTarget(event.target) || !(event.ctrlKey || event.metaKey)) return;
      var editor = currentSvgEditor();
      var workarea = editor && editor.workarea ? editor.workarea : document.getElementById("workarea");
      if (!workarea) return;
      var dominantDelta = Math.abs(event.deltaX) > Math.abs(event.deltaY) ? event.deltaX : event.deltaY;
      var speed = event.shiftKey ? 3 : 1.8;
      workarea.scrollLeft += dominantDelta * speed;
      event.preventDefault();
      event.stopImmediatePropagation();
      event.stopPropagation();
    }, { capture: true, passive: false });

    document.addEventListener("contextmenu", function () {
      window.setTimeout(updateIllustratorContextMenuLabels, 0);
      window.setTimeout(updateIllustratorContextMenuLabels, 120);
    }, true);
  }

  var svgEditDialogText = {
    "保存并退出 SVG-Edit？": { en: "Save and exit SVG-Edit?", "zh-CN": "保存并退出 SVG-Edit？", "zh-TW": "儲存並退出 SVG-Edit？", ja: "SVG-Edit を保存して終了しますか？", es: "¿Guardar y salir de SVG-Edit?" },
    "保存": { en: "Save", "zh-CN": "保存", "zh-TW": "儲存", ja: "保存", es: "Guardar" },
    "退出": { en: "Exit", "zh-CN": "退出", "zh-TW": "退出", ja: "終了", es: "Salir" },
    "继续编辑": { en: "Continue editing", "zh-CN": "继续编辑", "zh-TW": "繼續編輯", ja: "編集を続ける", es: "Continuar editando" },
    "保存中...": { en: "Saving...", "zh-CN": "保存中...", "zh-TW": "儲存中...", ja: "保存中...", es: "Guardando..." },
    "已保存": { en: "Saved", "zh-CN": "已保存", "zh-TW": "已儲存", ja: "保存済み", es: "Guardado" },
    "正在保存当前 SVG 编辑内容...": { en: "Saving the current SVG edits...", "zh-CN": "正在保存当前 SVG 编辑内容...", "zh-TW": "正在儲存目前 SVG 編輯內容...", ja: "現在の SVG 編集内容を保存しています...", es: "Guardando las ediciones SVG actuales..." },
    "当前 SVG 编辑内容尚未保存。": { en: "The current SVG edits have not been saved.", "zh-CN": "当前 SVG 编辑内容尚未保存。", "zh-TW": "目前 SVG 編輯內容尚未儲存。", ja: "現在の SVG 編集内容はまだ保存されていません。", es: "Las ediciones SVG actuales aún no se han guardado." },
    "当前 SVG 编辑内容已保存，可以退出。": { en: "The current SVG edits are saved and you can exit.", "zh-CN": "当前 SVG 编辑内容已保存，可以退出。", "zh-TW": "目前 SVG 編輯內容已儲存，可以退出。", ja: "現在の SVG 編集内容は保存済みです。終了できます。", es: "Las ediciones SVG actuales están guardadas y puede salir." },
    "保存到 SVG Gallery": { en: "Save to SVG Gallery", "zh-CN": "保存到 SVG Gallery", "zh-TW": "儲存到 SVG Gallery", ja: "SVG Gallery に保存", es: "Guardar en SVG Gallery" },
    "请输入保存名称。": { en: "Enter a name to save.", "zh-CN": "请输入保存名称。", "zh-TW": "請輸入儲存名稱。", ja: "保存名を入力してください。", es: "Introduzca un nombre para guardar." },
    "确认": { en: "Confirm", "zh-CN": "确认", "zh-TW": "確認", ja: "確認", es: "Confirmar" },
    "取消": { en: "Cancel", "zh-CN": "取消", "zh-TW": "取消", ja: "キャンセル", es: "Cancelar" }
  };
  function svgEditText(value) {
    var entry = svgEditDialogText[value];
    return entry ? (entry[interfaceLanguage] || entry.en || value) : value;
  }
  function setSvgEditLanguage(language) {
    interfaceLanguage = svgEditDialogText["保存"] && { en: 1, "zh-CN": 1, "zh-TW": 1, ja: 1, es: 1 }[language] ? language : "en";
    updateExitDialog();
    var dialog = document.getElementById("dava_svgedit_exit_dialog");
    if (dialog) {
      var title = dialog.querySelector("h2");
      var save = dialog.querySelector("[data-dava-exit-dialog='save']");
      var exit = dialog.querySelector("[data-dava-exit-dialog='exit']");
      var cancel = dialog.querySelector("[data-dava-exit-dialog='cancel']");
      if (title) title.textContent = svgEditText("保存并退出 SVG-Edit？");
      if (save) save.textContent = svgEditText("保存");
      if (exit) exit.textContent = svgEditText("退出");
      if (cancel) cancel.textContent = svgEditText("继续编辑");
    }
    var saveDialog = document.getElementById("dava_svgedit_save_name_dialog");
    if (saveDialog) {
      var saveTitle = saveDialog.querySelector("h2");
      var saveConfirm = saveDialog.querySelector("[data-dava-save-name='confirm']");
      var saveCancel = saveDialog.querySelector("[data-dava-save-name='cancel']");
      if (saveTitle) saveTitle.textContent = svgEditText("保存到 SVG Gallery");
      if (saveConfirm) saveConfirm.textContent = svgEditText("确认");
      if (saveCancel) saveCancel.textContent = svgEditText("取消");
    }
  }
  function updateExitDialog() {
    var dialog = document.getElementById("dava_svgedit_exit_dialog");
    if (!dialog) return;
    var saveButton = dialog.querySelector("[data-dava-exit-dialog='save']");
    var status = dialog.querySelector("[data-dava-exit-dialog='status']");
    if (saveButton) {
      saveButton.disabled = !saveState.dirty || saveState.pending;
      saveButton.textContent = saveState.pending ?
        svgEditText("保存中...") :
        (saveState.dirty ? svgEditText("保存") : svgEditText("已保存"));
    }
    if (status) {
      status.textContent = saveState.pending ?
        svgEditText("正在保存当前 SVG 编辑内容...") :
        (saveState.dirty ?
          svgEditText("当前 SVG 编辑内容尚未保存。") :
          svgEditText("当前 SVG 编辑内容已保存，可以退出。"));
    }
  }

  function markDirty(reason) {
    if (shuttingDown || saveState.ignoreNativeChange) return;
    if (saveState.saveTimer) window.clearTimeout(saveState.saveTimer);
    saveState.saveTimer = null;
    saveState.dirty = true;
    saveState.pending = false;
    saveState.dirtyRevision += 1;
    saveState.lastReason = reason || "changed";
    updateExitDialog();
    if (window.DavaSimpleDocumentStore && window.DavaSimpleDocumentStore.markDirty) {
      window.DavaSimpleDocumentStore.markDirty(null, true);
    }
  }

  function markSaved() {
    if (saveState.saveTimer) window.clearTimeout(saveState.saveTimer);
    saveState.saveTimer = null;
    saveState.dirty = false;
    saveState.pending = false;
    saveState.requestId = "";
    saveState.pendingRevision = saveState.dirtyRevision;
    updateExitDialog();
    if (window.DavaSimpleDocumentStore && window.DavaSimpleDocumentStore.getActiveDocument && window.DavaSimpleDocumentStore.handleSavedToGallery) {
      var doc = window.DavaSimpleDocumentStore.getActiveDocument();
      if (doc) window.DavaSimpleDocumentStore.handleSavedToGallery({ documentId: doc.id, saved: true });
    }
  }

  function markLoadedClean() {
    if (saveState.saveTimer) window.clearTimeout(saveState.saveTimer);
    saveState.saveTimer = null;
    saveState.dirty = false;
    saveState.pending = false;
    saveState.requestId = "";
    saveState.pendingRevision = saveState.dirtyRevision;
    updateExitDialog();
  }

  function requestSave(source) {
    showSaveNameDialog(source || "toolbar");
  }

  function commitSave(source, galleryName) {
    if (saveState.pending) return;
    saveState.requestId = "dava-save-" + Date.now() + "-" + Math.floor(Math.random() * 100000);
    saveState.pending = true;
    saveState.pendingRevision = saveState.dirtyRevision;
    updateExitDialog();
    hostAction("save", {
      requestId: saveState.requestId,
      source: source || "toolbar",
      galleryName: galleryName || saveState.defaultGalleryName || "SVGEdit"
    });
    if (saveState.saveTimer) window.clearTimeout(saveState.saveTimer);
    saveState.saveTimer = window.setTimeout(function (requestId) {
      if (saveState.pending && saveState.requestId === requestId) {
        saveState.pending = false;
        updateExitDialog();
      }
    }, 15000, saveState.requestId);
  }

  function ensureSaveNameDialog() {
    var dialog = document.getElementById("dava_svgedit_save_name_dialog");
    if (dialog) return dialog;
    dialog = document.createElement("div");
    dialog.id = "dava_svgedit_save_name_dialog";
    dialog.className = "dava-svgedit-exit-dialog";
    dialog.hidden = true;
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.innerHTML = [
      "<div class=\"dava-svgedit-exit-backdrop\"></div>",
      "<div class=\"dava-svgedit-exit-panel\">",
      "<h2>保存到 SVG Gallery</h2>",
      "<p>请输入保存名称。</p>",
      "<input type=\"text\" data-dava-save-name=\"input\" aria-label=\"SVG Gallery name\">",
      "<div class=\"dava-svgedit-exit-actions\">",
      "<button type=\"button\" class=\"ok\" data-dava-save-name=\"confirm\">确认</button>",
      "<button type=\"button\" data-dava-save-name=\"cancel\">取消</button>",
      "</div>",
      "</div>"
    ].join("");
    document.body.appendChild(dialog);
    setSvgEditLanguage(interfaceLanguage);
    dialog.addEventListener("click", function (event) {
      var action = event.target && event.target.getAttribute("data-dava-save-name");
      if (action === "confirm") {
        var input = dialog.querySelector("[data-dava-save-name='input']");
        var value = input ? input.value.trim() : "";
        if (!value) {
          if (input && typeof input.focus === "function") input.focus();
          return;
        }
        dialog.hidden = true;
        commitSave(dialog.dataset.saveSource || "toolbar", value);
      } else if (action === "cancel") {
        dialog.hidden = true;
      }
    });
    dialog.addEventListener("keydown", function (event) {
      if (event.key === "Enter") {
        var confirm = dialog.querySelector("[data-dava-save-name='confirm']");
        if (confirm) confirm.click();
      } else if (event.key === "Escape") {
        dialog.hidden = true;
      }
    });
    return dialog;
  }

  function showSaveNameDialog(source) {
    var dialog = ensureSaveNameDialog();
    var input = dialog.querySelector("[data-dava-save-name='input']");
    dialog.dataset.saveSource = source || "toolbar";
    if (input) input.value = saveState.defaultGalleryName || "SVGEdit";
    dialog.hidden = false;
    if (input && typeof input.focus === "function") {
      input.focus();
      input.select();
    }
  }

  function completeSave(message) {
    message = message || {};
    if (saveState.requestId && message.hostRequestId && message.hostRequestId !== saveState.requestId) return;
    if (saveState.dirtyRevision <= saveState.pendingRevision || !saveState.dirty) {
      markSaved();
      return;
    }
    saveState.pending = false;
    updateExitDialog();
  }

  function exitWithoutSaving() {
    hideExitDialog();
    hostAction("exit", { force: true });
  }

  function handleExitRequest() {
    if (!saveState.dirty && !saveState.pending) {
      exitWithoutSaving();
      return;
    }
    showExitDialog();
  }

  function hideExitDialog() {
    var dialog = document.getElementById("dava_svgedit_exit_dialog");
    if (dialog) dialog.hidden = true;
  }

  function showExitDialog() {
    var dialog = ensureExitDialog();
    dialog.hidden = false;
    updateExitDialog();
    var exitButton = dialog.querySelector("[data-dava-exit-dialog='exit']");
    if (exitButton && typeof exitButton.focus === "function") exitButton.focus();
  }

  function ensureExitDialog() {
    var dialog = document.getElementById("dava_svgedit_exit_dialog");
    if (dialog) return dialog;
    dialog = document.createElement("div");
    dialog.id = "dava_svgedit_exit_dialog";
    dialog.className = "dava-svgedit-exit-dialog";
    dialog.hidden = true;
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.innerHTML = [
      "<div class=\"dava-svgedit-exit-backdrop\"></div>",
      "<div class=\"dava-svgedit-exit-panel\">",
      "<h2>保存并退出 SVG-Edit？</h2>",
      "<p data-dava-exit-dialog=\"status\"></p>",
      "<div class=\"dava-svgedit-exit-actions\">",
      "<button type=\"button\" class=\"ok\" data-dava-exit-dialog=\"save\">保存</button>",
      "<button type=\"button\" class=\"danger\" data-dava-exit-dialog=\"exit\">退出</button>",
      "<button type=\"button\" data-dava-exit-dialog=\"cancel\">继续编辑</button>",
      "</div>",
      "</div>"
    ].join("");
    document.body.appendChild(dialog);
    setSvgEditLanguage(interfaceLanguage);
    dialog.addEventListener("click", function (event) {
      var action = event.target && event.target.getAttribute("data-dava-exit-dialog");
      if (action === "save") {
        requestSave("exit-dialog");
      } else if (action === "exit") {
        exitWithoutSaving();
      } else if (action === "cancel") {
        hideExitDialog();
      }
    });
    return dialog;
  }

  function ensureDavaMenu() {
    if (!document.getElementById("dava_svgedit_dava_dialog_styles")) {
      var dialogStyle = document.createElement("style");
      dialogStyle.id = "dava_svgedit_dava_dialog_styles";
      dialogStyle.textContent = [
        ".svg_editor.dava-svg-menubar-rebuilt #dava_svgedit_toolbar_toggle{grid-area:main;align-self:start;justify-self:start;z-index:20;display:inline-flex;align-items:center;gap:5px;height:28px;margin:2px 0 0 4px;border:1px solid rgba(255,255,255,.32);background:#5d6669;color:#fff;border-radius:2px;padding:0 7px;font:12px Arial,sans-serif;cursor:pointer;vertical-align:top}",
        ".svg_editor.dava-svg-menubar-rebuilt #main_button{margin-left:74px!important}",
        ".svg_editor.dava-svg-menubar-rebuilt #tools_top{padding-left:74px;box-sizing:border-box}",
        "#dava_svgedit_toolbar_toggle:hover{background:#6d777a}",
        "#dava_svgedit_toolbar_toggle .fold-icon{position:relative;width:12px;height:12px;border-top:2px solid #fff;border-bottom:2px solid #fff;box-sizing:border-box}",
        "#dava_svgedit_toolbar_toggle .fold-icon:before{content:'';position:absolute;left:0;right:0;top:4px;border-top:2px solid #fff}",
        "#dava_svgedit_toolbar_toggle .fold-caret{width:0;height:0;border-left:4px solid transparent;border-right:4px solid transparent;border-top:5px solid #fff}",
        "#dava_svgedit_toolbar_toggle.is-collapsed .fold-caret{border-top:0;border-bottom:5px solid #fff}",
        "#dava_svgedit_app_header_toggle{position:fixed;right:9px;top:8px;z-index:1000004;display:inline-flex;align-items:center;justify-content:center;width:32px;height:24px;border:1px solid rgba(255,255,255,.38);background:#5d6669;color:#fff;border-radius:2px;padding:0;cursor:pointer;pointer-events:auto!important}",
        "#dava_svgedit_app_header_toggle:hover{background:#6d777a}",
        "#dava_svgedit_app_header_toggle svg{width:18px;height:18px;stroke:#f5f7f8;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}",
        "#dava_svgedit_app_header_toggle.is-collapsed svg .collapse-mark{display:none}",
        "#dava_svgedit_app_header_toggle:not(.is-collapsed) svg .expand-mark{display:none}",
        ".dava-svgedit-exit-dialog[hidden]{display:none!important}",
        ".dava-svgedit-exit-dialog{position:fixed;inset:0;z-index:1000000;display:flex;align-items:center;justify-content:center;font:14px Arial,sans-serif;color:#17212b}",
        ".dava-svgedit-exit-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.48)}",
        ".dava-svgedit-exit-panel{position:relative;width:min(420px,calc(100vw - 32px));background:#fff;border:1px solid #d6dde5;box-shadow:0 18px 45px rgba(15,23,42,.28);padding:18px}",
        ".dava-svgedit-exit-panel h2{margin:0 0 8px;font:700 18px/1.35 Arial,sans-serif;color:#17212b}",
        ".dava-svgedit-exit-panel p{margin:0 0 16px;color:#516173;line-height:1.5}",
        ".dava-svgedit-exit-actions{display:flex;justify-content:flex-end;gap:8px}",
        ".dava-svgedit-exit-actions button{height:30px;border:1px solid #aeb8c3;background:#f8fafc;color:#17212b;border-radius:3px;padding:0 12px;cursor:pointer}",
        ".dava-svgedit-exit-actions button.ok{border-color:#0f766e;color:#0f766e}",
        ".dava-svgedit-exit-actions button.danger{border-color:#b91c1c;color:#b91c1c}",
        ".dava-svgedit-exit-actions button:disabled{opacity:.45;cursor:not-allowed}",
        ".dava-svgedit-exit-panel input{width:100%;height:32px;margin:0 0 16px;border:1px solid #aeb8c3;border-radius:3px;padding:0 9px;font:14px Arial,sans-serif;color:#17212b}"
      ].join("\n");
      document.head.appendChild(dialogStyle);
    }
    ensureToolbarToggle();
    ensureAppHeaderToggle();
    return;

    var existing = document.getElementById("dava_svgedit_menu");
    var anchor = document.querySelector("#main_button") ||
      document.querySelector("se-menu") ||
      document.querySelector("#tools_top") ||
      document.body.firstElementChild;
    if (existing) {
      if (anchor && anchor.parentNode && existing.previousElementSibling !== anchor) {
        anchor.parentNode.insertBefore(existing, anchor.nextSibling);
      }
      return;
    }
    var style = document.createElement("style");
    style.textContent = [
      "#dava_svgedit_menu{display:inline-flex;align-items:center;gap:4px;height:28px;margin-left:6px;vertical-align:top;font:12px/1.2 Arial,sans-serif;color:#fff;position:relative;z-index:5}",
      "#dava_svgedit_menu button,#dava_svgedit_menu select{height:26px;border:1px solid rgba(255,255,255,.28);background:#5d6669;color:#fff;border-radius:2px;padding:0 7px;font:12px Arial,sans-serif}",
      "#dava_svgedit_menu button{cursor:pointer}",
      "#dava_svgedit_menu button:hover,#dava_svgedit_menu select:hover{background:#6d777a}",
      "#dava_svgedit_menu select{max-width:260px;min-width:180px}",
      "#dava_svgedit_menu option{background:#fff;color:#17212b}",
      "#dava_svgedit_menu .tool{color:#eaf2ff;border-color:rgba(150,190,255,.55)}",
      "#dava_svgedit_menu .danger{color:#ffd3d3;border-color:rgba(255,120,120,.55)}",
      "#dava_svgedit_menu .ok{color:#d7fff6;border-color:rgba(75,220,185,.6)}",
      "#dava_svgedit_menu .status{max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#e6eef2;margin-left:4px}",
      ".dava-svgedit-exit-dialog[hidden]{display:none!important}",
      ".dava-svgedit-exit-dialog{position:fixed;inset:0;z-index:1000000;display:flex;align-items:center;justify-content:center;font:14px Arial,sans-serif;color:#17212b}",
      ".dava-svgedit-exit-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.48)}",
      ".dava-svgedit-exit-panel{position:relative;width:min(420px,calc(100vw - 32px));background:#fff;border:1px solid #d6dde5;box-shadow:0 18px 45px rgba(15,23,42,.28);padding:18px}",
      ".dava-svgedit-exit-panel h2{margin:0 0 8px;font:700 18px/1.35 Arial,sans-serif;color:#17212b}",
      ".dava-svgedit-exit-panel p{margin:0 0 16px;color:#516173;line-height:1.5}",
      ".dava-svgedit-exit-actions{display:flex;justify-content:flex-end;gap:8px}",
      ".dava-svgedit-exit-actions button{height:30px;border:1px solid #aeb8c3;background:#f8fafc;color:#17212b;border-radius:3px;padding:0 12px;cursor:pointer}",
      ".dava-svgedit-exit-actions button.ok{border-color:#0f766e;color:#0f766e}",
      ".dava-svgedit-exit-actions button.danger{border-color:#b91c1c;color:#b91c1c}",
      ".dava-svgedit-exit-actions button:disabled{opacity:.45;cursor:not-allowed}",
      ".dava-svgedit-exit-panel input{width:100%;height:32px;margin:0 0 16px;border:1px solid #aeb8c3;border-radius:3px;padding:0 9px;font:14px Arial,sans-serif;color:#17212b}"
    ].join("\n");
    document.head.appendChild(style);

    var menu = document.createElement("span");
    menu.id = "dava_svgedit_menu";
    menu.innerHTML = [
      "<button type=\"button\" data-dava-action=\"insert-r-plot\" title=\"Insert current R plot\">+ R Plot</button>",
      "<button type=\"button\" data-dava-action=\"create-area-text\" class=\"tool\" title=\"Create DAVA area text\">Area Text</button>",
      "<button type=\"button\" data-dava-action=\"convert-area-text\" class=\"tool\" title=\"Convert selected text to DAVA area text\">To Area</button>",
      "<button type=\"button\" data-dava-action=\"import-file\" title=\"Import SVG file\">Import</button>",
      "<button type=\"button\" data-dava-action=\"pdf-import\" class=\"tool\" title=\"PDF Import\">PDF Import</button>",
      "<select id=\"dava_svgedit_source_select\" title=\"Plot source\"></select>",
      "<button type=\"button\" data-dava-action=\"save\" class=\"ok\" title=\"Save edited SVG\">Save</button>",
      "<button type=\"button\" data-dava-action=\"download\" title=\"Download SVG\">Download</button>",
      "<button type=\"button\" data-dava-action=\"clear\" class=\"danger\" title=\"Clear editor\">Clear</button>",
      "<button type=\"button\" data-dava-action=\"exit\" title=\"Exit editor\">Exit</button>"
    ].join("");

    if (anchor && anchor.parentNode) {
      anchor.parentNode.insertBefore(menu, anchor.nextSibling);
    } else {
      document.body.insertBefore(menu, document.body.firstChild);
    }

    menu.addEventListener("click", function (event) {
      var button = event.target.closest("[data-dava-action]");
      if (!button) return;
      if (button.dataset.davaAction === "create-area-text") {
        if (window.DAVA_SVGEDIT_TEXTBOX_API && typeof window.DAVA_SVGEDIT_TEXTBOX_API.createAreaText === "function") {
          window.DAVA_SVGEDIT_TEXTBOX_API.createAreaText({ text: "输入文字" });
        } else {
          console.warn("[DAVA SVG-Edit bridge] DAVA area text API is not available.");
        }
        return;
      }
      if (button.dataset.davaAction === "convert-area-text") {
        if (window.DAVA_SVGEDIT_TEXTBOX_API && typeof window.DAVA_SVGEDIT_TEXTBOX_API.convertSelectedTextToAreaText === "function") {
          window.DAVA_SVGEDIT_TEXTBOX_API.convertSelectedTextToAreaText();
        } else {
          console.warn("[DAVA SVG-Edit bridge] DAVA area text API is not available.");
        }
        return;
      }
      if (button.dataset.davaAction === "save") {
        requestSave("toolbar");
        return;
      }
      if (button.dataset.davaAction === "pdf-import") {
        openPdfImportPanel();
        return;
      }
      if (button.dataset.davaAction === "exit") {
        handleExitRequest();
        return;
      }
      hostAction(button.dataset.davaAction);
    });
    menu.querySelector("select").addEventListener("change", function (event) {
      hostAction("set-source", { value: event.target.value || "" });
    });
    window.setTimeout(function () { hostAction("refresh-menu"); }, 250);
  }

  function ensurePdfImportNativeMenuItem() {
    var menu = document.getElementById("main_button");
    if (!menu || document.getElementById("dava_tool_pdf_import_menu")) return;
    var item = document.createElement("div");
    item.id = "dava_tool_pdf_import_menu";
    item.className = "dava-pdf-menu-item";
    item.setAttribute("role", "menuitem");
    item.setAttribute("tabindex", "0");
    item.setAttribute("title", "PDF Import");
    item.setAttribute("aria-label", "PDF Import");
    item.innerHTML = "<span class=\"dava-pdf-menu-icon\" aria-hidden=\"true\"></span><span class=\"dava-pdf-menu-label\">PDF Import</span>";
    var openPdfMenu = function (event) {
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
      openPdfImportPanel();
    };
    item.addEventListener("click", openPdfMenu, true);
    item.addEventListener("keydown", function (event) {
      if (event.key === "Enter" || event.key === " ") openPdfMenu(event);
    });
    var importItem = document.getElementById("tool_import") || document.getElementById("tool_export");
    if (importItem && importItem.parentNode === menu && importItem.nextSibling) {
      menu.insertBefore(item, importItem.nextSibling);
    } else {
      menu.appendChild(item);
    }
    var style = document.getElementById("dava_pdf_import_menu_style");
    if (!style) {
      style = document.createElement("style");
      style.id = "dava_pdf_import_menu_style";
      style.textContent = [
        "#dava_tool_pdf_import_menu{display:flex!important;align-items:center!important;gap:12px!important;min-height:34px!important;padding:4px 16px!important;color:#fff!important;font:600 14px/1.2 Arial,sans-serif!important;box-sizing:border-box!important;cursor:pointer!important;width:100%!important}",
        "#dava_tool_pdf_import_menu .dava-pdf-menu-icon{width:24px;height:24px;flex:0 0 24px;background:transparent url('images/import.svg') center/22px 22px no-repeat}",
        "#dava_tool_pdf_import_menu .dava-pdf-menu-label{display:inline-block!important;white-space:nowrap!important;color:#fff!important;text-shadow:0 1px 1px rgba(0,0,0,.35);font-size:inherit!important;font-weight:inherit!important;line-height:inherit!important}",
        "#dava_tool_pdf_import_menu:hover{background:rgba(255,255,255,.12)!important}"
      ].join("\n");
      document.head.appendChild(style);
    }
  }

  function updateDavaMenuState(message) {
    ensureDavaMenu();
    var select = document.getElementById("dava_svgedit_source_select");
    var currentValue = message.sources && message.sources.value || "";
    var options = message.sources && message.sources.options || [];
    if (select) {
      select.innerHTML = "";
      options.forEach(function (item) {
        var parent = select;
        if (item.group) {
          parent = Array.prototype.find.call(select.children || [], function (child) {
            return child.tagName && child.tagName.toLowerCase() === "optgroup" && child.label === item.group;
          });
          if (!parent) {
            parent = document.createElement("optgroup");
            parent.label = item.group;
            select.appendChild(parent);
          }
        }
        var option = document.createElement("option");
        option.value = item.value || "";
        option.textContent = item.label || item.value || "";
        parent.appendChild(option);
      });
      select.value = currentValue;
    }
  }

  function getFonts() {
    return normalizeFonts(Array.isArray(window.DAVA_SVGEDIT_FONTS) ? window.DAVA_SVGEDIT_FONTS.slice() : []);
  }

  function findFontFamilyControl() {
    return document.getElementById("tool_font_family") ||
      document.querySelector("[data-attr='font-family']") ||
      document.querySelector("se-select#tool_font_family") ||
      document.querySelector("select#tool_font_family");
  }

  function splitControlList(value) {
    if (!value) return [];
    return String(value).split("::").map(function (item) { return item.trim(); }).filter(Boolean);
  }

  function appendUniqueControlValue(current, value) {
    var items = splitControlList(current);
    if (items.indexOf(value) === -1) items.push(value);
    return items.join("::");
  }

  function normalizeFonts(fonts) {
    var seen = {};
    return (fonts || []).filter(function (font) {
      if (!font || !font.label || !font.value) return false;
      var key = String(font.category || "") + "\u0000" + String(font.label) + "\u0000" + String(font.value);
      if (seen[key]) return false;
      seen[key] = true;
      return true;
    });
  }

  function fontGroupLabel(category) {
    switch (category) {
      case "Theme Fonts":
      case "Theme":
        return "主题字体";
      case "All Fonts":
      case "Office":
      case "Sans":
      case "Serif":
      case "CJK":
      case "Mono":
      case "Display":
      default:
        return "所有字体";
    }
  }

  function createFontOption(font) {
    var option = document.createElement("option");
    option.value = font.value;
    option.textContent = font.label;
    decorateFontOption(option, font);
    return option;
  }

  function rebuildNativeFontSelect(select, fonts, currentValue) {
    if (!select) return false;
    while (select.firstChild) select.removeChild(select.firstChild);

    var groups = [
      { key: "Theme Fonts", label: "主题字体", fonts: [] },
      { key: "All Fonts", label: "所有字体", fonts: [] }
    ];
    fonts.forEach(function (font) {
      var label = fontGroupLabel(font.category);
      var group = label === "主题字体" ? groups[0] : groups[1];
      group.fonts.push(font);
    });

    groups.forEach(function (group) {
      if (!group.fonts.length) return;
      var optgroup = document.createElement("optgroup");
      optgroup.label = group.label;
      group.fonts.forEach(function (font) {
        optgroup.appendChild(createFontOption(font));
      });
      select.appendChild(optgroup);
    });

    select.style.minWidth = "300px";
    select.style.maxWidth = "360px";
    select.style.fontFamily = window.DAVA_SVGEDIT_DEFAULT_FONT || "Arial, sans-serif";
    select.style.fontSize = "13px";
    if (currentValue) select.value = currentValue;
    if (!select.value && fonts[0]) select.value = fonts[0].value;
    return true;
  }

  function decorateFontOption(option, font) {
    if (!option || !font) return;
    option.setAttribute("data-dava-font-category", font.category || "");
    option.setAttribute("title", (font.category ? font.category + " | " : "") + font.label);
    try {
      option.style.fontFamily = font.value;
      option.style.fontSize = "14px";
    } catch (error) {}
  }

  function decorateFontControlPreview(control, fonts) {
    if (!control || !fonts || !fonts.length) return;
    control.setAttribute("data-dava-font-preview", "1");
    try {
      if (control.shadowRoot) {
        var select = control.shadowRoot.querySelector("select");
        if (select) {
          select.style.minWidth = "300px";
          select.style.maxWidth = "360px";
          select.style.fontFamily = window.DAVA_SVGEDIT_DEFAULT_FONT || "Arial, sans-serif";
          select.style.fontSize = "13px";
        }
        Array.prototype.forEach.call(control.shadowRoot.querySelectorAll("option"), function (node) {
          var value = node.getAttribute("value") || node.value || "";
          var font = fonts.find(function (item) { return item.value === value || item.label === node.textContent; });
          if (font) decorateFontOption(node, font);
        });
      }
    } catch (error) {}
  }

  function appendFontsToControl(fonts) {
    var control = findFontFamilyControl();
    if (!control) {
      console.warn("[DAVA SVG-Edit fonts] Font family control was not found.");
      return false;
    }
    fonts = normalizeFonts(fonts || getFonts());
    if (!fonts.length) return false;
    var currentValue = control.value || control.getAttribute("value") || window.DAVA_SVGEDIT_DEFAULT_FONT || "";

    if (control.tagName && control.tagName.toLowerCase() === "select") {
      return rebuildNativeFontSelect(control, fonts, currentValue);
    }

    control.setAttribute("data-dava-font-rebuilt", "1");
    control.setAttribute("options", "");
    control.setAttribute("values", "");
    if (control.shadowRoot) {
      var innerSelect = control.shadowRoot.querySelector("select");
      if (!innerSelect) return false;
      rebuildNativeFontSelect(innerSelect, fonts, currentValue);
      control.value = innerSelect.value;
      control.setAttribute("value", control.value);
    } else {
      control.setAttribute("options", fonts.map(function (font) { return font.label.replace(/,/g, " "); }).join(","));
      control.setAttribute("values", fonts.map(function (font) { return font.value; }).join("::"));
      control.value = currentValue;
      control.setAttribute("value", currentValue);
    }
    decorateFontControlPreview(control, fonts);
    return true;
  }

  function textSelection(canvas) {
    if (!canvas || typeof canvas.getSelectedElements !== "function") return [];
    var out = [];
    canvas.getSelectedElements().filter(Boolean).forEach(function (element) {
      if (!element || !element.tagName) return;
      var name = element.tagName.toLowerCase();
      if (name === "text" || name === "tspan") {
        out.push(element);
      }
      if (element.querySelectorAll) {
        Array.prototype.forEach.call(element.querySelectorAll("text,tspan"), function (child) {
          out.push(child);
        });
      }
    });
    return out.filter(function (element, index, list) {
      return list.indexOf(element) === index;
    });
  }

  function isSvgTextNode(node) {
    return !!(node && node.tagName && /^(text|tspan)$/i.test(node.tagName));
  }

  function textNodesIn(element) {
    var nodes = [];
    if (isSvgTextNode(element)) nodes.push(element);
    if (element && element.querySelectorAll) {
      Array.prototype.forEach.call(element.querySelectorAll("text,tspan"), function (child) {
        nodes.push(child);
      });
    }
    return nodes.filter(function (node, index, list) {
      return list.indexOf(node) === index;
    });
  }

  function normalizeTextStretchAttributes(element) {
    var nodes = textNodesIn(element);
    var changed = false;
    nodes.forEach(function (node) {
      ["textLength", "lengthAdjust"].forEach(function (name) {
        if (node.hasAttribute && node.hasAttribute(name)) {
          node.removeAttribute(name);
          changed = true;
        }
      });
    });
    return changed;
  }

  function clearImportWrapperPaint(element) {
    if (!element || !element.getAttribute || !element.removeAttribute) return false;
    var tag = (element.tagName || "").toLowerCase();
    if (tag !== "use" && tag !== "g") return false;
    var changed = false;
    ["fill", "fill-opacity", "stroke", "stroke-opacity", "color", "opacity"].forEach(function (name) {
      if (element.hasAttribute(name)) {
        element.removeAttribute(name);
        changed = true;
      }
    });
    var style = element.getAttribute("style") || "";
    if (style) {
      var filtered = style.split(";").filter(function (declaration) {
        var name = declaration.split(":", 1)[0].trim().toLowerCase();
        return ["fill", "fill-opacity", "stroke", "stroke-opacity", "color", "opacity"].indexOf(name) === -1;
      }).join(";").trim();
      if (filtered !== style.trim()) {
        if (filtered) element.setAttribute("style", filtered);
        else element.removeAttribute("style");
        changed = true;
      }
    }
    return changed;
  }

  function restoreSvgEditorKeyboardFocus() {
    try { window.focus(); } catch (error) {}
    var active = document.activeElement;
    if (active && active !== document.body && typeof active.blur === "function") {
      active.blur();
    }
  }

  function isScriptTextSpan(node) {
    return !!(node && node.getAttribute &&
      (node.getAttribute("data-dava-script") || node.getAttribute("baseline-shift")));
  }

  function syncTextAttributeToLines(root, attribute, value) {
    root = textRootForNode(root);
    if (!root || !root.getAttribute) return false;
    var changed = false;
    var lineTspans = directLineTspans(root);

    function setOrRemove(node) {
      if (!node || !node.setAttribute) return;
      if (attribute === "font-size" && isScriptTextSpan(node)) return;
      if (value === "" || value === null || value === undefined) {
        if (node.hasAttribute && node.hasAttribute(attribute)) {
          node.removeAttribute(attribute);
          changed = true;
        }
      } else if (node.getAttribute(attribute) !== String(value)) {
        node.setAttribute(attribute, String(value));
        changed = true;
      }
    }

    setOrRemove(root);
    lineTspans.forEach(setOrRemove);
    return changed;
  }

  function normalizeSelectedTextSizing(canvas, attribute, value) {
    var nodes = selectedTextNodes(canvas);
    var roots = [];
    nodes.forEach(function (node) {
      normalizeTextStretchAttributes(node);
      var root = textRootForNode(node);
      if (root && roots.indexOf(root) === -1) roots.push(root);
    });
    roots.forEach(function (root) {
      normalizeTextStretchAttributes(root);
      if (attribute) syncTextAttributeToLines(root, attribute, value);
      if (root.getAttribute && root.getAttribute("data-dava-multiline-text") !== null) {
        layoutMultilineText(root);
      }
    });
    return roots.length > 0 || nodes.length > 0;
  }

  function applyFontToSelection(fontFamily) {
    if (!fontFamily) return false;
    var canvas = getSvgCanvas();
    var control = findFontFamilyControl();

    if (control) {
      try {
        control.value = fontFamily;
        control.setAttribute("value", fontFamily);
        control.dispatchEvent(new CustomEvent("change", {
          bubbles: true,
          detail: { value: fontFamily }
        }));
      } catch (error) {
        console.warn("[DAVA SVG-Edit fonts] Native font control dispatch failed.", error);
      }
    }

    if (canvas && typeof canvas.setFontFamily === "function") {
      try {
        canvas.setFontFamily(fontFamily);
        normalizeSelectedTextSizing(canvas, "font-family", fontFamily);
        relayoutSelectedAreaText(canvas);
        return true;
      } catch (error) {
        console.warn("[DAVA SVG-Edit fonts] Native setFontFamily failed; falling back to selected text attributes.", error);
      }
    }

    var textNodes = textSelection(canvas);
    if (textNodes.length === 0) return false;
    if (canvas && typeof canvas.changeSelectedAttribute === "function") {
      try {
        canvas.changeSelectedAttribute("font-family", fontFamily, textNodes);
        canvas.call && canvas.call("changed", textNodes);
        normalizeSelectedTextSizing(canvas, "font-family", fontFamily);
        relayoutSelectedAreaText(canvas);
        return true;
      } catch (error) {
        console.warn("[DAVA SVG-Edit fonts] changeSelectedAttribute failed; setting attributes directly.", error);
      }
    }

    textNodes.forEach(function (node) {
      node.setAttribute("font-family", fontFamily);
    });
    normalizeSelectedTextSizing(canvas, "font-family", fontFamily);
    try { canvas && canvas.call && canvas.call("changed", textNodes); } catch (error) {}
    relayoutSelectedAreaText(canvas);
    return true;
  }

  function selectedTextNodes(canvas) {
    return textSelection(canvas).filter(function (node) {
      return node && node.tagName && /^(text|tspan)$/i.test(node.tagName);
    });
  }

  function callTextChanged(canvas, nodes, reason) {
    try { canvas && canvas.call && canvas.call("changed", nodes); } catch (error) {}
    relayoutSelectedAreaText(canvas);
    markDirty(reason || "text-style");
    window.setTimeout(updateTextStyleToolState, 0);
  }

  function applyTextAttribute(canvas, nodes, attribute, value) {
    if (!nodes.length) return;
    if (canvas && typeof canvas.changeSelectedAttribute === "function") {
      try {
        canvas.changeSelectedAttribute(attribute, value, nodes);
        if (attribute === "font-family" || attribute === "font-size") {
          nodes.forEach(function (node) {
            normalizeTextStretchAttributes(node);
            syncTextAttributeToLines(node, attribute, value);
          });
        }
        return;
      } catch (error) {
        console.warn("[DAVA SVG-Edit text] changeSelectedAttribute failed.", error);
      }
    }
    nodes.forEach(function (node) {
      if (value === "" || value === null || value === undefined) {
        node.removeAttribute(attribute);
      } else {
        node.setAttribute(attribute, value);
      }
      if (attribute === "font-family" || attribute === "font-size") {
        normalizeTextStretchAttributes(node);
        syncTextAttributeToLines(node, attribute, value);
      }
    });
  }

  function activateTextTool() {
    return withSvgEditor(function (editor, canvas) {
      if (editor.leftPanel && typeof editor.leftPanel.clickText === "function") {
        editor.leftPanel.clickText();
      } else if (typeof canvas.setMode === "function") {
        canvas.setMode("text");
      }
    });
  }

  function setTextOrientation(orientation) {
    var canvas = getSvgCanvas();
    var nodes = selectedTextNodes(canvas);
    var vertical = orientation === "vertical";
    setVerticalTextCursor(vertical);

    if (!nodes.length) {
      activateTextTool();
      updateTextStyleToolState();
      return true;
    }

    applyTextAttribute(canvas, nodes, "writing-mode", vertical ? "vertical-rl" : "");
    applyTextAttribute(canvas, nodes, "text-orientation", vertical ? "upright" : "");
    nodes.forEach(function (node) {
      node.setAttribute("data-dava-text-orientation", vertical ? "vertical" : "horizontal");
    });
    callTextChanged(canvas, nodes, "text-orientation");
    return true;
  }

  function setVerticalTextCursor(vertical) {
    try {
      document.body.classList.toggle("dava-vertical-text-cursor", !!vertical);
    } catch (error) {}
  }

  function isVerticalTextNode(node) {
    if (!node || !node.getAttribute) return false;
    return /vertical/i.test(node.getAttribute("writing-mode") || "") ||
      node.getAttribute("data-dava-text-orientation") === "vertical";
  }

  function currentEditingTextRoot(canvas) {
    var nodes = selectedTextNodes(canvas);
    if (nodes.length) return textRootForNode(nodes[0]);
    var selected = selectedElements(canvas);
    if (selected.length) {
      return textRootForNode(selected[0]);
    }
    return null;
  }

  function isTextEditMode(canvas) {
    if (!canvas || typeof canvas.getCurrentMode !== "function") return false;
    try {
      return canvas.getCurrentMode() === "textedit";
    } catch (error) {
      return false;
    }
  }

  function elementTransformMatrix(element) {
    try {
      var list = element && element.transform && element.transform.baseVal;
      if (!list || list.numberOfItems === 0) return null;
      var consolidated = list.consolidate();
      return consolidated && consolidated.matrix ? consolidated.matrix : null;
    } catch (error) {
      return null;
    }
  }

  function textPointToCursorScreen(canvas, root, x, y) {
    var point = transformPointByMatrix(x, y, elementTransformMatrix(root));
    var zoom = canvas && typeof canvas.getZoom === "function" ? canvas.getZoom() : 1;
    return {
      x: point.x * zoom,
      y: point.y * zoom
    };
  }

  function verticalCaretGeometry(canvas, root, index) {
    var text = String(root && root.textContent || "");
    var length = text.length;
    if (!root || !length || typeof root.getExtentOfChar !== "function") return null;
    var charIndex = Math.max(0, Math.min(index, length - 1));
    var extent;
    try {
      extent = root.getExtentOfChar(charIndex);
    } catch (error) {
      return null;
    }
    if (!extent) return null;
    var caretY = index >= length ? extent.y + extent.height : extent.y;
    var lineWidth = Math.max(extent.width || 0, numericFontSize(root) * 0.9);
    var centerX = extent.x + (extent.width || lineWidth) / 2;
    var left = textPointToCursorScreen(canvas, root, centerX - lineWidth / 2, caretY);
    var right = textPointToCursorScreen(canvas, root, centerX + lineWidth / 2, caretY);
    return { x1: left.x, y1: left.y, x2: right.x, y2: right.y };
  }

  function setNumericAttributeIfChanged(element, name, value) {
    var current = Number.parseFloat(element.getAttribute(name));
    if (Number.isFinite(current) && Math.abs(current - value) < 0.01) return;
    element.setAttribute(name, String(value));
  }

  function adjustVerticalTextCursor() {
    var canvas = getSvgCanvas();
    var input = document.getElementById("text");
    var cursor = document.getElementById("text_cursor");
    if (!canvas || !input || !cursor || !isTextEditMode(canvas)) return;
    var root = currentEditingTextRoot(canvas);
    if (!isVerticalTextNode(root)) return;
    var index = typeof input.selectionStart === "number" ? input.selectionStart : 0;
    var geometry = verticalCaretGeometry(canvas, root, index);
    if (!geometry) return;
    setNumericAttributeIfChanged(cursor, "x1", geometry.x1);
    setNumericAttributeIfChanged(cursor, "x2", geometry.x2);
    setNumericAttributeIfChanged(cursor, "y1", geometry.y1);
    setNumericAttributeIfChanged(cursor, "y2", geometry.y2);
  }

  function multilineCaretGeometry(canvas, root, index) {
    if (!root || !root.getAttribute || root.getAttribute("data-dava-multiline-text") === null) return null;
    var text = multilineTextValue(root);
    var before = text.slice(0, Math.max(0, index));
    var lineIndex = before.split(/\n/).length - 1;
    var column = before.length - before.lastIndexOf("\n") - 1;
    var tspans = directLineTspans(root);
    var line = tspans[Math.max(0, Math.min(lineIndex, tspans.length - 1))];
    if (!line) return null;
    var fontSize = numericFontSize(root);
    var x = baseTextPosition(line, "x", baseTextPosition(root, "x", 0));
    var y = baseTextPosition(line, "y", baseTextPosition(root, "y", 0));
    if (!line.getAttribute("y")) {
      var firstY = baseTextPosition(tspans[0], "y", baseTextPosition(root, "y", 0));
      var lineHeight = Number.parseFloat(root.getAttribute("data-dava-line-spacing") || "1.2");
      if (!Number.isFinite(lineHeight) || lineHeight <= 0) lineHeight = 1.2;
      y = firstY + lineIndex * Math.max(1, fontSize * lineHeight);
    }
    var lineText = String(line.textContent || "");
    var usableLength = lineText === " " ? 0 : lineText.length;
    if (column > 0 && usableLength > 0 && typeof line.getEndPositionOfChar === "function") {
      try {
        var charPoint = line.getEndPositionOfChar(Math.min(column, usableLength) - 1);
        x = charPoint.x;
        y = charPoint.y;
      } catch (error) {}
    }
    var top = textPointToCursorScreen(canvas, root, x, y - fontSize * 0.9);
    var bottom = textPointToCursorScreen(canvas, root, x, y + fontSize * 0.22);
    return { x1: top.x, y1: top.y, x2: bottom.x, y2: bottom.y };
  }

  function adjustMultilineTextCursor() {
    var canvas = getSvgCanvas();
    var input = document.getElementById("text");
    var cursor = document.getElementById("text_cursor");
    if (!canvas || !input || !cursor || !isTextEditMode(canvas)) return;
    var root = currentEditingTextRoot(canvas);
    if (!root || isVerticalTextNode(root)) return;
    var index = typeof input.selectionStart === "number" ? input.selectionStart : 0;
    var geometry = multilineCaretGeometry(canvas, root, index);
    if (!geometry) return;
    setNumericAttributeIfChanged(cursor, "x1", geometry.x1);
    setNumericAttributeIfChanged(cursor, "x2", geometry.x2);
    setNumericAttributeIfChanged(cursor, "y1", geometry.y1);
    setNumericAttributeIfChanged(cursor, "y2", geometry.y2);
  }

  function scheduleTextCaretAdjust(delay) {
    var run = function () {
      var canvas = getSvgCanvas();
      if (!isTextEditMode(canvas)) return;
      adjustVerticalTextCursor();
      adjustMultilineTextCursor();
    };
    if (delay) {
      window.setTimeout(run, delay);
    } else {
      window.requestAnimationFrame(run);
    }
  }

  function ensureVerticalTextCaretBridge() {
    if (document.documentElement.getAttribute("data-dava-vertical-text-caret-bridge") === "1") return;
    document.documentElement.setAttribute("data-dava-vertical-text-caret-bridge", "1");
    var scheduled = false;
    var schedule = function () {
      if (!isTextEditMode(getSvgCanvas())) return;
      if (scheduled) return;
      scheduled = true;
      window.requestAnimationFrame(function () {
        scheduled = false;
        adjustVerticalTextCursor();
        adjustMultilineTextCursor();
      });
    };
    var observer = new MutationObserver(schedule);
    observer.observe(document.documentElement, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ["x1", "x2", "y1", "y2", "visibility", "display"]
    });
    schedule();
  }

  function transformPointByMatrix(x, y, matrix) {
    if (!matrix) return { x: x, y: y };
    return {
      x: matrix.a * x + matrix.c * y + matrix.e,
      y: matrix.b * x + matrix.d * y + matrix.f
    };
  }

  function numericFontSize(node) {
    var raw = node && node.getAttribute && node.getAttribute("font-size");
    if (!raw && window.getComputedStyle) {
      try { raw = window.getComputedStyle(node).fontSize; } catch (error) {}
    }
    var match = String(raw || "").match(/^([0-9.]+)/);
    return match ? Number(match[1]) : 16;
  }

  function textRootForNode(node) {
    var current = node;
    while (current && current.tagName && !/^text$/i.test(current.tagName)) {
      current = current.parentNode;
    }
    return current && current.tagName && /^text$/i.test(current.tagName) ? current : node;
  }

  function selectedTextRoot(canvas) {
    var nodes = selectedTextNodes(canvas);
    if (nodes.length) return textRootForNode(nodes[0]);
    var selected = selectedElements(canvas);
    for (var index = 0; index < selected.length; index += 1) {
      var element = selected[index];
      if (!element || !element.tagName) continue;
      if (/^text$/i.test(element.tagName)) return element;
      if (element.querySelector) {
        var text = element.querySelector("text");
        if (text) return text;
      }
    }
    return null;
  }

  function multilineTextValue(root) {
    if (!root || !root.getAttribute) return "";
    return root.getAttribute("data-dava-multiline-text") || root.textContent || "";
  }

  function baseTextPosition(root, name, fallback) {
    if (!root || !root.getAttribute) return fallback;
    var value = root.getAttribute(name);
    if ((value === null || value === "") && root.querySelector) {
      var first = root.querySelector("tspan");
      if (first) value = first.getAttribute(name);
    }
    var number = Number.parseFloat(value);
    return Number.isFinite(number) ? number : fallback;
  }

  function stripParagraphPrefix(line) {
    return String(line || "").replace(/^(\s*(?:\u2022|\u25e6|\u25aa|\u25a0|\u25c6|-|\([0-9]+\)|[0-9]+[.)]|[A-Z][.)]|[a-z][.)]|[IVXLCDM]+[.)])\s+)/i, "");
  }

  function paragraphLines(root) {
    return multilineTextValue(root).split(/\r?\n/);
  }

  function listMarkerForStyle(style, index) {
    var one = index + 1;
    if (style === "bullet-square") return "\u25aa";
    if (style === "bullet-diamond") return "\u25c6";
    if (style === "bullet-circle") return "\u25e6";
    if (style === "bullet-dash") return "-";
    if (style === "number-alpha") return String.fromCharCode(65 + (index % 26)) + ".";
    if (style === "number-lower") return String.fromCharCode(97 + (index % 26)) + ".";
    if (style === "number-paren") return one + ")";
    if (style === "number-roman") {
      var romans = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"];
      return (romans[index] || String(one)) + ".";
    }
    if (style === "number-circle") return "(" + one + ")";
    if (style && style.indexOf("number") === 0) return one + ".";
    return "\u2022";
  }

  function listFamily(style) {
    return String(style || "").indexOf("number") === 0 ? "number" : "bullet";
  }

  function directLineTspans(root) {
    if (!root || !root.children) return [];
    return Array.prototype.filter.call(root.children, function (child) {
      return child && child.tagName && /^tspan$/i.test(child.tagName);
    });
  }

  function layoutMultilineText(root, text) {
    if (!root || !root.ownerDocument) return false;
    normalizeTextStretchAttributes(root);
    text = String(text === undefined ? multilineTextValue(root) : text);
    var multiline = text.indexOf("\n") !== -1 ||
      root.getAttribute("data-dava-multiline-text") !== null ||
      root.getAttribute("data-dava-line-spacing") ||
      root.getAttribute("data-dava-list-style") ||
      root.getAttribute("data-dava-paragraph-indent");
    if (!multiline) return false;
    var owner = root.ownerDocument;
    var x = baseTextPosition(root, "x", 0);
    var y = baseTextPosition(root, "y", 0);
    var indent = Number.parseFloat(root.getAttribute("data-dava-paragraph-indent") || "0");
    if (!Number.isFinite(indent)) indent = 0;
    var lineHeight = Number.parseFloat(root.getAttribute("data-dava-line-spacing") || "1.2");
    if (!Number.isFinite(lineHeight) || lineHeight <= 0) lineHeight = 1.2;
    var dy = Math.max(1, numericFontSize(root) * lineHeight);
    var lines = text.split(/\r?\n/);
    var attrs = {};
    ["font-family", "font-size", "font-style", "font-weight", "fill", "text-anchor", "writing-mode", "text-orientation"].forEach(function (name) {
      var value = root.getAttribute(name);
      if (value) attrs[name] = value;
    });
    while (root.firstChild) root.removeChild(root.firstChild);
    root.setAttribute("data-dava-multiline-text", text);
    root.setAttribute("xml:space", "preserve");
    lines.forEach(function (line, index) {
      var tspan = owner.createElementNS("http://www.w3.org/2000/svg", "tspan");
      Object.keys(attrs).forEach(function (name) { tspan.setAttribute(name, attrs[name]); });
      tspan.setAttribute("x", String(x + indent));
      if (index === 0) tspan.setAttribute("y", String(y));
      else tspan.setAttribute("dy", String(dy));
      tspan.textContent = line.length ? line : " ";
      root.appendChild(tspan);
      if (index < lines.length - 1) root.appendChild(owner.createTextNode("\n"));
    });
    normalizeTextStretchAttributes(root);
    normalizeRichTextPointerEvents(root);
    return true;
  }

  function applyMultilineTextValue(value) {
    var canvas = getSvgCanvas();
    var root = selectedTextRoot(canvas);
    if (!root) return false;
    value = String(value || "");
    if (canvas && typeof canvas.changeSelectedAttribute === "function") {
      try {
        canvas.changeSelectedAttribute("#text", value, [root]);
      } catch (error) {
        root.textContent = value;
      }
    } else {
      root.textContent = value;
    }
    layoutMultilineText(root, value);
    try { canvas && canvas.call && canvas.call("changed", [root]); } catch (error) {}
    try { canvas && canvas.textActions && canvas.textActions.init && canvas.textActions.init(); } catch (error) {}
    markDirty("text-multiline");
    window.setTimeout(updateTextStyleToolState, 0);
    return true;
  }

  function setParagraphAlignment(anchor) {
    var canvas = getSvgCanvas();
    var root = selectedTextRoot(canvas);
    if (!root) return false;
    var value = anchor === "center" ? "middle" : anchor === "right" ? "end" : "start";
    root.setAttribute("text-anchor", value);
    root.setAttribute("data-dava-paragraph-align", anchor || "left");
    layoutMultilineText(root);
    callTextChanged(canvas, [root], "paragraph-align");
    return true;
  }

  function setParagraphLineSpacing(mode) {
    var canvas = getSvgCanvas();
    var root = selectedTextRoot(canvas);
    if (!root) return false;
    var current = Number.parseFloat(root.getAttribute("data-dava-line-spacing") || "1.2");
    var values = mode ? [Number(mode)] : [1, 1.15, 1.5, 2];
    var next = values[0];
    if (!mode) {
      var index = values.reduce(function (best, value, valueIndex) {
        return Math.abs(value - current) < Math.abs(values[best] - current) ? valueIndex : best;
      }, 0);
      next = values[(index + 1) % values.length];
    }
    root.setAttribute("data-dava-line-spacing", String(next));
    layoutMultilineText(root);
    callTextChanged(canvas, [root], "paragraph-line-spacing");
    return true;
  }

  function setParagraphListStyle(style) {
    var canvas = getSvgCanvas();
    var root = selectedTextRoot(canvas);
    if (!root) return false;
    var lines = paragraphLines(root).map(stripParagraphPrefix);
    var currentStyle = root.getAttribute("data-dava-list-style") || "";
    var active = currentStyle === style;
    if (active) {
      root.removeAttribute("data-dava-list-style");
    } else {
      root.setAttribute("data-dava-list-style", style);
      lines = lines.map(function (line, index) {
        return listMarkerForStyle(style, index) + " " + line;
      });
    }
    var text = lines.join("\n");
    root.setAttribute("data-dava-multiline-text", text);
    layoutMultilineText(root, text);
    callTextChanged(canvas, [root], "paragraph-list");
    var input = document.getElementById("text");
    if (input) input.value = text;
    return true;
  }

  function clearParagraphListStyle() {
    var canvas = getSvgCanvas();
    var root = selectedTextRoot(canvas);
    if (!root) return false;
    var text = paragraphLines(root).map(stripParagraphPrefix).join("\n");
    root.removeAttribute("data-dava-list-style");
    root.setAttribute("data-dava-multiline-text", text);
    layoutMultilineText(root, text);
    callTextChanged(canvas, [root], "paragraph-list-clear");
    var input = document.getElementById("text");
    if (input) input.value = text;
    return true;
  }

  function adjustParagraphIndent(delta) {
    var canvas = getSvgCanvas();
    var root = selectedTextRoot(canvas);
    if (!root) return false;
    var current = Number.parseFloat(root.getAttribute("data-dava-paragraph-indent") || "0");
    if (!Number.isFinite(current)) current = 0;
    var next = Math.max(0, current + delta);
    if (next) root.setAttribute("data-dava-paragraph-indent", String(next));
    else root.removeAttribute("data-dava-paragraph-indent");
    layoutMultilineText(root);
    callTextChanged(canvas, [root], "paragraph-indent");
    return true;
  }

  function activeTextEditSelection(canvas) {
    var nativeEditor = window.__davaActiveSvgTextEditor;
    var snapshot = window.__davaTextSelectionSnapshot;
    if (nativeEditor && snapshot && snapshot.element === nativeEditor.element &&
        Number.isFinite(snapshot.start) && Number.isFinite(snapshot.end) && snapshot.start !== snapshot.end) {
      var snapshotText = String(snapshot.text || nativeEditor.input.value || "");
      var snapshotStart = Math.min(snapshot.start, snapshot.end);
      var snapshotEnd = Math.max(snapshot.start, snapshot.end);
      if (snapshotEnd <= snapshotText.length) {
        return { node: nativeEditor.element, start: snapshotStart, end: snapshotEnd, text: snapshotText };
      }
    }
    if (nativeEditor && nativeEditor.element && nativeEditor.input) {
      var nativeInput = nativeEditor.input;
      var nativeStart = nativeInput.selectionStart;
      var nativeEnd = nativeInput.selectionEnd;
      if (typeof nativeEditor.selectionStart === "number" && typeof nativeEditor.selectionEnd === "number" &&
          nativeEditor.selectionStart !== nativeEditor.selectionEnd) {
        nativeStart = nativeEditor.selectionStart;
        nativeEnd = nativeEditor.selectionEnd;
      }
      if (typeof nativeStart === "number" && typeof nativeEnd === "number" && nativeStart !== nativeEnd) {
        if (nativeStart > nativeEnd) {
          var nativeTmp = nativeStart;
          nativeStart = nativeEnd;
          nativeEnd = nativeTmp;
        }
      // The editor input is the authoritative logical text. SVG may have
      // split the same label into styled tspans, so textContent is not a safe
      // index space for a saved local selection.
        var nativeText = String(nativeInput.value || nativeEditor.element.textContent || "");
        if (nativeEnd <= nativeText.length) {
          return { node: nativeEditor.element, start: nativeStart, end: nativeEnd, text: nativeText };
        }
      }
    }
    var input = document.getElementById("text");
    if (!input || typeof input.selectionStart !== "number" || typeof input.selectionEnd !== "number") return null;
    var start = input.selectionStart;
    var end = input.selectionEnd;
    if (!Number.isFinite(start) || !Number.isFinite(end) || start === end) return null;
    if (start > end) {
      var tmp = start;
      start = end;
      end = tmp;
    }
    var nodes = selectedTextNodes(canvas);
    if (!nodes.length) return null;
    var value = String(input.value || "");
    var node = nodes.filter(function (item) {
      return item && item.tagName && /^text$/i.test(item.tagName) && String(item.textContent || "") === value;
    })[0] || nodes.map(textRootForNode).filter(function (item) {
      return String(item.textContent || "") === value;
    })[0] || nodes[0];
    node = textRootForNode(node);
    var text = String(node.textContent || value || "");
    if (end > text.length) return null;
    return { node: node, start: start, end: end, text: text };
  }

  function createSvgTspan(owner, text, attrs) {
    var tspan = owner.createElementNS("http://www.w3.org/2000/svg", "tspan");
    tspan.textContent = text;
    Object.keys(attrs || {}).forEach(function (name) {
      tspan.setAttribute(name, attrs[name]);
    });
    return tspan;
  }

  function textScriptAttrs(element) {
    var attrs = {};
    if (!element || !element.getAttribute) return attrs;
    var script = element.getAttribute("data-dava-script") || element.getAttribute("baseline-shift");
    if (script === "super" || script === "sub") {
      attrs["baseline-shift"] = script;
      attrs["data-dava-script"] = script;
      ["font-size", "data-dava-original-font-size"].forEach(function (name) {
        var value = element.getAttribute(name);
        if (value) attrs[name] = value;
      });
    }
    return attrs;
  }

  function sameTextRunAttrs(left, right) {
    var names = ["baseline-shift", "data-dava-script", "font-size", "data-dava-original-font-size"];
    return names.every(function (name) {
      return String((left || {})[name] || "") === String((right || {})[name] || "");
    });
  }

  function appendTextRun(runs, text, attrs) {
    if (!text) return;
    var nextAttrs = Object.assign({}, attrs || {});
    var previous = runs[runs.length - 1];
    if (previous && sameTextRunAttrs(previous.attrs, nextAttrs)) {
      previous.text += text;
    } else {
      runs.push({ text: text, attrs: nextAttrs });
    }
  }

  function collectTextRuns(root) {
    var runs = [];
    var inherited = textScriptAttrs(root);
    function walk(node, attrs) {
      Array.prototype.forEach.call(node.childNodes || [], function (child) {
        if (child.nodeType === 3) {
          var value = child.nodeValue || "";
          // Newline/indent text nodes between tspans are SVG serialization
          // whitespace, not characters in the label. Do not let them shift
          // the editor's selection indices.
          if (!(node === root && /^\s+$/.test(value) && node.querySelector("tspan"))) {
            appendTextRun(runs, value, attrs);
          }
          return;
        }
        if (child.nodeType !== 1) return;
        if (child.tagName && /^tspan$/i.test(child.tagName)) {
          var childAttrs = Object.assign({}, attrs || {}, textScriptAttrs(child));
          if (child.childNodes && child.childNodes.length) {
            walk(child, childAttrs);
          } else {
            appendTextRun(runs, child.textContent || "", childAttrs);
          }
        }
      });
    }
    walk(root, inherited);
    if (!runs.length) appendTextRun(runs, String(root.textContent || ""), inherited);
    return runs;
  }

  function rangeHasScript(runs, start, end, script) {
    var cursor = 0;
    var touched = false;
    var allMatch = true;
    runs.forEach(function (run) {
      var next = cursor + run.text.length;
      var overlapStart = Math.max(start, cursor);
      var overlapEnd = Math.min(end, next);
      if (overlapStart < overlapEnd) {
        touched = true;
        allMatch = allMatch && ((run.attrs || {})["data-dava-script"] === script || (run.attrs || {})["baseline-shift"] === script);
      }
      cursor = next;
    });
    return touched && allMatch;
  }

  function attrsForTextScript(root, script) {
    var size = numericFontSize(root);
    return {
      "baseline-shift": script,
      "data-dava-script": script,
      "data-dava-original-font-size": String(size),
      "font-size": String(Math.max(1, Math.round(size * 65) / 100))
    };
  }

  function normalizeRichTextPointerEvents(root) {
    if (!root || !root.querySelectorAll) return;
    root.removeAttribute("pointer-events");
    Array.prototype.forEach.call(root.querySelectorAll("tspan"), function (tspan) {
      tspan.removeAttribute("pointer-events");
    });
  }

  // R plots are imported inside an editable wrapper group.  Some R SVG
  // producers put pointer-events/user-select restrictions on that wrapper or
  // on the text runs.  Those restrictions make the browser report the group
  // as the mouse target, so SVG-Edit cannot place a caret or receive a drag
  // selection.  Keep the visual attributes intact, but make imported text a
  // normal SVG-Edit text target.
  function normalizeImportedTextEditing(element) {
    if (!element || !element.querySelectorAll) return false;
    var changed = false;
    var imported = element.closest && element.closest("[data-dava-source='R'],[data-dava-type='r-plot']");
    if (!imported && element.getAttribute && (element.getAttribute("data-dava-source") === "R" || element.getAttribute("data-dava-type") === "r-plot")) {
      imported = element;
    }
    if (!imported) return false;

    var nodes = [];
    if (isSvgTextNode(element)) nodes.push(element);
    Array.prototype.forEach.call(element.querySelectorAll("text,tspan"), function (node) {
      if (nodes.indexOf(node) === -1) nodes.push(node);
    });
    nodes.forEach(function (node) {
      if (node.hasAttribute && node.hasAttribute("pointer-events")) {
        node.removeAttribute("pointer-events");
        changed = true;
      }
      // Make the glyph itself the hit target. Without this, an annotation
      // whose producer emitted pointer-events:none is reported as its parent
      // group and the editor cannot determine which text object was double
      // clicked.
      if (node.setAttribute && node.getAttribute("pointer-events") !== "visiblePainted") {
        node.setAttribute("pointer-events", "visiblePainted");
        changed = true;
      }
      if (node.style) {
        var pointerEvents = node.style.pointerEvents;
        if (pointerEvents && pointerEvents.toLowerCase() === "none") {
          node.style.pointerEvents = "visiblePainted";
          changed = true;
        }
        if (node.style.userSelect !== "text") {
          node.style.userSelect = "text";
          node.style.webkitUserSelect = "text";
        }
      }
    });
    // A disabled ancestor would still prevent the text from becoming the
    // event target.  Only clear the blocking value on imported wrappers.
    var wrapper = element;
    while (wrapper && wrapper !== imported.parentNode) {
      if (wrapper.getAttribute && wrapper.hasAttribute("pointer-events") &&
          String(wrapper.getAttribute("pointer-events")).toLowerCase() === "none") {
        wrapper.removeAttribute("pointer-events");
        changed = true;
      }
      if (wrapper.style && String(wrapper.style.pointerEvents || "").toLowerCase() === "none") {
        wrapper.style.pointerEvents = "";
        changed = true;
      }
      wrapper = wrapper.parentNode;
    }
    return changed;
  }

  function importedTextRootFromTarget(target) {
    var node = target && target.correspondingUseElement ? target.correspondingUseElement : target;
    // SVG hit testing may report the imported wrapper/group instead of the
    // painted glyph (especially for small blue/red annotations). Resolve a
    // text descendant before walking ancestors so double-click reaches the
    // actual editable label.
    if (node && node.querySelector) {
      var descendant = node.querySelector("text");
      if (descendant) {
        var ownerDescendant = descendant.closest &&
          descendant.closest("[data-dava-source='R'],[data-dava-type='r-plot']");
        if (ownerDescendant) return descendant;
      }
    }
    while (node && node !== document) {
      if (isSvgTextNode(node)) {
        var root = textRootForNode(node);
        var owner = root && root.closest && root.closest("[data-dava-source='R'],[data-dava-type='r-plot']");
        if (owner) return root;
      }
      node = node.parentNode;
    }
    return null;
  }

  function importedTextAtPoint(clientX, clientY) {
    var hit = document.elementFromPoint ? document.elementFromPoint(clientX, clientY) : null;
    var resolved = importedTextRootFromTarget(hit);
    if (resolved) return resolved;
    // Some imported plots place an invisible hit surface over small labels.
    // Resolve the actual R text by its painted client rectangle as a fallback.
    var nodes = document.querySelectorAll(
      "[data-dava-source='R'] text,[data-dava-type='r-plot'] text,#svgcontent text,svg text"
    );
    for (var index = nodes.length - 1; index >= 0; index -= 1) {
      var node = nodes[index];
      var rect = node.getBoundingClientRect && node.getBoundingClientRect();
      if (!rect || (!rect.width && !rect.height)) continue;
      if (clientX >= rect.left - 4 && clientX <= rect.right + 4 &&
          clientY >= rect.top - 4 && clientY <= rect.bottom + 4) return node;
    }
    return null;
  }

  function importedTextPoint(event, canvas) {
    var matrix = canvas && typeof canvas.getrootSctm === "function" ? canvas.getrootSctm() : null;
    return transformPointByMatrix(event.clientX, event.clientY, matrix);
  }

  function ensureImportedTextEditBridge() {
    if (document.documentElement.getAttribute("data-dava-imported-text-edit-bridge") === "1") return;
    document.documentElement.setAttribute("data-dava-imported-text-edit-bridge", "1");

    ["mousedown", "mousemove", "mouseup"].forEach(function (eventName) {
      document.addEventListener(eventName, function (event) {
        var canvas = getSvgCanvas();
        if (!canvas || !canvas.textActions) return;
        var root = importedTextRootFromTarget(event.target) ||
          importedTextAtPoint(event.clientX, event.clientY);
        if (!root) return;
        normalizeImportedTextEditing(root);
        if (!canvas.getCurrentMode || canvas.getCurrentMode() !== "textedit") return;
        var point = importedTextPoint(event, canvas);
        var handler = canvas.textActions[eventName === "mousedown" ? "mouseDown" : eventName === "mousemove" ? "mouseMove" : "mouseUp"];
        if (typeof handler !== "function") return;
        // SVG-Edit's canvas listener may see the wrapper group rather than the
        // text node.  Feed the event to its native text action explicitly.
        event.preventDefault();
        event.stopImmediatePropagation();
        try {
          if (eventName === "mousedown") handler.call(canvas.textActions, event, root, point.x, point.y);
          else handler.call(canvas.textActions, event, point.x, point.y);
        } catch (error) {
          console.warn("[DAVA SVG-Edit text] Imported R text event forwarding failed.", error);
        }
      }, true);
    });

    document.addEventListener("dblclick", function (event) {
      var canvas = getSvgCanvas();
      var root = importedTextRootFromTarget(event.target) ||
        importedTextAtPoint(event.clientX, event.clientY);
      if (!canvas || !root) return;
      // R annotations (for example R2/P/n labels) are often nested tspans
      // with transforms. SVG-Edit's native textActions can enter text mode for
      // the object but cannot create a reliable drag range in those runs. Use
      // the browser-native DAVA editor first so every imported label behaves
      // like a PPT text box: drag-select, delete, replace and click-away commit.
      if (window.DAVA_SVGEDIT_TEXTBOX_API &&
          typeof window.DAVA_SVGEDIT_TEXTBOX_API.editSvgText === "function") {
        try {
          event.preventDefault();
          event.stopImmediatePropagation();
          normalizeImportedTextEditing(root);
          if (window.DAVA_SVGEDIT_TEXTBOX_API.editSvgText(root)) return;
        } catch (error) {
          console.warn("[DAVA SVG-Edit text] Native imported-text editor fallback failed.", error);
        }
      }
      if (!canvas.textActions || typeof canvas.textActions.select !== "function") return;
      if (canvas.getCurrentMode && canvas.getCurrentMode() === "textedit") return;
      try {
        event.preventDefault();
        event.stopImmediatePropagation();
        normalizeImportedTextEditing(root);
        var point = importedTextPoint(event, canvas);
        if (canvas.selectOnly) canvas.selectOnly([root]);
        canvas.textActions.select(root, point.x, point.y);
        window.setTimeout(function () {
          var input = document.getElementById("text");
          if (input && typeof input.focus === "function") input.focus();
          syncTextInputFromMultilineRoot();
        }, 0);
      } catch (error) {
        console.warn("[DAVA SVG-Edit text] Failed to enter imported R text edit mode.", error);
      }
    }, true);

    // Native SVG-Edit exits text mode on a click outside the text.  Do the
    // same explicitly for imported wrappers, which otherwise can retain the
    // edit state when their group consumes the click.
    document.addEventListener("mousedown", function (event) {
      var canvas = getSvgCanvas();
      // A DAVA text editor is a native textarea over the SVG.  Its drag
      // selection must not be interpreted as a click outside the SVG text
      // object by SVG-Edit's text-mode exit handler.
      if (event.target && event.target.closest &&
          event.target.closest(".dava-svg-text-editor,.dava-area-text-editor")) return;
      if (!canvas || !canvas.getCurrentMode || canvas.getCurrentMode() !== "textedit" ||
          !canvas.textActions || typeof canvas.textActions.toSelectMode !== "function") return;
      var active = selectedTextRoot(canvas);
      if (!active || (event.target && (event.target === active || (active.contains && active.contains(event.target))))) return;
      if (importedTextRootFromTarget(event.target)) return;
      try { canvas.textActions.toSelectMode(); } catch (error) {}
    }, true);
  }

  function rebuildTextRuns(root, runs) {
    var owner = root.ownerDocument || document;
    while (root.firstChild) root.removeChild(root.firstChild);
    root.setAttribute("data-dava-rich-text", "1");
    runs.forEach(function (run) {
      root.appendChild(createSvgTspan(owner, run.text, run.attrs));
    });
    normalizeRichTextPointerEvents(root);
  }

  function applyScriptToTextRange(canvas, range, script) {
    if (!range || !range.node) return false;
    var node = textRootForNode(range.node);
    var text = String(range.text || node.textContent || "");
    if (range.end > text.length || range.start === range.end) return false;
    var runs = collectTextRuns(node);
    var selectedAttrs = rangeHasScript(runs, range.start, range.end, script) ? {} : attrsForTextScript(node, script);
    var nextRuns = [];
    var cursor = 0;
    runs.forEach(function (run) {
      var next = cursor + run.text.length;
      var overlapStart = Math.max(range.start, cursor);
      var overlapEnd = Math.min(range.end, next);
      if (overlapStart >= overlapEnd) {
        appendTextRun(nextRuns, run.text, run.attrs);
      } else {
        appendTextRun(nextRuns, run.text.slice(0, overlapStart - cursor), run.attrs);
        appendTextRun(nextRuns, run.text.slice(overlapStart - cursor, overlapEnd - cursor), selectedAttrs);
        appendTextRun(nextRuns, run.text.slice(overlapEnd - cursor), run.attrs);
      }
      cursor = next;
    });
    rebuildTextRuns(node, nextRuns);
    callTextChanged(canvas, [node], "text-script");
    if (typeof window.__davaSvgTextEditorRefresh === "function" &&
        typeof window.__davaFinishSvgTextFormat !== "function") window.__davaSvgTextEditorRefresh();
    if (typeof window.__davaFocusSvgTextEditor === "function" &&
        typeof window.__davaFinishSvgTextFormat !== "function") {
      window.setTimeout(window.__davaFocusSvgTextEditor, 0);
    }
    return true;
  }

  function setTextScript(script) {
    if (window.__davaActiveRichTextEditor && typeof window.__davaApplyRichTextCommand === "function") {
      return window.__davaApplyRichTextCommand(script === "super" ? "superscript" : "subscript");
    }
    var canvas = getSvgCanvas();
    var range = activeTextEditSelection(canvas);
    if (range) {
      if (typeof window.__davaPrepareSvgTextFormat === "function") {
        window.__davaPrepareSvgTextFormat();
      }
      if (applyScriptToTextRange(canvas, range, script)) {
        if (typeof window.__davaFinishSvgTextFormat === "function") {
          window.__davaFinishSvgTextFormat();
        }
        return true;
      }
    }
    var nodes = selectedTextNodes(canvas);
    if (!nodes.length) return false;
    var active = nodes.every(function (node) {
      return node.getAttribute("data-dava-script") === script || node.getAttribute("baseline-shift") === script;
    });
    nodes.forEach(function (node) {
      var originalSize = node.getAttribute("data-dava-original-font-size");
      if (originalSize) {
        node.setAttribute("font-size", originalSize);
        node.removeAttribute("data-dava-original-font-size");
      }
      if (active) {
        node.removeAttribute("baseline-shift");
        node.removeAttribute("data-dava-script");
      } else {
        var size = numericFontSize(node);
        node.setAttribute("data-dava-original-font-size", String(size));
        node.setAttribute("baseline-shift", script);
        node.setAttribute("data-dava-script", script);
        node.setAttribute("font-size", String(Math.max(1, Math.round(size * 70) / 100)));
      }
    });
    callTextChanged(canvas, nodes, "text-script");
    return true;
  }

  function updateTextStyleToolState() {
    var canvas = getSvgCanvas();
    var nodes = selectedTextNodes(canvas);
    var vertical = false;
    if (nodes.length) {
      nodes.map(textRootForNode).forEach(normalizeRichTextPointerEvents);
      vertical = nodes.some(function (node) {
        return /vertical/i.test(node.getAttribute("writing-mode") || "") ||
          node.getAttribute("data-dava-text-orientation") === "vertical";
      });
    }
    var superActive = nodes.length && nodes.every(function (node) {
      return (node.getAttribute("data-dava-script") || node.getAttribute("baseline-shift")) === "super";
    });
    var subActive = nodes.length && nodes.every(function (node) {
      return (node.getAttribute("data-dava-script") || node.getAttribute("baseline-shift")) === "sub";
    });
    [
      ["dava_text_horizontal", !vertical],
      ["dava_text_vertical", vertical],
      ["dava_text_superscript", superActive],
      ["dava_text_subscript", subActive]
    ].forEach(function (entry) {
      var button = document.getElementById(entry[0]);
      if (button) button.classList.toggle("active", !!entry[1]);
    });
    var root = selectedTextRoot(canvas);
    var align = root && root.getAttribute ? (root.getAttribute("data-dava-paragraph-align") || "left") : "";
    var list = root && root.getAttribute ? (root.getAttribute("data-dava-list-style") || "") : "";
    [
      ["dava_para_left", align === "left"],
      ["dava_para_center", align === "center"],
      ["dava_para_right", align === "right"],
      ["dava_para_justify", align === "justify"],
      ["dava_para_distribute", align === "distribute"],
      ["dava_para_bullet", listFamily(list) === "bullet" && !!list],
      ["dava_para_number", listFamily(list) === "number" && !!list]
    ].forEach(function (entry) {
      var button = document.getElementById(entry[0]);
      if (button) button.classList.toggle("active", !!entry[1]);
    });
  }

  function createTextStyleButton(id, label, title) {
    var button = document.createElement("span");
    button.id = id;
    button.className = "dava-text-style-button";
    button.setAttribute("role", "button");
    button.setAttribute("tabindex", "-1");
    button.setAttribute("title", title);
    button.setAttribute("aria-label", title);
    button.innerHTML = label;
    return button;
  }

  function paragraphIcon(name) {
    var lines = {
      left: "<path d='M5 7h18M5 12h13M5 17h16'/>",
      center: "<path d='M7 7h14M5 12h18M8 17h12'/>",
      right: "<path d='M5 7h18M10 12h13M7 17h16'/>",
      justify: "<path d='M5 7h18M5 12h18M5 17h18'/>",
      distribute: "<path d='M5 7h18M8 12h12M5 17h18'/><path d='M4 4v16M24 4v16'/>",
      indentIn: "<path d='M5 7h18M12 12h11M12 17h11'/><path d='M5 13l4-3v6z'/>",
      indentOut: "<path d='M5 7h18M12 12h11M12 17h11'/><path d='M9 10l-4 3 4 3z'/>",
      line: "<path d='M12 7h11M12 12h11M12 17h11'/><path d='M6 5v14M3 8l3-3 3 3M3 16l3 3 3-3'/>",
      bullet: "<circle cx='6' cy='7' r='1.4'/><circle cx='6' cy='12' r='1.4'/><circle cx='6' cy='17' r='1.4'/><path d='M11 7h12M11 12h12M11 17h12'/>",
      number: "<text x='4' y='8' font-size='5' font-family='Arial'>1</text><text x='4' y='13' font-size='5' font-family='Arial'>2</text><text x='4' y='18' font-size='5' font-family='Arial'>3</text><path d='M11 7h12M11 12h12M11 17h12'/>"
    };
    return "<svg viewBox='0 0 28 24' aria-hidden='true'>" + (lines[name] || lines.left) + "</svg>";
  }

  function paragraphButton(id, icon, title, action, hasMenu) {
    var button = createTextStyleButton(id, paragraphIcon(icon) + (hasMenu ? "<span class='dava-menu-caret'></span>" : ""), title);
    if (hasMenu) button.classList.add("has-menu");
    button.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      action(event, button);
    });
    return button;
  }

  function closeParagraphMenus() {
    Array.prototype.forEach.call(document.querySelectorAll(".dava-paragraph-menu"), function (menu) {
      menu.parentNode && menu.parentNode.removeChild(menu);
    });
  }

  function showParagraphMenu(button, kind, items) {
    closeParagraphMenus();
    var menu = document.createElement("div");
    menu.className = "dava-paragraph-menu dava-paragraph-menu-" + kind;
    items.forEach(function (item) {
      var option = document.createElement("button");
      option.type = "button";
      option.className = "dava-paragraph-option";
      option.innerHTML = item.preview + "<span>" + item.label + "</span>";
      option.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        closeParagraphMenus();
        item.action();
      });
      menu.appendChild(option);
    });
    document.body.appendChild(menu);
    var rect = button.getBoundingClientRect();
    var left = Math.min(rect.left, window.innerWidth - menu.offsetWidth - 8);
    var top = Math.min(rect.bottom + 2, window.innerHeight - menu.offsetHeight - 8);
    menu.style.left = Math.max(8, Math.round(left)) + "px";
    menu.style.top = Math.max(8, Math.round(top)) + "px";
  }

  function bulletPreview(marker) {
    return "<span class='dava-list-preview'><b>" + marker + "</b><i></i><b>" + marker + "</b><i></i><b>" + marker + "</b><i></i></span>";
  }

  function numberPreview(values) {
    return "<span class='dava-list-preview numbered'><b>" + values[0] + "</b><i></i><b>" + values[1] + "</b><i></i><b>" + values[2] + "</b><i></i></span>";
  }

  function lineSpacingPreview(value) {
    return "<span class='dava-line-preview'><b>" + value + "</b><i></i><i></i><i></i></span>";
  }

  function syncTextInputFromMultilineRoot() {
    var input = document.getElementById("text");
    var canvas = getSvgCanvas();
    if (!isTextEditMode(canvas)) return;
    var root = selectedTextRoot(canvas);
    if (!input || !root) return;
    var value = root.getAttribute("data-dava-multiline-text");
    if (value !== null && input.value !== value) input.value = value;
  }

  function ensureMultilineTextInputBridge() {
    if (document.documentElement.getAttribute("data-dava-multiline-text-input") === "1") return;
    var input = document.getElementById("text");
    if (!input) return;
    var textarea = input;
    if (!/^textarea$/i.test(input.tagName || "")) {
      textarea = document.createElement("textarea");
      Array.prototype.forEach.call(input.attributes || [], function (attribute) {
        if (attribute.name !== "type") textarea.setAttribute(attribute.name, attribute.value);
      });
      textarea.id = "text";
      textarea.value = input.value || "";
      input.parentNode.replaceChild(textarea, input);
    }
    textarea.setAttribute("data-dava-multiline-input", "1");
    textarea.setAttribute("rows", "3");
    textarea.style.position = "absolute";
    textarea.style.left = "-10000px";
    textarea.style.top = "0";
    textarea.style.width = "2px";
    textarea.style.height = "2px";
    textarea.style.opacity = "0";
    textarea.style.pointerEvents = "none";
    document.documentElement.setAttribute("data-dava-multiline-text-input", "1");
    var canvas = getSvgCanvas();
    try {
      if (canvas && canvas.textActions && typeof canvas.textActions.setInputElem === "function") {
        canvas.textActions.setInputElem(textarea);
      }
    } catch (error) {}
    var updateText = function (event) {
      var target = event.currentTarget;
      var value = String(target.value || "");
      var canvasNow = getSvgCanvas();
      var root = selectedTextRoot(canvasNow);
      if (root && (value.indexOf("\n") !== -1 || root.getAttribute("data-dava-multiline-text") !== null)) {
        applyMultilineTextValue(value);
      } else if (canvasNow && typeof canvasNow.setTextContent === "function") {
        canvasNow.setTextContent(value);
      }
      scheduleTextCaretAdjust();
    };
    textarea.addEventListener("input", updateText, false);
    textarea.addEventListener("keyup", updateText, false);
    textarea.addEventListener("keydown", function (event) {
      if (event.key === "Enter") {
        event.stopPropagation();
        window.setTimeout(function () { updateText({ currentTarget: textarea }); }, 0);
      } else {
        scheduleTextCaretAdjust(0);
      }
    }, true);
    ["dblclick", "mouseup", "keyup", "click"].forEach(function (name) {
      document.addEventListener(name, function () {
        window.setTimeout(syncTextInputFromMultilineRoot, 0);
        scheduleTextCaretAdjust(0);
        scheduleTextCaretAdjust(30);
      }, true);
    });
    document.addEventListener("selectionchange", function () {
      scheduleTextCaretAdjust(0);
    }, true);
  }

  function ensureRichTextPointerEventBridge() {
    if (document.documentElement.getAttribute("data-dava-rich-text-pointer-bridge") === "1") return;
    document.documentElement.setAttribute("data-dava-rich-text-pointer-bridge", "1");
    document.addEventListener("dblclick", function (event) {
      var target = event.target;
      if (!target || !target.tagName || !/^tspan$/i.test(target.tagName)) return;
      var root = textRootForNode(target);
      var canvas = getSvgCanvas();
      if (!root || !canvas || !canvas.textActions || typeof canvas.textActions.select !== "function") return;
      if (canvas.getCurrentMode && canvas.getCurrentMode() === "textedit") return;
      try {
        event.preventDefault();
        event.stopImmediatePropagation();
        normalizeRichTextPointerEvents(root);
        var matrix = typeof canvas.getrootSctm === "function" ? canvas.getrootSctm() : null;
        var point = transformPointByMatrix(event.clientX, event.clientY, matrix);
        canvas.selectOnly && canvas.selectOnly([root]);
        canvas.textActions.select(root, point.x, point.y);
      } catch (error) {
        console.warn("[DAVA SVG-Edit text] Failed to enter rich text edit mode.", error);
      }
    }, true);
    document.addEventListener("mouseup", function (event) {
      var target = event.target;
      if (!target || !target.tagName || !/^tspan$/i.test(target.tagName)) return;
      var root = textRootForNode(target);
      var canvas = getSvgCanvas();
      if (!root || !canvas || !canvas.getCurrentMode || canvas.getCurrentMode() !== "textedit") return;
      if (!canvas.textActions || typeof canvas.textActions.mouseUp !== "function") return;
      try {
        event.preventDefault();
        event.stopImmediatePropagation();
        var clone = new MouseEvent(event.type, {
          bubbles: true,
          cancelable: true,
          view: window,
          screenX: event.screenX,
          screenY: event.screenY,
          clientX: event.clientX,
          clientY: event.clientY,
          ctrlKey: event.ctrlKey,
          shiftKey: event.shiftKey,
          altKey: event.altKey,
          metaKey: event.metaKey,
          button: event.button,
          buttons: event.buttons
        });
        root.dispatchEvent(clone);
      } catch (error) {
        console.warn("[DAVA SVG-Edit text] Failed to retarget rich text mouseup.", error);
      }
    }, true);
  }

  function readToolControlValue(control) {
    if (!control) return "";
    if (control.shadowRoot) {
      var inner = control.shadowRoot.querySelector("input,select");
      if (inner && inner.value !== undefined && inner.value !== "") return inner.value;
    }
    if (control.value !== undefined && control.value !== "") return control.value;
    return control.getAttribute && control.getAttribute("value") || "";
  }

  function ensureTextSizingControlBridge() {
    var bindings = [
      { id: "tool_font_family", attribute: "font-family" },
      { id: "font_size", attribute: "font-size" }
    ];
    bindings.forEach(function (binding) {
      var control = document.getElementById(binding.id);
      if (!control || control.getAttribute("data-dava-text-sizing-bound") === "1") return;
      control.setAttribute("data-dava-text-sizing-bound", "1");
      var normalize = function () {
        var value = readToolControlValue(control);
        window.setTimeout(function () {
          var canvas = getSvgCanvas();
          if (!value) {
            normalizeSelectedTextSizing(canvas);
            return;
          }
          normalizeSelectedTextSizing(canvas, binding.attribute, value);
          try { canvas && canvas.call && canvas.call("changed", selectedTextNodes(canvas)); } catch (error) {}
          relayoutSelectedAreaText(canvas);
          window.setTimeout(updateTextStyleToolState, 0);
        }, 0);
      };
      ["change", "input", "blur"].forEach(function (eventName) {
        control.addEventListener(eventName, normalize, false);
      });
    });
  }

  function ensureTextStyleTools() {
    var panel = document.querySelector(".text_panel");
    if (!panel) return false;
    ensureMultilineTextInputBridge();
    ensureVerticalTextCaretBridge();
    ensureRichTextPointerEventBridge();
    ensureImportedTextEditBridge();
    ensureTextSizingControlBridge();
    if (!document.getElementById("dava_text_style_tools_css")) {
      var style = document.createElement("style");
      style.id = "dava_text_style_tools_css";
      style.textContent = [
        "body.dava-vertical-text-cursor #workarea,body.dava-vertical-text-cursor #svgcanvas{cursor:default!important}",
        "text[data-dava-text-orientation='vertical']{text-orientation:upright}",
        "#dava_text_style_tools{display:inline-flex;align-items:center;gap:2px;margin-left:3px;vertical-align:middle}",
        "#dava_text_style_tools:before{content:'';display:inline-block;width:1px;height:21px;margin:0 3px;background:rgba(255,255,255,.28)}",
        "#dava_paragraph_tools{display:inline-flex;align-items:center;gap:2px;margin-left:4px;vertical-align:middle}",
        "#dava_paragraph_tools:before{content:'';display:inline-block;width:1px;height:21px;margin:0 3px;background:rgba(255,255,255,.28)}",
        ".dava-text-style-button{display:inline-flex;align-items:center;justify-content:center;width:25px;height:23px;border:1px solid rgba(255,255,255,.32);background:#60696c;color:#fff;border-radius:2px;padding:0;font:700 12px/1 Arial,sans-serif;cursor:pointer}",
        ".dava-text-style-button:hover{background:#707a7d}",
        ".dava-text-style-button.active{background:#1f7a8c;border-color:#4cc9e4}",
        ".dava-text-style-button[pressed]{background:#1f7a8c;border-color:#4cc9e4}",
        ".dava-text-style-button svg{width:21px;height:19px;stroke:#f5f7f8;fill:none;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}",
        ".dava-text-style-button svg text{fill:#f5f7f8;stroke:none;font-weight:700}",
        ".dava-text-style-button .dava-menu-caret{width:0;height:0;margin-left:2px;border-left:3px solid transparent;border-right:3px solid transparent;border-top:4px solid #f5f7f8}",
        ".dava-text-style-button .script-base{display:inline-block;font-size:13px;line-height:1}",
        ".dava-text-style-button .script-mark{display:inline-block;position:relative;font-size:8px;line-height:1}",
        ".dava-text-style-button .script-mark.super{top:-6px;margin-left:1px}",
        ".dava-text-style-button .script-mark.sub{top:6px;margin-left:1px}",
        ".dava-text-style-button.wide{width:38px;font-size:11px}",
        ".dava-text-style-button.has-menu{width:32px}",
        ".dava-text-style-button img{display:none!important}",
        ".dava-paragraph-menu{position:fixed;z-index:1000002;display:grid;gap:4px;padding:8px;background:#f7f7f7;border:1px solid #9da3a8;box-shadow:0 8px 24px rgba(0,0,0,.28);font:12px Arial,'Microsoft YaHei',sans-serif;color:#111}",
        ".dava-paragraph-menu-bullet,.dava-paragraph-menu-number{grid-template-columns:repeat(3,92px);min-width:292px}",
        ".dava-paragraph-menu-line{grid-template-columns:1fr;min-width:140px}",
        ".dava-paragraph-option{border:1px solid transparent;background:#fff;color:#111;min-height:44px;padding:6px;display:flex;align-items:center;gap:8px;text-align:left;cursor:pointer}",
        ".dava-paragraph-option:hover{border-color:#71a8d6;background:#e9f3ff}",
        ".dava-list-preview{display:grid;grid-template-columns:15px 42px;gap:3px;align-items:center;min-width:62px}",
        ".dava-list-preview b{font-style:normal;font-size:13px;text-align:center;line-height:1;color:#111}",
        ".dava-list-preview i,.dava-line-preview i{display:block;height:1px;background:#555}",
        ".dava-line-preview{display:grid;grid-template-columns:28px 54px;gap:4px;align-items:center;min-width:82px}",
        ".dava-line-preview b{font-weight:400;text-align:center;color:#111}"
      ].join("\n");
      document.head.appendChild(style);
    }
    if (document.documentElement.getAttribute("data-dava-paragraph-menu-close") !== "1") {
      document.documentElement.setAttribute("data-dava-paragraph-menu-close", "1");
      document.addEventListener("click", function (event) {
        if (event.target && event.target.closest && event.target.closest(".dava-paragraph-menu,.dava-text-style-button")) return;
        closeParagraphMenus();
      }, true);
      document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") closeParagraphMenus();
      }, true);
    }
    if (!document.getElementById("dava_text_style_tools")) {
      var group = document.createElement("span");
      group.id = "dava_text_style_tools";
      group.appendChild(createTextStyleButton("dava_text_horizontal", "H", "Horizontal text"));
      group.appendChild(createTextStyleButton("dava_text_vertical", "V", "Vertical text"));
      group.appendChild(createTextStyleButton("dava_text_superscript", "<span class=\"script-base\">x</span><span class=\"script-mark super\">2</span>", "Superscript"));
      group.appendChild(createTextStyleButton("dava_text_subscript", "<span class=\"script-base\">x</span><span class=\"script-mark sub\">2</span>", "Subscript"));

      var anchor = document.getElementById("tool_text_decoration_overline") ||
        document.getElementById("tool_font_family") ||
        panel.firstElementChild;
      if (anchor && anchor.parentNode === panel && anchor.nextSibling) {
        panel.insertBefore(group, anchor.nextSibling);
      } else {
        panel.appendChild(group);
      }

      document.getElementById("dava_text_horizontal").addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        setTextOrientation("horizontal");
      });
      document.getElementById("dava_text_vertical").addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        setTextOrientation("vertical");
      });
      document.getElementById("dava_text_superscript").addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        setTextScript("super");
      });
      document.getElementById("dava_text_subscript").addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        setTextScript("sub");
      });
    }
    if (!document.getElementById("dava_paragraph_tools")) {
      var paragraph = document.createElement("span");
      paragraph.id = "dava_paragraph_tools";
      paragraph.appendChild(paragraphButton("dava_para_bullet", "bullet", "Bullets", function (event, button) {
        showParagraphMenu(button, "bullet", [
          { label: "None", preview: "<span class='dava-list-preview'><b></b><i></i><b></b><i></i><b></b><i></i></span>", action: clearParagraphListStyle },
          { label: "Bullets", preview: bulletPreview("\u2022"), action: function () { setParagraphListStyle("bullet"); } },
          { label: "Squares", preview: bulletPreview("\u25aa"), action: function () { setParagraphListStyle("bullet-square"); } },
          { label: "Diamonds", preview: bulletPreview("\u25c6"), action: function () { setParagraphListStyle("bullet-diamond"); } },
          { label: "Hollow", preview: bulletPreview("\u25e6"), action: function () { setParagraphListStyle("bullet-circle"); } },
          { label: "Dash", preview: bulletPreview("-"), action: function () { setParagraphListStyle("bullet-dash"); } }
        ]);
      }, true));
      paragraph.appendChild(paragraphButton("dava_para_number", "number", "Numbering", function (event, button) {
        showParagraphMenu(button, "number", [
          { label: "None", preview: "<span class='dava-list-preview'><b></b><i></i><b></b><i></i><b></b><i></i></span>", action: clearParagraphListStyle },
          { label: "1. 2. 3.", preview: numberPreview(["1.", "2.", "3."]), action: function () { setParagraphListStyle("number"); } },
          { label: "1) 2) 3)", preview: numberPreview(["1)", "2)", "3)"]), action: function () { setParagraphListStyle("number-paren"); } },
          { label: "A. B. C.", preview: numberPreview(["A.", "B.", "C."]), action: function () { setParagraphListStyle("number-alpha"); } },
          { label: "a. b. c.", preview: numberPreview(["a.", "b.", "c."]), action: function () { setParagraphListStyle("number-lower"); } },
          { label: "I. II. III.", preview: numberPreview(["I.", "II.", "III."]), action: function () { setParagraphListStyle("number-roman"); } },
          { label: "(1) (2) (3)", preview: numberPreview(["(1)", "(2)", "(3)"]), action: function () { setParagraphListStyle("number-circle"); } }
        ]);
      }, true));
      paragraph.appendChild(paragraphButton("dava_para_outdent", "indentOut", "Decrease indent", function () { adjustParagraphIndent(-18); }));
      paragraph.appendChild(paragraphButton("dava_para_indent", "indentIn", "Increase indent", function () { adjustParagraphIndent(18); }));
      paragraph.appendChild(paragraphButton("dava_para_line", "line", "Line spacing", function (event, button) {
        showParagraphMenu(button, "line", [
          { label: "1.0", preview: lineSpacingPreview("1.0"), action: function () { setParagraphLineSpacing("1"); } },
          { label: "1.15", preview: lineSpacingPreview("1.15"), action: function () { setParagraphLineSpacing("1.15"); } },
          { label: "1.5", preview: lineSpacingPreview("1.5"), action: function () { setParagraphLineSpacing("1.5"); } },
          { label: "2.0", preview: lineSpacingPreview("2.0"), action: function () { setParagraphLineSpacing("2"); } },
          { label: "2.5", preview: lineSpacingPreview("2.5"), action: function () { setParagraphLineSpacing("2.5"); } },
          { label: "3.0", preview: lineSpacingPreview("3.0"), action: function () { setParagraphLineSpacing("3"); } }
        ]);
      }, true));
      paragraph.appendChild(paragraphButton("dava_para_left", "left", "Align left", function () { setParagraphAlignment("left"); }));
      paragraph.appendChild(paragraphButton("dava_para_center", "center", "Align center", function () { setParagraphAlignment("center"); }));
      paragraph.appendChild(paragraphButton("dava_para_right", "right", "Align right", function () { setParagraphAlignment("right"); }));
      paragraph.appendChild(paragraphButton("dava_para_justify", "justify", "Justify", function () { setParagraphAlignment("justify"); }));
      paragraph.appendChild(paragraphButton("dava_para_distribute", "distribute", "Distributed", function () { setParagraphAlignment("distribute"); }));
      var paragraphAnchor = document.getElementById("tool_length_adjust") ||
        document.getElementById("dava_text_style_tools") ||
        panel.lastElementChild;
      if (paragraphAnchor && paragraphAnchor.parentNode === panel && paragraphAnchor.nextSibling) {
        panel.insertBefore(paragraph, paragraphAnchor.nextSibling);
      } else {
        panel.appendChild(paragraph);
      }
    }
    updateTextStyleToolState();
    return true;
  }

  function refreshFontDropdown() {
    return appendFontsToControl(getFonts());
  }

  function setDefaultStrokeForNewShapes() {
    var canvas = getSvgCanvas();
    if (!canvas) return false;
    var hasSelection = selectedElements(canvas).length > 0;
    try {
      if (window.svgEditor &&
          window.svgEditor.configObj &&
          window.svgEditor.configObj.curConfig &&
          window.svgEditor.configObj.curConfig.initStroke) {
        window.svgEditor.configObj.curConfig.initStroke.color = "000000";
        window.svgEditor.configObj.curConfig.initStroke.width = 0.5;
        window.svgEditor.configObj.curConfig.initStroke.opacity = 1;
      }
      if (typeof canvas.setCurShape === "function") {
        canvas.setCurShape("stroke", "#000000");
        canvas.setCurShape("stroke_width", 0.5);
        canvas.setCurShape("stroke_dasharray", "none");
        canvas.setCurShape("stroke_linecap", "butt");
      }
      if (!hasSelection) {
        if (typeof canvas.setStrokeWidth === "function") canvas.setStrokeWidth(0.5);
        if (typeof canvas.setColor === "function") canvas.setColor("stroke", "#000000");
        if (typeof canvas.setStrokeAttr === "function") {
          canvas.setStrokeAttr("stroke-dasharray", "none");
          canvas.setStrokeAttr("stroke-linecap", "butt");
        }
      }
    } catch (error) {
      console.warn("[DAVA SVG-Edit bridge] Could not set default stroke style.", error);
      return false;
    }
    if (hasSelection) return true;
    var strokeWidth = document.getElementById("stroke_width");
    if (strokeWidth) {
      strokeWidth.value = 0.5;
      strokeWidth.setAttribute("value", "0.5");
    }
    var strokeStyle = document.getElementById("stroke_style");
    if (strokeStyle) {
      strokeStyle.value = "none";
      strokeStyle.setAttribute("value", "none");
    }
    var strokeColor = document.getElementById("stroke_color");
    if (strokeColor && typeof strokeColor.setPaint === "function") {
      try {
        strokeColor.setPaint({ type: "solidColor", alpha: 100, solidColor: "000000" });
      } catch (error) {}
    }
    return true;
  }

  function isShapeDrawMode(mode) {
    return [
      "line",
      "rect",
      "square",
      "fhrect",
      "circle",
      "ellipse",
      "fhellipse",
      "star",
      "polygon",
      "path",
      "fhpath",
      "shapelib"
    ].indexOf(mode) !== -1;
  }

  function bindDefaultStrokeForShapeTools() {
    if (defaultStrokeToolBindingBound) return;
    defaultStrokeToolBindingBound = true;
    var fixInsertedShapeStroke = function (elements) {
      if (!elements || !elements.length) return;
      Array.prototype.forEach.call(elements, function (element) {
        if (!isStrokeStyleElement(element)) return;
        if (!/^svg_\d+$/.test(element.id || "")) return;
        var stroke = element.getAttribute("stroke");
        var width = element.getAttribute("stroke-width");
        if (!stroke || stroke === "none") {
          element.setAttribute("stroke", "#000000");
          if (element.style) element.style.setProperty("stroke", "#000000");
        }
        if (!width || String(width).toLowerCase() === "null" || Number(width) === 0) {
          element.setAttribute("stroke-width", "0.5");
          if (element.style) element.style.setProperty("stroke-width", "0.5");
        }
        if (!element.getAttribute("stroke-dasharray")) element.setAttribute("stroke-dasharray", "none");
      });
    };
    document.addEventListener("modeChange", function (event) {
      var mode = "";
      try {
        mode = event && event.detail && typeof event.detail.getMode === "function" ?
          event.detail.getMode() :
          "";
      } catch (error) {
        mode = "";
      }
      if (isShapeDrawMode(mode)) window.setTimeout(setDefaultStrokeForNewShapes, 0);
    }, false);
    var canvas = getSvgCanvas();
    if (canvas && typeof canvas.bind === "function") {
      try {
        canvas.bind("changed", fixInsertedShapeStroke);
      } catch (error) {
        console.warn("[DAVA SVG-Edit bridge] Could not bind default stroke fixer.", error);
      }
    }
  }

  var strokeStyleTags = ["line", "polyline", "path", "rect", "circle", "ellipse", "polygon"];
  var strokeStyleOptions = [
    { label: "No line", value: "none", preview: "", noLine: true },
    { label: "Solid", value: "none", preview: "" },
    { label: "Dotted", value: "2,2", preview: "2 4" },
    { label: "Dashed", value: "5,5", preview: "8 5" },
    { label: "Dash dot", value: "18 6 1.8 6", preview: "18 6 1.8 6", round: true },
    { label: "Dash dot dot", value: "18 6 1.8 6 1.8 6", preview: "18 6 1.8 6 1.8 6", round: true },
    { label: "Long dash", value: "10,4", preview: "14 6" },
    { label: "Long dash dot", value: "16,5,1.6,5", preview: "16 5 1.6 5", round: true },
    { label: "Round dots", value: "1,4", preview: "1 6", round: true },
    { label: "Long dash dot dot", value: "16,5,1.6,5,1.6,5", preview: "16 5 1.6 5 1.6 5", round: true }
  ];

  function strokeStyleTopIcon() {
    return [
      "<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\">",
      "<line x1=\"4\" y1=\"6\" x2=\"20\" y2=\"6\" stroke-dasharray=\"5 3\"></line>",
      "<line x1=\"4\" y1=\"12\" x2=\"20\" y2=\"12\" stroke-dasharray=\"2 3\"></line>",
      "<line x1=\"4\" y1=\"18\" x2=\"20\" y2=\"18\" stroke-dasharray=\"8 3\"></line>",
      "</svg>"
    ].join("");
  }

  function strokeStylePreview(option) {
    if (option.noLine) {
      return [
        "<svg viewBox=\"0 0 88 22\" aria-hidden=\"true\" class=\"dava-stroke-preview-svg\">",
        "<rect x=\"9\" y=\"4\" width=\"18\" height=\"14\" fill=\"none\" stroke=\"#111\" stroke-width=\"1.5\"></rect>",
        "<line x1=\"9\" y1=\"18\" x2=\"27\" y2=\"4\" stroke=\"#d0342c\" stroke-width=\"2\"></line>",
        "</svg>"
      ].join("");
    }
    return [
      "<svg viewBox=\"0 0 88 22\" aria-hidden=\"true\" class=\"dava-stroke-preview-svg\">",
      "<line x1=\"8\" y1=\"11\" x2=\"80\" y2=\"11\" stroke=\"#26384a\" stroke-width=\"2.4\"",
      option.preview ? " stroke-dasharray=\"" + option.preview + "\"" : "",
      option.round ? " stroke-linecap=\"round\"" : " stroke-linecap=\"butt\"",
      "></line>",
      "</svg>"
    ].join("");
  }

  function closeStrokeStyleMenu() {
    var menu = document.getElementById("dava_stroke_style_menu");
    if (menu && menu.parentNode) menu.parentNode.removeChild(menu);
  }

  function isStrokeStyleElement(element) {
    var tag = element && (element.tagName || element.nodeName);
    return !!(tag && strokeStyleTags.indexOf(String(tag).toLowerCase()) !== -1);
  }

  function collectStrokeStyleElements(element, collected, seen) {
    if (!element || seen.indexOf(element) !== -1) return;
    seen.push(element);
    if (isStrokeStyleElement(element)) {
      collected.push(element);
      return;
    }
    if (!element.querySelectorAll) return;
    Array.prototype.forEach.call(element.querySelectorAll(strokeStyleTags.join(",")), function (child) {
      if (seen.indexOf(child) === -1) {
        seen.push(child);
        collected.push(child);
      }
    });
  }

  function selectedStrokeStyleElements(canvas) {
    var collected = [];
    var seen = [];
    selectedElements(canvas).forEach(function (element) {
      collectStrokeStyleElements(element, collected, seen);
    });
    return collected;
  }

  function changeSelectedStrokeAttribute(canvas, attr, value, selected) {
    selected = selected || selectedStrokeStyleElements(canvas);
    if (!selected.length) return;
    if (canvas && typeof canvas.changeSelectedAttribute === "function") {
      canvas.changeSelectedAttribute(attr, value, selected);
      return;
    }
    selected.forEach(function (element) {
      if (value === null || value === undefined || value === "") {
        element.removeAttribute(attr);
      } else {
        element.setAttribute(attr, value);
      }
    });
    if (canvas && typeof canvas.call === "function") canvas.call("changed", selected);
  }

  function syncStrokeStyleInline(selected, option) {
    selected.forEach(function (element) {
      if (!element || !element.style) return;
      if (option.noLine) {
        element.style.setProperty("stroke", "none");
        element.style.setProperty("stroke-width", "0");
        element.style.setProperty("stroke-dasharray", "none");
        return;
      }
      element.style.setProperty("stroke-dasharray", option.value);
      element.style.setProperty("stroke-linecap", option.round ? "round" : "butt");
    });
  }

  function dispatchSvgEditControlValue(control, value) {
    if (!control) return;
    control.value = value;
    control.setAttribute("value", value);
    control.dispatchEvent(new CustomEvent("change", {
      bubbles: true,
      detail: { value: value }
    }));
  }

  function rememberStrokeBeforeNone(element) {
    if (!element) return;
    var value = {
      stroke: element.getAttribute("stroke") || "",
      width: element.getAttribute("stroke-width") || ""
    };
    if (strokeStyleBeforeNone) {
      if (!strokeStyleBeforeNone.has(element)) strokeStyleBeforeNone.set(element, value);
    } else if (!element.__davaStrokeStyleBeforeNone) {
      element.__davaStrokeStyleBeforeNone = value;
    }
  }

  function restoreStrokeBeforeNone(element) {
    if (!element) return { stroke: "#000000", width: "1" };
    var value = strokeStyleBeforeNone ?
      strokeStyleBeforeNone.get(element) :
      element.__davaStrokeStyleBeforeNone;
    return {
      stroke: value && value.stroke ? value.stroke : "#000000",
      width: value && value.width ? value.width : "1"
    };
  }

  function applyStrokeStyleOption(nativeControl, option) {
    var canvas = getSvgCanvas();
    var selected = selectedStrokeStyleElements(canvas);
    if (!selected.length) {
      closeStrokeStyleMenu();
      updateStrokeStyleTopVisibility();
      return;
    }
    if (option.noLine) {
      selected.forEach(rememberStrokeBeforeNone);
      changeSelectedStrokeAttribute(canvas, "stroke-dasharray", "none", selected);
      changeSelectedStrokeAttribute(canvas, "stroke-width", "0", selected);
      changeSelectedStrokeAttribute(canvas, "stroke", "none", selected);
      syncStrokeStyleInline(selected, option);
      dispatchSvgEditControlValue(nativeControl, "none");
      var strokeWidth = document.getElementById("stroke_width");
      if (strokeWidth) {
        strokeWidth.value = 0;
        strokeWidth.setAttribute("value", "0");
      }
    } else {
      selected.forEach(function (element) {
        var stroke = element.getAttribute("stroke");
        var width = element.getAttribute("stroke-width");
        var styledStroke = element.style ? element.style.getPropertyValue("stroke") : "";
        var styledWidth = element.style ? element.style.getPropertyValue("stroke-width") : "";
        var previous = restoreStrokeBeforeNone(element);
        if (!stroke || stroke === "none" || styledStroke === "none") {
          changeSelectedStrokeAttribute(canvas, "stroke", previous.stroke, [element]);
          if (element.style) element.style.setProperty("stroke", previous.stroke);
        }
        if (!width || Number(width) === 0 || Number(styledWidth) === 0) {
          changeSelectedStrokeAttribute(canvas, "stroke-width", previous.width, [element]);
          if (element.style) element.style.setProperty("stroke-width", previous.width);
        }
      });
      if (option.round) {
        changeSelectedStrokeAttribute(canvas, "stroke-linecap", "round", selected);
      } else {
        changeSelectedStrokeAttribute(canvas, "stroke-linecap", "butt", selected);
      }
      changeSelectedStrokeAttribute(canvas, "stroke-dasharray", option.value, selected);
      syncStrokeStyleInline(selected, option);
      nativeControl.value = option.value;
      nativeControl.setAttribute("value", option.value);
    }
    closeStrokeStyleMenu();
  }

  function updateStrokeStyleTopVisibility() {
    var wrapper = document.getElementById("dava_stroke_style_top");
    if (!wrapper) return;
    var visible = false;
    try {
      visible = selectedStrokeStyleElements(getSvgCanvas()).length > 0;
    } catch (error) {
      visible = false;
    }
    wrapper.style.display = visible ? "inline-flex" : "none";
    if (!visible) closeStrokeStyleMenu();
  }

  function bindStrokeStyleVisibilityTracking() {
    if (strokeStyleVisibilityBound) return;
    strokeStyleVisibilityBound = true;
    var delayedUpdate = function () {
      window.setTimeout(updateStrokeStyleTopVisibility, 0);
    };
    document.addEventListener("mouseup", delayedUpdate, false);
    document.addEventListener("keyup", delayedUpdate, false);
    window.setInterval(delayedUpdate, 300);
  }

  function restoreNativeStrokeStyleControl(nativeControl) {
    var bottom = document.getElementById("tools_bottom");
    if (!nativeControl || !bottom || nativeControl.parentNode === bottom) return;
    var lineJoin = document.getElementById("stroke_linejoin");
    if (lineJoin && lineJoin.parentNode === bottom) {
      bottom.insertBefore(nativeControl, lineJoin);
    } else {
      bottom.appendChild(nativeControl);
    }
  }

  function showStrokeStyleMenu(trigger, nativeControl) {
    closeStrokeStyleMenu();
    var menu = document.createElement("div");
    menu.id = "dava_stroke_style_menu";
    menu.setAttribute("role", "menu");
    strokeStyleOptions.forEach(function (option) {
      var item = document.createElement("button");
      item.type = "button";
      item.className = "dava-stroke-style-item";
      item.innerHTML = strokeStylePreview(option) + "<span>" + option.label + "</span>";
      item.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        applyStrokeStyleOption(nativeControl, option);
      });
      menu.appendChild(item);
    });
    document.body.appendChild(menu);
    var rect = trigger.getBoundingClientRect();
    var width = 360;
    var left = Math.min(Math.max(8, rect.left), Math.max(8, window.innerWidth - width - 8));
    menu.style.left = left + "px";
    menu.style.top = (rect.bottom + 4) + "px";
    var onPointer = function (event) {
      if (!menu.contains(event.target) && event.target !== trigger) {
        closeStrokeStyleMenu();
        document.removeEventListener("mousedown", onPointer, true);
      }
    };
    window.setTimeout(function () {
      document.addEventListener("mousedown", onPointer, true);
    }, 0);
  }

  function ensureStrokeStyleTopControl() {
    var nativeControl = document.getElementById("stroke_style");
    var toolsTop = document.getElementById("tools_top");
    if (!nativeControl || !toolsTop) {
      window.setTimeout(ensureStrokeStyleTopControl, 100);
      return false;
    }
    restoreNativeStrokeStyleControl(nativeControl);
    if (!document.getElementById("dava_stroke_style_top_css")) {
      var style = document.createElement("style");
      style.id = "dava_stroke_style_top_css";
      style.textContent = [
        "#dava_stroke_style_top{display:none;align-items:center;margin-left:4px;vertical-align:middle;position:relative;top:10px}",
        "#dava_stroke_style_top .dava-stroke-style-trigger{display:inline-flex;align-items:center;justify-content:center;width:26px;height:22px;padding:0;border:1px solid rgba(255,255,255,.28);background:#60696c;border-radius:2px;cursor:pointer}",
        "#dava_stroke_style_top .dava-stroke-style-trigger:hover{background:#6f787b}",
        "#dava_stroke_style_top .dava-stroke-style-trigger svg{width:18px;height:18px;stroke:#f5f7f8;fill:none;stroke-width:2;stroke-linecap:round}",
        "#tools_bottom #stroke_style{display:none!important}",
        "#dava_stroke_style_menu{position:fixed;z-index:1000005;width:360px;display:grid;grid-template-columns:1fr 1fr;background:#f7f7f7;border:1px solid #d7d7d7;box-shadow:0 12px 28px rgba(0,0,0,.24);font:12px Arial,'Microsoft YaHei',sans-serif}",
        "#dava_stroke_style_menu .dava-stroke-style-item{display:grid;grid-template-columns:96px 1fr;align-items:center;height:38px;padding:0 8px;border:0;border-right:1px solid #ececec;border-bottom:1px solid #ececec;background:#fff;color:#111;text-align:left;cursor:pointer}",
        "#dava_stroke_style_menu .dava-stroke-style-item:nth-child(2n){border-right:0}",
        "#dava_stroke_style_menu .dava-stroke-style-item:hover{background:#eef4ff}",
        "#dava_stroke_style_menu .dava-stroke-style-item span{justify-self:end;line-height:13px;text-align:right}",
        "#dava_stroke_style_menu .dava-stroke-preview-svg{width:88px;height:22px;display:block}"
      ].join("\n");
      document.head.appendChild(style);
    }
    var wrapper = document.getElementById("dava_stroke_style_top");
    if (!wrapper) {
      wrapper = document.createElement("span");
      wrapper.id = "dava_stroke_style_top";
      wrapper.innerHTML = "<button type=\"button\" id=\"dava_stroke_style_trigger\" class=\"dava-stroke-style-trigger\" title=\"Line style\">" + strokeStyleTopIcon() + "</button>";
      var anchor = document.querySelector(".xy_panel") ||
        document.getElementById("angle") ||
        document.getElementById("blur") ||
        document.getElementById("history_panel");
      if (anchor && anchor.parentNode === toolsTop) {
        toolsTop.insertBefore(wrapper, anchor);
      } else {
        toolsTop.appendChild(wrapper);
      }
    }
    if (!document.getElementById("dava_stroke_style_trigger")) {
      wrapper.innerHTML = "<button type=\"button\" id=\"dava_stroke_style_trigger\" class=\"dava-stroke-style-trigger\" title=\"Line style\">" + strokeStyleTopIcon() + "</button>";
    }
    nativeControl.setAttribute("title", "Line style");
    var trigger = document.getElementById("dava_stroke_style_trigger");
    if (trigger && !trigger.dataset.davaStrokeBound) {
      trigger.dataset.davaStrokeBound = "1";
      trigger.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        showStrokeStyleMenu(trigger, nativeControl);
      });
    }
    bindStrokeStyleVisibilityTracking();
    updateStrokeStyleTopVisibility();
    return true;
  }

  function relayoutSelectedAreaText(canvas) {
    if (!window.DAVA_SVGEDIT_TEXTBOX_API ||
        typeof window.DAVA_SVGEDIT_TEXTBOX_API.findAreaTextRoot !== "function" ||
        typeof window.DAVA_SVGEDIT_TEXTBOX_API.layoutAreaText !== "function") {
      return;
    }
    var roots = [];
    selectedElements(canvas).forEach(function (element) {
      var root = window.DAVA_SVGEDIT_TEXTBOX_API.findAreaTextRoot(element);
      if (root && roots.indexOf(root) === -1) roots.push(root);
      if (element && element.querySelectorAll) {
        Array.prototype.forEach.call(element.querySelectorAll("[data-dava-textbox='1']"), function (child) {
          if (roots.indexOf(child) === -1) roots.push(child);
        });
      }
    });
    roots.forEach(function (root) {
      window.DAVA_SVGEDIT_TEXTBOX_API.layoutAreaText(root);
    });
  }

  function getSvgCanvas() {
    var candidates = [
      window.svgCanvas,
      window.svgEditor && window.svgEditor.svgCanvas,
      window.svgEditor && window.svgEditor.canvas,
      window.svgEditor && window.svgEditor.svgCanvas_,
      window.editor && window.editor.svgCanvas,
      window.editor && window.editor.canvas,
      window.svgEditor && typeof window.svgEditor.ready === "function" && window.svgEditor.svgCanvas
    ];
    for (var i = 0; i < candidates.length; i += 1) {
      if (candidates[i]) return candidates[i];
    }
    return null;
  }

  function waitForSvgCanvas(callback, attempts) {
    attempts = attempts || 0;
    var canvas = getSvgCanvas();
    if (canvas) {
      callback(canvas);
      return;
    }
    if (attempts > 120) {
      reportError(new Error("SVG-Edit canvas API was not found."));
      return;
    }
    window.setTimeout(function () {
      waitForSvgCanvas(callback, attempts + 1);
    }, 100);
  }

  function findSvgRoot() {
    var selectors = [
      "#svgcontent > svg",
      "#svgcontent svg",
      "#svgcanvas",
      "svg#svgcanvas",
      "svg"
    ];
    for (var i = 0; i < selectors.length; i += 1) {
      var node = document.querySelector(selectors[i]);
      if (node && node.tagName && node.tagName.toLowerCase() === "svg") return node;
    }
    return null;
  }

  function callFirst(target, methodNames, args) {
    if (!target) return undefined;
    for (var i = 0; i < methodNames.length; i += 1) {
      var name = methodNames[i];
      if (typeof target[name] === "function") {
        return target[name].apply(target, args || []);
      }
    }
    return undefined;
  }

  function assertSvgText(svgText, messageType) {
    if (typeof svgText !== "string" || !/<svg[\s>]/i.test(svgText)) {
      throw new Error((messageType || "SVG message") + " received invalid SVG text.");
    }
    if (/<script[\s>]/i.test(svgText)) {
      throw new Error("SVG with script tags is not accepted by the DAVA bridge.");
    }
  }

  function numericSvgLength(value, fallback) {
    var number = parseFloat(String(value || "").replace(/[^0-9.+-]/g, ""));
    return Number.isFinite(number) && number > 0 ? number : fallback;
  }

  function getCanvasContentSize(canvas, content) {
    var viewBox = (content && content.getAttribute("viewBox") || "").trim().split(/[\s,]+/).map(Number);
    var viewBoxWidth = viewBox.length === 4 && Number.isFinite(viewBox[2]) && viewBox[2] > 0 ? viewBox[2] : null;
    var viewBoxHeight = viewBox.length === 4 && Number.isFinite(viewBox[3]) && viewBox[3] > 0 ? viewBox[3] : null;
    var width = canvas && typeof canvas.getContentW === "function" ? canvas.getContentW() : null;
    var height = canvas && typeof canvas.getContentH === "function" ? canvas.getContentH() : null;
    width = Number.isFinite(width) && width > 0 ? width : viewBoxWidth;
    height = Number.isFinite(height) && height > 0 ? height : viewBoxHeight;
    width = numericSvgLength(content && content.getAttribute("width"), width || 1024);
    height = numericSvgLength(content && content.getAttribute("height"), height || 768);
    return { width: width, height: height };
  }

  function topLevelDrawableNodes(content) {
    if (!content || !content.children) return [];
    var ignored = {
      defs: true,
      title: true,
      desc: true,
      metadata: true,
      style: true,
      script: true
    };
    return Array.prototype.filter.call(content.children, function (node) {
      var tag = (node.tagName || "").toLowerCase();
      return !ignored[tag] && node.id !== "selectorParentGroup" && node.id !== "canvasBackground";
    });
  }

  function matrixToTransformValue(matrix) {
    return "matrix(" + [matrix.a, matrix.b, matrix.c, matrix.d, matrix.e, matrix.f].join(" ") + ")";
  }

  function createSvgGroup(content) {
    var doc = content && (content.ownerDocument || document);
    return doc.createElementNS("http://www.w3.org/2000/svg", "g");
  }

  function wrapDrawableNodes(content, nodes) {
    if (!content || !nodes || !nodes.length) return null;
    var wrapper = createSvgGroup(content);
    wrapper.setAttribute("id", "dava_loaded_svg_content");
    wrapper.setAttribute("data-dava-loaded-svg-wrapper", "1");
    content.insertBefore(wrapper, nodes[0]);
    nodes.forEach(function (node) {
      wrapper.appendChild(node);
    });
    return wrapper;
  }

  function applyTransformMatrix(node, matrix) {
    if (!node || !matrix) return;
    node.setAttribute("transform", matrixToTransformValue(matrix));
  }

  function makeBridgeObjectId(prefix) {
    return (prefix || "dava-svg") + "-" + Date.now().toString(36) + "-" + Math.floor(Math.random() * 100000).toString(36);
  }

  function uniqueElementId(preferredId, element) {
    var baseId = preferredId || makeBridgeObjectId("dava-svg");
    var candidate = baseId;
    var index = 1;
    while (document.getElementById(candidate) && document.getElementById(candidate) !== element) {
      candidate = baseId + "-" + index;
      index += 1;
    }
    return candidate;
  }

  function elementBBox(element) {
    if (!element || typeof element.getBBox !== "function") return null;
    try {
      var bbox = element.getBBox();
      if (bbox && Number.isFinite(bbox.x) && Number.isFinite(bbox.y) &&
          Number.isFinite(bbox.width) && Number.isFinite(bbox.height) &&
          bbox.width > 0 && bbox.height > 0) {
        return bbox;
      }
    } catch (error) {
      console.warn("[DAVA SVG-Edit bridge] Element bounds could not be measured.", error);
    }
    return null;
  }

  function selectCanvasElement(canvas, element) {
    if (!canvas || !element) return;
    if (typeof canvas.clearSelection === "function") canvas.clearSelection(true);
    if (typeof canvas.selectOnly === "function") {
      canvas.selectOnly([element], true);
    } else if (typeof canvas.addToSelection === "function") {
      canvas.addToSelection([element], true);
    }
    refreshSelectedElementBox(canvas, element);
  }

  function markGroupAsSvgEditNativeBBox(canvas, element) {
    if (!canvas || !element || (element.tagName || "").toLowerCase() !== "g") return;
    element.setAttribute("data-dava-selector-native-bbox", "1");
  }

  function placeElementInsideCanvas(canvas, element, options) {
    options = options || {};
    if (!canvas || !element || typeof canvas.getSvgContent !== "function") return false;
    var content = canvas.getSvgContent();
    var bbox = elementBBox(element);
    if (!bbox) return false;

    var size = getCanvasContentSize(canvas, content);
    var padding = Math.max(12, Math.min(size.width, size.height) * 0.03);
    var usableWidth = Math.max(1, size.width - padding * 2);
    var usableHeight = Math.max(1, size.height - padding * 2);
    var scale = options.preserveSize ? 1 : Math.min(1, usableWidth / bbox.width, usableHeight / bbox.height);

    selectCanvasElement(canvas, element);
    if (scale < 1) {
      var existingTransform = element.getAttribute("transform") || "";
      var scalePrefix = "translate(" + bbox.x + " " + bbox.y + ") scale(" + scale + ") translate(" + (-bbox.x) + " " + (-bbox.y) + ")";
      element.setAttribute("transform", scalePrefix + (existingTransform ? " " + existingTransform : ""));
      if (canvas.call) canvas.call("changed", [element]);
      bbox = elementBBox(element) || bbox;
      selectCanvasElement(canvas, element);
    }

    var targetX = Math.max(padding, (size.width - bbox.width) / 2);
    var targetY = Math.max(padding, (size.height - bbox.height) / 2);
    if (!options.center) {
      targetX = Math.max(padding, Math.min(bbox.x, size.width - bbox.width - padding));
      targetY = Math.max(padding, Math.min(bbox.y, size.height - bbox.height - padding));
    }
    var dx = targetX - bbox.x;
    var dy = targetY - bbox.y;
    if (Math.abs(dx) < 0.01 && Math.abs(dy) < 0.01) {
      refreshSelectedElementBox(canvas, element);
      return false;
    }
    var zoom = typeof canvas.getZoom === "function" ? canvas.getZoom() : 1;
    if (!Number.isFinite(zoom) || zoom <= 0) zoom = 1;
    if (typeof canvas.moveSelectedElements === "function") {
      canvas.moveSelectedElements(dx * zoom, dy * zoom, false);
    } else {
      var transform = element.getAttribute("transform") || "";
      element.setAttribute("transform", "translate(" + dx + " " + dy + ")" + (transform ? " " + transform : ""));
      if (canvas.call) canvas.call("changed", [element]);
    }
    refreshSelectedElementBox(canvas, element);
    return true;
  }

  function keepLoadedSvgInsideCanvas(canvas) {
    if (!canvas || typeof canvas.getSvgContent !== "function") return false;
    var content = canvas.getSvgContent();
    if (!content || typeof content.getBBox !== "function") return false;
    var drawableNodes = topLevelDrawableNodes(content);
    if (!drawableNodes.length) return false;

    var bbox;
    try {
      bbox = content.getBBox();
    } catch (error) {
      console.warn("[DAVA SVG-Edit bridge] Loaded SVG bounds could not be measured.", error);
      return false;
    }
    if (!bbox || !Number.isFinite(bbox.x) || !Number.isFinite(bbox.y) ||
        !Number.isFinite(bbox.width) || !Number.isFinite(bbox.height) ||
        bbox.width <= 0 || bbox.height <= 0) {
      return false;
    }

    var size = getCanvasContentSize(canvas, content);
    var padding = Math.max(12, Math.min(size.width, size.height) * 0.03);
    var usableWidth = Math.max(1, size.width - padding * 2);
    var usableHeight = Math.max(1, size.height - padding * 2);
    var scale = Math.min(1, usableWidth / bbox.width, usableHeight / bbox.height);
    var scaledWidth = bbox.width * scale;
    var scaledHeight = bbox.height * scale;
    var alreadyInside = scale === 1 &&
      bbox.x >= 0 && bbox.y >= 0 &&
      bbox.x + bbox.width <= size.width &&
      bbox.y + bbox.height <= size.height;
    if (alreadyInside) return false;

    var targetX = Math.max(padding, (size.width - scaledWidth) / 2);
    var targetY = Math.max(padding, (size.height - scaledHeight) / 2);
    var svgRoot = canvas.getSvgRoot && canvas.getSvgRoot();
    var matrix = svgRoot && svgRoot.createSVGMatrix ? svgRoot.createSVGMatrix() : null;
    if (!matrix) return false;
    matrix.a = scale;
    matrix.b = 0;
    matrix.c = 0;
    matrix.d = scale;
    matrix.e = targetX - bbox.x * scale;
    matrix.f = targetY - bbox.y * scale;
    var wrapper = wrapDrawableNodes(content, drawableNodes);
    applyTransformMatrix(wrapper, matrix);
    if (typeof canvas.clearSelection === "function") canvas.clearSelection(true);
    if (canvas.call) canvas.call("changed", [wrapper || content]);
    return true;
  }

  function refreshEditorAfterDocumentLoad(options) {
    options = options || {};
    var editor = currentSvgEditor();
    var canvas = getSvgCanvas();
    try {
      if (canvas && typeof canvas.clearSelection === "function") canvas.clearSelection(true);
      if (editor && editor.leftPanel && typeof editor.leftPanel.clickSelect === "function") {
        editor.leftPanel.clickSelect();
      } else if (canvas && typeof canvas.setMode === "function") {
        canvas.setMode("select");
      }
      if (editor && editor.layersPanel && typeof editor.layersPanel.populateLayers === "function") {
        editor.layersPanel.populateLayers();
      }
      if (editor && editor.topPanel && typeof editor.topPanel.updateContextPanel === "function") {
        editor.topPanel.updateContextPanel();
      }
      if (options.center_canvas && editor && typeof editor.zoomImage === "function") {
        editor.zoomImage();
      } else if (editor && typeof editor.updateCanvas === "function") {
        editor.updateCanvas(false);
      }
      if (editor && editor.rulers && typeof editor.rulers.updateRulers === "function") editor.rulers.updateRulers();
    } catch (error) {
      console.warn("[DAVA SVG-Edit bridge] Editor refresh after document load failed.", error);
    }
  }

  function isBlankSvgDocument(svgText) {
    return !/<(path|rect|circle|ellipse|line|polygon|polyline|text|image|use)\b/i.test((svgText || "").replace(/<defs[\s\S]*?<\/defs>/gi, ""));
  }

  function loadSvgString(svgText, options) {
    options = options || {};
    assertSvgText(svgText, "DAVA_LOAD_SVG");
    var canvas = getSvgCanvas();
    if (options.preserve_layout) {
      var editor = currentSvgEditor();
      var loaded = false;
      saveState.ignoreNativeChange = true;
      try {
        if (options.allow_blank_clear && isBlankSvgDocument(svgText) && canvas && typeof canvas.clear === "function") {
          canvas.clear();
          if (typeof canvas.setResolution === "function") {
            canvas.setResolution(options.canvasWidth || 960, options.canvasHeight || 720);
          }
          loaded = true;
        } else if (editor && typeof editor.loadSvgString === "function") {
          editor.loadSvgString(svgText, { noAlert: true });
          loaded = true;
        } else {
          var directResult = callFirst(canvas, [
            "setSvgString",
            "setSVGString",
            "loadSvgString",
            "setSvgContent"
          ], [svgText]);
          loaded = directResult !== undefined;
        }
      } finally {
        saveState.ignoreNativeChange = false;
      }
      if (loaded) {
        refreshEditorAfterDocumentLoad(options);
        markLoadedClean();
        if (!options.silent) post("DAVA_SVG_CHANGED", { reason: "loaded-preserve-layout" });
        return true;
      }
    }
    if (canvas && typeof canvas.importSvgString === "function") {
      saveState.ignoreNativeChange = true;
      try {
        if (typeof canvas.clear === "function") {
          canvas.clear();
        }
        importSvgIntoCurrentLayer(svgText, {
          object_id: makeBridgeObjectId("dava-loaded-svg"),
          select_after_import: true,
          source: "loaded-svg",
          type: "loaded-svg",
          center_on_canvas: true,
          suppress_import_post: true
        });
      } finally {
        saveState.ignoreNativeChange = false;
      }
      markLoadedClean();
      post("DAVA_SVG_CHANGED", { reason: "loaded" });
      return true;
    }

    var result;
    saveState.ignoreNativeChange = true;
    try {
      result = callFirst(canvas, [
        "setSvgString",
        "setSVGString",
        "loadSvgString",
        "setSvgContent"
      ], [svgText]);
      if (result !== undefined) keepLoadedSvgInsideCanvas(canvas);
    } finally {
      saveState.ignoreNativeChange = false;
    }

    if (result !== undefined) {
      markLoadedClean();
      post("DAVA_SVG_CHANGED", { reason: "loaded" });
      return true;
    }

    var root = findSvgRoot();
    if (!root || !root.parentNode) {
      throw new Error("SVG-Edit API was not recognized and no SVG root was found.");
    }

    var parsed = new DOMParser().parseFromString(svgText, "image/svg+xml");
    var parsedRoot = parsed.documentElement;
    if (!parsedRoot || parsedRoot.nodeName.toLowerCase() !== "svg") {
      throw new Error("Imported SVG could not be parsed.");
    }
    saveState.ignoreNativeChange = true;
    try {
      root.parentNode.replaceChild(document.importNode(parsedRoot, true), root);
    } finally {
      saveState.ignoreNativeChange = false;
    }
    markLoadedClean();
    post("DAVA_SVG_CHANGED", { reason: "loaded-dom-fallback" });
    return true;
  }

  function setToolbarToggleState(collapsed) {
    var button = document.getElementById("dava_svgedit_toolbar_toggle");
    if (!button) return;
    button.classList.toggle("is-collapsed", !!collapsed);
    button.title = collapsed ? "Show R-Plot toolbar" : "Hide R-Plot toolbar";
    button.setAttribute("aria-pressed", collapsed ? "true" : "false");
  }

  function setAppHeaderToggleState(collapsed) {
    appHeaderCollapsed = !!collapsed;
    var button = document.getElementById("dava_svgedit_app_header_toggle");
    if (!button) return;
    button.classList.toggle("is-collapsed", appHeaderCollapsed);
    button.title = appHeaderCollapsed ? "Show application header" : "Hide application header";
    button.setAttribute("aria-label", button.title);
    button.setAttribute("aria-pressed", appHeaderCollapsed ? "true" : "false");
  }

  function findSvgEditMenuAnchor() {
    return document.querySelector("se-menu[label='SVG-Edit']") ||
      Array.prototype.find.call(document.querySelectorAll("se-menu"), function (item) {
        return (item.getAttribute("label") || "").trim() === "SVG-Edit";
      }) ||
      null;
  }

  function ensureToolbarToggle() {
    var existing = document.getElementById("dava_svgedit_toolbar_toggle");
    var anchor = findSvgEditMenuAnchor();
    if (!anchor || !anchor.parentNode) {
      if (toolbarToggleRetryCount < 40) {
        toolbarToggleRetryCount += 1;
        window.setTimeout(ensureToolbarToggle, 100);
      }
      return;
    }
    toolbarToggleRetryCount = 0;
    var editorRoot = anchor.closest(".svg_editor") || document.querySelector(".svg_editor");
    if (editorRoot) editorRoot.classList.add("dava-svg-menubar-rebuilt");
    if (existing) {
      if (anchor && anchor.parentNode && existing.nextElementSibling !== anchor) {
        anchor.parentNode.insertBefore(existing, anchor);
      }
      return;
    }
    var button = document.createElement("button");
    button.id = "dava_svgedit_toolbar_toggle";
    button.type = "button";
    button.title = "Hide R-Plot toolbar";
    button.setAttribute("aria-label", "Toggle R-Plot toolbar");
    button.setAttribute("aria-pressed", "false");
    button.innerHTML = "<span class=\"fold-icon\" aria-hidden=\"true\"></span><span class=\"fold-caret\" aria-hidden=\"true\"></span><span>R-Plot</span>";
    button.addEventListener("click", function () {
      var nextCollapsed = !button.classList.contains("is-collapsed");
      setToolbarToggleState(nextCollapsed);
      post("DAVA_TOGGLE_HOST_TOOLBAR", { collapsed: nextCollapsed });
    });
    if (anchor && anchor.parentNode) {
      anchor.parentNode.insertBefore(button, anchor);
    }
  }

  function ensureAppHeaderToggle() {
    var existing = document.getElementById("dava_svgedit_app_header_toggle");
    var parent = document.body;
    if (existing) {
      if (parent && existing.parentNode !== parent) parent.appendChild(existing);
      setAppHeaderToggleState(appHeaderCollapsed);
      return;
    }
    var button = document.createElement("button");
    button.id = "dava_svgedit_app_header_toggle";
    button.type = "button";
    button.innerHTML = [
      "<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\">",
      "<path d=\"M5 7h14\"></path>",
      "<path class=\"collapse-mark\" d=\"M8 12l4 4 4-4\"></path>",
      "<path class=\"expand-mark\" d=\"M8 16l4-4 4 4\"></path>",
      "</svg>"
    ].join("");
    button.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      var nextCollapsed = !appHeaderCollapsed;
      post("DAVA_TOGGLE_APP_HEADER", { collapsed: nextCollapsed });
    });
    parent.appendChild(button);
    setAppHeaderToggleState(appHeaderCollapsed);
  }

  function releaseSvgEditSelector(canvas, element) {
    var manager = canvas && canvas.selectorManager;
    if (!manager || !element || !element.id || typeof manager.releaseSelector !== "function") return;
    if (manager.selectorMap && !manager.selectorMap[element.id]) return;
    try {
      manager.releaseSelector(element);
    } catch (error) {
      console.warn("[DAVA SVG-Edit bridge] Stale selector cleanup failed.", error);
    }
  }

  function trySelectImportedObject(canvas, target) {
    var element = typeof target === "string" ? document.getElementById(target) : target;
    if (!element) {
      return "Imported SVG was inserted, but precise selection is not supported by this SVG-Edit API.";
    }

    try {
      if (typeof canvas.clearSelection === "function") canvas.clearSelection(true);
      if (typeof canvas.selectOnly === "function") {
        canvas.selectOnly([element], true);
        refreshSelectedElementBox(canvas, element);
        return "";
      }
      if (typeof canvas.addToSelection === "function") {
        canvas.addToSelection([element], true);
        refreshSelectedElementBox(canvas, element);
        return "";
      }
      if (window.svgEditor && typeof window.svgEditor.selectedChanged === "function") {
        window.svgEditor.selectedChanged(window, [element]);
        return "";
      }
    } catch (error) {
      console.warn("[DAVA SVG-Edit bridge] Imported object selection failed.", error);
    }

    return "Imported SVG was inserted, but precise selection is not supported by this SVG-Edit API.";
  }

  function refreshSelectedElementBox(canvas, element) {
    try {
      if (typeof canvas.recalculateAllSelectedDimensions === "function") {
        canvas.recalculateAllSelectedDimensions();
      }
      if (canvas.selectorManager && element) {
        var selector = canvas.selectorManager.requestSelector(element);
        if (selector && typeof selector.resize === "function") selector.resize();
        if (selector && typeof selector.showGrips === "function") selector.showGrips(true);
      }
    } catch (error) {
      console.warn("[DAVA SVG-Edit bridge] Selection box refresh failed.", error);
    }
  }

  function selectedElements(canvas) {
    if (canvas && typeof canvas.getSelectedElements === "function") {
      return canvas.getSelectedElements().filter(Boolean);
    }
    return [];
  }

  function selectionSignature(canvas) {
    return selectedElements(canvas).map(function (element) {
      return element.id || "";
    }).join("|");
  }

  function findNewSelectedElement(canvas, beforeSignature, fallbackElement) {
    var selected = selectedElements(canvas);
    if (selected.length === 1) return selected[0];
    if (fallbackElement && fallbackElement.parentNode) return fallbackElement;
    var afterSignature = selectionSignature(canvas);
    if (afterSignature && afterSignature !== beforeSignature && selected.length > 0) return selected[0];
    return null;
  }

  function markDavaImportedGroup(canvas, element, options) {
    if (!element || !options || !options.object_id) return element;
    var duplicateIndex = 0;
    Array.prototype.forEach.call(element.querySelectorAll("[id]"), function (node) {
      if (node.id === options.object_id) {
        duplicateIndex += 1;
        node.setAttribute("data-dava-original-wrapper-id", options.object_id);
        node.setAttribute("id", options.object_id + "-content" + (duplicateIndex > 1 ? "-" + duplicateIndex : ""));
      }
    });
    element.setAttribute("id", uniqueElementId(options.object_id, element));
    element.setAttribute("data-dava-type", options.type || "r-plot");
    element.setAttribute("data-dava-import-mode", "import");
    element.setAttribute("data-dava-edit-policy", "group-first");
    element.setAttribute("data-dava-source", options.source || "R");
    element.setAttribute("data-dava-realized-from-use", "1");
    markGroupAsSvgEditNativeBBox(canvas, element);
    if (canvas && typeof canvas.setUseData === "function") {
      try { canvas.setUseData(element); } catch (error) {}
    }
    return element;
  }

  function ensureImportedEditableGroup(canvas, element) {
    if (!element || !element.parentNode) return element;
    if ((element.tagName || "").toLowerCase() === "g") return element;
    var group = createSvgGroup(element.parentNode);
    group.setAttribute("data-dava-import-wrapper", "1");
    element.parentNode.insertBefore(group, element);
    group.appendChild(element);
    markGroupAsSvgEditNativeBBox(canvas, group);
    if (canvas && typeof canvas.setUseData === "function") {
      try { canvas.setUseData(group); } catch (error) {}
    }
    return group;
  }

  function realizeImportedUse(canvas, importedElement, options) {
    clearImportWrapperPaint(importedElement);
    if (!importedElement || importedElement.tagName !== "use") {
      return importedElement;
    }
    if (typeof canvas.selectOnly === "function") {
      canvas.selectOnly([importedElement], true);
    } else {
      if (typeof canvas.clearSelection === "function") canvas.clearSelection(true);
      if (typeof canvas.addToSelection === "function") canvas.addToSelection([importedElement], true);
    }

    var beforeSignature = selectionSignature(canvas);
    if (typeof canvas.ungroupSelectedElement !== "function") {
      return importedElement;
    }
    canvas.ungroupSelectedElement();
    var realized = findNewSelectedElement(canvas, beforeSignature, importedElement);
    realized = ensureImportedEditableGroup(canvas, realized);
    if (realized && realized.tagName === "g") {
      clearImportWrapperPaint(realized);
      releaseSvgEditSelector(canvas, importedElement);
      if (typeof canvas.clearSelection === "function") canvas.clearSelection(true);
      markDavaImportedGroup(canvas, realized, options);
      if (typeof canvas.selectOnly === "function") {
        canvas.selectOnly([realized], true);
      }
      try {
        refreshSelectedElementBox(canvas, realized);
        canvas.call && canvas.call("changed", [realized]);
      } catch (error) {
        console.warn("[DAVA SVG-Edit bridge] Imported group selector refresh failed.", error);
      }
      return realized;
    }
    return importedElement;
  }

  function importSvgIntoCurrentLayer(svgText, options) {
    options = options || {};
    assertSvgText(svgText, "DAVA_IMPORT_SVG");

    var canvas = getSvgCanvas();
    if (!canvas || typeof canvas.importSvgString !== "function") {
      throw new Error("SVG-Edit importSvgString API is not available.");
    }

    var importedElement = canvas.importSvgString(svgText, options.preserve_size === true);
    if (!importedElement) {
      throw new Error("SVG-Edit importSvgString failed to import SVG text.");
    }
    var editableElement = realizeImportedUse(canvas, importedElement, options);
    normalizeTextStretchAttributes(editableElement || importedElement);
    normalizeImportedTextEditing(editableElement || importedElement);
    if (editableElement) {
      placeElementInsideCanvas(canvas, editableElement, {
        center: !!options.center_on_canvas,
        preserveSize: !!options.preserve_size
      });
    }
    var warning = null;
    if (options.select_after_import) {
      warning = trySelectImportedObject(canvas, editableElement || options.object_id) || null;
    }
    if (!options.suppress_import_post) {
      post("DAVA_SVG_IMPORTED", {
        object_id: editableElement ? (editableElement.id || options.object_id || null) : (options.object_id || null),
        warning: warning
      });
      markDirty("imported");
      post("DAVA_SVG_CHANGED", { reason: "imported", object_id: editableElement ? (editableElement.id || options.object_id || null) : (options.object_id || null) });
    }
    window.setTimeout(restoreSvgEditorKeyboardFocus, 0);
    return editableElement || importedElement;
  }

  function getSvgString() {
    var canvas = getSvgCanvas();
    var svgText = callFirst(canvas, [
      "getSvgString",
      "getSVGString",
      "svgCanvasToString",
      "getSvgContent",
      "getSvgData"
    ]);

    if (svgText && svgText.nodeType === 1) {
      svgText = new XMLSerializer().serializeToString(svgText);
    }
    if (typeof svgText === "string" && /<svg[\s>]/i.test(svgText)) return svgText;

    var root = findSvgRoot();
    if (!root) throw new Error("SVG-Edit API was not recognized and no SVG root was found.");
    return new XMLSerializer().serializeToString(root);
  }

  function clearCanvas() {
    var canvas = getSvgCanvas();
    var result = callFirst(canvas, ["clear", "clearCanvas", "newDocument"], []);
    if (result !== undefined) {
      markDirty("cleared");
      post("DAVA_SVG_CHANGED", { reason: "cleared" });
      return true;
    }
    throw new Error("SVG-Edit clear API is not available.");
  }

  function bindDirtyTracking() {
    if (saveState.dirtyBound) return;
    var canvas = getSvgCanvas();
    if (!canvas || typeof canvas.bind !== "function") return;
    try {
      canvas.bind("changed", function () {
        markDirty("native-changed");
      });
      saveState.dirtyBound = true;
    } catch (error) {
      console.warn("[DAVA SVG-Edit bridge] Could not bind dirty tracking.", error);
    }
  }

  function shutdownSvgEdit() {
    shuttingDown = true;
    ready = false;
    try {
      if (document.activeElement && typeof document.activeElement.blur === "function") {
        document.activeElement.blur();
      }
    } catch (error) {}

    try {
      if (window.svgEditor) {
        window.svgEditor.showSaveWarning = false;
        if (window.svgEditor.configObj && window.svgEditor.configObj.curConfig) {
          window.svgEditor.configObj.curConfig.no_save_warning = true;
        }
        if (typeof window.svgEditor.cancelTool === "function") window.svgEditor.cancelTool();
      }
    } catch (error) {}

    try {
      var canvas = getSvgCanvas();
      if (canvas && typeof canvas.clearSelection === "function") canvas.clearSelection(true);
    } catch (error) {}

    try {
      window.onbeforeunload = null;
      window.onunload = null;
    } catch (error) {}

    var menu = document.getElementById("dava_svgedit_menu");
    if (menu && menu.parentNode) menu.parentNode.removeChild(menu);
    var pdfMenuItem = document.getElementById("dava_tool_pdf_import_menu");
    if (pdfMenuItem && pdfMenuItem.parentNode) pdfMenuItem.parentNode.removeChild(pdfMenuItem);
    var strokeMenu = document.getElementById("dava_stroke_style_menu");
    if (strokeMenu && strokeMenu.parentNode) strokeMenu.parentNode.removeChild(strokeMenu);
    var toggle = document.getElementById("dava_svgedit_toolbar_toggle");
    if (toggle && toggle.parentNode) toggle.parentNode.removeChild(toggle);
    var headerToggle = document.getElementById("dava_svgedit_app_header_toggle");
    if (headerToggle && headerToggle.parentNode) headerToggle.parentNode.removeChild(headerToggle);
    var editorRoot = document.querySelector(".svg_editor.dava-svg-menubar-rebuilt");
    if (editorRoot) editorRoot.classList.remove("dava-svg-menubar-rebuilt");
  }

  function reportError(error, type) {
    lastError = error && error.message ? error.message : String(error);
    console.error("[DAVA SVG-Edit bridge]", lastError, error);
    post(type || "DAVA_SVGEDIT_ERROR", { error: lastError, message: lastError });
  }

  function isToolbarNode(node) {
    return !!(node && node.closest && node.closest([
      "#tools_top",
      "#tools_left",
      "#tools_bottom",
      "#main_button",
      "#dava_svgedit_toolbar_toggle",
      "#dava_svgedit_menu",
      "#dava_tool_symbol",
      "#dava_symbol_panel",
      "#dava_tool_equation",
      "#dava_equation_panel",
      "#dava_pdf_import_panel",
      "#dava_stroke_style_top",
      "#dava_stroke_style_menu",
      "se-menu",
      "se-button",
      "se-select",
      "se-list",
      "se-spin-input",
      "se-input",
      "se-colorpicker",
      "se-palette",
      "se-zoom"
    ].join(",")));
  }

  function clearToolbarTextSelection() {
    var selection = window.getSelection ? window.getSelection() : null;
    if (!selection || selection.rangeCount === 0 || selection.isCollapsed) return;
    var anchor = selection.anchorNode && selection.anchorNode.nodeType === 1 ?
      selection.anchorNode :
      selection.anchorNode && selection.anchorNode.parentElement;
    var focus = selection.focusNode && selection.focusNode.nodeType === 1 ?
      selection.focusNode :
      selection.focusNode && selection.focusNode.parentElement;
    if (isToolbarNode(anchor) || isToolbarNode(focus)) selection.removeAllRanges();
  }

  function ensureToolbarSelectionGuard() {
    if (document.documentElement.getAttribute("data-dava-toolbar-selection-guard") === "1") return;
    document.documentElement.setAttribute("data-dava-toolbar-selection-guard", "1");
    if (!document.getElementById("dava_toolbar_selection_guard_css")) {
      var style = document.createElement("style");
      style.id = "dava_toolbar_selection_guard_css";
      style.textContent = [
        "#tools_top,#tools_left,#tools_bottom,#main_button,#dava_svgedit_toolbar_toggle,#dava_svgedit_menu,#dava_tool_symbol,#dava_symbol_panel,#dava_tool_equation,#dava_equation_panel,#dava_pdf_import_panel,#dava_stroke_style_menu{user-select:none;-webkit-user-select:none}",
        "#tools_top *,#tools_left *,#tools_bottom *,#main_button *,#dava_svgedit_toolbar_toggle *,#dava_svgedit_menu *,#dava_tool_symbol *,#dava_symbol_panel *,#dava_tool_equation *,#dava_equation_panel *,#dava_pdf_import_panel * *,#dava_stroke_style_top *,#dava_stroke_style_menu *{user-select:none;-webkit-user-select:none}",
        "#dava_symbol_panel input,#dava_symbol_panel select,#dava_equation_panel input,#dava_equation_panel textarea,#dava_equation_panel select,#dava_equation_panel math-field,#dava_pdf_import_panel input,#dava_pdf_import_panel select{user-select:text;-webkit-user-select:text}",
        "#tools_top input,#tools_top textarea,#tools_top select,#tools_bottom input,#tools_bottom textarea,#tools_bottom select input{user-select:text;-webkit-user-select:text}"
      ].join("\n");
      document.head.appendChild(style);
    }
    document.addEventListener("selectionchange", function () {
      window.setTimeout(clearToolbarTextSelection, 0);
    }, false);
    document.addEventListener("mouseup", function (event) {
      if (isToolbarNode(event.target)) window.setTimeout(clearToolbarTextSelection, 0);
    }, false);
  }

  function symbolEnvironment() {
    return {
      getSvgCanvas: getSvgCanvas,
      post: post,
      activeTextInput: function () {
        var canvas = getSvgCanvas();
        var input = document.getElementById("text");
        if (!input || typeof input.selectionStart !== "number") return null;
        if (isTextEditMode(canvas)) return input;
        if (document.body.classList.contains("dava-symbol-panel-open") &&
          symbolTextInputSnapshot &&
          symbolTextInputSnapshot.input === input) {
          try {
            if (String(input.value || "") === symbolTextInputSnapshot.value) {
              input.selectionStart = symbolTextInputSnapshot.start;
              input.selectionEnd = symbolTextInputSnapshot.end;
            } else {
              symbolTextInputSnapshot.start = input.selectionStart;
              symbolTextInputSnapshot.end = input.selectionEnd;
              symbolTextInputSnapshot.value = String(input.value || "");
            }
          } catch (error) {}
          return input;
        }
        return null;
      },
      lastCanvasPoint: function () {
        return null;
      }
    };
  }

  function equationEnvironment() {
    return {
      getSvgCanvas: getSvgCanvas,
      post: post,
      lastCanvasPoint: function () {
        return null;
      }
    };
  }

  function pdfImportEnvironment() {
    return {
      getSvgCanvas: getSvgCanvas,
      getEditor: currentSvgEditor,
      importSvgIntoCurrentLayer: importSvgIntoCurrentLayer,
      post: post,
      documentId: currentDocumentId
    };
  }

  function openPdfImportPanel() {
    loadPdfImportModules(function () {
      if (!window.DavaPdfImportTool) {
        reportError(new Error("PDF import modules are not available."), "DAVA_SVGEDIT_ERROR");
        return;
      }
      window.DavaPdfImportTool.open(pdfImportEnvironment());
    });
  }

  function openExportPanel() {
    loadExportModules(function () {
      if (!window.DavaExportPanel) {
        reportError(new Error("Export modules are not available."), "DAVA_SVGEDIT_ERROR");
        return;
      }
      window.DavaExportPanel.open();
    });
  }

  function directLogicalUserObjectFromTarget(target) {
    var node = target && target.correspondingUseElement ? target.correspondingUseElement : target;
    while (node && node !== document) {
      var parent = node.parentNode;
      if (parent && parent.getAttribute && parent.getAttribute("data-dava-logical-user-layer") === "1") {
        if (node.getAttribute && node.getAttribute("data-dava-container-only") === "1") return null;
        return node;
      }
      node = parent;
    }
    return null;
  }

  function installLogicalUserLayerMouseTargetPatch() {
    normalizeLogicalUserLayerPointerEvents();
    var canvas = getSvgCanvas();
    if (!canvas || typeof canvas.getMouseTarget !== "function" || canvas.__davaLogicalUserMouseTargetPatch) return;
    var nativeGetMouseTarget = canvas.getMouseTarget.bind(canvas);
    canvas.getMouseTarget = function (event) {
      var logicalObject = directLogicalUserObjectFromTarget(event && event.target);
      return logicalObject || nativeGetMouseTarget(event);
    };
    canvas.__davaLogicalUserMouseTargetPatch = true;
  }

  function normalizeLogicalUserLayerPointerEvents() {
    Array.prototype.forEach.call(document.querySelectorAll("g[data-dava-logical-user-layer='1']"), function (group) {
      group.removeAttribute("pointer-events");
      group.style.pointerEvents = "";
      Array.prototype.forEach.call(group.querySelectorAll("text[data-type='symbol']"), function (text) {
        text.setAttribute("pointer-events", "visiblePainted");
      });
    });
  }

  function captureSymbolTextInputSnapshot() {
    var canvas = getSvgCanvas();
    var input = document.getElementById("text");
    if (!isTextEditMode(canvas) || !input || typeof input.selectionStart !== "number") {
      symbolTextInputSnapshot = null;
      return;
    }
    symbolTextInputSnapshot = {
      input: input,
      start: input.selectionStart,
      end: input.selectionEnd,
      value: String(input.value || "")
    };
  }

  function installSymbolTextEditBridge() {
    if (document.documentElement.getAttribute("data-dava-symbol-text-edit-bridge") === "1") return;
    document.documentElement.setAttribute("data-dava-symbol-text-edit-bridge", "1");
    document.addEventListener("dblclick", function (event) {
      var target = event.target;
      if (!target || !target.tagName || !/^text$/i.test(target.tagName)) return;
      if (!target.getAttribute || target.getAttribute("data-type") !== "symbol") return;
      var canvas = getSvgCanvas();
      if (!canvas || !canvas.textActions || typeof canvas.textActions.select !== "function") return;
      if (canvas.getCurrentMode && canvas.getCurrentMode() === "textedit") return;
      try {
        event.preventDefault();
        event.stopImmediatePropagation();
        target.removeAttribute("data-dava-container-only");
        target.setAttribute("pointer-events", "visiblePainted");
        var matrix = typeof canvas.getrootSctm === "function" ? canvas.getrootSctm() : null;
        var point = transformPointByMatrix(event.clientX, event.clientY, matrix);
        if (canvas.selectOnly) canvas.selectOnly([target]);
        canvas.textActions.select(target, point.x, point.y);
        window.setTimeout(function () {
          var input = document.getElementById("text");
          if (input && typeof input.focus === "function") input.focus();
          syncTextInputFromMultilineRoot();
          scheduleTextCaretAdjust(0);
        }, 0);
      } catch (error) {
        console.warn("[DAVA SVG-Edit symbol] Failed to enter symbol text edit mode.", error);
      }
    }, true);
  }

  function selectedEquationElement() {
    var canvas = getSvgCanvas();
    var selected = selectedElements(canvas);
    for (var index = 0; index < selected.length; index += 1) {
      var element = selected[index];
      if (element && element.getAttribute && element.getAttribute("data-type") === "equation") return element;
      if (element && element.closest) {
        var parentEquation = element.closest("[data-type='equation']");
        if (parentEquation) return parentEquation;
      }
    }
    return null;
  }

  function openEquationPanel(options) {
    options = options || {};
    loadEquationModules(function () {
      if (!window.DavaEquationTool) {
        reportError(new Error("Equation panel modules are not available."), "DAVA_SVGEDIT_ERROR");
        return;
      }
      var equation = options.element || selectedEquationElement();
      var payload = equation ? {
        element: equation,
        latex: equation.getAttribute("data-latex") || "",
        displayMode: equation.getAttribute("data-display-mode") !== "false",
        fill: equation.getAttribute("fill") || "#000000"
      } : {};
      window.DavaEquationTool.open(equationEnvironment(), payload);
    });
  }

  function bindEquationDoubleClick() {
    if (document.documentElement.getAttribute("data-dava-equation-dblclick") === "1") return;
    document.documentElement.setAttribute("data-dava-equation-dblclick", "1");
    var closestEquationFromNode = function (node) {
      if (node && node.closest) return node.closest("[data-type='equation']");
      for (var current = node; current && current !== document; current = current.parentNode) {
        if (current.getAttribute && current.getAttribute("data-type") === "equation") return current;
      }
      return null;
    };
    var pointInsideElementRect = function (event, element) {
      if (!element || typeof element.getBoundingClientRect !== "function") return false;
      var rect = element.getBoundingClientRect();
      return event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
    };
    var equationAtPoint = function (event) {
      var equations = Array.prototype.slice.call(document.querySelectorAll("[data-type='equation']"));
      for (var index = equations.length - 1; index >= 0; index -= 1) {
        if (pointInsideElementRect(event, equations[index])) return equations[index];
      }
      return null;
    };
    document.addEventListener("dblclick", function (event) {
      var target = closestEquationFromNode(event.target);
      if (!target) {
        var selectedEquation = selectedEquationElement();
        if (selectedEquation && pointInsideElementRect(event, selectedEquation)) target = selectedEquation;
      }
      if (!target) target = equationAtPoint(event);
      if (!target) return;
      event.preventDefault();
      if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
      event.stopPropagation();
      openEquationPanel({ element: target });
    }, true);
  }

  function bindEquationCanvasSelectionGuard() {
    if (document.documentElement.getAttribute("data-dava-equation-selection-guard") === "1") return;
    document.documentElement.setAttribute("data-dava-equation-selection-guard", "1");
    var closeSvgEditContextMenu = function () {
      var menu = document.getElementById("se-cmenu_canvas");
      var dialog = menu && menu.shadowRoot ? menu.shadowRoot.querySelector(".contextMenu") : null;
      if (dialog) dialog.style.display = "none";
    };
    var setEquationContextMenuState = function () {
      var menu = document.getElementById("se-cmenu_canvas");
      if (!menu) return;
      if (selectedEquationElement()) {
        menu.setAttribute("disablemenuitems", "#group,#ungroup");
      }
    };
    var isInsideSvgEditContextMenu = function (event) {
      var menu = document.getElementById("se-cmenu_canvas");
      if (!menu || !menu.shadowRoot || !event.composedPath) return false;
      var path = event.composedPath();
      return path.indexOf(menu) !== -1 || path.some(function (node) {
        return node && node.classList && node.classList.contains("contextMenu");
      });
    };
    var selectEquationGroup = function (canvas, equation) {
      try {
        if (window.DavaEquationObjectModel && typeof window.DavaEquationObjectModel.normalizeEquationElement === "function") {
          window.DavaEquationObjectModel.normalizeEquationElement(equation);
        }
        if (typeof canvas.clearSelection === "function") canvas.clearSelection(true);
        if (typeof canvas.selectOnly === "function") canvas.selectOnly([equation], true);
        else if (typeof canvas.addToSelection === "function") canvas.addToSelection([equation], true);
        if (typeof canvas.recalculateAllSelectedDimensions === "function") canvas.recalculateAllSelectedDimensions();
        if (canvas.call) canvas.call("selected", [equation]);
      } catch (error) {
        console.warn("[DAVA SVG-Edit equation] Could not promote equation selection.", error);
      }
    };
    var normalizeExistingEquations = function () {
      if (!window.DavaEquationObjectModel || typeof window.DavaEquationObjectModel.normalizeEquationElement !== "function") return;
      Array.prototype.forEach.call(document.querySelectorAll("[data-type='equation']"), function (equation) {
        window.DavaEquationObjectModel.normalizeEquationElement(equation);
      });
    };
    document.addEventListener("contextmenu", function (event) {
      var equation = event.target && event.target.closest ? event.target.closest("[data-type='equation']") : null;
      if (!equation || shuttingDown) return;
      var canvas = getSvgCanvas();
      if (canvas) selectEquationGroup(canvas, equation);
      window.setTimeout(setEquationContextMenuState, 0);
      window.setTimeout(setEquationContextMenuState, 50);
    }, true);
    window.setTimeout(function () {
      var menu = document.getElementById("se-cmenu_canvas");
      if (!menu || menu.__davaEquationUngroupGuard) return;
      menu.__davaEquationUngroupGuard = true;
      menu.addEventListener("change", function (event) {
        if (!selectedEquationElement()) return;
        var trigger = event.detail && event.detail.trigger;
        if (trigger !== "ungroup" && trigger !== "group") return;
        event.preventDefault();
        if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
        event.stopPropagation();
        closeSvgEditContextMenu();
      }, true);
    }, 500);
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") closeSvgEditContextMenu();
      if ((event.ctrlKey || event.metaKey) && event.shiftKey && String(event.key || "").toLowerCase() === "g" && selectedEquationElement()) {
        event.preventDefault();
        if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
        event.stopPropagation();
      }
    }, true);
    document.addEventListener("mousedown", function (event) {
      if (event.button === 2 || isInsideSvgEditContextMenu(event)) return;
      closeSvgEditContextMenu();
    }, true);
    document.addEventListener("click", function (event) {
      if (!selectedEquationElement()) return;
      var tool = event.target && event.target.closest ? event.target.closest("#tool_ungroup,#tool_group_elements") : null;
      if (!tool) return;
      event.preventDefault();
      if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
      event.stopPropagation();
    }, true);
    document.addEventListener("click", function (event) {
      var equation = event.target && event.target.closest ? event.target.closest("[data-type='equation']") : null;
      if (!equation || event.target === equation || shuttingDown) return;
      var canvas = getSvgCanvas();
      if (!canvas) return;
      selectEquationGroup(canvas, equation);
    }, true);
    normalizeExistingEquations();
    window.setTimeout(normalizeExistingEquations, 500);
    window.setTimeout(normalizeExistingEquations, 1500);
  }

  function openSymbolPanel() {
    captureSymbolTextInputSnapshot();
    loadSymbolModules(function () {
      if (!window.DavaSymbolPanel) {
        reportError(new Error("Symbol panel modules are not available."), "DAVA_SVGEDIT_ERROR");
        return;
      }
      window.DavaSymbolPanel.init(symbolEnvironment());
      window.DavaSymbolPanel.open();
    });
  }

  function ensureSymbolTool() {
    if (symbolToolsBound && document.getElementById("dava_tool_symbol")) return true;
    var toolsLeft = document.getElementById("tools_left");
    if (!toolsLeft) {
      window.setTimeout(ensureSymbolTool, 100);
      return false;
    }
    if (!document.getElementById("dava_symbol_tool_css")) {
      var style = document.createElement("style");
      style.id = "dava_symbol_tool_css";
      style.textContent = [
        "#dava_tool_symbol{width:26px;height:26px;margin:2px 0;border:0;background:#60696c;color:#ffc400;font:700 18px/26px 'Cambria Math','Segoe UI Symbol',serif;text-align:center;cursor:pointer;border-radius:2px}",
        "#dava_tool_symbol:hover{background:#6f787b;color:#ffe17a}",
        "#dava_tool_symbol.active{background:#1f7a8c;color:#fff}"
      ].join("\n");
      document.head.appendChild(style);
    }
    var button = document.getElementById("dava_tool_symbol");
    if (!button) {
      button = document.createElement("button");
      button.id = "dava_tool_symbol";
      button.type = "button";
      button.title = "Insert Symbol (Alt+Shift+S)";
      button.setAttribute("shortcut", "Alt+Shift+S");
      button.textContent = "\u03a9";
      var textTool = document.getElementById("tool_text");
      if (textTool && textTool.parentNode === toolsLeft && textTool.nextSibling) {
        toolsLeft.insertBefore(button, textTool.nextSibling);
      } else if (textTool && textTool.parentNode === toolsLeft) {
        toolsLeft.appendChild(button);
      } else {
        toolsLeft.appendChild(button);
      }
    }
    button.title = "Insert Symbol (Alt+Shift+S)";
    button.setAttribute("shortcut", "Alt+Shift+S");
    if (!button.dataset.davaSymbolBound) {
      button.dataset.davaSymbolBound = "1";
      button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        openSymbolPanel();
      });
    }
    symbolToolsBound = true;
    return true;
  }

  function ensureEquationTool() {
    installLogicalUserLayerMouseTargetPatch();
    if (equationToolsBound && document.getElementById("dava_tool_equation")) return true;
    var toolsLeft = document.getElementById("tools_left");
    if (!toolsLeft) {
      window.setTimeout(ensureEquationTool, 100);
      return false;
    }
    if (!document.getElementById("dava_equation_tool_css")) {
      var style = document.createElement("style");
      style.id = "dava_equation_tool_css";
      style.textContent = [
        "#dava_tool_equation{width:26px;height:26px;margin:2px 0;border:0;background:#60696c;color:#ffc400;font:700 18px/26px 'Cambria Math','Segoe UI Symbol',serif;text-align:center;cursor:pointer;border-radius:2px}",
        "#dava_tool_equation:hover{background:#6f787b;color:#ffe17a}",
        "#dava_tool_equation.active{background:#1f7a8c;color:#fff}"
      ].join("\n");
      document.head.appendChild(style);
    }
    var button = document.getElementById("dava_tool_equation");
    if (!button) {
      button = document.createElement("button");
      button.id = "dava_tool_equation";
      button.type = "button";
      button.title = "Equation (Alt+=)";
      button.textContent = "\u03c0";
      var symbolTool = document.getElementById("dava_tool_symbol");
      var textTool = document.getElementById("tool_text");
      var anchor = symbolTool || textTool;
      if (anchor && anchor.parentNode === toolsLeft && anchor.nextSibling) {
        toolsLeft.insertBefore(button, anchor.nextSibling);
      } else if (anchor && anchor.parentNode === toolsLeft) {
        toolsLeft.appendChild(button);
      } else {
        toolsLeft.appendChild(button);
      }
    }
    if (!button.dataset.davaEquationBound) {
      button.dataset.davaEquationBound = "1";
      button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        openEquationPanel();
      });
    }
    equationToolsBound = true;
    bindEquationDoubleClick();
    bindEquationCanvasSelectionGuard();
    return true;
  }

  function ensureExportTool() {
    if (exportToolBound) return true;
    var tool = document.getElementById("tool_export");
    if (!tool) {
      window.setTimeout(ensureExportTool, 150);
      return false;
    }
    tool.setAttribute("title", "Export SVG / PDF (Vector) / TIFF");
    tool.setAttribute("aria-label", "Export SVG / PDF (Vector) / TIFF");
    tool.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
      openExportPanel();
    }, true);
    exportToolBound = true;
    return true;
  }

  function initializeSimpleDocumentTabs() {
    loadSimpleDocumentModules(function () {
      if (!window.DavaSimpleDocumentStore || !window.DavaSimpleDocumentStore.init) return;
      window.DavaSimpleDocumentStore.init({
        getSvgCanvas: getSvgCanvas,
        importSvgIntoCurrentLayer: importSvgIntoCurrentLayer,
        loadSvgString: loadSvgString,
        getSvgString: getSvgString,
        clearCanvas: clearCanvas
      });
    });
  }

  function initializeExportPanel() {
    loadExportModules(function () {
      ensureExportTool();
    });
  }

  window.DavaSvgEditBridge = {
    getSvgCanvas: getSvgCanvas,
    waitForSvgCanvas: waitForSvgCanvas,
    importSvgIntoCurrentLayer: importSvgIntoCurrentLayer,
    loadSvgString: loadSvgString,
    getSvgString: getSvgString,
    clearCanvas: clearCanvas,
    shutdownSvgEdit: shutdownSvgEdit
  };

  window.DAVA_SVGEDIT_FONT_API = {
    getFonts: getFonts,
    applyFontFamily: applyFontToSelection,
    refreshFontDropdown: refreshFontDropdown,
    findFontFamilyControl: findFontFamilyControl,
    appendFontsToControl: appendFontsToControl
  };

  window.DAVA_SVGEDIT_TEXT_STYLE_API = {
    ensureTools: ensureTextStyleTools,
    setOrientation: setTextOrientation,
    setSuperscript: function () { return setTextScript("super"); },
    setSubscript: function () { return setTextScript("sub"); },
    updateState: updateTextStyleToolState
  };

  window.addEventListener("message", function (event) {
    var message = event.data || {};
    if (!message || message.source === "DAVA_SVGEDIT_BRIDGE") return;
    try {
      if (message.type === "DAVA_SET_LANGUAGE") {
        setSvgEditLanguage(message.language || "en");
      } else if (message.type === "DAVA_SHUTDOWN_SVGEDIT") {
        shutdownSvgEdit();
      } else if (shuttingDown) {
        return;
      } else if (message.type === "DAVA_IMPORT_SVG") {
        if ((message.mode || "import") !== "import") {
          throw new Error("DAVA_IMPORT_SVG requires mode=\"import\".");
        }
        importSvgIntoCurrentLayer(message.svg || "", {
          object_id: message.object_id || null,
          select_after_import: message.select_after_import !== false,
          center_on_canvas: message.center_on_canvas !== false,
          preserve_size: message.preserve_size === true
        });
      } else if (message.type === "DAVA_LOAD_SVG") {
        loadSvgString(message.svg || "");
      } else if (message.type === "DAVA_GET_SVG") {
        post("DAVA_SVG_EXPORTED", { svg: getSvgString(), requestId: message.requestId || "" });
      } else if (message.type === "DAVA_CLEAR_SVG" || message.type === "DAVA_CLEAR") {
        clearCanvas();
      } else if (message.type === "DAVA_HOST_MENU_STATE") {
        updateDavaMenuState(message);
      } else if (message.type === "DAVA_HOST_TOOLBAR_STATE") {
        setToolbarToggleState(!!message.collapsed);
        window.dispatchEvent(new Event("resize"));
      } else if (message.type === "DAVA_OPEN_PDF_IMPORT_PANEL") {
        openPdfImportPanel();
      } else if (message.type === "DAVA_OPEN_EXPORT_PANEL") {
        openExportPanel();
      } else if (message.type === "DAVA_EXPORT_RESULT") {
        loadExportModules(function () {
          if (window.DavaExportShinyBridge) window.DavaExportShinyBridge.handleResult(message.payload || message);
        });
      } else if (message.type === "DAVA_PDF_CONVERSION_RESULT") {
        loadPdfImportModules(function () {
          if (window.DavaPdfImportClient) window.DavaPdfImportClient.handleConversionResult(message.payload || message);
        });
      } else if (message.type === "DAVA_PDF_IMPORT_ERROR") {
        loadPdfImportModules(function () {
          if (window.DavaPdfImportPanel) window.DavaPdfImportPanel.setStatus(message.message || message.error || "PDF import failed.", "error");
        });
      } else if (message.type === "DAVA_APP_HEADER_STATE") {
        setAppHeaderToggleState(!!message.collapsed);
        window.dispatchEvent(new Event("resize"));
      } else if (message.type === "DAVA_SAVE_COMPLETED") {
        completeSave(message);
      } else if (message.type === "DAVA_DOCUMENT_SAVED_TO_GALLERY") {
        if (window.DavaSimpleDocumentStore && window.DavaSimpleDocumentStore.handleSavedToGallery) {
          window.DavaSimpleDocumentStore.handleSavedToGallery(message);
        }
      } else if (message.type === "DAVA_GALLERY_STATE") {
        saveState.defaultGalleryName = message.defaultName || saveState.defaultGalleryName || "SVGEdit";
      } else if (message.type === "DAVA_OPEN_SAVE_DIALOG") {
        requestSave(message.source || "toolbar");
      } else if (message.type === "DAVA_REQUEST_EXIT") {
        handleExitRequest();
      } else if (message.type === "open_equation_panel" || message.type === "DAVA_OPEN_EQUATION_PANEL") {
        openEquationPanel();
      } else if (message.type === "insert_equation" || message.type === "DAVA_INSERT_EQUATION") {
        loadEquationModules(function () {
          window.DavaEquationInsertCommand.insertEquationCommand(equationEnvironment(), message.latex || "", {
            displayMode: message.displayMode !== false,
            fill: message.fill || "#000000"
          }).catch(function (error) {
            reportError(error, "svg_editor_equation_render_error");
          });
        });
      } else if (message.type === "update_equation" || message.type === "DAVA_UPDATE_EQUATION") {
        loadEquationModules(function () {
          var equation = selectedEquationElement();
          if (!equation) {
            reportError(new Error("No selected equation object is available."), "DAVA_SVGEDIT_ERROR");
            return;
          }
          window.DavaEquationEditCommand.editEquationCommand(equationEnvironment(), equation, message.latex || "", {
            displayMode: message.displayMode !== false
          }).catch(function (error) {
            reportError(error, "svg_editor_equation_render_error");
          });
        });
      }
    } catch (error) {
      reportError(error, message.type === "DAVA_IMPORT_SVG" ? "DAVA_SVG_IMPORT_ERROR" : "DAVA_SVGEDIT_ERROR");
    }
  });

  function announceReady() {
    if (ready || shuttingDown) return;
    waitForSvgCanvas(function () {
      if (shuttingDown) return;
      setSvgEditLanguage(document.documentElement.getAttribute("data-dava-language") || "en");
      ensureDavaMenu();
      ensurePdfImportNativeMenuItem();
      initializeSimpleDocumentTabs();
      initializeExportPanel();
      bindDirtyTracking();
      ensureToolbarSelectionGuard();
      refreshFontDropdown();
      ensureTextStyleTools();
      ensureStrokeStyleTopControl();
      ensureSymbolTool();
      installLogicalUserLayerMouseTargetPatch();
      installSymbolTextEditBridge();
      ensureEquationTool();
      setDefaultStrokeForNewShapes();
      bindDefaultStrokeForShapeTools();
      installIllustratorShortcuts();
      window.setTimeout(refreshFontDropdown, 500);
      window.setTimeout(refreshFontDropdown, 1500);
      window.setTimeout(ensureTextStyleTools, 500);
      window.setTimeout(ensureTextStyleTools, 1500);
      window.setTimeout(ensureStrokeStyleTopControl, 500);
      window.setTimeout(ensureStrokeStyleTopControl, 1500);
      window.setTimeout(ensureSymbolTool, 500);
      window.setTimeout(ensureSymbolTool, 1500);
      window.setTimeout(ensureEquationTool, 500);
      window.setTimeout(ensureEquationTool, 1500);
      window.setTimeout(ensureExportTool, 500);
      window.setTimeout(ensureExportTool, 1500);
      window.setTimeout(setDefaultStrokeForNewShapes, 500);
      window.setTimeout(setDefaultStrokeForNewShapes, 1500);
      window.setTimeout(updateIllustratorShortcutHints, 500);
      window.setTimeout(updateIllustratorShortcutHints, 1500);
      window.setTimeout(updateIllustratorContextMenuLabels, 500);
      window.setTimeout(updateIllustratorContextMenuLabels, 1500);
      ready = true;
      post("DAVA_SVGEDIT_READY", { version: "svgedit-bridge-2", lastError: lastError });
      post("DAVA_SVG_READY", { version: "svgedit-bridge-2", lastError: lastError });
    });
  }

  if (document.readyState === "complete") {
    window.setTimeout(announceReady, 250);
  } else {
    window.addEventListener("load", function () {
      window.setTimeout(announceReady, 250);
    });
  }
})();

