/* DAVA font choices for SVG-Edit.
 * Values are written directly to SVG font-family attributes so exported SVGs
 * preserve the selected family plus browser/system fallback chains.
 */
(function () {
  "use strict";

  function font(label, value, category, role) {
    return {
      label: label,
      value: value,
      category: category || "All Fonts",
      role: role || ""
    };
  }

  window.DAVA_SVGEDIT_DEFAULT_FONT = "\"Aptos\", \"Calibri\", \"Microsoft YaHei\", \"PingFang SC\", \"Hiragino Sans GB\", Arial, sans-serif";

  window.DAVA_SVGEDIT_FONTS = [
    font("Calibri (标题)", "\"Calibri\", \"Aptos\", \"Segoe UI\", Arial, sans-serif", "Theme Fonts", "heading"),
    font("Calibri (正文)", "\"Calibri\", \"Aptos\", \"Segoe UI\", Arial, sans-serif", "Theme Fonts", "body"),
    font("微软雅黑 (标题)", "\"Microsoft YaHei\", \"PingFang SC\", \"Hiragino Sans GB\", \"Noto Sans CJK SC\", sans-serif", "Theme Fonts", "heading"),
    font("微软雅黑 (正文)", "\"Microsoft YaHei\", \"PingFang SC\", \"Hiragino Sans GB\", \"Noto Sans CJK SC\", sans-serif", "Theme Fonts", "body"),

    font("Aptos", "\"Aptos\", \"Calibri\", \"Segoe UI\", Arial, sans-serif", "All Fonts"),
    font("Aptos Display", "\"Aptos Display\", \"Aptos\", \"Calibri Light\", \"Segoe UI Semilight\", Arial, sans-serif", "All Fonts"),
    font("Arial", "Arial, Helvetica, sans-serif", "All Fonts"),
    font("Arial Narrow", "\"Arial Narrow\", Arial, Helvetica, sans-serif", "All Fonts"),
    font("Avenir Next", "\"Avenir Next\", Avenir, \"Segoe UI\", Arial, sans-serif", "All Fonts"),
    font("Baskerville", "Baskerville, \"Libre Baskerville\", Georgia, serif", "All Fonts"),
    font("Calibri", "\"Calibri\", \"Aptos\", \"Segoe UI\", Arial, sans-serif", "All Fonts"),
    font("Calibri Light", "\"Calibri Light\", \"Aptos Display\", \"Segoe UI Light\", Arial, sans-serif", "All Fonts"),
    font("Cambria", "\"Cambria\", Georgia, \"Times New Roman\", serif", "All Fonts"),
    font("Candara", "\"Candara\", \"Aptos\", \"Segoe UI\", Arial, sans-serif", "All Fonts"),
    font("Cascadia Mono", "\"Cascadia Mono\", Consolas, \"Courier New\", monospace", "All Fonts"),
    font("Century Gothic", "\"Century Gothic\", \"Apple Gothic\", Futura, sans-serif", "All Fonts"),
    font("Comic Sans MS", "\"Comic Sans MS\", \"Comic Sans\", cursive", "All Fonts"),
    font("Consolas", "\"Consolas\", \"Cascadia Mono\", \"Courier New\", monospace", "All Fonts"),
    font("Constantia", "\"Constantia\", Cambria, Georgia, serif", "All Fonts"),
    font("Corbel", "\"Corbel\", \"Aptos\", \"Segoe UI\", Arial, sans-serif", "All Fonts"),
    font("Courier New", "\"Courier New\", Courier, monospace", "All Fonts"),
    font("DengXian 等线", "\"DengXian\", \"Microsoft YaHei\", \"PingFang SC\", sans-serif", "All Fonts"),
    font("FangSong 仿宋", "FangSong, STFangsong, serif", "All Fonts"),
    font("Futura", "Futura, \"Century Gothic\", \"Avenir Next\", sans-serif", "All Fonts"),
    font("Garamond", "Garamond, \"Apple Garamond\", \"Times New Roman\", serif", "All Fonts"),
    font("Georgia", "Georgia, \"Times New Roman\", serif", "All Fonts"),
    font("Gill Sans", "\"Gill Sans\", \"Gill Sans MT\", Calibri, Arial, sans-serif", "All Fonts"),
    font("Heiti SC 黑体-简", "\"Heiti SC\", STHeiti, SimHei, sans-serif", "All Fonts"),
    font("Helvetica Neue", "\"Helvetica Neue\", Helvetica, Arial, sans-serif", "All Fonts"),
    font("Hiragino Sans GB 冬青黑体", "\"Hiragino Sans GB\", \"PingFang SC\", \"Microsoft YaHei\", sans-serif", "All Fonts"),
    font("Impact", "Impact, Haettenschweiler, \"Arial Narrow Bold\", sans-serif", "All Fonts"),
    font("KaiTi 楷体", "KaiTi, STKaiti, \"Kaiti SC\", serif", "All Fonts"),
    font("Kaiti SC 楷体-简", "\"Kaiti SC\", STKaiti, KaiTi, serif", "All Fonts"),
    font("Malgun Gothic", "\"Malgun Gothic\", \"Apple SD Gothic Neo\", sans-serif", "All Fonts"),
    font("Meiryo", "Meiryo, \"Yu Gothic\", sans-serif", "All Fonts"),
    font("Menlo", "Menlo, Monaco, Consolas, monospace", "All Fonts"),
    font("Microsoft JhengHei", "\"Microsoft JhengHei\", \"PingFang TC\", sans-serif", "All Fonts"),
    font("Microsoft Sans Serif", "\"Microsoft Sans Serif\", Arial, sans-serif", "All Fonts"),
    font("Microsoft YaHei 微软雅黑", "\"Microsoft YaHei\", \"PingFang SC\", \"Hiragino Sans GB\", sans-serif", "All Fonts"),
    font("Microsoft YaHei UI", "\"Microsoft YaHei UI\", \"Microsoft YaHei\", \"PingFang SC\", sans-serif", "All Fonts"),
    font("Monaco", "Monaco, Menlo, Consolas, monospace", "All Fonts"),
    font("Noto Sans CJK", "\"DAVA Noto Sans CJK\", \"Noto Sans CJK SC\", \"Source Han Sans SC\", \"Microsoft YaHei\", \"PingFang SC\", sans-serif", "All Fonts"),
    font("Noto Serif CJK", "\"DAVA Noto Serif CJK\", \"Noto Serif CJK SC\", \"Source Han Serif SC\", SimSun, serif", "All Fonts"),
    font("Palatino", "Palatino, \"Palatino Linotype\", \"Book Antiqua\", serif", "All Fonts"),
    font("PingFang SC 苹方", "\"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", sans-serif", "All Fonts"),
    font("Segoe UI", "\"Segoe UI\", \"Aptos\", Arial, sans-serif", "All Fonts"),
    font("SimHei 黑体", "SimHei, \"Heiti SC\", \"Microsoft YaHei\", sans-serif", "All Fonts"),
    font("SimSun 宋体", "SimSun, STSong, \"Songti SC\", serif", "All Fonts"),
    font("Songti SC 华文宋体", "\"Songti SC\", STSong, SimSun, serif", "All Fonts"),
    font("Source Han Sans 思源黑体", "\"Source Han Sans SC\", \"Noto Sans CJK SC\", \"Microsoft YaHei\", \"PingFang SC\", sans-serif", "All Fonts"),
    font("Source Han Serif 思源宋体", "\"Source Han Serif SC\", \"Noto Serif CJK SC\", SimSun, \"Songti SC\", serif", "All Fonts"),
    font("Tahoma", "Tahoma, Geneva, sans-serif", "All Fonts"),
    font("Times New Roman", "\"Times New Roman\", Times, serif", "All Fonts"),
    font("Trebuchet MS", "\"Trebuchet MS\", Arial, sans-serif", "All Fonts"),
    font("Verdana", "Verdana, Geneva, sans-serif", "All Fonts"),
    font("Yu Gothic", "\"Yu Gothic\", YuGothic, Meiryo, sans-serif", "All Fonts")
  ];
})();
