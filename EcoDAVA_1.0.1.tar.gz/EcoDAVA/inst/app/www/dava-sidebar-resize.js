(function () {
  "use strict";

  var selector = ".bslib-sidebar-layout > .sidebar, .bslib-sidebar-layout > aside.sidebar";
  var label = "Drag to resize the sidebar; double-click to restore automatic width";

  function limits(layout) {
    var rem = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
    return {
      min: Math.max(10.5 * rem, 136),
      max: Math.min(30 * rem, layout.clientWidth * 0.42)
    };
  }

  function setWidth(layout, sidebar, width) {
    var range = limits(layout);
    var next = Math.max(range.min, Math.min(range.max, width));
    layout.style.setProperty("--_sidebar-width", Math.round(next) + "px", "important");
    sidebar.setAttribute("data-dava-sidebar-manual-width", String(Math.round(next)));
    return next;
  }

  function install(sidebar) {
    if (!sidebar || sidebar.dataset.davaResizable === "true") return;
    var layout = sidebar.parentElement;
    if (!layout || !layout.classList.contains("bslib-sidebar-layout")) return;
    sidebar.dataset.davaResizable = "true";

    var originalValue = layout.style.getPropertyValue("--_sidebar-width");
    var originalPriority = layout.style.getPropertyPriority("--_sidebar-width");
    var handle = document.createElement("div");
    handle.className = "dava-sidebar-resizer";
    handle.tabIndex = 0;
    handle.setAttribute("role", "separator");
    handle.setAttribute("aria-orientation", "vertical");
    handle.setAttribute("aria-label", label);
    handle.setAttribute("title", label);
    sidebar.appendChild(handle);

    function reset() {
      if (originalValue) layout.style.setProperty("--_sidebar-width", originalValue, originalPriority);
      else layout.style.removeProperty("--_sidebar-width");
      sidebar.removeAttribute("data-dava-sidebar-manual-width");
    }

    handle.addEventListener("dblclick", function (event) {
      event.preventDefault();
      reset();
    });
    handle.addEventListener("keydown", function (event) {
      if (event.key === "Home") { event.preventDefault(); reset(); return; }
      if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
      event.preventDefault();
      var direction = event.key === "ArrowRight" ? 1 : -1;
      var right = layout.classList.contains("sidebar-right");
      setWidth(layout, sidebar, sidebar.getBoundingClientRect().width + direction * (right ? -10 : 10));
    });
    handle.addEventListener("pointerdown", function (event) {
      if (event.button !== 0) return;
      event.preventDefault();
      var startX = event.clientX;
      var startWidth = sidebar.getBoundingClientRect().width;
      var right = layout.classList.contains("sidebar-right");
      document.documentElement.classList.add("dava-sidebar-resizing");
      function move(moveEvent) {
        var delta = moveEvent.clientX - startX;
        setWidth(layout, sidebar, startWidth + delta * (right ? -1 : 1));
      }
      function stop() {
        document.documentElement.classList.remove("dava-sidebar-resizing");
        document.removeEventListener("pointermove", move);
        document.removeEventListener("pointerup", stop);
        document.removeEventListener("pointercancel", stop);
      }
      document.addEventListener("pointermove", move);
      document.addEventListener("pointerup", stop);
      document.addEventListener("pointercancel", stop);
    });
  }

  function scan(root) {
    if (root && root.matches && root.matches(selector)) install(root);
    Array.prototype.forEach.call((root || document).querySelectorAll(selector), install);
  }

  document.addEventListener("DOMContentLoaded", function () { scan(document); });
  new MutationObserver(function (records) {
    records.forEach(function (record) {
      Array.prototype.forEach.call(record.addedNodes, function (node) {
        if (node.nodeType === 1) scan(node);
      });
    });
  }).observe(document.documentElement, { childList: true, subtree: true });
  scan(document);
})();
