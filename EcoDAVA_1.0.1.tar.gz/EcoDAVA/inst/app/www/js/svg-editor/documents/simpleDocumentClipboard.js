(function () {
  "use strict";

  var store = null;
  var bound = false;

  function isTextTarget(target) {
    if (!target || !target.tagName) return false;
    var tag = target.tagName.toLowerCase();
    return tag === "input" || tag === "textarea" || tag === "select" || target.isContentEditable;
  }

  function isPanelTarget(target) {
    return !!(target && target.closest && target.closest(".dava-symbol-panel, .dava-equation-panel, .dava-pdf-import-panel"));
  }

  function selectedElements(canvas) {
    try {
      if (canvas && typeof canvas.getSelectedElements === "function") {
        return (canvas.getSelectedElements() || []).filter(Boolean);
      }
    } catch (error) {
      console.warn("DAVA clipboard: cannot read selected elements.", error);
    }
    return [];
  }

  function serializeSelection() {
    var canvas = store && store.getSvgCanvas ? store.getSvgCanvas() : null;
    var items = selectedElements(canvas);
    if (!items.length) return "";
    var serializer = new XMLSerializer();
    return items.map(function (node) {
      return serializer.serializeToString(node);
    }).join("\n");
  }

  function looksLikeSvgFragment(text) {
    return /<(svg|g|path|text|rect|circle|ellipse|line|polygon|polyline|image|use)\b/i.test(text || "");
  }

  function prefixIds(svgText) {
    var prefix = "clip-" + Date.now().toString(36) + "-" + Math.floor(Math.random() * 10000).toString(36) + "-";
    var idMap = {};
    var out = svgText.replace(/\sid=(["'])([^"']+)\1/g, function (all, quote, id) {
      var next = prefix + id;
      idMap[id] = next;
      return " id=" + quote + next + quote;
    });
    Object.keys(idMap).forEach(function (oldId) {
      var nextId = idMap[oldId];
      var urlRe = new RegExp("url\\(#" + oldId.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\)", "g");
      out = out.replace(urlRe, "url(#" + nextId + ")");
      var hrefRe = new RegExp("([\"'])#" + oldId.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\1", "g");
      out = out.replace(hrefRe, "$1#" + nextId + "$1");
    });
    return out;
  }

  function importFragment(fragment) {
    var safe = prefixIds(fragment);
    var wrapped = /<svg[\s>]/i.test(safe) ? safe : "<svg xmlns=\"http://www.w3.org/2000/svg\">" + safe + "</svg>";
    if (store && typeof store.importSvgFragment === "function") {
      store.importSvgFragment(wrapped);
    }
  }

  function bind(documentStore) {
    store = documentStore;
    if (bound) return;
    bound = true;
    document.addEventListener("keydown", function (event) {
      if (!(event.ctrlKey || event.metaKey) || event.altKey || isTextTarget(event.target) || isPanelTarget(event.target)) return;
      var key = String(event.key || "").toLowerCase();
      if (key === "c") {
        var fragment = serializeSelection();
        if (fragment && navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(fragment).catch(function (error) {
            console.warn("DAVA clipboard: system clipboard write was blocked; native SVG-Edit copy can still run.", error);
          });
        }
        return;
      }
      if (key === "v") {
        if (!navigator.clipboard || !navigator.clipboard.readText) return;
        navigator.clipboard.readText().then(function (text) {
          if (!looksLikeSvgFragment(text)) return;
          event.preventDefault();
          importFragment(text);
        }).catch(function (error) {
          console.warn("Browser restriction reading systemCutboard，please use SVG-Edit nativePasteor allowCutBoard permissions。", error);
        });
      }
    }, true);
    document.addEventListener("paste", function (event) {
      if (isTextTarget(event.target) || isPanelTarget(event.target)) return;
      var data = event.clipboardData;
      var text = data && data.getData ? data.getData("text/plain") : "";
      if (!looksLikeSvgFragment(text)) return;
      event.preventDefault();
      importFragment(text);
    }, true);
  }

  window.DavaSimpleDocumentClipboard = {
    bind: bind
  };
})();
