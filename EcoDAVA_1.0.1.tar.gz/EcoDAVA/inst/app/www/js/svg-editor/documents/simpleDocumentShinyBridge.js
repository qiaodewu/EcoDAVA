(function () {
  "use strict";

  function nsPrefix() {
    try {
      var frame = window.frameElement;
      var root = frame && frame.closest ? frame.closest("[data-dava-svgedit-root='1']") : null;
      return root ? root.getAttribute("data-ns-prefix") || "" : "";
    } catch (error) {
      return "";
    }
  }

  function shiny() {
    try {
      return window.parent && window.parent.Shiny ? window.parent.Shiny : window.Shiny;
    } catch (error) {
      return null;
    }
  }

  function sendInput(name, payload) {
    var api = shiny();
    if (!api || typeof api.setInputValue !== "function") return false;
    var value = payload || {};
    if (!value.timestamp) value.timestamp = Date.now();
    api.setInputValue(nsPrefix() + name, value, { priority: "event" });
    return true;
  }

  window.DavaSimpleDocumentShinyBridge = {
    sendInput: sendInput,
    sendCreated: function (doc) {
      return sendInput("svg_editor_document_created", {
        documentId: doc.id,
        name: doc.name,
        index: doc.index,
        timestamp: Date.now()
      });
    },
    sendActivated: function (doc) {
      return sendInput("svg_editor_document_activated", {
        documentId: doc.id,
        name: doc.name,
        timestamp: Date.now()
      });
    },
    sendDirtyChanged: function (doc) {
      return sendInput("svg_editor_document_dirty_changed", {
        documentId: doc.id,
        name: doc.name,
        dirty: !!doc.dirty,
        timestamp: Date.now()
      });
    },
    sendSaveToGallery: function (doc) {
      return sendInput("svg_editor_save_document_to_gallery", {
        documentId: doc.id,
        name: doc.name,
        svgString: doc.svgString || "",
        createdAt: doc.createdAt,
        updatedAt: Date.now(),
        timestamp: Date.now()
      });
    }
  };
})();
