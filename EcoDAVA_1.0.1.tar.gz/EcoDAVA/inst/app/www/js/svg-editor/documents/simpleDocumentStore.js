(function () {
  "use strict";

  var documents = [];
  var activeDocumentId = "";
  var nextIndex = 1;
  var env = {};
  var initialized = false;
  var suppressDirty = false;
  var dirtyBound = false;
  var initialEditorSettings = null;
  var settingsPersistTimers = {};

  function now() {
    return Date.now();
  }

  function uuid() {
    return "doc-" + now().toString(36) + "-" + Math.floor(Math.random() * 100000).toString(36);
  }

  function blankSvg() {
    return "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"960\" height=\"720\" viewBox=\"0 0 960 720\"><defs></defs></svg>";
  }

  function getSvgCanvas() {
    try {
      return env.getSvgCanvas ? env.getSvgCanvas() : null;
    } catch (error) {
      console.warn("DAVA documents: svgCanvas is not ready.", error);
      return null;
    }
  }

  function getAllDocuments() {
    return documents.slice();
  }

  function getDocument(docId) {
    return documents.filter(function (doc) { return doc.id === docId; })[0] || null;
  }

  function getActiveDocument() {
    return getDocument(activeDocumentId);
  }

  function notifyTabs() {
    if (window.DavaSimpleDocumentTabs) window.DavaSimpleDocumentTabs.render();
  }

  function shinyBridge() {
    return window.DavaSimpleDocumentShinyBridge || null;
  }

  function serializeActiveSvg() {
    try {
      if (env.getSvgString) return env.getSvgString();
    } catch (error) {
      console.warn("DAVA documents: getSvgString failed.", error);
    }
    try {
      var canvas = getSvgCanvas();
      var root = canvas && canvas.getSvgContent ? canvas.getSvgContent() : document.querySelector("svg#svgcontent, #svgcontent svg, svg");
      return root ? new XMLSerializer().serializeToString(root) : blankSvg();
    } catch (error2) {
      console.warn("DAVA documents: SVG serialization fallback failed.", error2);
      return blankSvg();
    }
  }

  function hasStoredPan(viewState) {
    return !!(viewState && Number.isFinite(viewState.panX) && Number.isFinite(viewState.panY));
  }

  function withoutDirty(callback) {
    suppressDirty = true;
    try {
      return callback();
    } finally {
      window.setTimeout(function () { suppressDirty = false; }, 250);
    }
  }

  function loadSvgIntoEditor(svgString, doc) {
    doc = doc || getActiveDocument() || {};
    return withoutDirty(function () {
      try {
        if (env.loadSvgString) {
          env.loadSvgString(svgString || blankSvg(), {
            preserve_layout: true,
            silent: true,
            allow_blank_clear: true,
            center_canvas: !hasStoredPan(doc.viewState),
            canvasWidth: doc.canvas && doc.canvas.width || 960,
            canvasHeight: doc.canvas && doc.canvas.height || 720
          });
        }
      } catch (error) {
        console.warn("DAVA documents: loadSvgString failed.", error);
      }
    });
  }

  function captureCanvasState() {
    var canvas = getSvgCanvas();
    var width = 960;
    var height = 720;
    var unit = "px";
    var viewBox = "0 0 960 720";
    try {
      var res = canvas && typeof canvas.getResolution === "function" ? canvas.getResolution() : null;
      if (res) {
        width = Number(res.w || res.width || width) || width;
        height = Number(res.h || res.height || height) || height;
      }
      var content = canvas && typeof canvas.getSvgContent === "function" ? canvas.getSvgContent() : null;
      if (content) {
        width = Number(parseFloat(content.getAttribute("width"))) || width;
        height = Number(parseFloat(content.getAttribute("height"))) || height;
        viewBox = content.getAttribute("viewBox") || ("0 0 " + width + " " + height);
      }
    } catch (error) {
      console.warn("DAVA documents: capture canvas state failed.", error);
    }
    return { width: width, height: height, unit: unit, viewBox: viewBox };
  }

  function clonePlainObject(value) {
    if (!value || typeof value !== "object") return value;
    try {
      return JSON.parse(JSON.stringify(value));
    } catch (error) {
      var copy = {};
      Object.keys(value).forEach(function (key) {
        var item = value[key];
        if (item == null || typeof item !== "object") copy[key] = item;
      });
      return copy;
    }
  }

  function readPreference(configObj, key, fallback) {
    try {
      if (configObj && typeof configObj.pref === "function") {
        var value = configObj.pref(key);
        return value == null ? fallback : value;
      }
    } catch (error) {
      console.warn("DAVA documents: read editor preference failed.", key, error);
    }
    return fallback;
  }

  function writePreference(configObj, key, value) {
    if (value === undefined) return;
    try {
      if (configObj && typeof configObj.pref === "function") configObj.pref(key, value);
    } catch (error) {
      console.warn("DAVA documents: write editor preference failed.", key, error);
    }
  }

  function captureCurrentProperties(canvas) {
    var properties = {};
    [
      "fill",
      "fill_opacity",
      "stroke",
      "stroke_opacity",
      "stroke_width",
      "stroke_dasharray",
      "stroke_linejoin",
      "stroke_linecap",
      "opacity"
    ].forEach(function (key) {
      try {
        if (canvas && typeof canvas.getColor === "function" && (key === "fill" || key === "stroke")) {
          properties[key] = canvas.getColor(key);
        } else if (canvas && typeof canvas.getStrokeWidth === "function" && key === "stroke_width") {
          properties[key] = canvas.getStrokeWidth();
        } else if (canvas && typeof canvas.getCurShape === "function" && canvas.getCurShape()) {
          properties[key] = canvas.getCurShape()[key];
        }
      } catch (error) {
        properties[key] = undefined;
      }
    });
    try {
      if (canvas && typeof canvas.getCurShape === "function") properties.curShape = clonePlainObject(canvas.getCurShape());
    } catch (error2) {
      properties.curShape = null;
    }
    try {
      if (canvas && typeof canvas.getCurText === "function") {
        properties.curText = {
          fill: canvas.getCurText("fill"),
          stroke_width: canvas.getCurText("stroke_width"),
          font_size: canvas.getCurText("font_size"),
          font_family: canvas.getCurText("font_family")
        };
      }
    } catch (error3) {
      properties.curText = null;
    }
    return properties;
  }

  function getGridVisible() {
    var configObj = window.svgEditor && window.svgEditor.configObj ? window.svgEditor.configObj : null;
    var config = configObj && configObj.curConfig ? configObj.curConfig : {};
    var grid = document.getElementById("canvasGrid");
    var button = document.getElementById("view_grid");
    if (window.DavaSvgGridControl && typeof window.DavaSvgGridControl.getVisible === "function") {
      return !!window.DavaSvgGridControl.getVisible();
    }
    if (button && typeof button.pressed !== "undefined") return !!button.pressed;
    if (grid) return grid.style.display !== "none" && grid.getAttribute("display") !== "none";
    return !!config.showGrid;
  }

  function restoreGridState(visible) {
    var desired = !!visible;
    var configObj = window.svgEditor && window.svgEditor.configObj ? window.svgEditor.configObj : null;
    var config = configObj && configObj.curConfig ? configObj.curConfig : null;
    var grid = document.getElementById("canvasGrid");
    var button = document.getElementById("view_grid");
    try {
      if (config) config.showGrid = desired;
      if (window.DavaSvgGridControl && typeof window.DavaSvgGridControl.setVisible === "function") {
        window.DavaSvgGridControl.setVisible(desired);
      } else if (button && typeof button.click === "function" && !!button.pressed !== desired) {
        button.click();
      }
      if (config) config.showGrid = desired;
      if (grid) grid.style.display = desired ? "block" : "none";
      if (button) button.pressed = desired;
    } catch (error) {
      console.warn("DAVA documents: restore grid state failed.", error);
    }
  }

  function captureEditorSettings() {
    var editor = window.svgEditor || null;
    var canvas = getSvgCanvas();
    var configObj = editor && editor.configObj ? editor.configObj : null;
    var config = configObj && configObj.curConfig ? configObj.curConfig : {};
    var workarea = editor && editor.workarea ? editor.workarea : document.getElementById("workarea");
    var wireframeButton = document.getElementById("tool_wireframe");
    return {
      showGrid: getGridVisible(),
      gridSnapping: !!config.gridSnapping,
      snappingStep: config.snappingStep == null ? 10 : config.snappingStep,
      gridColor: config.gridColor || "#000",
      showRulers: config.showRulers !== false,
      baseUnit: config.baseUnit || "px",
      dynamicOutput: !!config.dynamicOutput,
      wireframe: !!((workarea && workarea.classList && workarea.classList.contains("wireframe")) || (wireframeButton && wireframeButton.pressed)),
      backgroundColor: readPreference(configObj, "bkgd_color", "#fff"),
      backgroundUrl: readPreference(configObj, "bkgd_url", ""),
      imageSaveMode: readPreference(configObj, "img_save", "embed"),
      currentMode: canvas && typeof canvas.getMode === "function" ? canvas.getMode() : "select",
      currentProperties: captureCurrentProperties(canvas)
    };
  }

  function restoreCurrentProperties(canvas, settings) {
    var props = settings && settings.currentProperties ? settings.currentProperties : null;
    if (!canvas || !props) return;
    try {
      if (props.curShape && typeof canvas.setCurProperties === "function") {
        Object.keys(props.curShape).forEach(function (key) {
          if (props.curShape[key] !== undefined) canvas.setCurProperties(key, props.curShape[key]);
        });
      }
    } catch (error) {
      console.warn("DAVA documents: restore current shape properties failed.", error);
    }
    try {
      if (props.fill !== undefined && typeof canvas.setColor === "function") canvas.setColor("fill", props.fill);
      if (props.stroke !== undefined && typeof canvas.setColor === "function") canvas.setColor("stroke", props.stroke);
      if (props.stroke_width !== undefined && typeof canvas.setStrokeWidth === "function") canvas.setStrokeWidth(props.stroke_width);
    } catch (error2) {
      console.warn("DAVA documents: restore paint properties failed.", error2);
    }
  }

  function syncPreferenceDialogs(settings) {
    try {
      var prefs = document.getElementById("se-edit-prefs");
      if (prefs) {
        prefs.setAttribute("showgrid", String(!!settings.showGrid));
        prefs.setAttribute("gridsnappingon", String(!!settings.gridSnapping));
        prefs.setAttribute("gridsnappingstep", settings.snappingStep);
        prefs.setAttribute("gridcolor", settings.gridColor || "#000");
        prefs.setAttribute("showrulers", String(settings.showRulers !== false));
        prefs.setAttribute("baseunit", settings.baseUnit || "px");
        prefs.setAttribute("bgurl", settings.backgroundUrl || "");
      }
      var props = document.getElementById("se-img-prop");
      var canvas = getSvgCanvas();
      if (props && canvas) {
        var res = typeof canvas.getResolution === "function" ? canvas.getResolution() : null;
        props.setAttribute("save", settings.imageSaveMode || "embed");
        if (res) {
          props.setAttribute("width", res.w || res.width || 960);
          props.setAttribute("height", res.h || res.height || 720);
        }
        if (typeof canvas.getDocumentTitle === "function") props.setAttribute("title", canvas.getDocumentTitle() || "");
      }
    } catch (error) {
      console.warn("DAVA documents: sync preference dialogs failed.", error);
    }
  }

  function restoreWireframeState(enabled) {
    try {
      var editor = window.svgEditor || null;
      var workarea = editor && editor.workarea ? editor.workarea : document.getElementById("workarea");
      var button = document.getElementById("tool_wireframe");
      var rules = document.getElementById("wireframe_rules");
      if (workarea && workarea.classList) workarea.classList.toggle("wireframe", !!enabled);
      if (button) button.pressed = !!enabled;
      if (!rules && enabled) {
        rules = document.createElement("style");
        rules.setAttribute("id", "wireframe_rules");
        document.getElementsByTagName("head")[0].appendChild(rules);
      }
      if (rules && !enabled) rules.textContent = "";
      if (editor && typeof editor.updateWireFrame === "function") editor.updateWireFrame();
    } catch (error) {
      console.warn("DAVA documents: restore wireframe state failed.", error);
    }
  }

  function restoreEditorSettings(settings) {
    if (!settings) return;
    var editor = window.svgEditor || null;
    var canvas = getSvgCanvas();
    var configObj = editor && editor.configObj ? editor.configObj : null;
    var config = configObj && configObj.curConfig ? configObj.curConfig : null;
    try {
      if (config) {
        config.showGrid = !!settings.showGrid;
        config.gridSnapping = !!settings.gridSnapping;
        config.snappingStep = settings.snappingStep == null ? 10 : settings.snappingStep;
        config.gridColor = settings.gridColor || "#000";
        config.showRulers = settings.showRulers !== false;
        config.baseUnit = settings.baseUnit || "px";
        config.dynamicOutput = !!settings.dynamicOutput;
      }
      writePreference(configObj, "bkgd_color", settings.backgroundColor);
      writePreference(configObj, "bkgd_url", settings.backgroundUrl || "");
      writePreference(configObj, "img_save", settings.imageSaveMode || "embed");
      if (editor && typeof editor.setBackground === "function") {
        editor.setBackground(settings.backgroundColor, settings.backgroundUrl || "");
      } else if (canvas && typeof canvas.setBackground === "function") {
        canvas.setBackground(settings.backgroundColor, settings.backgroundUrl || "");
      }
      if (canvas && config && typeof canvas.setConfig === "function") canvas.setConfig(config);
      if (editor && editor.rulers && typeof editor.rulers.display === "function") {
        editor.rulers.display(settings.showRulers !== false);
      }
      if (editor && editor.rulers && settings.showRulers !== false && typeof editor.rulers.updateRulers === "function") {
        editor.rulers.updateRulers();
      }
      restoreGridState(!!settings.showGrid);
      restoreWireframeState(!!settings.wireframe);
      restoreCurrentProperties(canvas, settings);
      syncPreferenceDialogs(settings);
      if (editor && typeof editor.updateCanvas === "function") editor.updateCanvas(false);
    } catch (error) {
      console.warn("DAVA documents: restore editor settings failed.", error);
    }
  }

  function captureViewState() {
    var canvas = getSvgCanvas();
    var zoom = 1;
    var scrollLeft = 0;
    var scrollTop = 0;
    try {
      if (canvas && typeof canvas.getZoom === "function") zoom = canvas.getZoom();
    } catch (error) {
      zoom = 1;
    }
    try {
      var editor = window.svgEditor || null;
      var workarea = editor && editor.workarea ? editor.workarea : document.getElementById("workarea");
      if (workarea) {
        scrollLeft = workarea.scrollLeft || 0;
        scrollTop = workarea.scrollTop || 0;
      }
    } catch (error2) {
      scrollLeft = 0;
      scrollTop = 0;
    }
    return { zoom: zoom || 1, panX: scrollLeft, panY: scrollTop, initialized: true };
  }

  function restoreViewState(viewState) {
    var canvas = getSvgCanvas();
    if (!viewState || !viewState.initialized) return;
    try {
      if (canvas && viewState && viewState.zoom && typeof canvas.setZoom === "function") {
        canvas.setZoom(viewState.zoom);
      }
    } catch (error) {
      console.warn("DAVA documents: restore zoom failed.", error);
    }
    window.setTimeout(function () {
      try {
        var editor = window.svgEditor || null;
        var workarea = editor && editor.workarea ? editor.workarea : document.getElementById("workarea");
        if (workarea && hasStoredPan(viewState)) {
          workarea.scrollLeft = viewState.panX || 0;
          workarea.scrollTop = viewState.panY || 0;
        }
        if (editor && editor.rulers && typeof editor.rulers.manageScroll === "function") {
          editor.rulers.manageScroll();
        }
      } catch (error2) {
        console.warn("DAVA documents: restore pan failed.", error2);
      }
    }, 0);
  }

  function clearSelection() {
    var canvas = getSvgCanvas();
    try {
      if (canvas && typeof canvas.clearSelection === "function") canvas.clearSelection(true);
    } catch (error) {
      console.warn("DAVA documents: clear selection failed.", error);
    }
  }

  function switchToSelectTool() {
    var canvas = getSvgCanvas();
    try {
      if (canvas && typeof canvas.setMode === "function") {
        canvas.setMode("select");
        return;
      }
    } catch (error) {
      console.warn("DAVA documents: setMode(select) failed.", error);
    }
    var tool = document.getElementById("tool_select");
    if (tool) tool.click();
  }

  function clearUndoHistory() {
    var canvas = getSvgCanvas();
    var mgr = canvas && (canvas.undoMgr || canvas.undoManager || canvas.undoManager_);
    try {
      if (mgr && typeof mgr.resetUndoStack === "function") mgr.resetUndoStack();
      if (mgr && typeof mgr.resetRedoStack === "function") mgr.resetRedoStack();
      if (mgr && Array.isArray(mgr.undoStack)) mgr.undoStack.length = 0;
      if (mgr && Array.isArray(mgr.redoStack)) mgr.redoStack.length = 0;
    } catch (error) {
      console.warn("DAVA documents: clear undo history fallback failed.", error);
    }
  }

  function createDoc(options) {
    options = options || {};
    var index = options.index || nextIndex++;
    if (index >= nextIndex) nextIndex = index + 1;
    var doc = {
      id: options.id || uuid(),
      index: index,
      name: options.name || ("Not yettitle-" + index),
      svgString: options.svgString || blankSvg(),
      dirty: !!options.dirty,
      savedToGallery: !!options.savedToGallery,
      createdAt: options.createdAt || now(),
      updatedAt: options.updatedAt || now(),
      canvas: options.canvas || { width: 960, height: 720, unit: "px", viewBox: "0 0 960 720" },
      viewState: options.viewState || { zoom: 1, panX: null, panY: null, initialized: false },
      settings: clonePlainObject(options.settings || initialEditorSettings) || captureEditorSettings(),
      source: options.source || { type: "blank", origin: null }
    };
    documents.push(doc);
    return doc;
  }

  function saveActiveDocumentSnapshot() {
    var doc = getActiveDocument();
    if (!doc) return null;
    doc.svgString = serializeActiveSvg();
    doc.canvas = captureCanvasState();
    doc.viewState = captureViewState();
    doc.settings = captureEditorSettings();
    doc.updatedAt = now();
    return doc;
  }

  function saveDocumentRuntimeState(docId) {
    var doc = getDocument(docId || activeDocumentId);
    if (!doc) return null;
    if (doc.id !== activeDocumentId) return doc;
    doc.canvas = captureCanvasState();
    doc.viewState = captureViewState();
    doc.settings = captureEditorSettings();
    doc.updatedAt = now();
    return doc;
  }

  function saveActiveDocumentRuntimeState() {
    return saveDocumentRuntimeState(activeDocumentId);
  }

  function clearDocumentRuntimeTimers(docId) {
    var timers = settingsPersistTimers[docId] || [];
    timers.forEach(function (timer) { window.clearTimeout(timer); });
    delete settingsPersistTimers[docId];
  }

  function rememberDocumentRuntimeTimer(docId, timer) {
    if (!settingsPersistTimers[docId]) settingsPersistTimers[docId] = [];
    settingsPersistTimers[docId].push(timer);
  }

  function flushDocumentRuntimeState(docId) {
    if (!docId) return null;
    clearDocumentRuntimeTimers(docId);
    return saveDocumentRuntimeState(docId);
  }

  function scheduleSaveDocumentRuntimeState(docId, markAsDirty) {
    if (suppressDirty) return;
    docId = docId || activeDocumentId;
    clearDocumentRuntimeTimers(docId);
    rememberDocumentRuntimeTimer(docId, window.setTimeout(function () {
      clearDocumentRuntimeTimers(docId);
      if (activeDocumentId !== docId) return;
      saveDocumentRuntimeState(docId);
      if (markAsDirty) markDirty(docId, true);
      rememberDocumentRuntimeTimer(docId, window.setTimeout(function () {
        if (activeDocumentId !== docId) return;
        saveDocumentRuntimeState(docId);
      }, 120));
    }, 0));
  }

  function scheduleRestoreDocumentRuntimeState(doc) {
    if (!doc) return;
    [0, 40, 120, 260, 600, 1000].forEach(function (delay) {
      window.setTimeout(function () {
        if (!doc || activeDocumentId !== doc.id) return;
        withoutDirty(function () {
          restoreEditorSettings(doc.settings);
          restoreViewState(doc.viewState);
          clearSelection();
        });
      }, delay);
    });
  }

  function hasRealContent(svgString) {
    return /<(path|rect|circle|ellipse|line|polygon|polyline|text|image|g|use)\b/i.test((svgString || "").replace(/<defs[\s\S]*?<\/defs>/gi, ""));
  }

  function createInitialDocument() {
    if (documents.length) return getActiveDocument();
    var currentSvg = serializeActiveSvg();
    var hasContent = hasRealContent(currentSvg);
    var doc = createDoc({
      index: 1,
      name: "Not yettitle-1",
      svgString: hasContent ? currentSvg : blankSvg(),
      dirty: hasContent,
      canvas: hasContent ? captureCanvasState() : { width: 960, height: 720, unit: "px", viewBox: "0 0 960 720" },
      viewState: hasContent ? captureViewState() : { zoom: 1, panX: null, panY: null, initialized: false },
      settings: captureEditorSettings(),
      source: hasContent ? { type: "r-plot", origin: null } : { type: "blank", origin: null }
    });
    activeDocumentId = doc.id;
    if (!hasContent) loadSvgIntoEditor(doc.svgString, doc);
    notifyTabs();
    return doc;
  }

  function createNewDocument(options) {
    options = options || {};
    flushDocumentRuntimeState(activeDocumentId);
    saveActiveDocumentSnapshot();
    var doc = createDoc({
      name: options.name,
      svgString: options.svgString || blankSvg(),
      dirty: !!options.dirty,
      canvas: options.canvas || { width: 960, height: 720, unit: "px", viewBox: "0 0 960 720" },
      viewState: options.viewState || { zoom: 1, panX: null, panY: null, initialized: false },
      settings: clonePlainObject(options.settings || initialEditorSettings) || captureEditorSettings(),
      source: options.source || { type: "blank", origin: null }
    });
    activateDocument(doc.id, { skipSnapshot: true, created: true });
    var bridge = shinyBridge();
    if (bridge && bridge.sendCreated) bridge.sendCreated(doc);
    return doc;
  }

  function activateDocument(docId, options) {
    options = options || {};
    var target = getDocument(docId);
    if (!target || target.id === activeDocumentId) return target;
    flushDocumentRuntimeState(activeDocumentId);
    if (!options.skipSnapshot) saveActiveDocumentSnapshot();
    clearDocumentRuntimeTimers(activeDocumentId);
    withoutDirty(function () {
      clearSelection();
      activeDocumentId = target.id;
      clearDocumentRuntimeTimers(target.id);
      target.settings = clonePlainObject(target.settings || initialEditorSettings) || captureEditorSettings();
      restoreEditorSettings(target.settings);
      loadSvgIntoEditor(target.svgString || blankSvg(), target);
      restoreEditorSettings(target.settings);
      restoreViewState(target.viewState);
      clearUndoHistory();
      switchToSelectTool();
    });
    scheduleRestoreDocumentRuntimeState(target);
    notifyTabs();
    var bridge = shinyBridge();
    if (bridge && bridge.sendActivated) bridge.sendActivated(target);
    return target;
  }

  function markDirty(docId, dirty) {
    var doc = getDocument(docId || activeDocumentId);
    if (!doc) return;
    var nextDirty = dirty !== false;
    if (doc.dirty === nextDirty) return;
    doc.dirty = nextDirty;
    doc.updatedAt = now();
    notifyTabs();
    var bridge = shinyBridge();
    if (bridge && bridge.sendDirtyChanged) bridge.sendDirtyChanged(doc);
  }

  function eventTouchesDocumentSettings(event) {
    var path = typeof event.composedPath === "function" ? event.composedPath() : [];
    var settingIds = [
      "se-edit-prefs",
      "se-img-prop",
      "svg_docprops",
      "svg_docprops_container",
      "svg_docprops_docprops",
      "change_resolution",
      "image_save_opts",
      "view_grid",
      "tool_wireframe",
      "tool_docprops",
      "tool_editor_prefs",
      "tool_rulers",
      "rulers",
      "canvas_panel",
      "canvas_title",
      "canvas_width",
      "canvas_height",
      "canvas_portrait",
      "canvas_landscape",
      "resolution",
      "image_embed",
      "image_ref"
    ];
    var selectors = [
      "#se-edit-prefs",
      "#se-img-prop",
      "#svg_docprops",
      "#svg_docprops_container",
      "#svg_docprops_docprops",
      "#change_resolution",
      "#image_save_opts",
      "#view_grid",
      "#tool_wireframe",
      "#tool_docprops",
      "#tool_editor_prefs",
      "#tool_rulers",
      "#rulers",
      "#canvas_panel",
      "#canvas_title",
      "#canvas_width",
      "#canvas_height"
    ].join(", ");
    for (var i = 0; i < path.length; i += 1) {
      var node = path[i];
      if (node && node.id && settingIds.indexOf(node.id) !== -1) return true;
      if (node && node.closest && node.closest(selectors)) return true;
    }
    var target = event.target;
    return !!(target && target.closest && target.closest(selectors));
  }

  function modalChoice(doc, callback) {
    var overlay = document.createElement("div");
    overlay.className = "dava-svg-document-modal-overlay";
    var modal = document.createElement("div");
    modal.className = "dava-svg-document-modal";
    var title = document.createElement("div");
    title.className = "dava-svg-document-modal-title";
    title.textContent = "CloseCanvas";
    var body = document.createElement("div");
    body.className = "dava-svg-document-modal-body";
    body.textContent = "YesNowill「" + doc.name + "」Save to the overall beautified gallery？";
    var actions = document.createElement("div");
    actions.className = "dava-svg-document-modal-actions";
    [
      ["save", "Save andClose"],
      ["discard", "Do not saveClose"],
      ["cancel", "Cancel"]
    ].forEach(function (item) {
      var button = document.createElement("button");
      button.type = "button";
      button.className = "dava-svg-document-modal-button " + item[0];
      button.textContent = item[1];
      button.addEventListener("click", function () {
        document.body.removeChild(overlay);
        callback(item[0]);
      });
      actions.appendChild(button);
    });
    modal.appendChild(title);
    modal.appendChild(body);
    modal.appendChild(actions);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
  }

  function saveDocumentToGallery(doc) {
    doc.svgString = doc.id === activeDocumentId ? serializeActiveSvg() : (doc.svgString || blankSvg());
    doc.updatedAt = now();
    var bridge = shinyBridge();
    if (bridge && bridge.sendSaveToGallery) bridge.sendSaveToGallery(doc);
    doc.savedToGallery = true;
    doc.dirty = false;
  }

  function removeDocument(docId) {
    var wasActive = docId === activeDocumentId;
    var index = documents.findIndex(function (doc) { return doc.id === docId; });
    if (index < 0) return;
    clearDocumentRuntimeTimers(docId);
    documents.splice(index, 1);
    if (!documents.length) {
      activeDocumentId = "";
      nextIndex = 1;
      var fresh = createDoc({
        index: 1,
        name: "Not yettitle-1",
        svgString: blankSvg(),
        dirty: false,
        canvas: { width: 960, height: 720, unit: "px", viewBox: "0 0 960 720" },
        viewState: { zoom: 1, panX: null, panY: null, initialized: false },
        settings: clonePlainObject(initialEditorSettings) || captureEditorSettings(),
        source: { type: "blank", origin: null }
      });
      activeDocumentId = fresh.id;
      restoreEditorSettings(fresh.settings);
      loadSvgIntoEditor(fresh.svgString, fresh);
      restoreEditorSettings(fresh.settings);
      clearUndoHistory();
      switchToSelectTool();
      notifyTabs();
      return;
    }
    if (wasActive) {
      var nextDoc = documents[Math.max(0, index - 1)] || documents[0];
      activeDocumentId = "";
      activateDocument(nextDoc.id, { skipSnapshot: true });
    } else {
      notifyTabs();
    }
  }

  function closeDocument(docId) {
    var doc = getDocument(docId);
    if (!doc) return;
    if (doc.id === activeDocumentId) saveActiveDocumentSnapshot();
    var closeNow = function (action) {
      if (action === "cancel") return;
      if (action === "save") saveDocumentToGallery(doc);
      removeDocument(doc.id);
      notifyTabs();
    };
    if (doc.dirty || !doc.savedToGallery) {
      modalChoice(doc, closeNow);
    } else {
      closeNow("discard");
    }
  }

  function renameDocument(docId, name) {
    var doc = getDocument(docId);
    if (!doc || !name) return;
    doc.name = String(name);
    doc.updatedAt = now();
    notifyTabs();
  }

  function importSvgFragment(svgText) {
    if (!svgText) return;
    if (env.importSvgIntoCurrentLayer) {
      env.importSvgIntoCurrentLayer(svgText, {
        select_after_import: true,
        center_on_canvas: true
      });
    }
    markDirty(activeDocumentId, true);
  }

  function bindDirtyTracking() {
    if (dirtyBound) return;
    dirtyBound = true;
    var canvas = getSvgCanvas();
    try {
      if (canvas && typeof canvas.bind === "function") {
        canvas.bind("changed", function () {
          if (!suppressDirty) {
            var docId = activeDocumentId;
            saveDocumentRuntimeState(docId);
            markDirty(docId, true);
          }
        });
      }
    } catch (error) {
      console.warn("DAVA documents: canvas change binding failed.", error);
    }
    ["mouseup", "keyup", "paste", "cut"].forEach(function (type) {
      document.addEventListener(type, function () {
        if (!suppressDirty) markDirty(activeDocumentId, true);
      }, true);
    });
    ["click", "change", "input"].forEach(function (type) {
      document.addEventListener(type, function (event) {
        if (!suppressDirty && eventTouchesDocumentSettings(event)) scheduleSaveDocumentRuntimeState(activeDocumentId, true);
      }, false);
    });
    document.addEventListener("keydown", function (event) {
      if (suppressDirty) return;
      var key = String(event.key || "").toLowerCase();
      if (key === "delete" || key === "backspace") markDirty(activeDocumentId, true);
    }, true);
  }

  function patchLabels(root) {
    root = root || document;
    var candidates = Array.prototype.slice.call(root.querySelectorAll("button, div, span, a, li, se-menu-item"));
    candidates.forEach(function (el) {
      ["title", "aria-label", "data-title"].forEach(function (attr) {
        var value = el.getAttribute && el.getAttribute(attr);
        if (/New (Image|image|SVG image)/.test(value || "")) el.setAttribute(attr, value.replace(/New (Image|image|SVG image)/g, "New Document"));
        if ((value || "").indexOf("New picture") >= 0) el.setAttribute(attr, value.replace(/\u65b0\u56fe\u7247/g, "New document"));
      });
      if (/^\s*New (Image|image|SVG image)\s*$/.test(el.textContent || "")) el.textContent = "New Document";
      if (/^\s*\u65b0\u56fe\u7247\s*$/.test(el.textContent || "")) el.textContent = "New document";
    });
  }

  function interceptNewDocumentUi() {
    patchLabels();
    var bindNativeNewButton = function () {
      var tool = document.getElementById("tool_clear");
      if (!tool || tool.getAttribute("data-dava-simple-new-bound") === "1") return;
      tool.setAttribute("data-dava-simple-new-bound", "1");
      tool.setAttribute("title", "New Document");
      tool.setAttribute("aria-label", "New Document");
      tool.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
        createNewDocument();
      }, true);
    };
    bindNativeNewButton();
    var observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        if (mutation.addedNodes) {
          Array.prototype.forEach.call(mutation.addedNodes, function (node) {
            if (node.nodeType === 1) patchLabels(node);
          });
        }
      });
      bindNativeNewButton();
    });
    observer.observe(document.body, { childList: true, subtree: true });
    document.addEventListener("click", function (event) {
      var target = event.target && event.target.closest ? event.target.closest("#tool_clear, #tool_new, se-menu-item, button, div, span, a, li") : null;
      if (!target) return;
      var text = target.textContent || "";
      var title = target.getAttribute("title") || target.getAttribute("aria-label") || "";
      var label = target.getAttribute("label") || target.getAttribute("data-label") || "";
      var id = target.id || "";
      if (
        id === "tool_clear" ||
        id === "tool_new" ||
        /new_doc/.test(label) ||
        /New (Document|Image|SVG image)/.test(title + " " + text) ||
        /\u65b0\u5efa\u6587\u6863|\u65b0\u56fe\u7247/.test(title + " " + text)
      ) {
        event.preventDefault();
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
        createNewDocument();
      }
    }, true);
    window.setTimeout(bindNativeNewButton, 250);
    window.setTimeout(bindNativeNewButton, 1000);
    window.setTimeout(bindNativeNewButton, 2500);
  }

  function handleSavedToGallery(payload) {
    var doc = getDocument(payload && payload.documentId);
    if (!doc) return;
    if (payload.saved !== false) {
      doc.savedToGallery = true;
      doc.dirty = false;
      notifyTabs();
    }
  }

  function init(options) {
    env = options || {};
    if (initialized) return;
    initialized = true;
    initialEditorSettings = captureEditorSettings();
    if (window.DavaSimpleDocumentTabs) window.DavaSimpleDocumentTabs.mount(api);
    createInitialDocument();
    bindDirtyTracking();
    interceptNewDocumentUi();
    if (window.DavaSimpleDocumentClipboard) window.DavaSimpleDocumentClipboard.bind(api);
    notifyTabs();
  }

  function ensureAtLeastOneDocument() {
    if (!documents.length) createInitialDocument();
  }

  var api = {
    init: init,
    createInitialDocument: createInitialDocument,
    createNewDocument: createNewDocument,
    getActiveDocument: getActiveDocument,
    getDocument: getDocument,
    getAllDocuments: getAllDocuments,
    activateDocument: activateDocument,
    closeDocument: closeDocument,
    renameDocument: renameDocument,
    markDirty: markDirty,
    saveActiveDocumentSnapshot: saveActiveDocumentSnapshot,
    loadDocumentSnapshot: activateDocument,
    serializeActiveSvg: serializeActiveSvg,
    loadSvgIntoEditor: loadSvgIntoEditor,
    getNextUntitledName: function () { return "Not yettitle-" + nextIndex; },
    ensureAtLeastOneDocument: ensureAtLeastOneDocument,
    getSvgCanvas: getSvgCanvas,
    importSvgFragment: importSvgFragment,
    handleSavedToGallery: handleSavedToGallery
  };

  window.DavaSimpleDocumentStore = api;
})();
