(function () {
  "use strict";

  var store = null;
  var rootEl = null;
  var listEl = null;

  function text(value) {
    return value == null ? "" : String(value);
  }

  function mount(documentStore) {
    store = documentStore;
    rootEl = document.getElementById("dava-svg-document-tabs");
    if (!rootEl) {
      rootEl = document.createElement("div");
      rootEl.id = "dava-svg-document-tabs";
      rootEl.className = "dava-svg-document-tabs";

      listEl = document.createElement("div");
      listEl.id = "dava-svg-document-tab-list";
      listEl.className = "dava-svg-document-tab-list";
      rootEl.appendChild(listEl);

      var addButton = document.createElement("button");
      addButton.id = "dava-svg-document-new";
      addButton.className = "dava-svg-document-new";
      addButton.type = "button";
      addButton.title = "Create new canvas";
      addButton.setAttribute("aria-label", "New Document");
      addButton.textContent = "+";
      addButton.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        store.createNewDocument();
      });
      rootEl.appendChild(addButton);

      var topTools = document.getElementById("tools_top") || document.querySelector(".tools_top");
      var workarea = document.getElementById("workarea");
      var editorRoot = document.querySelector(".svg_editor");
      if (editorRoot) editorRoot.classList.add("dava-simple-doc-tabs-enabled");
      if (topTools && topTools.parentNode) {
        topTools.parentNode.insertBefore(rootEl, topTools.nextSibling);
      } else if (workarea && workarea.parentNode) {
        workarea.parentNode.insertBefore(rootEl, workarea);
      } else {
        document.body.insertBefore(rootEl, document.body.firstChild);
      }
    } else {
      listEl = document.getElementById("dava-svg-document-tab-list");
      var existingEditorRoot = document.querySelector(".svg_editor");
      if (existingEditorRoot) existingEditorRoot.classList.add("dava-simple-doc-tabs-enabled");
    }
    render();
  }

  function render() {
    if (!store || !listEl) return;
    listEl.textContent = "";
    var active = store.getActiveDocument();
    store.getAllDocuments().forEach(function (doc) {
      var tab = document.createElement("button");
      tab.className = "dava-svg-document-tab" + (active && active.id === doc.id ? " active" : "");
      tab.type = "button";
      tab.setAttribute("data-doc-id", doc.id);
      tab.title = [
        doc.name,
        doc.dirty ? "Unsaved changes" : "Saved",
        doc.svgString ? "Snapshot ready" : "Blank snapshot"
      ].join("\n");

      var title = document.createElement("span");
      title.className = "dava-svg-document-title";
      title.textContent = text(doc.name);
      tab.appendChild(title);

      var dirty = document.createElement("span");
      dirty.className = "dava-svg-document-dirty";
      dirty.textContent = doc.dirty ? "*" : "";
      tab.appendChild(dirty);

      var close = document.createElement("span");
      close.className = "dava-svg-document-close";
      close.setAttribute("role", "button");
      close.setAttribute("aria-label", "Close");
      close.textContent = "\u00d7";
      close.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        store.closeDocument(doc.id);
      });
      tab.appendChild(close);

      tab.addEventListener("click", function (event) {
        event.preventDefault();
        store.activateDocument(doc.id);
      });
      listEl.appendChild(tab);
    });
  }

  window.DavaSimpleDocumentTabs = {
    mount: mount,
    render: render
  };
})();
