(function () {
  "use strict";

  var svgNS = "http://www.w3.org/2000/svg";

  function uniqueId(prefix, root) {
    root = root || document;
    var id;
    do {
      id = prefix + "-" + Math.random().toString(36).slice(2, 8) + "-" + Date.now().toString(36);
    } while (root.getElementById && root.getElementById(id));
    return id;
  }

  function importSvgNode(doc, svg) {
    return doc.importNode ? doc.importNode(svg, true) : svg.cloneNode(true);
  }

  function parseLength(value, fallback) {
    var text = String(value || "").trim();
    var number = parseFloat(text);
    if (!Number.isFinite(number) || number <= 0) return fallback;
    if (/ex$/i.test(text)) return number * 8;
    if (/em$/i.test(text)) return number * 16;
    return number;
  }

  function viewBoxParts(svg) {
    var viewBox = String(svg && svg.getAttribute("viewBox") || "").trim().split(/\s+/).map(Number);
    if (viewBox.length === 4 && viewBox.every(function (value) { return Number.isFinite(value); })) {
      return viewBox;
    }
    return [0, 0, 160, 60];
  }

  function renderedBounds(svg) {
    var parts = viewBoxParts(svg);
    var viewWidth = Math.max(1, Math.abs(parts[2]));
    var viewHeight = Math.max(1, Math.abs(parts[3]));
    var width = parseLength(svg && svg.getAttribute("width"), 160);
    var height = parseLength(svg && svg.getAttribute("height"), width * viewHeight / viewWidth);
    if (!Number.isFinite(height) || height <= 0) height = 60;
    return { x: 0, y: 0, width: Math.max(1, width), height: Math.max(1, height) };
  }

  function normalizeRenderedSvg(svg) {
    var bounds = renderedBounds(svg);
    svg.setAttribute("x", "0");
    svg.setAttribute("y", "0");
    svg.setAttribute("width", bounds.width);
    svg.setAttribute("height", bounds.height);
    svg.setAttribute("overflow", "visible");
    svg.setAttribute("preserveAspectRatio", "xMinYMin meet");
    svg.removeAttribute("style");
    return svg;
  }

  function createHitbox(doc, svg) {
    var bounds = renderedBounds(svg);
    var rect = doc.createElementNS(svgNS, "rect");
    rect.setAttribute("class", "equation-hitbox");
    rect.setAttribute("x", bounds.x);
    rect.setAttribute("y", bounds.y);
    rect.setAttribute("width", bounds.width);
    rect.setAttribute("height", bounds.height);
    rect.setAttribute("fill", "#fff");
    rect.setAttribute("fill-opacity", "0");
    rect.setAttribute("stroke", "none");
    rect.setAttribute("data-dava-equation-hitbox", "1");
    rect.setAttribute("pointer-events", "all");
    return rect;
  }

  function protectRenderedLayer(rendered) {
    rendered.setAttribute("pointer-events", "none");
    Array.prototype.forEach.call(rendered.querySelectorAll("*"), function (node) {
      node.setAttribute("pointer-events", "none");
    });
  }

  function createEquationGroup(doc, options) {
    options = options || {};
    var group = doc.createElementNS(svgNS, "g");
    var id = options.id || uniqueId("eq", doc);
    var latex = window.DavaEquationSanitizer.sanitizeLatex(options.latex || "");
    group.setAttribute("id", id);
    group.setAttribute("data-type", "equation");
    group.setAttribute("data-role", "user-object");
    group.setAttribute("data-latex", latex);
    group.setAttribute("data-display-mode", options.displayMode === false ? "false" : "true");
    group.setAttribute("data-equation-engine", "mathjax");
    group.setAttribute("data-equation-version", "1");
    group.setAttribute("data-dava-edit-policy", "atomic-equation");
    group.setAttribute("data-dava-ungroup", "disabled");
    group.setAttribute("data-dava-selector-native-bbox", "1");
    group.setAttribute("pointer-events", "visiblePainted");
    group.setAttribute("font-family", options.fontFamily || window.DavaEquationRegistry.defaults.fontFamily);
    group.setAttribute("fill", options.fill || window.DavaEquationRegistry.defaults.fill);
    group.setAttribute("transform", "translate(" + (options.x || 0) + "," + (options.y || 0) + ") scale(1)");

    var title = doc.createElementNS(svgNS, "title");
    title.textContent = latex;
    var desc = doc.createElementNS(svgNS, "desc");
    desc.textContent = "Editable equation object generated from LaTeX source.";
    var rendered = doc.createElementNS(svgNS, "g");
    rendered.setAttribute("class", "equation-rendered-svg");
    rendered.appendChild(normalizeRenderedSvg(importSvgNode(doc, options.svg)));
    protectRenderedLayer(rendered);
    group.appendChild(title);
    group.appendChild(desc);
    group.appendChild(createHitbox(doc, options.svg));
    group.appendChild(rendered);
    return group;
  }

  function replaceRenderedSvg(equationEl, svg, latex, options) {
    options = options || {};
    var doc = equationEl.ownerDocument;
    var rendered = equationEl.querySelector(".equation-rendered-svg");
    if (!rendered) {
      rendered = doc.createElementNS(svgNS, "g");
      rendered.setAttribute("class", "equation-rendered-svg");
      equationEl.appendChild(rendered);
    }
    while (rendered.firstChild) rendered.removeChild(rendered.firstChild);
    rendered.appendChild(normalizeRenderedSvg(importSvgNode(doc, svg)));
    protectRenderedLayer(rendered);
    var oldHitbox = equationEl.querySelector(".equation-hitbox");
    if (oldHitbox && oldHitbox.parentNode) oldHitbox.parentNode.removeChild(oldHitbox);
    equationEl.insertBefore(createHitbox(doc, svg), rendered);
    equationEl.setAttribute("data-dava-selector-native-bbox", "1");
    equationEl.setAttribute("pointer-events", "visiblePainted");
    equationEl.setAttribute("data-dava-edit-policy", "atomic-equation");
    equationEl.setAttribute("data-dava-ungroup", "disabled");
    equationEl.setAttribute("data-latex", latex);
    equationEl.setAttribute("data-display-mode", options.displayMode === false ? "false" : "true");
    var title = equationEl.querySelector("title") || doc.createElementNS(svgNS, "title");
    title.textContent = latex;
    if (!title.parentNode) equationEl.insertBefore(title, equationEl.firstChild);
    var desc = equationEl.querySelector("desc") || doc.createElementNS(svgNS, "desc");
    desc.textContent = "Editable equation object generated from LaTeX source.";
    if (!desc.parentNode) equationEl.insertBefore(desc, title.nextSibling);
  }

  function normalizeEquationElement(equationEl) {
    if (!equationEl) return;
    var doc = equationEl.ownerDocument;
    var rendered = equationEl.querySelector(".equation-rendered-svg");
    var svg = rendered ? rendered.querySelector("svg") : null;
    if (!rendered || !svg) return;
    normalizeRenderedSvg(svg);
    protectRenderedLayer(rendered);
    var oldHitbox = equationEl.querySelector(".equation-hitbox");
    if (oldHitbox && oldHitbox.parentNode) oldHitbox.parentNode.removeChild(oldHitbox);
    equationEl.insertBefore(createHitbox(doc, svg), rendered);
    equationEl.setAttribute("data-dava-selector-native-bbox", "1");
    equationEl.setAttribute("pointer-events", "visiblePainted");
    equationEl.setAttribute("data-dava-edit-policy", "atomic-equation");
    equationEl.setAttribute("data-dava-ungroup", "disabled");
  }

  function isEquationElement(element) {
    return !!(element && element.nodeType === 1 && element.getAttribute("data-type") === "equation");
  }

  function closestEquationElement(element) {
    return element && element.closest ? element.closest("[data-type='equation']") : null;
  }

  window.DavaEquationObjectModel = {
    uniqueId: uniqueId,
    createEquationGroup: createEquationGroup,
    replaceRenderedSvg: replaceRenderedSvg,
    normalizeEquationElement: normalizeEquationElement,
    isEquationElement: isEquationElement,
    closestEquationElement: closestEquationElement
  };
})();
