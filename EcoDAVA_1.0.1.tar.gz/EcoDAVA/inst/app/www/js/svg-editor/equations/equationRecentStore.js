(function () {
  "use strict";

  var key = "dava.svgEdit.equation.recent.v1";

  function read() {
    try {
      var value = JSON.parse(localStorage.getItem(key) || "[]");
      return Array.isArray(value) ? value : [];
    } catch (error) {
      return [];
    }
  }

  function write(items) {
    try {
      localStorage.setItem(key, JSON.stringify(items.slice(0, 24)));
    } catch (error) {}
  }

  function add(latex) {
    latex = String(latex || "").trim();
    if (!latex) return;
    var items = read().filter(function (item) { return item.latex !== latex; });
    items.unshift({ latex: latex, label: latex.length > 42 ? latex.slice(0, 39) + "..." : latex, time: Date.now() });
    write(items);
  }

  window.DavaEquationRecentStore = {
    read: read,
    add: add
  };
})();
