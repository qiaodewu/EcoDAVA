(function () {
  "use strict";

  var blockedCommands = [
    "\\href", "\\url", "\\htmlId", "\\htmlClass", "\\htmlStyle", "\\style",
    "\\class", "\\cssId", "\\require", "\\includegraphics", "\\unicode",
    "\\newcommand", "\\def", "\\let", "\\catcode"
  ];

  function sanitizeLatex(latex) {
    var value = String(latex || "").trim();
    if (!value) throw new Error("Equation LaTeX cannot be empty.");
    blockedCommands.forEach(function (command) {
      if (value.indexOf(command) !== -1) {
        throw new Error("Unsafe LaTeX command is not allowed: " + command);
      }
    });
    if (value.length > 8000) throw new Error("Equation LaTeX is too long.");
    return value;
  }

  function escapeAttribute(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/"/g, "&quot;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function safeText(value) {
    return String(value || "").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "");
  }

  window.DavaEquationSanitizer = {
    sanitizeLatex: sanitizeLatex,
    escapeAttribute: escapeAttribute,
    safeText: safeText
  };
})();
