(function () {
  "use strict";

  function editEquationCommand(env, equationEl, newLatex, options) {
    options = options || {};
    if (!window.DavaEquationObjectModel.isEquationElement(equationEl)) {
      return Promise.reject(new Error("Selected object is not an equation."));
    }
    var canvas = env && env.getSvgCanvas ? env.getSvgCanvas() : null;
    var cleanLatex = window.DavaEquationSanitizer.sanitizeLatex(newLatex);
    var oldLatex = equationEl.getAttribute("data-latex") || "";
    var oldDisplay = equationEl.getAttribute("data-display-mode") || "true";
    return window.DavaEquationRendererMathJax.renderLatexToSvg(cleanLatex, {
      displayMode: options.displayMode !== false,
      idPrefix: equationEl.id + "-mjx-" + Date.now().toString(36)
    }).then(function (svg) {
      window.DavaEquationObjectModel.replaceRenderedSvg(equationEl, svg, cleanLatex, options);
      try {
        if (canvas && canvas.history && canvas.history.ChangeElementCommand && typeof canvas.addCommandToHistory === "function") {
          canvas.addCommandToHistory(new canvas.history.ChangeElementCommand(equationEl, {
            "data-latex": oldLatex,
            "data-display-mode": oldDisplay
          }, "update-equation"));
        }
        window.DavaEquationInsertCommand.selectElement(canvas, equationEl);
      } catch (error) {}
      window.DavaEquationRecentStore.add(cleanLatex);
      window.DavaEquationInsertCommand.shinyEvent(env, "svg_editor_equation_updated", {
        id: equationEl.id,
        latex: cleanLatex,
        previousLatex: oldLatex,
        displayMode: options.displayMode !== false,
        timestamp: Date.now()
      });
      return equationEl;
    });
  }

  window.DavaEquationEditCommand = {
    editEquationCommand: editEquationCommand
  };
})();
