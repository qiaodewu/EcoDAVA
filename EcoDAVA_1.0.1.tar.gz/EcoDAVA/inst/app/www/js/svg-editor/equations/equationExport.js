(function () {
  "use strict";

  function listEquations(root) {
    root = root || document;
    return Array.prototype.map.call(root.querySelectorAll("[data-type='equation']"), function (element) {
      return {
        id: element.id || "",
        latex: element.getAttribute("data-latex") || "",
        engine: element.getAttribute("data-equation-engine") || "mathjax",
        displayMode: element.getAttribute("data-display-mode") !== "false"
      };
    });
  }

  function prepareForExport(root) {
    return { equations: listEquations(root), warning: "" };
  }

  window.DavaEquationExport = {
    listEquations: listEquations,
    prepareForExport: prepareForExport
  };
})();
