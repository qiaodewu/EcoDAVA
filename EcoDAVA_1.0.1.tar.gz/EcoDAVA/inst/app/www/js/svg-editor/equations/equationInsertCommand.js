(function () {
  "use strict";

  function svgContent(canvas) {
    if (!canvas) return document.querySelector("svg");
    if (typeof canvas.getSvgContent === "function") return canvas.getSvgContent();
    return document.getElementById("svgcontent") || document.querySelector("svg");
  }

  function directLogicalUserGroup(parent) {
    if (!parent || !parent.children) return null;
    for (var index = 0; index < parent.children.length; index += 1) {
      var child = parent.children[index];
      if (child && child.getAttribute && child.getAttribute("data-dava-logical-user-layer") === "1") {
        return child;
      }
    }
    return null;
  }

  function isProtectedUiLayer(layer) {
    if (!layer || !layer.getAttribute) return true;
    var id = layer.getAttribute("id") || "";
    var role = layer.getAttribute("data-dava-layer-role") || "";
    return id === "selectorParentGroup" ||
      id === "selection-ui-layer" ||
      id === "guides-layer" ||
      role === "selection-ui" ||
      role === "guides";
  }

  function ensureLogicalUserGroup(canvas) {
    var drawing = canvas && typeof canvas.getCurrentDrawing === "function" ? canvas.getCurrentDrawing() : null;
    var parent = null;
    try {
      parent = drawing && typeof drawing.getCurrentLayer === "function" ? drawing.getCurrentLayer() : null;
    } catch (error) {}
    if (!parent || isProtectedUiLayer(parent)) parent = svgContent(canvas);
    var group = directLogicalUserGroup(parent);
    if (!group) {
      var doc = parent.ownerDocument || document;
      group = doc.createElementNS("http://www.w3.org/2000/svg", "g");
      group.setAttribute("data-dava-logical-user-layer", "1");
      group.setAttribute("data-dava-layer-role", "user-overlay");
      group.setAttribute("data-dava-source", "user");
      group.setAttribute("data-dava-container-only", "1");
      group.setAttribute("data-dava-selectable", "0");
      group.setAttribute("data-dava-editable", "0");
      group.setAttribute("pointer-events", "none");
      parent.appendChild(group);
    } else if (group.parentNode === parent && group.nextSibling) {
      parent.appendChild(group);
    }
    return group;
  }

  function defaultPoint(env, canvas) {
    if (env && typeof env.lastCanvasPoint === "function") {
      var point = env.lastCanvasPoint();
      if (point) return point;
    }
    var root = svgContent(canvas);
    var viewBox = root && root.getAttribute("viewBox");
    if (viewBox) {
      var parts = viewBox.split(/\s+/).map(Number);
      if (parts.length === 4) return { x: parts[0] + parts[2] / 2, y: parts[1] + parts[3] / 2 };
    }
    return { x: 120, y: 120 };
  }

  function selectElement(canvas, element) {
    try {
      if (typeof canvas.clearSelection === "function") canvas.clearSelection(true);
      if (typeof canvas.selectOnly === "function") canvas.selectOnly([element], true);
      else if (typeof canvas.addToSelection === "function") canvas.addToSelection([element], true);
      if (typeof canvas.recalculateAllSelectedDimensions === "function") canvas.recalculateAllSelectedDimensions();
      if (canvas.call) {
        canvas.call("selected", [element]);
        canvas.call("changed", [element]);
      }
    } catch (error) {}
  }

  function activateSelectMode(canvas) {
    try {
      if (window.svgEditor && window.svgEditor.leftPanel && typeof window.svgEditor.leftPanel.clickSelect === "function") {
        window.svgEditor.leftPanel.clickSelect();
      } else if (canvas && typeof canvas.setMode === "function") {
        canvas.setMode("select");
      }
    } catch (error) {}
  }

  function addInsertHistory(canvas, element) {
    try {
      if (canvas.history && canvas.history.InsertElementCommand && typeof canvas.addCommandToHistory === "function") {
        canvas.addCommandToHistory(new canvas.history.InsertElementCommand(element));
      }
    } catch (error) {}
  }

  function shinyEvent(env, name, payload) {
    if (env && typeof env.post === "function") env.post(name, payload);
    try {
      if (window.parent && window.parent.Shiny && window.parent.Shiny.setInputValue) {
        window.parent.Shiny.setInputValue(name, payload, { priority: "event" });
      }
    } catch (error) {}
  }

  function insertEquationCommand(env, latex, options) {
    options = options || {};
    var canvas = env && env.getSvgCanvas ? env.getSvgCanvas() : null;
    if (!canvas) return Promise.reject(new Error("SVG-Edit canvas is not available."));
    var cleanLatex = window.DavaEquationSanitizer.sanitizeLatex(latex);
    return window.DavaEquationRendererMathJax.renderLatexToSvg(cleanLatex, {
      displayMode: options.displayMode !== false,
      idPrefix: "eq-mjx-" + Date.now().toString(36)
    }).then(function (svg) {
      var point = options.point || defaultPoint(env, canvas);
      var group = window.DavaEquationObjectModel.createEquationGroup(svgContent(canvas).ownerDocument, {
        latex: cleanLatex,
        svg: svg,
        x: point.x,
        y: point.y,
        displayMode: options.displayMode !== false,
        fill: options.fill,
        fontFamily: options.fontFamily
      });
      ensureLogicalUserGroup(canvas).appendChild(group);
      addInsertHistory(canvas, group);
      activateSelectMode(canvas);
      selectElement(canvas, group);
      window.setTimeout(function () {
        activateSelectMode(canvas);
        selectElement(canvas, group);
      }, 0);
      window.DavaEquationRecentStore.add(cleanLatex);
      shinyEvent(env, "svg_editor_equation_inserted", {
        id: group.id,
        latex: cleanLatex,
        displayMode: options.displayMode !== false,
        x: point.x,
        y: point.y,
        timestamp: Date.now()
      });
      return group;
    });
  }

  window.DavaEquationInsertCommand = {
    insertEquationCommand: insertEquationCommand,
    ensureLogicalUserGroup: ensureLogicalUserGroup,
    selectElement: selectElement,
    shinyEvent: shinyEvent
  };
})();
