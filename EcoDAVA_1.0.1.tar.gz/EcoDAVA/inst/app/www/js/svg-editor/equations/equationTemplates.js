(function () {
  "use strict";

  var r = String.raw;

  function item(label, latex, description) {
    return { label: label, latex: latex, description: description || label };
  }

  var categories = [
    {
      id: "recent",
      label: "Recent",
      templates: []
    },
    {
      id: "common",
      label: "Common",
      templates: [
        item("Fraction", r`\frac{a}{b}`),
        item("Power", r`x^2`),
        item("Subscript", r`x_i`),
        item("Subscript + power", r`x_i^2`),
        item("Square root", r`\sqrt{x}`),
        item("Nth root", r`\sqrt[n]{x}`),
        item("Integral", r`\int_a^b f(x)\,dx`),
        item("Summation", r`\sum_{i=1}^{n}x_i`),
        item("Product", r`\prod_{i=1}^{n}x_i`),
        item("Limit", r`\lim_{x\to 0}f(x)`),
        item("Parentheses", r`\left( x \right)`),
        item("Brackets", r`\left[ x \right]`),
        item("Braces", r`\left\{ x \right\}`),
        item("Matrix", r`\begin{bmatrix} a & b \\ c & d \end{bmatrix}`)
      ]
    },
    {
      id: "built-in",
      label: "Built-in",
      templates: [
        item("Quadratic formula", r`x=\frac{-b\pm\sqrt{b^2-4ac}}{2a}`),
        item("Pythagorean theorem", r`a^2+b^2=c^2`),
        item("Euler identity", r`e^{i\pi}+1=0`),
        item("Mass energy", r`E=mc^2`)
      ]
    },
    {
      id: "statistics",
      label: "Statistics",
      templates: [
        item("Mean", r`\bar{x}=\frac{1}{n}\sum_{i=1}^{n}x_i`),
        item("Sample SD", r`s=\sqrt{\frac{\sum_{i=1}^{n}(x_i-\bar{x})^2}{n-1}}`),
        item("SE", r`SE=\frac{s}{\sqrt{n}}`),
        item("CI", r`CI=\bar{x}\pm t_{\alpha/2,n-1}\frac{s}{\sqrt{n}}`),
        item("Linear model", r`y=\beta_0+\beta_1x+\varepsilon`),
        item("R squared", r`R^2=1-\frac{SS_{res}}{SS_{tot}}`),
        item("F statistic", r`F=\frac{MS_{between}}{MS_{within}}`),
        item("Correlation", r`r=\frac{\sum (x_i-\bar{x})(y_i-\bar{y})}{\sqrt{\sum(x_i-\bar{x})^2\sum(y_i-\bar{y})^2}}`)
      ]
    },
    {
      id: "ecology",
      label: "Ecology",
      templates: [
        item("Shannon", r`H'=-\sum_{i=1}^{S}p_i\ln p_i`),
        item("Simpson", r`D=1-\sum_{i=1}^{S}p_i^2`),
        item("Evenness", r`J=\frac{H'}{\ln S}`),
        item("Relative abundance", r`RA_i=\frac{n_i}{N}\times100\%`),
        item("Bray-Curtis", r`BC_{ij}=1-\frac{2C_{ij}}{S_i+S_j}`),
        item("Activity", r`Activity=\frac{C\times V}{m\times t}`),
        item("Michaelis-Menten", r`v=\frac{V_{max}[S]}{K_m+[S]}`),
        item("Decay", r`C_t=C_0e^{-kt}`),
        item("C:N", r`C:N=\frac{SOC}{TN}`)
      ]
    },
    {
      id: "operators",
      label: "Large Operators",
      templates: [
        item("Double integral", r`\iint_A f(x,y)\,dx\,dy`),
        item("Triple integral", r`\iiint_V f(x,y,z)\,dV`),
        item("Union", r`\bigcup_{i=1}^{n} A_i`),
        item("Intersection", r`\bigcap_{i=1}^{n} A_i`)
      ]
    },
    {
      id: "greek",
      label: "Greek",
      templates: [
        item("Alpha beta", r`\alpha+\beta`),
        item("Delta", r`\Delta x`),
        item("Mu sigma", r`\mu\pm\sigma`),
        item("Chi-square", r`\chi^2`)
      ]
    }
  ];

  window.DavaEquationTemplates = {
    categories: categories,
    findTemplate: function (latex) {
      var found = null;
      categories.some(function (category) {
        return category.templates.some(function (template) {
          if (template.latex === latex) {
            found = template;
            return true;
          }
          return false;
        });
      });
      return found;
    }
  };
})();
