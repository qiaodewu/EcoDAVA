(function () {
  "use strict";

  var env = null;
  var panel = null;
  var mathField = null;
  var latexSource = null;
  var selectedLatex = "";
  var editingElement = null;
  var renderTimer = null;
  var gallery = null;

  function css() {
    if (document.getElementById("dava_equation_panel_css")) return;
    var style = document.createElement("style");
    style.id = "dava_equation_panel_css";
    style.textContent = [
      "#dava_equation_panel{position:fixed;left:50%;top:42px;transform:translateX(-50%);width:1180px;max-width:calc(100vw - 28px);height:650px;max-height:calc(100vh - 66px);z-index:1000005;background:#ececec;border:1px solid #7c7c7c;box-shadow:0 16px 42px rgba(0,0,0,.38);font:12px 'Segoe UI',Arial,sans-serif;color:#1f1f1f;display:none}",
      "#dava_equation_panel.open{display:grid;grid-template-rows:34px 132px 1fr}",
      "#dava_equation_panel .equation-titlebar{display:flex;align-items:center;gap:8px;padding:4px 8px;background:#d9d9d9;border-bottom:1px solid #a8a8a8}",
      "#dava_equation_panel .equation-titlebar strong{font-size:13px;font-weight:600;margin-right:auto}",
      "#dava_equation_panel button{border:1px solid #8d8d8d;background:#f8f8f8;border-radius:0;padding:4px 8px;cursor:pointer;color:#111;font:12px 'Segoe UI',Arial,sans-serif}",
      "#dava_equation_panel button:hover{background:#fff;border-color:#4d87c7}",
      "#dava_equation_panel button.primary{background:#2f75b5;border-color:#1e5d94;color:#fff;font-weight:600}",
      "#dava_equation_panel .equation-titlebar label{display:flex;gap:5px;align-items:center}",
      "#dava_equation_panel .equation-fill{width:30px;height:22px;padding:0;border:1px solid #888;background:#fff}",
      "#dava_equation_panel .equation-ribbon{display:flex;align-items:stretch;gap:14px;background:#b7b7b7;border-bottom:1px solid #8f8f8f;padding:8px 10px 4px 10px;overflow:auto}",
      "#dava_equation_panel .ribbon-group{position:relative;display:flex;flex-direction:column;align-items:center;min-height:112px;padding:0 10px 18px 0}",
      "#dava_equation_panel .ribbon-group+.ribbon-group{border-left:1px solid #777;padding-left:18px}",
      "#dava_equation_panel .ribbon-label{position:absolute;left:0;right:10px;bottom:0;text-align:center;color:#1f1f1f;font-size:13px}",
      "#dava_equation_panel .symbol-wrap{display:flex;align-items:flex-start;gap:4px}",
      "#dava_equation_panel .symbol-grid{display:grid;grid-template-columns:repeat(12,36px);grid-auto-rows:36px;gap:4px}",
      "#dava_equation_panel .symbol-btn{width:36px;height:36px;padding:0;background:#f4f4f4;border:1px solid #777;font:20px/1 'Cambria Math','Times New Roman',serif;color:#111}",
      "#dava_equation_panel .symbol-more{width:34px;height:78px;margin-left:2px;display:flex;align-items:flex-end;justify-content:center;font-size:14px;background:#bdbdbd}",
      "#dava_equation_panel .structure-grid{display:grid;grid-template-columns:repeat(11,68px);gap:4px;align-items:start}",
      "#dava_equation_panel .structure-btn{width:68px;height:92px;padding:2px 2px 4px;background:transparent;border:1px solid transparent;display:grid;grid-template-rows:42px 30px 12px;justify-items:center;align-items:center}",
      "#dava_equation_panel .structure-btn:hover{background:#c9d8ec;border-color:#6f95c2}",
      "#dava_equation_panel .structure-icon{font:32px/1 'Cambria Math','STIX Two Math','Times New Roman',serif;color:#303030;white-space:nowrap}",
      "#dava_equation_panel .structure-label{font-size:13px;line-height:15px;text-align:center;color:#222;word-break:keep-all;white-space:pre-line}",
      "#dava_equation_panel .structure-arrow{font-size:11px;line-height:1;color:#111}",
      "#dava_equation_panel .equation-gallery{position:absolute;z-index:3;display:none;width:520px;max-width:calc(100vw - 44px);max-height:430px;overflow:auto;background:#f3f3f3;border:1px solid #9a9a9a;box-shadow:0 8px 20px rgba(0,0,0,.28);padding:10px 10px 14px 10px;color:#111}",
      "#dava_equation_panel .equation-gallery.open{display:block}",
      "#dava_equation_panel .gallery-title{font-size:18px;font-weight:600;margin:0 0 8px 0}",
      "#dava_equation_panel .gallery-section{margin:0 0 12px 0}",
      "#dava_equation_panel .gallery-section-title{font-size:15px;font-weight:700;margin:8px 0 6px 0}",
      "#dava_equation_panel .gallery-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:8px}",
      "#dava_equation_panel .gallery-item{height:104px;background:#f8f8f8;border:1px solid #b5b5b5;display:flex;align-items:center;justify-content:center;padding:6px;text-align:center;font:26px/1.15 'Cambria Math','STIX Two Math','Times New Roman',serif;white-space:pre-line}",
      "#dava_equation_panel .gallery-item.wide{grid-column:span 2}",
      "#dava_equation_panel .gallery-item:hover{background:#fff;border-color:#4d87c7}",
      "#dava_equation_panel .gallery-symbols{grid-template-columns:repeat(11,42px);gap:6px}",
      "#dava_equation_panel .gallery-symbols .gallery-item{width:42px;height:42px;padding:0;font-size:24px}",
      "#dava_equation_panel .equation-workspace{display:grid;grid-template-columns:minmax(360px,1fr) 310px;gap:10px;min-height:0;padding:10px;background:#f2f2f2}",
      "#dava_equation_panel .editor-pane,.preview-pane{min-height:0;overflow:auto}",
      "#dava_equation_panel .editor-pane{display:grid;grid-template-rows:auto auto minmax(72px,auto);gap:8px}",
      "#dava_equation_panel .mathfield-host{background:#fff;border:1px solid #a0a0a0;padding:8px}",
      "#dava_equation_panel math-field,.dava-equation-latex-fallback{display:block;box-sizing:border-box;width:100%;min-height:118px;border:0;background:#fff;padding:8px;font-size:24px}",
      "#dava_equation_panel textarea{box-sizing:border-box;width:100%;min-height:78px;font-family:Consolas,monospace;border:1px solid #b0b0b0;background:#fff}",
      "#dava_equation_panel .quick-templates{display:grid;grid-template-columns:repeat(auto-fill,minmax(128px,1fr));gap:6px;align-content:start}",
      "#dava_equation_panel .template{min-height:34px;text-align:left;background:#fff;border:1px solid #c9c9c9;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
      "#dava_equation_panel .template:hover{border-color:#4d87c7;background:#f5f9ff}",
      "#dava_equation_panel .preview-pane{border-left:1px solid #c6c6c6;padding-left:10px}",
      "#dava_equation_panel .preview-pane h3{font-size:13px;font-weight:600;margin:0 0 6px 0}",
      "#dava_equation_panel .preview{min-height:132px;border:1px solid #c9c9c9;background:#fff;display:flex;align-items:center;justify-content:center;padding:12px;overflow:auto}",
      "#dava_equation_panel .latex-readout{min-height:44px;max-height:86px;overflow:auto;margin:0 0 8px 0;padding:6px;border:1px solid #d0d0d0;background:#fff;font:12px Consolas,monospace;white-space:pre-wrap}",
      "#dava_equation_panel .mathml-source{min-height:70px;font-size:11px}",
      "#dava_equation_panel .error{color:#b00020;white-space:pre-wrap;margin-top:8px}"
    ].join("\n");
    document.head.appendChild(style);
  }

  var ribbonSymbols = [
    ["\u00b1", "\\pm"], ["\u221e", "\\infty"], ["=", "="], ["\u2260", "\\ne"], ["\u223c", "\\sim"], ["\u00d7", "\\times"], ["\u00f7", "\\div"], ["!", "!"], ["\u03b1", "\\alpha"], ["<", "<"], ["\u226a", "\\ll"], [">", ">"],
    ["\u226b", "\\gg"], ["\u2264", "\\le"], ["\u2265", "\\ge"], ["\u2213", "\\mp"], ["\u2245", "\\cong"], ["\u2248", "\\approx"], ["\u2261", "\\equiv"], ["\u2200", "\\forall"], ["C", "C"], ["\u2202", "\\partial"]
  ];

  var ribbonStructures = [
    { id: "fraction", label: "\u5206\u5f0f", icon: "x\u2044y" },
    { id: "script", label: "\u4e0a\u4e0b\u6807", icon: "e\u02e3" },
    { id: "radical", label: "\u6839\u5f0f", icon: "\u207f\u221ax" },
    { id: "integral", label: "\u79ef\u5206", icon: "\u222b\u2093\u02e3" },
    { id: "largeop", label: "\u5927\u578b\n\u8fd0\u7b97\u7b26", icon: "\u2211\u1d62\u207f" },
    { id: "bracket", label: "\u62ec\u53f7", icon: "{()}" },
    { id: "function", label: "\u51fd\u6570", icon: "sin \u03b8" },
    { id: "accent", label: "\u6807\u6ce8\u7b26\u53f7", icon: "\u00e4" },
    { id: "limitlog", label: "\u6781\u9650\u548c\u5bf9\u6570", icon: "lim" },
    { id: "operator", label: "\u8fd0\u7b97\u7b26", icon: "\u25b3" },
    { id: "matrix", label: "\u77e9\u9635", icon: "[10\u033201]" }
  ];

  function template(preview, latex, wide) {
    return { preview: preview, latex: latex, wide: !!wide };
  }

  function section(title, items, symbolGrid) {
    return { title: title, items: items, symbolGrid: !!symbolGrid };
  }

  var equationGalleries = {
    symbols: {
      title: "\u57fa\u7840\u6570\u5b66",
      sections: [
        section("\u57fa\u7840\u6570\u5b66", [
          ["\u00b1", "\\pm"], ["\u221e", "\\infty"], ["=", "="], ["\u2260", "\\ne"], ["\u223c", "\\sim"], ["\u00d7", "\\times"], ["\u00f7", "\\div"], ["!", "!"], ["\u221d", "\\propto"], ["<", "<"], ["\u226a", "\\ll"],
          [">", ">"], ["\u226b", "\\gg"], ["\u2264", "\\le"], ["\u2265", "\\ge"], ["\u2213", "\\mp"], ["\u2245", "\\cong"], ["\u2248", "\\approx"], ["\u2261", "\\equiv"], ["\u2200", "\\forall"], ["\u2102", "\\mathbb{C}"], ["\u2202", "\\partial"],
          ["\u221a", "\\sqrt{x}"], ["\u221b", "\\sqrt[3]{x}"], ["\u222a", "\\cup"], ["\u2229", "\\cap"], ["\u2205", "\\emptyset"], ["%", "\\%"], ["\u00b0", "^{\\circ}"], ["\u2109", "^{\\circ}F"], ["\u2103", "^{\\circ}C"], ["\u2206", "\\Delta"],
          ["\u2207", "\\nabla"], ["\u2203", "\\exists"], ["\u2204", "\\nexists"], ["\u2208", "\\in"], ["\u220b", "\\ni"], ["\u2190", "\\leftarrow"], ["\u2191", "\\uparrow"], ["\u2192", "\\rightarrow"], ["\u2193", "\\downarrow"], ["\u2194", "\\leftrightarrow"], ["\u2234", "\\therefore"],
          ["+", "+"], ["-", "-"], ["\u00ac", "\\neg"], ["\u03b1", "\\alpha"], ["\u03b2", "\\beta"], ["\u03b3", "\\gamma"], ["\u03b4", "\\delta"], ["\u03b5", "\\epsilon"], ["\u03b8", "\\theta"], ["\u03d1", "\\vartheta"],
          ["\u03bc", "\\mu"], ["\u03c0", "\\pi"], ["\u03c1", "\\rho"], ["\u03c3", "\\sigma"], ["\u03c4", "\\tau"], ["\u03c6", "\\phi"], ["\u03c9", "\\omega"], ["*", "*"], ["\u00b7", "\\cdot"], ["\u22ee", "\\vdots"], ["\u2026", "\\ldots"]
        ].map(function (item) { return template(item[0], item[1]); }), true)
      ]
    },
    fraction: {
      title: "\u5206\u5f0f",
      sections: [
        section("\u5206\u5f0f", [
          template("\u25a1\n\u2500\n\u25a1", "\\frac{a}{b}"),
          template("\u25a1/\u25a1", "a/b"),
          template("\u25a1/\u25a1", "\\left. a \\middle/ b \\right."),
          template("\u25a1\n\u2015\n\u25a1", "\\dfrac{a}{b}")
        ]),
        section("\u5e38\u7528\u5206\u5f0f", [
          template("dy\n\u2500\ndx", "\\frac{dy}{dx}"),
          template("\u0394y\n\u2500\n\u0394x", "\\frac{\\Delta y}{\\Delta x}"),
          template("\u2202y\n\u2500\n\u2202x", "\\frac{\\partial y}{\\partial x}"),
          template("\u03b4y\n\u2500\n\u03b4x", "\\frac{\\delta y}{\\delta x}"),
          template("\u03c0\n\u2500\n2", "\\frac{\\pi}{2}")
        ])
      ]
    },
    script: {
      title: "\u4e0b\u6807\u548c\u4e0a\u6807",
      sections: [
        section("\u4e0b\u6807\u548c\u4e0a\u6807", [
          template("\u25a1\u02e3", "x^2"), template("\u25a1\u1d62", "x_i"), template("\u25a1\u1d62\u02e3", "x_i^2"), template("\u207f\u2081Y", "{}_1^nY")
        ]),
        section("\u5e38\u7528\u7684\u4e0b\u6807\u548c\u4e0a\u6807", [
          template("x\u1d67\u00b2", "x_y^2"), template("e\u207b\u1d62\u03c9t", "e^{-i\\omega t}"), template("x\u00b2", "x^2"), template("\u207f\u2081Y", "{}_1^nY")
        ])
      ]
    },
    radical: {
      title: "\u6839\u5f0f",
      sections: [
        section("\u6839\u5f0f", [
          template("\u221a\u25a1", "\\sqrt{x}"), template("\u25a1\u221a\u25a1", "\\sqrt[n]{x}"), template("\u00b2\u221a\u25a1", "\\sqrt[2]{x}"), template("\u00b3\u221a\u25a1", "\\sqrt[3]{x}")
        ]),
        section("\u5e38\u7528\u6839\u5f0f", [
          template("-b \u00b1 \u221ab\u00b2 - 4ac\n\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n2a", "\\frac{-b\\pm\\sqrt{b^2-4ac}}{2a}", true),
          template("\u221aa\u00b2 + b\u00b2", "\\sqrt{a^2+b^2}", true)
        ])
      ]
    },
    integral: {
      title: "\u79ef\u5206",
      sections: [
        section("\u79ef\u5206", [
          template("\u222b \u25a1", "\\int f(x)\\,dx"), template("\u222b\u2090\u1d47 \u25a1", "\\int_a^b f(x)\\,dx"), template("\u222b\u25a1\u25a1 \u25a1", "\\int_{a}^{b} f(x)\\,dx"),
          template("\u222c \u25a1", "\\iint_A f(x,y)\\,dx\\,dy"), template("\u222c\u2090\u1d47 \u25a1", "\\iint_A f(x,y)\\,dA"), template("\u222c\u25a1\u25a1 \u25a1", "\\iint_{A} f(x,y)\\,dA"),
          template("\u222d \u25a1", "\\iiint_V f(x,y,z)\\,dV"), template("\u222d\u2090\u1d47 \u25a1", "\\iiint_V f(x,y,z)\\,dV"), template("\u222d\u25a1\u25a1 \u25a1", "\\iiint_{V} f(x,y,z)\\,dV")
        ]),
        section("\u56f4\u9053\u79ef\u5206", [
          template("\u222e \u25a1", "\\oint_C f(z)\\,dz"), template("\u222e\u2090\u1d47 \u25a1", "\\oint_C f(z)\\,dz"), template("\u222e\u25a1\u25a1 \u25a1", "\\oint_{C} f(z)\\,dz"),
          template("\u222f \u25a1", "\\oiint_S f\\,dS"), template("\u222f\u2090\u1d47 \u25a1", "\\oiint_S f\\,dS"), template("\u222f\u25a1\u25a1 \u25a1", "\\oiint_{S} f\\,dS"),
          template("\u2230 \u25a1", "\\oiiint_V f\\,dV"), template("\u2230\u2090\u1d47 \u25a1", "\\oiiint_V f\\,dV"), template("\u2230\u25a1\u25a1 \u25a1", "\\oiiint_{V} f\\,dV")
        ]),
        section("\u5fae\u5206", [
          template("dx", "\\,dx"), template("dy", "\\,dy"), template("d\u03b8", "\\,d\\theta")
        ])
      ]
    },
    largeop: {
      title: "\u5927\u578b\u8fd0\u7b97\u7b26",
      sections: [
        section("\u6c42\u548c", [
          template("\u2211 \u25a1", "\\sum x_i"), template("\u2211\u1d62 \u25a1", "\\sum_i x_i"), template("\u2211\u1d62\u207f \u25a1", "\\sum_{i=0}^{n} x_i"), template("\u2211 \u25a1\u1d62", "\\sum x_i"), template("\u2211\u25a1\u25a1 \u25a1", "\\sum_{i}^{n} x_i")
        ]),
        section("\u4e58\u79ef\u548c\u526f\u79ef", [
          template("\u220f \u25a1", "\\prod x_i"), template("\u220f\u1d62 \u25a1", "\\prod_i x_i"), template("\u220f\u1d62\u207f \u25a1", "\\prod_{i=1}^{n} x_i"), template("\u2210 \u25a1", "\\coprod A_i"), template("\u2210\u1d62\u207f \u25a1", "\\coprod_{i=1}^{n} A_i")
        ]),
        section("\u5e76\u96c6\u548c\u4ea4\u96c6", [
          template("\u22c3 \u25a1", "\\bigcup A_i"), template("\u22c3\u1d62 \u25a1", "\\bigcup_i A_i"), template("\u22c3\u1d62\u207f \u25a1", "\\bigcup_{i=1}^{n} A_i"), template("\u22c2 \u25a1", "\\bigcap A_i"), template("\u22c2\u1d62\u207f \u25a1", "\\bigcap_{i=1}^{n} A_i")
        ]),
        section("\u5176\u4ed6\u5927\u578b\u8fd0\u7b97\u7b26", [
          template("\u22c1 \u25a1", "\\bigvee A_i"), template("\u22c1\u1d62 \u25a1", "\\bigvee_i A_i"), template("\u22c0 \u25a1", "\\bigwedge A_i"), template("\u22c0\u1d62 \u25a1", "\\bigwedge_i A_i")
        ]),
        section("\u5e38\u7528\u5927\u578b\u8fd0\u7b97\u7b26", [
          template("\u2211\u2096 (n\u2096)", "\\sum_k n_k"), template("\u2211\u1d62\u208c\u2080\u207f", "\\sum_{i=0}^{n} x_i"), template("\u2211 P(i,j)", "\\sum_{0\\le i,j\\le m}^{n} P(i,j)", true), template("\u220f\u2096\u208c\u2081\u207f A\u2096", "\\prod_{k=1}^{n} A_k")
        ])
      ]
    },
    bracket: {
      title: "\u62ec\u53f7",
      sections: [
        section("\u62ec\u53f7", [
          template("(\u25a1)", "\\left( x \\right)"), template("[\u25a1]", "\\left[ x \\right]"), template("{\u25a1}", "\\left\\{ x \\right\\}"), template("\u27e8\u25a1\u27e9", "\\left\\langle x \\right\\rangle"),
          template("[\u25a1)", "\\left[ x \\right)"), template("(\u25a1]", "\\left( x \\right]"), template("|\u25a1|", "\\left| x \\right|"), template("||\u25a1||", "\\left\\| x \\right\\|"),
          template("[\u25a1[", "\\left[ x \\right["), template("]\u25a1]", "\\left] x \\right]"), template("]\u25a1[", "\\left] x \\right["), template("[[\u25a1]]", "\\left\\llbracket x \\right\\rrbracket")
        ]),
        section("\u5e26\u5206\u9694\u7b26\u7684\u62ec\u53f7", [
          template("(\u25a1|\u25a1)", "\\left( x \\middle| y \\right)"), template("{\u25a1|\u25a1}", "\\left\\{ x \\middle| y \\right\\}"), template("\u27e8\u25a1|\u25a1\u27e9", "\\left\\langle x \\middle| y \\right\\rangle"), template("\u27e8\u25a1|\u25a1|\u25a1\u27e9", "\\left\\langle x \\middle| y \\middle| z \\right\\rangle")
        ]),
        section("\u5355\u62ec\u53f7", [
          template("(\u25a1", "\\left( x \\right."), template("\u25a1)", "\\left. x \\right)"), template("[\u25a1", "\\left[ x \\right."), template("\u25a1]", "\\left. x \\right]"),
          template("{\u25a1", "\\left\\{ x \\right."), template("\u25a1}", "\\left. x \\right\\}"), template("\u27e8\u25a1", "\\left\\langle x \\right."), template("\u25a1\u27e9", "\\left. x \\right\\rangle")
        ])
      ]
    },
    function: {
      title: "\u51fd\u6570",
      sections: [
        section("\u4e09\u89d2\u51fd\u6570", [
          template("sin \u25a1", "\\sin x"), template("cos \u25a1", "\\cos x"), template("tan \u25a1", "\\tan x"), template("csc \u25a1", "\\csc x"), template("sec \u25a1", "\\sec x"), template("cot \u25a1", "\\cot x")
        ]),
        section("\u53cd\u51fd\u6570", [
          template("sin\u207b\u00b9 \u25a1", "\\sin^{-1} x"), template("cos\u207b\u00b9 \u25a1", "\\cos^{-1} x"), template("tan\u207b\u00b9 \u25a1", "\\tan^{-1} x"), template("csc\u207b\u00b9 \u25a1", "\\csc^{-1} x"), template("sec\u207b\u00b9 \u25a1", "\\sec^{-1} x"), template("cot\u207b\u00b9 \u25a1", "\\cot^{-1} x")
        ]),
        section("\u53cc\u66f2\u51fd\u6570", [
          template("sinh \u25a1", "\\sinh x"), template("cosh \u25a1", "\\cosh x"), template("tanh \u25a1", "\\tanh x"), template("csch \u25a1", "\\operatorname{csch} x"), template("sech \u25a1", "\\operatorname{sech} x"), template("coth \u25a1", "\\coth x")
        ]),
        section("\u53cd\u53cc\u66f2\u51fd\u6570", [
          template("sinh\u207b\u00b9 \u25a1", "\\sinh^{-1} x"), template("cosh\u207b\u00b9 \u25a1", "\\cosh^{-1} x"), template("tanh\u207b\u00b9 \u25a1", "\\tanh^{-1} x"), template("csch\u207b\u00b9 \u25a1", "\\operatorname{csch}^{-1} x"), template("sech\u207b\u00b9 \u25a1", "\\operatorname{sech}^{-1} x"), template("coth\u207b\u00b9 \u25a1", "\\coth^{-1} x")
        ])
      ]
    },
    accent: {
      title: "\u6807\u6ce8\u7b26\u53f7",
      sections: [
        section("\u6807\u6ce8\u7b26\u53f7", [
          template("\u0307\n\u25a1", "\\dot{x}"), template("\u0308\n\u25a1", "\\ddot{x}"), template("\u20db\n\u25a1", "\\dddot{x}"), template("\u0302\n\u25a1", "\\hat{x}"),
          template("\u030c\n\u25a1", "\\check{x}"), template("\u0306\n\u25a1", "\\breve{x}"), template("\u0303\n\u25a1", "\\tilde{x}"), template("\u0304\n\u25a1", "\\bar{x}"),
          template("\u2190\n\u25a1", "\\overleftarrow{x}"), template("\u2194\n\u25a1", "\\overleftrightarrow{x}"), template("\u2192\n\u25a1", "\\overrightarrow{x}")
        ]),
        section("\u5e26\u6846\u516c\u5f0f", [
          template("\u25a1", "\\boxed{x}"), template("a\u00b2 - b\u00b2 + c\u00b2", "\\boxed{a^2-b^2+c^2}", true)
        ]),
        section("\u9876\u7ebf\u548c\u5e95\u7ebf", [
          template("\u203e\n\u25a1", "\\overline{x}"), template("\u25a1\n_", "\\underline{x}")
        ]),
        section("\u5e38\u7528\u6807\u6ce8\u7b26\u53f7\u5bf9\u8c61", [
          template("\u0100", "\\bar{A}"), template("\u203eABC", "\\overline{ABC}"), template("x \u2295 y", "x\\oplus y", true)
        ])
      ]
    },
    limitlog: {
      title: "\u51fd\u6570",
      sections: [
        section("\u51fd\u6570", [
          template("log\u25a1 \u25a1", "\\log_{a} x"), template("log \u25a1", "\\log x"), template("lim\u25a1 \u25a1", "\\lim_{x\\to 0} f(x)"), template("min\u25a1 \u25a1", "\\min_{x} f(x)"), template("max\u25a1 \u25a1", "\\max_{x} f(x)"), template("ln \u25a1", "\\ln x")
        ]),
        section("\u5e38\u7528\u51fd\u6570", [
          template("lim\u2099\u2192\u221e (1 + 1/n)\u207f", "\\lim_{n\\to\\infty}\\left(1+\\frac{1}{n}\\right)^n", true),
          template("max\u2080\u2264x\u22641 xe\u207b\u02e3\u00b2", "\\max_{0\\le x\\le 1} xe^{-x^2}", true)
        ])
      ]
    },
    operator: {
      title: "\u57fa\u672c\u8fd0\u7b97\u7b26",
      sections: [
        section("\u57fa\u672c\u8fd0\u7b97\u7b26", [
          template("\u22c5=", "\\doteq"), template("==", "\\equiv"), template("+=", "+="), template("-=", "-="), template("def\n=", "\\overset{\\text{def}}{=}"), template("m\n=", "\\overset{m}{=}"), template("\u0394\n=", "\\overset{\\Delta}{=}")
        ]),
        section("\u8fd0\u7b97\u7b26\u7ed3\u6784", [
          template("\u2190\n\u25a1", "\\xleftarrow{x}"), template("\u2192\n\u25a1", "\\xrightarrow{x}"), template("\u25a1\n\u2190", "\\underset{x}{\\leftarrow}"), template("\u25a1\n\u2192", "\\underset{x}{\\rightarrow}"),
          template("\u21d0\n\u25a1", "\\xLeftarrow{x}"), template("\u21d2\n\u25a1", "\\xRightarrow{x}"), template("\u21d4\n\u25a1", "\\xleftrightarrow{x}"), template("\u25a1\n\u21d4", "\\underset{x}{\\leftrightarrow}")
        ]),
        section("\u5e38\u7528\u8fd0\u7b97\u7b26\u7ed3\u6784", [
          template("yields\n\u2192", "\\xrightarrow{\\text{yields}}", true), template("\u0394\n\u2192", "\\xrightarrow{\\Delta}")
        ])
      ]
    },
    matrix: {
      title: "\u7a7a\u77e9\u9635",
      sections: [
        section("\u7a7a\u77e9\u9635", [
          template("\u25a1 \u25a1", "\\begin{matrix}a&b\\end{matrix}"), template("\u25a1\n\u25a1", "\\begin{matrix}a\\\\b\\end{matrix}"), template("\u25a1 \u25a1 \u25a1", "\\begin{matrix}a&b&c\\end{matrix}"), template("\u25a1\n\u25a1\n\u25a1", "\\begin{matrix}a\\\\b\\\\c\\end{matrix}"),
          template("\u25a1 \u25a1\n\u25a1 \u25a1", "\\begin{matrix}a&b\\\\c&d\\end{matrix}"), template("\u25a1 \u25a1 \u25a1\n\u25a1 \u25a1 \u25a1", "\\begin{matrix}a&b&c\\\\d&e&f\\end{matrix}"), template("\u25a1 \u25a1\n\u25a1 \u25a1\n\u25a1 \u25a1", "\\begin{matrix}a&b\\\\c&d\\\\e&f\\end{matrix}"), template("\u25a1 \u25a1 \u25a1\n\u25a1 \u25a1 \u25a1\n\u25a1 \u25a1 \u25a1", "\\begin{matrix}a&b&c\\\\d&e&f\\\\g&h&i\\end{matrix}")
        ]),
        section("\u7701\u7565\u53f7", [
          template("\u22ef", "\\cdots"), template("\u2026", "\\ldots"), template("\u22ee", "\\vdots"), template("\u22f1", "\\ddots")
        ]),
        section("\u5355\u4f4d\u77e9\u9635", [
          template("1  0\n0  1", "\\begin{matrix}1&0\\\\0&1\\end{matrix}"), template("1\n  1", "\\begin{matrix}1&0\\\\0&1\\end{matrix}"), template("1 0 0\n0 1 0\n0 0 1", "\\begin{matrix}1&0&0\\\\0&1&0\\\\0&0&1\\end{matrix}"), template("1\n  1\n    1", "\\begin{matrix}1&0&0\\\\0&1&0\\\\0&0&1\\end{matrix}")
        ]),
        section("\u62ec\u53f7\u77e9\u9635", [
          template("(\u25a1 \u25a1\n \u25a1 \u25a1)", "\\begin{pmatrix}a&b\\\\c&d\\end{pmatrix}"), template("[\u25a1 \u25a1\n \u25a1 \u25a1]", "\\begin{bmatrix}a&b\\\\c&d\\end{bmatrix}"), template("|\u25a1 \u25a1\n \u25a1 \u25a1|", "\\begin{vmatrix}a&b\\\\c&d\\end{vmatrix}"), template("||\u25a1 \u25a1\n \u25a1 \u25a1||", "\\begin{Vmatrix}a&b\\\\c&d\\end{Vmatrix}")
        ]),
        section("\u7a00\u758f\u77e9\u9635", [
          template("(\u25a1 \u22ef \u25a1\n\u22ee \u22f1 \u22ee\n\u25a1 \u22ef \u25a1)", "\\begin{pmatrix}a&\\cdots&b\\\\\\vdots&\\ddots&\\vdots\\\\c&\\cdots&d\\end{pmatrix}", true),
          template("[\u25a1 \u22ef \u25a1\n\u22ee \u22f1 \u22ee\n\u25a1 \u22ef \u25a1]", "\\begin{bmatrix}a&\\cdots&b\\\\\\vdots&\\ddots&\\vdots\\\\c&\\cdots&d\\end{bmatrix}", true)
        ])
      ]
    }
  };

  function categories() {
    var cats = window.DavaEquationRegistry.getCategories();
    var recent = window.DavaEquationRecentStore.read();
    cats.forEach(function (cat) {
      if (cat.id === "recent") {
        cat.templates = recent.map(function (item) {
          return { label: item.label, latex: item.latex, description: item.latex };
        });
      }
    });
    return cats;
  }

  function renderCategories(activeId) {
    var box = panel.querySelector(".equation-categories");
    if (!box) return;
    box.textContent = "";
    categories().forEach(function (cat) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cat" + (cat.id === activeId ? " active" : "");
      btn.textContent = cat.label;
      btn.addEventListener("click", function () { renderTemplates(cat.id); });
      box.appendChild(btn);
    });
  }

  function renderTemplates(activeId) {
    var cats = categories();
    var cat = cats.filter(function (item) { return item.id === activeId; })[0] || cats[1] || cats[0];
    renderCategories(cat.id);
    var grid = panel.querySelector(".quick-templates");
    if (!grid) return;
    grid.textContent = "";
    (cat.templates || []).forEach(function (template) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "template";
      btn.title = template.description || template.latex;
      btn.textContent = template.label;
      btn.addEventListener("click", function () {
        window.DavaEquationMathLiveAdapter.insertTemplate(mathField, template.latex);
        syncSourceFromField();
        schedulePreview();
      });
      grid.appendChild(btn);
    });
  }

  function insertLatex(latex) {
    if (mathField) {
      window.DavaEquationMathLiveAdapter.insertTemplate(mathField, latex);
      syncSourceFromField();
    } else if (latexSource) {
      latexSource.value = (latexSource.value || "") + latex;
    }
    panel.querySelector(".latex-readout").textContent = currentLatex();
    if (mathField) panel.querySelector(".mathml-source").value = window.DavaEquationMathLiveAdapter.getMathML(mathField);
    schedulePreview();
  }

  function closeGallery() {
    if (!gallery) return;
    gallery.classList.remove("open");
    gallery.textContent = "";
  }

  function positionGallery(anchor) {
    if (!gallery || !anchor || !panel) return;
    var panelRect = panel.getBoundingClientRect();
    var anchorRect = anchor.getBoundingClientRect();
    var left = Math.max(8, anchorRect.left - panelRect.left);
    var top = Math.max(8, anchorRect.bottom - panelRect.top + 2);
    var maxLeft = Math.max(8, panelRect.width - gallery.offsetWidth - 8);
    gallery.style.left = Math.min(left, maxLeft) + "px";
    gallery.style.top = top + "px";
  }

  function renderGalleryItem(item) {
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "gallery-item" + (item.wide ? " wide" : "");
    btn.title = item.latex;
    btn.textContent = item.preview;
    btn.addEventListener("click", function () {
      insertLatex(item.latex);
      closeGallery();
    });
    return btn;
  }

  function openGallery(id, anchor) {
    var data = equationGalleries[id];
    if (!data || !gallery) return;
    gallery.textContent = "";
    var title = document.createElement("div");
    title.className = "gallery-title";
    title.textContent = data.title;
    gallery.appendChild(title);
    data.sections.forEach(function (sectionData) {
      var sectionBox = document.createElement("section");
      sectionBox.className = "gallery-section";
      var sectionTitle = document.createElement("div");
      sectionTitle.className = "gallery-section-title";
      sectionTitle.textContent = sectionData.title;
      var grid = document.createElement("div");
      grid.className = "gallery-grid" + (sectionData.symbolGrid ? " gallery-symbols" : "");
      sectionData.items.forEach(function (item) {
        grid.appendChild(renderGalleryItem(item));
      });
      sectionBox.appendChild(sectionTitle);
      sectionBox.appendChild(grid);
      gallery.appendChild(sectionBox);
    });
    gallery.classList.add("open");
    positionGallery(anchor);
  }

  function renderRibbon() {
    var symbolGrid = panel.querySelector(".symbol-grid");
    var structureGrid = panel.querySelector(".structure-grid");
    if (!symbolGrid || !structureGrid) return;
    symbolGrid.textContent = "";
    ribbonSymbols.forEach(function (item) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "symbol-btn";
      btn.title = item[1];
      btn.textContent = item[0];
      btn.addEventListener("click", function () { insertLatex(item[1]); });
      symbolGrid.appendChild(btn);
    });
    structureGrid.textContent = "";
    ribbonStructures.forEach(function (item) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "structure-btn";
      btn.title = item.label;
      btn.innerHTML = "<span class='structure-icon'></span><span class='structure-label'></span><span class='structure-arrow'>\u25be</span>";
      btn.querySelector(".structure-icon").textContent = item.icon;
      btn.querySelector(".structure-label").textContent = item.label;
      btn.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        openGallery(item.id, btn);
      });
      structureGrid.appendChild(btn);
    });
  }

  function syncSourceFromField() {
    if (latexSource && document.activeElement !== latexSource) {
      latexSource.value = window.DavaEquationMathLiveAdapter.getLatex(mathField);
    }
  }

  function syncFieldFromSource() {
    if (latexSource) window.DavaEquationMathLiveAdapter.setLatex(mathField, latexSource.value);
  }

  function currentLatex() {
    if (latexSource && document.activeElement === latexSource) return latexSource.value;
    return window.DavaEquationMathLiveAdapter.getLatex(mathField) || (latexSource ? latexSource.value : "");
  }

  function schedulePreview() {
    window.clearTimeout(renderTimer);
    renderTimer = window.setTimeout(renderPreview, 180);
  }

  function renderPreview() {
    var preview = panel.querySelector(".preview");
    var error = panel.querySelector(".error");
    var latex = currentLatex();
    preview.textContent = "Rendering...";
    error.textContent = "";
    try {
      latex = window.DavaEquationSanitizer.sanitizeLatex(latex);
    } catch (err) {
      preview.textContent = "";
      error.textContent = err.message;
      return;
    }
    window.DavaEquationRendererMathJax.renderLatexToSvg(latex, {
      displayMode: panel.querySelector(".display-mode").checked,
      idPrefix: "eq-preview-" + Date.now().toString(36)
    }).then(function (svg) {
      preview.textContent = "";
      preview.appendChild(svg);
      selectedLatex = latex;
    }).catch(function (err) {
      preview.textContent = "";
      error.textContent = err.message || String(err);
      if (env && typeof env.post === "function") env.post("svg_editor_equation_render_error", {
        latex: latex,
        error: error.textContent,
        timestamp: Date.now()
      });
    });
  }

  function submit() {
    var latex = currentLatex();
    var options = {
      displayMode: panel.querySelector(".display-mode").checked,
      fill: panel.querySelector(".equation-fill").value || "#000000"
    };
    var command = editingElement ?
      window.DavaEquationEditCommand.editEquationCommand(env, editingElement, latex, options) :
      window.DavaEquationInsertCommand.insertEquationCommand(env, latex, options);
    command.then(close).catch(function (err) {
      panel.querySelector(".error").textContent = err.message || String(err);
    });
  }

  function createPanel() {
    css();
    panel = document.createElement("section");
    panel.id = "dava_equation_panel";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "Equation");
    panel.innerHTML = [
      "<div class='equation-titlebar'><strong>Equation</strong><label><input class='display-mode' type='checkbox' checked>Display</label><label>Color <input class='equation-fill' type='color' value='#000000'></label><button class='source-toggle' type='button'>LaTeX</button><button class='primary submit' type='button'>Insert</button><button class='cancel' type='button'>Cancel</button></div>",
      "<div class='equation-ribbon'><section class='ribbon-group ribbon-symbols'><div class='symbol-wrap'><div class='symbol-grid'></div><button class='symbol-more' type='button' title='More symbols'>\u2304</button></div><div class='ribbon-label'>\u7b26\u53f7</div></section><section class='ribbon-group ribbon-structures'><div class='structure-grid'></div><div class='ribbon-label'>\u7ed3\u6784</div></section></div>",
      "<div class='equation-workspace'><main class='editor-pane'><div class='mathfield-host'></div><textarea class='latex-source' spellcheck='false'></textarea><div class='quick-templates'></div></main><aside class='preview-pane'><h3>Preview</h3><div class='preview'></div><h3>LaTeX</h3><pre class='latex-readout'></pre><h3>MathML</h3><textarea class='mathml-source' readonly></textarea><div class='error'></div></aside></div>"
    ].join("");
    document.body.appendChild(panel);
    latexSource = panel.querySelector(".latex-source");
    gallery = document.createElement("div");
    gallery.className = "equation-gallery";
    gallery.setAttribute("role", "menu");
    panel.appendChild(gallery);
    renderRibbon();
    panel.querySelector(".submit").addEventListener("click", submit);
    panel.querySelector(".cancel").addEventListener("click", close);
    panel.querySelector(".source-toggle").addEventListener("click", function () {
      latexSource.style.display = latexSource.style.display === "none" ? "" : "none";
    });
    panel.querySelector(".symbol-more").addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      openGallery("symbols", event.currentTarget);
    });
    panel.addEventListener("mousedown", function (event) {
      if (!gallery || !gallery.classList.contains("open")) return;
      var target = event.target;
      if (gallery.contains(target) || (target.closest && target.closest(".structure-btn,.symbol-more"))) return;
      closeGallery();
    });
    latexSource.addEventListener("input", function () {
      syncFieldFromSource();
      schedulePreview();
    });
    panel.addEventListener("keydown", function (event) {
      if (handleMathFieldDeleteKey(event)) return;
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        if (gallery && gallery.classList.contains("open")) {
          closeGallery();
          return;
        }
        close();
      } else if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
        event.preventDefault();
        event.stopPropagation();
        submit();
      }
    }, true);
  }

  function mathFieldFromEvent(event) {
    var path = typeof event.composedPath === "function" ? event.composedPath() : [];
    for (var index = 0; index < path.length; index += 1) {
      if (path[index] && path[index].tagName && path[index].tagName.toLowerCase() === "math-field") return path[index];
    }
    return event.target && event.target.closest ? event.target.closest("math-field") : null;
  }

  function executeDeleteCommand(field, key) {
    if (window.DavaEquationMathLiveAdapter && typeof window.DavaEquationMathLiveAdapter.handleDeleteKey === "function") {
      return window.DavaEquationMathLiveAdapter.handleDeleteKey({ key: key, preventDefault: function () {}, stopImmediatePropagation: function () {}, stopPropagation: function () {} }, field);
    }
    if (!field || typeof field.executeCommand !== "function") return false;
    var commands = key === "Backspace" ? ["deleteBackward", "delete-backward"] : ["deleteForward", "delete-forward"];
    for (var index = 0; index < commands.length; index += 1) {
      try {
        if (field.executeCommand(commands[index]) !== false) return true;
      } catch (error) {}
    }
    return false;
  }

  function handleMathFieldDeleteKey(event) {
    if (event.key !== "Backspace" && event.key !== "Delete") return false;
    var field = mathFieldFromEvent(event) || mathField;
    if (!field) return false;
    if (!executeDeleteCommand(field, event.key)) return false;
    event.preventDefault();
    event.stopImmediatePropagation();
    event.stopPropagation();
    field.dispatchEvent(new Event("input", { bubbles: true }));
    return true;
  }

  function init(environment) {
    env = environment || env;
    if (!panel) createPanel();
  }

  function open(options) {
    options = options || {};
    init(env);
    editingElement = options.element || null;
    var initialLatex = options.latex || (editingElement ? editingElement.getAttribute("data-latex") : "") || selectedLatex || "x=\\frac{-b\\pm\\sqrt{b^2-4ac}}{2a}";
    panel.querySelector(".display-mode").checked = options.displayMode !== false;
    panel.querySelector(".equation-fill").value = options.fill || (editingElement ? (editingElement.getAttribute("fill") || "#000000") : "#000000");
    var host = panel.querySelector(".mathfield-host");
    host.textContent = "";
    window.DavaEquationMathLiveAdapter.createMathField(host, { latex: initialLatex }, function (field) {
      mathField = field;
      latexSource.value = initialLatex;
      latexSource.style.display = "none";
      if (field) {
        field.addEventListener("input", function () {
          syncSourceFromField();
          panel.querySelector(".latex-readout").textContent = currentLatex();
          panel.querySelector(".mathml-source").value = window.DavaEquationMathLiveAdapter.getMathML(field);
          schedulePreview();
        });
      }
      renderPreview();
      if (field && typeof field.focus === "function") field.focus();
    });
    panel.querySelector(".submit").textContent = editingElement ? "Update" : "Insert";
    panel.classList.add("open");
    document.body.classList.add("dava-equation-panel-open");
    renderTemplates("common");
  }

  function close() {
    if (!panel) return;
    panel.classList.remove("open");
    document.body.classList.remove("dava-equation-panel-open");
    if (mathField) {
      window.DavaEquationMathLiveAdapter.destroyMathField(mathField);
      mathField = null;
    }
    editingElement = null;
  }

  window.DavaEquationPanel = {
    init: init,
    open: open,
    close: close
  };
})();
