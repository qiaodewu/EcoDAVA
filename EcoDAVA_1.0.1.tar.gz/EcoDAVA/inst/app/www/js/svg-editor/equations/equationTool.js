(function () {
  "use strict";

  function init(env) {
    if (window.DavaEquationPanel) window.DavaEquationPanel.init(env);
  }

  function open(env, options) {
    init(env);
    window.DavaEquationPanel.open(options || {});
  }

  window.DavaEquationTool = {
    init: init,
    open: open
  };
})();
