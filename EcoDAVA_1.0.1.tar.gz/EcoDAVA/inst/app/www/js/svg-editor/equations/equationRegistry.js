(function () {
  "use strict";

  var defaults = {
    fontSize: 28,
    fill: "#000000",
    displayMode: true,
    fontFamily: "Cambria Math, STIX Two Math, Noto Sans Math, Latin Modern Math, serif"
  };

  function getCategories() {
    return (window.DavaEquationTemplates && window.DavaEquationTemplates.categories || []).slice();
  }

  window.DavaEquationRegistry = {
    defaults: defaults,
    getCategories: getCategories,
    getTemplateCategories: getCategories
  };
})();
