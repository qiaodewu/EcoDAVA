(function () {
  "use strict";

  var scriptLoading = false;
  var scriptLoaded = false;
  var callbacks = [];

  function loadMathLive(callback) {
    if (window.MathfieldElement || scriptLoaded) {
      callback();
      return;
    }
    callbacks.push(callback);
    if (scriptLoading) return;
    scriptLoading = true;

    var css1 = document.createElement("link");
    css1.rel = "stylesheet";
    css1.href = "/vendor/mathlive/mathlive-static.css";
    document.head.appendChild(css1);

    var css2 = document.createElement("link");
    css2.rel = "stylesheet";
    css2.href = "/vendor/mathlive/mathlive-fonts.css";
    document.head.appendChild(css2);

    var script = document.createElement("script");
    script.src = "/vendor/mathlive/mathlive.min.js";
    script.onload = function () {
      scriptLoaded = true;
      scriptLoading = false;
      callbacks.splice(0).forEach(function (fn) { fn(); });
    };
    script.onerror = function () {
      scriptLoading = false;
      callbacks.splice(0).forEach(function (fn) { fn(); });
    };
    document.head.appendChild(script);
  }

  function createFallback(container, options) {
    var textarea = document.createElement("textarea");
    textarea.className = "dava-equation-latex-fallback";
    textarea.spellcheck = false;
    textarea.value = options && options.latex || "";
    container.appendChild(textarea);
    return textarea;
  }

  function valueOf(field) {
    try {
      return typeof field.getValue === "function" ? field.getValue("latex") : field.value;
    } catch (error) {
      return field.value || "";
    }
  }

  function dispatchInput(field) {
    field.dispatchEvent(new Event("input", { bubbles: true }));
  }

  function executeDeleteCommand(field, key) {
    if (!field || typeof field.executeCommand !== "function") return false;
    var before = valueOf(field);
    var commands = key === "Backspace" ? ["deleteBackward", "delete-backward"] : ["deleteForward", "delete-forward"];
    for (var index = 0; index < commands.length; index += 1) {
      try {
        field.executeCommand(commands[index]);
        if (valueOf(field) !== before) return true;
      } catch (error) {}
    }
    return false;
  }

  function fallbackDelete(field, key) {
    if (!field || typeof field.insert !== "function") return false;
    var before = valueOf(field);
    try {
      if (!field.selectionIsCollapsed) {
        field.insert("", { insertionMode: "replaceSelection" });
      } else {
        var position = Number(field.position || 0);
        var lastOffset = Number(field.lastOffset || 0);
        if (key === "Backspace" && position > 0) {
          field.selection = { ranges: [[position - 1, position]], direction: "forward" };
          field.insert("", { insertionMode: "replaceSelection" });
        } else if (key === "Delete" && position < lastOffset) {
          field.selection = { ranges: [[position, position + 1]], direction: "forward" };
          field.insert("", { insertionMode: "replaceSelection" });
        }
      }
    } catch (error) {}
    return valueOf(field) !== before;
  }

  function handleDeleteKey(event, field) {
    if (!event || (event.key !== "Backspace" && event.key !== "Delete")) return false;
    if (!field) return false;
    if (!executeDeleteCommand(field, event.key) && !fallbackDelete(field, event.key)) return false;
    event.preventDefault();
    if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
    event.stopPropagation();
    dispatchInput(field);
    return true;
  }

  function bindDeleteKeyHandlers(field) {
    var handler = function (event) {
      handleDeleteKey(event, field);
    };
    field.addEventListener("keydown", handler, true);
    window.setTimeout(function () {
      if (field.shadowRoot && !field.shadowRoot.__davaEquationDeleteBound) {
        field.shadowRoot.__davaEquationDeleteBound = true;
        field.shadowRoot.addEventListener("keydown", handler, true);
      }
    }, 0);
  }

  function createMathField(container, options, callback) {
    loadMathLive(function () {
      var field;
      if (window.MathfieldElement) {
        field = document.createElement("math-field");
        field.className = "dava-equation-mathfield";
        field.setAttribute("virtual-keyboard-mode", "manual");
        field.setAttribute("math-virtual-keyboard-policy", "manual");
        field.value = options && options.latex || "";
        container.appendChild(field);
        bindDeleteKeyHandlers(field);
      } else {
        field = createFallback(container, options || {});
      }
      if (callback) callback(field);
    });
  }

  function setLatex(field, latex) {
    if (!field) return;
    if (typeof field.setValue === "function") field.setValue(latex || "");
    else field.value = latex || "";
  }

  function getLatex(field) {
    if (!field) return "";
    if (typeof field.getValue === "function") return field.getValue("latex") || "";
    return field.value || "";
  }

  function insertTemplate(field, latex) {
    if (!field) return;
    if (typeof field.insert === "function") {
      field.insert(latex, { insertionMode: "replaceSelection" });
    } else {
      var start = field.selectionStart || 0;
      var end = field.selectionEnd || start;
      field.value = field.value.slice(0, start) + latex + field.value.slice(end);
      field.selectionStart = field.selectionEnd = start + latex.length;
      field.dispatchEvent(new Event("input", { bubbles: true }));
    }
    if (typeof field.focus === "function") field.focus();
  }

  function getMathML(field) {
    try {
      if (field && typeof field.getValue === "function") return field.getValue("math-ml") || "";
    } catch (error) {}
    return "";
  }

  function destroyMathField(field) {
    if (field && field.parentNode) field.parentNode.removeChild(field);
  }

  window.DavaEquationMathLiveAdapter = {
    createMathField: createMathField,
    setLatex: setLatex,
    getLatex: getLatex,
    insertTemplate: insertTemplate,
    handleDeleteKey: handleDeleteKey,
    getMathML: getMathML,
    destroyMathField: destroyMathField
  };
})();
