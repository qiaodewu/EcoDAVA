(function () {
  "use strict";

  var loading = false;
  var ready = false;
  var callbacks = [];

  function initMathJaxRenderer(callback) {
    if (ready && window.MathJax && window.MathJax.tex2svgPromise) {
      callback();
      return;
    }
    callbacks.push(callback);
    if (loading) return;
    loading = true;
    window.MathJax = window.MathJax || {
      tex: {
        packages: { "[+]": ["base", "ams", "newcommand"] },
        inlineMath: [["\\(", "\\)"]],
        displayMath: [["\\[", "\\]"]]
      },
      svg: { fontCache: "none" },
      startup: { typeset: false }
    };
    var script = document.createElement("script");
    script.src = "/vendor/mathjax/tex-svg.js";
    script.onload = function () {
      var done = function () {
        ready = true;
        loading = false;
        callbacks.splice(0).forEach(function (fn) { fn(); });
      };
      if (window.MathJax && window.MathJax.startup && window.MathJax.startup.promise) {
        window.MathJax.startup.promise.then(done).catch(done);
      } else {
        done();
      }
    };
    script.onerror = function () {
      loading = false;
      callbacks.splice(0).forEach(function (fn) { fn(); });
    };
    document.head.appendChild(script);
  }

  function rewriteIds(root, prefix) {
    var idMap = {};
    Array.prototype.forEach.call(root.querySelectorAll("[id]"), function (node) {
      var oldId = node.getAttribute("id");
      var newId = prefix + "-" + oldId;
      idMap[oldId] = newId;
      node.setAttribute("id", newId);
    });
    Array.prototype.forEach.call(root.querySelectorAll("*"), function (node) {
      Array.prototype.forEach.call(node.attributes || [], function (attr) {
        var value = attr.value;
        Object.keys(idMap).forEach(function (oldId) {
          value = value.replace(new RegExp("url\\(#" + oldId + "\\)", "g"), "url(#" + idMap[oldId] + ")");
          value = value.replace(new RegExp("#" + oldId + "\\b", "g"), "#" + idMap[oldId]);
        });
        if (value !== attr.value) node.setAttribute(attr.name, value);
      });
    });
  }

  function sanitizeMathJaxSvg(svg) {
    Array.prototype.forEach.call(svg.querySelectorAll("script,foreignObject,iframe,object,embed"), function (node) {
      if (node.parentNode) node.parentNode.removeChild(node);
    });
    Array.prototype.forEach.call(svg.querySelectorAll("*"), function (node) {
      Array.prototype.slice.call(node.attributes || []).forEach(function (attr) {
        if (/^on/i.test(attr.name)) node.removeAttribute(attr.name);
      });
    });
    return svg;
  }

  function normalizeMathJaxSvgForEditor(svg, options) {
    var idPrefix = options && options.idPrefix || ("eq-mjx-" + Date.now());
    svg.setAttribute("overflow", "visible");
    svg.removeAttribute("style");
    svg.setAttribute("data-equation-rendered", "mathjax");
    rewriteIds(svg, idPrefix);
    return sanitizeMathJaxSvg(svg);
  }

  function renderLatexToSvg(latex, options) {
    options = options || {};
    return new Promise(function (resolve, reject) {
      initMathJaxRenderer(function () {
        if (!window.MathJax || !window.MathJax.tex2svgPromise) {
          reject(new Error("MathJax tex-svg renderer is not available."));
          return;
        }
        window.MathJax.tex2svgPromise(latex, { display: options.displayMode !== false }).then(function (node) {
          var svg = node.querySelector("svg");
          if (!svg) throw new Error("MathJax did not return SVG output.");
          resolve(normalizeMathJaxSvgForEditor(svg.cloneNode(true), options));
        }).catch(reject);
      });
    });
  }

  function getEquationBounds(equationEl) {
    if (!equationEl || typeof equationEl.getBBox !== "function") return null;
    try { return equationEl.getBBox(); } catch (error) { return null; }
  }

  window.DavaEquationRendererMathJax = {
    initMathJaxRenderer: initMathJaxRenderer,
    renderLatexToSvg: renderLatexToSvg,
    sanitizeMathJaxSvg: sanitizeMathJaxSvg,
    normalizeMathJaxSvgForEditor: normalizeMathJaxSvgForEditor,
    getEquationBounds: getEquationBounds
  };
})();
