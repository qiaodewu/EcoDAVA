(function () {
  "use strict";

  var panel = null;
  var statusNode = null;
  var downloadObjectUrl = null;
  var resultRevision = 0;

  function el(tag, attrs, text) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      if (key === "className") node.className = attrs[key];
      else node.setAttribute(key, attrs[key]);
    });
    if (text != null) node.textContent = text;
    return node;
  }

  function row(label, input) {
    var wrap = el("label", { className: "dava-export-row" });
    wrap.appendChild(el("span", {}, label));
    wrap.appendChild(input);
    return wrap;
  }

  function select(name, values) {
    var node = el("select", { name: name });
    values.forEach(function (item) {
      var option = el("option", { value: item.value }, item.label);
      if (item.selected) option.selected = true;
      node.appendChild(option);
    });
    return node;
  }

  function normalizeEnglishText() {
    if (!panel) return;
    var title = panel.querySelector(".dava-export-head strong");
    var close = panel.querySelector(".dava-export-head button");
    if (title) title.textContent = "Export";
    if (close) {
      close.textContent = "x";
      close.setAttribute("title", "Close");
    }
    var labels = {
      fileName: "File name",
      format: "Format",
      background: "Background",
      backgroundColor: "Background color",
      engine: "PDF engine",
      textMode: "Text",
      dpi: "TIFF DPI",
      compression: "TIFF compression",
      colorspace: "Color mode"
    };
    Object.keys(labels).forEach(function (name) {
      var input = panel.querySelector("[name='" + name + "']");
      var label = input && input.closest ? input.closest(".dava-export-row") : null;
      var span = label && label.querySelector("span");
      if (span) span.textContent = labels[name];
    });
    var fileName = panel.querySelector("[name='fileName']");
    if (fileName && !fileName.value) fileName.value = "Untitled-1";
    var optionLabels = {
      "pdf_vector": "PDF (Vector)",
      "tiff": "TIFF (High-resolution)",
      "svg": "SVG",
      "png": "PNG",
      "white": "White",
      "transparent": "Transparent",
      "custom": "Custom color",
      "auto": "Auto",
      "inkscape": "Inkscape",
      "rsvg": "rsvg",
      "cairosvg": "CairoSVG",
      "keep-text": "Keep text",
      "text-to-path": "Convert text to paths",
      "300": "300",
      "600": "600",
      "1200": "1200",
      "lzw": "LZW",
      "zip": "ZIP",
      "none": "None",
      "rgb": "RGB",
      "cmyk": "CMYK"
    };
    Array.prototype.forEach.call(panel.querySelectorAll("option"), function (option) {
      if (Object.prototype.hasOwnProperty.call(optionLabels, option.value)) {
        option.textContent = optionLabels[option.value];
      }
    });
    Array.prototype.forEach.call(panel.querySelectorAll(".dava-export-note"), function (note) {
      note.remove();
    });
    var buttons = panel.querySelectorAll(".dava-export-actions button");
    if (buttons[0]) buttons[0].textContent = "Export";
    if (buttons[1]) buttons[1].textContent = "Cancel";
  }

  function build() {
    if (panel) return panel;
    panel = el("div", { id: "dava_export_panel", className: "dava-export-panel", role: "dialog" });
    var head = el("div", { className: "dava-export-head" });
    head.appendChild(el("strong", {}, "Export / Export"));
    var close = el("button", { type: "button", title: "Close" }, "×");
    close.addEventListener("click", closePanel);
    head.appendChild(close);

    var body = el("div", { className: "dava-export-body" });
    var fileName = el("input", { name: "fileName", type: "text", value: "Not yettitle-1" });
    var doc = window.DavaSimpleDocumentStore && window.DavaSimpleDocumentStore.getActiveDocument && window.DavaSimpleDocumentStore.getActiveDocument();
    if (doc && doc.name) fileName.value = doc.name;
    body.appendChild(row("filename", fileName));
    body.appendChild(row("format", select("format", [
      { value: "pdf_vector", label: "PDF（vector）", selected: true },
      { value: "tiff", label: "TIFF（High quality）" },
      { value: "svg", label: "SVG" },
      { value: "png", label: "PNG" }
    ])));
    body.appendChild(row("Background", select("background", [
      { value: "white", label: "white", selected: true },
      { value: "transparent", label: "Transparent" },
      { value: "custom", label: "CustomColor" }
    ])));
    body.appendChild(row("BackgroundColor", el("input", { name: "backgroundColor", type: "color", value: "#ffffff" })));
    body.appendChild(row("PDF Engine", select("engine", [
      { value: "rsvg", label: "R package: rsvg", selected: true }
    ])));
    body.appendChild(row("text", select("textMode", [
      { value: "keep-text", label: "Keep text", selected: true }
    ])));
    body.appendChild(row("TIFF DPI", select("dpi", [
      { value: "300", label: "300" },
      { value: "600", label: "600", selected: true },
      { value: "1200", label: "1200" }
    ])));
    body.appendChild(row("TIFF Compression", select("compression", [
      { value: "lzw", label: "LZW", selected: true },
      { value: "zip", label: "ZIP" },
      { value: "none", label: "None" }
    ])));
    body.appendChild(row("Color", select("colorspace", [
      { value: "rgb", label: "RGB", selected: true },
      { value: "cmyk", label: "CMYK" }
    ])));
    body.appendChild(el("div", { className: "dava-export-note" }, "PDF Using backend vectorsExport；TIFF YesHigh resolution raster format，NoYesvector format。"));
    statusNode = el("div", { className: "dava-export-status", "data-kind": "idle" }, "");
    body.appendChild(statusNode);

    var actions = el("div", { className: "dava-export-actions" });
    var exportButton = el("button", { type: "button", className: "primary" }, "Export");
    exportButton.addEventListener("click", function () {
      var data = formData();
      window.DavaExportClient.requestExport(data.format, data);
    });
    actions.appendChild(exportButton);
    actions.appendChild(el("button", { type: "button" }, "Cancel"));
    actions.lastChild.addEventListener("click", closePanel);
    body.appendChild(actions);

    panel.appendChild(head);
    panel.appendChild(body);
    document.body.appendChild(panel);
    normalizeEnglishText();
    return panel;
  }

  function formData() {
    var data = {};
    Array.prototype.forEach.call(panel.querySelectorAll("input,select"), function (input) {
      data[input.name] = input.value;
    });
    data.dpi = Number(data.dpi || 600);
    data.timeoutSec = data.format === "tiff" ? 120 : 60;
    return data;
  }

  function open() {
    build();
    normalizeEnglishText();
    panel.style.display = "block";
    setStatus("", "idle");
  }

  function closePanel() {
    if (panel) panel.style.display = "none";
  }

  function setStatus(message, kind) {
    build();
    statusNode.textContent = message || "";
    statusNode.setAttribute("data-kind", kind || "idle");
  }

  function setLoading(loading, message) {
    build();
    panel.setAttribute("data-loading", loading ? "1" : "0");
    var exportButton = panel.querySelector(".dava-export-actions .primary");
    if (exportButton) exportButton.disabled = !!loading;
    if (!message && loading) message = "Exporting...";
    setStatus(message || (loading ? "isExport..." : ""), loading ? "loading" : "idle");
  }

  async function showResult(message) {
    var revision = ++resultRevision;
    message.warnings = Array.isArray(message.warnings) ? message.warnings :
      (message.warnings ? [String(message.warnings)] : []);
    if (!message.success) {
      setStatus((message.error || "Export failed") + "\n" + (message.warnings || []).join("\n"), "error");
      return;
    }
    if (!message.downloadUrl || !message.fileName) {
      setStatus("R reported a successful export, but did not provide a downloadable file. Please retry.", "error");
      return;
    }
    setLoading(true, "Retrieving and verifying the exported file...");
    try {
      var response = await fetch(message.downloadUrl, {credentials: "same-origin", cache: "no-store"});
      if (!response.ok) throw new Error("Download failed: HTTP " + response.status);
      var blob = await response.blob();
      if (!blob.size || (message.fileSize && blob.size !== Number(message.fileSize))) {
        throw new Error("The downloaded file is empty or incomplete.");
      }
      var bytes = new Uint8Array(await blob.slice(0, 8).arrayBuffer());
      var format = String(message.format || "").toLowerCase();
      var matches = function (signature) {
        return signature.every(function (value, index) { return bytes[index] === value; });
      };
      if ((format === "pdf" && !matches([37, 80, 68, 70, 45])) ||
          (format === "png" && !matches([137, 80, 78, 71, 13, 10, 26, 10])) ||
          ((format === "tiff" || format === "tif") &&
           !matches([73, 73, 42, 0]) && !matches([77, 77, 0, 42]))) {
        throw new Error("The server did not return a valid " + format.toUpperCase() + " file.");
      }
      if (revision !== resultRevision) return;
      if (downloadObjectUrl) URL.revokeObjectURL(downloadObjectUrl);
      downloadObjectUrl = URL.createObjectURL(blob);
      setLoading(false);
      setStatus("File verified (" + blob.size + " bytes). Download requested: " + message.fileName, "success");
      var download = document.createElement("a");
      download.href = downloadObjectUrl;
      download.download = message.fileName || "";
      download.textContent = "Download " + (message.fileName || "file");
      download.rel = "noopener";
      statusNode.appendChild(document.createElement("br"));
      statusNode.appendChild(download);
      download.click();
    } catch (error) {
      if (revision !== resultRevision) return;
      setLoading(false);
      setStatus(error.message + " Your drawing is retained. Export has not been downloaded.", "error");
    }
  }

  window.DavaExportPanel = {
    open: open,
    close: closePanel,
    setStatus: setStatus,
    setLoading: setLoading,
    showResult: showResult
  };
})();
