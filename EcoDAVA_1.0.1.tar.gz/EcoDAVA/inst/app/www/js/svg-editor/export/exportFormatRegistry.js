(function () {
  "use strict";

  var formats = {
    svg: {
      id: "svg",
      label: "Export SVG",
      zhLabel: "Export SVG",
      extension: "svg"
    },
    pdf_vector: {
      id: "pdf_vector",
      label: "Export PDF (Vector)",
      zhLabel: "Export PDF（vector）",
      extension: "pdf",
      note: "PDF will be exported as vector content where possible."
    },
    tiff: {
      id: "tiff",
      label: "Export TIFF (High-resolution)",
      zhLabel: "Export TIFF（High quality）",
      extension: "tiff",
      note: "TIFF is a high-resolution raster format, not a vector format."
    },
    png: {
      id: "png",
      label: "Export PNG",
      zhLabel: "Export PNG",
      extension: "png"
    }
  };

  window.DavaExportFormatRegistry = {
    get: function (id) { return formats[id] || formats.svg; },
    all: function () { return Object.keys(formats).map(function (key) { return formats[key]; }); }
  };
})();
