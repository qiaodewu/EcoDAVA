(function () {
  "use strict";

  var pending = {};
  var dependencyDialog = null;
  function closeDependencies() {
    if (dependencyDialog) dependencyDialog.remove();
    dependencyDialog = null;
  }
  function showDependencies(message) {
    closeDependencies();
    var dialog = document.createElement("dialog");
    dependencyDialog = dialog;
    dialog.setAttribute("aria-label", "Export dependencies");
    dialog.style.cssText = "background:#303030;color:#fff;border:1px solid #888;border-radius:8px;padding:24px;max-width:480px;width:calc(100% - 60px);font:14px/1.5 sans-serif;z-index:2147483647";
    var zh = false;
    try { zh = /^zh/.test(window.parent.document.documentElement.lang); } catch (e) {}
    var title = document.createElement("h3");
    title.textContent = zh ? "安装导出依赖" : "Install export dependencies";
    dialog.appendChild(title);
    var description = document.createElement("p");
    var packages = Array.isArray(message.packages) ? message.packages : [message.packages || "rsvg"];
    description.textContent = (zh ? "需要安装：" : "Required packages: ") + packages.join(", ") +
      (zh ? "。安装成功后将按原设置继续保存，编辑内容已保留。" : ". After installation, export will resume with your original settings. Your drawing is retained.");
    dialog.appendChild(description);
    if (message.detail) {
      var detail = document.createElement("pre");
      detail.style.cssText = "white-space:pre-wrap;max-height:160px;overflow:auto";
      detail.textContent = message.detail;
      dialog.appendChild(detail);
    }
    var actions = document.createElement("div");
    dialog.appendChild(actions);
    function choose(action) {
      Array.prototype.forEach.call(actions.querySelectorAll("button"), function (b) { b.disabled = true; });
      description.textContent = action === "install" ?
        (zh ? "正在安装，请稍候。安装日志可在 R 控制台查看。" : "Installing packages. Please wait; installation logs are in the R console.") :
        (zh ? "正在取消…" : "Cancelling...");
      var payload = {requestId: message.requestId, timestamp: Date.now()};
      if (window.parent !== window) {
        window.parent.postMessage({source: "DAVA_SVGEDIT_BRIDGE", type: "DAVA_EXPORT_DEPENDENCY_ACTION",
          action: action, requestId: message.requestId}, window.location.origin);
      } else {
        shiny().setInputValue(nsPrefix() + "svg_export_" + action, payload, {priority: "event"});
      }
    }
    ["install", "cancel"].forEach(function (action) {
      var button = document.createElement("button");
      button.type = "button";
      button.textContent = action === "install" ? (zh ? "安装并继续保存" : "Install and resume export") : (zh ? "取消" : "Cancel");
      button.style.cssText = "padding:8px 12px;margin-right:12px;cursor:pointer";
      button.addEventListener("click", function () { choose(action); });
      actions.appendChild(button);
    });
    dialog.addEventListener("cancel", function (event) { event.preventDefault(); choose("cancel"); });
    document.body.appendChild(dialog);
    if (dialog.showModal) dialog.showModal();
    else { dialog.setAttribute("open", ""); dialog.style.position = "fixed"; dialog.style.top = "20%"; }
  }
  function armTimeout(requestId) {
    if (pending[requestId]) window.clearTimeout(pending[requestId]);
    pending[requestId] = window.setTimeout(function () {
      delete pending[requestId];
      if (window.DavaExportPanel) {
        window.DavaExportPanel.setLoading(false);
        window.DavaExportPanel.setStatus("No response from R. Check the R console and connection, then retry. Your drawing is retained.", "error");
      }
    }, 180000);
  }

  function nsPrefix() {
    try {
      var frame = window.frameElement;
      var root = frame && frame.closest ? frame.closest("[data-dava-svgedit-root='1']") : null;
      return root ? root.getAttribute("data-ns-prefix") || "" : "";
    } catch (error) {
      return "";
    }
  }

  function shiny() {
    try {
      return window.parent && window.parent.Shiny ? window.parent.Shiny : window.Shiny;
    } catch (error) {
      return null;
    }
  }

  function activeDocument() {
    if (window.DavaSimpleDocumentStore && typeof window.DavaSimpleDocumentStore.getActiveDocument === "function") {
      return window.DavaSimpleDocumentStore.getActiveDocument();
    }
    return null;
  }

  function activeCanvas() {
    if (window.DavaSvgEditBridge && typeof window.DavaSvgEditBridge.getSvgCanvas === "function") {
      return window.DavaSvgEditBridge.getSvgCanvas();
    }
    return window.svgEditor && window.svgEditor.svgCanvas;
  }

  function fallbackSerialize() {
    var canvas = activeCanvas();
    if (canvas && typeof canvas.getSvgString === "function") return canvas.getSvgString();
    var root = canvas && typeof canvas.getSvgContent === "function" ? canvas.getSvgContent() : document.querySelector("svg#svgcontent, #svgcontent svg, svg");
    return root ? new XMLSerializer().serializeToString(root) : "";
  }

  function activeSvgRoot() {
    var canvas = activeCanvas();
    return canvas && typeof canvas.getSvgContent === "function" ?
      canvas.getSvgContent() : (document.querySelector ? document.querySelector("svg#svgcontent, #svgcontent svg, svg") : null);
  }

  // Browser geometry is substantially more accurate than parsing path numbers
  // on the server (curves, arcs, text metrics and nested transforms are all
  // resolved here). SVG getBBox() is independent of the root viewport, so it
  // also includes drawing objects placed partly or wholly outside the canvas.
  function getActiveContentBounds() {
    var root = activeSvgRoot();
    if (!root || typeof root.getBBox !== "function") return null;
    var box = null;
    var canvas = activeCanvas();
    try {
      var drawableNames = /^(a|circle|ellipse|foreignobject|g|image|line|path|polygon|polyline|rect|svg|text|use)$/i;
      var topLevelObjects = Array.prototype.filter.call(root.children || [], function (node) {
        var id = String(node.id || "").toLowerCase();
        var style = String(node.getAttribute && node.getAttribute("style") || "").toLowerCase();
        return drawableNames.test(node.localName || node.nodeName || "") &&
          id !== "canvas_background" && id !== "canvasbackground" &&
          !(node.getAttribute && node.getAttribute("data-dava-export-background") === "1") &&
          !(node.getAttribute && node.getAttribute("display") === "none") &&
          !/(^|;)\s*display\s*:\s*none\s*(;|$)/.test(style);
      });
      if (topLevelObjects.length && canvas && typeof canvas.getStrokedBBox === "function") {
        box = canvas.getStrokedBBox(topLevelObjects);
      }
    } catch (canvasError) {
      box = null;
    }
    try {
      if (!box) box = root.getBBox({fill: true, stroke: true, markers: true, clipped: false});
    } catch (error) {
      try { box = root.getBBox(); } catch (fallbackError) { return null; }
    }
    var result = {
      x: Number(box && box.x),
      y: Number(box && box.y),
      width: Number(box && box.width),
      height: Number(box && box.height)
    };
    if (![result.x, result.y, result.width, result.height].every(Number.isFinite) ||
        result.width <= 0 || result.height <= 0) return null;
    return result;
  }

  function getActiveExportSvg() {
    if (window.DavaSimpleDocumentStore && typeof window.DavaSimpleDocumentStore.saveActiveDocumentSnapshot === "function") {
      window.DavaSimpleDocumentStore.saveActiveDocumentSnapshot();
    }
    if (window.DavaSimpleDocumentStore && typeof window.DavaSimpleDocumentStore.serializeActiveSvg === "function") {
      return window.DavaSimpleDocumentStore.serializeActiveSvg();
    }
    if (window.DavaSvgEditBridge && typeof window.DavaSvgEditBridge.getSvgString === "function") {
      return window.DavaSvgEditBridge.getSvgString();
    }
    return fallbackSerialize();
  }

  function requestExport(format, options) {
    options = Object.assign({}, options || {});
    var api = shiny();
    if (!api || typeof api.setInputValue !== "function") {
      if (window.DavaExportPanel) window.DavaExportPanel.setStatus("required Shiny BackendExportServices。", "error");
      return false;
    }
    var doc = activeDocument();
    var requestId = "export-" + Date.now() + "-" + Math.floor(Math.random() * 100000);
    var svgString = "";
    try {
      svgString = getActiveExportSvg();
    } catch (error) {
      if (window.DavaExportPanel) window.DavaExportPanel.setStatus("SVG Prefacecolumnfailed：" + error.message, "error");
      return false;
    }
    if (!/<svg\b/i.test(svgString || "")) {
      if (window.DavaExportPanel) window.DavaExportPanel.setStatus("The current canvas has no availableExportThe true whole of SVG。", "error");
      return false;
    }
    if (!options.contentBounds) {
      var contentBounds = getActiveContentBounds();
      if (contentBounds) options.contentBounds = contentBounds;
    }
    armTimeout(requestId);
    if (window.DavaExportPanel) window.DavaExportPanel.setLoading(true, "Submitting export task...");
    var payload = {
      requestId: requestId,
      documentId: doc && doc.id || "active",
      name: options.fileName || doc && doc.name || "untitled",
      format: format,
      svgString: svgString,
      options: options,
      timestamp: Date.now()
    };
    // The host owns the module namespace; route through the actual iframe.
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ source: "DAVA_SVGEDIT_BRIDGE", type: "DAVA_EXPORT_REQUEST", payload: payload }, window.location.origin);
    } else {
      api.setInputValue(nsPrefix() + "svg_editor_export_request", payload, { priority: "event" });
    }
    return true;
  }

  function handleExportResult(message) {
    if (!message) return;
    if (message.requestId && pending[message.requestId]) window.clearTimeout(pending[message.requestId]);
    if (message.status === "dependencies" || message.status === "working") {
      if (message.status === "dependencies") showDependencies(message);
      else closeDependencies();
      if (message.status === "working") armTimeout(message.requestId);
      if (window.DavaExportPanel) window.DavaExportPanel.setLoading(true,
        message.status === "dependencies" ? "Install the required packages in the application dialog to continue." : "R is exporting the current SVG...");
      return;
    }
    if (message.requestId) delete pending[message.requestId];
    closeDependencies();
    if (window.DavaExportPanel) {
      window.DavaExportPanel.setLoading(false);
      window.DavaExportPanel.showResult(message);
    }
  }

  window.DavaExportClient = {
    getActiveExportSvg: getActiveExportSvg,
    getActiveContentBounds: getActiveContentBounds,
    requestExport: requestExport,
    handleExportResult: handleExportResult
  };
})();
