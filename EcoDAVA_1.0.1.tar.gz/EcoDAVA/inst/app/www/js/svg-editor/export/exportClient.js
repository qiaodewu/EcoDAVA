(function () {
  "use strict";

  var pending = {};

  function nsPrefix() {
    try {
      var frame = window.frameElement;
      var root = frame && frame.closest ? frame.closest("[data-dava-svgedit-root='1']") : null;
      return root ? root.getAttribute("data-ns-prefix") || "" : "";
    } catch (error) {
      return "";
    }
  }

  function shiny() {
    try {
      return window.parent && window.parent.Shiny ? window.parent.Shiny : window.Shiny;
    } catch (error) {
      return null;
    }
  }

  function activeDocument() {
    if (window.DavaSimpleDocumentStore && typeof window.DavaSimpleDocumentStore.getActiveDocument === "function") {
      return window.DavaSimpleDocumentStore.getActiveDocument();
    }
    return null;
  }

  function activeCanvas() {
    if (window.DavaSvgEditBridge && typeof window.DavaSvgEditBridge.getSvgCanvas === "function") {
      return window.DavaSvgEditBridge.getSvgCanvas();
    }
    return window.svgEditor && window.svgEditor.svgCanvas;
  }

  function fallbackSerialize() {
    var canvas = activeCanvas();
    if (canvas && typeof canvas.getSvgString === "function") return canvas.getSvgString();
    var root = canvas && typeof canvas.getSvgContent === "function" ? canvas.getSvgContent() : document.querySelector("svg#svgcontent, #svgcontent svg, svg");
    return root ? new XMLSerializer().serializeToString(root) : "";
  }

  function getActiveExportSvg() {
    if (window.DavaSimpleDocumentStore && typeof window.DavaSimpleDocumentStore.saveActiveDocumentSnapshot === "function") {
      window.DavaSimpleDocumentStore.saveActiveDocumentSnapshot();
    }
    if (window.DavaSimpleDocumentStore && typeof window.DavaSimpleDocumentStore.serializeActiveSvg === "function") {
      return window.DavaSimpleDocumentStore.serializeActiveSvg();
    }
    if (window.DavaSvgEditBridge && typeof window.DavaSvgEditBridge.getSvgString === "function") {
      return window.DavaSvgEditBridge.getSvgString();
    }
    return fallbackSerialize();
  }

  function requestExport(format, options) {
    options = options || {};
    var api = shiny();
    if (!api || typeof api.setInputValue !== "function") {
      if (window.DavaExportPanel) window.DavaExportPanel.setStatus("required Shiny BackendExportServices。", "error");
      return false;
    }
    var doc = activeDocument();
    var requestId = "export-" + Date.now() + "-" + Math.floor(Math.random() * 100000);
    var svgString = "";
    try {
      svgString = getActiveExportSvg();
    } catch (error) {
      if (window.DavaExportPanel) window.DavaExportPanel.setStatus("SVG Prefacecolumnfailed：" + error.message, "error");
      return false;
    }
    if (!/<svg\b/i.test(svgString || "")) {
      if (window.DavaExportPanel) window.DavaExportPanel.setStatus("The current canvas has no availableExportThe true whole of SVG。", "error");
      return false;
    }
    pending[requestId] = true;
    if (window.DavaExportPanel) window.DavaExportPanel.setLoading(true, "SubmittingExportTask...");
    api.setInputValue(nsPrefix() + "svg_editor_export_request", {
      requestId: requestId,
      documentId: doc && doc.id || "active",
      name: options.fileName || doc && doc.name || "untitled",
      format: format,
      svgString: svgString,
      options: options,
      timestamp: Date.now()
    }, { priority: "event" });
    return true;
  }

  function handleExportResult(message) {
    if (!message) return;
    if (message.requestId) delete pending[message.requestId];
    if (window.DavaExportPanel) {
      window.DavaExportPanel.setLoading(false);
      window.DavaExportPanel.showResult(message);
    }
  }

  window.DavaExportClient = {
    getActiveExportSvg: getActiveExportSvg,
    requestExport: requestExport,
    handleExportResult: handleExportResult
  };
})();
