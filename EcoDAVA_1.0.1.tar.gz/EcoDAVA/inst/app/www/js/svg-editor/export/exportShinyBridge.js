(function () {
  "use strict";

  window.DavaExportShinyBridge = {
    handleResult: function (payload) {
      if (window.DavaExportClient) window.DavaExportClient.handleExportResult(payload);
    }
  };
})();
