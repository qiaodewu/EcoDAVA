(function () {
  "use strict";

  function codePoint(char) {
    if (!char) return "";
    var text = String(char);
    if (Array.from(text).length !== 1) return "TEXT";
    var point = text.codePointAt(0);
    if (!Number.isFinite(point)) return "";
    return "U+" + point.toString(16).toUpperCase().padStart(4, "0");
  }

  function allCodes(text) {
    return Array.from(String(text || "")).map(codePoint).filter(Boolean).join(" ");
  }

  function fromCode(value) {
    var text = String(value || "").trim().toUpperCase().replace(/^U\+/, "");
    if (!/^[0-9A-F]{1,6}$/.test(text)) return "";
    var point = parseInt(text, 16);
    if (!Number.isFinite(point) || point < 0 || point > 0x10FFFF) return "";
    try {
      return String.fromCodePoint(point);
    } catch (error) {
      return "";
    }
  }

  function slug(text) {
    return String(text || "")
      .toLowerCase()
      .replace(/[^a-z0-9\u00a0-\uffff]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 72);
  }

  function symbolId(char, suffix) {
    var code = codePoint(char);
    var base = code === "TEXT" ? "text-" + slug(char) : code.replace("+", "").toLowerCase();
    return "symbol-" + base + (suffix ? "-" + slug(suffix) : "");
  }

  window.DavaSymbolUnicodeUtils = {
    codePoint: codePoint,
    allCodes: allCodes,
    fromCode: fromCode,
    symbolId: symbolId
  };
})();
