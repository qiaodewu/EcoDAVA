(function () {
  "use strict";

  var utils = window.DavaSymbolUnicodeUtils;
  var fontStacks = {
    symbol: "\"Segoe UI Symbol\", \"Apple Symbols\", \"Noto Sans Symbols\", \"Noto Sans Symbols 2\", \"Arial Unicode MS\", sans-serif",
    math: "\"Cambria Math\", \"STIX Two Math\", \"Noto Sans Math\", \"Latin Modern Math\", serif",
    text: "\"Aptos\", \"Calibri\", \"Arial\", \"Helvetica Neue\", sans-serif",
    cjk: "\"Microsoft YaHei\", \"PingFang SC\", \"Hiragino Sans GB\", \"Noto Sans CJK SC\", sans-serif"
  };

  function words(text) {
    return String(text || "").trim().split(/\s+/).filter(Boolean);
  }

  function codeOf(value) {
    var text = String(value || "");
    return Array.from(text).length > 1 ? utils.allCodes(text) : utils.codePoint(text);
  }

  function makeSymbol(category, value, options) {
    options = options || {};
    var label = options.label || value;
    var name = options.name || label;
    var preferredFontStack = options.preferredFontStack || options.font || fontStacks.symbol;
    return {
      id: options.id || utils.symbolId(value, category + "-" + String(name).replace(/\W+/g, "-").toLowerCase()),
      char: value,
      code: options.code || codeOf(value),
      name: name,
      label: label,
      category: category,
      keywords: (options.keywords || []).concat([category, name, label]).join(" "),
      preferredFontStack: preferredFontStack,
      font: preferredFontStack,
      aliases: options.aliases || [],
      isTemplate: !!options.isTemplate
    };
  }

  function addChars(list, category, chars, font, keywords) {
    words(chars).forEach(function (char) {
      list.push(makeSymbol(category, char, {
        name: category + " " + char,
        preferredFontStack: font,
        keywords: keywords || []
      }));
    });
  }

  function addTemplates(list, category, items, font, keywords) {
    items.forEach(function (item) {
      var value = item[0];
      var name = item[1] || value;
      var aliases = item[2] || [];
      list.push(makeSymbol(category, value, {
        name: name,
        label: name,
        preferredFontStack: font,
        keywords: (keywords || []).concat(aliases),
        aliases: aliases,
        isTemplate: true
      }));
    });
  }

  function build() {
    var symbols = [];

    addChars(symbols, "common", "± ∓ × ÷ · • ° ′ ″ ℃ ℉ ‰ ‱ ≤ ≥ ≠ ≈ ≃ ≅ ≡ ∼ ∝ ∞ μ µ Ω Ω Å Å ℓ № § ¶ † ‡", fontStacks.symbol, ["common", "frequent", "symbol"]);
    addChars(symbols, "greek", "Α Β Γ Δ Ε Ζ Η Θ Ι Κ Λ Μ Ν Ξ Ο Π Ρ Σ Τ Υ Φ Χ Ψ Ω α β γ δ ε ζ η θ ι κ λ μ ν ξ ο π ρ σ τ υ φ χ ψ ω ϐ ϑ ϒ ϕ ϖ ϰ ϱ ϵ", fontStacks.math, ["greek", "alpha", "beta", "gamma", "delta"]);
    addChars(symbols, "math", "∀ ∁ ∂ ∃ ∄ ∅ ∆ ∇ ∈ ∉ ∋ ∌ ∏ ∐ ∑ − ∓ ∔ ∕ ∖ ∗ ∘ ∙ √ ∛ ∜ ∝ ∞ ∟ ∠ ∡ ∢ ∣ ∤ ∥ ∦ ∧ ∨ ∩ ∪ ∫ ∬ ∭ ∮ ∴ ∵ ∶ ∷ ∸ ∹ ∺ ∻ ∼ ∽ ∾ ∿ ≁ ≂ ≃ ≄ ≅ ≆ ≇ ≈ ≉ ≊ ≋ ≌ ≍ ≎ ≏ ≐ ≑ ≒ ≓ ≔ ≕ ≖ ≗ ≘ ≙ ≚ ≛ ≜ ≝ ≞ ≟ ≠ ≡ ≢ ≤ ≥ ≦ ≧ ≪ ≫ ≬ ≭ ≮ ≯ ⊂ ⊃ ⊄ ⊅ ⊆ ⊇ ⊕ ⊖ ⊗ ⊘ ⊙ ⊚ ⊛ ⊜ ⊥ ⋅ ⋆ ⋈ ⋮ ⋯ ⋰ ⋱", fontStacks.math, ["math", "operator", "equation"]);
    addTemplates(symbols, "statistics", [
      ["p", "p"], ["P", "P"], ["n", "n"], ["N", "N"], ["df", "df"], ["SE", "SE"], ["SD", "SD"], ["CI", "CI"], ["CV", "CV"], ["F", "F"], ["t", "t"], ["r", "r"], ["R²", "R squared", ["R2", "rsquared"]], ["χ²", "chi-square", ["chi2", "chisq"]], ["η²", "eta squared"], ["β", "beta"], ["β₀", "beta 0"], ["β₁", "beta 1"], ["ε", "epsilon"], ["λ", "lambda"], ["AIC", "AIC"], ["BIC", "BIC"], ["RMSE", "RMSE"], ["MAE", "MAE"], ["ns", "not significant"], ["*", "significance *"], ["**", "significance **"], ["***", "significance ***"], ["p < 0.05", "p < 0.05", ["pvalue", "p value"]], ["p < 0.01", "p < 0.01"], ["p < 0.001", "p < 0.001"], ["mean ± SE", "mean ± SE"], ["mean ± SD", "mean ± SD"]
    ], fontStacks.text, ["statistics", "model", "anova", "regression", "pvalue"]);
    addChars(symbols, "super-sub", "⁰ ¹ ² ³ ⁴ ⁵ ⁶ ⁷ ⁸ ⁹ ⁺ ⁻ ⁼ ⁽ ⁾ ⁿ ⁱ ₀ ₁ ₂ ₃ ₄ ₅ ₆ ₇ ₈ ₉ ₊ ₋ ₌ ₍ ₎ ₐ ₑ ₕ ₖ ₗ ₘ ₙ ₒ ₚ ₛ ₜ ₓ", fontStacks.symbol, ["superscript", "subscript"]);
    addTemplates(symbols, "super-sub", [["m²", "m squared"], ["m³", "m cubed"], ["cm²", "cm squared"], ["cm³", "cm cubed"], ["CO₂", "CO2", ["carbon dioxide"]], ["CH₄", "CH4"], ["N₂O", "N2O"], ["NO₃⁻", "NO3", ["nitrate"]], ["NH₄⁺", "NH4", ["ammonium"]], ["PO₄³⁻", "PO4", ["phosphate"]], ["SO₄²⁻", "SO4", ["sulfate"]]], fontStacks.text, ["chemistry", "unit"]);
    addChars(symbols, "arrows", "← ↑ → ↓ ↔ ↕ ↖ ↗ ↘ ↙ ↚ ↛ ↜ ↝ ↞ ↟ ↠ ↡ ↢ ↣ ↤ ↥ ↦ ↧ ↨ ↩ ↪ ↫ ↬ ↭ ↮ ↯ ↰ ↱ ↲ ↳ ↴ ↵ ↶ ↷ ↸ ↹ ↺ ↻ ⇐ ⇑ ⇒ ⇓ ⇔ ⇕ ⇖ ⇗ ⇘ ⇙ ⇚ ⇛ ⇜ ⇝ ⇞ ⇟ ⇠ ⇡ ⇢ ⇣ ⇤ ⇥ ⇦ ⇧ ⇨ ⇩ ⇪ ⟵ ⟶ ⟷ ⟸ ⟹ ⟺ ⬀ ⬁ ⬂ ⬃ ⬄ ⬅ ⬆ ⬇ ⬈ ⬉ ⬊ ⬋ ⬌ ⬍ ➔ ➘ ➙ ➚ ➛ ➜ ➝ ➞ ➟ ➠ ➡", fontStacks.symbol, ["arrow", "direction", "flow"]);
    addChars(symbols, "geometry", "■ □ ▢ ▣ ▤ ▥ ▦ ▧ ▨ ▩ ▪ ▫ ▬ ▭ ▮ ▯ ▲ △ ▴ ▵ ▶ ▷ ▸ ▹ ▼ ▽ ▾ ▿ ◀ ◁ ◂ ◃ ◆ ◇ ◈ ◉ ○ ◌ ● ◐ ◑ ◒ ◓ ◔ ◕ ◖ ◗ ◘ ◙ ◚ ◛ ◜ ◝ ◞ ◟ ◠ ◡ ◢ ◣ ◤ ◥ ◦ ◧ ◨ ◩ ◪ ◫ ◬ ◭ ◮ ◯", fontStacks.symbol, ["geometry", "shape", "marker"]);
    addChars(symbols, "check-cross", "✓ ✔ ✕ ✖ ✗ ✘ ☑ ☒ ☐ ✅ ❎ ○ ● ◎ ◉ ★ ☆ ✦ ✧ ✩ ✪ ✫ ✬ ✭ ✮ ✯", fontStacks.symbol, ["check", "cross", "tick", "star"]);
    addChars(symbols, "dingbats", "✁ ✂ ✃ ✄ ☎ ☛ ☞ ✆ ✉ ✍ ✎ ✏ ✐ ✑ ✒ ✚ ✛ ✜ ✝ ✞ ✟ ✠ ✡ ✢ ✣ ✤ ✥ ✦ ✧ ✩ ✪ ✫ ✬ ✭ ✮ ✯ ✰ ✱ ✲ ✳ ✴ ✵ ✶ ✷ ✸ ✹ ✺ ✻ ✼ ✽ ✾ ✿ ❀ ❁ ❂ ❃ ❄ ❅ ❆ ❇ ❈ ❉ ❊ ❋ ❖ ❘ ❙ ❚ ❶ ❷ ❸ ❹ ❺ ❻ ❼ ❽ ❾ ❿ ➀ ➁ ➂ ➃ ➄ ➅ ➆ ➇ ➈ ➉", fontStacks.symbol, ["dingbat", "ornament", "number"]);
    addTemplates(symbols, "science-units", [
      ["℃", "degree Celsius"], ["℉", "degree Fahrenheit"], ["K", "Kelvin"], ["µ", "micro"], ["μ", "mu"], ["Å", "angstrom"], ["Å", "angstrom sign"], ["Ω", "ohm"], ["Ω", "ohm sign"], ["ℓ", "liter"], ["‰", "per mille"], ["‱", "per ten thousand"], ["°", "degree"], ["′", "prime"], ["″", "double prime"], ["±", "plus minus"], ["∓", "minus plus"], ["×", "multiply"], ["÷", "divide"], ["·", "middle dot"],
      ["mg·kg⁻¹", "mg kg-1"], ["g·kg⁻¹", "g kg-1"], ["μg·g⁻¹", "ug g-1"], ["ng·g⁻¹", "ng g-1"], ["mg·L⁻¹", "mg L-1"], ["μmol·L⁻¹", "umol L-1"], ["mmol·L⁻¹", "mmol L-1"], ["μmol·m⁻²·s⁻¹", "umol m-2 s-1"], ["nmol·g⁻¹·h⁻¹", "nmol g-1 h-1"], ["mg C·g⁻¹ soil", "mg C g-1 soil"], ["mg N·kg⁻¹ soil", "mg N kg-1 soil"], ["kg·hm⁻²", "kg hm-2"], ["mL·min⁻¹", "mL min-1"], ["mAU", "mAU"], ["AU", "AU"], ["OD₆₀₀", "OD600"], ["pH", "pH"], ["EC", "EC"], ["SOC", "SOC"], ["TN", "TN"], ["TP", "TP"], ["DOC", "DOC"], ["MBC", "MBC"], ["MBN", "MBN"], ["MAOC", "MAOC"], ["POC", "POC"]
    ], fontStacks.text, ["unit", "science", "soil", "ecology"]);
    addTemplates(symbols, "chem-bio", [
      ["H₂O", "H2O"], ["CO₂", "CO2"], ["CH₄", "CH4"], ["N₂O", "N2O"], ["O₂", "O2"], ["NO₃⁻", "NO3"], ["NH₄⁺", "NH4"], ["NO₂⁻", "NO2"], ["PO₄³⁻", "PO4"], ["SO₄²⁻", "SO4"], ["Ca²⁺", "Ca2+"], ["Mg²⁺", "Mg2+"], ["K⁺", "K+"], ["Na⁺", "Na+"], ["Fe³⁺", "Fe3+"], ["Al³⁺", "Al3+"], ["H⁺", "H+"], ["OH⁻", "OH-"], ["C:N", "C:N"], ["C:P", "C:P"], ["N:P", "N:P"], ["DNA", "DNA"], ["RNA", "RNA"], ["ATP", "ATP"], ["NADH", "NADH"], ["NADPH", "NADPH"], ["α-diversity", "alpha diversity"], ["β-diversity", "beta diversity"], ["γ-diversity", "gamma diversity"], ["16S", "16S"], ["ITS", "ITS"], ["ASV", "ASV"], ["OTU", "OTU"], ["PCoA", "PCoA"], ["PCA", "PCA"], ["NMDS", "NMDS"], ["PERMANOVA", "PERMANOVA"], ["LEfSe", "LEfSe"], ["FAPROTAX", "FAPROTAX"], ["PICRUSt", "PICRUSt"], ["FUNGuild", "FUNGuild"]
    ], fontStacks.text, ["chemistry", "biology", "microbiology", "ecology"]);
    addChars(symbols, "punctuation", "— – ‐ - ‒ ‘ ’ “ ” „ « » ‹ › … · • ‣ ※ § ¶ † ‡ ′ ″ ‴ ⁂ ⁎ ⁑ 〈 〉 《 》 「 」 『 』 【 】 〔 〕 〖 〗 （ ） ［ ］ ｛ ｝", fontStacks.cjk, ["punctuation", "bracket", "quote"]);
    addChars(symbols, "currency-number", "$ ¢ £ ¤ ¥ € ₩ ₽ ₹ ₺ ₫ ₱ ₦ ₪ ₡ ₵ ① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ ⑴ ⑵ ⑶ ⑷ ⑸ ⑹ ⑺ ⑻ ⑼ ⑽ Ⓐ Ⓑ Ⓒ Ⓓ Ⓔ Ⓕ Ⓖ Ⓗ Ⓘ Ⓙ ⓐ ⓑ ⓒ ⓓ ⓔ ⓕ ⓖ ⓗ ⓘ ⓙ", fontStacks.symbol, ["currency", "number", "label"]);
    addChars(symbols, "box-block", "─ ━ │ ┃ ┄ ┅ ┆ ┇ ┈ ┉ ┊ ┋ ┌ ┐ └ ┘ ├ ┤ ┬ ┴ ┼ ═ ║ ╔ ╗ ╚ ╝ ╠ ╣ ╦ ╩ ╬ ▀ ▁ ▂ ▃ ▄ ▅ ▆ ▇ █ ▉ ▊ ▋ ▌ ▍ ▎ ▏ ░ ▒ ▓", fontStacks.symbol, ["box", "block", "line"]);
    addTemplates(symbols, "emoji", [["🌱", "seedling"], ["🌿", "herb"], ["🍃", "leaf"], ["🍂", "fallen leaf"], ["🌾", "rice"], ["🔬", "microscope"], ["🧪", "test tube"], ["🧫", "petri dish"], ["🧬", "DNA"], ["📈", "chart up"], ["📉", "chart down"], ["📊", "bar chart"], ["⚠️", "warning"], ["✅", "check"], ["❌", "cross"]], fontStacks.symbol, ["emoji", "icon", "pictograph"]);
    return symbols;
  }

  window.DavaSymbolRegistry = {
    fontStacks: fontStacks,
    symbols: build(),
    byCategory: function (category) {
      return this.symbols.filter(function (symbol) { return symbol.category === category; });
    },
    byId: function (id) {
      return this.symbols.filter(function (symbol) { return symbol.id === id; })[0] || null;
    }
  };
})();
