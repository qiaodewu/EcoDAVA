(function () {
  "use strict";

  var api = null;
  var panel = null;
  var selected = null;
  var activeCategory = "common";

  function categories() {
    return window.DavaSymbolCategories || [];
  }

  function categoryById(id) {
    return categories().filter(function (category) { return category.id === id; })[0] || null;
  }

  function fontStacks() {
    return window.DavaSymbolRegistry && window.DavaSymbolRegistry.fontStacks || {};
  }

  function symbolsForCategory(category) {
    if (category === "recent") return window.DavaSymbolRecentStore.read();
    return (window.DavaSymbolRegistry.symbols || []).filter(function (symbol) {
      return symbol.category === category;
    });
  }

  function ensurePanel() {
    var existing = document.getElementById("dava_symbol_panel");
    if (existing) {
      panel = existing;
      return panel;
    }
    injectCss();
    panel = document.createElement("section");
    panel.id = "dava_symbol_panel";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "Insert scientific symbol");
    panel.innerHTML = [
      "<div class='dava-symbol-title'><div><strong>Insert Symbol</strong><span>Scientific Symbols</span></div><button class='dava-symbol-close' type='button' aria-label='Close'>\u00d7</button></div>",
      "<div class='dava-symbol-codebar'><label for='dava_symbol_code'>Unicode</label><input id='dava_symbol_code' type='text' placeholder='U+03BC'><button id='dava_symbol_code_add' type='button'>Use code</button></div>",
      "<div class='dava-symbol-body'><nav id='dava_symbol_categories' class='dava-symbol-categories'></nav><main id='dava_symbol_results' class='dava-symbol-results'></main></div>",
      "<div class='dava-symbol-footer'><div id='dava_symbol_preview' class='dava-symbol-preview'>\u03a9</div><div id='dava_symbol_meta' class='dava-symbol-meta'></div><button id='dava_symbol_insert' class='dava-symbol-action primary' type='button'>Insert</button></div>"
    ].join("");
    document.body.appendChild(panel);
    wirePanel();
    return panel;
  }

  function injectCss() {
    if (document.getElementById("dava_symbol_panel_css")) return;
    var style = document.createElement("style");
    style.id = "dava_symbol_panel_css";
    style.textContent = [
      "#dava_symbol_panel{position:fixed;right:24px;top:72px;z-index:1000006;width:720px;max-width:calc(100vw - 44px);height:560px;max-height:calc(100vh - 92px);display:none;grid-template-rows:42px 42px 1fr 88px;background:#f6f7f8;border:1px solid #858b91;box-shadow:0 16px 38px rgba(0,0,0,.32);font:12px 'Segoe UI',Arial,'Microsoft YaHei',sans-serif;color:#111}",
      "#dava_symbol_panel.open{display:grid}",
      ".dava-symbol-title{display:flex;align-items:center;gap:8px;padding:6px 10px;background:#dfe3e6;border-bottom:1px solid #bdc4ca}",
      ".dava-symbol-title div{display:flex;flex-direction:column;gap:1px;margin-right:auto}",
      ".dava-symbol-title strong{font-size:14px;line-height:16px}",
      ".dava-symbol-title span{font-size:11px;color:#53606a}",
      ".dava-symbol-close{width:26px;height:26px;border:0;background:transparent;font-size:20px;line-height:22px;cursor:pointer}",
      ".dava-symbol-codebar{display:grid;grid-template-columns:54px 1fr 76px;gap:8px;align-items:center;padding:7px 10px;border-bottom:1px solid #d0d5d9;background:#eef1f3}",
      ".dava-symbol-codebar label{color:#3b454d}",
      ".dava-symbol-codebar input{height:27px;box-sizing:border-box;border:1px solid #aeb4b8;background:#fff;padding:2px 8px;font:12px 'Segoe UI',Arial,sans-serif}",
      ".dava-symbol-codebar button{height:27px;border:1px solid #9ba9b5;background:#f8fafc;cursor:pointer}",
      ".dava-symbol-body{display:grid;grid-template-columns:190px 1fr;min-height:0}",
      ".dava-symbol-categories{overflow:auto;border-right:1px solid #c8cdd1;background:#eceff1;padding:7px}",
      ".dava-symbol-cat{display:flex;width:100%;align-items:center;justify-content:space-between;text-align:left;margin:0 0 3px 0;padding:7px 8px;border:1px solid transparent;background:transparent;cursor:pointer;color:#16222c}",
      ".dava-symbol-cat:hover{background:#f8fbff;border-color:#b7c7d8}",
      ".dava-symbol-cat.active{background:#d9e8f6;border-color:#8db3d8;font-weight:600}",
      ".dava-symbol-cat small{font-size:11px;color:#667;font-weight:400}",
      ".dava-symbol-results{overflow:auto;padding:10px;background:#fff}",
      ".dava-symbol-section-title{font-size:13px;font-weight:700;color:#2b2b2b;margin:0 0 8px 0;padding-bottom:4px;border-bottom:1px solid #e2e4e6}",
      ".dava-symbol-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(46px,1fr));gap:5px;align-items:start}",
      ".dava-symbol-cell{height:42px;min-width:42px;border:1px solid #d2d6d9;background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:2px 4px;font-size:22px;line-height:1.1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
      ".dava-symbol-cell.template{font-size:13px;min-width:86px;grid-column:span 2}",
      ".dava-symbol-cell:hover,.dava-symbol-cell.selected{border-color:#2678c5;background:#e7f1ff}",
      ".dava-symbol-empty{color:#6c737a;padding:16px}",
      ".dava-symbol-footer{display:grid;grid-template-columns:74px 1fr 84px;gap:8px;align-items:center;padding:8px;border-top:1px solid #d1d5d8;background:#f9fafb}",
      ".dava-symbol-preview{height:58px;border:1px solid #cfd4d8;background:#fff;display:flex;align-items:center;justify-content:center;font-size:40px;overflow:hidden}",
      ".dava-symbol-meta{line-height:1.45;min-width:0;color:#26323b}",
      ".dava-symbol-meta b{font-weight:600}",
      ".dava-symbol-action{height:31px;border:1px solid #8fa1b3;background:#eef4fb;cursor:pointer}",
      ".dava-symbol-action.primary{background:#2f75b5;border-color:#1e5d94;color:#fff;font-weight:600}"
    ].join("\n");
    document.head.appendChild(style);
  }

  function renderCategories() {
    var box = panel.querySelector("#dava_symbol_categories");
    box.textContent = "";
    categories().forEach(function (category) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "dava-symbol-cat" + (category.id === activeCategory ? " active" : "");
      btn.dataset.category = category.id;
      var label = document.createElement("span");
      label.textContent = category.zh + " / " + category.label;
      btn.appendChild(label);
      if (category.collapsed) {
        var tag = document.createElement("small");
        tag.textContent = "optional";
        btn.appendChild(tag);
      }
      btn.addEventListener("click", function () {
        activeCategory = category.id;
        clearCodeInput();
        renderCategories();
        renderResults();
      });
      box.appendChild(btn);
    });
  }

  function clearCodeInput() {
    var input = panel.querySelector("#dava_symbol_code");
    if (input) input.value = "";
  }

  function makeUnicodeSymbol(char) {
    var stack = fontStacks().symbol || "Segoe UI Symbol, Arial Unicode MS, sans-serif";
    return {
      id: window.DavaSymbolUnicodeUtils.symbolId(char, "manual"),
      char: char,
      code: window.DavaSymbolUnicodeUtils.codePoint(char),
      name: "Unicode " + window.DavaSymbolUnicodeUtils.codePoint(char),
      label: char,
      category: "unicode",
      keywords: "unicode manual code",
      preferredFontStack: stack,
      font: stack,
      aliases: [],
      isTemplate: false
    };
  }

  function activeItems() {
    var codeChar = window.DavaSymbolUnicodeUtils.fromCode(panel.querySelector("#dava_symbol_code").value);
    if (codeChar) return [makeUnicodeSymbol(codeChar)];
    return symbolsForCategory(activeCategory);
  }

  function renderResults() {
    var results = panel.querySelector("#dava_symbol_results");
    var items = activeItems();
    results.textContent = "";
    if (!items.length) {
      var empty = document.createElement("div");
      empty.className = "dava-symbol-empty";
      empty.textContent = activeCategory === "recent" ? "No recent symbols." : "No symbols in this category.";
      results.appendChild(empty);
      selectSymbol(null);
      return;
    }
    var title = document.createElement("div");
    title.className = "dava-symbol-section-title";
    var cat = categoryById(activeCategory);
    title.textContent = cat ? cat.zh + " / " + cat.label : "Unicode";
    var grid = document.createElement("div");
    grid.className = "dava-symbol-grid";
    items.forEach(function (symbol) {
      grid.appendChild(renderCell(symbol));
    });
    results.appendChild(title);
    results.appendChild(grid);
    selectSymbol(items[0]);
  }

  function renderCell(symbol) {
    var button = document.createElement("button");
    button.type = "button";
    button.className = "dava-symbol-cell" + (symbol.isTemplate ? " template" : "");
    button.textContent = symbol.char;
    button.title = [symbol.name, symbol.code, symbol.category].filter(Boolean).join(" | ");
    button.style.fontFamily = symbol.preferredFontStack || symbol.font || fontStacks().symbol;
    button.addEventListener("click", function () { selectSymbol(symbol, button); });
    button.addEventListener("dblclick", insertSelected);
    return button;
  }

  function selectSymbol(symbol, cell) {
    selected = symbol || null;
    Array.prototype.forEach.call(panel.querySelectorAll(".dava-symbol-cell.selected"), function (node) {
      node.classList.remove("selected");
    });
    if (cell) cell.classList.add("selected");
    var preview = panel.querySelector("#dava_symbol_preview");
    var meta = panel.querySelector("#dava_symbol_meta");
    if (!symbol) {
      preview.textContent = "";
      meta.textContent = "";
      return;
    }
    preview.textContent = symbol.char;
    preview.style.fontFamily = symbol.preferredFontStack || symbol.font || fontStacks().symbol;
    meta.textContent = "";
    [
      symbol.name || symbol.label || symbol.char,
      [symbol.code, symbol.category, symbol.isTemplate ? "template" : "unicode text"].filter(Boolean).join(" | "),
      "Font: " + (symbol.preferredFontStack || symbol.font || "recommended")
    ].forEach(function (line, index) {
      if (index) meta.appendChild(document.createElement("br"));
      meta.appendChild(document.createTextNode(line));
    });
  }

  function applyCodeInput() {
    renderResults();
    var input = panel.querySelector("#dava_symbol_code");
    if (input) input.focus();
  }

  function insertSelected() {
    if (!selected || !api) return;
    window.DavaSymbolRecentStore.add(selected);
    window.DavaSymbolInsertCommand.insert(api, selected, {
      fontFamily: selected.preferredFontStack || selected.font
    });
    renderCategories();
  }

  function wirePanel() {
    panel.querySelector(".dava-symbol-close").addEventListener("click", close);
    panel.querySelector("#dava_symbol_insert").addEventListener("click", insertSelected);
    panel.querySelector("#dava_symbol_code_add").addEventListener("click", applyCodeInput);
    panel.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        event.preventDefault();
        close();
      } else if (event.key === "Enter" && event.target && event.target.id === "dava_symbol_code") {
        event.preventDefault();
        applyCodeInput();
      } else if (event.key === "Enter") {
        event.preventDefault();
        insertSelected();
      }
      event.stopPropagation();
    }, true);
  }

  function open() {
    ensurePanel();
    renderCategories();
    renderResults();
    panel.classList.add("open");
    document.body.classList.add("dava-symbol-panel-open");
  }

  function close() {
    ensurePanel();
    panel.classList.remove("open");
    document.body.classList.remove("dava-symbol-panel-open");
  }

  window.DavaSymbolPanel = {
    init: function (environment) { api = environment; ensurePanel(); },
    open: open,
    close: close
  };
})();
