(function () {
  "use strict";
  var key = "dava.svgEdit.symbol.recent";
  var maxItems = 30;

  function pack(symbol) {
    return {
      id: symbol.id,
      char: symbol.char,
      code: symbol.code,
      name: symbol.name,
      label: symbol.label,
      category: symbol.category,
      keywords: symbol.keywords,
      preferredFontStack: symbol.preferredFontStack,
      font: symbol.font || symbol.preferredFontStack,
      aliases: symbol.aliases || [],
      isTemplate: !!symbol.isTemplate
    };
  }

  function read() {
    try { return JSON.parse(localStorage.getItem(key) || "[]"); } catch (error) { return []; }
  }

  function add(symbol) {
    var item = pack(symbol);
    var items = read().filter(function (existing) { return existing.id !== item.id; });
    items.unshift(item);
    localStorage.setItem(key, JSON.stringify(items.slice(0, maxItems)));
  }

  window.DavaSymbolRecentStore = { read: read, add: add, pack: pack };
})();
