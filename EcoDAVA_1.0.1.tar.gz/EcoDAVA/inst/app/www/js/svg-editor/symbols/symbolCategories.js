(function () {
  "use strict";

  window.DavaSymbolCategories = [
    { id: "recent", label: "Recent", zh: "\u6700\u8fd1\u4f7f\u7528" },
    { id: "common", label: "Common", zh: "\u5e38\u7528\u7b26\u53f7" },
    { id: "greek", label: "Greek", zh: "\u5e0c\u814a\u5b57\u6bcd" },
    { id: "math", label: "Math", zh: "\u6570\u5b66\u8fd0\u7b97\u7b26" },
    { id: "statistics", label: "Statistics", zh: "\u7edf\u8ba1\u5b66\u4e0e\u6a21\u578b" },
    { id: "super-sub", label: "Super/Sub", zh: "\u4e0a\u6807\u548c\u4e0b\u6807" },
    { id: "arrows", label: "Arrows", zh: "\u7bad\u5934" },
    { id: "geometry", label: "Geometry", zh: "\u51e0\u4f55\u56fe\u5f62" },
    { id: "check-cross", label: "Check/Cross", zh: "\u52fe\u9009\u4e0e\u53c9\u53f7" },
    { id: "dingbats", label: "Dingbats", zh: "\u88c5\u9970\u7b26\u53f7" },
    { id: "science-units", label: "Science Units", zh: "\u5355\u4f4d\u4e0e\u79d1\u5b66\u7b26\u53f7" },
    { id: "chem-bio", label: "Chem/Bio", zh: "\u5316\u5b66\u4e0e\u751f\u7269\u5b66" },
    { id: "punctuation", label: "Punctuation", zh: "\u6807\u70b9\u4e0e\u62ec\u53f7" },
    { id: "currency-number", label: "Currency/Number", zh: "\u8d27\u5e01\u4e0e\u7f16\u53f7" },
    { id: "box-block", label: "Box/Block", zh: "\u6846\u7ebf\u4e0e\u5757\u5143\u7d20" },
    { id: "emoji", label: "Emoji / Icons", zh: "Emoji / \u56fe\u6807", collapsed: true }
  ];
})();
