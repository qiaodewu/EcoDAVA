(function () {
  "use strict";

  function notify(env, symbol, insertedAs, target) {
    var payload = {
      symbolId: symbol.id,
      char: symbol.char,
      code: symbol.code,
      name: symbol.name,
      label: symbol.label || symbol.name,
      category: symbol.category,
      insertedAs: insertedAs,
      targetId: target && target.id || null,
      timestamp: Date.now()
    };
    try {
      if (window.parent && window.parent.Shiny && window.parent.Shiny.setInputValue) {
        window.parent.Shiny.setInputValue("svg_editor_symbol_inserted", payload, { priority: "event" });
      }
    } catch (error) {}
    if (env && typeof env.post === "function") env.post("DAVA_SYMBOL_INSERTED", payload);
  }

  function activeTextInput() {
    var element = document.activeElement;
    if (!element) return null;
    if (element.closest && element.closest("#dava_symbol_panel")) return null;
    var tag = String(element.tagName || "").toLowerCase();
    return tag === "textarea" || tag === "input" || element.isContentEditable ? element : null;
  }

  function insertIntoInput(input, symbol) {
    if (input.isContentEditable) {
      var selection = window.getSelection ? window.getSelection() : null;
      if (selection && selection.rangeCount) {
        var range = selection.getRangeAt(0);
        range.deleteContents();
        range.insertNode(document.createTextNode(symbol.char));
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
        input.dispatchEvent(new Event("input", { bubbles: true }));
        if (typeof input.focus === "function") input.focus();
        return;
      }
      input.textContent += symbol.char;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      if (typeof input.focus === "function") input.focus();
      return;
    }
    var start = input.selectionStart || 0;
    var end = input.selectionEnd || start;
    input.value = input.value.slice(0, start) + symbol.char + input.value.slice(end);
    input.selectionStart = input.selectionEnd = start + symbol.char.length;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    if (typeof input.focus === "function") input.focus();
  }

  function viewportCenter(canvas) {
    var resolution = canvas && typeof canvas.getResolution === "function" ? canvas.getResolution() : { w: 640, h: 480 };
    return { x: Math.round((resolution.w || 640) / 2), y: Math.round((resolution.h || 480) / 2) };
  }

  function svgContent(canvas) {
    if (canvas && typeof canvas.getSvgContent === "function") return canvas.getSvgContent();
    return document.getElementById("svgcontent") || document.querySelector("svg");
  }

  function directLogicalUserGroup(parent) {
    if (!parent || !parent.children) return null;
    for (var index = 0; index < parent.children.length; index += 1) {
      var child = parent.children[index];
      if (child && child.getAttribute && child.getAttribute("data-dava-logical-user-layer") === "1") return child;
    }
    return null;
  }

  function isProtectedUiLayer(layer) {
    if (!layer || !layer.getAttribute) return true;
    var id = layer.getAttribute("id") || "";
    var role = layer.getAttribute("data-dava-layer-role") || "";
    return id === "selectorParentGroup" ||
      id === "selection-ui-layer" ||
      id === "guides-layer" ||
      role === "selection-ui" ||
      role === "guides";
  }

  function ensureLogicalUserGroup(canvas) {
    var drawing = canvas && canvas.getCurrentDrawing && canvas.getCurrentDrawing();
    var parent = null;
    try {
      parent = drawing && typeof drawing.getCurrentLayer === "function" ? drawing.getCurrentLayer() : null;
    } catch (error) {}
    if (!parent || isProtectedUiLayer(parent)) parent = svgContent(canvas);
    var group = directLogicalUserGroup(parent);
    if (!group) {
      var doc = parent.ownerDocument || document;
      group = doc.createElementNS("http://www.w3.org/2000/svg", "g");
      group.setAttribute("data-dava-logical-user-layer", "1");
      group.setAttribute("data-dava-layer-role", "user-overlay");
      group.setAttribute("data-dava-source", "user");
      group.setAttribute("data-dava-container-only", "1");
      group.setAttribute("data-dava-selectable", "0");
      group.setAttribute("data-dava-editable", "0");
      parent.appendChild(group);
    } else if (group.parentNode === parent && group.nextSibling) {
      parent.appendChild(group);
    }
    group.removeAttribute("pointer-events");
    group.style.pointerEvents = "";
    return group;
  }

  function activateSelectMode(canvas) {
    try {
      if (window.svgEditor && window.svgEditor.leftPanel && typeof window.svgEditor.leftPanel.clickSelect === "function") {
        window.svgEditor.leftPanel.clickSelect();
      } else if (canvas && typeof canvas.setMode === "function") {
        canvas.setMode("select");
      }
    } catch (error) {}
  }

  function insertNewText(env, symbol, fontFamily) {
    var canvas = env.getSvgCanvas();
    var doc = canvas.getDOMDocument ? canvas.getDOMDocument() : document;
    var text = doc.createElementNS("http://www.w3.org/2000/svg", "text");
    var pos = env.lastCanvasPoint && env.lastCanvasPoint() || viewportCenter(canvas);
    text.textContent = symbol.char;
    text.setAttribute("id", canvas.getNextId ? canvas.getNextId() : ("symbol_" + Date.now()));
    text.setAttribute("x", pos.x);
    text.setAttribute("y", pos.y);
    text.setAttribute("data-type", "symbol");
    text.setAttribute("data-symbol-id", symbol.id);
    text.setAttribute("data-symbol-category", symbol.category || "");
    text.setAttribute("data-symbol-code", symbol.code);
    text.setAttribute("data-symbol-name", symbol.name);
    text.setAttribute("data-dava-source", "user");
    text.setAttribute("font-family", fontFamily || symbol.preferredFontStack || symbol.font);
    text.setAttribute("font-size", "32");
    text.setAttribute("fill", "#000000");
    text.setAttribute("pointer-events", "visiblePainted");
    ensureLogicalUserGroup(canvas).appendChild(text);
    if (canvas.history && canvas.history.InsertElementCommand) {
      canvas.addCommandToHistory(new canvas.history.InsertElementCommand(text));
    }
    activateSelectMode(canvas);
    if (canvas.selectOnly) canvas.selectOnly([text], true);
    else if (canvas.addToSelection) canvas.addToSelection([text], true);
    if (typeof canvas.recalculateAllSelectedDimensions === "function") canvas.recalculateAllSelectedDimensions();
    if (canvas.call) {
      canvas.call("changed", [text]);
      canvas.call("selected", [text]);
    }
    notify(env, symbol, "new-text", text);
    return text;
  }

  function insert(env, symbol, options) {
    options = options || {};
    var input = env && typeof env.activeTextInput === "function" ? env.activeTextInput() : null;
    if (!input) input = activeTextInput();
    if (input) {
      insertIntoInput(input, symbol);
      notify(env, symbol, "active-text-editor", null);
      return true;
    }
    return insertNewText(env, symbol, options.fontFamily);
  }

  window.DavaSymbolInsertCommand = { insert: insert };
})();
