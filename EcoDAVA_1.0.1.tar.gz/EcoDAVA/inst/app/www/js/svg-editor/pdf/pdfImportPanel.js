(function () {
  "use strict";

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      if (key === "className") node.className = attrs[key];
      else node.setAttribute(key, attrs[key]);
    });
    (children || []).forEach(function (child) {
      node.appendChild(typeof child === "string" ? document.createTextNode(child) : child);
    });
    return node;
  }

  var panel = null;
  var uploadInfo = null;
  var dragState = null;

  function row(label, field) {
    return el("label", { className: "dava-pdf-row" }, [el("span", {}, [label]), field]);
  }

  function build() {
    if (panel) return panel;
    panel = el("div", { id: "dava_pdf_import_panel", className: "dava-pdf-panel", hidden: "hidden" }, [
      el("div", { className: "dava-pdf-head" }, [
        el("strong", {}, ["PDF Import"]),
        el("button", { type: "button", "data-action": "close", title: "Close" }, ["×"])
      ]),
      el("div", { className: "dava-pdf-body" }, [
        el("button", { type: "button", className: "dava-pdf-upload", "data-action": "upload" }, ["Upload PDF"]),
        el("div", { className: "dava-pdf-status", "data-role": "status" }, ["No PDF uploaded."]),
        row("Page", el("input", { type: "text", value: "1", "data-role": "pageSpec", placeholder: "1-3,5 or all" })),
        row("Target", el("select", { "data-role": "target" }, [
          el("option", { value: "current" }, ["Current artboard"]),
          el("option", { value: "new" }, ["New artboard"]),
          el("option", { value: "pages" }, ["Each page new artboard"])
        ])),
        row("Text", el("select", { "data-role": "textMode" }, [
          el("option", { value: "preserve-text", selected: "selected" }, ["Preserve editable text"]),
          el("option", { value: "outline-text" }, ["Outline text (visual fallback)"])
        ])),
        row("Clean", el("select", { "data-role": "cleanLevel" }, [
          el("option", { value: "safe" }, ["Safe"]),
          el("option", { value: "standard", selected: "selected" }, ["Standard"]),
          el("option", { value: "aggressive" }, ["Aggressive"])
        ])),
        row("Raster images", el("select", { "data-role": "keepImages" }, [
          el("option", { value: "true" }, ["Keep and warn"]),
          el("option", { value: "false" }, ["Reject pages with images"])
        ])),
        el("div", { className: "dava-pdf-actions" }, [
          el("button", { type: "button", className: "primary", "data-action": "convert" }, ["Convert and Import"]),
          el("button", { type: "button", "data-action": "close" }, ["Cancel"])
        ])
      ])
    ]);
    document.body.appendChild(panel);
    bindDrag();
    panel.addEventListener("click", function (event) {
      var action = event.target && event.target.getAttribute("data-action");
      if (!action) return;
      if (action === "close") close();
      if (action === "upload" && window.DavaPdfImportShinyBridge) window.DavaPdfImportShinyBridge.requestUpload();
      if (action === "convert") requestConvert();
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && panel && !panel.hidden) close();
    });
    return panel;
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function placeDefault() {
    build();
    if (panel.getAttribute("data-user-positioned") === "1") return;
    panel.hidden = false;
    var rect = panel.getBoundingClientRect();
    var workarea = document.getElementById("workarea");
    var bounds = workarea ? workarea.getBoundingClientRect() : {
      left: 0,
      top: 0,
      width: window.innerWidth,
      height: window.innerHeight
    };
    var left = bounds.left + Math.max(24, (bounds.width - rect.width) / 2);
    var top = bounds.top + Math.max(26, Math.min(bounds.height * 0.16, 120));
    panel.style.left = clamp(left, 8, window.innerWidth - rect.width - 8) + "px";
    panel.style.top = clamp(top, 8, window.innerHeight - rect.height - 8) + "px";
    panel.style.right = "auto";
  }

  function bindDrag() {
    var head = panel && panel.querySelector(".dava-pdf-head");
    if (!head || head.getAttribute("data-dava-drag-bound") === "1") return;
    head.setAttribute("data-dava-drag-bound", "1");
    head.addEventListener("mousedown", function (event) {
      if (event.target && event.target.closest && event.target.closest("button")) return;
      var rect = panel.getBoundingClientRect();
      dragState = {
        offsetX: event.clientX - rect.left,
        offsetY: event.clientY - rect.top,
        width: rect.width,
        height: rect.height
      };
      panel.setAttribute("data-dragging", "1");
      event.preventDefault();
    });
    document.addEventListener("mousemove", function (event) {
      if (!dragState || !panel || panel.hidden) return;
      var left = clamp(event.clientX - dragState.offsetX, 8, window.innerWidth - dragState.width - 8);
      var top = clamp(event.clientY - dragState.offsetY, 8, window.innerHeight - dragState.height - 8);
      panel.style.left = left + "px";
      panel.style.top = top + "px";
      panel.style.right = "auto";
      panel.setAttribute("data-user-positioned", "1");
      event.preventDefault();
    });
    document.addEventListener("mouseup", function () {
      if (!dragState || !panel) return;
      dragState = null;
      panel.removeAttribute("data-dragging");
    });
  }

  function value(role) {
    var input = panel && panel.querySelector("[data-role='" + role + "']");
    return input ? input.value : "";
  }

  function requestConvert() {
    if (!window.DavaPdfImportClient) return;
    window.DavaPdfImportClient.requestConvert({
      pageSpec: value("pageSpec"),
      target: value("target"),
      textMode: value("textMode"),
      cleanLevel: value("cleanLevel"),
      keepImages: value("keepImages") !== "false",
      engine: "auto"
    });
    setStatus("Converting PDF page(s)...", "busy");
  }

  function setStatus(text, kind) {
    build();
    var status = panel.querySelector("[data-role='status']");
    status.textContent = text || "";
    status.setAttribute("data-kind", kind || "");
  }

  function setUploadState(payload) {
    uploadInfo = payload;
    var pages = payload && payload.pageCount ? payload.pageCount : "unknown";
    var tool = payload && payload.availableTools && payload.availableTools.primary || "none";
    setStatus("Uploaded: " + (payload.fileName || "PDF") + " | pages: " + pages + " | engine: " + tool, payload && payload.availableTools && payload.availableTools.available ? "ready" : "warning");
  }

  function open() {
    build().hidden = false;
    placeDefault();
    document.body.classList.add("dava-pdf-import-open");
    setStatus(uploadInfo ? "Uploaded: " + uploadInfo.fileName : "Upload a PDF to begin.", uploadInfo ? "ready" : "");
  }

  function close() {
    if (panel) panel.hidden = true;
    document.body.classList.remove("dava-pdf-import-open");
  }

  window.DavaPdfImportPanel = {
    open: open,
    close: close,
    setStatus: setStatus,
    setUploadState: setUploadState
  };
})();
