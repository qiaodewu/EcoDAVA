(function () {
  "use strict";

  var svgNS = "http://www.w3.org/2000/svg";

  function removeUnsafe(root) {
    Array.prototype.forEach.call(root.querySelectorAll("script, foreignObject"), function (node) {
      if (node.parentNode) node.parentNode.removeChild(node);
    });
    Array.prototype.forEach.call(root.querySelectorAll("*"), function (node) {
      Array.prototype.slice.call(node.attributes || []).forEach(function (attr) {
        var name = attr.name || "";
        var value = attr.value || "";
        if (/^on/i.test(name) || /^\s*javascript:/i.test(value)) node.removeAttribute(name);
        if (/^(href|xlink:href)$/i.test(name) && /^(https?:)?\/\//i.test(value)) node.removeAttribute(name);
      });
    });
    return root;
  }

  function parseCleanSvg(svgText) {
    var parsed = new DOMParser().parseFromString(String(svgText || ""), "image/svg+xml");
    var error = parsed.querySelector("parsererror");
    if (error) throw new Error("Converted PDF SVG could not be parsed.");
    var svg = parsed.documentElement;
    if (!svg || !/^svg$/i.test(svg.nodeName)) throw new Error("Converted PDF payload is not an SVG document.");
    return removeUnsafe(svg);
  }

  function importedGroupFromSvg(svgText, doc) {
    var svg = parseCleanSvg(svgText);
    var group = svg.querySelector("g[data-type='imported-pdf']");
    var imported = group ? doc.importNode(group, true) : doc.createElementNS(svgNS, "g");
    if (!group) {
      imported.setAttribute("data-type", "imported-pdf");
      while (svg.firstChild) imported.appendChild(doc.importNode(svg.firstChild, true));
    }
    removeUnsafe(imported);
    imported.setAttribute("data-type", "imported-pdf");
    imported.setAttribute("data-dava-source", "pdf-import");
    imported.setAttribute("pointer-events", "visiblePainted");
    return imported;
  }

  function extractDefs(svgText, doc) {
    var svg = typeof svgText === "string" ? parseCleanSvg(svgText) : svgText;
    return Array.prototype.map.call(svg.querySelectorAll("defs"), function (defs) {
      return doc.importNode(defs, true);
    });
  }

  window.DavaPdfSvgSanitizer = {
    parseCleanSvg: parseCleanSvg,
    importedGroupFromSvg: importedGroupFromSvg,
    extractDefs: extractDefs,
    removeUnsafe: removeUnsafe
  };
})();
