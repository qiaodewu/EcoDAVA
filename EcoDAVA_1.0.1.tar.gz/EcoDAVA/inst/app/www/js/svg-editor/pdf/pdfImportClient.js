(function () {
  "use strict";

  var state = {
    uploaded: null,
    lastError: ""
  };

  function handleUploadResult(payload) {
    state.uploaded = payload || null;
    if (window.DavaPdfImportPanel) window.DavaPdfImportPanel.setUploadState(payload);
    if (window.DavaPdfImportShinyBridge) {
      window.DavaPdfImportShinyBridge.notify("svg_editor_pdf_uploaded", payload || {});
    }
  }

  function importResult(result, target) {
    if (!result || !result.ok) {
      if (window.DavaPdfImportPanel) window.DavaPdfImportPanel.setStatus(result && result.error || "PDF conversion failed.", "error");
      if (window.DavaPdfImportShinyBridge) window.DavaPdfImportShinyBridge.notify("svg_editor_pdf_import_failed", result || {});
      state.lastError = result && result.error || "PDF conversion failed.";
      return;
    }
    if (result.warnings && result.warnings.length && window.DavaPdfImportShinyBridge) {
      window.DavaPdfImportShinyBridge.notify("svg_editor_pdf_import_warning", result);
    }
    if (target === "new" || target === "pages") {
      if (window.DavaPdfImportPanel) {
        window.DavaPdfImportPanel.setStatus("New artboard import is disabled in this build. Imported into the current canvas instead.", "warning");
      }
    }
    try {
      window.DavaPdfSvgImporter.importCleanSvgIntoActiveArtboard(result.cleanSvg, {
      fileId: result.fileId,
      fileName: result.fileName,
      page: result.page,
      engine: result.engine,
      stats: result.stats,
      warnings: result.warnings
      });
      return true;
    } catch (error) {
      var message = error && error.message ? error.message : "Converted PDF SVG could not be imported.";
      state.lastError = message;
      if (window.DavaPdfImportPanel) window.DavaPdfImportPanel.setStatus(message, "error");
      if (window.DavaPdfImportShinyBridge) {
        window.DavaPdfImportShinyBridge.notify("svg_editor_pdf_import_failed", {
          fileId: result.fileId,
          fileName: result.fileName,
          page: result.page,
          error: message
        });
      }
      console.error("[DAVA PDF Import] Import failed:", error);
      return false;
    }
  }

  function handleConversionResult(payload) {
    if (!payload) return;
    if (payload.stage === "uploaded") {
      handleUploadResult(payload);
      return;
    }
    if (payload.stage === "converting") {
      if (window.DavaPdfImportPanel) {
        window.DavaPdfImportPanel.setStatus("Converting page " + (payload.page || "") + " with " + (payload.engine || "auto") + "...", "busy");
      }
      return;
    }
    var target = payload.target || "current";
    var imported = 0;
    var failed = 0;
    state.lastError = "";
    (payload.results || []).forEach(function (result) {
      if (importResult(result, target)) imported += 1;
      else failed += 1;
    });
    if (window.DavaPdfImportPanel) {
      if (imported > 0 && failed === 0) window.DavaPdfImportPanel.setStatus("PDF import finished. Imported " + imported + " page(s).", "ready");
      else if (imported > 0) window.DavaPdfImportPanel.setStatus("PDF import partially finished. Imported " + imported + ", failed " + failed + ".", "warning");
      else window.DavaPdfImportPanel.setStatus(state.lastError || "PDF import failed. No SVG objects were inserted.", "error");
    }
  }

  function requestConvert(options) {
    if (!state.uploaded || !state.uploaded.fileId) {
      if (window.DavaPdfImportPanel) window.DavaPdfImportPanel.setStatus("Upload a PDF first.", "error");
      return;
    }
    options = options || {};
    options.fileId = state.uploaded.fileId;
    if (window.DavaPdfImportShinyBridge) window.DavaPdfImportShinyBridge.requestConvert(options);
  }

  window.DavaPdfImportClient = {
    state: state,
    handleUploadResult: handleUploadResult,
    handleConversionResult: handleConversionResult,
    requestConvert: requestConvert
  };
})();
