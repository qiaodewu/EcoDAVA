(function () {
  "use strict";

  function parentShiny() {
    try {
      return window.parent && window.parent.Shiny ? window.parent.Shiny : null;
    } catch (error) {
      return null;
    }
  }

  function post(type, payload) {
    if (window.DavaPdfImportEnv && typeof window.DavaPdfImportEnv.post === "function") {
      window.DavaPdfImportEnv.post(type, payload || {});
    }
  }

  function eventPayload(payload) {
    payload = payload || {};
    payload.documentId = payload.documentId || (window.DavaPdfImportEnv && window.DavaPdfImportEnv.documentId && window.DavaPdfImportEnv.documentId()) || "";
    payload.artboardId = payload.artboardId || payload.documentId;
    payload.timestamp = payload.timestamp || Date.now();
    return payload;
  }

  function notify(eventType, payload) {
    payload = eventPayload(payload);
    post("DAVA_SVG_DOCUMENT_RESULT", {
      eventType: eventType,
      payload: payload
    });
  }

  function requestUpload() {
    post("DAVA_PDF_IMPORT_REQUEST_UPLOAD", {});
    notify("svg_editor_pdf_import_opened", {});
  }

  function requestConvert(payload) {
    payload = eventPayload(payload);
    post("DAVA_PDF_IMPORT_CONVERT_REQUEST", payload);
  }

  window.DavaPdfImportShinyBridge = {
    notify: notify,
    requestUpload: requestUpload,
    requestConvert: requestConvert,
    parentShiny: parentShiny
  };
})();
