(function () {
  "use strict";

  function open(env) {
    window.DavaPdfImportEnv = env || window.DavaPdfImportEnv || {};
    if (window.DavaPdfSvgImporter) window.DavaPdfSvgImporter.bindContextMenu();
    if (window.DavaPdfImportPanel) window.DavaPdfImportPanel.open();
  }

  window.DavaPdfImportTool = {
    open: open
  };
})();
