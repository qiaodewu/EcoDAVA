(function () {
  "use strict";

  var svgNS = "http://www.w3.org/2000/svg";

  function canvasFromEnv() {
    return window.DavaPdfImportEnv && typeof window.DavaPdfImportEnv.getSvgCanvas === "function" ?
      window.DavaPdfImportEnv.getSvgCanvas() :
      null;
  }

  function editorFromEnv() {
    return window.DavaPdfImportEnv && typeof window.DavaPdfImportEnv.getEditor === "function" ?
      window.DavaPdfImportEnv.getEditor() :
      window.svgEditor || null;
  }

  function svgRoot(canvas) {
    if (canvas && typeof canvas.getSvgContent === "function") return canvas.getSvgContent();
    return document.getElementById("svgcontent") || document.querySelector("svg");
  }

  function currentLayer(canvas) {
    var drawing = canvas && canvas.getCurrentDrawing && canvas.getCurrentDrawing();
    if (drawing && typeof drawing.getCurrentLayer === "function") return drawing.getCurrentLayer();
    return svgRoot(canvas);
  }

  function ensureLogicalUserGroup(canvas) {
    var layer = currentLayer(canvas);
    if (!layer) throw new Error("Active SVG-Edit layer was not found.");
    var group = null;
    try {
      group = layer.querySelector(":scope > g[data-dava-logical-user-layer='1']");
    } catch (error) {
      group = Array.prototype.filter.call(layer.children || [], function (child) {
        return child.getAttribute && child.getAttribute("data-dava-logical-user-layer") === "1";
      })[0] || null;
    }
    if (!group) {
      group = document.createElementNS(svgNS, "g");
      group.setAttribute("data-dava-logical-user-layer", "1");
      group.setAttribute("data-dava-layer-role", "user-overlay");
      group.setAttribute("data-dava-source", "user");
      group.setAttribute("data-dava-container-only", "1");
      group.setAttribute("data-dava-selectable", "0");
      group.setAttribute("data-dava-editable", "0");
      layer.appendChild(group);
    }
    group.removeAttribute("pointer-events");
    group.style.pointerEvents = "";
    return group;
  }

  function ensureSvgRootDefs(canvas) {
    var root = svgRoot(canvas);
    if (!root) throw new Error("SVG root was not found.");
    var defs = null;
    try {
      defs = root.querySelector(":scope > defs");
    } catch (error) {
      defs = Array.prototype.filter.call(root.children || [], function (child) {
        return child.nodeName && child.nodeName.toLowerCase() === "defs";
      })[0] || null;
    }
    if (!defs) {
      defs = document.createElementNS(svgNS, "defs");
      root.insertBefore(defs, root.firstChild || null);
    }
    return defs;
  }

  function mergeDefsIntoSvgRoot(cleanSvgString, canvas) {
    if (!window.DavaPdfSvgSanitizer || typeof window.DavaPdfSvgSanitizer.extractDefs !== "function") return;
    var rootDefs = ensureSvgRootDefs(canvas);
    var defsList = window.DavaPdfSvgSanitizer.extractDefs(cleanSvgString, document);
    defsList.forEach(function (defs) {
      Array.prototype.slice.call(defs.childNodes || []).forEach(function (child) {
        rootDefs.appendChild(child);
      });
    });
  }

  function makeImportedPdfWrapper(group, options) {
    options = options || {};
    var wrapper = group;
    if (!wrapper || wrapper.nodeName.toLowerCase() !== "g") {
      wrapper = document.createElementNS(svgNS, "g");
      if (group) wrapper.appendChild(group);
    }
    if (!wrapper.getAttribute("id")) wrapper.setAttribute("id", options.objectId || ("dava-pdf-import-" + Date.now().toString(36)));
    wrapper.setAttribute("data-type", "imported-pdf");
    wrapper.setAttribute("data-source-format", "pdf");
    wrapper.setAttribute("data-dava-source", "pdf-import");
    wrapper.setAttribute("data-dava-edit-policy", "group-first");
    wrapper.setAttribute("data-pdf-file", options.fileName || wrapper.getAttribute("data-pdf-file") || "");
    wrapper.setAttribute("data-pdf-page", options.page || wrapper.getAttribute("data-pdf-page") || "1");
    wrapper.setAttribute("pointer-events", "visiblePainted");
    return wrapper;
  }

  function removeNestedDefs(group) {
    Array.prototype.slice.call(group.querySelectorAll("defs")).forEach(function (defs) {
      if (defs.parentNode) defs.parentNode.removeChild(defs);
    });
  }

  function fitImportedGroupToCanvas(canvas, group) {
    var root = svgRoot(canvas);
    if (!root || !group || typeof group.getBBox !== "function") return;
    try {
      var box = group.getBBox();
      if (!box || !isFinite(box.width) || !isFinite(box.height) || box.width <= 0 || box.height <= 0) return;
      var vb = (root.getAttribute("viewBox") || "").trim().split(/\s+/).map(Number);
      var target = vb.length === 4 && vb.every(isFinite) ? { x: vb[0], y: vb[1], width: vb[2], height: vb[3] } : {
        x: 0,
        y: 0,
        width: Number(root.getAttribute("width")) || 960,
        height: Number(root.getAttribute("height")) || 720
      };
      var scale = Math.min(target.width * 0.86 / box.width, target.height * 0.86 / box.height, 1);
      var tx = target.x + (target.width - box.width * scale) / 2 - box.x * scale;
      var ty = target.y + (target.height - box.height * scale) / 2 - box.y * scale;
      group.setAttribute("transform", "translate(" + tx.toFixed(3) + " " + ty.toFixed(3) + ") scale(" + scale.toFixed(6) + ")");
    } catch (error) {
      console.warn("[DAVA PDF Import] Could not fit PDF group to canvas.", error);
    }
  }

  function selectImported(canvas, element) {
    try {
      if (canvas.setMode) canvas.setMode("select");
      if (canvas.clearSelection) canvas.clearSelection(true);
      if (canvas.selectOnly) canvas.selectOnly([element]);
      else if (canvas.addToSelection) canvas.addToSelection([element], true);
      if (canvas.call) canvas.call("selected", [element]);
      if (canvas.call) canvas.call("changed", [element]);
      if (canvas.selectorManager && element) {
        var selector = canvas.selectorManager.requestSelector(element);
        if (selector && selector.resize) selector.resize();
        if (selector && selector.showGrips) selector.showGrips(true);
      }
    } catch (error) {
      console.warn("[DAVA PDF Import] Could not select imported PDF group.", error);
    }
  }

  function refreshEditor(canvas, element) {
    var editor = editorFromEnv();
    try {
      if (canvas && typeof canvas.setUseData === "function" && element) canvas.setUseData(element);
    } catch (error1) {}
    try {
      if (editor && editor.layersPanel && typeof editor.layersPanel.populateLayers === "function") editor.layersPanel.populateLayers();
      if (editor && editor.topPanel && typeof editor.topPanel.updateContextPanel === "function") editor.topPanel.updateContextPanel();
      if (editor && typeof editor.updateCanvas === "function") editor.updateCanvas(false);
      if (editor && editor.rulers && typeof editor.rulers.updateRulers === "function") editor.rulers.updateRulers();
    } catch (error2) {
      console.warn("[DAVA PDF Import] Editor refresh failed.", error2);
    }
    try {
      if (window.DavaSimpleDocumentStore && typeof window.DavaSimpleDocumentStore.markDirty === "function") {
        window.DavaSimpleDocumentStore.markDirty(null, true);
      }
    } catch (error3) {}
  }

  function notifyEditorChanged(canvas, group, options) {
    refreshEditor(canvas, group);
    try {
      if (canvas && canvas.call) {
        canvas.call("changed", [group]);
        canvas.call("selected", [group]);
      }
    } catch (error) {
      console.warn("[DAVA PDF Import] Could not notify SVG-Edit change listeners.", error);
    }
    try {
      if (window.DavaSimpleDocumentStore && typeof window.DavaSimpleDocumentStore.markDirty === "function") {
        window.DavaSimpleDocumentStore.markDirty(null, true);
      }
    } catch (error2) {}
    if (window.DavaPdfImportShinyBridge) {
      window.DavaPdfImportShinyBridge.notify("svg_editor_pdf_imported", {
        fileId: options.fileId || "",
        fileName: options.fileName || "",
        page: options.page || 1,
        engine: options.engine || "",
        isPureVector: !(options.stats && options.stats.hasRasterImages),
        hasRasterImages: !!(options.stats && options.stats.hasRasterImages),
        stats: options.stats || {},
        warnings: options.warnings || []
      });
    }
  }

  function importViaBridge(cleanSvgString, options) {
    if (!window.DavaPdfImportEnv || typeof window.DavaPdfImportEnv.importSvgIntoCurrentLayer !== "function") return null;
    try {
      return window.DavaPdfImportEnv.importSvgIntoCurrentLayer(cleanSvgString, {
        object_id: options.objectId || ("dava-pdf-import-" + Date.now().toString(36)),
        select_after_import: true,
        center_on_canvas: true,
        source: "pdf-import",
        type: "imported-pdf",
        suppress_import_post: true
      });
    } catch (error) {
      console.warn("[DAVA PDF Import] Bridge import failed.", error);
      return null;
    }
  }

  function importCleanSvgIntoActiveArtboard(cleanSvgString, options) {
    options = options || {};
    var canvas = canvasFromEnv();
    if (!canvas) throw new Error("SVG-Edit canvas is not available.");
    var group = null;
    try {
      mergeDefsIntoSvgRoot(cleanSvgString, canvas);
      group = window.DavaPdfSvgSanitizer.importedGroupFromSvg(cleanSvgString, document);
      removeNestedDefs(group);
      group = makeImportedPdfWrapper(group, options);
      ensureLogicalUserGroup(canvas).appendChild(group);
      fitImportedGroupToCanvas(canvas, group);
    } catch (domError) {
      console.warn("[DAVA PDF Import] Direct DOM insertion failed; trying SVG-Edit bridge import.", domError);
      group = importViaBridge(cleanSvgString, options);
    }
    if (!group || !group.parentNode) throw new Error("Converted PDF SVG could not be inserted into SVG-Edit.");
    if (group.tagName && group.tagName.toLowerCase() !== "g") {
      var wrapper = document.createElementNS(svgNS, "g");
      wrapper.setAttribute("id", options.objectId || ("dava-pdf-import-" + Date.now().toString(36)));
      group.parentNode.insertBefore(wrapper, group);
      wrapper.appendChild(group);
      group = wrapper;
    }
    if (!group.getAttribute("id")) group.setAttribute("id", options.objectId || ("dava-pdf-import-" + Date.now().toString(36)));
    group = makeImportedPdfWrapper(group, options);
    selectImported(canvas, group);
    notifyEditorChanged(canvas, group, options);
    return group;
  }

  function ungroupPdfPage(group) {
    if (!group || !group.parentNode) return null;
    var parent = group.parentNode;
    var moved = [];
    while (group.firstChild) {
      moved.push(parent.insertBefore(group.firstChild, group));
    }
    parent.removeChild(group);
    var canvas = canvasFromEnv();
    if (canvas && canvas.call) canvas.call("changed", moved);
    return moved;
  }

  function bindContextMenu() {
    if (document.documentElement.getAttribute("data-dava-pdf-context") === "1") return;
    document.documentElement.setAttribute("data-dava-pdf-context", "1");
    document.addEventListener("contextmenu", function (event) {
      var group = event.target && event.target.closest ? event.target.closest("g[data-type='imported-pdf']") : null;
      if (!group) return;
      var action = window.prompt("PDF Import\n1. Edit as group\n2. Ungroup PDF page\n3. Select all paths\n4. Select all text\n5. Select all images", "1");
      if (action === null || action === "1") return;
      event.preventDefault();
      if (action === "2") ungroupPdfPage(group);
      if (action === "3" || action === "4" || action === "5") {
        var selector = action === "3" ? "path" : action === "4" ? "text" : "image";
        var nodes = Array.prototype.slice.call(group.querySelectorAll(selector));
        var canvas = canvasFromEnv();
        if (canvas && canvas.selectOnly) canvas.selectOnly(nodes);
      }
    }, true);
  }

  window.DavaPdfSvgImporter = {
    importCleanSvgIntoActiveArtboard: importCleanSvgIntoActiveArtboard,
    ensureLogicalUserGroup: ensureLogicalUserGroup,
    ensureSvgRootDefs: ensureSvgRootDefs,
    mergeDefsIntoSvgRoot: mergeDefsIntoSvgRoot,
    makeImportedPdfWrapper: makeImportedPdfWrapper,
    removeNestedDefs: removeNestedDefs,
    fitImportedGroupToCanvas: fitImportedGroupToCanvas,
    notifyEditorChanged: notifyEditorChanged,
    ungroupPdfPage: ungroupPdfPage,
    bindContextMenu: bindContextMenu
  };
})();
