(function () {
  "use strict";

  if (window.DavaI18n) return;

  var STORAGE_KEY = "dava.interface.language";
  var CATALOG_URL = "dava_i18n_catalog.json?v=20260909-6";
  var supported = ["en", "zh-CN", "zh-TW", "ja", "es"];
  var languages = {
    en: { code: "EN", name: "English", locale: "en-US" },
    "zh-CN": { code: "简", name: "简体中文", locale: "zh-CN" },
    "zh-TW": { code: "繁", name: "繁體中文", locale: "zh-TW" },
    ja: { code: "日", name: "日本語", locale: "ja-JP" },
    es: { code: "ES", name: "Español", locale: "es-ES" }
  };
  var chrome = {
    title: {
      en: "Language settings", "zh-CN": "语言设置", "zh-TW": "語言設定",
      ja: "言語設定", es: "Configuración de idioma"
    },
    intro: {
      en: "Choose the interface language. Imported data, variable names, data values and all analysis outputs are never translated.",
      "zh-CN": "选择界面语言。导入数据、变量名称、数据值以及所有分析结果输出均不参与翻译。",
      "zh-TW": "選擇介面語言。匯入資料、變數名稱、資料值以及所有分析結果輸出均不參與翻譯。",
      ja: "インターフェースの言語を選択してください。インポートしたデータ、変数名、値、およびすべての分析出力は翻訳されません。",
      es: "Elija el idioma de la interfaz. Los datos importados, los nombres de variables, los valores y todos los resultados del análisis nunca se traducen."
    },
    close: {
      en: "Close", "zh-CN": "关闭", "zh-TW": "關閉", ja: "閉じる", es: "Cerrar"
    },
    selected: {
      en: "Selected language", "zh-CN": "已选择语言", "zh-TW": "已選擇語言",
      ja: "選択中の言語", es: "Idioma seleccionado"
    }
  };
  var excludedSelector = [
    "script", "style", "code", "pre", "textarea",
    ".ace_editor", ".CodeMirror", ".dava-code-console",
    ".shiny-plot-output", ".html-widget svg", "svg text", "svg tspan",
    // Data-table content is data, not interface chrome. Protect column names,
    // row names, cell values and column-filter values. The surrounding DT
    // controls (Show, entries, Search, pagination) remain translatable.
    "table.dataTable thead th", "table.dataTable tbody th", "table.dataTable tbody td",
    "table.dataTable tfoot th", "table.dataTable tfoot td",
    ".dava-user-data-table th", ".dava-user-data-table td",
    ".rhandsontable", ".handsontable",
    // Model-text tab labels remain localizable, but their complete rendered
    // bodies are analysis output and must be preserved byte-for-byte.
    "[id$='-model_text']", "[id$='_model_text']",
    ".dava-model-text", "[data-dava-model-text]",
    // Explicit result containers and common analysis-output bindings. Their
    // tab captions are outside these nodes and remain interface-localizable.
    "[data-dava-i18n-role='result']", ".dava-analysis-output",
    "[id$='-module_code_rmd_document']", "[id$='-code_rmd_document']",
    "[id$='-messages']", "[id$='-message_table']",
    "[id$='-error_table']", "[id$='-error_table_anova']",
    "[id$='-diagnostic_table']", "[id$='-model_status']",
    "[id$='-optimization_summary']", "[id$='-optimization_table']",
    "[id$='-optimization_status']",
    "[data-dava-i18n-ignore]"
  ].join(",");
  var state = {
    language: initialLanguage(),
    catalog: {},
    normalizedCatalog: {},
    messageKeys: [],
    ready: false,
    applying: false,
    observer: null
  };

  function initialLanguage() {
    var value = null;
    try { value = window.localStorage.getItem(STORAGE_KEY); } catch (error) {}
    return supported.indexOf(value) >= 0 ? value : "en";
  }

  function ownText(value) {
    return typeof value === "string" ? value : "";
  }

  function normalizedKey(value) {
    var text = ownText(value);
    if (text.normalize) text = text.normalize("NFKC");
    return text.replace(/\s+/g, " ").trim();
  }

  function catalogEntry(value) {
    return state.catalog[value] || state.normalizedCatalog[normalizedKey(value)] || null;
  }

  function translated(value, language) {
    if (!value) return value;
    if (/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?%?$/i.test(value.trim())) return value;
    var entry = catalogEntry(value);
    if (!entry) return value;
    return ownText(entry[language]) || ownText(entry.en) || value;
  }

  function isKnownRendering(source, value) {
    if (source === value) return true;
    var entry = catalogEntry(source);
    if (!entry) return false;
    return supported.some(function (language) { return ownText(entry[language]) === value; });
  }

  function translatedMessage(value, language) {
    var exact = translated(value, language);
    if (exact !== value || language === "zh-CN") return exact;
    // Dynamic application messages may contain several registered interface
    // phrases separated by counts, timestamps or user-owned names. Replace
    // non-overlapping phrases longest-first and preserve every unknown span.
    var occupied = new Array(value.length).fill(false);
    var replacements = [];
    state.messageKeys.forEach(function (key) {
      if (!key || key.length >= value.length) return;
      var position = value.indexOf(key);
      while (position >= 0) {
        var end = position + key.length;
        var overlaps = false;
        for (var index = position; index < end; index += 1) {
          if (occupied[index]) { overlaps = true; break; }
        }
        if (!overlaps) {
          for (var cell = position; cell < end; cell += 1) occupied[cell] = true;
          replacements.push({ start: position, end: end, value: translated(key, language) });
        }
        position = value.indexOf(key, position + key.length);
      }
    });
    if (!replacements.length) return value;
    replacements.sort(function (left, right) { return left.start - right.start; });
    var cursor = 0;
    var pieces = [];
    replacements.forEach(function (replacement) {
      if (replacement.start > cursor) pieces.push(value.slice(cursor, replacement.start));
      pieces.push(replacement.value);
      cursor = replacement.end;
    });
    if (cursor < value.length) pieces.push(value.slice(cursor));
    return pieces.join("");
  }

  function splitWhitespace(value) {
    var match = /^(\s*)([\s\S]*?)(\s*)$/.exec(value || "");
    return { before: match[1], text: match[2], after: match[3] };
  }

  function isAnalysisOutput(element) {
    if (!element || !element.closest) return false;
    if (element.closest("[data-dava-i18n-role='result'], .dava-analysis-output")) return true;
    var output = element.closest(".shiny-bound-output, .shiny-text-output, .shiny-html-output");
    if (!output) return false;
    var id = (output.id || "").toLowerCase();
    return /(?:^|[-_])(?:result|results|model_text|model_table|model_status|diagnostic|diagnostics|error|errors|warning|warnings|messages|rmd|code_rmd_document|module_code_rmd_document|formula_table|summary_table|anova_table|normality_table|variance_table|posthoc|prediction_table|adequacy|overview|optimization)(?:$|[-_])/.test(id);
  }

  function canTranslate(element) {
    if (!element || element.nodeType !== 1) return false;
    if (element.matches && element.matches('[data-dava-i18n-role="original"]')) return false;
    if (element.closest && element.closest('[data-dava-i18n-role="original"]')) return false;
    // Result content must be reproducible across interface languages. This
    // check precedes the DataTables empty-state exception intentionally.
    if (isAnalysisOutput(element)) return false;
    if ((element.matches && element.matches(".dataTables_empty")) ||
        (element.closest && element.closest(".dataTables_empty"))) return true;
    if (element.matches && element.matches(excludedSelector)) return false;
    return !(element.closest && element.closest(excludedSelector));
  }

  function isUserDataChoice(element, text) {
    if (!element || !text) return false;
    // Explicit ownership beats lexical matches: a column called Plot is not
    // a plot tab. Mark custom/detached controls using these attributes.
    if (element.closest('[data-dava-i18n-role="data"]')) return true;
    if (element.closest('[data-dava-i18n-role="interface"]')) return false;
    var select = element.closest && element.closest("select");
    if (!select && element.closest) {
      var picker = element.closest(".bootstrap-select, .selectize-control, .choices, .bs-container");
      if (picker) {
        select = picker.querySelector("select") ||
          (picker.previousElementSibling && picker.previousElementSibling.matches("select")
            ? picker.previousElementSibling : null);
      }
      var list = element.closest('[role="listbox"], .selectize-dropdown');
      if (!select && list && list.id) {
        var owner = document.querySelector('[aria-owns="' + CSS.escape(list.id) + '"], [aria-controls="' + CSS.escape(list.id) + '"]');
        var ownerPicker = owner && owner.closest('.bootstrap-select, .selectize-control, .choices');
        if (ownerPicker) select = ownerPicker.querySelector('select');
      }
    }
    var selectId = select && (select.id || select.name) || "";
    var option = element.closest && element.closest("option");
    var choice = element.closest && element.closest("[data-value]");
    var choiceValue = option ? option.value : (choice ? choice.getAttribute("data-value") : "");
    var choiceSurface = option || element.closest('.filter-option, .selectize-input .item, .selectize-dropdown .option, .choices__item, [role="option"], .bootstrap-select .dropdown-menu .text, .bs-container .dropdown-menu .text');
    if (!choiceSurface) return false;
    if ((select && select.getAttribute('data-dava-i18n-role') === 'stable-choice') ||
        (select && select.closest && select.closest('[data-dava-i18n-role="stable-choice"]')) ||
        element.closest('[data-dava-i18n-role="stable-choice"]')) return true;
    if (select && select.getAttribute('data-dava-i18n-role') === 'data') return true;
    if (select && select.getAttribute('data-dava-i18n-role') === 'interface') return false;
    // Resolve selected-button labels as well as detached menus against the
    // native option, rather than treating catalog membership as UI ownership.
    if (!choiceValue && select) {
      var matched = Array.prototype.find.call(select.options, function (item) {
        return item.textContent.trim() === text || item.value === text;
      });
      if (matched) choiceValue = matched.value;
    }
    if (/^(__demo__|\.__method_demo__)$/.test(choiceValue || "")) return false;
    if (!choiceValue && /^(Nothing selected|None selected|Select an option|请选择)$/.test(text)) return false;
    // Controls describing an application method, mode, type or display option
    // are fixed DAVA interface controls even when their IDs contain words such
    // as "factor" or "variable". Their registered choices must be localized.
    // For example factor_n/factor_n_aov contains the built-in choices
    // 单因素、双因素、三因素、四因素; none of those are user data columns.
    var interfaceControl = /(^|[-_])(factor_n|n_factors)([-_]|$)|(^|[-_])(method|mode|type|number|count|strategy|transform|test|palette|theme|position|layout|status|level|engine|family|link|distribution|distance|metric|algorithm|adjust|alternative|direction|correction|format|language|policy|structure)$/i;
    if (selectId && interfaceControl.test(selectId)) return false;
    var dataSelector = /(^|[-_])(dataset|dataset_select_input|response|predictor|predictors|covariate|covariates|variable|variables|var|vars|column|columns|row|rows|sheet|workbook|feature|features|sample|samples|factor|factors|fixed_effect|mediator|mediators|moderator|moderators|group_var|id_var|taxonomy|abundance|metadata|environment)([-_]|$)/i;
    if (selectId && dataSelector.test(selectId)) {
      // A value identical to its visible label is a user-data value in DAVA's
      // column/row selectors. Preserve it even if it happens to equal a word
      // present in the application catalog. Built-in sentinel choices use a
      // distinct value (usually an empty or reserved value) and are localized.
      if (option && option.value === text) return true;
      if (choice && choice.getAttribute("data-value") === text) return true;
      return true;
    }
    // Unknown choice controls are data-safe by default. Application options
    // can opt into localization explicitly; labels and action buttons are
    // outside choiceSurface and continue to translate normally.
    return true;
  }

  function isMessageElement(element) {
    return !!(element && element.closest && element.closest(
      ".shiny-notification, .shiny-progress, .progress-text, .modal-title, " +
      ".progress-message, .progress-detail, .shiny-progress-notification, " +
      ".alert, .invalid-feedback, .validation-message, .text-success, .text-danger, " +
      ".dava-code-status, .dava-environment-summary, .dava-object-structure, " +
      ".small-muted, .help-block, .form-text, .dava-sem-status, .dava-sem-document-state, " +
      ".dava-sem-footer, .dava-sem-context-menu"
    ));
  }

  function translateTextNode(node) {
    if (!node || node.nodeType !== 3 || !canTranslate(node.parentElement)) return;
    var parts = splitWhitespace(node.nodeValue);
    if (!parts.text) return;
    // Catalog membership must never override data ownership.
    if (isUserDataChoice(node.parentElement, parts.text)) return;
    if (!Object.prototype.hasOwnProperty.call(node, "__davaI18nOriginal")) {
      node.__davaI18nOriginal = parts.text;
    } else {
      var expected = isMessageElement(node.parentElement)
        ? translatedMessage(node.__davaI18nOriginal, state.language)
        : translated(node.__davaI18nOriginal, state.language);
      if (parts.text !== expected && !isKnownRendering(node.__davaI18nOriginal, parts.text)) {
        node.__davaI18nOriginal = parts.text;
      }
    }
    var source = node.__davaI18nOriginal;
    var next = isMessageElement(node.parentElement)
      ? translatedMessage(source, state.language)
      : translated(source, state.language);
    var value = parts.before + next + parts.after;
    if (node.nodeValue !== value) node.nodeValue = value;
  }

  function translateAttribute(element, attribute) {
    if (!element.hasAttribute(attribute)) return;
    if (attribute !== 'placeholder' && isUserDataChoice(element, element.getAttribute(attribute))) return;
    var storeName = "data-dava-i18n-original-" + attribute.replace(/[^a-z0-9_-]/gi, "-");
    if (!element.hasAttribute(storeName)) {
      element.setAttribute(storeName, element.getAttribute(attribute) || "");
    }
    var source = element.getAttribute(storeName) || "";
    var current = element.getAttribute(attribute) || "";
    var expected = translated(source, state.language);
    if (current !== expected && !isKnownRendering(source, current)) {
      source = current;
      element.setAttribute(storeName, source);
    }
    var next = translated(source, state.language);
    if (element.getAttribute(attribute) !== next) element.setAttribute(attribute, next);
  }

  function translateElement(element) {
    if (!canTranslate(element)) return;
    ["title", "placeholder", "aria-label", "aria-valuetext", "data-original-title"].forEach(function (attribute) {
      translateAttribute(element, attribute);
    });
    if (element.matches && element.matches('input[type="button"], input[type="submit"], input[type="reset"]')) {
      translateAttribute(element, "value");
    }
    Array.prototype.forEach.call(element.childNodes || [], function (node) {
      if (node.nodeType === 3) translateTextNode(node);
    });
  }

  function safeTranslateElement(element) {
    try { translateElement(element); } catch (error) {
      if (window.console && console.debug) console.debug("DAVA i18n skipped one element", error);
    }
  }

  function translateTree(root) {
    if (!root || !state.ready || state.applying) return;
    state.applying = true;
    try {
      if (root.nodeType === 3) {
        translateTextNode(root);
      } else if (root.nodeType === 1 || root.nodeType === 9) {
        if (root.nodeType === 1) safeTranslateElement(root);
        var elements = root.querySelectorAll ? root.querySelectorAll("*") : [];
        Array.prototype.forEach.call(elements, safeTranslateElement);
      }
    } finally {
      state.applying = false;
    }
  }

  function setDocumentLanguage(language) {
    var locale = languages[language].locale;
    document.documentElement.lang = language;
    document.documentElement.setAttribute("data-dava-language", language);
    document.documentElement.setAttribute("data-dava-locale", locale);
  }

  function notifyShiny(language) {
    if (window.Shiny && typeof window.Shiny.setInputValue === "function") {
      window.Shiny.setInputValue("dava_interface_language", language, { priority: "event" });
    }
    document.dispatchEvent(new CustomEvent("dava:language-changed", {
      detail: { language: language, locale: languages[language].locale }
    }));
  }

  function syncSvgEditors(language) {
    var svgLanguage = language === "zh-CN" ? "zh-CN" : "en";
    Array.prototype.forEach.call(document.querySelectorAll("iframe"), function (frame) {
      try {
        var editor = frame.contentWindow && frame.contentWindow.svgEditor;
        if (editor && typeof editor.setLang === "function") editor.setLang(svgLanguage);
      } catch (error) {}
    });
  }

  function setLanguage(language, options) {
    options = options || {};
    if (supported.indexOf(language) < 0) language = "en";
    state.language = language;
    setDocumentLanguage(language);
    if (options.persist !== false) {
      try { window.localStorage.setItem(STORAGE_KEY, language); } catch (error) {}
    }
    translateTree(document);
    updateModal();
    syncSvgEditors(language);
    notifyShiny(language);
  }

  function modalElement() {
    return document.getElementById("dava-language-modal");
  }

  function createModal() {
    var existing = modalElement();
    if (existing) return existing;
    var wrapper = document.createElement("div");
    wrapper.innerHTML = [
      '<div class="modal fade dava-language-modal" id="dava-language-modal" tabindex="-1" aria-hidden="true">',
      '  <div class="modal-dialog modal-dialog-centered">',
      '    <div class="modal-content">',
      '      <div class="modal-header">',
      '        <div class="modal-title-wrap">',
      '          <span class="modal-title-icon" aria-hidden="true"><i class="fas fa-globe"></i></span>',
      '          <h5 class="modal-title" id="dava-language-title"></h5>',
      '        </div>',
      '        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>',
      '      </div>',
      '      <div class="modal-body">',
      '        <p class="dava-language-intro" id="dava-language-intro"></p>',
      '        <div class="dava-language-list" role="radiogroup"></div>',
      '      </div>',
      '      <div class="modal-footer">',
      '        <button type="button" class="btn btn-secondary" id="dava-language-close" data-bs-dismiss="modal"></button>',
      '      </div>',
      '    </div>',
      '  </div>',
      '</div>'
    ].join("");
    var modal = wrapper.firstElementChild;
    modal.setAttribute("data-dava-i18n-ignore", "true");
    var list = modal.querySelector(".dava-language-list");
    supported.forEach(function (language) {
      var info = languages[language];
      var button = document.createElement("button");
      button.type = "button";
      button.className = "dava-language-choice";
      button.setAttribute("data-language", language);
      button.setAttribute("role", "radio");
      button.innerHTML =
        '<span class="dava-language-code" aria-hidden="true"></span>' +
        '<span class="dava-language-label"></span>' +
        '<span class="dava-language-check" aria-hidden="true"><i class="fas fa-check"></i></span>';
      button.querySelector(".dava-language-code").textContent = info.code;
      button.querySelector(".dava-language-label").textContent = info.name;
      button.addEventListener("click", function () { setLanguage(language); });
      list.appendChild(button);
    });
    document.body.appendChild(modal);
    updateModal();
    return modal;
  }

  function updateModal() {
    var modal = modalElement();
    if (!modal) return;
    var language = state.language;
    modal.querySelector("#dava-language-title").textContent = chrome.title[language];
    modal.querySelector("#dava-language-intro").textContent = chrome.intro[language];
    modal.querySelector("#dava-language-close").textContent = chrome.close[language];
    modal.querySelector(".btn-close").setAttribute("aria-label", chrome.close[language]);
    Array.prototype.forEach.call(modal.querySelectorAll(".dava-language-choice"), function (button) {
      var active = button.getAttribute("data-language") === language;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-checked", active ? "true" : "false");
      button.setAttribute("aria-label", languages[button.getAttribute("data-language")].name +
        (active ? " — " + chrome.selected[language] : ""));
    });
  }

  function openModal() {
    var modal = createModal();
    updateModal();
    if (window.bootstrap && window.bootstrap.Modal) {
      window.bootstrap.Modal.getOrCreateInstance(modal).show();
    } else if (window.jQuery && window.jQuery.fn.modal) {
      window.jQuery(modal).modal("show");
    }
  }

  function installObserver() {
    if (state.observer) return;
    state.observer = new MutationObserver(function (records) {
      if (state.applying) return;
      records.forEach(function (record) {
        if (record.type === "characterData") translateTree(record.target);
        if (record.type === "attributes") safeTranslateElement(record.target);
        Array.prototype.forEach.call(record.addedNodes || [], translateTree);
      });
    });
    state.observer.observe(document.documentElement, {
      childList: true, characterData: true, attributes: true, subtree: true,
      attributeFilter: ["title", "placeholder", "aria-label", "aria-valuetext", "data-original-title", "value"]
    });
  }

  function installEvents() {
    document.addEventListener("click", function (event) {
      var trigger = event.target && event.target.closest
        ? event.target.closest("#dava_language_settings") : null;
      if (!trigger) return;
      event.preventDefault();
      event.stopPropagation();
      openModal();
    }, true);
    document.addEventListener("shiny:connected", function () {
      notifyShiny(state.language);
      translateTree(document);
    });
    document.addEventListener("shiny:value", function () {
      window.setTimeout(function () { translateTree(document); }, 0);
    });
  }

  function loadCatalog() {
    return window.fetch(CATALOG_URL, { cache: "no-cache" })
      .then(function (response) {
        if (!response.ok) throw new Error("Unable to load the DAVA language catalog.");
        return response.json();
      })
      .then(function (catalog) {
        state.catalog = catalog && catalog.messages ? catalog.messages : catalog;
        state.normalizedCatalog = {};
        Object.keys(state.catalog).forEach(function (key) {
          var normalized = normalizedKey(key);
          if (!Object.prototype.hasOwnProperty.call(state.normalizedCatalog, normalized)) {
            state.normalizedCatalog[normalized] = state.catalog[key];
          }
        });
        state.messageKeys = Object.keys(state.catalog).filter(function (key) {
          return key.length >= 2;
        }).sort(function (left, right) { return right.length - left.length; });
        state.ready = true;
        translateTree(document);
      })
      .catch(function (error) {
        state.ready = true;
        if (window.console && console.warn) console.warn(error.message || error);
      });
  }

  window.DavaI18n = {
    getLanguage: function () { return state.language; },
    setLanguage: setLanguage,
    open: openModal,
    translate: function (value, language) { return translated(value, language || state.language); },
    translateTree: translateTree,
    languages: languages
  };

  setDocumentLanguage(state.language);
  installEvents();
  installObserver();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      createModal();
      loadCatalog().then(function () { setLanguage(state.language, { persist: false }); });
    });
  } else {
    createModal();
    loadCatalog().then(function () { setLanguage(state.language, { persist: false }); });
  }
})();
