const zhCN = {
  opensave: {
    new_doc: "新建文档",
    open_image_doc: "打开 SVG",
    save_doc: "保存图像",
    save_as_doc: "另存为图像"
  }
};
export {
  zhCN as default
};
//# sourceMappingURL=zh-CN.js.map
