const en = {
  opensave: {
    new_doc: "New Document",
    open_image_doc: "Open SVG",
    save_doc: "Save SVG",
    save_as_doc: "Save as SVG"
  }
};
export {
  en as default
};
//# sourceMappingURL=en.js.map
