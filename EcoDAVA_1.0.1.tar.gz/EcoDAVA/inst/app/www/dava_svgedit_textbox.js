/* DAVA SVG-Edit area text layer.
 * Area text is represented as SVG <text>/<tspan> inside a selectable group.
 * Resizing changes box dimensions and line layout; normal resize does not scale
 * font-size or write scale transforms to the text element.
 */
(function () {
  "use strict";

  var SVG_NS = "http://www.w3.org/2000/svg";
  var TEXTBOX_SELECTOR = "g[data-dava-textbox='1']";
  var activeResize = null;
  var observer = null;
  var observerTimer = 0;
  var normalizing = false;

  function svgEl(name) {
    return document.createElementNS(SVG_NS, name);
  }

  function defaultFontFamily() {
    return window.DAVA_SVGEDIT_DEFAULT_FONT ||
      "\"Aptos\", \"Calibri\", \"Microsoft YaHei\", \"PingFang SC\", \"Hiragino Sans GB\", Arial, sans-serif";
  }

  function asNumber(value, fallback) {
    var number = parseFloat(value);
    return Number.isFinite(number) ? number : fallback;
  }

  function safeText(value) {
    return value === undefined || value === null ? "" : String(value);
  }

  function getSvgCanvas() {
    if (window.DavaSvgEditBridge && typeof window.DavaSvgEditBridge.getSvgCanvas === "function") {
      return window.DavaSvgEditBridge.getSvgCanvas();
    }
    return window.svgCanvas ||
      window.svgEditor && (window.svgEditor.svgCanvas || window.svgEditor.canvas || window.svgEditor.svgCanvas_) ||
      window.editor && (window.editor.svgCanvas || window.editor.canvas) ||
      null;
  }

  function waitForSvgCanvas(callback, attempts) {
    attempts = attempts || 0;
    var canvas = getSvgCanvas();
    if (canvas) {
      callback(canvas);
      return;
    }
    if (attempts > 120) {
      console.warn("[DAVA area text] SVG-Edit canvas API was not found.");
      return;
    }
    window.setTimeout(function () {
      waitForSvgCanvas(callback, attempts + 1);
    }, 100);
  }

  function getSvgRoot() {
    return document.querySelector("#svgcontent svg") ||
      document.querySelector("svg#svgcanvas") ||
      document.querySelector("svg");
  }

  function getCurrentLayer(canvas) {
    try {
      if (canvas && typeof canvas.getCurrentGroup === "function" && canvas.getCurrentGroup()) {
        return canvas.getCurrentGroup();
      }
      if (canvas && typeof canvas.getCurrentDrawing === "function") {
        var drawing = canvas.getCurrentDrawing();
        if (drawing && typeof drawing.getCurrentLayer === "function" && drawing.getCurrentLayer()) {
          return drawing.getCurrentLayer();
        }
      }
    } catch (error) {
      console.warn("[DAVA area text] Current layer lookup failed.", error);
    }
    return document.querySelector("#svgcontent > g.layer, #svgcontent g.layer") ||
      document.getElementById("svgcontent") ||
      getSvgRoot();
  }

  function getSelectedElements(canvas) {
    if (canvas && typeof canvas.getSelectedElements === "function") {
      return canvas.getSelectedElements().filter(Boolean);
    }
    return [];
  }

  function selectElement(canvas, element) {
    if (!canvas || !element) return;
    try {
      if (typeof canvas.selectOnly === "function") {
        canvas.selectOnly([element], true);
      } else if (typeof canvas.clearSelection === "function" && typeof canvas.addToSelection === "function") {
        canvas.clearSelection(true);
        canvas.addToSelection([element], true);
      }
    } catch (error) {
      console.warn("[DAVA area text] Selection failed.", error);
    }
  }

  function notifyChanged(elements) {
    var canvas = getSvgCanvas();
    try {
      if (canvas && typeof canvas.call === "function") canvas.call("changed", elements || []);
      if (canvas && typeof canvas.recalculateAllSelectedDimensions === "function") {
        canvas.recalculateAllSelectedDimensions();
      }
    } catch (error) {
      console.warn("[DAVA area text] SVG-Edit change notification failed.", error);
    }
  }

  function addInsertHistory(element) {
    var canvas = getSvgCanvas();
    try {
      if (canvas && canvas.history && canvas.history.InsertElementCommand && typeof canvas.addCommandToHistory === "function") {
        canvas.addCommandToHistory(new canvas.history.InsertElementCommand(element));
      }
    } catch (error) {
      console.warn("[DAVA area text] Insert history registration failed.", error);
    }
  }

  function addChangeHistory(element, oldValues, label) {
    var canvas = getSvgCanvas();
    try {
      if (canvas && canvas.history && canvas.history.ChangeElementCommand && typeof canvas.addCommandToHistory === "function") {
        canvas.addCommandToHistory(new canvas.history.ChangeElementCommand(element, oldValues || {}, label || "DAVA area text"));
      }
    } catch (error) {
      console.warn("[DAVA area text] Change history registration failed.", error);
    }
  }

  function uniqueId() {
    var nextId = "";
    var canvas = getSvgCanvas();
    try {
      if (canvas && typeof canvas.getNextId === "function") nextId = canvas.getNextId();
    } catch (error) {}
    return nextId || ("dava-area-text-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8));
  }

  function isAreaTextElement(element) {
    return !!findAreaTextRoot(element);
  }

  function findAreaTextRoot(element) {
    if (!element || element.nodeType !== 1) return null;
    if (element.matches && element.matches(TEXTBOX_SELECTOR)) return element;
    return element.closest ? element.closest(TEXTBOX_SELECTOR) : null;
  }

  function getTextElement(group) {
    return group ? group.querySelector("text") : null;
  }

  function getFrameElement(group) {
    return group ? group.querySelector(".dava-area-text-frame") : null;
  }

  function getFontSize(textEl) {
    if (!textEl) return 16;
    var computed = window.getComputedStyle ? window.getComputedStyle(textEl) : null;
    return asNumber(textEl.getAttribute("font-size") || computed && computed.fontSize, 16);
  }

  function getLineHeight(group, textEl) {
    return asNumber(group && group.getAttribute("data-line-height"), asNumber(textEl && textEl.getAttribute("data-line-height"), 1.25));
  }

  function copyFontAttributes(source, target) {
    ["font-family", "font-size", "font-weight", "font-style", "letter-spacing"].forEach(function (attr) {
      var value = source.getAttribute(attr);
      if (value !== null && value !== "") target.setAttribute(attr, value);
    });
    var style = window.getComputedStyle ? window.getComputedStyle(source) : null;
    if (style) {
      if (!target.getAttribute("font-family")) target.setAttribute("font-family", style.fontFamily);
      if (!target.getAttribute("font-size")) target.setAttribute("font-size", style.fontSize);
      if (!target.getAttribute("font-weight")) target.setAttribute("font-weight", style.fontWeight);
      if (!target.getAttribute("font-style")) target.setAttribute("font-style", style.fontStyle);
      if (!target.getAttribute("letter-spacing")) target.setAttribute("letter-spacing", style.letterSpacing);
    }
  }

  function measureTextWidth(textEl, text) {
    text = safeText(text);
    if (!text) return 0;
    var root = getSvgRoot();
    if (!root || !textEl) return text.length * getFontSize(textEl) * 0.55;
    var probe = svgEl("text");
    copyFontAttributes(textEl, probe);
    probe.setAttribute("visibility", "hidden");
    probe.setAttribute("x", "-10000");
    probe.setAttribute("y", "-10000");
    probe.textContent = text;
    root.appendChild(probe);
    var width = 0;
    try {
      if (typeof probe.getComputedTextLength === "function") {
        width = probe.getComputedTextLength();
      }
      if (!width && typeof probe.getBBox === "function") {
        width = probe.getBBox().width;
      }
    } catch (error) {
      width = text.length * getFontSize(textEl) * 0.55;
    }
    probe.remove();
    return width || 0;
  }

  function tokenizeParagraph(text) {
    var tokens = safeText(text).match(/[\u3400-\u9fff\uf900-\ufaff]|[^\s\u3400-\u9fff\uf900-\ufaff]+|\s+/g);
    return tokens || [""];
  }

  function wrapParagraph(textEl, paragraph, maxWidth) {
    var tokens = tokenizeParagraph(paragraph);
    var lines = [];
    var current = "";

    function pushLine(line) {
      lines.push(line.replace(/\s+$/g, ""));
    }

    tokens.forEach(function (token) {
      var candidate = current + token;
      if (!current && /^\s+$/.test(token)) return;
      if (!current || measureTextWidth(textEl, candidate) <= maxWidth) {
        current = candidate;
        return;
      }
      pushLine(current);
      current = /^\s+$/.test(token) ? "" : token.replace(/^\s+/g, "");
      while (current && measureTextWidth(textEl, current) > maxWidth && current.length > 1) {
        var cut = 1;
        for (var i = 1; i <= current.length; i += 1) {
          if (measureTextWidth(textEl, current.slice(0, i)) <= maxWidth) cut = i;
          else break;
        }
        pushLine(current.slice(0, cut));
        current = current.slice(cut);
      }
    });
    pushLine(current);
    return lines.length ? lines : [""];
  }

  function layoutAreaText(group) {
    group = findAreaTextRoot(group);
    if (!group) return false;
    var textEl = getTextElement(group);
    if (!textEl) return false;
    var rawText = getRawText(group);
    var width = Math.max(1, asNumber(group.getAttribute("data-textbox-width"), 240));
    var height = Math.max(1, asNumber(group.getAttribute("data-textbox-height"), 120));
    var x = asNumber(textEl.getAttribute("x"), 0);
    var y = asNumber(textEl.getAttribute("y"), getFontSize(textEl));
    var fontSize = getFontSize(textEl);
    var lineHeight = getLineHeight(group, textEl);
    var dy = fontSize * lineHeight;
    var lines = [];

    safeText(rawText).split(/\r\n|\r|\n/).forEach(function (paragraph) {
      Array.prototype.push.apply(lines, wrapParagraph(textEl, paragraph, width));
    });

    while (textEl.firstChild) textEl.removeChild(textEl.firstChild);
    lines.forEach(function (line, index) {
      var tspan = svgEl("tspan");
      tspan.setAttribute("x", String(x));
      tspan.setAttribute("dy", index === 0 ? "0" : String(dy));
      tspan.textContent = line || "\u00a0";
      textEl.appendChild(tspan);
    });
    textEl.setAttribute("y", String(y));

    var overflow = lines.length * dy > height + 0.01;
    if (overflow) {
      group.setAttribute("data-overflow", "1");
      group.classList.add("is-overflow");
    } else {
      group.removeAttribute("data-overflow");
      group.classList.remove("is-overflow");
    }
    return true;
  }

  function setRawText(group, rawText) {
    group = findAreaTextRoot(group);
    if (!group) return false;
    group.setAttribute("data-raw-text", safeText(rawText));
    layoutAreaText(group);
    notifyChanged([group]);
    return true;
  }

  function getRawText(group) {
    group = findAreaTextRoot(group);
    return group ? safeText(group.getAttribute("data-raw-text")) : "";
  }

  function resizeAreaText(group, width, height, options) {
    group = findAreaTextRoot(group);
    if (!group) return null;
    options = options || {};
    var textEl = getTextElement(group);
    var frame = getFrameElement(group);
    var fontSize = getFontSize(textEl);
    var lineHeight = getLineHeight(group, textEl);
    var oldWidth = asNumber(group.getAttribute("data-textbox-width"), 240);
    var oldHeight = asNumber(group.getAttribute("data-textbox-height"), 120);
    var minWidth = asNumber(options.minWidth, 20);
    var minHeight = asNumber(options.minHeight, fontSize * lineHeight);
    var nextWidth = Math.max(minWidth, asNumber(width, oldWidth));
    var nextHeight = Math.max(minHeight, asNumber(height, oldHeight));

    if (options.scaleFont === true && textEl) {
      var factor = asNumber(options.scaleFactor, Math.sqrt(nextWidth * nextHeight / Math.max(1, oldWidth * oldHeight)));
      textEl.setAttribute("font-size", String(Math.max(1, fontSize * factor)));
    }

    group.setAttribute("data-textbox-width", String(nextWidth));
    group.setAttribute("data-textbox-height", String(nextHeight));
    if (frame) {
      frame.setAttribute("width", String(nextWidth));
      frame.setAttribute("height", String(nextHeight));
    }
    layoutAreaText(group);
    notifyChanged([group]);
    return { width: nextWidth, height: nextHeight };
  }

  function createAreaText(options) {
    options = options || {};
    var canvas = getSvgCanvas();
    var layer = getCurrentLayer(canvas);
    if (!layer) throw new Error("SVG-Edit current layer was not found.");

    var x = asNumber(options.x, 96);
    var y = asNumber(options.y, 96);
    var width = Math.max(20, asNumber(options.width, 240));
    var height = Math.max(20, asNumber(options.height, 120));
    var fontSize = asNumber(options.fontSize, 16);
    var lineHeight = asNumber(options.lineHeight, 1.25);
    var text = safeText(options.text || "输入文字");

    var group = svgEl("g");
    group.setAttribute("id", options.id || uniqueId());
    group.setAttribute("class", "dava-area-text");
    group.setAttribute("data-dava-textbox", "1");
    group.setAttribute("data-dava-type", "area-text");
    group.setAttribute("data-textbox-width", String(width));
    group.setAttribute("data-textbox-height", String(height));
    group.setAttribute("data-line-height", String(lineHeight));
    group.setAttribute("data-raw-text", text);
    group.setAttribute("transform", "translate(" + x + " " + y + ")");

    var frame = svgEl("rect");
    frame.setAttribute("class", "dava-area-text-frame");
    frame.setAttribute("x", "0");
    frame.setAttribute("y", "0");
    frame.setAttribute("width", String(width));
    frame.setAttribute("height", String(height));
    frame.setAttribute("fill", "none");
    frame.setAttribute("stroke", "transparent");
    frame.setAttribute("pointer-events", "none");

    var textEl = svgEl("text");
    textEl.setAttribute("x", "0");
    textEl.setAttribute("y", String(fontSize));
    textEl.setAttribute("font-size", String(fontSize));
    textEl.setAttribute("font-family", options.fontFamily || defaultFontFamily());
    textEl.setAttribute("fill", options.fill || "#000000");

    group.appendChild(frame);
    group.appendChild(textEl);
    layer.appendChild(group);
    layoutAreaText(group);
    addInsertHistory(group);
    selectElement(canvas, group);
    notifyChanged([group]);
    return group;
  }

  function selectedTextElement() {
    var canvas = getSvgCanvas();
    var selected = getSelectedElements(canvas);
    for (var i = 0; i < selected.length; i += 1) {
      var node = selected[i];
      if (findAreaTextRoot(node)) continue;
      if (node.tagName && node.tagName.toLowerCase() === "text") return node;
      if (node.querySelector) {
        var text = node.querySelector("text");
        if (text) return text;
      }
    }
    return null;
  }

  function convertSelectedTextToAreaText(options) {
    options = options || {};
    var oldText = selectedTextElement();
    if (!oldText) {
      console.warn("[DAVA area text] No SVG text element is selected.");
      return null;
    }
    var bbox = { x: 0, y: 0, width: 240, height: 80 };
    try { bbox = oldText.getBBox(); } catch (error) {}
    var area = createAreaText({
      x: asNumber(options.x, bbox.x),
      y: asNumber(options.y, bbox.y),
      width: asNumber(options.width, Math.max(80, bbox.width || 240)),
      height: asNumber(options.height, Math.max(32, bbox.height || 80)),
      text: options.text || oldText.textContent || "",
      fontFamily: options.fontFamily || oldText.getAttribute("font-family") || window.getComputedStyle(oldText).fontFamily,
      fontSize: options.fontSize || getFontSize(oldText),
      fill: options.fill || oldText.getAttribute("fill") || window.getComputedStyle(oldText).fill,
      lineHeight: options.lineHeight || 1.25
    });
    var parent = oldText.parentNode;
    if (parent) {
      var oldNext = oldText.nextSibling;
      parent.removeChild(oldText);
      addChangeHistory(parent, { child: oldText, nextSibling: oldNext }, "Convert to DAVA area text");
    }
    return area;
  }

  function commitAreaTextEdit(group, rawText) {
    group = findAreaTextRoot(group);
    if (!group) return false;
    var oldText = group.getAttribute("data-raw-text");
    group.setAttribute("data-raw-text", safeText(rawText));
    layoutAreaText(group);
    addChangeHistory(group, { "data-raw-text": oldText }, "Edit DAVA area text");
    notifyChanged([group]);
    return true;
  }

  // R/ggplot imports use ordinary <text>/<tspan> nodes rather than the DAVA
  // area-text wrapper.  Edit those nodes through the same browser-native text
  // surface used by PowerPoint: a positioned textarea gives reliable mouse
  // drag selection, deletion and keyboard navigation while preserving the
  // original SVG node and its style.
  function editableSvgText(element) {
    if (!element || element.nodeType !== 1) return null;
    if (element.tagName && element.tagName.toLowerCase() === "text") return element;
    var direct = element.closest ? element.closest("text") : null;
    if (direct) return direct;
    // SVG hit testing can return the imported R-plot wrapper/group rather than
    // the glyph itself. Resolve its text child so the edit overlay is still
    // created for small annotations such as R2/P/n labels.
    return element.querySelector ? element.querySelector("text") : null;
  }

  function svgTextAtPoint(clientX, clientY) {
    var hit = document.elementFromPoint ? document.elementFromPoint(clientX, clientY) : null;
    var text = editableSvgText(hit);
    if (text) return text;
    var nodes = document.querySelectorAll(
      "[data-dava-source='R'] text,[data-dava-type='r-plot'] text,#svgcontent text,svg text"
    );
    for (var index = nodes.length - 1; index >= 0; index -= 1) {
      var node = nodes[index];
      var rect = node.getBoundingClientRect && node.getBoundingClientRect();
      if (!rect || (!rect.width && !rect.height)) continue;
      if (clientX >= rect.left - 4 && clientX <= rect.right + 4 &&
          clientY >= rect.top - 4 && clientY <= rect.bottom + 4) return node;
    }
    return null;
  }

  function svgTextValue(textEl) {
    if (!textEl) return "";
    var stored = textEl.getAttribute && textEl.getAttribute("data-dava-text-value");
    if (stored !== null) return stored;
    var multiline = textEl.getAttribute && textEl.getAttribute("data-dava-multiline-text");
    if (multiline !== null) return multiline;
    var tspans = Array.prototype.slice.call(textEl.querySelectorAll("tspan"));
    if (!tspans.length) return textEl.textContent || "";
    // R/ggplot often splits one visual label into several tspans for styling.
    // Those runs are not line breaks and must be concatenated. Explicit user
    // line breaks are stored in data-dava-text-value above; only use a newline
    // fallback for tspans that carry distinct y/dy line positioning.
    return tspans.map(function (node) { return node.textContent || ""; }).join("");
  }

  function commitSvgTextEdit(textEl, rawText, original) {
    if (!textEl || !textEl.parentNode) return false;
    var oldText = original === undefined ? svgTextValue(textEl) : original;
    while (textEl.firstChild) textEl.removeChild(textEl.firstChild);
    var lines = safeText(rawText).split(/\r?\n/);
    if (lines.length > 1) {
      textEl.setAttribute("data-dava-text-value", safeText(rawText));
      textEl.setAttribute("data-dava-multiline-text", safeText(rawText));
    } else {
      textEl.removeAttribute("data-dava-text-value");
      textEl.removeAttribute("data-dava-multiline-text");
    }
    // Keep a single text node for ordinary R labels; use tspans only when the
    // user explicitly inserted line breaks so the result remains editable.
    if (lines.length <= 1) {
      textEl.textContent = lines[0];
    } else {
      var x = textEl.getAttribute("x") || "0";
      var dy = asNumber(textEl.getAttribute("font-size"), 12) * 1.2;
      lines.forEach(function (line, index) {
        var tspan = svgEl("tspan");
        tspan.setAttribute("x", x);
        tspan.setAttribute("dy", index ? String(dy) : "0");
        tspan.textContent = line;
        textEl.appendChild(tspan);
      });
    }
    addChangeHistory(textEl, { textContent: oldText }, "Edit SVG text");
    notifyChanged([textEl]);
    return true;
  }

  function richEditorRuns(editor) {
    var runs = [];
    function append(text, style) {
      if (!text) return;
      var previous = runs[runs.length - 1];
      var key = JSON.stringify(style || {});
      if (previous && previous.key === key) previous.text += text;
      else runs.push({ text: text, style: Object.assign({}, style || {}), key: key });
    }
    function walk(node, inherited) {
      if (node.nodeType === 3) { append(node.nodeValue || "", inherited); return; }
      if (node.nodeType !== 1) return;
      if (/^br$/i.test(node.tagName)) { append("\n", {}); return; }
      if (/^div$/i.test(node.tagName) && node.previousSibling &&
          (!runs.length || !/\n$/.test(runs[runs.length - 1].text))) append("\n", {});
      var style = Object.assign({}, inherited || {});
      var tag = String(node.tagName || "").toLowerCase();
      if (tag === "b" || tag === "strong") style.fontWeight = "bold";
      if (tag === "i" || tag === "em") style.fontStyle = "italic";
      if (tag === "u") style.textDecoration = "underline";
      if (tag === "sup") style.baselineShift = "super";
      if (tag === "sub") style.baselineShift = "sub";
      if (node.style) {
        if (node.style.fontWeight) style.fontWeight = node.style.fontWeight;
        if (node.style.fontStyle) style.fontStyle = node.style.fontStyle;
        if (node.style.textDecoration) style.textDecoration = node.style.textDecoration;
        if (node.style.fontFamily) style.fontFamily = node.style.fontFamily;
        if (node.style.fontSize) style.fontSize = node.style.fontSize;
        if (node.style.color) style.fill = node.style.color;
        if (node.style.verticalAlign === "super" || node.style.verticalAlign === "sub") style.baselineShift = node.style.verticalAlign;
      }
      Array.prototype.forEach.call(node.childNodes || [], function (child) { walk(child, style); });
      if (/^div$/i.test(node.tagName) && node.nextSibling &&
          (!runs.length || !/\n$/.test(runs[runs.length - 1].text))) append("\n", {});
    }
    Array.prototype.forEach.call(editor.childNodes || [], function (child) { walk(child, {}); });
    return runs;
  }

  function syncRichEditorToSvg(editor, textEl) {
    if (!editor || !textEl || !textEl.parentNode) return false;
    var runs = richEditorRuns(editor);
    var x = textEl.getAttribute("x") || "0";
    var baseSize = getFontSize(textEl);
    var pendingLineBreaks = 0;
    while (textEl.firstChild) textEl.removeChild(textEl.firstChild);
    runs.forEach(function (run) {
      var pieces = run.text.split("\n");
      pieces.forEach(function (piece, index) {
        if (index) pendingLineBreaks += 1;
        if (!piece) return;
        var tspan = svgEl("tspan");
        if (pendingLineBreaks > 0) {
          tspan.setAttribute("x", x);
          tspan.setAttribute("dy", String(baseSize * 1.2 * pendingLineBreaks));
          pendingLineBreaks = 0;
        }
        if (run.style.fontWeight) tspan.setAttribute("font-weight", run.style.fontWeight);
        if (run.style.fontStyle) tspan.setAttribute("font-style", run.style.fontStyle);
        if (run.style.textDecoration) tspan.setAttribute("text-decoration", run.style.textDecoration);
        if (run.style.fontFamily) tspan.setAttribute("font-family", run.style.fontFamily);
        if (run.style.fontSize) tspan.setAttribute("font-size", run.style.fontSize);
        if (run.style.fill) tspan.setAttribute("fill", run.style.fill);
        if (run.style.baselineShift) {
          tspan.setAttribute("baseline-shift", run.style.baselineShift);
          tspan.setAttribute("data-dava-script", run.style.baselineShift);
          tspan.setAttribute("font-size", String(baseSize * 0.65));
        }
        tspan.textContent = piece;
        textEl.appendChild(tspan);
      });
    });
    textEl.setAttribute("data-dava-rich-html", editor.innerHTML);
    var logicalText = String(editor.innerText || editor.textContent || "").replace(/\r\n?/g, "\n");
    if (logicalText.indexOf("\n") !== -1) {
      textEl.setAttribute("data-dava-text-value", logicalText);
      textEl.setAttribute("data-dava-multiline-text", logicalText);
    } else {
      textEl.removeAttribute("data-dava-text-value");
      textEl.removeAttribute("data-dava-multiline-text");
    }
    notifyChanged([textEl]);
    return true;
  }

  function richHtmlFromSvg(textEl) {
    var storedHtml = textEl.getAttribute("data-dava-rich-html");
    if (storedHtml !== null) return storedHtml;
    var spans = Array.prototype.slice.call(textEl.querySelectorAll(":scope > tspan"));
    if (!spans.length) return safeText(textEl.textContent);
    var holder = document.createElement("div");
    spans.forEach(function (node) {
      var span = document.createElement("span");
      span.textContent = node.textContent || "";
      var script = node.getAttribute("data-dava-script") || node.getAttribute("baseline-shift");
      if (script === "super" || script === "sub") span.style.verticalAlign = script;
      ["font-weight", "font-style", "text-decoration", "font-family", "font-size", "fill"].forEach(function (name) {
        var value = node.getAttribute(name);
        if (!value) return;
        var property = name === "fill" ? "color" : name.replace(/-([a-z])/g, function (_, letter) { return letter.toUpperCase(); });
        span.style[property] = value;
      });
      holder.appendChild(span);
    });
    return holder.innerHTML;
  }

  function editRichSvgText(textEl) {
    var rect = textEl.getBoundingClientRect();
    var computed = window.getComputedStyle(textEl);
    var editor = document.createElement("div");
    editor.className = "dava-area-text-editor dava-svg-rich-editor";
    editor.contentEditable = "true";
    editor.innerHTML = richHtmlFromSvg(textEl);
    editor.style.left = Math.max(0, rect.left - 3) + "px";
    editor.style.top = Math.max(0, rect.top - 3) + "px";
    editor.style.minWidth = Math.max(48, rect.width + 8) + "px";
    editor.style.minHeight = Math.max(24, rect.height + 8) + "px";
    editor.style.fontFamily = textEl.getAttribute("font-family") || computed.fontFamily || defaultFontFamily();
    editor.style.fontSize = getFontSize(textEl) + "px";
    editor.style.color = /^(none|transparent)$/i.test(computed.fill || "") ? "#000" : computed.fill;
    var closed = false;
    var savedRange = null;
    function saveRange() {
      var selection = window.getSelection && window.getSelection();
      if (selection && selection.rangeCount && editor.contains(selection.anchorNode)) savedRange = selection.getRangeAt(0).cloneRange();
    }
    function applyCommand(command, value) {
      if (closed) return false;
      editor.focus();
      var selection = window.getSelection && window.getSelection();
      if (selection && savedRange) {
        selection.removeAllRanges();
        selection.addRange(savedRange);
      }
      try { document.execCommand("styleWithCSS", false, true); } catch (error) {}
      var ok = false;
      try { ok = document.execCommand(command, false, value === undefined ? null : value); } catch (error) {}
      saveRange();
      syncRichEditorToSvg(editor, textEl);
      return ok;
    }
    function close(commit) {
      if (closed) return;
      closed = true;
      if (commit) syncRichEditorToSvg(editor, textEl);
      if (editor.parentNode) editor.remove();
      window.__davaActiveRichTextEditor = null;
      window.__davaApplyRichTextCommand = null;
    }
    window.__davaActiveRichTextEditor = { editor: editor, element: textEl, sync: function () { syncRichEditorToSvg(editor, textEl); }, close: close };
    window.__davaApplyRichTextCommand = applyCommand;
    editor.addEventListener("input", function () { syncRichEditorToSvg(editor, textEl); });
    ["mouseup", "keyup", "select"].forEach(function (name) { editor.addEventListener(name, saveRange); });
    editor.addEventListener("keydown", function (event) {
      if (event.key === "Escape") { event.preventDefault(); close(false); }
      if (event.key === "Enter" && event.ctrlKey) { event.preventDefault(); close(true); }
    });
    document.body.appendChild(editor);
    editor.focus();
    saveRange();
    return true;
  }

  function editSvgText(textEl) {
    textEl = editableSvgText(textEl);
    if (!textEl) return false;
    return editRichSvgText(textEl);
    var canvas = getSvgCanvas();
    try {
      if (canvas && typeof canvas.selectOnly === "function") canvas.selectOnly([textEl], true);
    } catch (error) {}
    var rect = textEl.getBoundingClientRect();
    var computed = window.getComputedStyle ? window.getComputedStyle(textEl) : null;
    var area = document.createElement("textarea");
    area.className = "dava-area-text-editor dava-svg-text-editor";
    area.value = svgTextValue(textEl);
    area.setAttribute("wrap", "off");
    area.style.left = Math.max(0, rect.left - 3) + "px";
    area.style.top = Math.max(0, rect.top - 3) + "px";
    area.style.width = Math.max(48, rect.width + 8) + "px";
    area.style.height = Math.max(24, rect.height + 8) + "px";
    area.style.fontFamily = textEl.getAttribute("font-family") || computed && computed.fontFamily || defaultFontFamily();
    area.style.fontSize = getFontSize(textEl) + "px";
    area.style.fontWeight = textEl.getAttribute("font-weight") || computed && computed.fontWeight || "normal";
    area.style.fontStyle = textEl.getAttribute("font-style") || computed && computed.fontStyle || "normal";
    var textColor = textEl.getAttribute("fill") || computed && computed.fill || "#000000";
    if (!textColor || /^(none|transparent)$/i.test(String(textColor).trim()) ||
        /^rgba?\([^)]*,\s*0\s*\)$/i.test(String(textColor).trim())) textColor = "#000000";
    area.style.color = textColor;
    area.style.lineHeight = "1.2";
    area.classList.toggle("dava-svg-text-editor-multiline", area.value.indexOf("\n") !== -1);
    area.dataset.svgTextEditor = "1";
    var original = area.value;
    var cancelled = false;
    window.__davaActiveSvgTextEditor = {
      element: textEl, input: area,
      selectionStart: area.selectionStart, selectionEnd: area.selectionEnd
    };
    function rememberSelection() {
      var active = window.__davaActiveSvgTextEditor;
      if (!active || active.input !== area) return;
      if (typeof area.selectionStart === "number" && typeof area.selectionEnd === "number") {
        active.selectionStart = area.selectionStart;
        active.selectionEnd = area.selectionEnd;
        window.__davaTextSelectionSnapshot = {
          element: textEl,
          start: area.selectionStart,
          end: area.selectionEnd,
          text: String(area.value || "")
        };
      }
    }
    window.__davaSvgTextEditorRefresh = function () {
      if (window.__davaActiveSvgTextEditor &&
          window.__davaActiveSvgTextEditor.element === textEl && area.parentNode) {
        var active = window.__davaActiveSvgTextEditor;
        var start = active.selectionStart;
        var end = active.selectionEnd;
        area.value = svgTextValue(textEl);
        area.setSelectionRange(Math.min(start, area.value.length), Math.min(end, area.value.length));
      }
    };
    window.__davaFocusSvgTextEditor = function () {
      if (area.parentNode) area.focus();
    };
    window.__davaPrepareSvgTextFormat = function () {
      // Synchronize edited characters before a rich-text operation. This is
      // intentionally non-closing; the bridge applies tspans immediately
      // afterwards using the saved logical selection range.
      if (area.value !== svgTextValue(textEl)) commitSvgTextEdit(textEl, area.value, original);
    };
    window.__davaFinishSvgTextFormat = function () {
      // A textarea cannot render mixed baselines/fonts. Once a local rich-text
      // operation has produced SVG tspans, remove the plain overlay without
      // committing it again (which would destroy those tspans).
      cleanup();
    };
    function cleanup() {
      if (window.__davaActiveSvgTextEditor && window.__davaActiveSvgTextEditor.element === textEl) {
        window.__davaActiveSvgTextEditor = null;
        window.__davaSvgTextEditorRefresh = null;
        window.__davaCommitSvgTextEditor = null;
        window.__davaFocusSvgTextEditor = null;
        window.__davaTextSelectionSnapshot = null;
        window.__davaPrepareSvgTextFormat = null;
        window.__davaFinishSvgTextFormat = null;
      }
      if (area.parentNode) area.parentNode.removeChild(area);
    }
    function commit(close) {
      if (!cancelled) commitSvgTextEdit(textEl, area.value, original);
      if (close !== false) cleanup();
    }
    window.__davaCommitSvgTextEditor = function () { commit(true); };
    area.addEventListener("keydown", function (event) {
      window.setTimeout(rememberSelection, 0);
      if (event.key === "Escape") {
        cancelled = true;
        cleanup();
      } else if (event.key === "Enter" && event.ctrlKey) {
        event.preventDefault();
        commit();
      }
    });
    area.addEventListener("blur", function (event) {
      // Keep the editor alive while a formatting toolbar button is clicked.
      // This preserves the textarea range for superscript/subscript and other
      // SVG-Edit text actions; clicking elsewhere still commits and exits.
      window.setTimeout(function () {
        var active = document.activeElement;
        var toolbar = active && (active.closest && active.closest(
          "#tools_top,#tools_left,#tools_bottom,.text_panel,#dava_text_style_tools,#dava_paragraph_tools"
        ));
        if (!toolbar && !window.__davaTextToolbarPending) commit(true);
        window.__davaTextToolbarPending = false;
      }, 0);
    });
    document.body.appendChild(area);
    area.focus();
    // Preserve a normal text-box interaction: the first click establishes the
    // caret near the clicked location, while subsequent mouse drags are handled
    // entirely by the textarea's native selection engine.
    area.setSelectionRange(area.value.length, area.value.length);
    area.addEventListener("mousedown", function () {
      area.focus();
    }, false);
    ["select", "mouseup", "keyup", "input"].forEach(function (name) {
      area.addEventListener(name, rememberSelection, false);
    });
    return true;
  }

  function editAreaText(group) {
    group = findAreaTextRoot(group);
    if (!group) return false;
    var textEl = getTextElement(group);
    if (!textEl) return false;
    var rect = group.getBoundingClientRect();
    var area = document.createElement("textarea");
    area.className = "dava-area-text-editor";
    area.value = getRawText(group);
    area.setAttribute("wrap", "off");
    area.style.left = rect.left + "px";
    area.style.top = rect.top + "px";
    area.style.width = Math.max(40, rect.width) + "px";
    area.style.height = Math.max(24, rect.height) + "px";
    area.style.fontFamily = textEl.getAttribute("font-family") || window.getComputedStyle(textEl).fontFamily;
    area.style.fontSize = getFontSize(textEl) + "px";
    area.style.lineHeight = String(getLineHeight(group, textEl));
    area.style.color = "#000000";

    var cancelled = false;
    window.__davaActiveSvgTextEditor = {
      element: textEl, input: area, areaGroup: group,
      selectionStart: area.selectionStart, selectionEnd: area.selectionEnd
    };
    function rememberAreaSelection() {
      var active = window.__davaActiveSvgTextEditor;
      if (!active || active.input !== area) return;
      if (typeof area.selectionStart === "number" && typeof area.selectionEnd === "number") {
        active.selectionStart = area.selectionStart;
        active.selectionEnd = area.selectionEnd;
        window.__davaTextSelectionSnapshot = {
          element: textEl,
          start: area.selectionStart,
          end: area.selectionEnd,
          text: String(area.value || "")
        };
      }
    }
    window.__davaSvgTextEditorRefresh = function () {
      if (window.__davaActiveSvgTextEditor && window.__davaActiveSvgTextEditor.element === textEl && area.parentNode) {
        var active = window.__davaActiveSvgTextEditor;
        var start = active.selectionStart, end = active.selectionEnd;
        area.value = getRawText(group);
        area.setSelectionRange(Math.min(start, area.value.length), Math.min(end, area.value.length));
      }
    };
    window.__davaFocusSvgTextEditor = function () { if (area.parentNode) area.focus(); };
    window.__davaPrepareSvgTextFormat = function () {
      if (area.value !== getRawText(group)) commitAreaTextEdit(group, area.value);
    };
    window.__davaFinishSvgTextFormat = function () { cleanup(); };
    function cleanup() {
      group.classList.remove("is-editing");
      if (window.__davaActiveSvgTextEditor && window.__davaActiveSvgTextEditor.element === textEl) {
        window.__davaActiveSvgTextEditor = null;
        window.__davaSvgTextEditorRefresh = null;
        window.__davaCommitSvgTextEditor = null;
        window.__davaFocusSvgTextEditor = null;
        window.__davaTextSelectionSnapshot = null;
        window.__davaPrepareSvgTextFormat = null;
        window.__davaFinishSvgTextFormat = null;
      }
      if (area.parentNode) area.parentNode.removeChild(area);
    }
    function commit() {
      if (cancelled) return;
      commitAreaTextEdit(group, area.value);
      cleanup();
    }
    window.__davaCommitSvgTextEditor = function () { commit(); };
    area.addEventListener("keydown", function (event) {
      window.setTimeout(rememberAreaSelection, 0);
      if (event.key === "Escape") {
        cancelled = true;
        cleanup();
      } else if (event.key === "Enter" && event.ctrlKey) {
        event.preventDefault();
        commit();
      }
    });
    area.addEventListener("blur", function () {
      window.setTimeout(function () {
        var active = document.activeElement;
        var toolbar = active && active.closest && active.closest(
          "#tools_top,#tools_left,#tools_bottom,.text_panel,#dava_text_style_tools,#dava_paragraph_tools"
        );
        if (!toolbar && !window.__davaTextToolbarPending) commit();
        window.__davaTextToolbarPending = false;
      }, 0);
    });
    ["select", "mouseup", "keyup", "input"].forEach(function (name) {
      area.addEventListener(name, rememberAreaSelection, false);
    });
    group.classList.add("is-editing");
    document.body.appendChild(area);
    area.focus();
    area.select();
    return true;
  }

  function readMatrixFromTransform(transform) {
    var match = safeText(transform).match(/matrix\(\s*([-+0-9.eE]+)[,\s]+([-+0-9.eE]+)[,\s]+([-+0-9.eE]+)[,\s]+([-+0-9.eE]+)[,\s]+([-+0-9.eE]+)[,\s]+([-+0-9.eE]+)\s*\)/);
    if (!match) return null;
    return {
      a: parseFloat(match[1]),
      b: parseFloat(match[2]),
      c: parseFloat(match[3]),
      d: parseFloat(match[4]),
      e: parseFloat(match[5]),
      f: parseFloat(match[6])
    };
  }

  function scaleFromTransform(transform) {
    transform = safeText(transform);
    var matrix = readMatrixFromTransform(transform);
    if (matrix) {
      return {
        scaleX: Math.sqrt(matrix.a * matrix.a + matrix.b * matrix.b) || 1,
        scaleY: Math.sqrt(matrix.c * matrix.c + matrix.d * matrix.d) || 1,
        translate: { x: matrix.e || 0, y: matrix.f || 0 },
        source: "matrix"
      };
    }
    var match = transform.match(/scale\(\s*([-+0-9.eE]+)(?:[,\s]+([-+0-9.eE]+))?\s*\)/);
    if (!match) return null;
    return {
      scaleX: asNumber(match[1], 1),
      scaleY: asNumber(match[2], asNumber(match[1], 1)),
      translate: null,
      source: "scale"
    };
  }

  function stripScaleFromTransform(transform, fallbackTranslate) {
    transform = safeText(transform);
    var rotate = transform.match(/rotate\([^)]+\)/g) || [];
    var translate = transform.match(/translate\([^)]+\)/g) || [];
    if (!translate.length && fallbackTranslate) {
      translate.push("translate(" + fallbackTranslate.x + " " + fallbackTranslate.y + ")");
    }
    var kept = translate.concat(rotate).join(" ").trim();
    return kept;
  }

  function normalizeAreaTextTransform(group, options) {
    group = findAreaTextRoot(group);
    if (!group || normalizing) return false;
    var transform = group.getAttribute("transform") || "";
    var scale = scaleFromTransform(transform);
    if (!scale) {
      layoutAreaText(group);
      return false;
    }
    if (Math.abs(scale.scaleX - 1) < 0.001 && Math.abs(scale.scaleY - 1) < 0.001) return false;
    normalizing = true;
    var width = asNumber(group.getAttribute("data-textbox-width"), activeResize && activeResize.width || 240);
    var height = asNumber(group.getAttribute("data-textbox-height"), activeResize && activeResize.height || 120);
    if (activeResize && activeResize.group === group) {
      width = activeResize.width;
      height = activeResize.height;
    }
    var oldTransform = transform;
    group.setAttribute("transform", stripScaleFromTransform(transform, scale.translate));
    resizeAreaText(group, width * scale.scaleX, height * scale.scaleY, {
      scaleFont: options && options.scaleFont === true,
      scaleFactor: Math.sqrt(Math.abs(scale.scaleX * scale.scaleY))
    });
    addChangeHistory(group, { transform: oldTransform }, "Resize DAVA area text");
    normalizing = false;
    return true;
  }

  function selectedAreaTextRoot() {
    var canvas = getSvgCanvas();
    var selected = getSelectedElements(canvas);
    for (var i = 0; i < selected.length; i += 1) {
      var root = findAreaTextRoot(selected[i]);
      if (root) return root;
    }
    return null;
  }

  function captureResizeStart() {
    var group = selectedAreaTextRoot();
    if (!group) {
      activeResize = null;
      return;
    }
    activeResize = {
      group: group,
      width: asNumber(group.getAttribute("data-textbox-width"), 240),
      height: asNumber(group.getAttribute("data-textbox-height"), 120),
      transform: group.getAttribute("transform") || ""
    };
  }

  function finishResize(event) {
    var group = activeResize && activeResize.group || selectedAreaTextRoot();
    if (!group) return;
    window.setTimeout(function () {
      normalizeAreaTextTransform(group, { scaleFont: !!(event && event.shiftKey) });
      activeResize = null;
    }, 0);
  }

  function observeAreaTextTransforms() {
    if (observer) return;
    observer = new MutationObserver(function (mutations) {
      if (normalizing || activeResize) return;
      var changed = null;
      mutations.some(function (mutation) {
        changed = findAreaTextRoot(mutation.target);
        return !!changed;
      });
      if (!changed) return;
      window.clearTimeout(observerTimer);
      observerTimer = window.setTimeout(function () {
        normalizeAreaTextTransform(changed, { scaleFont: false });
      }, 120);
    });
    var root = getSvgRoot() || document.body;
    observer.observe(root, {
      attributes: true,
      attributeFilter: ["transform"],
      childList: true,
      subtree: true
    });
  }

  function installEvents() {
    document.addEventListener("mousedown", captureResizeStart, true);
    document.addEventListener("pointerdown", captureResizeStart, true);
    document.addEventListener("mouseup", finishResize, true);
    document.addEventListener("pointerup", finishResize, true);
    document.addEventListener("mousedown", function (event) {
      var active = window.__davaActiveRichTextEditor;
      if (!active || !active.editor) return;
      if (active.editor.contains(event.target)) return;
      if (event.target && event.target.closest && event.target.closest(
        "#tools_top,#tools_left,#tools_bottom,.text_panel,#dava_text_style_tools,#dava_paragraph_tools"
      )) return;
      active.close(true);
    }, true);
    document.addEventListener("mousedown", function (event) {
      if (!window.__davaActiveRichTextEditor || !window.__davaApplyRichTextCommand) return;
      var button = event.target && event.target.closest && event.target.closest(
        "#tool_bold,#tool_italic,#tool_text_decoration_underline"
      );
      if (!button) return;
      var commands = {
        tool_bold: "bold", tool_italic: "italic",
        tool_text_decoration_underline: "underline"
      };
      event.preventDefault();
      event.stopImmediatePropagation();
      window.__davaRichToolbarClickGuard = button.id;
      window.__davaApplyRichTextCommand(commands[button.id]);
    }, true);
    document.addEventListener("click", function (event) {
      if (!window.__davaRichToolbarClickGuard) return;
      var button = event.target && event.target.closest && event.target.closest("#" + window.__davaRichToolbarClickGuard);
      if (!button) return;
      window.__davaRichToolbarClickGuard = null;
      event.preventDefault();
      event.stopImmediatePropagation();
    }, true);
    document.addEventListener("change", function (event) {
      if (!window.__davaActiveRichTextEditor || !window.__davaApplyRichTextCommand) return;
      var control = event.target && event.target.closest && event.target.closest("#tool_font_family,#font_size");
      if (!control) return;
      var value = control.value || control.getAttribute("value") || "";
      if (!value && control.shadowRoot) {
        var inner = control.shadowRoot.querySelector("input,select");
        value = inner && inner.value || "";
      }
      if (!value) return;
      event.stopImmediatePropagation();
      window.__davaApplyRichTextCommand(control.id === "tool_font_family" ? "fontName" : "fontSize", value);
    }, true);
    document.addEventListener("mousedown", function (event) {
      var active = window.__davaActiveSvgTextEditor;
      if (!active || !active.input || !active.input.parentNode) return;
      var toolbar = event.target && event.target.closest && event.target.closest(
        "#tools_top,#tools_left,#tools_bottom,.text_panel,#dava_text_style_tools,#dava_paragraph_tools"
      );
      window.__davaTextToolbarPending = !!toolbar;
      if (toolbar && active.input.selectionStart !== undefined) {
        active.selectionStart = active.input.selectionStart;
        active.selectionEnd = active.input.selectionEnd;
        window.__davaTextSelectionSnapshot = {
          element: active.element,
          start: active.selectionStart,
          end: active.selectionEnd,
          text: String(active.input.value || "")
        };
      }
    }, true);
    document.addEventListener("mousedown", function (event) {
      var active = window.__davaActiveSvgTextEditor;
      if (!active || !active.input || !active.input.parentNode) return;
      if (event.target === active.input || (event.target.closest && event.target.closest(".dava-svg-text-editor"))) return;
      var toolbar = event.target && event.target.closest && event.target.closest(
        "#tools_top,#tools_left,#tools_bottom,.text_panel,#dava_text_style_tools,#dava_paragraph_tools"
      );
      if (toolbar) return;
      if (typeof window.__davaCommitSvgTextEditor === "function") {
        window.__davaCommitSvgTextEditor();
      }
    }, true);
    document.addEventListener("dblclick", function (event) {
      var group = findAreaTextRoot(event.target);
      if (group) {
        event.preventDefault();
        event.stopPropagation();
        editAreaText(group);
        return;
      }
      var textEl = editableSvgText(event.target) || svgTextAtPoint(event.clientX, event.clientY);
      if (!textEl || textEl.closest(".dava-area-text-editor")) return;
      event.preventDefault();
      // This must be the sole double-click owner. If the native SVG-Edit
      // handler also runs it enters its own text mode and immediately steals
      // the drag selection from our textarea.
      event.stopImmediatePropagation();
      editSvgText(textEl);
    }, true);
    observeAreaTextTransforms();
  }

  window.DAVA_SVGEDIT_TEXTBOX_API = {
    createAreaText: createAreaText,
    convertSelectedTextToAreaText: convertSelectedTextToAreaText,
    isAreaTextElement: isAreaTextElement,
    findAreaTextRoot: findAreaTextRoot,
    layoutAreaText: layoutAreaText,
    resizeAreaText: resizeAreaText,
    editAreaText: editAreaText,
    editSvgText: editSvgText,
    commitSvgTextEdit: commitSvgTextEdit,
    commitAreaTextEdit: commitAreaTextEdit,
    getRawText: getRawText,
    setRawText: setRawText,
    measureTextWidth: measureTextWidth
  };

  waitForSvgCanvas(function () {
    installEvents();
    Array.prototype.forEach.call(document.querySelectorAll(TEXTBOX_SELECTOR), layoutAreaText);
  });
})();
