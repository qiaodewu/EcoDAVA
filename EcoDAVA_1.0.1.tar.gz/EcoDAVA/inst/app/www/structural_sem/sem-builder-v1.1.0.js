(function(){
  "use strict";
  var states = new Map();
  function escapeHtml(value){var div=document.createElement("div");div.textContent=String(value==null?"":value);return div.innerHTML;}
  function escapeXml(value){return String(value==null?"":value).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;").replace(/'/g,"&apos;");}
  function downloadUri(uri,fileName){var link=document.createElement("a");link.href=uri;link.download=fileName;link.style.display="none";document.body.appendChild(link);link.click();link.remove();}
  function debounce(fn, wait){
    var timer;
    function debounced(){var args=arguments;clearTimeout(timer);timer=setTimeout(function(){timer=null;fn.apply(null,args);},wait);}
    debounced.cancel=function(){clearTimeout(timer);timer=null;};
    return debounced;
  }
  function button(action,label,title){ return "<button type='button' data-action='"+action+"' data-tooltip='"+escapeHtml(title)+"'>"+label+"</button>"; }
  function toolbar(){ return [
    button("select","↖","Select"),button("add-observed","O","Add observed variables"),button("add-latent","L","Add latent variables").replace("<button ","<button data-latent-toolbar "),
    button("add-composite","C","Add composite construct").replace("<button ","<button data-composite-toolbar "),button("add-note","T","Add comment"),button("directed","→","Add one-way path"),
    button("covariance","↔","Add two-way covariance"),button("delete","⌫","Delete"),button("undo","↶","Undo"),button("redo","↷","Redo"),
    button("copy","⧉","Copy"),button("paste","▣","Paste"),button("lock","🔒","Lock or unlock"),button("layout","▦","Causal hierarchy automatic layout"),
    button("align-left","⇤","left aligned"),button("align-right","⇥","right aligned"),button("align-top","↥","Top alignment"),button("align-bottom","↧","Bottom alignment"),
    button("align-h","═","Center horizontally"),button("align-v","║","Center vertically"),button("distribute-h","⋯","Horizontal uniform distribution"),button("distribute-v","⋮","Vertically uniform distribution"),
    button("zoom-in","+","Enlarge"),button("zoom-out","−","Zoom out"),button("actual-size","1:1","Actual size"),
    button("fit","□","Fit to canvas"),button("toggle-grid","#","Show or hide the grid"),button("clear-selection","×","Clear selection")].join(""); }
  function colorControl(key,label,title,color){return "<label class='dava-sem-toolbar-color' data-tooltip='"+escapeHtml(title)+"'><span>"+label+"</span><input type='color' data-toolbar-color='"+key+"' value='"+color+"'></label>";}
  function resultToolbar(){ return [
    button("select","↖","Select object"),button("add-note","T","Add text"),button("delete","⌫","Delete object"),
    button("undo","↶","Undo"),button("redo","↷","Redo"),button("copy","⧉","Copy"),button("paste","▣","Paste"),button("lock","🔒","Lock or unlock"),
    button("text-bold","B","bold"),button("text-italic","I","italics"),button("font-increase","A+","Increase text"),button("font-decrease","A−","Reduce text"),
    button("shape-rectangle","□","Rectangle"),button("shape-ellipse","○","Ellipse"),button("shape-diamond","◇","Diamond"),
    button("line-solid","━","solid line"),button("line-dashed","┄","dashed line"),
    colorControl("fill_color","Fill in","fill color","#ffffff"),colorControl("border_color","line","Border or path color","#345b6b"),
    button("align-left","⇤","left aligned"),button("align-right","⇥","right aligned"),button("align-top","↥","Top alignment"),button("align-bottom","↧","Bottom alignment"),
    button("align-h","═","Center horizontally"),button("align-v","║","Center vertically"),button("distribute-h","⋯","Horizontal uniform distribution"),button("distribute-v","⋮","Vertically uniform distribution"),
    button("zoom-in","+","Enlarge"),button("zoom-out","−","Zoom out"),button("actual-size","1:1","Actual size"),button("fit","□","Fit to canvas"),
    button("toggle-grid","#","Show or hide the grid"),button("clear-selection","×","Clear selection")].join(""); }
  function resources(variables){return "<div class='dava-sem-resources'><div class='dava-sem-variable-browser'><div class='dava-sem-pane-title'>variable</div><input class='dava-sem-search' type='search' placeholder='Search variables'><div class='dava-sem-variable-scroll'><div class='dava-sem-resource-list'>"+variables.map(function(v){return "<button type='button' draggable='true' data-variable='"+escapeHtml(v)+"' title='Drag to canvas to create observation variables'><span>▣</span><span data-dava-i18n-ignore>"+escapeHtml(v)+"</span></button>";}).join("")+"</div></div></div><div class='dava-sem-element-browser'><div class='dava-sem-pane-title'>Model Elements</div><div class='dava-sem-element-list'><button draggable='true' data-node-type='observed_variable'>Observed variables</button><button draggable='true' data-node-type='latent_variable' data-latent-tool>Latent variables</button><button draggable='true' data-node-type='composite_construct' data-composite-tool>Composite construct</button><button draggable='true' data-node-type='annotation'>Comments</button></div></div></div>";}
  function templateManager(templates){var options=(templates||[]).map(function(row){return"<option value='"+escapeHtml(row.id)+"'>"+escapeHtml(row.label)+"</option>";}).join("");return "<div class='dava-sem-template-manager'><div class='dava-sem-compact-label'>Priori model template</div><select class='dava-sem-template-select' data-template-select>"+options+"</select><div class='dava-sem-template-actions'><button type='button' data-template-action='new_model'>Create new blank</button><button type='button' data-template-action='load_template'>New from template</button><button type='button' data-template-action='save_revision'>Save candidate</button></div></div>";}
  function nodeDefaults(type,index){ return {id:"n"+Date.now()+"_"+index,label:type==="latent_variable"?"Latent":type==="composite_construct"?"Composite":type==="annotation"?"Note":"Observed",node_type:type,variable_name:"",construct_name:"",indicator_variables:[],measurement_mode:type==="composite_construct"?"formative":"reflective",role:"exogenous",endogenous:false,observed:type==="observed_variable",latent:type==="latent_variable",composite:type==="composite_construct",error_term:false,width:140,height:58,locked:false,color_role:type,display_order:index,r_squared_display:false,notes:"",shape:type==="latent_variable"?"ellipse":"round-rectangle",fill_color:"#ffffff",fill_opacity:1,border_color:"#345b6b",border_width:2,border_style:"solid",corner_radius:8,text_color:"#17242b",font_size:13,font_weight:"normal",font_style:"normal",text_script:"normal",text_wrap:"wrap",line_height:1.2,text_align:"center",text_runs:[]}; }
  function edgeDefaults(source,target,type,index){ return {id:"e"+Date.now()+"_"+index,source:source,target:target,edge_type:type,direction:type==="directed_path"?"forward":"bidirectional",label:"",parameter_name:"",fixed_value:null,starting_value:null,free:true,optional:false,locked:false,active:true,residual_covariance:type==="covariance",measurement_loading:false,structural_path:type==="directed_path",moderation_path:false,style:"",notes:"",line_color:"#567483",line_width:2,line_style:type==="covariance"?"dashed":"solid",curve_style:"bezier",arrow_scale:1,label_font_size:11,label_color:"#17242b",label_offset_x:0,label_offset_y:0,bendPointPositions:[],controlPointPositions:[]}; }
  var TEXT_STYLE_KEYS=["font_size","font_weight","font_style","text_color","text_script"];
  function baseTextStyle(data){return{font_size:Number(data.font_size||13),font_weight:data.font_weight||"normal",font_style:data.font_style||"normal",text_color:data.text_color||"#17242b",text_script:data.text_script||"normal"};}
  function normalizeTextStyle(style,fallback){style=style||{};fallback=fallback||baseTextStyle({});var size=Number(style.font_size);return{font_size:Number.isFinite(size)?size:fallback.font_size,font_weight:style.font_weight||fallback.font_weight,font_style:style.font_style||fallback.font_style,text_color:style.text_color||fallback.text_color,text_script:["normal","super","sub"].indexOf(style.text_script)>=0?style.text_script:fallback.text_script};}
  function sameTextStyle(left,right){return TEXT_STYLE_KEYS.every(function(key){return left[key]===right[key];});}
  function expandedRichText(data){
    var text=String(data.label==null?"":data.label),base=baseTextStyle(data),styles=Array.from({length:text.length},function(){return Object.assign({},base);}),runs=Array.isArray(data.text_runs)?data.text_runs:[];
    runs.forEach(function(run){var start=Math.max(0,Math.min(text.length,Number(run.start)||0)),end=Math.max(start,Math.min(text.length,Number(run.end)||0)),style=normalizeTextStyle(run,base);for(var index=start;index<end;index++)styles[index]=Object.assign({},style);});
    return{text:text,base:base,styles:styles};
  }
  function compressTextRuns(text,styles,base){
    var runs=[],start=0;
    while(start<text.length){var style=normalizeTextStyle(styles[start],base),end=start+1;while(end<text.length&&sameTextStyle(style,normalizeTextStyle(styles[end],base)))end++;if(!sameTextStyle(style,base))runs.push(Object.assign({start:start,end:end},style));start=end;}
    return runs;
  }
  function richSpanMarkup(text,style,selected,className,scale){
    if(!text)return"";var script=style.text_script||"normal",visibleSize=Number(style.font_size||13)*(script==="normal"?1:0.75)*Number(scale||1),offset=script==="super"?"-.38em":script==="sub"?".22em":"0";
    return "<span class='"+(className||"")+(selected?" is-editor-selection":"")+"' data-font-size='"+Number(style.font_size||13)+"' data-font-weight='"+escapeHtml(style.font_weight||"normal")+"' data-font-style='"+escapeHtml(style.font_style||"normal")+"' data-text-color='"+escapeHtml(style.text_color||"#17242b")+"' data-text-script='"+escapeHtml(script)+"' style='font-size:"+visibleSize+"px;font-weight:"+escapeHtml(style.font_weight||"normal")+";font-style:"+escapeHtml(style.font_style||"normal")+";color:"+escapeHtml(style.text_color||"#17242b")+";position:relative;top:"+offset+"'>"+escapeHtml(text)+"</span>";
  }
  function richTextMarkup(data,selection,className,scale){
    var model=expandedRichText(data),parts=[],start=0,selectedStart=selection?selection.start:-1,selectedEnd=selection?selection.end:-1;
    while(start<model.text.length){var style=model.styles[start]||model.base,isSelected=start>=selectedStart&&start<selectedEnd,end=start+1;while(end<model.text.length&&sameTextStyle(style,model.styles[end]||model.base)&&(end>=selectedStart&&end<selectedEnd)===isSelected)end++;parts.push(richSpanMarkup(model.text.slice(start,end),style,isSelected,className,scale));start=end;}
    return parts.join("");
  }
  function richSvgLines(data,maxWidth){
    var model=expandedRichText(data),wrap=(data.text_wrap||"wrap")==="wrap",lines=[[]],width=0,limit=Math.max(16,Number(maxWidth||120)-12);
    for(var index=0;index<model.text.length;index++){var character=model.text.charAt(index),style=model.styles[index]||model.base;if(character==="\n"){lines.push([]);width=0;continue;}var characterWidth=Number(style.font_size||13)*(/[\u2e80-\uffff]/.test(character)?1:0.58);if(wrap&&lines[lines.length-1].length&&width+characterWidth>limit){lines.push([]);width=0;}lines[lines.length-1].push({text:character,style:style});width+=characterWidth;}
    return{lines:lines,base:model.base};
  }
  function svgRichText(x,y,data,maxWidth,className){
    var layout=richSvgLines(data,maxWidth),lineHeight=Number(layout.base.font_size||13)*Number(data.line_height||1.2),startY=y-(layout.lines.length-1)*lineHeight/2,align=data.text_align||"center",anchor=align==="left"?"start":align==="right"?"end":"middle",textX=align==="left"?x-maxWidth/2+8:align==="right"?x+maxWidth/2-8:x,markup=[];
    layout.lines.forEach(function(line,lineIndex){var groups=[],start=0;while(start<line.length){var style=line[start].style,end=start+1;while(end<line.length&&sameTextStyle(style,line[end].style))end++;groups.push({text:line.slice(start,end).map(function(item){return item.text;}).join(""),style:style});start=end;}markup.push("<text class='"+className+"' x='"+textX+"' y='"+(startY+lineIndex*lineHeight)+"' text-anchor='"+anchor+"' dominant-baseline='middle' font-family='Arial, sans-serif'>"+groups.map(function(group){var style=group.style,script=style.text_script||"normal",shift=script==="super"?"super":script==="sub"?"sub":"baseline",size=Number(style.font_size||13)*(script==="normal"?1:0.75);return"<tspan fill='"+escapeXml(style.text_color)+"' font-size='"+size+"' font-weight='"+escapeXml(style.font_weight)+"' font-style='"+escapeXml(style.font_style)+"' baseline-shift='"+shift+"'>"+escapeXml(group.text)+"</tspan>";}).join("")+"</text>");});
    return markup.join("");
  }
  function initialize(root){
    var id=root.id,inputId=root.dataset.inputId,variables=JSON.parse(root.dataset.variables||"[]"),templates=JSON.parse(root.dataset.templates||"[]"),resultEditor=root.classList.contains("dava-sem-result-builder");
    if(states.has(id)){ try{states.get(id).destroy();}catch(e){} states.delete(id); }
    var documentControls=root.querySelector("[data-sem-document-controls]"),localControls=root.querySelector("[data-sem-local-controls]");
    if(localControls){localControls.remove();}
    if(documentControls){documentControls.remove();}
    var documentMarkup=resultEditor?"<div class='dava-sem-document-host' hidden></div>":"<div class='dava-sem-document-host'><div class='dava-sem-document-tabs' data-document-tabs hidden><button type='button' data-document-tab='local' class='active'>Partial model</button><button type='button' data-document-tab='manager'>Model management</button></div><section class='dava-sem-local-model-host' data-local-model-host hidden></section><section class='dava-sem-model-manager-host'>"+templateManager(templates)+"</section></div>";
    root.innerHTML="<div class='dava-sem-toolbar'>"+(resultEditor?resultToolbar():toolbar())+"</div>"+(resultEditor?"":resources(variables))+"<div class='dava-sem-stage'><div class='dava-sem-document-state' data-document-state></div><div class='dava-sem-canvas' tabindex='0'></div>"+(resultEditor?"<div class='dava-sem-rich-label-layer' data-rich-label-layer></div>":"")+"<div class='dava-sem-context-menu' data-context-menu hidden></div></div><div class='dava-sem-properties'>"+documentMarkup+"<div class='dava-sem-property-section'><div class='dava-sem-pane-title'>Graphics and text properties</div><div data-properties><p class='dava-sem-status'>Please select the object</p></div></div></div><div class='dava-sem-footer'><span data-mode-status>Select</span><span data-selection-status>0 items selected</span><span data-model-status>node 0 · path 0</span><label>Zoom <input data-zoom type='range' min='25' max='200' value='100'> <span data-zoom-label>100%</span></label></div><div class='dava-sem-tooltip' data-toolbar-tooltip hidden></div>";
    if(window.DavaI18n)window.DavaI18n.translateTree(root);
    root.querySelectorAll(".dava-sem-stage [title]").forEach(function(element){element.removeAttribute("title");});
    root.addEventListener("contextmenu",function(event){
      if(event.target.closest(".dava-sem-stage"))event.preventDefault();
    },true);
    var documentHost=root.querySelector(".dava-sem-document-host"),documentTabs=root.querySelector("[data-document-tabs]"),localHost=root.querySelector("[data-local-model-host]"),modelManagerHost=root.querySelector(".dava-sem-model-manager-host");
    if(localControls&&localHost){localHost.appendChild(localControls);}
    if(documentControls&&modelManagerHost){modelManagerHost.appendChild(documentControls);}
    function activateDocumentTab(name){var local=name==="local";if(localHost)localHost.hidden=!local;if(modelManagerHost)modelManagerHost.hidden=local;documentHost.querySelectorAll("[data-document-tab]").forEach(function(button){button.classList.toggle("active",button.dataset.documentTab===name);});}
    if(documentTabs)documentTabs.addEventListener("click",function(event){var button=event.target.closest("[data-document-tab]");if(button)activateDocumentTab(button.dataset.documentTab);});
    var canvas=root.querySelector(".dava-sem-canvas"),prop=root.querySelector("[data-properties]"),documentHost=root.querySelector(".dava-sem-document-host"),propertySection=root.querySelector(".dava-sem-property-section"),richLabelLayer=root.querySelector("[data-rich-label-layer]"),mode="select",clipboard=null,currentSpec=null,gridVisible=true,hydrating=false,savedTextSelection=null;
    var cy=cytoscape({container:canvas,elements:[],layout:{name:"preset"},style:[
      {selector:"node",style:{"shape":"data(shape)","label":resultEditor?"":"data(label)","text-valign":"center","text-halign":"center","text-wrap":"wrap","text-max-width":120,"color":"data(text_color)","background-color":"data(fill_color)","background-opacity":"data(fill_opacity)","border-color":"data(border_color)","border-width":"data(border_width)","border-style":"data(border_style)","corner-radius":"data(corner_radius)","width":"data(width)","height":"data(height)","font-size":"data(font_size)","font-weight":"data(font_weight)","font-style":"data(font_style)"}},
      {selector:"node[node_type = 'latent_variable']",style:{"shape":"data(shape)"}},
      {selector:"node[node_type = 'composite_construct']",style:{"shape":"data(shape)"}},
      {selector:"node[node_type = 'annotation']",style:{"shape":"rectangle","border-style":"dashed","background-opacity":0}},
      {selector:"edge",style:{"curve-style":"data(curve_style)","target-arrow-shape":"triangle","line-color":"data(line_color)","target-arrow-color":"data(line_color)","source-arrow-color":"data(line_color)","line-style":"data(line_style)","width":"data(line_width)","arrow-scale":"data(arrow_scale)","label":"data(label)","font-size":"data(label_font_size)","color":"data(label_color)","text-margin-x":"data(label_offset_x)","text-margin-y":"data(label_offset_y)","text-background-color":"#fff","text-background-opacity":0.85}},
      {selector:"edge[edge_type = 'covariance']",style:{"source-arrow-shape":"triangle","target-arrow-shape":"triangle","line-style":"dashed"}},
      {selector:":selected",style:{"border-color":"#18a88b","line-color":"#18a88b","target-arrow-color":"#18a88b"}}
    ]});
    var ur=typeof cy.undoRedo==="function"?cy.undoRedo({}):null;
    var gridGuide=typeof cy.gridGuide==="function"?cy.gridGuide({snapToGridOnRelease:true,drawGrid:true,gridSpacing:20}):null;
    var nodeEditor=typeof cy.nodeEditing==="function"?cy.nodeEditing({padding:5,undoable:!!ur,grappleSize:8,grappleColor:"#18a88b",grappleStrokeColor:"#0d5f50",grappleStrokeWidth:1,minWidth:function(){return 48;},minHeight:function(){return 32;},resizeToContentCueEnabled:function(){return false;}}):null;
    var richLabelFrame=null;
    function renderRichLabels(){
      richLabelFrame=null;if(!resultEditor||!richLabelLayer)return;var zoom=cy.zoom(),markup=[];
      cy.nodes().forEach(function(node){if(!node.visible())return;var data=node.data(),position=node.renderedPosition(),width=Number(data.width||140)*zoom,height=Number(data.height||58)*zoom,lineHeight=Number(data.line_height||1.2),wrap=(data.text_wrap||"wrap")==="wrap"?"pre-wrap":"pre",align=data.text_align||"center";markup.push("<div class='dava-sem-rich-node-label' data-node-id='"+escapeHtml(node.id())+"' style='left:"+position.x+"px;top:"+position.y+"px;width:"+width+"px;height:"+height+"px;line-height:"+lineHeight+";text-align:"+align+";white-space:"+wrap+"'><div class='dava-sem-rich-node-text'>"+richTextMarkup(data,null,"dava-sem-rich-run",zoom)+"</div></div>");});
      richLabelLayer.innerHTML=markup.join("");
    }
    function queueRichLabels(){if(!resultEditor||richLabelFrame!=null)return;richLabelFrame=requestAnimationFrame(renderRichLabels);}
    cy.on("render position data add remove",queueRichLabels);
    function snapshot(){ return {nodes:cy.nodes().map(function(n){var d=Object.assign({},n.data());d.x=n.position("x");d.y=n.position("y");return d;}),edges:cy.edges().map(function(e){return Object.assign({},e.data());})}; }
    function svgText(x,y,label,fontSize,color,anchor,className,fontWeight,fontStyle){
      var lines=String(label==null?"":label).split(/\r?\n/),lineHeight=Number(fontSize||13)*1.2,startY=y-(lines.length-1)*lineHeight/2;
      return "<text class='"+className+"' x='"+x+"' y='"+startY+"' text-anchor='"+(anchor||"middle")+"' dominant-baseline='middle' fill='"+escapeXml(color||"#17242b")+"' font-family='Arial, sans-serif' font-size='"+Number(fontSize||13)+"' font-weight='"+escapeXml(fontWeight||"normal")+"' font-style='"+escapeXml(fontStyle||"normal")+"'>"+lines.map(function(line,index){return "<tspan x='"+x+"' dy='"+(index?lineHeight:0)+"'>"+escapeXml(line)+"</tspan>";}).join("")+"</text>";
    }
    function edgePath(edge){
      var source=edge.source().position(),target=edge.target().position(),curve=edge.data("curve_style")||"bezier",bends=edge.data("bendPointPositions")||[],controls=edge.data("controlPointPositions")||[];
      if(curve==="segments"&&bends.length)return "M "+source.x+" "+source.y+" "+bends.map(function(point){return "L "+point.x+" "+point.y;}).join(" ")+" L "+target.x+" "+target.y;
      if(controls.length===1)return "M "+source.x+" "+source.y+" Q "+controls[0].x+" "+controls[0].y+" "+target.x+" "+target.y;
      if(controls.length>=2)return "M "+source.x+" "+source.y+" C "+controls[0].x+" "+controls[0].y+" "+controls[1].x+" "+controls[1].y+" "+target.x+" "+target.y;
      return "M "+source.x+" "+source.y+" L "+target.x+" "+target.y;
    }
    function svgMarkup(){
      var box=cy.elements().boundingBox({includeLabels:true,includeOverlays:false}),padding=40,width=Math.max(1,box.w+padding*2),height=Math.max(1,box.h+padding*2),offsetX=padding-box.x1,offsetY=padding-box.y1,definitions=[],edges=[],nodes=[];
      cy.edges().forEach(function(edge,index){
        var data=edge.data(),color=data.line_color||"#567483",markerId="sem-arrow-"+index,lineWidth=Number(data.line_width||2),dash=data.line_style==="dashed"?"8 6":data.line_style==="dotted"?"2 5":"none";
        definitions.push("<marker id='"+markerId+"' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='7' markerHeight='7' orient='auto-start-reverse'><path d='M 0 0 L 10 5 L 0 10 z' fill='"+escapeXml(color)+"'/></marker>");
        var markerStart=data.edge_type==="covariance"?" marker-start='url(#"+markerId+")'":"",markerEnd=data.edge_type==="directed_path"||data.edge_type==="covariance"?" marker-end='url(#"+markerId+")'":"";
        edges.push("<g id='"+escapeXml(data.id)+"' class='sem-edge' data-source='"+escapeXml(data.source)+"' data-target='"+escapeXml(data.target)+"'><path d='"+edgePath(edge)+"' transform='translate("+offsetX+" "+offsetY+")' fill='none' stroke='"+escapeXml(color)+"' stroke-width='"+lineWidth+"' stroke-dasharray='"+dash+"'"+markerStart+markerEnd+"/>");
        if(data.label){var midpoint=edge.midpoint(),labelFontSize=Number(data.label_font_size||11),labelX=midpoint.x+offsetX+Number(data.label_offset_x||0),labelY=midpoint.y+offsetY+Number(data.label_offset_y||0),labelWidth=Math.max(24,String(data.label).length*labelFontSize*.64+10),labelHeight=Math.max(20,labelFontSize*1.5);edges.push("<rect x='"+(labelX-labelWidth/2)+"' y='"+(labelY-labelHeight/2)+"' width='"+labelWidth+"' height='"+labelHeight+"' rx='3' fill='#fff' fill-opacity='.88'/>");edges.push(svgText(labelX,labelY,data.label,labelFontSize,data.label_color||"#17242b","middle","sem-edge-label"));}
        edges.push("</g>");
      });
      cy.nodes().forEach(function(node){
        var data=node.data(),position=node.position(),x=position.x+offsetX,y=position.y+offsetY,nodeWidth=Number(data.width||node.width()||140),nodeHeight=Number(data.height||node.height()||58),fill=data.fill_color||"#fff",opacity=data.fill_opacity==null?1:Number(data.fill_opacity),border=data.border_color||"#345b6b",borderWidth=Number(data.border_width==null?2:data.border_width),dash=data.border_style==="dashed"?"8 5":data.border_style==="dotted"?"2 4":"none";
        nodes.push("<g id='"+escapeXml(data.id)+"' class='sem-node sem-node-"+escapeXml(data.node_type||"observed_variable")+"' data-node-type='"+escapeXml(data.node_type||"")+"'>");
        if(data.shape==="ellipse"||data.node_type==="latent_variable")nodes.push("<ellipse cx='"+x+"' cy='"+y+"' rx='"+(nodeWidth/2)+"' ry='"+(nodeHeight/2)+"' fill='"+escapeXml(fill)+"' fill-opacity='"+opacity+"' stroke='"+escapeXml(border)+"' stroke-width='"+borderWidth+"' stroke-dasharray='"+dash+"'/>");
        else nodes.push("<rect x='"+(x-nodeWidth/2)+"' y='"+(y-nodeHeight/2)+"' width='"+nodeWidth+"' height='"+nodeHeight+"' rx='"+Number(data.corner_radius||0)+"' fill='"+escapeXml(fill)+"' fill-opacity='"+opacity+"' stroke='"+escapeXml(border)+"' stroke-width='"+borderWidth+"' stroke-dasharray='"+dash+"'/>");
        nodes.push(svgRichText(x,y,data,nodeWidth,"sem-node-label"));nodes.push("</g>");
      });
      return "<svg xmlns='http://www.w3.org/2000/svg' width='"+Math.ceil(width)+"' height='"+Math.ceil(height)+"' viewBox='0 0 "+width+" "+height+"'><metadata>Editable DAVA Cytoscape SEM result</metadata><defs>"+definitions.join("")+"</defs><g id='sem-path-layer'>"+edges.join("")+"</g><g id='sem-node-layer'>"+nodes.join("")+"</g></svg>";
    }
    var send=debounce(function(event){ if(hydrating||!currentSpec)return; var graph=snapshot(); currentSpec.nodes=graph.nodes;currentSpec.edges=graph.edges;currentSpec.layout=graph.nodes.map(function(n){return{id:n.id,x:n.x,y:n.y,width:n.width,height:n.height};});currentSpec.updated_at=new Date().toISOString();currentSpec.revision=(currentSpec.revision||0)+1;if(window.Shiny)Shiny.setInputValue(inputId,{event:event,model_spec:currentSpec,selection:cy.$(":selected").map(function(e){return e.id();})},{priority:"event"}); },250);
    function hasPath(from,to){ var found=false;cy.elements().bfs({roots:"#"+CSS.escape(from),directed:true,visit:function(v){if(v.id()===to)found=true;}});return found; }
    var eh=typeof cy.edgehandles==="function"?cy.edgehandles({canConnect:function(source,target){return source.id()!==target.id()&&(mode!=="directed"||!hasPath(target.id(),source.id()));},edgeParams:function(source,target){return{data:edgeDefaults(source.id(),target.id(),mode==="covariance"?"covariance":"directed_path",cy.edges().length+1)};},complete:function(){send("sem_edge_added");}}):null;
    var edgeEditor=typeof cy.edgeEditing==="function"?cy.edgeEditing({undoable:!!ur,handleReconnectEdge:!resultEditor,handleAnchors:true,enableCreateAnchorOnDrag:true,isShowHandleOnHover:false,bendPositionsFunction:function(edge){return edge.data("bendPointPositions")||[];},controlPositionsFunction:function(edge){return edge.data("controlPointPositions")||[];},bendPointPositionsSetterFunction:function(edge,value){edge.data("bendPointPositions",value);},controlPointPositionsSetterFunction:function(edge,value){edge.data("controlPointPositions",value);},validateEdge:function(edge,newSource,newTarget){if(newSource.id()===newTarget.id())return "invalid";return "valid";},anchorColor:"#18a88b",endPointColor:"#e85d4a"}):null;
    root.dataset.edgeHandles=String(!!eh);root.dataset.nodeEditing=String(!!nodeEditor);root.dataset.edgeEditing=String(!!edgeEditor);
    function updateStatus(){var selected=cy.$(":selected"),errors=cy.nodes().filter(function(n){return n.data("node_type")==="observed_variable"&&!n.data("variable_name");}).length;root.querySelector("[data-mode-status]").textContent={select:"Select",directed:"One-way path",covariance:"Two-way covariance"}[mode]||mode;root.querySelector("[data-selection-status]").textContent="Selected "+selected.length+" item";root.querySelector("[data-model-status]").textContent="node "+cy.nodes().length+" · Path "+cy.edges().length+" · Tips "+errors;root.querySelector("[data-document-state]").textContent=(currentSpec&&currentSpec.model_name?currentSpec.model_name:"Prior model")+" · "+(currentSpec&&currentSpec.method?currentSpec.method:"")+" · "+(errors?"Need to check":"The structure is valid");var zoom=Math.round(cy.zoom()*100);root.querySelector("[data-zoom]").value=Math.max(25,Math.min(200,zoom));root.querySelector("[data-zoom-label]").textContent=zoom+"%";if(window.DavaI18n)window.DavaI18n.translateTree(root);}
    function setMode(value){mode=value;root.querySelectorAll("[data-action]").forEach(function(b){b.classList.toggle("active",b.dataset.action===value);});if(eh){if(value==="directed"||value==="covariance")eh.enableDrawMode();else eh.disableDrawMode();}updateStatus();}
    function viewportCenter(){var projected=cy.renderer().projectIntoViewport(canvas.clientWidth/2,canvas.clientHeight/2);return{x:projected[0],y:projected[1]};}
    function constrainToViewport(position,nodeData){var extent=cy.extent(),padding=12/Math.max(cy.zoom(),0.01),halfWidth=Number(nodeData.width||140)/2,halfHeight=Number(nodeData.height||58)/2,minX=extent.x1+halfWidth+padding,maxX=extent.x2-halfWidth-padding,minY=extent.y1+halfHeight+padding,maxY=extent.y2-halfHeight-padding;if(minX>maxX){minX=maxX=(extent.x1+extent.x2)/2;}if(minY>maxY){minY=maxY=(extent.y1+extent.y2)/2;}return{x:Math.max(minX,Math.min(maxX,position.x)),y:Math.max(minY,Math.min(maxY,position.y))};}
    function findVisibleFreePosition(preferred,nodeData){var center=constrainToViewport(preferred,nodeData),stepX=Number(nodeData.width||140)+28,stepY=Number(nodeData.height||58)+28,candidates=[center];for(var ring=1;ring<=5;ring++){for(var x=-ring;x<=ring;x++){candidates.push(constrainToViewport({x:center.x+x*stepX,y:center.y-ring*stepY},nodeData));candidates.push(constrainToViewport({x:center.x+x*stepX,y:center.y+ring*stepY},nodeData));}for(var y=-ring+1;y<ring;y++){candidates.push(constrainToViewport({x:center.x-ring*stepX,y:center.y+y*stepY},nodeData));candidates.push(constrainToViewport({x:center.x+ring*stepX,y:center.y+y*stepY},nodeData));}}var width=Number(nodeData.width||140),height=Number(nodeData.height||58);for(var index=0;index<candidates.length;index++){var candidate=candidates[index],overlap=cy.nodes().some(function(node){var data=node.data(),position=node.position();return Math.abs(candidate.x-position.x)<(width+Number(data.width||140))/2+16&&Math.abs(candidate.y-position.y)<(height+Number(data.height||58))/2+16;});if(!overlap)return candidate;}return center;}
    function addNode(type,position,variable){if(variable&&currentSpec&&(currentSpec.method==="covariance_sem"||currentSpec.method==="pls_pm")){var assigned=[];cy.nodes().forEach(function(node){if(node.data("node_type")==="observed_variable"&&node.data("variable_name"))assigned.push(node.data("variable_name"));if(node.data("node_type")==="latent_variable")assigned=assigned.concat(node.data("indicator_variables")||[]);});if(assigned.indexOf(variable)>=0)return;}var d=nodeDefaults(type,cy.nodes().length+1);if(variable){d.label=variable;d.variable_name=variable;}if(type==="composite_construct"&&currentSpec&&currentSpec.method==="piecewise_sem")d.construct_name=d.label;var safePosition=findVisibleFreePosition(position||viewportCenter(),d),element={group:"nodes",data:d,position:safePosition};if(ur)ur.do("add",element);else cy.add(element);cy.$(":selected").unselect();cy.$id(d.id).select();send("sem_node_added");updateStatus();}
    function selectedNodes(){return cy.$("node:selected").filter(function(n){return !n.locked();});}
    function align(kind){var nodes=selectedNodes();if(nodes.length<2)return;var box=nodes.boundingBox();nodes.forEach(function(n){var p=n.position(),b=n.boundingBox();if(kind==="left")p.x+=box.x1-b.x1;if(kind==="right")p.x+=box.x2-b.x2;if(kind==="top")p.y+=box.y1-b.y1;if(kind==="bottom")p.y+=box.y2-b.y2;if(kind==="h")p.y=box.y1+box.h/2;if(kind==="v")p.x=box.x1+box.w/2;n.position(p);});send("sem_layout_changed");}
    function distribute(axis){var nodes=selectedNodes().sort(function(a,b){return a.position(axis)-b.position(axis);});if(nodes.length<3)return;var first=nodes[0].position(axis),last=nodes[nodes.length-1].position(axis),step=(last-first)/(nodes.length-1);nodes.forEach(function(n,i){var p=n.position();p[axis]=first+step*i;n.position(p);});send("sem_layout_changed");}
    function renderProperties(){
      var selected=cy.$(":selected"),hasSelection=selected.length>0;
      if(resultEditor){renderResultProperties();return;}
      documentHost.hidden=hasSelection;propertySection.hidden=!hasSelection;
      if(!hasSelection){prop.innerHTML="";return;}
      if(selected.length>1){
        prop.innerHTML="<p class='dava-sem-status'>Selected "+selected.length+" item</p><button type='button' data-batch='lock'>Lock selection</button><button type='button' data-batch='unlock'>Unlock selected</button><label>Unify color</label><input type='color' data-batch-color value='#dff4ef'>";
        prop.querySelectorAll("[data-batch]").forEach(function(input){input.addEventListener(input.type==="color"?"input":"click",function(){selected.forEach(function(ele){if(input.dataset.batch==="lock"){ele.lock();ele.data("locked",true);}else if(input.dataset.batch==="unlock"){ele.unlock();ele.data("locked",false);}});send("sem_batch_updated");});});
        prop.querySelector("[data-batch-color]").addEventListener("input",function(event){selected.nodes().data("fill_color",event.target.value);selected.edges().data("line_color",event.target.value);send("sem_batch_style_updated");});return;
      }
      var ele=selected[0],d=ele.data(),piecewise=currentSpec&&currentSpec.method==="piecewise_sem",cbsem=currentSpec&&currentSpec.method==="covariance_sem",plspm=currentSpec&&currentSpec.method==="pls_pm";
      if(cbsem||plspm){
        if(ele.isNode()){
          var cbType=d.node_type||"observed_variable";
          if(cbType==="composite_construct"){cbType="latent_variable";ele.data({node_type:cbType,observed:false,latent:true,composite:false,variable_name:"",measurement_mode:d.measurement_mode||"reflective"});}
          var occupied=[];
          cy.nodes().forEach(function(node){
            if(node.id()===ele.id())return;
            if(node.data("node_type")==="observed_variable"&&node.data("variable_name"))occupied.push(node.data("variable_name"));
            if(node.data("node_type")==="latent_variable")occupied=occupied.concat(node.data("indicator_variables")||[]);
          });
          var selectedVariables=cbType==="latent_variable"?(d.indicator_variables||[]):d.variable_name?[d.variable_name]:[];
          var availableVariables=variables.filter(function(variable){return occupied.indexOf(variable)<0||selectedVariables.indexOf(variable)>=0;});
          var cbHtml="<label>Show tags</label><input data-key='label' value='"+escapeHtml(d.label||"")+"'><label>Node type</label><select data-key='node_type'><option value='observed_variable'>Observed variables</option><option value='latent_variable'>Latent variables</option><option value='annotation'>Comments</option></select>";
          if(cbType==="latent_variable"){
            cbHtml+="<label>data variable</label><select multiple size='6' data-key='indicator_variables'>"+availableVariables.map(function(variable){return"<option value='"+escapeHtml(variable)+"' "+(selectedVariables.indexOf(variable)>=0?"selected":"")+">"+escapeHtml(variable)+"</option>";}).join("")+"</select>";
            if(plspm)cbHtml+="<label>Measurement mode</label><select data-key='measurement_mode'><option value='reflective'>Reflective / Mode A</option><option value='formative'>Formative / Mode B</option></select>";
          }
          else if(cbType==="observed_variable")cbHtml+="<label>data variable</label><select data-key='variable_name'><option value=''>Unspecified</option>"+availableVariables.map(function(variable){return"<option value='"+escapeHtml(variable)+"' "+(d.variable_name===variable?"selected":"")+">"+escapeHtml(variable)+"</option>";}).join("")+"</select>";
          cbHtml+="<label class='dava-sem-checkbox-row'><input type='checkbox' data-key='locked' "+(d.locked?"checked":"")+"><span>Lock</span></label>";
          prop.innerHTML=cbHtml;
          prop.querySelector("[data-key='node_type']").value=cbType;
          if(plspm&&cbType==="latent_variable")prop.querySelector("[data-key='measurement_mode']").value=d.measurement_mode||"reflective";
        }else{
          prop.innerHTML="<label>path label</label><input data-key='label' value='"+escapeHtml(d.label||"")+"'><label>path type</label><select data-key='edge_type'><option value='directed_path'>One-way path</option><option value='covariance'>Two-way covariance</option><option value='measurement_loading'>Measurement path</option></select><label>Parameter name</label><input data-key='parameter_name' value='"+escapeHtml(d.parameter_name||"")+"'><label class='dava-sem-checkbox-row'><input type='checkbox' data-key='optional' "+(d.optional?"checked":"")+"><span>Optional path</span></label><label class='dava-sem-checkbox-row'><input type='checkbox' data-key='locked' "+(d.locked?"checked":"")+"><span>Lock</span></label>";
          prop.querySelector("[data-key='edge_type']").value=d.edge_type||"directed_path";
        }
        prop.querySelectorAll("[data-key]").forEach(function(input){input.addEventListener("change",function(){
          var key=input.dataset.key,value=input.type==="checkbox"?input.checked:(input.multiple?Array.from(input.selectedOptions).map(function(option){return option.value;}):input.value);
          ele.data(key,value);
          if(ele.isNode()&&key==="label"&&ele.data("node_type")==="latent_variable")ele.data("construct_name",value);
          if(ele.isNode()&&key==="node_type"){
            ele.data({observed:value==="observed_variable",latent:value==="latent_variable",composite:false,measurement_mode:value==="latent_variable"?"reflective":""});
            if(value==="latent_variable"){ele.data({variable_name:"",construct_name:ele.data("construct_name")||ele.data("label")||"Latent"});}
            else if(value==="observed_variable")ele.data({construct_name:"",indicator_variables:[]});
            else ele.data({variable_name:"",construct_name:"",indicator_variables:[]});
            renderAllProperties();
          }else if(key==="variable_name"||key==="indicator_variables")renderAllProperties();
          if(ele.isNode()&&key==="locked"){value?ele.lock():ele.unlock();renderAllProperties();}
          send(ele.isNode()?"sem_node_updated":"sem_edge_updated");
        });});
        prop.querySelectorAll("select[multiple]").forEach(function(input){input.addEventListener("mousedown",function(event){if(event.target.tagName!=="OPTION")return;event.preventDefault();event.target.selected=!event.target.selected;input.dispatchEvent(new Event("change",{bubbles:true}));});});
        return;
      }
      if(!piecewise){
        if(ele.isNode()){
          var legacyOptions=["<option value=''>Unspecified</option>"].concat(variables.map(function(v){return"<option "+(d.variable_name===v?"selected":"")+">"+escapeHtml(v)+"</option>";}));
          prop.innerHTML="<label>Show tags</label><input data-key='label' value='"+escapeHtml(d.label||"")+"'><label>Node type</label><select data-key='node_type'><option value='observed_variable'>Observed variables</option><option value='latent_variable'>Latent variables</option><option value='composite_construct'>Composite construct</option><option value='annotation'>Comments</option></select><label>data variable</label><select data-key='variable_name'>"+legacyOptions.join("")+"</select><label>Construct name</label><input data-key='construct_name' value='"+escapeHtml(d.construct_name||"")+"'><label>Metrics (comma separated)</label><textarea data-key='indicator_variables'>"+(d.indicator_variables||[]).map(escapeHtml).join(",")+"</textarea><label>Measurement mode</label><select data-key='measurement_mode'><option value='reflective'>Reflective / Mode A</option><option value='formative'>Formative / Mode B</option></select><label><input type='checkbox' data-key='locked' "+(d.locked?"checked":"")+"> Lock</label>";
          prop.querySelector("[data-key='node_type']").value=d.node_type||"observed_variable";
          prop.querySelector("[data-key='measurement_mode']").value=d.measurement_mode||"reflective";
        }else{
          prop.innerHTML="<label>path label</label><input data-key='label' value='"+escapeHtml(d.label||"")+"'><label>path type</label><select data-key='edge_type'><option value='directed_path'>One-way path</option><option value='covariance'>Two-way covariance</option><option value='measurement_loading'>Measurement path</option><option value='formative_weight'>Formative weight</option></select><label>Parameter name</label><input data-key='parameter_name' value='"+escapeHtml(d.parameter_name||"")+"'><label><input type='checkbox' data-key='optional' "+(d.optional?"checked":"")+"> Optional path</label><label><input type='checkbox' data-key='locked' "+(d.locked?"checked":"")+"> Lock</label>";
          prop.querySelector("[data-key='edge_type']").value=d.edge_type||"directed_path";
        }
        prop.querySelectorAll("[data-key]").forEach(function(input){input.addEventListener("change",function(){var key=input.dataset.key,value=input.type==="checkbox"?input.checked:input.value;if(key==="indicator_variables")value=value.split(",").map(function(x){return x.trim();}).filter(Boolean);ele.data(key,value);if(ele.isNode()&&key==="locked"){value?ele.lock():ele.unlock();}send(ele.isNode()?"sem_node_updated":"sem_edge_updated");});});
        return;
      }
      function options(values,current){return values.map(function(v){return"<option value='"+escapeHtml(v)+"' "+(current===v?"selected":"")+">"+escapeHtml(v)+"</option>";}).join("");}
      if(ele.isNode()){
        var type=d.node_type||"observed_variable",html="<label>Show tags</label><input data-key='label' value='"+escapeHtml(d.label||"")+"'><label>Node type</label><select data-key='node_type'><option value='observed_variable'>Observed variables</option>"+(piecewise?"":"<option value='latent_variable'>Latent variables</option>")+"<option value='composite_construct'>Composite construct</option><option value='annotation'>Comments</option></select>";
        if(piecewise&&type==="latent_variable"){type="observed_variable";ele.data({node_type:type,latent:false,observed:true,composite:false,measurement_mode:""});}
        if(type==="observed_variable"){
          var usedObserved=cy.nodes("[node_type = 'observed_variable']").filter(function(n){return n.id()!==ele.id();}).map(function(n){return n.data("variable_name");}).filter(Boolean);
          var observedChoices=variables.filter(function(v){return usedObserved.indexOf(v)<0;});
          html+="<label>data variable</label><select data-key='variable_name'><option value=''>Unspecified</option>"+options(observedChoices,d.variable_name||"")+"</select>";
        }else if(type==="composite_construct"){
          var occupied=[];
          cy.nodes().forEach(function(n){if(n.id()===ele.id())return;if(n.data("node_type")==="observed_variable"&&n.data("variable_name"))occupied.push(n.data("variable_name"));if(n.data("node_type")==="composite_construct")occupied=occupied.concat(n.data("indicator_variables")||[]);});
          var indicators=d.indicator_variables||[],compositeChoices=variables.filter(function(v){return occupied.indexOf(v)<0||indicators.indexOf(v)>=0;});
          html+="<label>data variable</label><select multiple size='6' data-key='indicator_variables'>"+compositeChoices.map(function(v){return"<option value='"+escapeHtml(v)+"' "+(indicators.indexOf(v)>=0?"selected":"")+">"+escapeHtml(v)+"</option>";}).join("")+"</select><label>Construct name</label><input data-key='construct_name' value='"+escapeHtml(d.construct_name||"")+"'><label>Composite variable construction method</label><select data-key='composite_method'><option value='z_mean'>Z-standardized mean method</option><option value='pca'>PCA score</option><option value='factor'>CFA Factor Score</option></select>";
          var method=d.composite_method||"z_mean";
          if(method==="z_mean"&&indicators.length>=2)html+="<label>Flip indicator direction</label><select multiple size='4' data-key='reverse_indicators'>"+indicators.map(function(v){return"<option value='"+escapeHtml(v)+"' "+((d.reverse_indicators||[]).indexOf(v)>=0?"selected":"")+">"+escapeHtml(v)+"</option>";}).join("")+"</select>";
          if(method==="pca")html+="<label>Unified direction</label><select data-key='score_direction'><option value='1'>PC</option><option value='-1'>PC * -1</option></select>";
          html+="<button type='button' class='dava-sem-composite-build' data-composite-build>Construct composite variables</button><label class='dava-sem-checkbox-row'><input type='checkbox' data-composite-validate><span>"+(method==="z_mean"?"Verification Index":"Verification Score")+"</span></label>";
        }
        html+="<label class='dava-sem-checkbox-row'><input type='checkbox' data-key='locked' "+(d.locked?"checked":"")+"><span>Lock</span></label>";
        prop.innerHTML=html;prop.querySelector("[data-key='node_type']").value=type;
        ["composite_method","score_direction"].forEach(function(key){var input=prop.querySelector("[data-key='"+key+"']");if(input)input.value=d[key]||({composite_method:"z_mean",score_direction:"1"}[key]);});
        if(piecewise&&d.locked)prop.querySelectorAll("input,select,textarea,button").forEach(function(input){if(!input.matches("[data-key='locked'],[data-composite-validate]"))input.disabled=true;});
      }else{
        prop.innerHTML="<label>path label</label><input data-key='label' value='"+escapeHtml(d.label||"")+"'><label>path type</label><select data-key='edge_type'><option value='directed_path'>One-way path</option><option value='covariance'>Two-way covariance</option><option value='measurement_loading'>Measurement path</option><option value='formative_weight'>Formative weight</option></select><label>Parameter name</label><input data-key='parameter_name' value='"+escapeHtml(d.parameter_name||"")+"'><label><input type='checkbox' data-key='optional' "+(d.optional?"checked":"")+"> Optional path</label><label><input type='checkbox' data-key='locked' "+(d.locked?"checked":"")+"> Lock</label>";prop.querySelector("[data-key='edge_type']").value=d.edge_type||"directed_path";
      }
      prop.querySelectorAll("[data-key]").forEach(function(input){input.addEventListener("change",function(){var key=input.dataset.key;if(piecewise&&ele.isNode()&&ele.data("locked")&&key!=="locked")return;var value=input.type==="checkbox"?input.checked:(input.multiple?Array.from(input.selectedOptions).map(function(o){return o.value;}):input.value);ele.data(key,value);if(ele.isNode()&&key==="node_type"){ele.data({observed:value==="observed_variable",latent:value==="latent_variable",composite:value==="composite_construct"});if(value==="composite_construct"&&!ele.data("construct_name"))ele.data("construct_name",ele.data("label")||"Composite");renderAllProperties();}else if(key==="indicator_variables"||key==="composite_method"){renderAllProperties();}if(ele.isNode()&&key==="locked"){value?ele.lock():ele.unlock();renderAllProperties();}send(ele.isNode()?"sem_node_updated":"sem_edge_updated");});});
      prop.querySelectorAll("select[multiple]").forEach(function(input){input.addEventListener("mousedown",function(event){if(event.target.tagName!=="OPTION")return;event.preventDefault();event.target.selected=!event.target.selected;input.dispatchEvent(new Event("change",{bubbles:true}));});});
      var build=prop.querySelector("[data-composite-build]");if(build)build.addEventListener("click",function(){send("sem_composite_build");});
      var validate=prop.querySelector("[data-composite-validate]");if(validate)validate.addEventListener("change",function(){if(validate.checked)send("sem_composite_validate");});
    }
    function richNodeLength(node){if(node.nodeType===3)return node.nodeValue.length;if(node.nodeName==="BR")return 1;return Array.from(node.childNodes||[]).reduce(function(total,child){return total+richNodeLength(child);},0);}
    function richBoundaryOffset(root,container,offset){var total=0,found=false;function walk(node){if(found)return;if(node===container){if(node.nodeType===3)total+=Math.min(offset,node.nodeValue.length);else{var children=Array.from(node.childNodes||[]);for(var index=0;index<Math.min(offset,children.length);index++)total+=richNodeLength(children[index]);}found=true;return;}if(node.nodeType===3){total+=node.nodeValue.length;return;}if(node.nodeName==="BR"){total+=1;return;}Array.from(node.childNodes||[]).forEach(walk);}walk(root);return total;}
    function captureRichSelection(editor,nodeId){var selection=window.getSelection();if(!selection||!selection.rangeCount)return savedTextSelection;var range=selection.getRangeAt(0);if(!editor.contains(range.startContainer)||!editor.contains(range.endContainer))return savedTextSelection;var start=richBoundaryOffset(editor,range.startContainer,range.startOffset),end=richBoundaryOffset(editor,range.endContainer,range.endOffset);savedTextSelection={nodeId:nodeId,start:Math.min(start,end),end:Math.max(start,end)};return savedTextSelection;}
    function locateRichOffset(root,offset){var remaining=Math.max(0,offset),last=null,found=null;function walk(node){if(found)return;if(node.nodeType===3){last=node;if(remaining<=node.nodeValue.length){found={node:node,offset:remaining};return;}remaining-=node.nodeValue.length;return;}if(node.nodeName==="BR"){if(remaining<=1){found={node:node.parentNode,offset:Array.prototype.indexOf.call(node.parentNode.childNodes,node)+(remaining?1:0)};return;}remaining-=1;return;}Array.from(node.childNodes||[]).forEach(walk);}walk(root);if(found)return found;if(last)return{node:last,offset:last.nodeValue.length};return{node:root,offset:0};}
    function restoreRichSelection(editor,selection){if(!selection)return;var start=locateRichOffset(editor,selection.start),end=locateRichOffset(editor,selection.end),range=document.createRange();range.setStart(start.node,start.offset);range.setEnd(end.node,end.offset);var browserSelection=window.getSelection();browserSelection.removeAllRanges();browserSelection.addRange(range);}
    function editorTextStyle(node,base){var element=node.nodeType===1?node:node.parentElement,run=element&&element.closest("[data-font-size]");if(!run)return base;return normalizeTextStyle({font_size:run.dataset.fontSize,font_weight:run.dataset.fontWeight,font_style:run.dataset.fontStyle,text_color:run.dataset.textColor,text_script:run.dataset.textScript},base);}
    function readRichEditor(editor,data){var base=baseTextStyle(data),text="",styles=[];function append(value,style){text+=value;for(var index=0;index<value.length;index++)styles.push(Object.assign({},style));}function walk(node,inherited){if(node.nodeType===3){append(node.nodeValue,inherited);return;}if(node.nodeName==="BR"){append("\n",inherited);return;}var style=editorTextStyle(node,inherited),block=/^(DIV|P)$/.test(node.nodeName);if(block&&text&&text.charAt(text.length-1)!=="\n")append("\n",inherited);Array.from(node.childNodes||[]).forEach(function(child){walk(child,style);});}Array.from(editor.childNodes).forEach(function(child){walk(child,base);});return{text:text,base:base,styles:styles};}
    function storeRichModel(node,model){node.data("label",model.text);node.data("text_runs",compressTextRuns(model.text,model.styles,model.base));queueRichLabels();}
    function selectedTextRange(node,textLength){var range=savedTextSelection&&savedTextSelection.nodeId===node.id()?savedTextSelection:{start:0,end:0};return{start:Math.max(0,Math.min(textLength,range.start)),end:Math.max(0,Math.min(textLength,range.end))};}
    function isPartialTextRange(range,textLength){return range.end>range.start&&!(range.start===0&&range.end===textLength);}
    function currentTextStyle(node){var model=expandedRichText(node.data()),range=selectedTextRange(node,model.text.length);return isPartialTextRange(range,model.text.length)&&model.styles[range.start]?model.styles[range.start]:model.base;}
    function setRichEditorContent(editor,data,highlight){var range=highlight?selectedTextRange(cy.getElementById(editor.dataset.nodeId),String(data.label||"").length):null;editor.innerHTML=richTextMarkup(data,range,"dava-sem-rich-editor-run",1);}
    function updateRichSelectionStatus(node){var status=prop.querySelector("[data-rich-selection-status]");if(!status)return;var length=String(node.data("label")||"").length,range=selectedTextRange(node,length);status.textContent=isPartialTextRange(range,length)?"Partial selection "+(range.end-range.start)+" characters":"Overall text";status.classList.toggle("is-partial",isPartialTextRange(range,length));}
    function insertPlainRichText(editor,value){var selection=window.getSelection();if(!selection||!selection.rangeCount)return;var range=selection.getRangeAt(0);range.deleteContents();var textNode=document.createTextNode(value);range.insertNode(textNode);range.setStartAfter(textNode);range.collapse(true);selection.removeAllRanges();selection.addRange(range);editor.dispatchEvent(new Event("input",{bubbles:true}));}
    function applyRichTextProperty(node,key,value){
      var editor=prop.querySelector("[data-rich-text-editor]"),model=editor&&editor.dataset.nodeId===node.id()?readRichEditor(editor,node.data()):expandedRichText(node.data()),range=selectedTextRange(node,model.text.length),partial=isPartialTextRange(range,model.text.length);
      if(key==="font_size")value=Math.max(8,Math.min(72,Number(value)||13));
      if(partial){for(var index=range.start;index<range.end;index++){model.styles[index]=Object.assign({},model.styles[index]||model.base);model.styles[index][key]=value;}}
      else{node.data(key,value);model.base=baseTextStyle(node.data());for(var whole=0;whole<model.styles.length;whole++){model.styles[whole]=Object.assign({},model.styles[whole]||model.base);model.styles[whole][key]=value;}}
      storeRichModel(node,model);if(editor){setRichEditorContent(editor,node.data(),partial);updateRichSelectionStatus(node);}send("sem_result_style_updated");
    }
    function bindRichTextEditor(node){
      var editor=prop.querySelector("[data-rich-text-editor]");if(!editor)return;setRichEditorContent(editor,node.data(),false);
      editor.addEventListener("focus",function(){setRichEditorContent(editor,node.data(),false);var range=selectedTextRange(node,String(node.data("label")||"").length);restoreRichSelection(editor,range);});
      editor.addEventListener("mouseup",function(){captureRichSelection(editor,node.id());updateRichSelectionStatus(node);});
      editor.addEventListener("keyup",function(){captureRichSelection(editor,node.id());updateRichSelectionStatus(node);});
      editor.addEventListener("keydown",function(event){if(event.key==="Enter"){event.preventDefault();insertPlainRichText(editor,"\n");}});
      editor.addEventListener("paste",function(event){event.preventDefault();insertPlainRichText(editor,(event.clipboardData||window.clipboardData).getData("text/plain"));});
      editor.addEventListener("input",function(){var model=readRichEditor(editor,node.data());storeRichModel(node,model);captureRichSelection(editor,node.id());updateRichSelectionStatus(node);send("sem_result_style_updated");});
      editor.addEventListener("blur",function(){captureRichSelection(editor,node.id());setTimeout(function(){if(document.activeElement!==editor&&prop.contains(editor)){setRichEditorContent(editor,node.data(),true);updateRichSelectionStatus(node);}},0);});
      prop.querySelectorAll("[data-text-key],[data-text-layout-key]").forEach(function(control){control.addEventListener("pointerdown",function(){captureRichSelection(editor,node.id());});});
    }
    function onRichSelectionChange(){
      if(!resultEditor)return;var editor=prop.querySelector("[data-rich-text-editor]"),selection=window.getSelection();if(!editor||!selection||!selection.rangeCount)return;var range=selection.getRangeAt(0);if(!editor.contains(range.startContainer)||!editor.contains(range.endContainer))return;var node=cy.getElementById(editor.dataset.nodeId);if(!node||!node.length)return;captureRichSelection(editor,node.id());updateRichSelectionStatus(node);
    }
    document.addEventListener("selectionchange",onRichSelectionChange);
    function renderResultProperties(){
      var selected=cy.$(":selected"),hasSelection=selected.length>0;
      documentHost.hidden=true;propertySection.hidden=!hasSelection;
      if(!hasSelection){prop.innerHTML="<p class='dava-sem-status'>Please select a node or edge</p>";return;}
      if(selected.length>1){
        prop.innerHTML="<p class='dava-sem-status'>Selected "+selected.length+" item</p><button type='button' data-batch='lock'>Lock selection</button><button type='button' data-batch='unlock'>Unlock selected</button><label>Unify fill or line color</label><input type='color' data-batch-color value='#2f6fb0'>";
        prop.querySelectorAll("[data-batch]").forEach(function(input){input.addEventListener("click",function(){selected.forEach(function(ele){if(input.dataset.batch==="lock"){ele.lock();ele.data("locked",true);}else{ele.unlock();ele.data("locked",false);}});send("sem_result_style_updated");renderResultProperties();});});
        prop.querySelector("[data-batch-color]").addEventListener("input",function(event){selected.nodes().data("fill_color",event.target.value);selected.edges().data("line_color",event.target.value);send("sem_result_style_updated");});return;
      }
      var ele=selected[0],d=ele.data(),html="";
      if(ele.isNode()){
        var textStyle=currentTextStyle(ele);
        html="<section class='dava-sem-attribute-block dava-sem-text-attribute-block'><div class='dava-sem-attribute-title'>Text attributes</div>"+
          "<label>text</label><div class='dava-sem-rich-editor' data-rich-text-editor data-node-id='"+escapeHtml(ele.id())+"' contenteditable='"+(!d.locked)+"' role='textbox' aria-multiline='true' spellcheck='false'></div><div class='dava-sem-rich-selection-status' data-rich-selection-status>Overall text</div>"+
          "<div class='dava-sem-property-grid'><label>Text size<input type='number' min='8' max='72' step='1' data-text-key='font_size' value='"+Number(textStyle.font_size||13)+"'></label><label>Thickness<select data-text-key='font_weight'>"+optionList([["normal","General"],["bold","bold"]],textStyle.font_weight||"normal")+"</select></label></div>"+
          "<div class='dava-sem-property-grid'><label>glyph<select data-text-key='font_style'>"+optionList([["normal","General"],["italic","italics"]],textStyle.font_style||"normal")+"</select></label><label>text color<input type='color' data-text-key='text_color' value='"+(textStyle.text_color||"#17242b")+"'></label></div>"+
          "<div class='dava-sem-property-grid'><label>Line break<select data-text-layout-key='text_wrap'>"+optionList([["wrap","Automatic line wrapping"],["manual","Manual line wrapping only"]],d.text_wrap||"wrap")+"</select></label><label>Line spacing<input type='number' min='0.8' max='3' step='0.1' data-text-layout-key='line_height' value='"+Number(d.line_height||1.2)+"'></label></div>"+
          "<div class='dava-sem-property-grid'><label>Alignment<select data-text-layout-key='text_align'>"+optionList([["left","left aligned"],["center","Center"],["right","right aligned"]],d.text_align||"center")+"</select></label><label>Superscript and subscript<select data-text-key='text_script'>"+optionList([["normal","General"],["super","superscript"],["sub","subscript"]],textStyle.text_script||"normal")+"</select></label></div></section>"+
          "<section class='dava-sem-attribute-block dava-sem-border-attribute-block'><div class='dava-sem-attribute-title'>Border properties</div>"+
          "<label>shape<select data-result-key='shape'>"+optionList([["round-rectangle","Rounded rectangle"],["rectangle","Rectangle"],["ellipse","Ellipse"],["diamond","Diamond"],["hexagon","Hexagon"]],d.shape||"round-rectangle")+"</select></label>"+
          "<div class='dava-sem-property-grid'><label>width<input type='number' min='48' max='800' data-result-key='width' value='"+(d.width||140)+"'></label><label>height<input type='number' min='32' max='600' data-result-key='height' value='"+(d.height||58)+"'></label></div>"+
          "<div class='dava-sem-property-grid'><label>fill color<input type='color' data-result-key='fill_color' value='"+(d.fill_color||"#ffffff")+"'></label><label>Transparency<input type='number' min='0' max='1' step='0.05' data-result-key='fill_opacity' value='"+(d.fill_opacity==null?1:d.fill_opacity)+"'></label></div>"+
          "<div class='dava-sem-property-grid'><label>Border color<input type='color' data-result-key='border_color' value='"+(d.border_color||"#345b6b")+"'></label><label>Border width<input type='number' min='0' max='16' step='0.5' data-result-key='border_width' value='"+(d.border_width==null?2:d.border_width)+"'></label></div>"+
          "<label>Border line style<select data-result-key='border_style'>"+optionList([["solid","solid line"],["dashed","dashed line"],["dotted","dotted line"],["double","Double line"]],d.border_style||"solid")+"</select></label></section>";
      }else{
        if(currentSpec&&["covariance_sem","piecewise_sem","pls_pm"].indexOf(currentSpec.method)>=0)html="<section class='dava-sem-attribute-block dava-sem-path-text-attribute-block'><div class='dava-sem-attribute-title'>Path text attribute</div><label>path text</label><input data-result-key='label' value='"+escapeHtml(d.label||"")+"'><div class='dava-sem-property-grid'><label>Text size<input type='number' min='8' max='72' step='1' data-result-key='label_font_size' value='"+Number(d.label_font_size||11)+"'></label><label>text color<input type='color' data-result-key='label_color' value='"+(d.label_color||"#17242b")+"'></label></div><div class='dava-sem-property-grid'><label>Horizontal position<input type='number' min='-300' max='300' step='1' data-result-key='label_offset_x' value='"+Number(d.label_offset_x||0)+"'></label><label>vertical position<input type='number' min='-300' max='300' step='1' data-result-key='label_offset_y' value='"+Number(d.label_offset_y||0)+"'></label></div></section><section class='dava-sem-attribute-block dava-sem-path-line-attribute-block'><div class='dava-sem-attribute-title'>Path line properties</div><div class='dava-sem-property-grid'><label>Line color<input type='color' data-result-key='line_color' value='"+(d.line_color||"#567483")+"'></label><label>Line width<input type='number' min='0.5' max='16' step='0.5' data-result-key='line_width' value='"+(d.line_width||2)+"'></label></div><label>Line style<select data-result-key='line_style'>"+optionList([["solid","solid line"],["dashed","dashed line"],["dotted","dotted line"]],d.line_style||"solid")+"</select></label><label>Curve type<select data-result-key='curve_style'>"+optionList([["bezier","Curve"],["segments","Polyline"],["straight","straight line"],["unbundled-bezier","Controllable curve"]],d.curve_style||"bezier")+"</select></label><label>Arrow size<input type='range' min='0.5' max='3' step='0.1' data-result-key='arrow_scale' value='"+(d.arrow_scale||1)+"'></label></section>";
        else html="<label>path text</label><input data-result-key='label' value='"+escapeHtml(d.label||"")+"'><div class='dava-sem-property-grid'><label>Line color<input type='color' data-result-key='line_color' value='"+(d.line_color||"#567483")+"'></label><label>Line width<input type='number' min='0.5' max='16' step='0.5' data-result-key='line_width' value='"+(d.line_width||2)+"'></label></div><label>Line style<select data-result-key='line_style'>"+optionList([["solid","solid line"],["dashed","dashed line"],["dotted","dotted line"]],d.line_style||"solid")+"</select></label><label>Curve type<select data-result-key='curve_style'>"+optionList([["bezier","Curve"],["segments","Polyline"],["straight","straight line"],["unbundled-bezier","Controllable curve"]],d.curve_style||"bezier")+"</select></label><label>Arrow size<input type='range' min='0.5' max='3' step='0.1' data-result-key='arrow_scale' value='"+(d.arrow_scale||1)+"'></label>";
      }
      html+="<label class='dava-sem-checkbox-row'><input type='checkbox' data-result-key='locked' "+(d.locked?"checked":"")+"><span>Lock</span></label>";prop.innerHTML=html;
      if(ele.isNode()){
        bindRichTextEditor(ele);updateRichSelectionStatus(ele);
        prop.querySelectorAll("[data-text-key]").forEach(function(input){input.addEventListener(input.type==="color"?"input":"change",function(){if(d.locked)return;applyRichTextProperty(ele,input.dataset.textKey,input.type==="number"?Number(input.value):input.value);});});
        prop.querySelectorAll("[data-text-layout-key]").forEach(function(input){input.addEventListener("change",function(){if(d.locked)return;var key=input.dataset.textLayoutKey,value=input.type==="number"?Number(input.value):input.value;if(key==="line_height")value=Math.max(.8,Math.min(3,value||1.2));ele.data(key,value);queueRichLabels();send("sem_result_style_updated");});});
      }
      prop.querySelectorAll("[data-result-key]").forEach(function(input){input.addEventListener(input.type==="color"||input.type==="range"?"input":"change",function(){var key=input.dataset.resultKey;if(d.locked&&key!=="locked")return;var value=input.type==="checkbox"?input.checked:input.value;if(input.type==="number"||input.type==="range")value=Number(value);ele.data(key,value);if(key==="locked"){value?ele.lock():ele.unlock();renderResultProperties();}if((key==="width"||key==="height")&&nodeEditor)nodeEditor.refreshGrapples();queueRichLabels();send("sem_result_style_updated");});});
      if(ele.isNode()&&d.locked)prop.querySelectorAll("[data-text-key],[data-text-layout-key],[data-result-key]:not([type='checkbox'])").forEach(function(input){input.disabled=true;});
    }
    function optionList(values,current){return values.map(function(item){return"<option value='"+item[0]+"' "+(current===item[0]?"selected":"")+">"+item[1]+"</option>";}).join("");}
    function renderAllProperties(){
      if(resultEditor){renderResultProperties();return;}
      renderProperties();
      var selected=cy.$(":selected");if(selected.length!==1)return;
      var ele=selected[0],d=ele.data(),html="<hr><strong>Appearance</strong>";
      if(ele.isNode()){
        html+="<label>shape</label><select data-visual-key='shape'>"+optionList([["round-rectangle","Rounded rectangle"],["rectangle","Rectangle"],["ellipse","Ellipse"],["diamond","Diamond"],["hexagon","Hexagon"]],d.shape||"round-rectangle")+"</select>"+
          "<div class='dava-sem-property-grid'><label>width<input type='number' min='48' max='800' data-visual-key='width' value='"+(d.width||140)+"'></label><label>height<input type='number' min='32' max='600' data-visual-key='height' value='"+(d.height||58)+"'></label></div>"+
          "<div class='dava-sem-property-grid'><label>fill color<input type='color' data-visual-key='fill_color' value='"+(d.fill_color||"#ffffff")+"'></label><label>Transparency<input type='number' min='0' max='1' step='0.05' data-visual-key='fill_opacity' value='"+(d.fill_opacity==null?1:d.fill_opacity)+"'></label></div>"+
          "<div class='dava-sem-property-grid'><label>Border color<input type='color' data-visual-key='border_color' value='"+(d.border_color||"#345b6b")+"'></label><label>Border width<input type='number' min='0' max='16' step='0.5' data-visual-key='border_width' value='"+(d.border_width==null?2:d.border_width)+"'></label></div>"+
          "<label>Border line style</label><select data-visual-key='border_style'>"+optionList([["solid","solid line"],["dashed","dashed line"],["dotted","dotted line"],["double","Double line"]],d.border_style||"solid")+"</select>"+
          "<div class='dava-sem-property-grid'><label>Rounded corners<input type='number' min='0' max='80' data-visual-key='corner_radius' value='"+(d.corner_radius==null?8:d.corner_radius)+"'></label><label>Text size<input type='number' min='8' max='48' data-visual-key='font_size' value='"+(d.font_size||13)+"'></label></div>"+
          "<label>text color</label><input type='color' data-visual-key='text_color' value='"+(d.text_color||"#17242b")+"'>";
      }else{
        html+="<div class='dava-sem-property-grid'><label>Line color<input type='color' data-visual-key='line_color' value='"+(d.line_color||"#567483")+"'></label><label>Line width<input type='number' min='0.5' max='16' step='0.5' data-visual-key='line_width' value='"+(d.line_width||2)+"'></label></div>"+
          "<label>Line style</label><select data-visual-key='line_style'>"+optionList([["solid","solid line"],["dashed","dashed line"],["dotted","dotted line"]],d.line_style||"solid")+"</select>"+
          "<label>path type</label><select data-visual-key='curve_style'>"+optionList([["bezier","Curve"],["segments","Polyline"],["straight","straight line"],["unbundled-bezier","Controllable curve"]],d.curve_style||"bezier")+"</select>"+
          "<label>Arrow size</label><input type='range' min='0.5' max='3' step='0.1' data-visual-key='arrow_scale' value='"+(d.arrow_scale||1)+"'>"+
          "<p class='dava-sem-status'>After selecting a single path, you can drag the endpoint to change the connection node; drag the path to create and move control points.</p>";
      }
      prop.insertAdjacentHTML("beforeend",html);
      prop.querySelectorAll("[data-visual-key]").forEach(function(input){input.addEventListener(input.type==="range"||input.type==="color"?"input":"change",function(){var key=input.dataset.visualKey,value=input.value;if(input.type==="number"||input.type==="range")value=Number(value);ele.data(key,value);if(ele.isNode()&&(key==="width"||key==="height")&&nodeEditor)nodeEditor.refreshGrapples();send(ele.isNode()?"sem_node_style_updated":"sem_edge_style_updated");});});
    }
    cy.on("select unselect",function(){renderAllProperties();updateStatus();});cy.on("dragfree","node",function(){send("sem_layout_changed");updateStatus();});cy.on("remove add",function(){send("sem_model_updated");updateStatus();});cy.on("zoom",updateStatus);
    cy.on("nodeediting.resizeend",function(event,type,node){node.data("width",Number(node.width()));node.data("height",Number(node.height()));send("sem_node_resized");});
    cy.on("cyedgeediting.changeAnchorPoints cyedgeediting.reconnect",function(){send("sem_edge_geometry_updated");});
    function applyResultStyle(action){
      var selected=cy.$(":selected").filter(function(ele){return !ele.locked();}),nodes=selected.nodes(),edges=selected.edges(),handled=true;
      if(action==="text-bold")nodes.forEach(function(node){var style=currentTextStyle(node);applyRichTextProperty(node,"font_weight",style.font_weight==="bold"?"normal":"bold");});
      else if(action==="text-italic")nodes.forEach(function(node){var style=currentTextStyle(node);applyRichTextProperty(node,"font_style",style.font_style==="italic"?"normal":"italic");});
      else if(action==="font-increase")nodes.forEach(function(node){var style=currentTextStyle(node);applyRichTextProperty(node,"font_size",Math.min(72,Number(style.font_size||13)+1));});
      else if(action==="font-decrease")nodes.forEach(function(node){var style=currentTextStyle(node);applyRichTextProperty(node,"font_size",Math.max(8,Number(style.font_size||13)-1));});
      else if(action.indexOf("shape-")===0)nodes.data("shape",action.replace("shape-",""));
      else if(action==="line-solid"){nodes.data("border_style","solid");edges.data("line_style","solid");}
      else if(action==="line-dashed"){nodes.data("border_style","dashed");edges.data("line_style","dashed");}
      else handled=false;
      if(handled){send("sem_result_style_updated");renderAllProperties();}
      return handled;
    }
    function runAction(action){if(!action||action==="add-latent"&&currentSpec&&currentSpec.method==="piecewise_sem"||action==="add-composite"&&currentSpec&&(currentSpec.method==="covariance_sem"||currentSpec.method==="pls_pm"))return;if(resultEditor&&["add-observed","add-latent","add-composite","directed","covariance"].indexOf(action)>=0)return;if(resultEditor&&applyResultStyle(action)){updateStatus();return;}if(action.indexOf("add-")===0)addNode({"add-observed":"observed_variable","add-latent":"latent_variable","add-composite":"composite_construct","add-note":"annotation"}[action]);else if(action==="select"||action==="directed"||action==="covariance")setMode(action);else if(action==="delete"){var sel=cy.$(":selected");if(ur)ur.do("remove",sel);else sel.remove();}else if(action==="undo"&&ur)ur.undo();else if(action==="redo"&&ur)ur.redo();else if(action==="copy")clipboard=cy.$(":selected").jsons();else if(action==="paste"&&clipboard){var stamp=Date.now();clipboard.forEach(function(x){x=JSON.parse(JSON.stringify(x));x.data.id=x.data.id+"_copy"+stamp;if(x.position){x.position.x+=30;x.position.y+=30;}cy.add(x);});send("sem_model_updated");}else if(action==="lock")cy.$(":selected").forEach(function(e){e.locked()?e.unlock():e.lock();e.data("locked",e.locked());});else if(action==="layout"){cy.layout({name:"breadthfirst",directed:true,padding:45,spacingFactor:1.25,animate:false}).run();send("sem_layout_changed");}else if(action.indexOf("align-")===0)align(action.replace("align-",""));else if(action==="distribute-h")distribute("x");else if(action==="distribute-v")distribute("y");else if(action==="zoom-in")cy.zoom(cy.zoom()*1.2);else if(action==="zoom-out")cy.zoom(cy.zoom()/1.2);else if(action==="actual-size")cy.zoom(1);else if(action==="fit")cy.fit(undefined,30);else if(action==="toggle-grid"){gridVisible=!gridVisible;canvas.classList.toggle("hide-grid",!gridVisible);}else if(action==="clear-selection")cy.$(":selected").unselect();updateStatus();}
    root.querySelector(".dava-sem-toolbar").addEventListener("click",function(event){var target=event.target.closest("button");runAction(target&&target.dataset.action);});
    root.querySelectorAll("[data-toolbar-color]").forEach(function(input){input.addEventListener("input",function(){var selected=cy.$(":selected").filter(function(ele){return !ele.locked();});if(input.dataset.toolbarColor==="fill_color")selected.nodes().data("fill_color",input.value);else{selected.nodes().data("border_color",input.value);selected.edges().data("line_color",input.value);}send("sem_result_style_updated");renderAllProperties();});});
    (function(){
      var toolbar=root.querySelector(".dava-sem-toolbar"), tip=root.querySelector("[data-toolbar-tooltip]"), active=null;
      function hide(){if(active)active.removeAttribute("data-tooltip-active");active=null;tip.hidden=true;tip.textContent="";}
      function show(control){var text=control&&control.dataset.tooltip;if(!text)return;active=control;tip.textContent=text;tip.hidden=false;var rect=control.getBoundingClientRect(), width=tip.offsetWidth, height=tip.offsetHeight;
        var left=Math.max(8,Math.min(rect.left+(rect.width-width)/2,window.innerWidth-width-8));
        var top=rect.bottom+8;if(top+height>window.innerHeight-8)top=Math.max(8,rect.top-height-8);
        tip.style.left=left+"px";tip.style.top=top+"px";control.setAttribute("data-tooltip-active","");}
      toolbar.addEventListener("mouseenter",function(event){var control=event.target.closest("[data-tooltip]");if(control)show(control);},true);
      toolbar.addEventListener("mouseleave",hide,true);toolbar.addEventListener("focusin",function(event){var control=event.target.closest("[data-tooltip]");if(control)show(control);});
      toolbar.addEventListener("focusout",hide);window.addEventListener("resize",hide);window.addEventListener("scroll",hide,true);
    }());
    var searchInput=root.querySelector(".dava-sem-search");if(searchInput)searchInput.addEventListener("input",function(event){var query=event.target.value.toLowerCase();root.querySelectorAll("[data-variable]").forEach(function(item){item.hidden=item.dataset.variable.toLowerCase().indexOf(query)<0;});});
    var templateSelect=root.querySelector("[data-template-select]");if(templateSelect&&root.dataset.templateInputId){templateSelect.addEventListener("change",function(){if(window.Shiny)Shiny.setInputValue(root.dataset.templateInputId,templateSelect.value,{priority:"event"});});if(window.Shiny)Shiny.setInputValue(root.dataset.templateInputId,templateSelect.value,{priority:"event"});}
    root.querySelectorAll("[data-template-action]").forEach(function(control){control.addEventListener("click",function(){var action=control.dataset.templateAction,targetId=action==="new_model"?root.dataset.newModelId:action==="save_revision"?root.dataset.saveRevisionId:root.dataset.templateActionId;if(action==="load_template"&&window.Shiny)Shiny.setInputValue(root.dataset.templateInputId,templateSelect.value,{priority:"event"});if(window.Shiny&&targetId)Shiny.setInputValue(targetId,Date.now(),{priority:"event"});});});
    root.querySelectorAll("[draggable='true']").forEach(function(item){item.addEventListener("dragstart",function(event){event.dataTransfer.setData("application/x-dava-sem",JSON.stringify({variable:item.dataset.variable||"",type:item.dataset.nodeType||"observed_variable"}));});});
    canvas.addEventListener("dragover",function(event){if(!resultEditor)event.preventDefault();});canvas.addEventListener("drop",function(event){if(resultEditor)return;event.preventDefault();var payload;try{payload=JSON.parse(event.dataTransfer.getData("application/x-dava-sem"));}catch(error){return;}var rect=canvas.getBoundingClientRect(),projected=cy.renderer().projectIntoViewport(event.clientX-rect.left,event.clientY-rect.top);addNode(payload.type,{x:projected[0],y:projected[1]},payload.variable);});
    cy.on("dbltap",function(event){if(event.target===cy)addNode(resultEditor?"annotation":"observed_variable",event.position);});
    var contextMenu=root.querySelector("[data-context-menu]"),stage=root.querySelector(".dava-sem-stage");function hideContextMenu(){contextMenu.hidden=true;}function showContextMenu(event){var target=event.target,items=resultEditor?(target===cy?[["add-note","Add text"],["paste","Paste"],["fit","Fit to canvas"]]:target.isNode()?[["copy","Copy"],["delete","Delete"],["lock","Lock/Unlock"]]:[["delete","Delete path"],["lock","Lock/Unlock"]]):(target===cy?[["add-observed","Create a new observation node"],["paste","Paste"],["layout","Auto Layout"],["fit","Fit to canvas"]]:target.isNode()?[["copy","Copy"],["delete","Delete"],["lock","Lock/Unlock"],["directed","Create one-way path"],["covariance","Create covariance"]]:[["delete","Delete path"],["lock","Lock/Unlock"]]);if(target!==cy&&!target.selected()){cy.$(":selected").unselect();target.select();}contextMenu.innerHTML=items.map(function(item){return"<button type='button' data-context-action='"+item[0]+"'>"+item[1]+"</button>";}).join("");contextMenu.hidden=false;var left=Math.max(4,Math.min(event.renderedPosition.x,stage.clientWidth-contextMenu.offsetWidth-4)),top=Math.max(4,Math.min(event.renderedPosition.y,stage.clientHeight-contextMenu.offsetHeight-4));contextMenu.style.left=left+"px";contextMenu.style.top=top+"px";}canvas.addEventListener("contextmenu",function(event){event.preventDefault();});cy.on("cxttap",showContextMenu);cy.on("tap",hideContextMenu);contextMenu.addEventListener("pointerdown",function(event){event.stopPropagation();});contextMenu.addEventListener("click",function(event){event.preventDefault();event.stopPropagation();var button=event.target.closest("button");if(button)runAction(button.dataset.contextAction);hideContextMenu();});
    stage.addEventListener("contextmenu",function(event){
      event.preventDefault();event.stopPropagation();
      var rect=stage.getBoundingClientRect(),position={x:event.clientX-rect.left,y:event.clientY-rect.top};
      var hit=cy.elementsAt(position),target=hit&&hit.length?hit[0]:cy;
      showContextMenu({target:target,renderedPosition:position});
    },true);
    root.addEventListener("contextmenu",function(event){
      if(event.target.closest(".dava-sem-stage"))event.preventDefault();
    },true);
    canvas.addEventListener("keydown",function(event){if(event.target.matches("input,textarea,select"))return;var ctrl=event.ctrlKey||event.metaKey,key=event.key.toLowerCase(),action=null;if(ctrl&&key==="z")action=event.shiftKey?"redo":"undo";else if(ctrl&&key==="y")action="redo";else if(ctrl&&key==="c")action="copy";else if(ctrl&&key==="v")action="paste";else if(ctrl&&key==="a"){cy.elements().select();event.preventDefault();return;}else if(key==="delete"||key==="backspace")action="delete";else if(key==="escape")action="clear-selection";else if(key==="+"||key==="=")action="zoom-in";else if(key==="-")action="zoom-out";if(action){event.preventDefault();runAction(action);}});
    root.querySelector("[data-zoom]").addEventListener("input",function(event){cy.zoom(Number(event.target.value)/100);});
    function load(spec){
      send.cancel();hydrating=true;
      try{
        currentSpec=JSON.parse(JSON.stringify(spec));var piecewise=currentSpec.method==="piecewise_sem",cbsem=currentSpec.method==="covariance_sem",plspm=currentSpec.method==="pls_pm",latentTool=root.querySelector("[data-latent-tool]"),latentToolbar=root.querySelector("[data-latent-toolbar]"),compositeTool=root.querySelector("[data-composite-tool]"),compositeToolbar=root.querySelector("[data-composite-toolbar]");if(latentTool)latentTool.hidden=piecewise;if(latentToolbar)latentToolbar.hidden=piecewise;if(compositeTool)compositeTool.hidden=cbsem||plspm;if(compositeToolbar)compositeToolbar.hidden=cbsem||plspm;if(documentTabs)documentTabs.hidden=!piecewise;documentHost.classList.toggle("is-piecewise",piecewise);activateDocumentTab(piecewise?"local":"manager");var elements=[];(spec.nodes||[]).forEach(function(n,index){n=Object.assign(nodeDefaults(n.node_type||"observed_variable",index+1),n);if(piecewise&&n.node_type==="latent_variable"){n.node_type="observed_variable";n.latent=false;n.observed=true;n.measurement_mode="";}if(plspm&&n.node_type==="composite_construct"){n.node_type="latent_variable";n.latent=true;n.observed=false;n.composite=false;n.variable_name="";n.construct_name=n.construct_name||n.label||"Latent";n.measurement_mode=n.measurement_mode||"reflective";}if(piecewise&&n.node_type==="composite_construct"&&(!n.construct_name||/^com\d+$/i.test(n.construct_name)))n.construct_name=n.label||"Composite";elements.push({group:"nodes",data:n,position:{x:Number(n.x)||100,y:Number(n.y)||100},locked:!!n.locked});});(spec.edges||[]).forEach(function(e,index){e=Object.assign(edgeDefaults(e.source,e.target,e.edge_type||"directed_path",index+1),e);elements.push({group:"edges",data:e});});cy.batch(function(){cy.elements().remove();cy.add(elements);cy.layout({name:"preset"}).run();});if(edgeEditor)edgeEditor.initAnchorPoints(cy.edges());cy.fit(undefined,30);renderAllProperties();updateStatus();
      }finally{hydrating=false;}
    }
    // Container resizing also happens on tab activation and sidebar toggles.
    // Do not re-layout model coordinates or reset zoom on unrelated DOM changes.
    var resizeFrame=null,lastCanvasWidth=0,lastCanvasHeight=0;
    function resizeEditor(){
      if(resizeFrame!==null)cancelAnimationFrame(resizeFrame);
      resizeFrame=requestAnimationFrame(function(){
        resizeFrame=null;
        if(!root.isConnected||cy.destroyed())return;
        var width=root.clientWidth;
        if(!width)return;
        var rem=parseFloat(getComputedStyle(document.documentElement).fontSize)||16;
        root.classList.toggle("sem-compact",width<(resultEditor?38:50)*rem);
        root.classList.toggle("sem-narrow",width<32*rem);
        var w=canvas.clientWidth,h=canvas.clientHeight;
        if(w>0&&h>0&&(w!==lastCanvasWidth||h!==lastCanvasHeight)){
          lastCanvasWidth=w;lastCanvasHeight=h;
          cy.resize();if(cy.nodes().length)cy.fit(undefined,30);updateStatus();
        }
      });
    }
    var editorResizeObserver=window.ResizeObserver?new ResizeObserver(resizeEditor):null;
    if(editorResizeObserver){editorResizeObserver.observe(root);editorResizeObserver.observe(canvas);}
    cy.on("destroy",function(){if(editorResizeObserver)editorResizeObserver.disconnect();if(resizeFrame!==null)cancelAnimationFrame(resizeFrame);});
    resizeEditor();
    function resetCompositeValidation(){var validate=prop.querySelector("[data-composite-validate]");if(validate)validate.checked=false;}
    var state={cy:cy,load:load,svgMarkup:svgMarkup,resetCompositeValidation:resetCompositeValidation,destroy:function(){send.cancel();document.removeEventListener("selectionchange",onRichSelectionChange);if(richLabelFrame!=null)cancelAnimationFrame(richLabelFrame);if(eh)eh.destroy();cy.destroy();}};states.set(id,state);if(root.dataset.initial)load(JSON.parse(root.dataset.initial));setMode("select");
  }
  function scan(){document.querySelectorAll(".dava-sem-builder:not([data-ready])").forEach(function(root){root.dataset.ready="true";initialize(root);});}
  document.addEventListener("DOMContentLoaded",scan);new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true});scan();
  if(window.Shiny)Shiny.addCustomMessageHandler("sem-builder-load",function(message){var state=states.get(message.id);if(state)state.load(message.model_spec);});
  if(window.Shiny)Shiny.addCustomMessageHandler("sem-builder-reset-composite-validation",function(message){var state=states.get(message.id);if(state)state.resetCompositeValidation();});
  if(window.Shiny)Shiny.addCustomMessageHandler("sem-builder-export",function(message){
    var state=states.get(message.id);if(!state)return;
    if(message.action==="png")return downloadUri(state.cy.png({full:true,scale:3,bg:"#ffffff"}),message.file_name||"sem-path.png");
    var svg=state.svgMarkup();
    if(message.action==="svg")return downloadUri("data:image/svg+xml;charset=utf-8,"+encodeURIComponent(svg),message.file_name||"sem-path.svg");
    Shiny.setInputValue(message.input_id,{action:message.action,svg:svg,file_name:message.file_name||"sem-path",nonce:Date.now()},{priority:"event"});
  });
  if(window.Shiny)Shiny.addCustomMessageHandler("sem-builder-download",function(message){downloadUri(message.data_uri,message.file_name);});
})();
