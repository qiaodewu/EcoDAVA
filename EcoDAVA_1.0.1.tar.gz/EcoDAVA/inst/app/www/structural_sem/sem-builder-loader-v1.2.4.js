(function(){
  "use strict";
  var current=document.currentScript;
  var source=new URL("sem-builder-v1.1.0.js?v=1.2.4",current.src);
  var script=document.createElement("script");
  script.src=source.href;
  script.async=false;
  current.parentNode.insertBefore(script,current.nextSibling);
})();
