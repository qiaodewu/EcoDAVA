/* Host bridge running in the Shiny page.
 * It keeps DAVA controls isolated from the SVG-Edit iframe and forwards only
 * explicit, typed messages through postMessage.
 */
(function () {
  "use strict";

  var iframeState = new WeakMap();
  var exitedIframes = new WeakSet();
  var iframeIds = ["dava_svg_editor_iframe", "dava_svgedit_iframe", "svg_editor_iframe"];

  function sameOriginTarget() {
    return window.location && window.location.origin ? window.location.origin : "*";
  }

  function findIframe(payload) {
    payload = payload || {};
    if (payload.iframeId) {
      var byPayload = document.getElementById(payload.iframeId);
      if (byPayload) return byPayload;
    }
    for (var i = 0; i < iframeIds.length; i += 1) {
      var byId = document.getElementById(iframeIds[i]);
      if (byId) return byId;
    }
    return document.querySelector("[data-dava-svgedit-iframe='1']");
  }

  function findIframeForWindow(sourceWindow) {
    var frames = document.querySelectorAll(
      "#dava_svg_editor_iframe, #dava_svgedit_iframe, #svg_editor_iframe, [data-dava-svgedit-iframe='1']"
    );
    for (var i = 0; i < frames.length; i += 1) {
      if (frames[i].contentWindow === sourceWindow) return frames[i];
    }
    return null;
  }

  function moduleRoot(iframe) {
    return iframe ? iframe.closest("[data-dava-svgedit-root='1']") : null;
  }

  function nsPrefix(iframe) {
    var root = moduleRoot(iframe);
    return (iframe && iframe.dataset.nsPrefix) ||
      (root && root.dataset.nsPrefix) ||
      "";
  }

  function stateFor(iframe) {
    var state = iframeState.get(iframe);
    if (!state) {
      state = { editorReady: false, pendingMessages: [] };
      iframeState.set(iframe, state);
    }
    return state;
  }

  function notify(iframe, text, type) {
    if (window.Shiny && Shiny.setInputValue && iframe) {
      var inputId = iframe.dataset.davaStatusInput;
      if (inputId) {
        Shiny.setInputValue(inputId, { message: text, type: type || "info", time: Date.now() }, { priority: "event" });
      }
    }
  }

  function focusSvgEditor(iframe) {
    if (!iframe) return;
    try { iframe.focus(); } catch (error) {}
    try {
      if (iframe.contentWindow && typeof iframe.contentWindow.focus === "function") iframe.contentWindow.focus();
    } catch (error) {}
  }

  function control(iframe, selector) {
    var root = moduleRoot(iframe);
    return root ? root.querySelector(selector) : null;
  }

  function clickControl(iframe, selector) {
    var element = control(iframe, selector);
    if (element) {
      element.click();
      return true;
    }
    return false;
  }

  function sourceSelect(iframe) {
    return control(iframe, ".dava-svgedit-source select");
  }

  function sourcePayload(iframe) {
    var select = sourceSelect(iframe);
    if (!select) return { options: [], value: "" };
    return {
      value: select.value || "",
      options: Array.prototype.map.call(select.options || [], function (option) {
        var parent = option.parentElement;
        return {
          value: option.value,
          label: option.textContent || option.value,
          group: parent && parent.tagName && parent.tagName.toLowerCase() === "optgroup" ? parent.label || "" : ""
        };
      })
    };
  }

  function postMenuState(iframe) {
    if (!iframe || !iframe.contentWindow) return;
    postNow(iframe, {
      type: "DAVA_HOST_MENU_STATE",
      sources: sourcePayload(iframe),
      status: ""
    });
  }

  function toggleToolbar(iframe, collapsed) {
    var root = moduleRoot(iframe);
    if (!root) return false;
    var nextCollapsed = typeof collapsed === "boolean" ? collapsed : !root.classList.contains("is-toolbar-collapsed");
    root.classList.toggle("is-toolbar-collapsed", nextCollapsed);
    postNow(iframe, {
      type: "DAVA_HOST_TOOLBAR_STATE",
      collapsed: nextCollapsed
    });
    return true;
  }

  function appHeaderElements() {
    var editorRoot = document.querySelector("[data-dava-svgedit-root='1']");
    var editorRect = editorRoot && editorRoot.getBoundingClientRect ?
      editorRoot.getBoundingClientRect() :
      null;
    var selectors = [
      "nav#main_nav",
      "#main_nav.navbar",
      "body > .bslib-page-navbar > nav",
      "body > .bslib-page-navbar > header",
      ".bslib-page-navbar > nav.navbar",
      ".bslib-page-navbar .navbar",
      "nav.navbar",
      ".navbar[role='navigation']",
      "[role='navigation'].navbar",
      ".navbar",
      ".main-header",
      "header"
    ];
    var seen = [];
    function addCandidate(element) {
      if (!element || seen.indexOf(element) !== -1) return;
      if (element.closest && element.closest("[data-dava-svgedit-root='1']")) return;
      if (element.querySelector && element.querySelector("[data-dava-svgedit-root='1']")) return;
      seen.push(element);
    }
    selectors.forEach(function (selector) {
      Array.prototype.forEach.call(document.querySelectorAll(selector), function (element) {
        addCandidate(element);
      });
    });
    var mainNav = document.getElementById("main_nav");
    if (mainNav) {
      addCandidate(mainNav.closest("nav,.navbar,header,.main-header") || mainNav);
    }
    Array.prototype.forEach.call(document.querySelectorAll(".navbar-brand,.navbar-title,.navbar .container-fluid"), function (node) {
      if (String(node.textContent || "").indexOf("DAVA") < 0) return;
      addCandidate(node.closest("nav,.navbar,header,.main-header") || node);
    });
    Array.prototype.forEach.call(document.body ? document.body.children : [], function (element) {
      var text = String(element.textContent || "");
      var classes = String(element.className || "");
      var rect = element.getBoundingClientRect ? element.getBoundingClientRect() : { top: 999, height: 999, width: 0 };
      var looksLikeHeader = rect.top <= 24 && rect.height > 20 && rect.height <= 160 &&
        rect.width >= Math.max(320, window.innerWidth * 0.5);
      if ((looksLikeHeader && text.indexOf("DAVA") >= 0) || /navbar|main-header/.test(classes)) {
        addCandidate(element);
      }
      if (editorRect && element !== editorRoot && !element.contains(editorRoot) &&
          rect.width >= Math.max(320, window.innerWidth * 0.5) &&
          rect.height > 20 && rect.height <= 180 &&
          rect.top >= -4 && rect.bottom <= editorRect.top + 6) {
        addCandidate(element);
      }
    });
    return seen;
  }

  function ensureAppHeaderCollapseStyle() {
    if (document.getElementById("dava_app_header_collapse_style")) return;
    var style = document.createElement("style");
    style.id = "dava_app_header_collapse_style";
    style.textContent = [
      "html.dava-app-header-collapsed nav#main_nav,",
      "html.dava-app-header-collapsed #main_nav.navbar,",
      "html.dava-app-header-collapsed body > .bslib-page-navbar > nav,",
      "html.dava-app-header-collapsed body > .bslib-page-navbar > header,",
      "html.dava-app-header-collapsed body > nav.navbar,",
      "html.dava-app-header-collapsed body > header,",
      "html.dava-app-header-collapsed body > .navbar,",
      "html.dava-app-header-collapsed .bslib-page-navbar > nav.navbar,",
      "html.dava-app-header-collapsed .bslib-page-navbar > .navbar,",
      "html.dava-app-header-collapsed .bslib-page-navbar .navbar:first-child,",
      "html.dava-app-header-collapsed .navbar[role='navigation'],",
      "html.dava-app-header-collapsed [role='navigation'].navbar,",
      "html.dava-app-header-collapsed .navbar.navbar-default,",
      "html.dava-app-header-collapsed .navbar.navbar-expand,",
      "html.dava-app-header-collapsed .navbar.navbar-expand-sm,",
      "html.dava-app-header-collapsed .navbar.navbar-expand-md,",
      "html.dava-app-header-collapsed .navbar.navbar-expand-lg,",
      "html.dava-app-header-collapsed .navbar.navbar-expand-xl,",
      "html.dava-app-header-collapsed .navbar.navbar-expand-xxl,",
      "html.dava-app-header-collapsed [data-bs-theme] > nav.navbar,",
      "html.dava-app-header-collapsed .main-header{display:none!important}",
      "html.dava-app-header-collapsed,",
      "body.dava-app-header-collapsed{height:100%!important;overflow:hidden!important}",
      "body.dava-app-header-collapsed .dava-svgedit-page{position:fixed!important;inset:0!important;z-index:2147483000!important;height:100vh!important;min-height:0!important}",
      "body.dava-app-header-collapsed .dava-svgedit-frame-wrap,",
      "body.dava-app-header-collapsed .dava-svgedit-iframe{height:100%!important;min-height:0!important}"
    ].join("\n");
    document.head.appendChild(style);
  }

  function toggleAppHeader(iframe, collapsed) {
    ensureAppHeaderCollapseStyle();
    var nextCollapsed = typeof collapsed === "boolean" ? collapsed : !document.documentElement.classList.contains("dava-app-header-collapsed");
    document.documentElement.classList.toggle("dava-app-header-collapsed", nextCollapsed);
    document.body.classList.toggle("dava-app-header-collapsed", nextCollapsed);
    appHeaderElements().forEach(function (element) {
      if (!element.dataset.davaOriginalDisplay) {
        element.dataset.davaOriginalDisplay = element.style.display || "__empty__";
      }
      if (nextCollapsed) {
        element.style.setProperty("display", "none", "important");
        element.setAttribute("aria-hidden", "true");
      } else {
        element.style.removeProperty("display");
        if (element.dataset.davaOriginalDisplay !== "__empty__") {
          element.style.display = element.dataset.davaOriginalDisplay;
        }
        element.removeAttribute("aria-hidden");
      }
    });
    if (iframe) {
      postNow(iframe, {
        type: "DAVA_APP_HEADER_STATE",
        collapsed: nextCollapsed
      });
    }
    window.dispatchEvent(new Event("resize"));
    return true;
  }

  function restoreAppHeader() {
    toggleAppHeader(null, false);
  }

  function setSourceValue(iframe, value) {
    var select = sourceSelect(iframe);
    if (!select) return false;
    select.value = value || "";
    select.dispatchEvent(new Event("change", { bubbles: true }));
    if (window.jQuery) {
      try { window.jQuery(select).trigger("change"); } catch (error) {}
    }
    postMenuState(iframe);
    return true;
  }

  function triggerHostAction(iframe, action, payload) {
    payload = payload || {};
    if (!iframe) return;
    if (action === "insert-r-plot") {
      clickControl(iframe, "[id$='insert_current_r_plot_to_svgedit']");
    } else if (action === "import-file") {
      clickControl(iframe, ".dava-svgedit-import input[type='file']");
    } else if (action === "save") {
      stateFor(iframe).pendingHostSaveRequestId = payload.requestId || "";
      stateFor(iframe).pendingGalleryName = payload.galleryName || "";
      queueOrPost(iframe, { type: "DAVA_GET_SVG", requestId: payload.requestId || String(Date.now()) });
    } else if (action === "download") {
      clickControl(iframe, "[id$='download_edited_svg']");
    } else if (action === "clear") {
      clickControl(iframe, "[id$='clear_svgedit']");
    } else if (action === "exit") {
      exitEditor(iframe);
    } else if (action === "set-source") {
      setSourceValue(iframe, payload.value || "");
    } else if (action === "refresh-menu") {
      postMenuState(iframe);
    } else if (action === "toggle-app-header") {
      toggleAppHeader(iframe, typeof payload.collapsed === "boolean" ? payload.collapsed : undefined);
    }
  }

  function sendInputValue(iframe, explicitInputId, fallbackName, value) {
    if (!window.Shiny || !Shiny.setInputValue) return;
    var inputId = explicitInputId || (nsPrefix(iframe) + fallbackName);
    if (inputId) Shiny.setInputValue(inputId, value, { priority: "event" });
  }

  function isReady(iframe) {
    var state = iframe && iframeState.get(iframe);
    return !!(state && state.editorReady && iframe.contentWindow);
  }

  function postNow(iframe, payload) {
    if (!iframe || !iframe.contentWindow || !payload || !payload.type) return false;
    if (!exitedIframes.has(iframe) && (!moduleRoot(iframe) || !moduleRoot(iframe).classList.contains("is-exiting"))) {
      restoreIframe(iframe);
    }
    payload.source = "DAVA_SVGEDIT_HOST";
    iframe.contentWindow.postMessage(payload, sameOriginTarget());
    return true;
  }

  function postShutdown(iframe) {
    if (!iframe || !iframe.contentWindow) return;
    try {
      iframe.contentWindow.postMessage({
        source: "DAVA_SVGEDIT_HOST",
        type: "DAVA_SHUTDOWN_SVGEDIT"
      }, sameOriginTarget());
    } catch (error) {
      console.warn("[DAVA SVG-Edit host] Could not request SVG-Edit shutdown.", error);
    }
  }

  function queueOrPost(iframe, payload, options) {
    options = options || {};
    if (!iframe) return false;
    var root = moduleRoot(iframe);
    if (root && root.classList.contains("is-exiting")) return false;
    var state = stateFor(iframe);
    if (!state.editorReady && !options.allowBeforeReady) {
      state.pendingMessages.push(payload);
      notify(iframe, "SVG 编辑器尚未加载完成，已加入待发送队列。", "warning");
      return true;
    }
    return postNow(iframe, payload);
  }

  function flushPending(iframe) {
    var state = stateFor(iframe);
    while (state.pendingMessages.length > 0) {
      postNow(iframe, state.pendingMessages.shift());
    }
  }

  function validateImportPayload(payload) {
    if (!payload || typeof payload.svg !== "string" || !/<svg[\s>]/i.test(payload.svg)) {
      return "请先生成或选择一个 R 图形。";
    }
    if ((payload.mode || "import") !== "import") {
      return "SVG-Edit import message mode must be \"import\".";
    }
    return "";
  }

  function selectMainNav(value) {
    var selectors = [
      "#main_nav [data-value='" + value + "']",
      "#main_nav a[href='#" + value + "']",
      ".navbar [data-value='" + value + "']",
      ".navbar a[href='#" + value + "']",
      ".bslib-page-navbar [data-value='" + value + "']",
      ".bslib-page-navbar a[href='#" + value + "']",
      "[data-value='" + value + "']",
      "a[href='#" + value + "']"
    ];
    for (var i = 0; i < selectors.length; i += 1) {
      var link = document.querySelector(selectors[i]);
      if (link) {
        link.click();
        return true;
      }
    }
    return false;
  }

  function releaseIframe(iframe) {
    if (!iframe) return;
    restoreAppHeader();
    exitedIframes.add(iframe);
    postShutdown(iframe);
    var root = moduleRoot(iframe);
    if (root) {
      root.classList.add("is-exiting");
      root.setAttribute("aria-hidden", "true");
      root.style.pointerEvents = "none";
    }
    if (!iframe.dataset.davaOriginalSrc) iframe.dataset.davaOriginalSrc = iframe.getAttribute("src") || "";
    iframe.style.pointerEvents = "none";
    iframe.setAttribute("aria-hidden", "true");
    iframeState.delete(iframe);
    window.setTimeout(function () {
      if (!exitedIframes.has(iframe)) return;
      try {
        iframe.src = "about:blank";
      } catch (error) {
        console.warn("[DAVA SVG-Edit host] Could not unload SVG-Edit iframe.", error);
      }
    }, 50);
  }

  function restoreIframe(iframe) {
    if (!iframe) return;
    exitedIframes.delete(iframe);
    var root = moduleRoot(iframe);
    if (root) {
      root.classList.remove("is-exiting");
      root.removeAttribute("aria-hidden");
      root.style.pointerEvents = "";
    }
    iframe.style.pointerEvents = "";
    iframe.removeAttribute("aria-hidden");
    if ((iframe.getAttribute("src") || "") === "about:blank" && iframe.dataset.davaOriginalSrc) {
      iframe.setAttribute("src", iframe.dataset.davaOriginalSrc);
    }
  }

  function requestHomeNav() {
    if (window.Shiny && Shiny.setInputValue) {
      try {
        Shiny.setInputValue("main_nav", "home", { priority: "event" });
      } catch (error) {}
    }
    return selectMainNav("home");
  }

  function exitEditor(iframe) {
    notify(iframe, "Exiting SVG editor", "info");
    restoreAppHeader();
    releaseIframe(iframe);
    if (!requestHomeNav()) window.location.hash = "";
    window.setTimeout(function () {
      try { window.scrollTo({ top: 0, behavior: "smooth" }); } catch (error) { window.scrollTo(0, 0); }
    }, 0);
  }
  function registerHandlers() {
    if (!window.Shiny || !Shiny.addCustomMessageHandler || window.DavaSvgEditHostRegistered) return;
    window.DavaSvgEditHostRegistered = true;

    Shiny.addCustomMessageHandler("dava-load-svg-into-svgedit", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      if (!payload || typeof payload.svg !== "string" || !/<svg[\s>]/i.test(payload.svg)) {
        notify(iframe, "请先生成或选择一个图形。", "warning");
        return;
      }
      queueOrPost(iframe, { type: "DAVA_LOAD_SVG", svg: payload.svg });
    });

    Shiny.addCustomMessageHandler("dava-import-svg-into-svgedit", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      var error = validateImportPayload(payload);
      if (error) {
        notify(iframe, error, "error");
        sendInputValue(iframe, iframe.dataset.davaImportErrorInput, "svgedit_import_error", error);
        return;
      }
      queueOrPost(iframe, {
        type: "DAVA_IMPORT_SVG",
        svg: payload.svg,
        mode: "import",
        object_id: payload.object_id || null,
        select_after_import: payload.select_after_import !== false,
        preserve_size: payload.preserve_size === true
      });
      window.setTimeout(function () { focusSvgEditor(iframe); }, 0);
    });

    Shiny.addCustomMessageHandler("dava-request-svg-from-svgedit", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      queueOrPost(iframe, { type: "DAVA_GET_SVG", requestId: payload && payload.requestId || String(Date.now()) });
    });

    Shiny.addCustomMessageHandler("dava-svgedit-command", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      var command = payload && payload.command;
      if (command === "DAVA_GET_SVG") {
        queueOrPost(iframe, { type: "DAVA_GET_SVG", requestId: payload.requestId || String(Date.now()) });
      } else if (command === "DAVA_CLEAR") {
        queueOrPost(iframe, { type: "DAVA_CLEAR_SVG" });
      } else if (command === "DAVA_OPEN_SAVE_DIALOG") {
        queueOrPost(iframe, { type: "DAVA_OPEN_SAVE_DIALOG", source: payload.source || "toolbar" });
      } else if (command === "DAVA_REQUEST_EXIT") {
        queueOrPost(iframe, { type: "DAVA_REQUEST_EXIT" });
      }
    });

    Shiny.addCustomMessageHandler("dava-svgedit-gallery-state", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      queueOrPost(iframe, {
        type: "DAVA_GALLERY_STATE",
        defaultName: payload && payload.defaultName || "SVGEdit"
      });
    });

    Shiny.addCustomMessageHandler("dava-svgedit-save-confirmed", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      postNow(iframe, {
        type: "DAVA_SAVE_COMPLETED",
        hostRequestId: payload && payload.requestId || stateFor(iframe).pendingHostSaveRequestId || "",
        galleryName: payload && payload.galleryName || stateFor(iframe).pendingGalleryName || "",
        time: Date.now()
      });
      stateFor(iframe).pendingHostSaveRequestId = "";
      stateFor(iframe).pendingGalleryName = "";
    });

    Shiny.addCustomMessageHandler("svg_document_saved_to_gallery", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      postNow(iframe, {
        type: "DAVA_DOCUMENT_SAVED_TO_GALLERY",
        documentId: payload && payload.documentId || "",
        saved: !payload || payload.saved !== false,
        galleryName: payload && payload.galleryName || "",
        time: Date.now()
      });
    });

    Shiny.addCustomMessageHandler("svg_editor_export_result", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      postNow(iframe, {
        type: "DAVA_EXPORT_RESULT",
        payload: payload || {}
      });
    });

    Shiny.addCustomMessageHandler("open_svg_export_panel", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      queueOrPost(iframe, { type: "DAVA_OPEN_EXPORT_PANEL" });
    });

    Shiny.addCustomMessageHandler("open_pdf_import_panel", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      queueOrPost(iframe, { type: "DAVA_OPEN_PDF_IMPORT_PANEL" });
    });

    Shiny.addCustomMessageHandler("pdf_conversion_result", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      queueOrPost(iframe, { type: "DAVA_PDF_CONVERSION_RESULT", payload: payload || {} });
    });

    Shiny.addCustomMessageHandler("import_converted_pdf_svg", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      queueOrPost(iframe, { type: "DAVA_PDF_CONVERSION_RESULT", payload: payload || {} });
    });

    Shiny.addCustomMessageHandler("pdf_import_error", function (payload) {
      var iframe = findIframe(payload);
      if (!iframe) return;
      queueOrPost(iframe, { type: "DAVA_PDF_IMPORT_ERROR", message: payload && (payload.message || payload.error) || "PDF import failed." });
    });
  }

  window.addEventListener("message", function (event) {
    var message = event.data || {};
    if (!message || message.source !== "DAVA_SVGEDIT_BRIDGE") return;

    var iframe = findIframeForWindow(event.source);
    if (!iframe) return;
    var root = moduleRoot(iframe);
    if (exitedIframes.has(iframe) || (root && root.classList.contains("is-exiting"))) return;

    if (message.type === "DAVA_SVGEDIT_READY" || message.type === "DAVA_SVG_READY") {
      restoreIframe(iframe);
      stateFor(iframe).editorReady = true;
      notify(iframe, "SVG 编辑器已加载", "ready");
      sendInputValue(iframe, iframe.dataset.davaReadyInput, "svgedit_ready", true);
      flushPending(iframe);
      postMenuState(iframe);
    } else if (message.type === "DAVA_HOST_ACTION") {
      triggerHostAction(iframe, message.action || "", message);
    } else if (message.type === "DAVA_TOGGLE_HOST_TOOLBAR") {
      toggleToolbar(iframe, typeof message.collapsed === "boolean" ? message.collapsed : undefined);
    } else if (message.type === "DAVA_TOGGLE_APP_HEADER") {
      toggleAppHeader(iframe, typeof message.collapsed === "boolean" ? message.collapsed : undefined);
    } else if (message.type === "DAVA_SVG_CHANGED") {
      sendInputValue(iframe, iframe.dataset.davaChangedInput, "svgedit_changed", { reason: message.reason || "changed", time: Date.now() });
    } else if (message.type === "DAVA_SVG_IMPORTED") {
      notify(iframe, "SVG-Edit 已完成导入", message.warning ? "warning" : "ready");
      sendInputValue(iframe, iframe.dataset.davaImportDoneInput, "svgedit_import_done", {
        object_id: message.object_id || null,
        warning: message.warning || null,
        time: Date.now()
      });
      window.requestAnimationFrame(function () { focusSvgEditor(iframe); });
    } else if (message.type === "DAVA_SVG_IMPORT_ERROR") {
      console.error("[DAVA SVG-Edit host] Import failed:", message.error || message.message || message);
      notify(iframe, message.error || "SVG-Edit 导入失败", "error");
      sendInputValue(iframe, iframe.dataset.davaImportErrorInput, "svgedit_import_error", message.error || message.message || "SVG-Edit 导入失败");
    } else if (message.type === "DAVA_SVG_EXPORTED") {
      notify(iframe, "SVG 编辑结果已保存到 DAVA", "saved");
      sendInputValue(iframe, iframe.dataset.davaSaveMetaInput, "svgedit_save_meta", {
        gallery_name: stateFor(iframe).pendingGalleryName || "",
        request_id: stateFor(iframe).pendingHostSaveRequestId || "",
        time: Date.now()
      });
      sendInputValue(iframe, iframe.dataset.davaEditedSvgInput, "edited_svg", message.svg || "");
      sendInputValue(iframe, iframe.dataset.davaEditedSvgFromSvgeditInput, "edited_svg_from_svgedit", message.svg || "");
    } else if (message.type === "DAVA_PDF_IMPORT_REQUEST_UPLOAD") {
      var prefix = nsPrefix(iframe);
      var input = prefix ? document.getElementById(prefix + "svgedit_pdf_import_file") : null;
      if (!input) input = document.querySelector("input[type='file'][id$='svgedit_pdf_import_file']");
      if (input) input.click();
    } else if (message.type === "DAVA_PDF_IMPORT_CONVERT_REQUEST") {
      if (window.Shiny && Shiny.setInputValue) {
        var request = message || {};
        Shiny.setInputValue(nsPrefix(iframe) + "pdf_import_convert_request", request, { priority: "event" });
      }
    } else if (message.type === "DAVA_SVG_DOCUMENT_RESULT") {
      if (window.Shiny && Shiny.setInputValue) {
        var payload = message.payload || {};
        var envelope = {
          documentId: payload.documentId || "",
          artboardId: payload.artboardId || payload.documentId || "",
          documentName: payload.documentName || "",
          eventType: message.eventType || "svg_editor_event",
          payload: payload,
          timestamp: payload.timestamp || Date.now()
        };
        Shiny.setInputValue(nsPrefix(iframe) + "svg_editor_event", envelope, { priority: "event" });
      }
    } else if (message.type === "DAVA_SVGEDIT_ERROR" || message.type === "DAVA_SVG_ERROR") {
      console.error("[DAVA SVG-Edit host] Bridge error:", message.error || message.message || message);
      notify(iframe, message.error || message.message || "SVG-Edit API 未识别", "error");
      sendInputValue(iframe, iframe.dataset.davaErrorInput, "svgedit_error", message.error || message.message || "SVG-Edit API 未识别");
    }
  });

  document.addEventListener("click", function (event) {
    var button = event.target.closest("[data-dava-svgedit-action]");
    if (!button) return;
    var root = button.closest("[data-dava-svgedit-root='1']");
    var iframe = root ? root.querySelector("[data-dava-svgedit-iframe='1']") : null;
    var action = button.dataset.davaSvgeditAction;
    if (action === "save") {
      queueOrPost(iframe, { type: "DAVA_OPEN_SAVE_DIALOG", source: "toolbar" });
    } else if (action === "clear") {
      queueOrPost(iframe, { type: "DAVA_CLEAR_SVG" });
    } else if (action === "exit") {
      if (!isReady(iframe) || !queueOrPost(iframe, { type: "DAVA_REQUEST_EXIT" })) exitEditor(iframe);
    }
  });

  document.addEventListener("change", function (event) {
    if (!event.target || !event.target.closest) return;
    if (event.target.id === "main_nav" && event.target.value === "plot_layout") {
      restoreIframe(findIframe({}));
      return;
    }
    var root = event.target.closest("[data-dava-svgedit-root='1']");
    if (!root) return;
    var iframe = root.querySelector("[data-dava-svgedit-iframe='1']");
    if (event.target.matches(".dava-svgedit-source select")) {
      postMenuState(iframe);
    }
  });

  document.addEventListener("shown.bs.tab", function (event) {
    var target = event.target;
    var value = target && (target.getAttribute("data-value") || "");
    if (value === "plot_layout") restoreIframe(findIframe({}));
  });

  registerHandlers();
  document.addEventListener("shiny:connected", registerHandlers);
  window.DavaSvgEditHost = {
    postToIframe: queueOrPost,
    isReady: isReady,
    exitEditor: exitEditor,
    flushPending: flushPending
  };
})();
