(function () {
  "use strict";

  if (window.davaCodeWorkbenchBound) return;
  window.davaCodeWorkbenchBound = true;
  var editorRecords = new WeakMap();
  var retryTimers = new WeakMap();
  var layoutTimers = new WeakMap();

  function refreshParameterMarkers(editor) {
    if (!editor || !window.ace) return;
    var session = editor.session;
    var previous = editor._davaParameterMarkers || [];
    previous.forEach(function (id) { session.removeMarker(id); });
    (editor._davaParameterRows || []).forEach(function (row) {
      session.removeGutterDecoration(row, "dava-ui-parameter-gutter");
    });
    editor._davaParameterMarkers = [];
    editor._davaParameterRows = [];
    var Range = window.ace.require("ace/range").Range;
    session.getDocument().getAllLines().forEach(function (line, row) {
      if (line.indexOf("<DAVA-UI-PARAM>") < 0) return;
      var marker = session.addMarker(
        new Range(row, 0, row, Math.max(1, line.length)),
        "dava-ui-parameter-marker", "text", false
      );
      editor._davaParameterMarkers.push(marker);
      editor._davaParameterRows.push(row);
      session.addGutterDecoration(row, "dava-ui-parameter-gutter");
    });
  }

  function workspaceFor(editor) {
    return editor && editor.container.closest(".dava-code-workspace");
  }

  function closeMenus() {
    document.querySelectorAll(".dava-ace-context-menu.is-open").forEach(function (menu) {
      menu.classList.remove("is-open");
    });
  }

  function updateEditorStatus(editor) {
    var workspace = workspaceFor(editor);
    if (!workspace) return;
    var cursor = editor.getCursorPosition();
    var selected = editor.getSelectedText();
    var position = workspace.querySelector(".dava-code-status-position");
    var selection = workspace.querySelector(".dava-code-status-selection");
    if (position) position.textContent = "行 " + (cursor.row + 1) + "，列 " + (cursor.column + 1);
    if (selection) selection.textContent = selected ? "已选择 " + selected.length + " 个字符" : "未选择代码";
  }

  function editorForNode(node) {
    if (!node || !window.ace) return null;
    var editor = node.env && node.env.editor ? node.env.editor : window.ace.edit(node);
    if (editor && window.jQuery && window.jQuery(node).data("aceEditor") !== editor) {
      window.jQuery(node).data("aceEditor", editor);
    }
    return editor || null;
  }

  function synchronizeEditorLayout(node) {
    if (!node || !node.isConnected || node.offsetParent === null) return;
    var editor = initializeEditor(node, 0);
    if (!editor) return;
    var previousTimer = layoutTimers.get(node);
    if (previousTimer) window.clearTimeout(previousTimer);

    window.requestAnimationFrame(function () {
      if (!node.isConnected || node.offsetParent === null) return;
      editor.resize(true);
      if (editor.renderer && editor.renderer.updateFull) editor.renderer.updateFull(true);
      window.requestAnimationFrame(function () {
        if (!node.isConnected || node.offsetParent === null) return;
        editor.resize(true);
        if (editor.renderer && editor.renderer.updateFull) editor.renderer.updateFull(true);
        updateEditorStatus(editor);
      });
    });

    var timer = window.setTimeout(function () {
      layoutTimers.delete(node);
      if (!node.isConnected || node.offsetParent === null) return;
      editor.resize(true);
      if (editor.renderer && editor.renderer.updateFull) editor.renderer.updateFull(true);
    }, 180);
    layoutTimers.set(node, timer);
  }

  function synchronizeVisibleEditors(root) {
    var scope = root && root.querySelectorAll ? root : document;
    if (scope.matches && scope.matches(".dava-code-workspace .ace_editor")) {
      synchronizeEditorLayout(scope);
    }
    scope.querySelectorAll(".dava-code-workspace .ace_editor").forEach(synchronizeEditorLayout);
  }

  function scheduleInitialization(node, attempt) {
    if (!node || retryTimers.has(node) || attempt > 20) return;
    var delay = Math.min(50 * Math.pow(1.35, attempt), 800);
    var timer = window.setTimeout(function () {
      retryTimers.delete(node);
      initializeEditor(node, attempt + 1);
    }, delay);
    retryTimers.set(node, timer);
  }

  function initializeEditor(node, attempt) {
    if (!node || !node.isConnected) return null;
    var editor = editorForNode(node);
    if (!editor) {
      scheduleInitialization(node, attempt || 0);
      return null;
    }
    var current = editorRecords.get(node);
    if (current && current.editor === editor) return editor;

    node.dataset.davaWorkbenchReady = "true";
    editor.setReadOnly(false);
    editor.setOptions({
      highlightActiveLine: true,
      highlightSelectedWord: true,
      selectionStyle: "text",
      behavioursEnabled: true,
      dragEnabled: true,
      showPrintMargin: false
    });
    editor.selection.on("changeCursor", function () { updateEditorStatus(editor); });
    editor.selection.on("changeSelection", function () { updateEditorStatus(editor); });
    editor.session.on("change", function () {
      updateEditorStatus(editor);
      window.clearTimeout(editor._davaMarkerTimer);
      editor._davaMarkerTimer = window.setTimeout(function () {
        refreshParameterMarkers(editor);
      }, 40);
    });
    editor.on("focus", function () { updateEditorStatus(editor); });
    var resizeObserver = null;
    if (window.ResizeObserver) {
      resizeObserver = new ResizeObserver(function () {
        if (node.offsetParent !== null) synchronizeEditorLayout(node);
      });
      resizeObserver.observe(node.parentElement || node);
    }
    editorRecords.set(node, {
      editor: editor,
      resizeObserver: resizeObserver
    });
    updateEditorStatus(editor);
    refreshParameterMarkers(editor);
    synchronizeEditorLayout(node);
    return editor;
  }

  function initializeEditors(root) {
    var scope = root && root.querySelectorAll ? root : document;
    if (scope.matches && scope.matches(".dava-code-workspace .ace_editor")) initializeEditor(scope, 0);
    scope.querySelectorAll(".dava-code-workspace .ace_editor").forEach(function (node) {
      initializeEditor(node, 0);
    });
  }

  async function editClipboard(editor, action) {
    var selected = editor.getSelectedText();
    if (action === "copy" && selected) await navigator.clipboard.writeText(selected);
    if (action === "cut" && selected) {
      await navigator.clipboard.writeText(selected);
      editor.session.replace(editor.getSelectionRange(), "");
    }
    if (action === "paste") {
      var text = await navigator.clipboard.readText();
      editor.session.replace(editor.getSelectionRange(), text);
    }
    if (action === "select-all") editor.selectAll();
    if (action === "undo") editor.undo();
    if (action === "redo") editor.redo();
    editor.focus();
    updateEditorStatus(editor);
  }

  function clickWorkspaceCommand(editor, suffix) {
    var workspace = workspaceFor(editor);
    if (window.Shiny) {
      Shiny.setInputValue(editor.container.id, editor.getValue(), { priority: "event" });
    }
    var button = workspace && workspace.querySelector('[id$="' + suffix + '"]');
    if (button) button.click();
    editor.focus();
  }

  document.addEventListener("contextmenu", function (event) {
    var editorNode = event.target.closest(".dava-code-workspace .ace_editor");
    if (!editorNode) return;
    var editor = initializeEditor(editorNode, 0);
    if (!editor) return;
    event.preventDefault();
    closeMenus();
    var workspace = editorNode.closest(".dava-code-workspace");
    var menu = workspace && workspace.querySelector(".dava-ace-context-menu");
    if (!menu) return;
    menu._davaEditor = editor;
    menu.style.left = Math.max(4, Math.min(event.clientX, window.innerWidth - 230)) + "px";
    menu.style.top = Math.max(4, Math.min(event.clientY, window.innerHeight - 250)) + "px";
    menu.classList.add("is-open");
  });

  document.addEventListener("mousedown", function (event) {
    var consoleButton = event.target.closest('.dava-console-command button[id$="module_code_console_run"]');
    if (consoleButton && window.Shiny) {
      var commandBox = consoleButton.closest(".dava-console-command").querySelector('input[id$="module_code_console_input"]');
      if (commandBox) Shiny.setInputValue(commandBox.id, commandBox.value, { priority: "event" });
    }
    if (event.target.closest(".dava-code-toolbar .btn")) {
      var workspace = event.target.closest(".dava-code-workspace");
      var editorNode = workspace && workspace.querySelector(".ace_editor");
      var editor = editorForNode(editorNode);
      if (editor && window.Shiny) {
        Shiny.setInputValue(editorNode.id, editor.getValue(), { priority: "event" });
      }
      event.preventDefault();
    }
    if (!event.target.closest(".dava-ace-context-menu")) closeMenus();
  });

  document.addEventListener("click", async function (event) {
    var item = event.target.closest(".dava-ace-context-menu button[data-action]");
    if (!item) return;
    var menu = item.closest(".dava-ace-context-menu");
    var editor = menu && menu._davaEditor;
    var action = item.dataset.action;
    closeMenus();
    if (!editor) return;
    if (action === "run") return clickWorkspaceCommand(editor, "module_code_run_selection");
    if (action === "run-all") return clickWorkspaceCommand(editor, "module_code_run");
    try {
      await editClipboard(editor, action);
    } catch (error) {
      editor.focus();
      if (window.Shiny && Shiny.notifications && typeof Shiny.notifications.show === "function") {
        Shiny.notifications.show({
          html: "剪贴板操作失败，请使用 Ctrl+C、Ctrl+X 或 Ctrl+V。",
          type: "warning",
          duration: 4
        });
      } else {
        console.warn("DAVA clipboard action failed", error);
      }
    }
  });

  document.addEventListener("keydown", function (event) {
    var input = event.target.closest('input[id$="module_code_console_input"]');
    if (!input) return;
    input._davaHistory = input._davaHistory || [];
    if (event.key === "Enter") {
      event.preventDefault();
      if (input.value.trim()) input._davaHistory.push(input.value);
      input._davaHistoryIndex = input._davaHistory.length;
      var workspace = input.closest(".dava-code-workspace");
      var button = workspace && workspace.querySelector('[id$="module_code_console_run"]');
      if (window.Shiny) Shiny.setInputValue(input.id, input.value, { priority: "event" });
      if (button) button.click();
    }
    if (event.key === "ArrowUp" && input._davaHistory.length) {
      event.preventDefault();
      input._davaHistoryIndex = Math.max(0, (input._davaHistoryIndex || input._davaHistory.length) - 1);
      input.value = input._davaHistory[input._davaHistoryIndex] || "";
    }
    if (event.key === "ArrowDown" && input._davaHistory.length) {
      event.preventDefault();
      input._davaHistoryIndex = Math.min(input._davaHistory.length, (input._davaHistoryIndex || 0) + 1);
      input.value = input._davaHistory[input._davaHistoryIndex] || "";
    }
  });

  var observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      mutation.addedNodes.forEach(function (node) {
        if (node.nodeType === 1) initializeEditors(node);
      });
    });
  });

  function start() {
    initializeEditors(document);
    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
  document.addEventListener("shiny:connected", function () { initializeEditors(document); });
  function handleVisibleLayoutChange() {
    initializeEditors(document);
    synchronizeVisibleEditors(document);
  }

  // Bootstrap 3 emits tab lifecycle events through jQuery, not native DOM events.
  if (window.jQuery) {
    window.jQuery(document).on("shown.bs.tab", handleVisibleLayoutChange);
  }
  document.addEventListener("transitionend", function (event) {
    if (event.target.closest && event.target.closest(".dava-code-workspace, .tab-content")) {
      synchronizeVisibleEditors(document);
    }
  });
  window.DavaCodeWorkbench = {
    initialize: handleVisibleLayoutChange,
    getEditor: function (id) { return editorForNode(document.getElementById(id)); },
    inspect: function (id) {
      var node = document.getElementById(id);
      var editor = editorForNode(node);
      if (!node || !editor) return { ready: false };
      return {
        ready: true,
        focused: editor.isFocused(),
        readOnly: editor.getReadOnly(),
        cursor: editor.getCursorPosition(),
        selection: editor.getSelectionRange()
      };
    }
  };

  window.addEventListener("blur", closeMenus);
  window.addEventListener("resize", closeMenus);
  document.addEventListener("scroll", closeMenus, true);
})();
