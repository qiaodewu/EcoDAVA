(function () {
  if (window.davaNetworkColourPickerReady) return;
  window.davaNetworkColourPickerReady = true;

  function targetFor(element) {
    if (element.dataset && element.dataset.target) return element.dataset.target;
    var owner = element.closest("[data-target]");
    return owner ? owner.dataset.target : "";
  }

  function normaliseColour(value) {
    value = String(value || "").trim();
    if (/^#[0-9a-f]{3}$/i.test(value)) {
      value = "#" + value.slice(1).split("").map(function (part) {
        return part + part;
      }).join("");
    }
    return /^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(value)
      ? value.toUpperCase() : "";
  }

  function updateTrigger(target, colour) {
    document.querySelectorAll(".dava-network-colour-trigger").forEach(function (trigger) {
      if (trigger.dataset.target === target) {
        trigger.style.background = colour;
        trigger.setAttribute("aria-label", "Current colour " + colour);
      }
    });
  }

  function setColour(target, colour) {
    colour = normaliseColour(colour);
    if (!target || !colour) return;
    var input = document.getElementById(target);
    if (input) {
      input.value = colour;
      input.dispatchEvent(new Event("change", { bubbles: true }));
    }
    updateTrigger(target, colour);
    if (window.Shiny && Shiny.setInputValue) {
      Shiny.setInputValue(target, colour, { priority: "event" });
    }
  }

  function hexToRgb(hex) {
    var value = parseInt(hex.slice(1), 16);
    return [(value >> 16) & 255, (value >> 8) & 255, value & 255];
  }

  function rgbToHex(rgb) {
    return "#" + rgb.map(function (value) {
      return Math.round(value).toString(16).padStart(2, "0");
    }).join("").toUpperCase();
  }

  function mix(start, end, fraction) {
    var first = hexToRgb(start);
    var second = hexToRgb(end);
    return rgbToHex(first.map(function (value, index) {
      return value + (second[index] - value) * fraction;
    }));
  }

  function renderGradient(panel) {
    var start = normaliseColour(panel.querySelector(".dava-gradient-start").value);
    var end = normaliseColour(panel.querySelector(".dava-gradient-end").value);
    var steps = Number(panel.querySelector(".dava-gradient-steps").value || 7);
    var output = panel.querySelector(".dava-gradient-swatches");
    var preview = panel.querySelector(".dava-gradient-preview");
    if (!start || !end || !output) return;
    steps = Math.max(3, Math.min(15, steps));
    preview.style.background = "linear-gradient(90deg," + start + "," + end + ")";
    output.replaceChildren();
    for (var index = 0; index < steps; index += 1) {
      var colour = mix(start, end, index / (steps - 1));
      var button = document.createElement("button");
      button.type = "button";
      button.className = "dava-network-colour-swatch";
      button.dataset.target = panel.dataset.target;
      button.dataset.colour = colour;
      button.title = colour;
      button.style.background = colour;
      output.appendChild(button);
    }
  }

  document.addEventListener("click", function (event) {
    var swatch = event.target.closest(".dava-network-colour-swatch");
    if (swatch) {
      event.preventDefault();
      setColour(targetFor(swatch), swatch.dataset.colour);
    }
  });

  document.addEventListener("input", function (event) {
    if (event.target.matches(".dava-network-colour-mixer")) {
      setColour(targetFor(event.target), event.target.value);
    } else if (event.target.matches(".dava-network-colour-hex")) {
      var typedColour = normaliseColour(event.target.value);
      if (typedColour) updateTrigger(event.target.id, typedColour);
    } else if (event.target.matches(
      ".dava-gradient-start,.dava-gradient-end,.dava-gradient-steps")) {
      var panel = event.target.closest(".dava-network-gradient-panel");
      if (panel) renderGradient(panel);
    }
  });

  document.addEventListener("change", function (event) {
    if (event.target.matches(".dava-network-colour-hex")) {
      var colour = normaliseColour(event.target.value);
      if (colour) {
        event.target.value = colour;
        updateTrigger(event.target.id, colour);
      }
    }
  });

  document.addEventListener("shown.bs.popover", function () {
    document.querySelectorAll(".dava-network-gradient-panel").forEach(renderGradient);
  });
})();
