options(encoding = "UTF-8")
options(shiny.maxRequestSize = max(
  getOption("shiny.maxRequestSize", 0), 512 * 1024^2))

dava_source <- function(path) {
  bytes <- readBin(path, what = "raw", n = file.info(path)[["size"]])
  code <- rawToChar(bytes)
  Encoding(code) <- "UTF-8"
  code <- sub("^\ufeff", "", code)
  code <- gsub("\r\n?", "\n", code)
  expr <- suppressWarnings(parse(text = code, encoding = "UTF-8", keep.source = FALSE))
  eval(expr, envir = .GlobalEnv)
}

dava_source("R/helpers.R")
dava_configure_shiny_graphics()
dava_source("R/i18n.R")
dava_source("R/help_pages.R")
dava_source("R/module_support/code_document.R")
dava_source("R/module_support/module_code_support.R")
dava_source("R/demo_data/local_demo_datasets.R")
dava_source("R/demo_data/ecology_demo_data.R")
dava_source("R/module_support/mod_code_plugin_manager.R")
dava_source("R/module_support/external_plugin_apps.R")
dava_source("R/module_support/workspace_state.R")
dava_source("R/statistical_analysis/stat_significance_core.R")
dava_source("R/statistical_analysis/stat_effect_hierarchy.R")
dava_source("R/statistical_analysis/stat_emmeans_helpers.R")
dava_source("R/statistical_analysis/stat_annotation_positions.R")
dava_source("R/statistical_analysis/stat_annotation_plot.R")
dava_source("R/statistical_analysis/stat_methods.R")
dava_source("R/statistical_analysis/plot_methods.R")
dava_source("R/statistical_analysis/regression_model_registry.R")
dava_source("R/statistical_analysis/regression_result_formatter.R")
dava_source("R/statistical_analysis/regression_formula_builder.R")
dava_source("R/statistical_analysis/regression_data_prepare.R")
dava_source("R/statistical_analysis/regression_prediction_engine.R")
dava_source("R/statistical_analysis/regression_diagnostics_engine.R")
dava_source("R/statistical_analysis/regression_fit_engine.R")
dava_source("R/statistical_analysis/regression_plot_engine.R")
dava_source("R/statistical_analysis/regression_output_registry.R")
dava_source("R/SVG_Edit/svg_edit_normalize.R")
dava_source("R/SVG_Edit/pdf_to_svg_pipeline.R")
dava_source("R/SVG_Edit/pdf_svg_cleaner.R")
dava_source("R/SVG_Edit/pdf_import_server.R")
dava_source("R/SVG_Edit/svg_export_tools.R")
dava_source("R/SVG_Edit/svg_export_cleaner.R")
dava_source("R/SVG_Edit/svg_export_pdf.R")
dava_source("R/SVG_Edit/svg_export_tiff.R")
dava_source("R/SVG_Edit/svg_export_pipeline.R")
dava_source("R/SVG_Edit/svg_export_server.R")
dava_source("R/file_management/mod_file_manager.R")
dava_source("R/statistical_analysis/mod_norm_variance.R")
dava_source("R/Style.R")
dava_source("R/statistical_analysis/t_test_mode.R")
dava_source("R/statistical_analysis/correlation_code_template.R")
dava_source("R/statistical_analysis/mod_advanced_analysis.R")
dava_source("R/variable_importance/importance_registry.R")
dava_source("R/variable_importance/importance_engine.R")
dava_source("R/variable_importance/mod_variable_importance.R")
dava_source("R/plotting/mod_plotting.R")
dava_source("R/analysis_library/mod_analysis_library.R")
dava_source("R/microbiome/00_bootstrap.R")
dava_source("R/structural_sem/00_bootstrap.R")
dava_source("R/platform_compatibility.R")

lazy_placeholder <- function(output_id) {
  uiOutput(output_id)
}

lazy_placeholder_message <- function(label = "page") {
  tags$div(
    class = "p-4 text-muted",
    tags$strong("Page to be loaded"),
    tags$div(paste0(label, "will be loaded when first opened."))
  )
}

dava_selectize_bootstrap_dependency <- function() {
  probe <- shiny::selectizeInput(
    "dava_selectize_dependency_probe", label = NULL,
    choices = character())
  dependencies <- Filter(function(dependency) {
    identical(dependency$name, "selectize")
  }, htmltools::findDependencies(probe))
  htmltools::attachDependencies(
    tags$span(style = "display:none", `aria-hidden` = "true"),
    dependencies)
}

home_page_ui <- function() {
  tags$div(
    class = "dava-home",
    tags$style(HTML("
      .dava-home {
        min-height: calc(100vh - 96px);
        padding: 28px;
        background:
          linear-gradient(135deg, rgba(246,250,250,0.94), rgba(234,244,241,0.92)),
          url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='1600' height='900' viewBox='0 0 1600 900'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%2316323c'/%3E%3Cstop offset='1' stop-color='%233b7ea1'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='1600' height='900' fill='url(%23g)'/%3E%3Cg opacity='.20' fill='none' stroke='%23ffffff' stroke-width='2'%3E%3Cpath d='M80 680C250 520 410 650 570 490S870 260 1120 360s310-10 420-130'/%3E%3Cpath d='M120 210c150 90 260 80 410-20s270-130 470-30 340 120 520 20'/%3E%3Ccircle cx='285' cy='560' r='74'/%3E%3Ccircle cx='1220' cy='240' r='112'/%3E%3C/g%3E%3Cg opacity='.16' fill='%23ffffff'%3E%3Ccircle cx='190' cy='170' r='7'/%3E%3Ccircle cx='380' cy='260' r='5'/%3E%3Ccircle cx='610' cy='180' r='8'/%3E%3Ccircle cx='845' cy='305' r='6'/%3E%3Ccircle cx='1075' cy='188' r='7'/%3E%3Ccircle cx='1375' cy='325' r='5'/%3E%3Ccircle cx='470' cy='670' r='6'/%3E%3Ccircle cx='920' cy='625' r='8'/%3E%3Ccircle cx='1310' cy='690' r='7'/%3E%3C/g%3E%3C/svg%3E\");
        background-size: cover;
        background-position: center;
      }
      .dava-hero {
        display: grid;
        grid-template-columns: minmax(0, 1.35fr) minmax(320px, 0.65fr);
        gap: 22px;
        align-items: stretch;
        margin-bottom: 22px;
      }
      .dava-hero-main {
        padding: 30px;
        border: 1px solid #d8e4e8;
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.92);
        backdrop-filter: blur(8px);
        box-shadow: 0 16px 42px rgba(31, 53, 68, 0.08);
      }
      .dava-eyebrow {
        color: #3b7ea1;
        font-weight: 700;
        letter-spacing: 0;
        margin-bottom: 8px;
      }
      .dava-hero h1 {
        margin: 0;
        font-size: 34px;
        line-height: 1.2;
        color: #162b36;
        letter-spacing: 0;
      }
      .dava-hero-translation {
        margin: 8px 0 0 0;
        font-size: 34px;
        line-height: 1.2;
        color: #162b36;
        letter-spacing: 0;
      }
      html[data-dava-language=\"en\"] .dava-hero-translation { display: none; }
      .dava-hero p {
        margin: 12px 0 0 0;
        color: #526672;
        font-size: 15px;
        line-height: 1.65;
        max-width: 850px;
      }
      .dava-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 22px;
      }
      .dava-actions .btn {
        border-radius: 6px;
        padding: 9px 14px;
        font-weight: 650;
      }
      .dava-status {
        border: 1px solid rgba(255,255,255,0.22);
        border-radius: 8px;
        background: rgba(23, 51, 61, 0.94);
        color: #f8fbfc;
        padding: 22px;
        box-shadow: 0 16px 42px rgba(31, 53, 68, 0.10);
        backdrop-filter: blur(8px);
      }
      .dava-status h3 {
        margin: 0 0 14px 0;
        font-size: 17px;
      }
      .dava-stat-line {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        border-top: 1px solid rgba(255,255,255,0.16);
        padding: 12px 0;
        color: #dbe8ec;
      }
      .dava-stat-line strong {
        color: #ffffff;
        font-size: 15px;
        text-align: right;
        overflow-wrap: anywhere;
      }
      .dava-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 14px;
      }
      .dava-tile {
        border: 1px solid rgba(216, 228, 232, 0.88);
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.92);
        padding: 18px;
        min-height: 156px;
        box-shadow: 0 12px 28px rgba(31, 53, 68, 0.06);
        backdrop-filter: blur(6px);
      }
      .dava-tile .fa, .dava-tile .fas {
        color: #3b7ea1;
      }
      .dava-tile h3 {
        margin: 10px 0 8px 0;
        font-size: 17px;
        color: #1d3440;
      }
      .dava-tile p {
        color: #5b6d76;
        line-height: 1.55;
        margin: 0;
        font-size: 13px;
      }
      @media (max-width: 1000px) {
        .dava-hero { grid-template-columns: 1fr; }
        .dava-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      }
      @media (max-width: 640px) {
        .dava-home { padding: 16px; }
        .dava-grid { grid-template-columns: 1fr; }
        .dava-hero h1, .dava-hero-translation { font-size: 26px; }
      }
    ")),
    tags$div(
      class = "dava-hero",
      tags$section(
        class = "dava-hero-main",
        tags$h1(`data-dava-i18n-role` = "original", "EcoDAVA: ecological data analysis and visualization assistant"),
        tags$div(class = "dava-hero-translation", "Ecological data analysis and visualization assistant"),
        tags$div(
          class = "dava-actions",
          actionButton("home_open_file", "Open file management", icon = icon("folder-open"), class = "btn-primary"),
          actionButton("home_open_microbe", "Microbial analysis", icon = icon("dna"), class = "btn-outline-primary"),
          actionButton("home_open_plot", "Scientific plots", icon = icon("chart-line"), class = "btn-outline-primary"),
          actionButton("home_open_stats", "Statistical analysis", icon = icon("calculator"), class = "btn-outline-primary")
        )
      ),
      tags$aside(
        class = "dava-status",
        tags$h3("Current workspace"),
        tags$div(class = "dava-stat-line", tags$span("Dataset loaded"), tags$strong(textOutput("home_dataset_count", inline = TRUE))),
        tags$div(class = "dava-stat-line", tags$span("Current data set"), tags$strong(textOutput("home_active_dataset", inline = TRUE))),
        tags$div(class = "dava-stat-line", tags$span("R language version"), tags$strong(textOutput("home_r_version", inline = TRUE))),
        tags$div(class = "dava-stat-line", tags$span("working path"), tags$strong(textOutput("home_workdir", inline = TRUE))),
        tags$div(class = "dava-stat-line", tags$span("Operating platform"), tags$strong(textOutput("home_platform", inline = TRUE))),
        tags$div(class = "dava-stat-line", tags$span("Startup time"), tags$strong(textOutput("home_started_at", inline = TRUE))),
        tags$div(class = "dava-stat-line", tags$span("Loading strategy"), tags$strong("On demand"))
      )
    ),
    tags$section(
      class = "dava-grid",
      tags$div(class = "dava-tile", icon("table"), tags$h3("Data preparation"), tags$p("The file management module is loaded when it is first opened, and supports multi-table import, editing, sorting and result writeback.")),
      tags$div(class = "dava-tile", icon("microscope"), tags$h3("Microbial analysis"), tags$p("OTU, classification annotation, grouping and environment variable table preparation, automatic suitability check.")),
      tags$div(class = "dava-tile", icon("chart-pie"), tags$h3("Paper drawing"), tags$p("Drawing modules such as boxplots, composition diagrams, correlation heat maps, and network diagrams are loaded on a page-by-page basis.")),
      tags$div(class = "dava-tile", icon("square-root-alt"), tags$h3("Statistical modeling"), tags$p("Tests, ANOVA, regression, dimensionality reduction, structural equations, and variable importance analysis are launched on demand."))
    )
  )
}

workspace_import_page_ui <- function() {
  bslib::page_sidebar(
    title = "Import working environment",
    sidebar = bslib::sidebar(
      width = 340,
      fileInput("workspace_nav_file", "Select DAVA work environment",
        accept = c(".davaws", ".rds")),
      actionButton("workspace_nav_import", "Import and restore",
        icon = icon("folder-open"), class = "btn-primary w-100"),
      tags$div(class = "small text-muted mt-2",
        "Support for DAVA work environment (.davaws) and compatible RDS files."),
      textOutput("workspace_nav_import_status")
    ),
    tags$section(
      class = "p-4",
      tags$h3("Current workspace"),
      uiOutput("workspace_nav_summary")
    )
  )
}

ui <- page_navbar(
  id = "main_nav",
  title = "EcoDAVA",
  theme = bs_theme(version = 5, bootswatch = "flatly"),
  fillable = TRUE,
  header = tagList(
    my_header_style(),
    dava_i18n_dependency(),
    dava_selectize_bootstrap_dependency(),
    dava_workspace_restore_script(),
    tags$script(HTML("
      (function(){
        if (window.davaDynamicScriptRunnerReady) return;
        window.davaDynamicScriptRunnerReady = true;
        function shouldRun(script) {
          if (!script || script.getAttribute('data-dava-dynamic-executed') === '1') return false;
          var text = script.textContent || '';
          return text.indexOf('window.DavaAIEditor') >= 0 ||
                 text.indexOf('window.DavaAIEditorBridge') >= 0 ||
                 text.indexOf('davaVectorCommand') >= 0;
        }
        function runScript(script) {
          if (!shouldRun(script)) return;
          script.setAttribute('data-dava-dynamic-executed', '1');
          var clone = document.createElement('script');
          clone.setAttribute('data-dava-dynamic-executed', '1');
          clone.text = script.textContent || '';
          document.head.appendChild(clone);
          setTimeout(function(){
            if (clone && clone.parentNode) clone.parentNode.removeChild(clone);
          }, 0);
        }
        function scan(root) {
          root = root || document;
          if (root.matches && root.matches('script')) runScript(root);
          var scripts = root.querySelectorAll ? root.querySelectorAll('script') : [];
          Array.prototype.forEach.call(scripts, runScript);
        }
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', function(){ scan(document); });
        } else {
          scan(document);
        }
        var observer = new MutationObserver(function(records){
          records.forEach(function(record){
            Array.prototype.forEach.call(record.addedNodes || [], function(node){
              if (node && node.nodeType === 1) scan(node);
            });
          });
        });
        observer.observe(document.documentElement, {childList:true, subtree:true});
      })();
    "))
  ),

  nav_panel("Home", value = "home", home_page_ui()),

  navbarMenu(
    "File management",
    nav_panel("Microbial data import", value = "micro_import", lazy_placeholder("lazy_micro_import")),
    nav_panel("Dataset importing and editing", value = "file_edit", lazy_placeholder("lazy_file_edit")),
    nav_panel("Import working environment", value = "workspace_import",workspace_import_page_ui()),
    nav_panel("Operation log", value = "file_log", lazy_placeholder("lazy_file_log"))
  ),

  navbarMenu(
    "Ecological statistics",
    nav_panel("Normality-Homogeneity of Variances test", value = "norm_variance", lazy_placeholder("lazy_norm_variance")),
    navbarMenu(
      "t-test",
      nav_panel("One-sample t test", value = "t_one_sample", lazy_placeholder("lazy_t_one_sample")),
      nav_panel("Two-sample t test", value = "t_two_sample", lazy_placeholder("lazy_t_two_sample")),
      nav_panel("Two-sample paired t test", value = "t_two_sample_paired", lazy_placeholder("lazy_t_two_sample_paired"))
    ),
    navbarMenu(
      "Analysis of Variance",
      nav_panel("Completely Randomized ANOVA", value = "anova_crd", lazy_placeholder("lazy_anova_crd")),
      nav_panel("Random block analysis of variance", value = "anova_block", lazy_placeholder("lazy_anova_block")),
      nav_panel("Repeated Measures Analysis of Variance", value = "anova_repeated", lazy_placeholder("lazy_anova_repeated")),
      nav_panel("Analysis of covariance", value = "ancova", lazy_placeholder("lazy_ancova"))
    ),
    navbarMenu(
      "Non-parametric test",
      nav_panel("One-sample Wilcoxon signed-rank test", value = "wilcoxon_one_sample", lazy_placeholder("lazy_wilcoxon_one_sample")),
      nav_panel("Two-sample paired signed-rank test", value = "wilcoxon_paired", lazy_placeholder("lazy_wilcoxon_paired")),
      nav_panel("Two-sample Wilcoxon-Mann-Whitney test", value = "wmw_two_sample", lazy_placeholder("lazy_wmw_two_sample")),
      nav_panel("One-way Kruskal-Wallis test", value = "kw_one_way", lazy_placeholder("lazy_kw_one_way")),
      nav_panel("One-way with Blocks Friedman test", value = "friedman_one_way", lazy_placeholder("lazy_friedman_one_way")),
      nav_panel("Two-way Scheirer-Ray-Hare test", value = "srh_two_way", lazy_placeholder("lazy_srh_two_way")),
      nav_panel("Aligned Ranks Transformation ANOVA", value = "art_anova", lazy_placeholder("lazy_art_anova"))
    ),
    navbarMenu(
      "Linear mixed effects model",
      nav_panel("Linear Mixed Effects Model (LMM)", value = "lmm", lazy_placeholder("lazy_lmm")),
      nav_panel("Generalized Linear Mixed Effects Model (GLMM)", value = "glmm", lazy_placeholder("lazy_glmm"))
    ),
    navbarMenu(
      "Regression model analysis",
      nav_panel("Ordinary least squares regression", value = "reg_classic", lazy_placeholder("lazy_reg_classic")),
      nav_panel("Generalized linear model regression", value = "reg_glm", lazy_placeholder("lazy_reg_glm")),
      nav_panel("Mixed effects model regression", value = "reg_mixed_zero", lazy_placeholder("lazy_reg_mixed_zero")),
      nav_panel("Partial least squares regression", value = "reg_nonlinear_regularized", lazy_placeholder("lazy_reg_nonlinear_regularized")),
      nav_panel("Piecewise threshold regression", value = "reg_mediation", lazy_placeholder("lazy_reg_mediation")),
      nav_panel("Multiple regression tree", value = "reg_community", lazy_placeholder("lazy_reg_community"))
    ),
    navbarMenu(
      "Correlation analysis",
      nav_panel("Correlation analysis", value = "correlation", lazy_placeholder("lazy_correlation")),
      nav_panel("Network correlation analysis", value = "network_correlation", lazy_placeholder("lazy_network_correlation"))
    ),
    nav_panel("Structural Equation Model", value = "sem", lazy_placeholder("lazy_sem")),
    nav_panel("Variable importance analysis", value = "variable_importance", lazy_placeholder("lazy_variable_importance"))
  ),

  microbiome_navbar_menu(),

  navbarMenu(
    "Chart library",
    nav_panel("Data table repository", value = "analysis_data_library", lazy_placeholder("lazy_analysis_data_library")),
    nav_panel("Analysis plot library", value = "analysis_plot_library", lazy_placeholder("lazy_analysis_plot_library")),
    nav_panel("Figure layout and styling", value = "plot_layout", lazy_placeholder("lazy_plot_layout"))
  ),

  navbarMenu(
    "Code and plugin",
    menuName = "code_plugin_manager",
    nav_panel("Code management", value = "code_manager", lazy_placeholder("lazy_code_manager")),
    nav_panel("Plug-in management", value = "plugin_manager", lazy_placeholder("lazy_plugin_manager"))
  ),

  navbarMenu(
    "Help",
    nav_panel("Version and copyright", value = "about", dava_about_page_ui()),
    nav_panel("Documentation", value = "help", dava_help_page_ui()),
    nav_item(actionLink(
      "dava_language_settings", "Language settings", icon = icon("globe"),
      class = "dropdown-item"
    ))
  ),

  nav_spacer(),
  nav_item(actionButton("btn_save", "Save workspace", icon = icon("save"), class = "btn-outline-danger btn-sm", style = "margin: 5px 20px;")),
  nav_item(actionButton("btn_logout", "Exit", icon = icon("sign-out-alt"), class = "btn-outline-danger btn-sm", style = "margin: 5px 20px;"))
)

server <- function(input, output, session) {
  shared_file_rv <- file_manager_state()
  microbiome_method_request <- reactiveVal(NULL)
  microbiome_method_request_serial <- 0L
  # The file manager is the application's shared data service, not merely a
  # page server. Initialise it exactly once before any lazy analysis module so
  # dataset registration, workspace restoration and refresh observers are
  # available regardless of navigation order. Its three UIs remain lazy.
  file_manager <- mod_file_manager_server(
    "file_manager", shared_rv = shared_file_rv)
  external_plugins <- reactiveValues(
    inserted = FALSE, signature = "", entries = dava_external_plugin_scan(),
    instances = list(), errors = list())

  external_plugin_stop_key <- function(key) {
    instance <- isolate(external_plugins$instances[[key]])
    dava_external_plugin_stop(instance)
    instances <- isolate(external_plugins$instances)
    instances[[key]] <- NULL
    external_plugins$instances <- instances
    invisible(TRUE)
  }

  external_plugin_output <- function(entry) {
    nav_value <- entry$nav_value[[1L]]
    output_id <- dava_external_plugin_output_id(nav_value)
    output[[output_id]] <- renderUI({
      instance <- external_plugins$instances[[nav_value]]
      error <- external_plugins$errors[[nav_value]] %||% ""
      if (nzchar(error)) return(tags$div(class = "alert alert-danger m-3", error))
      if (is.null(instance)) return(tags$div(
        class = "p-4 text-muted",
        tags$strong("External application to be started"),
        tags$div("When opening this plug-in for the first time, a read-only copy of the data is created and the quarantine process is started.")))
      tags$iframe(src = instance$url, title = entry$title[[1L]],
        style = "width:100%;height:calc(100vh - 120px);min-height:720px;border:0;background:white;")
    })
  }

  observe({
    shared_file_rv$external_plugin_revision %||% 0L
    settings <- dava_external_plugin_settings()
    entries <- dava_external_plugin_scan()
    signature <- paste(
      isTRUE(settings$show_directory),
      paste(entries$nav_value, entries$title, entries$folder, collapse = "|"),
      sep = "::")
    if (identical(signature, isolate(external_plugins$signature))) return()

    old_entries <- isolate(external_plugins$entries)
    stale <- setdiff(old_entries$nav_value %||% character(),
      entries$nav_value %||% character())
    for (key in stale) external_plugin_stop_key(key)
    if (isTRUE(isolate(external_plugins$inserted))) {
      try(bslib::nav_remove("main_nav", "plugin_directory", session = session),
        silent = TRUE)
      external_plugins$inserted <- FALSE
    }
    external_plugins$entries <- entries
    external_plugins$signature <- signature
    if (!isTRUE(settings$show_directory) || !nrow(entries)) return()

    for (index in seq_len(nrow(entries))) {
      local({
        entry <- entries[index, , drop = FALSE]
        external_plugin_output(entry)
      })
    }
    nav <- dava_external_plugin_nav(entries)
    if (!is.null(nav)) {
      bslib::nav_insert("main_nav", nav, target = "code_plugin_manager",
        position = "before", select = FALSE, session = session)
      external_plugins$inserted <- TRUE
    }
  })

  observeEvent(input$main_nav, {
    entries <- isolate(external_plugins$entries)
    entry <- entries[entries$nav_value == (input$main_nav %||% ""), ,
      drop = FALSE]
    if (!nrow(entry)) return()
    key <- entry$nav_value[[1L]]
    current <- isolate(external_plugins$instances[[key]])
    alive <- !is.null(current) && isTRUE(tryCatch(
      current$process$is_alive(), error = function(error) FALSE))
    if (alive) return()
    if (!is.null(current)) external_plugin_stop_key(key)
    tryCatch({
      datasets <- isolate(shared_file_rv$global_datasets %||% list())
      instance <- dava_external_plugin_start(entry, datasets)
      instances <- isolate(external_plugins$instances)
      instances[[key]] <- instance
      external_plugins$instances <- instances
      errors <- isolate(external_plugins$errors)
      errors[[key]] <- NULL
      external_plugins$errors <- errors
    }, error = function(error) {
      errors <- isolate(external_plugins$errors)
      errors[[key]] <- conditionMessage(error)
      external_plugins$errors <- errors
    })
  }, ignoreInit = TRUE)

  session$onSessionEnded(function() {
    instances <- isolate(external_plugins$instances)
    for (instance in instances) dava_external_plugin_stop(instance)
  })

  output$home_dataset_count <- renderText({
    length(shared_file_rv$global_datasets %||% list())
  })

  output$home_active_dataset <- renderText({
    shared_file_rv$active_dataset %||% "Not selected"
  })

  output$home_r_version <- renderText({
    paste0(R.version$major, ".", R.version$minor)
  })

  output$home_workdir <- renderText({
    normalizePath(getwd(), winslash = "/", mustWork = FALSE)
  })

  output$home_platform <- renderText({
    R.version$platform
  })

  output$home_started_at <- renderText({
    format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  })

  restore_workspace_input_values <- function(values, generation = NULL,
                                               passes = 1L) {
    if (!length(values)) return(invisible(FALSE))
    generation <- generation %||% isolate(
      shared_file_rv$workspace_restore_generation %||% 0L)
    passes <- max(1L, as.integer(passes))
    send_pass <- function(remaining) {
      try(session$sendCustomMessage(
        "dava-restore-inputs", list(
          values = values, generation = generation)), silent = TRUE)
      if (remaining > 1L) {
        later::later(function() send_pass(remaining - 1L), delay = 0.15)
      }
    }
    send_pass(passes)
    invisible(TRUE)
  }

  observeEvent(input$dava_workspace_inputs_applied, {
    acknowledgement <- input$dava_workspace_inputs_applied
    if (!is.list(acknowledgement)) return()
    dava_workspace_mark_inputs_restored(
      shared_file_rv,
      as.character(acknowledgement$ids %||% character()),
      acknowledgement$generation %||% -1L)
  }, ignoreInit = TRUE)

  workspace_restore_maybe_finalize <- function(generation = NULL) {
    generation <- generation %||% isolate(
      shared_file_rv$workspace_restore_generation %||% 0L)
    if (!dava_workspace_restore_matches(shared_file_rv, generation)) {
      return(invisible(FALSE))
    }
    required <- isolate(
      shared_file_rv$workspace_restore_required_modules %||% character())
    restored <- isolate(
      shared_file_rv$workspace_restored_modules %||% character())
    if (length(setdiff(required, restored))) return(invisible(FALSE))
    dava_workspace_finalize_restore(
      shared_file_rv, generation, clear_pending = FALSE)
  }

  workspace_module_ready <- function(nav_value) {
    if (!isTRUE(isolate(
      shared_file_rv$workspace_restore_in_progress %||% FALSE))) {
      return(invisible(FALSE))
    }
    restored <- isolate(
      shared_file_rv$workspace_restored_modules %||% character())
    shared_file_rv$workspace_restored_modules <- unique(c(restored, nav_value))
    pending <- isolate(shared_file_rv$workspace_pending_inputs %||% list())
    if (length(pending)) restore_workspace_input_values(pending)
    session$onFlushed(function() workspace_restore_maybe_finalize(), once = TRUE)
    invisible(TRUE)
  }

  lazy_module <- function(nav_value, output_id, ui_fun, server_fun = NULL, label = nav_value) {
    loaded <- FALSE
    loading <- FALSE
    output[[output_id]] <- renderUI({
      tags$div(
        class = "p-4 text-muted",
        tags$strong("Page to be loaded"),
        tags$div("The analysis interface and background logic will be automatically loaded when you open this page for the first time.")
      )
    })

    load_module <- function(notify = TRUE) {
      if (loaded) {
        workspace_module_ready(nav_value)
        return(invisible(FALSE))
      }
      if (loading) return(invisible(FALSE))
      loading <<- TRUE
      fail_loading <- function(error) {
        loading <<- FALSE
        loaded <<- FALSE
        message <- conditionMessage(error)
        output[[output_id]] <- renderUI(tags$div(
          class = "alert alert-danger m-3",
          tags$strong(paste0(label, "Loading failed")),
          tags$div(class = "mt-2", message),
          tags$div(class = "small mt-2",
            "Please switch to other pages and re-enter; the system will re-initialize the module.")
        ))
        showNotification(paste0(label, "Loading failed:", message),
          type = "error", duration = 10)
        invisible(FALSE)
      }

      ui_value <- tryCatch(ui_fun(), error = function(error) {
        fail_loading(error)
        NULL
      })
      if (is.null(ui_value)) return(invisible(FALSE))

      # Phase 1: publish the complete UI. Dynamic Shiny outputs cannot be
      # registered before their client-side containers have been inserted and
      # bound; otherwise the browser may discard their first values forever.
      output[[output_id]] <- renderUI(ui_value)

      # Phase 2: only after the UI-containing flush, register module servers.
      session$onFlushed(function() {
        tryCatch({
          if (!is.null(server_fun)) server_fun()
          loaded <<- TRUE
          loading <<- FALSE
          loaded_modules <- isolate(
            shared_file_rv$workspace_loaded_modules %||% character())
          shared_file_rv$workspace_loaded_modules <- unique(c(
            loaded_modules, nav_value))
          workspace_module_ready(nav_value)
          if (isTRUE(notify)) {
            showNotification(paste0("Loaded:", label),
              type = "message", duration = 2)
          }
        }, error = fail_loading)
      }, once = TRUE)
      invisible(TRUE)
    }

    observeEvent(input$main_nav, {
      if (!identical(input$main_nav, nav_value)) return()
      load_module(notify = TRUE)
    }, ignoreInit = FALSE)

    observeEvent(shared_file_rv$workspace_loaded_modules, {
      restored_modules <- shared_file_rv$workspace_loaded_modules %||% character()
      if (nav_value %in% restored_modules) load_module(notify = FALSE)
    }, ignoreInit = FALSE)
  }

  file_manager_loaded <- FALSE
  render_file_manager_placeholders <- function() {
    output$lazy_file_edit <- renderUI(mod_file_manger_ui("file_manager"))
    output$lazy_file_log <- renderUI(mod_file_manager_log_ui("file_manager"))
    output$lazy_micro_import <- renderUI(mod_file_manager_micro_import_ui("file_manager"))
  }

  output$lazy_file_edit <- renderUI(lazy_placeholder_message("File management"))
  output$lazy_file_log <- renderUI(lazy_placeholder_message("Operation log"))
  output$lazy_micro_import <- renderUI(lazy_placeholder_message("Microbial data import"))

  load_file_manager <- function(notify = TRUE) {
    if (file_manager_loaded) {
      workspace_module_ready("file_manager")
      return(invisible(FALSE))
    }
    file_manager_loaded <<- TRUE
    loaded_modules <- isolate(
      shared_file_rv$workspace_loaded_modules %||% character())
    shared_file_rv$workspace_loaded_modules <- unique(c(
      loaded_modules, "file_manager"))
    render_file_manager_placeholders()
    workspace_module_ready("file_manager")
    if (isTRUE(notify)) {
      showNotification("Loaded: File Management", type = "message", duration = 2)
    }
    invisible(TRUE)
  }

  observeEvent(input$main_nav, {
    if (!input$main_nav %in% c("file_edit", "file_log", "micro_import")) return()
    load_file_manager(notify = TRUE)
  }, ignoreInit = FALSE)

  observeEvent(shared_file_rv$workspace_loaded_modules, {
    restored_modules <- shared_file_rv$workspace_loaded_modules %||% character()
    if ("file_manager" %in% restored_modules) load_file_manager(notify = FALSE)
  }, ignoreInit = FALSE)

  select_main_nav <- function(value) {    #Compatible with both old and new bslib versionToggle navigation tab
    if ("nav_select" %in% getNamespaceExports("bslib")) {
      bslib::nav_select(id = "main_nav", selected = value, session = session)
    } else {
      updateNavbarPage(session, "main_nav", selected = value)
    }
  }

  observeEvent(input$home_open_file, {
    select_main_nav("file_edit")
  })
  observeEvent(input$home_open_microbe, {
    select_main_nav("microbiome_panel_alpha_diversity")
  })
  observeEvent(input$home_open_plot, {
    select_main_nav("analysis_plot_library")
  })
  observeEvent(input$home_open_stats, {
    select_main_nav("norm_variance")
  })
  lazy_module("norm_variance", "lazy_norm_variance",
    function() mod_norm_variance_ui("norm_variance"),
    function() mod_norm_variance_server("norm_variance", file_data = file_manager$rv),
    "Normality-Homogeneity of Variances Test"
  )

  lazy_module("t_one_sample", "lazy_t_one_sample",
    function() mod_ttest_ui("t_OneSample_module", title = "One-sample t-test", model_type = "t_OneSample"),
    function() mod_ttest_server("t_OneSample_module", file_data = file_manager$rv, model_type = "t_OneSample"),
    "One-sample t-test"
  )
  lazy_module("t_two_sample", "lazy_t_two_sample",
    function() mod_ttest_ui("t_TwoSample_module", title = "Two-sample t-test", model_type = "t_TwoSample"),
    function() mod_ttest_server("t_TwoSample_module", file_data = file_manager$rv, model_type = "t_TwoSample"),
    "Two-sample t-test"
  )
  lazy_module("t_two_sample_paired", "lazy_t_two_sample_paired",
    function() mod_ttest_ui("t_TwoSamplePaired_module", title = "Paired two-sample t-test", model_type = "t_TwoSamplePaired"),
    function() mod_ttest_server("t_TwoSamplePaired_module", file_data = file_manager$rv, model_type = "t_TwoSamplePaired"),
    "Paired two-sample t-test"
  )

  lazy_module("anova_crd", "lazy_anova_crd",
    function() mod_anova_ui("anova_CRD_module", title = "Completely Randomized ANOVA", model_type = "anova_CRD"),
    function() mod_anova_server("anova_CRD_module", file_data = file_manager$rv, model_type = "anova_CRD"),
    "Completely Randomized ANOVA"
  )
  lazy_module("anova_block", "lazy_anova_block",
    function() mod_anova_ui("anova_block_module", title = "Random block analysis of variance", model_type = "anova_block"),
    function() mod_anova_server("anova_block_module", file_data = file_manager$rv, model_type = "anova_block"),
    "Random block analysis of variance"
  )
  lazy_module("anova_repeated", "lazy_anova_repeated",
    function() mod_anova_ui("anova_repeated_module", title = "Repeated Measures Analysis of Variance", model_type = "anova_repeated"),
    function() mod_anova_server("anova_repeated_module", file_data = file_manager$rv, model_type = "anova_repeated"),
    "Repeated Measures Analysis of Variance"
  )
  lazy_module("ancova", "lazy_ancova",
    function() mod_anova_ui("ancova_module", title = "Analysis of covariance", model_type = "ancova"),
    function() mod_anova_server("ancova_module", file_data = file_manager$rv, model_type = "ancova"),
    "Analysis of covariance"
  )

  lazy_module("wilcoxon_one_sample", "lazy_wilcoxon_one_sample",
    function() mod_ttest_ui("Wilcoxon_OneSample_module", title = "One-sample Wilcoxon signed-rank test", model_type = "Wilcoxon_OneSample"),
    function() mod_ttest_server("Wilcoxon_OneSample_module", file_data = file_manager$rv, model_type = "Wilcoxon_OneSample"),
    "Single sample Wilcoxon"
  )
  lazy_module("wilcoxon_paired", "lazy_wilcoxon_paired",
    function() mod_ttest_ui("Wilcoxon_TwoSamplePaired_module", title = "Paired two-sample signed-rank test", model_type = "Wilcoxon_TwoSamplePaired"),
    function() mod_ttest_server("Wilcoxon_TwoSamplePaired_module", file_data = file_manager$rv, model_type = "Wilcoxon_TwoSamplePaired"),
    "Pairing Wilcoxon"
  )
  lazy_module("wmw_two_sample", "lazy_wmw_two_sample",
    function() mod_ttest_ui("WMW_TwoSample_module", title = "Two-sample Wilcoxon-Mann-Whitney test", model_type = "WMW_TwoSample"),
    function() mod_ttest_server("WMW_TwoSample_module", file_data = file_manager$rv, model_type = "WMW_TwoSample"),
    "Wilcoxon-Mann-Whitney"
  )
  lazy_module("kw_one_way", "lazy_kw_one_way",
    function() mod_ttest_ui("KW_OneWay_module", title = "One-way Kruskal-Wallis test", model_type = "KW_OneWay"),
    function() mod_ttest_server("KW_OneWay_module", file_data = file_manager$rv, model_type = "KW_OneWay"),
    "Kruskal-Wallis"
  )
  lazy_module("friedman_one_way", "lazy_friedman_one_way",
    function() mod_ttest_ui("Friedman_OneWay_module", title = "Single factor block Friedman test", model_type = "Friedman_OneWay"),
    function() mod_ttest_server("Friedman_OneWay_module", file_data = file_manager$rv, model_type = "Friedman_OneWay"),
    "Friedman test"
  )
  lazy_module("srh_two_way", "lazy_srh_two_way",
    function() mod_ttest_ui("SRH_TwoWay_module", title = "Two-factor Scheirer-Ray-Hare test", model_type = "SRH_TwoWay"),
    function() mod_ttest_server("SRH_TwoWay_module", file_data = file_manager$rv, model_type = "SRH_TwoWay"),
    "Scheirer-Ray-Hare"
  )
  lazy_module("art_anova", "lazy_art_anova",
    function() mod_ttest_ui("ART_ANOVA_module", title = "Aligned Rank Transformed ANOVA", model_type = "ART_ANOVA"),
    function() mod_ttest_server("ART_ANOVA_module", file_data = file_manager$rv, model_type = "ART_ANOVA"),
    "ART ANOVA"
  )

  lazy_module("lmm", "lazy_lmm",
    function() mod_anova_ui("LMM_module", "Linear Mixed Effects Model (LMM)", model_type = "LMM"),
    function() mod_anova_server("LMM_module", file_data = file_manager$rv, model_type = "LMM"),
    "LMM"
  )
  lazy_module("glmm", "lazy_glmm",
    function() mod_anova_ui("GLMM_module", "Generalized Linear Mixed Effects Model (GLMM)", model_type = "GLMM"),
    function() mod_anova_server("GLMM_module", file_data = file_manager$rv, model_type = "GLMM"),
    "GLMM"
  )

  lazy_advanced <- function(nav_value, output_id, module_id, title, analysis_type) {
    lazy_module(nav_value, output_id,
      function() mod_advanced_analysis_ui(module_id, title, analysis_type),
      function() mod_advanced_analysis_server(module_id, file_data = file_manager$rv, analysis_type = analysis_type),
      title
    )
  }
  lazy_advanced("reg_classic", "lazy_reg_classic", "reg_classic_module", "Ordinary least squares regression", "reg_classic")
  lazy_advanced("reg_glm", "lazy_reg_glm", "reg_glm_module", "Generalized linear model regression", "reg_glm")
  lazy_advanced("reg_mixed_zero", "lazy_reg_mixed_zero", "reg_mixed_zero_module", "Mixed Effects Model Regression", "reg_mixed_zero")
  lazy_advanced("reg_nonlinear_regularized", "lazy_reg_nonlinear_regularized", "reg_nonlinear_regularized_module", "Partial least squares regression", "reg_nonlinear_regularized")
  lazy_advanced("reg_mediation", "lazy_reg_mediation", "reg_mediation_module", "Piecewise threshold regression", "reg_mediation")
  lazy_advanced("reg_community", "lazy_reg_community", "reg_community_module", "Multiple regression tree", "reg_community")
  lazy_advanced("correlation", "lazy_correlation", "correlation_module", "Correlation analysis", "correlation")
  lazy_advanced("network_correlation", "lazy_network_correlation", "network_correlation_module", "Network correlation analysis", "network_correlation")
  lazy_advanced("micro_maaslin2", "lazy_micro_maaslin2", "micro_maaslin2_module", "MaAsLin2", "micro_maaslin2")
  lazy_advanced("micro_corncob", "lazy_micro_corncob", "micro_corncob_module", "corncob", "micro_corncob")
  lazy_advanced("micro_aldex2", "lazy_micro_aldex2", "micro_aldex2_module", "ALDEx2", "micro_aldex2")
  lazy_advanced("micro_multivariable_association", "lazy_micro_multivariable_association", "micro_multivariable_association_module", "Feature-level multivariate correlations", "micro_multivariable_association")
  lazy_advanced("micro_pgls", "lazy_micro_pgls", "micro_pgls_module", "Phylogenetic generalized least squares", "micro_pgls")
  lazy_advanced("micro_rda", "lazy_micro_rda", "micro_rda_module", "Redundancy Analysis (RDA)", "micro_rda")
  lazy_advanced("micro_cca", "lazy_micro_cca", "micro_cca_module", "Canonical Correspondence Analysis (CCA)", "micro_cca")
  lazy_advanced("micro_dbrda", "lazy_micro_dbrda", "micro_dbrda_module", "Distance Constrained Redundancy Analysis (dbRDA)", "micro_dbrda")
  lazy_module("sem", "lazy_sem",
    function() mod_structural_sem_ui("sem_module", "sem"),
    function() mod_structural_sem_server("sem_module", file_manager$rv, "sem"), "Structural Equation Modeling (SEM)")
  lazy_module("piecewise_sem", "lazy_piecewise_sem",
    function() mod_structural_sem_ui("piecewise_sem_module", "piecewise_sem"),
    function() mod_structural_sem_server("piecewise_sem_module", file_manager$rv, "piecewise_sem"), "Piecewise Structural Equation Model (piecewiseSEM)")
  lazy_module("plspm", "lazy_plspm",
    function() mod_structural_sem_ui("plspm_module", "plspm"),
    function() mod_structural_sem_server("plspm_module", file_manager$rv, "plspm"), "Least Squares Path Model (PLS-PM)")
  lazy_module("variable_importance", "lazy_variable_importance",
    function() mod_variable_importance_ui("variable_importance_module"),
    function() mod_variable_importance_server("variable_importance_module", file_data = file_manager$rv),
    "Variable importance analysis")

  lazy_plot <- function(nav_value, output_id, module_id, title, plot_type) {
    lazy_module(nav_value, output_id,
      function() mod_plotting_ui(module_id, title, plot_type),
      function() mod_plotting_server(module_id, file_data = file_manager$rv, plot_type = plot_type),
      title
    )
  }
  lazy_plot("plot_layout", "lazy_plot_layout", "plot_layout_module", "Figure layout and styling", "layout")
  lazy_module("analysis_data_library", "lazy_analysis_data_library",
    function() dava_analysis_data_library_ui("analysis_data_library_module"),
    function() dava_analysis_data_library_server("analysis_data_library_module", file_manager$rv), "Data table repository")
  lazy_module("analysis_plot_library", "lazy_analysis_plot_library",
    function() dava_analysis_plot_library_ui("analysis_plot_library_module"),
    function() dava_analysis_plot_library_server("analysis_plot_library_module", file_manager$rv), "Analysis plot library")

  lazy_module("code_manager", "lazy_code_manager",
    function() mod_code_plugin_manager_ui("code_manager_module", mode = "code"),
    function() mod_code_plugin_manager_server("code_manager_module", file_data = file_manager$rv, mode = "code"),
    "Code management"
  )
  lazy_module("plugin_manager", "lazy_plugin_manager",
    function() mod_code_plugin_manager_ui("plugin_manager_module", mode = "plugin"),
    function() mod_code_plugin_manager_server("plugin_manager_module", file_data = file_manager$rv, mode = "plugin"),
    "Plug-in management"
  )

  lazy_microbe_framework <- function(panel_id) {
    panel <- microbiome_panel_registry()
    category_id <- panel$secondary_category[match(panel_id, panel$id)]
    nav_value <- microbiome_panel_nav_value(panel_id)
    output_id <- paste0("lazy_", nav_value)
    module_id <- paste0(nav_value, "_module")
    lazy_module(nav_value, output_id,
      function() mod_microbiome_framework_ui(module_id, category_id, panel_id),
      function() mod_microbiome_framework_server(module_id, category_id, panel_id, file_data = file_manager$rv,
        requested_method = microbiome_method_request),
      panel$label_cn[match(panel_id, panel$id)]
    )
  }
  lapply(microbiome_panel_registry()$id, lazy_microbe_framework)

  observeEvent(input$main_nav, {
    method_id <- microbiome_method_from_nav_value(input$main_nav)
    if (nzchar(method_id)) {
      method <- MICROBIOME_METHOD_REGISTRY[MICROBIOME_METHOD_REGISTRY$id == method_id, , drop = FALSE]
      if (nrow(method)) {
        panel_id <- method$navigation_panel[[1]]
        microbiome_method_request_serial <<- microbiome_method_request_serial + 1L
        microbiome_method_request(list(method_id = method_id, category_id = method$navigation_category[[1]],
          panel_id = panel_id,
          serial = microbiome_method_request_serial))
        select_main_nav(microbiome_panel_nav_value(panel_id))
      }
      return()
    }
    target <- microbiome_legacy_nav_target(input$main_nav)
    if (!identical(target, input$main_nav)) select_main_nav(target)
  }, ignoreInit = TRUE)

  # Installed-package launchers can redirect mutable workspace files to a
  # user-writable directory while project-mode runs retain the historical
  # <project>/workspaces default.
  workspace_default_dir <- getOption(
    "dava.workspace_dir", file.path(getwd(), "workspaces"))
  choose_workspace_directory <- function(default) {
    dava_choose_directory(
      default = default, caption = "Select the DAVA working environment save directory")
  }

  capture_workspace <- function() dava_workspace_capture(
    shared_file_rv, input, current_nav = input$main_nav %||% "home",
    project_root = getwd())

  queue_workspace_import <- function(upload) {
    if (is.null(upload) || !nzchar(upload$datapath %||% "")) {
      stop("Please select the .davaws working environment file first.", call. = FALSE)
    }
    extension <- tolower(tools::file_ext(upload$name %||% ""))
    if (!extension %in% c("davaws", "rds")) {
      stop("Only .davaws or compatible .rds work environment files are supported.",
        call. = FALSE)
    }
    shared_file_rv$workspace_import_error <- ""
    shared_file_rv$workspace_import_request <- list(
      path = upload$datapath,
      name = upload$name,
      token = as.numeric(Sys.time()))
    invisible(TRUE)
  }

  observeEvent(input$workspace_nav_import, {
    tryCatch(queue_workspace_import(input$workspace_nav_file),
      error = function(error) {
        shared_file_rv$workspace_import_error <- conditionMessage(error)
        showNotification(conditionMessage(error), type = "error", duration = 8)
      })
  })

  output$workspace_nav_import_status <- renderText({
    error <- shared_file_rv$workspace_import_error %||% ""
    if (nzchar(error)) return(paste0("Import failed:", error))
    loaded <- shared_file_rv$workspace_last_loaded %||% ""
    if (nzchar(loaded)) return(paste0("Restored saved at:", loaded))
    "The working environment has not been imported yet."
  })

  output$workspace_nav_summary <- renderUI({
    datasets <- shared_file_rv$global_datasets %||% list()
    active <- shared_file_rv$active_dataset %||% "Not selected"
    tags$dl(
      tags$dt("data set"), tags$dd(length(datasets)),
      tags$dt("Current data set"), tags$dd(active),
      tags$dt("Recently imported"),
      tags$dd(shared_file_rv$workspace_last_loaded %||% "No records yet"),
      tags$dt("Recently saved"),
      tags$dd(shared_file_rv$workspace_last_saved %||% "No records yet")
    )
  })

  output$download_workspace_browser <- downloadHandler(
    filename = function() dava_workspace_file_name(
      input$workspace_name %||% "DAVA_workspace"),
    content = function(file) {
      workspace <- capture_workspace()
      saveRDS(workspace, file, version = 3, compress = "gzip")
      shared_file_rv$workspace_last_saved <- format(Sys.time(),
        "%Y-%m-%d %H:%M:%S")
    })

  observeEvent(input$btn_save, {
    showModal(modalDialog(
      title = "Save DAVA work environment",
      textInput("workspace_name", "Work environment name",
        paste0("DAVA_workspace_", format(Sys.time(), "%Y%m%d_%H%M%S"))),
      textInput("workspace_path", "Save directory", workspace_default_dir),
      actionButton("browse_workspace_path", "Select save directory",
        icon = icon("folder-open"), class = "btn-outline-secondary"),
      tags$div(class = "small text-muted mt-2",
        "Saved content includes shared data, workbooks, analysis parameters, graph properties, method codes, plug-in settings, logs, history, and current navigation state."),
      footer = tagList(
        modalButton("Cancel"),
        downloadButton("download_workspace_browser", "Download via browser",
          class = "btn-outline-primary"),
        actionButton("confirm_save", "Save to the specified directory", class = "btn-primary"))
    ))
  })

  observeEvent(input$browse_workspace_path, {
    selected <- tryCatch(
      choose_workspace_directory(input$workspace_path %||% workspace_default_dir),
      error = function(error) {
        showNotification(
          paste0("Unable to open directory selector:", conditionMessage(error),
                 ". Please fill in the save directory directly, or use a browser to download."),
          type = "error", duration = 8
        )
        NA_character_
      }
    )
    if (length(selected) == 1L && !is.na(selected) && nzchar(trimws(selected))) {
      updateTextInput(session, "workspace_path", value = normalizePath(
        selected, winslash = "/", mustWork = FALSE))
    } else {
      showNotification(
        "No saving directory is selected; you can directly fill in the path, or use the browser to download.",
        type = "message", duration = 5
      )
    }
  })

  observeEvent(input$confirm_save, {
    tryCatch({
      directory <- trimws(input$workspace_path %||% "")
      if (!nzchar(directory)) stop("Please select or fill in the save directory.", call. = FALSE)
      file_name <- dava_workspace_file_name(input$workspace_name)
      path <- file.path(directory, file_name)
      saved <- dava_workspace_save(capture_workspace(), path)
      shared_file_rv$workspace_last_saved <- saved
      removeModal()
      showNotification(paste0("Work environment saved:", saved),
        type = "message", duration = 8)
    }, error = function(error) showNotification(conditionMessage(error),
      type = "error", duration = 10))
  })

  restore_workspace_inputs <- function(workspace, generation) {
    values <- workspace$ui_inputs %||% list()
    values[c(
      "file_manager-select_global_dataset",
      "file_manager-book_select",
      "file_manager-sheet_select"
    )] <- NULL
    if (length(values)) restore_workspace_input_values(values, generation)
    target <- workspace$navigation$current %||% "home"
    if (nzchar(target)) try(select_main_nav(target), silent = TRUE)
    invisible(TRUE)
  }

  observeEvent(shared_file_rv$workspace_import_request, {
    request <- isolate(shared_file_rv$workspace_import_request)
    if (is.null(request) || !nzchar(request$path %||% "")) return()
    tryCatch({
      workspace <- dava_workspace_read(request$path)
      dava_workspace_restore_shared(shared_file_rv, workspace)
      restore_generation <- isolate(
        shared_file_rv$workspace_restore_generation %||% 0L)
      shared_file_rv$workspace_import_request <- NULL
      session$onFlushed(function() {
        tryCatch({
          restore_workspace_inputs(workspace, restore_generation)
          session$onFlushed(function() {
            tryCatch(
              workspace_restore_maybe_finalize(restore_generation),
              error = function(error) {
                dava_workspace_abort_restore(
                  shared_file_rv, restore_generation)
                showNotification(conditionMessage(error), type = "error", duration = 10)
              }
            )
          }, once = TRUE)
        }, error = function(error) {
          dava_workspace_abort_restore(shared_file_rv, restore_generation)
          showNotification(conditionMessage(error), type = "error", duration = 10)
        })
      }, once = TRUE)
      # Emergency release only: normal completion is driven by module-ready
      # acknowledgements, not a fixed rendering delay.
      later::later(function() {
        try(dava_workspace_finalize_restore(
          shared_file_rv, restore_generation, clear_pending = FALSE),
          silent = TRUE)
      }, delay = 15)
      showNotification(paste0("The working environment has been imported:",
        request$name %||% basename(request$path)), type = "message", duration = 8)
    }, error = function(error) {
      dava_workspace_abort_restore(shared_file_rv)
      shared_file_rv$workspace_import_request <- NULL
      shared_file_rv$workspace_import_error <- conditionMessage(error)
      showNotification(conditionMessage(error), type = "error", duration = 10)
    })
  }, ignoreInit = TRUE)

  observeEvent(input$btn_logout, {
    showModal(modalDialog(
      title = "Exit confirmation",
      tags$p("Are you sure to exit DAVA and completely end the current Shiny project process?"),
      tags$p(class = "text-danger small",
        "Unsaved analysis state will be lost; all external plug-in child processes will also be stopped."),
      footer = tagList(modalButton("Cancel"),
        actionButton("confirm_logout", "Confirm to exit and close", class = "btn-danger"))
    ))
  })

  observeEvent(input$confirm_logout, {
    removeModal()
    instances <- isolate(external_plugins$instances)
    for (instance in instances) dava_external_plugin_stop(instance)
    session$sendCustomMessage("dava-close-window", list())
    later::later(function() shiny::stopApp(
      returnValue = list(reason = "user_exit")), delay = 0.5)
  })
}

shinyApp(ui, server)
