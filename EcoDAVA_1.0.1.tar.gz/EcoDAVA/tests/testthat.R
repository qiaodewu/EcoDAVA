library(testthat)
library(EcoDAVA)

test_check("EcoDAVA")
