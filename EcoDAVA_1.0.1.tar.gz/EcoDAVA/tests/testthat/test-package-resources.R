test_that("installed application resources are complete", {
  app <- dava_app_dir()
  expect_true(file.exists(file.path(app, "app.R")))
  expect_true(file.exists(file.path(app, "R", "helpers.R")))
  expect_false(file.exists(file.path(app, "www", "code-workbench.js")))
  expect_false(file.exists(file.path(app, "www", "code-workbench.css")))
  code_support <- paste(readLines(file.path(app, "R", "module_support",
    "module_code_support.R"), warn = FALSE, encoding = "UTF-8"),
    collapse = "\n")
  expect_match(code_support, "module_code_rmd_document", fixed = TRUE)
  expect_true(file.exists(file.path(app, "www", "svgedit", "editor", "index.html")))
})

test_that("variable-importance multi-selects defer state updates until closing", {
  module_file <- file.path(dava_app_dir(), "R", "variable_importance",
    "mod_variable_importance.R")
  code <- paste(readLines(module_file, warn = FALSE, encoding = "UTF-8"),
    collapse = "\n")
  expect_match(code, "stateInput = TRUE", fixed = TRUE)
  expect_match(code,
    "list(input$predictors, input$predictors_open)", fixed = TRUE)
  expect_match(code,
    "if (isTRUE(input$predictors_open)) return()", fixed = TRUE)
  expect_match(code,
    "list(input$responses, input$responses_open)", fixed = TRUE)
})

test_that("ANOVA plot composition dependency is installed", {
  status <- dava_dependency_status(include_optional = FALSE)
  patchwork <- status[status$package == "patchwork", , drop = FALSE]
  expect_equal(nrow(patchwork), 1L)
  expect_true(patchwork$available)
  expect_identical(patchwork$role, "core")
})

test_that("local-archive bootstrap dependency is declared without blocking namespace load", {
  description <- utils::packageDescription("EcoDAVA")
  expect_match(description[["Suggests"]], "shinyjqui", fixed = TRUE)
  expect_match(description[["Config/EcoDAVA/BootstrapPackages"]], "shinyjqui",
    fixed = TRUE)
  expect_false(grepl("shinyjqui", description[["Imports"]], fixed = TRUE))
})

test_that("installed application parses as a Shiny app", {
  old <- setwd(dava_app_dir())
  on.exit(setwd(old), add = TRUE)
  expect_s3_class(shiny::shinyAppFile("app.R"), "shiny.appobj")
})

test_that("state directory can be redirected", {
  path <- file.path(tempdir(), paste0("dava-state-", Sys.getpid()))
  expect_true(dir.create(path, recursive = TRUE, showWarnings = FALSE) ||
    dir.exists(path))
  expect_true(dir.exists(normalizePath(path, mustWork = TRUE)))
})

test_that("default browser policy uses a configured standalone IDE window", {
  seen <- character()
  ide_window <- function(url) seen <<- url
  attr(ide_window, "shinyViewerType") <- "window"
  old <- options(shiny.launch.browser = ide_window, viewer = function(url) {
    stop("The embedded Viewer pane must not be used.")
  })
  on.exit(options(old), add = TRUE)
  browser <- EcoDAVA:::dava_browser_launcher()
  expect_true(is.function(browser))
  expect_identical(attr(browser, "dava.browser"), "ide-window")
  browser("http://127.0.0.1:12345")
  expect_identical(seen, "http://127.0.0.1:12345")
})

test_that("default browser policy falls back to the system browser", {
  old <- options(shiny.launch.browser = NULL, viewer = function(url) {
    stop("The embedded Viewer pane must not be used.")
  })
  on.exit(options(old), add = TRUE)
  if (!exists(".rs.invokeShinyWindowViewer", envir = baseenv(),
      mode = "function", inherits = FALSE)) {
    browser <- EcoDAVA:::dava_browser_launcher()
    expect_true(is.function(browser))
    expect_identical(attr(browser, "dava.browser"), "system-browser")
  }
})
