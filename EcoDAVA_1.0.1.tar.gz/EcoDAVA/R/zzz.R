.onAttach <- function(libname, pkgname) {
  # Local archive installation (repos = NULL) cannot resolve CRAN packages.
  # shinyjqui is intentionally bootstrapped on attach so library(EcoDAVA) can repair
  # the common incomplete-install case before the application is launched.
  if (!requireNamespace("shinyjqui", quietly = TRUE)) {
    tryCatch(
      dava_install_dependencies(include_optional = FALSE, update = FALSE),
      error = function(error) warning(
        "EcoDAVA loaded, but automatic dependency installation failed: ",
        conditionMessage(error),
        call. = FALSE
      )
    )
  }
  packageStartupMessage(
    "EcoDAVA 1.0.1: call EcoDAVA::run_dava() to launch the application."
  )
}
