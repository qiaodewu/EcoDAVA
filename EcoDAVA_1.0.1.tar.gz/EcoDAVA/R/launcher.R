#' Locate the installed DAVA application
#'
#' @return A normalized path to the installed Shiny application directory.
#' @export
dava_app_dir <- function() {
  path <- system.file("app", package = "EcoDAVA")
  if (!nzchar(path) || !dir.exists(path)) {
    stop("The installed DAVA application resources could not be located.",
      call. = FALSE)
  }
  normalizePath(path, winslash = "/", mustWork = TRUE)
}

#' Locate or create DAVA's user-writable state directory
#'
#' @param create Create the directory when it does not yet exist.
#' @return A normalized path to DAVA's per-user data directory.
#' @export
dava_state_dir <- function(create = TRUE) {
  path <- tools::R_user_dir("EcoDAVA", which = "data")
  if (isTRUE(create) && !dir.exists(path)) {
    if (!dir.create(path, recursive = TRUE, showWarnings = FALSE) &&
        !dir.exists(path)) {
      stop("Unable to create the DAVA state directory: ", path,
        call. = FALSE)
    }
  }
  normalizePath(path, winslash = "/", mustWork = isTRUE(create))
}

dava_core_packages <- function() {
  c(
    "shiny", "bslib", "shinyjs", "readxl", "writexl", "readr",
    "rhandsontable", "DT", "dplyr", "tibble", "stringr", "purrr",
    "shinyWidgets", "data.table", "tidyr", "rlang", "ggplot2",
    "nortest", "car", "MASS", "shinyjqui", "broom", "broom.mixed",
    "future", "promises", "later", "callr", "processx", "patchwork",
    "afex", "blme", "emmeans", "lme4", "multcomp", "multcompView"
  )
}

dava_optional_packages <- function() {
  c(
    "ape", "lavaan", "magick", "plotly", "png", "rstudioapi", "rsvg",
    "svglite", "vegan", "xml2"
  )
}

dava_user_library <- function() {
  configured <- strsplit(Sys.getenv("R_LIBS_USER", unset = ""),
    .Platform$path.sep, fixed = TRUE)[[1]][[1]]
  if (!nzchar(configured)) {
    r_minor <- strsplit(R.version$minor, ".", fixed = TRUE)[[1]][[1]]
    configured <- file.path(path.expand("~"), "R", "library",
      paste0(R.version$major, ".", r_minor))
  }
  configured <- path.expand(configured)
  if (!dir.exists(configured) &&
      !dir.create(configured, recursive = TRUE, showWarnings = FALSE)) {
    stop("Unable to create the personal R library: ", configured,
      call. = FALSE)
  }
  normalizePath(configured, winslash = "/", mustWork = TRUE)
}

#' Install or update DAVA dependencies
#'
#' Installs missing packages required to start DAVA. Set `update = TRUE` to
#' update installed DAVA dependencies when newer CRAN versions are available.
#'
#' @param include_optional Also install DAVA's optional analysis and export
#'   packages.
#' @param update Update installed dependencies in addition to installing
#'   missing ones.
#' @param ask Ask before updating packages when `update = TRUE`.
#' @param repos CRAN repository used for installation and update checks.
#' @return Invisibly, the dependency status after installation.
#' @export
dava_install_dependencies <- function(include_optional = FALSE,
                                      update = FALSE,
                                      ask = FALSE,
                                      repos = "https://cloud.r-project.org") {
  packages <- dava_core_packages()
  if (isTRUE(include_optional)) {
    packages <- unique(c(packages, dava_optional_packages()))
  }

  user_library <- dava_user_library()
  .libPaths(unique(c(user_library, .libPaths())))
  missing <- packages[!vapply(packages, requireNamespace, logical(1),
    quietly = TRUE)]
  if (length(missing)) {
    packageStartupMessage(
      "EcoDAVA is installing missing dependencies: ",
      paste(missing, collapse = ", ")
    )
    utils::install.packages(missing, lib = user_library, repos = repos,
      dependencies = NA)
  }

  if (isTRUE(update)) {
    old <- utils::old.packages(lib.loc = .libPaths(), repos = repos)
    if (!is.null(old) && nrow(old)) {
      outdated <- intersect(packages, rownames(old))
      if (length(outdated)) {
        packageStartupMessage(
          "EcoDAVA is updating dependencies: ",
          paste(outdated, collapse = ", ")
        )
        utils::install.packages(outdated, lib = user_library, repos = repos,
          dependencies = NA)
      }
    }
  }

  status <- dava_dependency_status(include_optional = include_optional)
  unresolved <- status$package[!status$available & status$role == "core"]
  if (length(unresolved)) {
    warning(
      "EcoDAVA could not install required packages: ",
      paste(unresolved, collapse = ", "),
      ". Check the network connection and CRAN repository settings.",
      call. = FALSE
    )
  }
  invisible(status)
}

#' Report DAVA dependency availability
#'
#' @param include_optional Include commonly used optional analysis and export
#'   packages in addition to the packages required at application startup.
#' @return A data frame with package, role, availability, and installed version.
#' @export
dava_dependency_status <- function(include_optional = TRUE) {
  packages <- dava_core_packages()
  roles <- rep("core", length(packages))
  if (isTRUE(include_optional)) {
    optional <- dava_optional_packages()
    packages <- c(packages, optional)
    roles <- c(roles, rep("optional", length(optional)))
  }
  available <- vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  versions <- vapply(seq_along(packages), function(index) {
    if (!available[[index]]) return(NA_character_)
    as.character(utils::packageVersion(packages[[index]]))
  }, character(1))
  data.frame(
    package = packages,
    role = roles,
    available = unname(available),
    version = versions,
    stringsAsFactors = FALSE
  )
}

dava_seed_plugins <- function(app_dir, plugin_dir) {
  bundled <- file.path(app_dir, "R", "plugin_apps")
  if (!dir.exists(bundled)) return(invisible(FALSE))
  existing <- list.files(plugin_dir, all.files = TRUE, no.. = TRUE)
  if (length(existing)) return(invisible(FALSE))
  entries <- list.files(bundled, all.files = TRUE, no.. = TRUE,
    full.names = TRUE)
  if (!length(entries)) return(invisible(FALSE))
  copied <- file.copy(entries, plugin_dir, recursive = TRUE,
    copy.mode = TRUE, copy.date = TRUE)
  invisible(all(copied))
}

dava_browser_launcher <- function() {
  rstudio_window <- get0(
    ".rs.invokeShinyWindowViewer",
    envir = baseenv(), mode = "function", inherits = FALSE
  )
  if (is.function(rstudio_window)) {
    launcher <- function(url) rstudio_window(url)
    attr(launcher, "dava.browser") <- "rstudio-window"
    return(launcher)
  }

  configured <- getOption("shiny.launch.browser")
  configured_type <- attr(configured, "shinyViewerType", exact = TRUE)
  if (is.function(configured) && identical(configured_type, "window")) {
    launcher <- function(url) configured(url)
    attr(launcher, "dava.browser") <- "ide-window"
    return(launcher)
  }

  launcher <- function(url) utils::browseURL(url)
  attr(launcher, "dava.browser") <- "system-browser"
  launcher
}

#' Run the DAVA application
#'
#' The installed application itself remains read-only. Workspaces, external
#' plugins, and plugin settings are stored below a per-user state directory.
#'
#' @param host Host interface passed to [shiny::runApp()].
#' @param port Port passed to [shiny::runApp()]. Use `NULL` to select an
#'   available port.
#' @param launch.browser Browser launch policy passed to [shiny::runApp()].
#'   The default `NULL` selects RStudio's standalone internal Shiny window
#'   (not the Viewer pane) when available and otherwise opens the URL in the
#'   operating system's default browser.
#' @param state_dir Optional user-writable directory for DAVA state.
#' @param ... Additional arguments passed to [shiny::runApp()].
#' @return The value returned by [shiny::runApp()], invisibly.
#' @export
run_dava <- function(host = "127.0.0.1", port = NULL,
                     launch.browser = NULL, state_dir = NULL, ...) {
  status <- dava_dependency_status(include_optional = FALSE)
  missing <- status$package[!status$available]
  if (length(missing)) {
    stop(
      "EcoDAVA cannot start because required packages are missing: ",
      paste(missing, collapse = ", "),
      ". Reinstall DAVA with dependencies = TRUE.",
      call. = FALSE
    )
  }

  app_dir <- dava_app_dir()
  if (is.null(state_dir)) state_dir <- dava_state_dir(create = TRUE)
  if (!dir.exists(state_dir) &&
      !dir.create(state_dir, recursive = TRUE, showWarnings = FALSE)) {
    stop("Unable to create state_dir: ", state_dir, call. = FALSE)
  }
  state_dir <- normalizePath(state_dir, winslash = "/", mustWork = TRUE)
  workspace_dir <- file.path(state_dir, "workspaces")
  plugin_dir <- file.path(state_dir, "plugin_apps")
  for (path in c(workspace_dir, plugin_dir)) {
    if (!dir.exists(path) &&
        !dir.create(path, recursive = TRUE, showWarnings = FALSE)) {
      stop("Unable to create DAVA writable directory: ", path,
        call. = FALSE)
    }
  }
  dava_seed_plugins(app_dir, plugin_dir)

  if (is.null(launch.browser)) {
    launch.browser <- dava_browser_launcher()
  }

  old_options <- options(
    dava.workspace_dir = workspace_dir,
    dava.external_plugin_root = plugin_dir
  )
  on.exit(options(old_options), add = TRUE)
  old_dir <- setwd(app_dir)
  on.exit(setwd(old_dir), add = TRUE)

  args <- c(
    list(appDir = app_dir, host = host, port = port,
      launch.browser = launch.browser),
    list(...)
  )
  invisible(do.call(shiny::runApp, args))
}
